# @dbp/ps-queue

PS.QUEUE — durable job queue platform service (GAP-BRS-2). **Session 1 slice**
(spec: `docs/03-features/specs/spec-ps-queue-2026-07-10.md`): Zod contracts,
the `QueueBackend` storage-adapter interface, an in-memory backend
(dev/demo-only, single process, lost on restart — NOT durable), and
`QUEUE_BACKEND` env-selection with production fail-fast. `enqueueJob`,
`getJob`, `listJobs` are the only server functions shipped so far.

**Not yet built** (later sessions, see the spec's §8 effort estimate — do not
assume these exist): the `pg-boss` backend, retry/backoff, dead-letter
transition, idempotency-key dedupe, PS.AUDIT lifecycle wiring, route handlers,
and the `./client` hooks. Selecting `QUEUE_BACKEND=pg-boss` today throws a
clear "not yet implemented" error rather than silently falling back to
in-memory.

Sits beside `@dbp/ps-scheduler`, not on top of it — no shared import either
direction (spec §1). Per the platform-services import-boundary rules this
package may import only `@dbp/contracts` from the workspace (currently
imports nothing from the workspace beyond `zod`).

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |

No `./client` export yet — Session 1 has no client-side surface.

## Config schema
`types.ts` — `JobEnvelopeSchema`, `EnqueueJobInputSchema`, `ListJobsFilterSchema` (Zod, source of truth; types are `z.infer`'d).

## Consumed by
Not yet wired into the generator or any solution — Session 1 is package
scaffold only. See `docs/03-features/specs/spec-ps-queue-2026-07-10.md` for
the intended consumers (escalation triggers, scheduled reminders, digest
notification sends, bulk change execution).

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client
delivery, ships as a packed `.tgz` tarball committed into the standalone's
`packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite
hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
