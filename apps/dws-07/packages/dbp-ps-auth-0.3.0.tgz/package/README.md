# @dbp/ps-auth

registryId: `PS.AUTH`

Authenticate users, issue and verify sessions, federate identity (SAML,
LDAP, DB-backed federated identity, JIT provisioning, MSAL). Built once at
Layer 06; solutions wire to the client SDK (`login`, `useAuth`,
`useSessionIdentity`) and never re-implement auth.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `./client/index.ts` (source) / `./dist/client/index.js` (published) |
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |

`publishConfig.exports` splits both entries to `dist/` with `.d.ts` types — same subpaths, built output only.

## Config schema
See `contract.yaml` (OpenAPI 3.0.3, generated via `pnpm contracts:gen` from the schemas in `contract/schemas.ts` — never hand-edited).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` registers `PS.AUTH` (dir `auth`, package `@dbp/ps-auth`, base path `/api/platform/auth`), wires `configureAuthClient`/`login` from `@dbp/ps-auth/client` and `useAuth`/`useSessionIdentity` into generated app pages, and is the only package the generated `middleware.ts` and auth API route import `@dbp/ps-auth/server` from (kept out of the edge runtime bundle deliberately — see inline comments in `scaffold-solution.mjs`).

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client delivery, ships as a packed `.tgz` tarball committed into the standalone's `packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
