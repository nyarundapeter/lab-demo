'use client'
import * as React from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { useAuth } from '@dbp/ps-auth/client'
import { toast } from '@dbp/ui'

export function SessionGuard({ children }: { children: React.ReactNode }) {
  const { user, status } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const hadSession = React.useRef(false)

  React.useEffect(() => {
    if (status === 'loading') return
    if (status === 'authenticated') { hadSession.current = true; return }
    if (hadSession.current) {
      toast({ title: 'Your session has expired. Signing you back in.' })
    }
    const from = encodeURIComponent(pathname)
    router.push(`/login?from=${from}`)
  }, [status, pathname, router])

  // Suppress unused-variable warning — user is present for future role checks
  void user

  return <>{children}</>
}
