import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import TransactionShell, { useSidePanel } from "../index.js";

vi.mock("next/navigation", () => ({
  useRouter: () => ({ push: vi.fn() }),
  usePathname: () => "/",
}))

vi.mock("@dbp/ps-auth/client", () => ({
  useAuth: () => ({ session: null, isLoading: true }),
}))

afterEach(() => {
  cleanup();
});

// ─── Slot rendering — empty state ─────────────────────────────────────────────

describe("slot rendering — empty state", () => {
  // Unfilled optional slots collapse — no dashed dev placeholder for ANY slot at
  // runtime (UI-audit fix). Slot frames appear only once populated.
  it("does NOT render an empty sidebar slot frame when no sidebar content provided", () => {
    const { container } = render(<TransactionShell />);
    const frame = container.querySelector('[data-slot-name="sidebar"]');
    expect(frame).toBeNull();
  });

  it("does NOT render an empty header slot frame when no header content provided", () => {
    const { container } = render(<TransactionShell />);
    const frame = container.querySelector('[data-slot-name="header"]');
    expect(frame).toBeNull();
  });

  it("does NOT render an empty main slot frame when no main content provided", () => {
    const { container } = render(<TransactionShell />);
    const frame = container.querySelector('[data-slot-name="main"]');
    expect(frame).toBeNull();
    expect(screen.queryByLabelText("Empty slot: main")).toBeNull();
  });

  it("renders sidebar + header slot frames once their slots have content", () => {
    const { container } = render(
      <TransactionShell
        slots={{
          sidebar: <div>s</div>,
          header: <div>h</div>,
          main: <div>m</div>,
        }}
      />,
    );
    for (const name of ["sidebar", "header", "main"]) {
      const el = container.querySelector(`[data-slot-name="${name}"]`);
      expect(el, `slot "${name}" not found`).toBeTruthy();
    }
  });

  it("context slot frame renders when context slot has content", () => {
    const { container } = render(
      <TransactionShell slots={{ context: <div data-testid="ctx">ctx</div> }} />,
    );
    // context slot frame may render in the inline panel or in a Sheet portal
    const inlineFrame =
      container.querySelector('[data-slot-name="context"]') ||
      document.querySelector('[data-slot-name="context"]');
    expect(inlineFrame).toBeTruthy();
  });

  it("context panel is hidden when context slot has no content", () => {
    const { container } = render(<TransactionShell />);
    // No inline context panel element — it should not render
    // The aside with aria-label="Context panel" should not be present
    const panel = container.querySelector('[aria-label="Context panel"]');
    expect(panel).toBeNull();
  });
});

// ─── Slot rendering — populated state ─────────────────────────────────────────

describe("slot rendering — populated state", () => {
  it("renders provided header content", () => {
    render(
      <TransactionShell
        slots={{ header: <nav data-testid="breadcrumb">Home / Orders</nav> }}
      />,
    );
    expect(screen.getByTestId("breadcrumb")).toBeTruthy();
    expect(screen.queryByText("slot:header")).toBeNull();
  });

  it("renders provided main content", () => {
    render(
      <TransactionShell slots={{ main: <div data-testid="entity-list">rows</div> }} />,
    );
    expect(screen.getByTestId("entity-list")).toBeTruthy();
  });

  it("renders all 4 slots populated simultaneously without errors", () => {
    render(
      <TransactionShell
        slots={{
          sidebar: <div data-testid="s-sidebar">sidebar</div>,
          header: <div data-testid="s-header">header</div>,
          main: <div data-testid="s-main">main</div>,
          context: <div data-testid="s-context">context</div>,
        }}
      />,
    );
    expect(screen.getByTestId("s-sidebar")).toBeTruthy();
    expect(screen.getByTestId("s-header")).toBeTruthy();
    expect(screen.getByTestId("s-main")).toBeTruthy();
    expect(screen.getByTestId("s-context")).toBeTruthy();
  });
});

// ─── Sidebar collapse toggle — click ─────────────────────────────────────────

describe("sidebar collapse toggle — click", () => {
  it("collapse toggle button is present and labelled", () => {
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    expect(btn).toBeTruthy();
  });

  it("collapse toggle starts expanded (aria-expanded=true)", () => {
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    expect(btn.getAttribute("aria-expanded")).toBe("true");
  });

  // Regression: the button's h-8 w-8 box previously kept the Button
  // component's default px-4 padding, leaving 0px of content width for the
  // hamburger icon (icon rendered but invisible). p-0 must win.
  it("collapse toggle has p-0 so its icon isn't squeezed to zero width by default button padding", () => {
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    expect(btn.className).toContain("p-0");
  });

  it("clicking the toggle collapses the sidebar (aria-expanded=false)", async () => {
    const user = userEvent.setup();
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    await user.click(btn);
    expect(btn.getAttribute("aria-expanded")).toBe("false");
  });

  it("clicking the toggle again re-expands the sidebar (aria-expanded=true)", async () => {
    const user = userEvent.setup();
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    await user.click(btn);
    await user.click(btn);
    expect(btn.getAttribute("aria-expanded")).toBe("true");
  });
});

// ─── Sidebar collapse toggle — keyboard ──────────────────────────────────────

describe("sidebar collapse toggle — keyboard", () => {
  it("Enter key on the toggle collapses the sidebar", async () => {
    const user = userEvent.setup();
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    btn.focus();
    await user.keyboard("{Enter}");
    expect(btn.getAttribute("aria-expanded")).toBe("false");
  });

  it("Space key on the toggle collapses the sidebar", async () => {
    const user = userEvent.setup();
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    btn.focus();
    await user.keyboard(" ");
    expect(btn.getAttribute("aria-expanded")).toBe("false");
  });

  it("toggle button is focusable", () => {
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    btn.focus();
    expect(document.activeElement).toBe(btn);
  });
});

// ─── Context panel optional behaviour ────────────────────────────────────────

describe("context panel optional behaviour", () => {
  it("context panel does not render when context slot is absent", () => {
    const { container } = render(<TransactionShell />);
    const panel = container.querySelector('[aria-label="Context panel"]');
    expect(panel).toBeNull();
  });

  it("context panel renders when context slot has content", () => {
    const { container } = render(
      <TransactionShell slots={{ context: <div>detail</div> }} />,
    );
    const panel = container.querySelector('[aria-label="Context panel"]');
    expect(panel).toBeTruthy();
  });

  it("contextOpen=false hides the inline context panel even when slot has content", () => {
    const { container } = render(
      <TransactionShell
        slots={{ context: <div>detail</div> }}
        contextOpen={false}
      />,
    );
    const panel = container.querySelector('[aria-label="Context panel"]');
    expect(panel).toBeNull();
  });

  it("close button calls onContextOpenChange(false) when rendered", async () => {
    const user = userEvent.setup();
    let called = false;
    render(
      <TransactionShell
        slots={{ context: <div>detail</div> }}
        onContextOpenChange={(open) => {
          if (!open) called = true;
        }}
      />,
    );
    const closeBtn = screen.getByRole("button", { name: /close context panel/i });
    await user.click(closeBtn);
    expect(called).toBe(true);
  });
});

// ─── Side panel chrome (RULING N10) ──────────────────────────────────────────

describe("side panel chrome — sidePanel prop", () => {
  it("renders the panel title when sidePanel.title is provided", () => {
    render(
      <TransactionShell
        slots={{ context: <div>ctx</div> }}
        sidePanel={{ title: "Assistant" }}
      />,
    );
    expect(screen.getByText("Assistant")).toBeTruthy();
  });

  it("renders a tab strip and switches tab content on click", async () => {
    const user = userEvent.setup();
    render(
      <TransactionShell
        sidePanel={{
          title: "Assistant",
          tabs: [
            { id: "ai", label: "AI assistant", content: <div>ai-body</div> },
            { id: "activity", label: "Activity", content: <div>activity-body</div> },
          ],
        }}
      />,
    );
    expect(screen.getByText("ai-body")).toBeTruthy();
    await user.click(screen.getByRole("tab", { name: "Activity" }));
    expect(screen.getByText("activity-body")).toBeTruthy();
  });

  it("panel opens without needing slots.context when sidePanel.tabs is populated", () => {
    const { container } = render(
      <TransactionShell sidePanel={{ tabs: [{ id: "a", label: "A", content: <div>x</div> }] }} />,
    );
    expect(container.querySelector('[aria-label="Context panel"]')).toBeTruthy();
  });
});

// ─── useSidePanel — imperative open/close hook (RULING N10) ─────────────────

describe("useSidePanel hook", () => {
  function Launcher() {
    const panel = useSidePanel();
    return (
      <button onClick={panel.toggle}>{panel.open ? "close" : "open"}</button>
    );
  }

  it("toggle() opens and closes the panel from a descendant component", async () => {
    const user = userEvent.setup();
    const { container } = render(
      <TransactionShell
        slots={{ context: <div>ctx</div>, main: <Launcher /> }}
      />,
    );
    expect(container.querySelector('[aria-label="Context panel"]')).toBeTruthy();
    await user.click(screen.getByRole("button", { name: "close" }));
    expect(container.querySelector('[aria-label="Context panel"]')).toBeNull();
    await user.click(screen.getByRole("button", { name: "open" }));
    expect(container.querySelector('[aria-label="Context panel"]')).toBeTruthy();
  });

  it("throws when used outside TransactionShell", () => {
    const BadConsumer = () => {
      useSidePanel();
      return null;
    };
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<BadConsumer />)).toThrow(
      /useSidePanel must be used within TransactionShell/,
    );
    spy.mockRestore();
  });
});

// ─── Theme token swap — structural stability ──────────────────────────────────

describe("theme token swap — structural stability", () => {
  it("same slot count after applying dbp-theme-alt class to container", () => {
    const { container } = render(
      <div className="dbp-alt-theme">
        <TransactionShell
          slots={{ sidebar: <div>s</div>, header: <div>h</div>, main: <div>m</div> }}
        />
      </div>,
    );
    const slots = container.querySelectorAll("[data-slot-name]");
    // sidebar, header, main = 3 (context not present without slot content)
    expect(slots.length).toBeGreaterThanOrEqual(3);
  });

  it("data-slot-name attributes are unchanged after theme class swap", () => {
    const { container } = render(<TransactionShell />);
    const slotsBefore = Array.from(container.querySelectorAll("[data-slot-name]")).map(
      (el) => el.getAttribute("data-slot-name"),
    );

    container.firstElementChild?.classList.add("dbp-alt-theme");

    const slotsAfter = Array.from(container.querySelectorAll("[data-slot-name]")).map(
      (el) => el.getAttribute("data-slot-name"),
    );
    expect(slotsAfter).toEqual(slotsBefore);
  });

  it("structural header element is preserved after theme class swap", () => {
    const { container } = render(<TransactionShell />);
    const headerBefore = container.querySelector("header");
    container.firstElementChild?.classList.add("dbp-alt-theme");
    const headerAfter = container.querySelector("header");
    expect(headerAfter).toBe(headerBefore);
  });

  it("all 4 slots queryable with context content after theme class swap", () => {
    const { container } = render(
      <TransactionShell
        slots={{
          sidebar: <div>s</div>,
          header: <div>h</div>,
          main: <div>m</div>,
          context: <div>c</div>,
        }}
      />,
    );
    container.firstElementChild?.classList.add("dbp-alt-theme");
    for (const name of ["sidebar", "header", "main", "context"]) {
      const el =
        container.querySelector(`[data-slot-name="${name}"]`) ||
        document.querySelector(`[data-slot-name="${name}"]`);
      expect(el, `slot "${name}" missing after theme swap`).toBeTruthy();
    }
  });
});

// ─── Nav props ────────────────────────────────────────────────────────────────

describe("nav props", () => {
  it("renders logo when provided", () => {
    render(
      <TransactionShell nav={{ logo: <span data-testid="logo">DBP</span> }} />,
    );
    expect(screen.getByTestId("logo")).toBeTruthy();
  });

  it("renders nav items when provided", () => {
    render(
      <TransactionShell
        nav={{
          items: [
            {
              id: "home",
              label: "Home",
              icon: <span>H</span>,
              href: "#",
            },
          ],
        }}
      />,
    );
    // Childless leaf items are real navigation targets — <a href> (D2 ruling).
    expect(screen.getByRole("link", { name: /home/i })).toBeTruthy();
  });

  it("marks active nav item with aria-current=page", () => {
    render(
      <TransactionShell
        nav={{
          items: [
            {
              id: "dashboard",
              label: "Dashboard",
              icon: <span>D</span>,
              active: true,
              // Match the mocked usePathname ("/") so AppSidebar marks it active.
              href: "/",
            },
          ],
        }}
      />,
    );
    const link = screen.getByRole("link", { name: /dashboard/i });
    expect(link.getAttribute("aria-current")).toBe("page");
  });

  it("renders breadcrumb in header zone", () => {
    render(
      <TransactionShell nav={{ breadcrumb: <span data-testid="bc">Home / Items</span> }} />,
    );
    expect(screen.getByTestId("bc")).toBeTruthy();
  });

  it("renders the enriched topBar in the top-bar slot when provided", () => {
    const { container } = render(
      <TransactionShell nav={{ topBar: <div data-testid="chrome">chrome</div> }} />,
    );
    expect(screen.getByTestId("chrome")).toBeTruthy();
    expect(container.querySelector('[data-slot-name="topBar"]')).toBeTruthy();
  });

  it("topBar replaces the legacy breadcrumb + actions layout", () => {
    render(
      <TransactionShell
        nav={{
          topBar: <div data-testid="chrome">chrome</div>,
          breadcrumb: <span data-testid="bc">crumbs</span>,
          actions: <button data-testid="legacy-action">x</button>,
        }}
      />,
    );
    // Chrome owns the bar — the legacy breadcrumb/actions zones are not rendered.
    expect(screen.getByTestId("chrome")).toBeTruthy();
    expect(screen.queryByTestId("bc")).toBeNull();
    expect(screen.queryByTestId("legacy-action")).toBeNull();
  });

  it("renders the footer in the footer region when nav.footer is provided", () => {
    const { container } = render(
      <TransactionShell nav={{ footer: <div data-testid="footer">© 2026</div> }} />,
    );
    expect(screen.getByTestId("footer")).toBeTruthy();
    expect(container.querySelector('[data-slot-name="footer"]')).toBeTruthy();
  });

  it("renders no footer region when nav.footer is omitted", () => {
    const { container } = render(<TransactionShell nav={{}} />);
    expect(container.querySelector('[data-slot-name="footer"]')).toBeNull();
  });
});

// ─── Shell v3.1 geometry (N29) ────────────────────────────────────────────
// Full-height sidebar owning the top-left corner; the top bar spans only the
// content column starting at the sidebar's right edge; exactly one breadcrumb
// (the top bar's) ever renders.

describe("shell v3.1 — full-height sidebar layout", () => {
  it("the sidebar and the content column (header + main) are siblings under one row container", () => {
    const { container } = render(
      <TransactionShell nav={{ identity: { code: "DBP.01", name: "Showcase" } }} />,
    );
    const sidebar = container.querySelector('aside[aria-label="Workspace navigation"]');
    const header = container.querySelector("header");
    expect(sidebar).toBeTruthy();
    expect(header).toBeTruthy();
    // The header must NOT be an ancestor of the sidebar, nor vice versa — they
    // are siblings in the row (sidebar spans full height; header spans only
    // the content column to its right).
    expect(sidebar!.contains(header!)).toBe(false);
    expect(header!.contains(sidebar!)).toBe(false);
    // Sidebar and the header's parent (content column) share the same parent
    // (the outer row container) — sidebar owns the full-height column, header
    // owns only the content column.
    expect(sidebar!.parentElement).toBe(header!.parentElement!.parentElement);
  });

  it("SidebarIdentity renders at the very top of the sidebar (above the nav)", () => {
    const { container } = render(
      <TransactionShell nav={{ identity: { code: "DBP.01", name: "Showcase" } }} />,
    );
    const sidebar = container.querySelector('aside[aria-label="Workspace navigation"]');
    expect(sidebar).toBeTruthy();
    expect(sidebar!.firstElementChild?.textContent).toContain("DBP.01");
  });

  it("collapsed sidebar keeps the identity square and stays full height (strip mode)", () => {
    const { container } = render(
      <TransactionShell
        nav={{ identity: { code: "DBP.01", name: "Showcase" }, defaultCollapsed: true }}
      />,
    );
    const sidebar = container.querySelector('aside[aria-label="Workspace navigation"]');
    expect(sidebar).toBeTruthy();
    // Collapsed identity square (initials) is still the first child.
    expect(sidebar!.firstElementChild?.textContent).toBeTruthy();
    expect((sidebar as HTMLElement).style.width).toBe("var(--shell-sidebar-collapsed-w)");
  });

  it("renders exactly one breadcrumb when both nav.topBar and a page-level breadcrumb-shaped slot are present", () => {
    render(
      <TransactionShell
        nav={{
          topBar: <nav data-testid="topbar-breadcrumb" aria-label="breadcrumb">Home / Item</nav>,
        }}
        slots={{ main: <div data-testid="page-body">body — no in-content breadcrumb</div> }}
      />,
    );
    // Exactly one breadcrumb-role/labelled element in the whole tree.
    const crumbs = screen.queryAllByLabelText("breadcrumb");
    expect(crumbs.length).toBe(1);
    expect(screen.getByTestId("topbar-breadcrumb")).toBeTruthy();
  });
});
