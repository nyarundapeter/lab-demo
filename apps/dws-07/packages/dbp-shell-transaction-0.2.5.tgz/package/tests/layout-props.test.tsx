import * as React from 'react'
import { describe, it, expect, afterEach } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'
import { PageHeader } from '@dbp/ui'

afterEach(cleanup)

// Helper: render a PageHeader with the given props inside a fragment — used to
// supply the header slot without importing the real layout under test.
// `subtitle` and unadorned `breadcrumb` are accepted but no longer rendered
// visibly (Amendment D-2, ADR-0052 — the shell's top bar owns page identity);
// pass `showBreadcrumb: true` to opt into the legacy no-chrome breadcrumb path.
function header(
  title: string,
  opts: {
    subtitle?: string
    breadcrumb?: { label: string; href?: string }[]
    showBreadcrumb?: boolean
    titleSpan?: 1 | 2 | 3
  } = {},
) {
  const { subtitle, breadcrumb, showBreadcrumb, titleSpan = 2 } = opts
  return (
    <PageHeader
      title={title}
      titleSpan={titleSpan}
      {...(subtitle !== undefined && { subtitle })}
      {...(breadcrumb !== undefined && { breadcrumb })}
      {...(showBreadcrumb !== undefined && { showBreadcrumb })}
    />
  )
}

describe('CanvasLayout — props', () => {
  it('renders title via header slot', async () => {
    const { CanvasLayout } = await import('../layouts/canvas.js')
    render(<CanvasLayout header={header('My Dashboard')}><div /></CanvasLayout>)
    expect(screen.getByText('My Dashboard')).toBeTruthy()
  })

  it('renders slot content', async () => {
    const { CanvasLayout } = await import('../layouts/canvas.js')
    render(
      <CanvasLayout
        slots={[{ id: 'w1', span: 6, content: <span>Widget A</span> }, { id: 'w2', span: 6, content: <span>Widget B</span> }]}
      />
    )
    expect(screen.getByText('Widget A')).toBeTruthy()
    expect(screen.getByText('Widget B')).toBeTruthy()
  })
})

describe('WorkingLayout — new props (alias for CanvasLayout)', () => {
  it('renders title via header slot', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout header={header('My Dashboard')}><div /></WorkingLayout>)
    expect(screen.getByText('My Dashboard')).toBeTruthy()
  })

  it('subtitle is accepted but not rendered (deprecated, Amendment D-2)', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout header={header('Tasks', { subtitle: '24 open' })}><div /></WorkingLayout>)
    expect(screen.queryByText('24 open')).toBeNull()
  })

  it('renders breadcrumb labels when showBreadcrumb is true (legacy no-chrome path)', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(
      <WorkingLayout
        header={header('Detail Page', {
          breadcrumb: [{ label: 'Home', href: '/' }, { label: 'Tasks', href: '/tasks' }, { label: 'Active Crumb' }],
          showBreadcrumb: true,
        })}
      >
        <div />
      </WorkingLayout>
    )
    const nav = screen.getByRole('navigation', { name: 'Breadcrumb' })
    expect(nav.textContent).toContain('Home')
    expect(nav.textContent).toContain('Tasks')
    expect(nav.textContent).toContain('Active Crumb')
  })
})

describe('AnalyticsLayout — new props', () => {
  it('renders title via header slot', async () => {
    const { AnalyticsLayout } = await import('../layouts/analytics.js')
    render(<AnalyticsLayout header={header('Revenue')}><div /></AnalyticsLayout>)
    expect(screen.getByText('Revenue')).toBeTruthy()
  })

  it('subtitle is accepted but not rendered (deprecated, Amendment D-2)', async () => {
    const { AnalyticsLayout } = await import('../layouts/analytics.js')
    render(<AnalyticsLayout header={header('Revenue', { subtitle: 'Last 30 days' })}><div /></AnalyticsLayout>)
    expect(screen.queryByText('Last 30 days')).toBeNull()
  })

  it('renders breadcrumb labels when showBreadcrumb is true (legacy no-chrome path)', async () => {
    const { AnalyticsLayout } = await import('../layouts/analytics.js')
    render(
      <AnalyticsLayout
        header={header('Revenue Page', {
          breadcrumb: [{ label: 'Analytics Section', href: '/analytics' }, { label: 'Revenue Crumb' }],
          showBreadcrumb: true,
        })}
      >
        <div />
      </AnalyticsLayout>
    )
    const nav = screen.getByRole('navigation', { name: 'Breadcrumb' })
    expect(nav.textContent).toContain('Analytics Section')
    expect(nav.textContent).toContain('Revenue Crumb')
  })
})

// ─── Page-header suppression contract (ARCHETYPE-REFERENCE-SPEC §3/§5) ─────────
// A1 header-led layouts render EXACTLY ONE PageHeader (marked [data-page-title])
// when a PageHeader is supplied via the header slot.
// A2 hero (content-landing) renders ZERO.
// ConversationalLayout is A1-based (CanvasLayout) and renders EXACTLY ONE when given a header.
// This locks the contract so a layout edit can't silently add or drop the page header.

describe('layout header-suppression contract', () => {
  it('content-landing renders NO page header', async () => {
    const { ContentLandingLayout } = await import('../layouts/content-landing.js')
    const { container } = render(<ContentLandingLayout><div /></ContentLandingLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(0)
  })

  it('conversational renders EXACTLY ONE page header when header slot is provided', async () => {
    const { ConversationalLayout } = await import('../layouts/conversational.js')
    const { container } = render(
      <ConversationalLayout
        header={<PageHeader title="AI Cockpit" />}
        thread={<div />}
        input={<div />}
      />
    )
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })

  it('working renders EXACTLY ONE page header when header slot is provided', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    const { container } = render(<WorkingLayout header={<PageHeader title="X" />}><div /></WorkingLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })

  it('analytics renders EXACTLY ONE page header when header slot is provided', async () => {
    const { AnalyticsLayout } = await import('../layouts/analytics.js')
    const { container } = render(<AnalyticsLayout header={<PageHeader title="X" />}><div /></AnalyticsLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })

  it('catalogue renders EXACTLY ONE page header when header slot is provided', async () => {
    const { CatalogueLayout } = await import('../layouts/catalogue.js')
    const { container } = render(<CatalogueLayout header={<PageHeader title="X" />}><div /></CatalogueLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })

  it('settings renders EXACTLY ONE page header when header slot is provided', async () => {
    const { SettingsLayout } = await import('../layouts/settings.js')
    const { container } = render(
      <SettingsLayout header={<PageHeader titleSpan={3} title="X" />} nav={<div />}>
        <div />
      </SettingsLayout>
    )
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })
})

// ─── Breadcrumb presence contract (spec §3 table) ─────────────────────────────
// Breadcrumb <nav> appears for header-led layouts ONLY when a breadcrumb is
// passed to the PageHeader header slot; content-landing never renders one.

describe('layout breadcrumb contract', () => {
  it('working renders NO breadcrumb nav when header has no breadcrumb', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout header={<PageHeader title="X" />}><div /></WorkingLayout>)
    expect(screen.queryByRole('navigation', { name: 'Breadcrumb' })).toBeNull()
  })

  it('working renders a breadcrumb nav when provided with showBreadcrumb', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(
      <WorkingLayout
        header={
          <PageHeader
            title="X"
            breadcrumb={[{ label: 'Home', href: '/' }, { label: 'X' }]}
            showBreadcrumb
          />
        }
      >
        <div />
      </WorkingLayout>
    )
    expect(screen.getByRole('navigation', { name: 'Breadcrumb' })).toBeTruthy()
  })

  it('content-landing renders NO breadcrumb nav', async () => {
    const { ContentLandingLayout } = await import('../layouts/content-landing.js')
    render(<ContentLandingLayout><div /></ContentLandingLayout>)
    expect(screen.queryByRole('navigation', { name: 'Breadcrumb' })).toBeNull()
  })

  it('settings renders NO breadcrumb nav when PageHeader has no breadcrumb', async () => {
    const { SettingsLayout } = await import('../layouts/settings.js')
    render(
      <SettingsLayout header={<PageHeader titleSpan={3} title="X" />} nav={<div />}>
        <div />
      </SettingsLayout>
    )
    expect(screen.queryByRole('navigation', { name: 'Breadcrumb' })).toBeNull()
  })
})

describe('CatalogueLayout — new props', () => {
  it('renders title via header slot', async () => {
    const { CatalogueLayout } = await import('../layouts/catalogue.js')
    render(<CatalogueLayout header={header('Products')}><div /></CatalogueLayout>)
    expect(screen.getByText('Products')).toBeTruthy()
  })

  it('subtitle is accepted but not rendered (deprecated, Amendment D-2)', async () => {
    const { CatalogueLayout } = await import('../layouts/catalogue.js')
    render(<CatalogueLayout header={header('Products', { subtitle: '142 items' })}><div /></CatalogueLayout>)
    expect(screen.queryByText('142 items')).toBeNull()
  })

  it('renders breadcrumb labels when showBreadcrumb is true (legacy no-chrome path)', async () => {
    const { CatalogueLayout } = await import('../layouts/catalogue.js')
    render(
      <CatalogueLayout
        header={header('Products Page', {
          breadcrumb: [{ label: 'Catalogue Section', href: '/catalogue' }, { label: 'Products Crumb' }],
          showBreadcrumb: true,
        })}
      >
        <div />
      </CatalogueLayout>
    )
    const nav = screen.getByRole('navigation', { name: 'Breadcrumb' })
    expect(nav.textContent).toContain('Catalogue Section')
    expect(nav.textContent).toContain('Products Crumb')
  })
})
