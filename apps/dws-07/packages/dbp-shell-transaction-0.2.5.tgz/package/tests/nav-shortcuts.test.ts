import { describe, it, expect } from "vitest";
import { deriveNavSequenceShortcuts } from "../nav-shortcuts.js";
import type { NavSection } from "@dbp/contracts";

const section = (id: string, label: string, href: string): NavSection => ({
  id,
  label,
  items: [{ id: `${id}-item`, label, href }],
});

describe("deriveNavSequenceShortcuts", () => {
  it("derives one g <letter> sequence per section from its label's first letter", () => {
    const { registrations, skipped } = deriveNavSequenceShortcuts([
      section("marketplace", "Marketplace", "/marketplace"),
      section("workspace", "Workspace", "/workspace"),
    ]);
    expect(registrations).toEqual([
      { letter: "m", keys: "g m", label: "Marketplace", href: "/marketplace" },
      { letter: "w", keys: "g w", label: "Workspace", href: "/workspace" },
    ]);
    expect(skipped).toEqual([]);
  });

  it("skips a later section whose first letter collides with an earlier one", () => {
    const { registrations, skipped } = deriveNavSequenceShortcuts([
      section("orientation", "Orientation", "/home"),
      section("operational-intelligence", "Operational Intelligence", "/insights"),
    ]);
    expect(registrations).toEqual([
      { letter: "o", keys: "g o", label: "Orientation", href: "/home" },
    ]);
    expect(skipped).toEqual([
      {
        label: "Operational Intelligence",
        letter: "o",
        reason: '"g o" already claimed by an earlier nav section',
      },
    ]);
  });

  it("skips a section whose letter collides with an existing single-key binding (j/k/c/n/[/]/?)", () => {
    // "Catalogue" -> "c" collides with the reserved single-key binding set.
    const { registrations, skipped } = deriveNavSequenceShortcuts([
      section("catalogue-area", "Catalogue", "/catalogue"),
    ]);
    expect(registrations).toEqual([]);
    expect(skipped).toEqual([
      {
        label: "Catalogue",
        letter: "c",
        reason: '"g c" collides with the existing "c" single-key binding',
      },
    ]);
  });

  it("skips a section with no navigable href anywhere in its tree", () => {
    const empty: NavSection = { id: "empty", label: "Empty", items: [] };
    const { registrations, skipped } = deriveNavSequenceShortcuts([empty]);
    expect(registrations).toEqual([]);
    expect(skipped).toEqual([{ label: "Empty", letter: "e", reason: "section has no navigable href" }]);
  });

  it("resolves an href nested under a group's children when the top-level item has none", () => {
    const nested: NavSection = {
      id: "workspace",
      label: "Workspace",
      items: [{ id: "group", label: "Manage Work", children: [{ id: "tasks", label: "Tasks", href: "/manage-work/tasks" }] }],
    };
    const { registrations } = deriveNavSequenceShortcuts([nested]);
    expect(registrations).toEqual([{ letter: "w", keys: "g w", label: "Workspace", href: "/manage-work/tasks" }]);
  });
});
