import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import TransactionShell from "../index.js";
import type { NavSection } from "@dbp/contracts";

const push = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({ push }),
  usePathname: () => "/",
}));

vi.mock("@dbp/ps-auth/client", () => ({
  useAuth: () => ({ session: null, isLoading: true }),
}));

afterEach(() => {
  cleanup();
  push.mockClear();
});

const SECTIONS: NavSection[] = [
  { id: "orientation", label: "Orientation", items: [{ id: "home", label: "Home", href: "/home" }] },
  { id: "marketplace", label: "Marketplace", items: [{ id: "browse", label: "Browse", href: "/marketplace" }] },
  {
    id: "operational-intelligence",
    label: "Operational Intelligence",
    items: [{ id: "insights", label: "Insights", href: "/insights" }],
  },
];

function typeSequence(first: string, second: string) {
  fireEvent.keyDown(window, { key: first });
  fireEvent.keyDown(window, { key: second });
}

describe("shell-level nav sequence shortcuts (deferral row 26)", () => {
  it("navigates to a section's href on g <letter>", () => {
    render(<TransactionShell nav={{ sections: SECTIONS }} />);
    typeSequence("g", "m");
    expect(push).toHaveBeenCalledWith("/marketplace");
  });

  it("navigates to a second, non-colliding section", () => {
    render(<TransactionShell nav={{ sections: SECTIONS }} />);
    typeSequence("g", "o");
    expect(push).toHaveBeenCalledWith("/home"); // Orientation wins the "o" slot
  });

  it("does not register a sequence for a section whose letter collided (Operational Intelligence)", () => {
    render(<TransactionShell nav={{ sections: SECTIONS }} />);
    typeSequence("g", "o");
    push.mockClear();
    // Nothing bound to a second "o" press mid-window; re-arm and confirm no
    // navigation to /insights ever happens via g o (Orientation already owns it).
    typeSequence("g", "o");
    expect(push).not.toHaveBeenCalledWith("/insights");
  });

  it("lists registered sequences in the ShortcutHelp overlay under Navigation", () => {
    render(<TransactionShell nav={{ sections: SECTIONS }} />);
    fireEvent.keyDown(window, { key: "?" });
    expect(screen.getByText("Navigation")).toBeTruthy();
    expect(screen.getByText("Go to Orientation")).toBeTruthy();
    expect(screen.getByText("Go to Marketplace")).toBeTruthy();
  });

  it("does not fire a sequence while typing in an input (typing guard)", () => {
    render(
      <TransactionShell
        nav={{ sections: SECTIONS }}
        slots={{ main: <input aria-label="search" /> }}
      />,
    );
    const input = screen.getByLabelText("search");
    input.focus();
    push.mockClear(); // drop SessionGuard's unrelated mount-time redirect push
    fireEvent.keyDown(input, { key: "g" });
    fireEvent.keyDown(input, { key: "m" });
    expect(push).not.toHaveBeenCalledWith("/marketplace");
  });
});
