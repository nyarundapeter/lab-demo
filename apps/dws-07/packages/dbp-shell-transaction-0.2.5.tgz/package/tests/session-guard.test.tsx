import * as React from 'react'
import { describe, it, expect, vi, afterEach } from 'vitest'
import { render, screen, cleanup, act } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

const mockPush = vi.fn()
vi.mock('next/navigation', () => ({
  useRouter: () => ({ push: mockPush }),
  usePathname: () => '/home',
}))

const mockUseAuth = vi.fn()
vi.mock('@dbp/ps-auth/client', () => ({ useAuth: () => mockUseAuth() }))

const mockToast = vi.fn()
vi.mock('@dbp/ui', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@dbp/ui')>()),
  toast: mockToast,
}))

afterEach(() => {
  cleanup()
  vi.clearAllMocks()
})

function wrapper({ children }: { children: React.ReactNode }) {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return <QueryClientProvider client={qc}>{children}</QueryClientProvider>
}

describe('SessionGuard', () => {
  it('renders children when session is valid', async () => {
    mockUseAuth.mockReturnValue({ user: { id: 'u1' }, status: 'authenticated' })
    const { SessionGuard } = await import('../session-guard.js')
    render(<SessionGuard><span>protected</span></SessionGuard>, { wrapper })
    expect(screen.getByText('protected')).toBeTruthy()
  })

  it('redirects to login when unauthenticated and no prior session', async () => {
    mockUseAuth.mockReturnValue({ user: null, status: 'unauthenticated' })
    const { SessionGuard } = await import('../session-guard.js')
    render(<SessionGuard><span>protected</span></SessionGuard>, { wrapper })
    await act(async () => { await new Promise(r => setTimeout(r, 100)) })
    expect(mockPush).toHaveBeenCalledWith('/login?from=%2Fhome')
  })

  it('shows a toast when session expires mid-session', async () => {
    mockUseAuth.mockReturnValue({ user: { id: 'u1' }, status: 'authenticated' })
    const { SessionGuard } = await import('../session-guard.js')
    const { rerender } = render(<SessionGuard><span>protected</span></SessionGuard>, { wrapper })
    mockUseAuth.mockReturnValue({ user: null, status: 'unauthenticated' })
    rerender(<SessionGuard><span>protected</span></SessionGuard>)
    await act(async () => { await new Promise(r => setTimeout(r, 100)) })
    expect(mockToast).toHaveBeenCalledWith(expect.objectContaining({ title: expect.stringContaining('session') }))
  })
})
