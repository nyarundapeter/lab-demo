import * as React from 'react'
import { describe, it, expect, afterEach } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'

afterEach(cleanup)

describe('ContentLandingLayout', () => {
  it('renders children in content area', async () => {
    const { ContentLandingLayout } = await import('../layouts/content-landing.js')
    render(<ContentLandingLayout><span>hero content</span></ContentLandingLayout>)
    expect(screen.getByText('hero content')).toBeTruthy()
  })
  it('does not render a page title block', async () => {
    const { ContentLandingLayout } = await import('../layouts/content-landing.js')
    const { container } = render(<ContentLandingLayout><div /></ContentLandingLayout>)
    expect(container.querySelector('[data-page-title]')).toBeNull()
  })
})

describe('CanvasLayout', () => {
  it('renders children when no slots provided', async () => {
    const { CanvasLayout } = await import('../layouts/canvas.js')
    render(<CanvasLayout><span>widgets</span></CanvasLayout>)
    expect(screen.getByText('widgets')).toBeTruthy()
  })

  it('renders slot content in a 12-col grid', async () => {
    const { CanvasLayout } = await import('../layouts/canvas.js')
    render(
      <CanvasLayout
        slots={[
          { id: 'a', span: 4, content: <span>slot-a</span> },
          { id: 'b', span: 6, content: <span>slot-b</span> },
        ]}
      />
    )
    expect(screen.getByText('slot-a')).toBeTruthy()
    expect(screen.getByText('slot-b')).toBeTruthy()
  })

  it('renders header node when provided', async () => {
    const { CanvasLayout } = await import('../layouts/canvas.js')
    render(
      <CanvasLayout header={<div data-testid="hdr">My Dashboard</div>}>
        <span>widgets</span>
      </CanvasLayout>
    )
    expect(screen.getByText('My Dashboard')).toBeTruthy()
    expect(screen.getByText('widgets')).toBeTruthy()
  })
})

describe('WorkingLayout (backward-compat alias)', () => {
  it('renders via the CanvasLayout alias', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout><span>widgets</span></WorkingLayout>)
    expect(screen.getByText('widgets')).toBeTruthy()
  })
})

describe('CollectionBoardLayout', () => {
  it('renders each column title, count, and card content', async () => {
    const { CollectionBoardLayout } = await import('../layouts/collection-board.js')
    render(
      <CollectionBoardLayout
        columns={[
          { id: 'open', title: 'Open', count: 32, children: <span>card-open</span> },
          { id: 'done', title: 'Done', count: 50, children: <span>card-done</span> },
        ]}
      />
    )
    expect(screen.getByText('Open')).toBeTruthy()
    expect(screen.getByText('32')).toBeTruthy()
    expect(screen.getByText('card-open')).toBeTruthy()
    expect(screen.getByText('Done')).toBeTruthy()
    expect(screen.getByText('50')).toBeTruthy()
    expect(screen.getByText('card-done')).toBeTruthy()
  })

  it('renders a column without a count', async () => {
    const { CollectionBoardLayout } = await import('../layouts/collection-board.js')
    render(
      <CollectionBoardLayout columns={[{ id: 'backlog', title: 'Backlog', children: <span>card</span> }]} />
    )
    expect(screen.getByText('Backlog')).toBeTruthy()
    expect(screen.queryByText('0')).toBeNull()
  })

  it('renders header node when provided', async () => {
    const { CollectionBoardLayout } = await import('../layouts/collection-board.js')
    render(
      <CollectionBoardLayout
        header={<div>Enquiries</div>}
        columns={[{ id: 'open', title: 'Open', children: <span>card</span> }]}
      />
    )
    expect(screen.getByText('Enquiries')).toBeTruthy()
  })

  it('renders filters node between header and columns when provided', async () => {
    const { CollectionBoardLayout } = await import('../layouts/collection-board.js')
    render(
      <CollectionBoardLayout
        filters={<div>Filter bar</div>}
        columns={[{ id: 'open', title: 'Open', children: <span>card</span> }]}
      />
    )
    expect(screen.getByText('Filter bar')).toBeTruthy()
  })

  it('renders each column as a labelled list region with a heading title', async () => {
    const { CollectionBoardLayout } = await import('../layouts/collection-board.js')
    render(
      <CollectionBoardLayout
        columns={[
          { id: 'open', title: 'Open', count: 32, children: <span>card-open</span> },
          { id: 'backlog', title: 'Backlog', children: <span>card-backlog</span> },
        ]}
      />
    )
    const lists = screen.getAllByRole('list')
    expect(lists).toHaveLength(2)
    expect(lists[0]?.getAttribute('aria-label')).toBe('Open (32)')
    expect(lists[1]?.getAttribute('aria-label')).toBe('Backlog')

    const heading = screen.getByRole('heading', { level: 3, name: 'Open' })
    expect(heading).toBeTruthy()
  })
})

describe('FormBasicLayout', () => {
  it('renders section titles and field content', async () => {
    const { FormBasicLayout } = await import('../layouts/form-basic.js')
    const { FormField, Input } = await import('@dbp/ui')
    render(
      <FormBasicLayout
        sections={[
          {
            id: 'details',
            title: 'Request Details',
            fields: [
              {
                id: 'title',
                content: (
                  <FormField label="Title">
                    <Input placeholder="Enter a concise title" />
                  </FormField>
                ),
              },
            ],
          },
        ]}
      />
    )
    expect(screen.getByText('Request Details')).toBeTruthy()
    expect(screen.getByPlaceholderText('Enter a concise title')).toBeTruthy()
  })

  it('renders header node when provided', async () => {
    const { FormBasicLayout } = await import('../layouts/form-basic.js')
    render(
      <FormBasicLayout
        header={<div>Create Regulatory Request</div>}
        sections={[{ id: 's', title: 'Section', fields: [] }]}
      />
    )
    expect(screen.getByText('Create Regulatory Request')).toBeTruthy()
  })

  it('renders section heading as an h2', async () => {
    const { FormBasicLayout } = await import('../layouts/form-basic.js')
    render(
      <FormBasicLayout sections={[{ id: 's', title: 'Assignment', fields: [] }]} />
    )
    expect(screen.getByRole('heading', { level: 2, name: 'Assignment' })).toBeTruthy()
  })

  it('does not render a sticky/fixed bottom action bar', async () => {
    const { FormBasicLayout } = await import('../layouts/form-basic.js')
    const { container } = render(
      <FormBasicLayout sections={[{ id: 's', title: 'Section', fields: [] }]} />
    )
    const fixedBottomBar = container.querySelector('[class*="fixed"][class*="bottom-0"]')
    expect(fixedBottomBar).toBeNull()
  })

  it('wires aria-required on required fields', async () => {
    const { FormBasicLayout } = await import('../layouts/form-basic.js')
    const { FormField, Input } = await import('@dbp/ui')
    render(
      <FormBasicLayout
        sections={[
          {
            id: 's',
            title: 'Section',
            fields: [
              {
                id: 'title',
                content: (
                  <FormField label="Title" required>
                    <Input placeholder="Enter title" />
                  </FormField>
                ),
              },
            ],
          },
        ]}
      />
    )
    const input = screen.getByPlaceholderText('Enter title')
    expect(input.getAttribute('aria-required')).toBe('true')
  })
})

describe('FormGuidedLayout', () => {
  const steps = [
    { id: 'details', label: 'Request Details', title: 'Request Details' },
    { id: 'scope', label: 'Scope', title: 'Scope' },
    { id: 'review-setup', label: 'Review Setup', title: 'Review Setup' },
    { id: 'confirm', label: 'Confirm & Submit', title: 'Confirm & Submit' },
  ]

  it("renders the active step's content and heading", async () => {
    const { FormGuidedLayout } = await import('../layouts/form-guided.js')
    render(
      <FormGuidedLayout steps={steps} currentStep={1} onContinue={() => {}}>
        <span>scope body</span>
      </FormGuidedLayout>
    )
    expect(screen.getByRole('heading', { name: 'Scope' })).toBeTruthy()
    expect(screen.getByText('scope body')).toBeTruthy()
  })

  it('shows the current step as active and earlier steps as completed', async () => {
    const { FormGuidedLayout } = await import('../layouts/form-guided.js')
    const { container } = render(
      <FormGuidedLayout steps={steps} currentStep={2} onContinue={() => {}}>
        <span>body</span>
      </FormGuidedLayout>
    )
    // exactly one step circle carries aria-current="step" (the active step, index 2)
    const activeCircles = container.querySelectorAll('[aria-current="step"]')
    expect(activeCircles).toHaveLength(1)
    expect(activeCircles[0]?.textContent).toBe('3')
  })

  it('renders header when provided', async () => {
    const { FormGuidedLayout } = await import('../layouts/form-guided.js')
    render(
      <FormGuidedLayout
        header={<div>New Compliance Review Request</div>}
        steps={steps}
        currentStep={0}
        onContinue={() => {}}
      >
        <span>body</span>
      </FormGuidedLayout>
    )
    expect(screen.getByText('New Compliance Review Request')).toBeTruthy()
  })

  it('bottom nav has only Back/Continue — no Save draft control', async () => {
    const { FormGuidedLayout } = await import('../layouts/form-guided.js')
    render(
      <FormGuidedLayout steps={steps} currentStep={1} onBack={() => {}} onContinue={() => {}}>
        <span>body</span>
      </FormGuidedLayout>
    )
    expect(screen.getByRole('button', { name: 'Back' })).toBeTruthy()
    expect(screen.getByRole('button', { name: 'Continue' })).toBeTruthy()
    expect(screen.queryByRole('button', { name: /save draft/i })).toBeNull()
  })

  it('Back is absent on the first step', async () => {
    const { FormGuidedLayout } = await import('../layouts/form-guided.js')
    render(
      <FormGuidedLayout steps={steps} currentStep={0} onContinue={() => {}}>
        <span>body</span>
      </FormGuidedLayout>
    )
    expect(screen.queryByRole('button', { name: 'Back' })).toBeNull()
  })

  it('uses a custom continue label (e.g. "Submit" on the final step)', async () => {
    const { FormGuidedLayout } = await import('../layouts/form-guided.js')
    render(
      <FormGuidedLayout
        steps={steps}
        currentStep={3}
        onBack={() => {}}
        onContinue={() => {}}
        continueLabel="Submit"
      >
        <span>body</span>
      </FormGuidedLayout>
    )
    expect(screen.getByRole('button', { name: 'Submit' })).toBeTruthy()
    expect(screen.queryByRole('button', { name: 'Continue' })).toBeNull()
  })

  it('renders the info rail progress label, auto-save note, and help link', async () => {
    const { FormGuidedLayout } = await import('../layouts/form-guided.js')
    render(
      <FormGuidedLayout
        steps={steps}
        currentStep={0}
        onContinue={() => {}}
        infoRail={{
          progressLabel: 'Step 1 of 4',
          autoSaveNote: 'Your draft will be saved automatically.',
          helpLink: { label: 'View request guidelines', href: '#' },
        }}
      >
        <span>body</span>
      </FormGuidedLayout>
    )
    expect(screen.getByText('Step 1 of 4')).toBeTruthy()
    expect(screen.getByText('Your draft will be saved automatically.')).toBeTruthy()
    expect(screen.getByRole('link', { name: 'View request guidelines' })).toBeTruthy()
  })
})

describe('ConversationalLayout', () => {
  it('renders thread and input', async () => {
    const { ConversationalLayout } = await import('../layouts/conversational.js')
    render(
      <ConversationalLayout
        thread={<span>messages</span>}
        input={<span>composer</span>}
      />
    )
    expect(screen.getByText('messages')).toBeTruthy()
    expect(screen.getByText('composer')).toBeTruthy()
  })

  it('renders header node when provided', async () => {
    const { ConversationalLayout } = await import('../layouts/conversational.js')
    render(
      <ConversationalLayout
        header={<div>AI Cockpit</div>}
        thread={<span>messages</span>}
        input={<span>composer</span>}
      />
    )
    expect(screen.getByText('AI Cockpit')).toBeTruthy()
  })
})
