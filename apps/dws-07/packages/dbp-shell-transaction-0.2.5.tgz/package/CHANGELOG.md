# Changelog

All notable changes to this package are documented here.

## [0.2.5] - 2026-07-28
### Fixed
- Collapsed sidebar group flyout (D6, second root cause — the 0.2.4 fix
  below was real and stays, but did not fully fix the flicker): Sharavi's
  precise repro was resting the pointer ON THE TRIGGER ICON with the flyout
  open — not moving into the flyout, which is what the 0.2.4 fix addressed.
  Measured: 32 opens / 31 closes over a 2.5s dwell, perfect alternation at
  ~13Hz, `getComputedStyle(document.body).pointerEvents === "none"` while
  the loop ran. Root cause: Radix `DropdownMenu` is MODAL by default — while
  open it sets `pointer-events: none` on the rest of the document, INCLUDING
  the trigger the pointer is resting on. That fires a synthetic pointer-leave
  on the trigger, our hover-leave handler reads it as "the user left" and
  closes the menu; pointer-events is restored, the (unmoved) pointer
  re-enters the trigger, and it reopens — a tight loop. Fixed by passing
  `modal={false}` to `DropdownMenu` — also correct on its own merits, since a
  navigation flyout should not trap focus or make the rest of the page inert
  like a dialog. Verified: resting on a rail icon for 2.5s now logs exactly 1
  open / 0 close and `document.body`'s `pointer-events` stays `"auto"`
  throughout; Escape-to-close, click-outside-to-close, and keyboard-open
  focus-into-first-item all still work with `modal={false}` (re-verified,
  not assumed — Radix changes some of this behaviour between modal and
  non-modal).

## [0.2.4] - 2026-07-28
### Fixed
- Collapsed sidebar group flyout (D6, regression in the D1 fix): the flyout
  flickered/strobed on hover. Root cause was two-fold — (1) `DropdownMenuContent`
  used the default `sideOffset` (8px), leaving a dead-space gap between the
  rail icon and the flyout that the pointer had to cross blind, and any
  hesitation there fired a close; (2) open/close state was local to each
  `CollapsedGroupFlyout` instance, so sweeping between two adjacent icons
  could leave both transiently "open" for the length of the close-grace
  timer instead of one flipping the other off synchronously. Fixed by (1)
  setting `sideOffset={0}` so the flyout abuts the rail with zero gap, and
  (2) lifting open/close state to a single `openGroupId` owned by
  `TransactionShell`, so hovering a new icon closes any previously-open one
  in the same render (`openGroup`) while a hover-leave with nothing else
  taking over debounces via `closeGroupSoon` (150ms grace period); Radix's
  own authoritative open/close signals (click, Escape, outside-click, item
  select) apply immediately via `closeGroupNow`, never debounced.

## [0.2.3] - 2026-07-28
### Fixed
- Collapsed sidebar icon strip: a group icon (a container with `children`)
  no longer builds a fallback link to its first child's `href` (that earlier
  approach was rejected — it silently routes the user somewhere they didn't
  choose and makes the rest of the group unreachable). It now opens a
  hover/keyboard flyout listing the group's children, built on the existing
  `DropdownMenu` primitive (`@dbp/ui`) — portal-rendered so it escapes the
  64px rail's `overflow-hidden`, with Radix's built-in keyboard roving,
  Escape-to-close, and ARIA menu semantics. Nested (grandchild) groups
  recurse via `DropdownMenuSub`. A childless group icon with its own `href`
  still navigates directly. A group with neither `href` nor children is a
  config problem — renders non-interactive (`aria-disabled`, dimmed) instead
  of a dead link to `"#"` (D1 defect).
- Collapsed sidebar rail: the `nav.logo` fallback identity block (used when
  neither `identitySlot` nor `identity` is supplied) now centers the mark on
  the same axis as the nav icons below it when collapsed, matching
  `SidebarIdentity`'s existing collapsed treatment; the expanded rail keeps
  its left-aligned padding (D3 defect).
- Mobile nav drawer: `AppSidebar`'s `onNavigate` callback discarded the
  clicked item's `href` and only closed the drawer — every mobile nav click
  went nowhere. Now pushes the route via `next/navigation`'s `router.push`
  and then closes the drawer (D4 defect).

## [0.2.2] - 2026-07-27
### Fixed
- Desktop sidebar-collapse toggle and mobile hamburger buttons: the shell used
  a bare `h-8 w-8` override on the shared `Button` component, but `Button`'s
  default size variant (`h-[var(--form-field-h)] px-4`) still applied 16px of
  horizontal padding either side — inside a 32px box that left 0px of content
  width, so the hamburger `<svg>` rendered at `width: 0` (present in the DOM,
  invisible on screen). Added `p-0` so the icon has room to render.

## [0.2.1] - 2026-07-18
### Fixed
- DQ-Shell defect-inventory pass (DR-4, `docs/03-features/audits/dq-defect-inventory-2026-07-18.md`):
  the page-body root now sets `overflow-x-hidden` as a backstop — no descendant (header,
  banner, main, or a feature's internal scroll region) can push the document itself into
  horizontal scroll. Wide content must scroll inside its own bounded container instead.

## [0.2.0] - 2026-07-18
### Added
- `nav.banner` (NOT-03/NOT-15) — shell-owned region rendered directly below
  the global top bar, spanning the main+context column. Hosts app/page-level
  `Alert` banners (solid `critical` = non-dismissible) and the Collaboration
  announcement banner. Generic by design, same pattern as `nav.topBar`/
  `nav.footer`; renders nothing when omitted (backward compatible).

## [0.1.0] - 2026-07-10
Initial documented baseline.
