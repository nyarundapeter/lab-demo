"use client"
// PROTOTYPE (hand-edited for approval) — real change goes into the generator after sign-off.
// FormBuilderView — body-only 3-panel builder feature.
// Palette | Canvas | Properties. The enclosing BuilderLayout owns the PageHeader + Publish action.
// The canvas root is wrapped in <form id="form-builder"> so the layout's Save targets it.
//
// ADR-0035 compliance:
//   - @dbp/ui components + dq-* classes + CSS token vars only.
//   - No raw <a>/<nav>/<button>/<input> outside @dbp/ui wrappers.
//   - No hardcoded hex, no color-mix, no arbitrary [...] hex classes.
//   - Body-only — no PageHeader here; one PageHeader lives in BuilderLayout.
import * as React from 'react'
import { useState, useCallback } from 'react'
import { Button, Badge, Input, Switch, FieldLabel, ScrollArea, Separator } from '@dbp/ui'
import {
  Type,
  AlignJustify,
  Hash,
  Mail,
  ChevronDown,
  ToggleLeft,
  Calendar,
  Upload,
  Heading,
  Minus,
  ChevronUp,
  Trash2,
  GripVertical,
  Eye,
} from 'lucide-react'

// ─── Types ────────────────────────────────────────────────────────────────────

type FieldType =
  | 'text' | 'email' | 'number' | 'select'
  | 'textarea' | 'checkbox' | 'date' | 'file'
  | 'heading' | 'divider'

interface PaletteItem {
  type: FieldType
  label: string
  hint: string
  Icon: React.ElementType
  /** Badge tone from the design system's valid set — no hex. */
  tone: 'info' | 'success' | 'warning' | 'danger' | 'default' | 'gray' | 'navy' | 'orange'
}

const PALETTE: PaletteItem[] = [
  { type: 'text',     label: 'Short Text',  hint: 'Single-line',   Icon: Type,         tone: 'info'    },
  { type: 'textarea', label: 'Long Text',   hint: 'Multi-line',    Icon: AlignJustify, tone: 'navy'    },
  { type: 'number',   label: 'Number',      hint: 'Numeric',       Icon: Hash,         tone: 'default' },
  { type: 'email',    label: 'Email',       hint: 'Email address', Icon: Mail,         tone: 'info'    },
  { type: 'select',   label: 'Dropdown',    hint: 'Pick one',      Icon: ChevronDown,  tone: 'orange'  },
  { type: 'checkbox', label: 'Checkbox',    hint: 'True / false',  Icon: ToggleLeft,   tone: 'success' },
  { type: 'date',     label: 'Date',        hint: 'Date picker',   Icon: Calendar,     tone: 'success' },
  { type: 'file',     label: 'File Upload', hint: 'Attachment',    Icon: Upload,       tone: 'gray'    },
  { type: 'heading',  label: 'Heading',     hint: 'Section label', Icon: Heading,      tone: 'navy'    },
  { type: 'divider',  label: 'Divider',     hint: 'Visual break',  Icon: Minus,        tone: 'gray'    },
]

interface Field {
  id: string
  type: FieldType
  label: string
  placeholder?: string
  required: boolean
}

const SEED: Field[] = [
  { id: 'f1', type: 'text',     label: 'Full Name',       placeholder: 'Enter your full name',  required: true  },
  { id: 'f2', type: 'email',    label: 'Email Address',   placeholder: 'you@example.com',       required: true  },
  { id: 'f3', type: 'select',   label: 'Department',                                            required: false },
  { id: 'f4', type: 'textarea', label: 'Request Details', placeholder: 'Describe your request', required: false },
]

// ─── Field preview (skeleton of the field input) ─────────────────────────────

function FieldPreview({ f }: { f: Field }) {
  if (f.type === 'divider') {
    return <Separator className="my-1" />
  }
  if (f.type === 'heading') {
    return (
      <p className="text-sm font-bold text-[var(--color-text-disabled)]">
        Section Title
      </p>
    )
  }
  if (f.type === 'checkbox') {
    return (
      <div className="flex items-center gap-2 h-8">
        <span className="w-4 h-4 rounded border border-[var(--color-border)] shrink-0 inline-block" />
        <span className="text-xs text-[var(--color-text-muted)]">Checkbox option</span>
      </div>
    )
  }
  if (f.type === 'select') {
    return (
      <div className="flex items-center justify-between h-8 px-2.5 rounded-[var(--radius-input)] border border-[var(--color-border)] bg-[var(--color-surface-raised)] text-xs text-[var(--color-text-muted)]">
        <span>Select an option</span>
        <ChevronDown size={12} className="opacity-40 shrink-0" />
      </div>
    )
  }
  if (f.type === 'textarea') {
    return (
      <div className="flex items-start pt-2 px-2.5 h-16 rounded-[var(--radius-input)] border border-[var(--color-border)] bg-[var(--color-surface-raised)] text-xs text-[var(--color-text-muted)]">
        {f.placeholder ?? 'Long text...'}
      </div>
    )
  }
  if (f.type === 'file') {
    return (
      <div className="flex items-center justify-center gap-1.5 h-12 rounded-[var(--radius-input)] border-2 border-dashed border-[var(--color-border)] text-xs text-[var(--color-text-muted)]">
        <Upload size={12} />
        Drop files or click to upload
      </div>
    )
  }
  return (
    <div className="flex items-center h-8 px-2.5 rounded-[var(--radius-input)] border border-[var(--color-border)] bg-[var(--color-surface-raised)] text-xs text-[var(--color-text-muted)]">
      {f.placeholder ?? `Enter ${f.label.toLowerCase()}...`}
    </div>
  )
}

// ─── Canvas field card ────────────────────────────────────────────────────────

function FieldCard({
  f, idx, total, active, onSelect, onMove, onDelete,
}: {
  f: Field
  idx: number
  total: number
  active: boolean
  onSelect: () => void
  onMove: (dir: -1 | 1) => void
  onDelete: () => void
}) {
  const palette = PALETTE.find(p => p.type === f.type)!

  return (
    <div
      role="button"
      tabIndex={0}
      aria-pressed={active}
      onClick={onSelect}
      onKeyDown={e => e.key === 'Enter' && onSelect()}
      className={[
        'relative rounded-[var(--radius-card)] border p-3 pl-5 cursor-pointer',
        'transition-shadow motion-safe:transition-all',
        active
          ? 'border-[var(--color-primary)] shadow-[var(--shadow-md)]'
          : 'border-[var(--color-border)] shadow-[var(--shadow-sm)] hover:border-[var(--color-border-strong)]',
        'bg-[var(--color-surface-2)]',
      ].join(' ')}
    >
      {/* Left accent bar — visible on active/hover */}
      <span
        className={[
          'absolute left-0 top-2 bottom-2 w-0.5 rounded-r-sm',
          'bg-[var(--color-primary)] transition-opacity',
          active ? 'opacity-100' : 'opacity-0 group-hover:opacity-40',
        ].join(' ')}
        aria-hidden
      />

      {/* Drag grip */}
      <span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[var(--color-text-disabled)]" aria-hidden>
        <GripVertical size={12} />
      </span>

      {/* Header row */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          {/* Deliberate keep: mono uppercase tag styling on the Badge primitive itself, not a bespoke eyebrow label — not a SectionLabel candidate. */}
          <Badge tone={palette.tone} className="text-xs px-1.5 py-0.5 font-mono tracking-wider uppercase">
            {f.type}
          </Badge>
          {f.required && (
            <Badge tone="danger" className="text-xs px-1.5 py-0.5 font-mono tracking-wider uppercase">
              required
            </Badge>
          )}
        </div>

        {active && (
          <div className="flex gap-0.5">
            <Button
              variant="ghost"
              size="sm"
              disabled={idx === 0}
              onClick={e => { e.stopPropagation(); onMove(-1) }}
              aria-label="Move field up"
              className="h-6 w-6 p-0"
            >
              <ChevronUp size={11} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              disabled={idx === total - 1}
              onClick={e => { e.stopPropagation(); onMove(1) }}
              aria-label="Move field down"
              className="h-6 w-6 p-0"
            >
              <ChevronDown size={11} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={e => { e.stopPropagation(); onDelete() }}
              aria-label="Remove field"
              className="h-6 w-6 p-0 text-[var(--color-danger)] hover:bg-[var(--color-danger-surface)]"
            >
              <Trash2 size={11} />
            </Button>
          </div>
        )}
      </div>

      {/* Label */}
      <p className="text-xs font-semibold text-[var(--color-text)] mb-1.5">
        {f.label}
        {f.required && <span className="text-[var(--color-danger)] ml-0.5">*</span>}
      </p>

      <FieldPreview f={f} />
    </div>
  )
}

// ─── Palette button ───────────────────────────────────────────────────────────

function PaletteButton({ item, onAdd }: { item: PaletteItem; onAdd: (type: FieldType) => void }) {
  const { Icon } = item
  return (
    <Button
      type="button"
      variant="ghost"
      onClick={() => onAdd(item.type)}
      title={item.hint}
      className={[
        'h-auto w-auto flex-col gap-1.5 px-1.5 py-2.5 rounded-[var(--radius-card)]',
        'border border-transparent',
        'hover:border-[var(--color-border)] hover:bg-[var(--color-background)]',
        'hover:shadow-[var(--shadow-sm)]',
        'text-center font-[inherit]',
      ].join(' ')}
    >
      <span className="w-8 h-8 rounded-lg flex items-center justify-center bg-[var(--color-surface-raised)] text-[var(--color-text-muted)] transition-colors">
        <Icon size={14} strokeWidth={1.8} />
      </span>
      <span className="text-xs font-semibold text-[var(--color-text-muted)] leading-tight whitespace-nowrap">
        {item.label}
      </span>
    </Button>
  )
}

// ─── Properties panel ─────────────────────────────────────────────────────────

function PropertiesPanel({
  field,
  palette,
  onUpdate,
  onDelete,
}: {
  field: Field
  palette: PaletteItem
  onUpdate: (changes: Partial<Field>) => void
  onDelete: () => void
}) {
  const showPlaceholder = !['divider', 'heading', 'checkbox', 'select', 'file'].includes(field.type)
  const { Icon } = palette

  return (
    <div className="flex flex-col h-full">
      {/* Type indicator */}
      <div className="flex items-center gap-2 pb-3 mb-3 border-b border-[var(--color-border)]">
        <span className="w-7 h-7 rounded-md flex items-center justify-center bg-[var(--color-surface-raised)] text-[var(--color-text-muted)] shrink-0">
          <Icon size={14} strokeWidth={1.8} />
        </span>
        <div>
          <p className="text-xs font-bold text-[var(--color-text)] leading-tight">{palette.label}</p>
          <p className="text-xs text-[var(--color-text-muted)] mt-px">{palette.hint}</p>
        </div>
      </div>

      {/* Properties */}
      <div className="flex flex-col gap-3 flex-1 overflow-y-auto">
        <div className="flex flex-col gap-1">
          <FieldLabel htmlFor="prop-label" className="text-xs tracking-wider text-[var(--color-text-muted)]">
            Label
          </FieldLabel>
          <Input
            id="prop-label"
            value={field.label}
            onChange={e => onUpdate({ label: e.target.value })}
            className="h-8 text-xs"
          />
        </div>

        {showPlaceholder && (
          <div className="flex flex-col gap-1">
            <FieldLabel htmlFor="prop-placeholder" className="text-xs tracking-wider text-[var(--color-text-muted)]">
              Placeholder
            </FieldLabel>
            <Input
              id="prop-placeholder"
              value={field.placeholder ?? ''}
              onChange={e => onUpdate({ placeholder: e.target.value })}
              className="h-8 text-xs"
              placeholder="Optional hint text..."
            />
          </div>
        )}

        <div className="flex items-center justify-between py-2 border-y border-[var(--color-border)]">
          <div>
            <p className="text-xs font-semibold text-[var(--color-text)]">Required</p>
            <p className="text-xs text-[var(--color-text-muted)]">Field must be filled</p>
          </div>
          <Switch
            checked={field.required}
            onCheckedChange={val => onUpdate({ required: val })}
            aria-label="Toggle required"
          />
        </div>
      </div>

      {/* Remove */}
      <div className="pt-3 mt-auto shrink-0">
        <Button
          variant="ghost"
          size="sm"
          onClick={onDelete}
          className="w-full text-[var(--color-danger)] hover:bg-[var(--color-danger-surface)] border border-[var(--color-danger-border)]"
        >
          <Trash2 size={11} />
          Remove field
        </Button>
      </div>
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

/**
 * FormBuilderView — body-only 3-panel builder feature.
 *
 * Panel structure (owned by this feature per ADR-0035's structural ReactNode seam rule):
 *   Palette (left) | Canvas (centre) | Properties (right, when a field is selected)
 *
 * The canvas root is `<form id="form-builder">` so the enclosing BuilderLayout's
 * header-owned Publish/Save button (which carries `form="form-builder"`) submits it
 * without any JS coupling.
 */
export function FormBuilderView() {
  const [fields, setFields] = useState<Field[]>(SEED)
  const [selectedId, setSelectedId] = useState<string | null>('f1')

  const sel = fields.find(f => f.id === selectedId) ?? null
  const selPalette = sel ? PALETTE.find(p => p.type === sel.type) ?? null : null

  const addField = useCallback((type: FieldType) => {
    const def = PALETTE.find(p => p.type === type)!
    const f: Field = { id: `f${Date.now()}`, type, label: def.label, required: false }
    setFields(prev => [...prev, f])
    setSelectedId(f.id)
  }, [])

  const updateField = useCallback((changes: Partial<Field>) => {
    setFields(prev => prev.map(f => f.id === selectedId ? { ...f, ...changes } : f))
  }, [selectedId])

  const deleteField = useCallback((id: string) => {
    setFields(prev => prev.filter(f => f.id !== id))
    if (selectedId === id) setSelectedId(null)
  }, [selectedId])

  const moveField = useCallback((id: string, dir: -1 | 1) => {
    setFields(prev => {
      const arr = [...prev]
      const i = arr.findIndex(f => f.id === id)
      const j = i + dir
      if (j < 0 || j >= arr.length) return prev
      const tmp = arr[i] as Field
      arr[i] = arr[j] as Field
      arr[j] = tmp
      return arr
    })
  }, [])

  return (
    <div className="flex h-full gap-3 min-h-0">

      {/* ── Left: Field palette ──────────────────────────────────────────────── */}
      <aside
        aria-label="Field types"
        className="w-44 shrink-0 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface-2)] overflow-hidden flex flex-col"
      >
        <p className="dq-overline px-3 pt-3 pb-2 shrink-0">Field Types</p>
        <ScrollArea className="flex-1">
          <div className="grid grid-cols-2 gap-0.5 p-1.5">
            {PALETTE.map(p => (
              <PaletteButton key={p.type} item={p} onAdd={addField} />
            ))}
          </div>
        </ScrollArea>
      </aside>

      {/* ── Centre: Form canvas ──────────────────────────────────────────────── */}
      {/* The <form> wraps the canvas so the layout's Publish button can submit it */}
      <form
        id="form-builder"
        onSubmit={e => e.preventDefault()}
        className="flex-1 min-w-0 flex flex-col rounded-[var(--radius-card)] border border-[var(--color-border)] overflow-hidden"
        aria-label="Form canvas"
      >
        {/* Canvas toolbar */}
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-[var(--color-border)] bg-[var(--color-surface-2)] shrink-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold text-[var(--color-text)]">Employee Request Form</p>
            <span className="dq-badge dq-badge-sm dq-badge-warning">DRAFT</span>
          </div>
          <Button variant="ghost" size="sm" type="button">
            <Eye size={13} strokeWidth={1.8} />
            Preview
          </Button>
        </div>

        {/* Canvas body — dot grid background */}
        <ScrollArea className="flex-1">
          <div
            className="min-h-full p-4 flex flex-col gap-2"
            style={{
              backgroundImage: 'radial-gradient(circle, var(--color-border-subtle) 1px, transparent 1px)',
              backgroundSize: '20px 20px',
            }}
          >
            {fields.length === 0 && (
              <div className="flex-1 flex flex-col items-center justify-center gap-2 min-h-48 text-[var(--color-text-muted)]">
                <span className="text-2xl opacity-30 leading-none">+</span>
                <span className="text-xs">Click a field type to start building</span>
              </div>
            )}

            {fields.map((f, idx) => (
              <FieldCard
                key={f.id}
                f={f}
                idx={idx}
                total={fields.length}
                active={f.id === selectedId}
                onSelect={() => setSelectedId(f.id)}
                onMove={dir => moveField(f.id, dir)}
                onDelete={() => deleteField(f.id)}
              />
            ))}

            <Button
              type="button"
              variant="ghost"
              onClick={() => addField('text')}
              className={[
                'h-9 w-full rounded-[var(--radius-card)] border-2 border-dashed border-[var(--color-border)]',
                'text-xs text-[var(--color-text-muted)] font-normal',
                'hover:border-[var(--color-primary)] hover:text-[var(--color-text)] hover:bg-transparent',
                'font-[inherit]',
              ].join(' ')}
            >
              <span className="text-sm leading-none font-light">+</span>
              Add field
            </Button>
          </div>
        </ScrollArea>
      </form>

      {/* ── Right: Properties panel ──────────────────────────────────────────── */}
      <aside
        aria-label="Field properties"
        className="w-52 shrink-0 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface-2)] overflow-hidden"
      >
        {sel && selPalette ? (
          <div className="h-full p-3.5">
            <PropertiesPanel
              field={sel}
              palette={selPalette}
              onUpdate={updateField}
              onDelete={() => deleteField(sel.id)}
            />
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center gap-2 text-[var(--color-text-muted)] p-4">
            <span className="text-2xl opacity-20 leading-none">⊡</span>
            <p className="text-xs text-center leading-relaxed">
              Select a field on the canvas to edit its properties
            </p>
          </div>
        )}
      </aside>

    </div>
  )
}
