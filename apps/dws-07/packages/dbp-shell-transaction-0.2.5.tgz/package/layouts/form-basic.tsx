import * as React from 'react'
import { FormSection, Grid, Col, type ColSpan } from '@dbp/ui'

export interface FormBasicField {
  /** Unique key for this field (used as the React key). */
  id: string
  /** Column span at md+ (1–12, matches the 12-col Grid). Default 6 (two-up). */
  span?: ColSpan
  /** Field content — typically a <FormField><Input/Select/Textarea/.../></FormField>. */
  content: React.ReactNode
}

export interface FormBasicSection {
  /** Unique key for this section. */
  id: string
  /** Section heading (rendered as a real heading — see `headingLevel` on the layout). */
  title: string
  /** Optional one-line description shown under the heading. */
  description?: string
  /** Optional icon rendered in a small circular badge to the left of the heading. */
  icon?: React.ReactNode
  /** Fields laid out on the 12-col Grid within this section. */
  fields: FormBasicField[]
}

export interface FormBasicLayoutProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is
   * now the page title. See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  /** Sections rendered top to bottom, each a FormSection with a 2-col field grid. */
  sections: FormBasicSection[]
}

/**
 * FormBasicLayout — a sectioned create/update form: sticky PageHeader (title +
 * Save draft/Submit actions in its `aside`) followed by a stack of FormSections,
 * each rendering its fields on the canonical 12-col Grid (2-up at md+, 1-up
 * below). No hardcoded copy — every heading/field/action comes from props.
 *
 * Deliberately has NO sticky/fixed bottom action bar — actions live in the
 * PageHeader only.
 */
export function FormBasicLayout({ header, sections }: FormBasicLayoutProps) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}
      <div className="flex flex-col gap-8 w-full max-w-4xl pt-4 pb-8">
        {sections.map((section) => (
          <FormSection
            key={section.id}
            title={section.title}
            {...(section.description !== undefined ? { description: section.description } : {})}
            icon={section.icon}
            headingLevel="h2"
          >
            <Grid>
              {section.fields.map((field) => (
                <Col key={field.id} span={field.span ?? 6}>
                  {field.content}
                </Col>
              ))}
            </Grid>
          </FormSection>
        ))}
      </div>
    </div>
  )
}
