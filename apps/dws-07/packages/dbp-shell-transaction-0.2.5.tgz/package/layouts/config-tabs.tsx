"use client"
import * as React from 'react'
import { Tabs, TabsList, TabsTrigger, TabsContent, Button } from '@dbp/ui'

export interface ConfigTab {
  id: string
  label: string
  content: React.ReactNode
  /**
   * id of the `<form>` rendered inside this tab. When set, the layout shows a primary Save
   * at the right end of the tab-strip row that submits this form via the HTML `form` attribute
   * (no JS coupling). The form is body-only and renders no submit button of its own.
   */
  formId?: string
  /** Label for the tab-row Save (default "Save changes"). */
  saveLabel?: string
}

interface ConfigTabsLayoutProps {
  /**
   * PageHeader ReactNode supplied by the page (header-slot pattern). Optional — renders sticky when present.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>` (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is now the page title.
   */
  header?: React.ReactNode
  tabs: ConfigTab[]
  defaultTab?: string
}

/**
 * ConfigTabsLayout — a header-slot layout for settings pages with multiple sections.
 *
 * The page passes a `<PageHeader>` via the `header` slot (same pattern as CanvasLayout /
 * SettingsLayout). The layout renders it sticky at the top, then an underline tab row,
 * then a body-only content area.
 *
 * Primary action ownership (ADR-0035): the LAYOUT owns the primary Save, placed at the
 * RIGHT END of the tab-strip row. It submits the ACTIVE tab's `<form id>` via the HTML
 * `form` attribute — the form carries no submit button of its own.
 *
 * Replaces the old AdminNav rail pattern; cross-page navigation is the shell sidebar's responsibility.
 */
export function ConfigTabsLayout({ header, tabs, defaultTab }: ConfigTabsLayoutProps) {
  const initialTab = defaultTab ?? tabs[0]?.id ?? ''
  const [active, setActive] = React.useState(initialTab)
  const activeTab = tabs.find((t) => t.id === active) ?? tabs[0]

  // Layout-owned primary action: submits the active tab's form via the HTML `form` attribute.
  const save = activeTab?.formId ? (
    <Button type="submit" form={activeTab.formId}>
      {activeTab.saveLabel ?? 'Save changes'}
    </Button>
  ) : null

  // Whether to show a tab-strip row: always if there are 2+ tabs; only for the save button if 1 tab + save.
  const showTabRow = tabs.length > 1 || save !== null

  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      {/* Page-supplied header — sticky when present */}
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}

      {/* Tabs — using @dbp/ui primitives; no raw <button> or inline hex. */}
      <Tabs value={active} onValueChange={setActive} className="flex flex-col flex-1 min-h-0 w-full">
        {showTabRow && (
          /* Tab-strip row — tabs on the left, layout-owned Save pushed right */
          <div className="shrink-0 flex items-center border-b border-[var(--color-border)]">
            {tabs.length > 1 ? (
              <TabsList className="rounded-none border-b-0 bg-transparent px-0 h-auto flex-1">
                {tabs.map((tab) => (
                  <TabsTrigger
                    key={tab.id}
                    value={tab.id}
                    className="rounded-none"
                  >
                    {tab.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            ) : (
              /* Single tab: no visible tab chrome — spacer to push save right */
              <div className="flex-1" />
            )}
            {save && <div className="px-4 py-2 shrink-0">{save}</div>}
          </div>
        )}

        {/* Content area — body-only, no card-in-card wrapper */}
        <div className="flex-1 overflow-y-auto pt-6 pb-8">
          <div className="max-w-[var(--settings-form-max-w,720px)]">
            {tabs.map((tab) => (
              <TabsContent key={tab.id} value={tab.id}>
                {tab.content}
              </TabsContent>
            ))}
          </div>
        </div>
      </Tabs>
    </div>
  )
}
