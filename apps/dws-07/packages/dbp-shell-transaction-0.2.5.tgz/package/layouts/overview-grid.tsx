import * as React from 'react'

interface OverviewGridLayoutProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is
   * now the page title. See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  children: React.ReactNode
}

/**
 * OverviewGridLayout — sticky PageHeader followed by a full-width content area
 * for a personal "My Dashboard" widget grid (e.g. APP.F21 WorkspaceDashboard).
 * The widget grid itself owns its column layout; this shell only provides the
 * sticky header region and page-level vertical rhythm.
 */
export function OverviewGridLayout({ header, children }: OverviewGridLayoutProps) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}
      <div className="flex-1 w-full pt-4 pb-8">
        {children}
      </div>
    </div>
  )
}
