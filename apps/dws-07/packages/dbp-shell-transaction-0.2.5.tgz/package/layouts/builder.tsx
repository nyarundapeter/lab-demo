"use client"
import * as React from 'react'
import { Button } from '@dbp/ui'

interface BuilderLayoutProps {
  /**
   * PageHeader ReactNode supplied by the page (header-slot pattern). Optional — renders sticky when present.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>` (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is now the page title.
   */
  header?: React.ReactNode
  /**
   * id of the `<form>` rendered by the builder feature. When provided, the layout shows a
   * primary Publish/Save button in the toolbar row that submits it via the HTML `form`
   * attribute (no JS coupling). The feature must NOT render its own submit button.
   */
  saveFormId?: string
  /** Label for the toolbar primary action (default "Publish"). */
  saveLabel?: string
  /**
   * The builder feature. Must be body-only — it renders the 3-panel UI (palette | canvas |
   * properties). Structural ReactNode seam rule (ADR-0035): the layout exposes ONLY `children`
   * as a ReactNode; panel composition is the feature's responsibility.
   */
  children: React.ReactNode
}

/**
 * BuilderLayout — full-height header-slot layout for builder surfaces (Form Builder,
 * Workflow Builder, Rule Builder, etc.).
 *
 * The page passes a `<PageHeader>` via the `header` slot (same pattern as CanvasLayout /
 * SettingsLayout). The layout renders it sticky at the top, then a thin toolbar row holding
 * the layout-owned primary action (Publish/Save) pushed to the right, then the full-height
 * children (the 3-panel builder body).
 *
 * ADR-0035 compliance:
 * - No ReactNode structural props; only `children`.
 * - No raw HTML chrome (`<nav>/<a>/<button>/<input>`), no hex, no `color-mix`, no `[...]`.
 * - Layout is the single source of the toolbar save control; features must be body-only.
 */
export function BuilderLayout({
  header,
  saveFormId,
  saveLabel,
  children,
}: BuilderLayoutProps) {
  const save = saveFormId ? (
    <Button type="submit" form={saveFormId}>
      {saveLabel ?? 'Publish'}
    </Button>
  ) : null

  return (
    <div className="flex flex-col h-full w-full overflow-hidden">
      {/* Page-supplied header — sticky when present */}
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}

      {/* Layout-owned toolbar row — save control pushed to the right */}
      {save && (
        <div className="shrink-0 flex items-center justify-end border-b border-[var(--color-border)] px-4 py-2 bg-[var(--color-surface)]">
          {save}
        </div>
      )}

      {/* Full-bleed body — builder feature owns the 3-panel layout inside.
          No horizontal padding: the shell already provides --shell-gutter on <main>.
          Top padding (pt-4) aligns the panel top edge with CanvasLayout's content start. */}
      <div className="flex-1 min-h-0 overflow-hidden pt-4">
        {children}
      </div>
    </div>
  )
}
