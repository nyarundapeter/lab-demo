import * as React from 'react'
import { CanvasLayout } from './canvas.js'

interface ConversationalLayoutProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar's breadcrumb terminal crumb is
   * now the page title. See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  /** The scrollable message thread area */
  thread: React.ReactNode
  /** The composer / input bar — pinned to the bottom of the chat surface */
  input: React.ReactNode
}

export function ConversationalLayout({ header, thread, input }: ConversationalLayoutProps) {
  const chatPanel = (
    <div className="flex flex-col overflow-hidden rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)]"
         style={{ height: 'calc(100vh - var(--shell-header-h) - 160px)' }}>
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {thread}
      </div>
      <div className="shrink-0 border-t border-[var(--color-border)] px-6 py-4">
        {input}
      </div>
    </div>
  )

  return (
    <CanvasLayout
      header={header}
      slots={[{ id: 'chat', span: 12, content: chatPanel }]}
    />
  )
}
