import * as React from 'react'

interface CatalogueLayoutProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is
   * now the page title. See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  filters?: React.ReactNode
  children: React.ReactNode
}

export function CatalogueLayout({ header, filters, children }: CatalogueLayoutProps) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}
      <div className="flex flex-1 w-full pt-4 pb-8 gap-6">
        {filters && (
          <aside className="hidden md:block w-[var(--catalogue-filter-w)] shrink-0">{filters}</aside>
        )}
        <main className="flex-1 min-w-0">{children}</main>
      </div>
    </div>
  )
}
