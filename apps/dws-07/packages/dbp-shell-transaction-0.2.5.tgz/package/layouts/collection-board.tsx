import * as React from 'react'

export interface CollectionBoardColumn {
  /** Unique column key (typically the status value it represents). */
  id: string
  title: string
  count?: number
  /**
   * Card content for this column. Each child is expected to be a `role="listitem"`
   * element — the layout renders the column wrapper as `role="list"` but cannot
   * force list semantics onto opaque children. Use `BoardCard` from `@dbp/ui`
   * (which sets `role="listitem"` itself) so the list/listitem structure is
   * correct end-to-end.
   */
  children: React.ReactNode
}

interface CollectionBoardLayoutColumnsProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is
   * now the page title. See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  /** Optional filter bar rendered between the header and the board columns. */
  filters?: React.ReactNode
  columns: CollectionBoardColumn[]
}

interface CollectionBoardLayoutChildrenProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is
   * now the page title. See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  /** Optional filter bar rendered between the header and the board area. */
  filters?: React.ReactNode
  /**
   * Structural ReactNode seam (ADR-0035, same pattern as BuilderLayout):
   * for self-contained board features (e.g. APP.F04 Kanban) that render their own
   * columns, cards, and title internally. Mutually exclusive with `columns`.
   */
  children: React.ReactNode
}

type CollectionBoardLayoutProps = CollectionBoardLayoutColumnsProps | CollectionBoardLayoutChildrenProps

/**
 * CollectionBoardLayout — a sticky-header, horizontally-scrolling kanban board.
 *
 * Two mutually exclusive modes:
 * - `columns` — structured per-column data; the layout renders column headers
 *   (title + count) and card stacks itself.
 * - `children` — a fully self-contained board feature (e.g. APP.F04 Kanban)
 *   that renders its own columns/cards internally; the layout renders only the
 *   outer sticky-header + filters + scroll-container chrome.
 *
 * This is a static board — no drag-and-drop yet. When DnD is added, it MUST
 * ship with a keyboard-operable alternative (e.g. a "Move to..." action per
 * card) — do not add DnD without one.
 */
export function CollectionBoardLayout(props: CollectionBoardLayoutProps) {
  const { header, filters } = props

  return (
    <div className="flex flex-col min-h-full w-full">
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}
      {filters && <div className="shrink-0 pt-4">{filters}</div>}
      <div className="flex-1 min-h-0 w-full pt-4 pb-8 overflow-x-auto">
        {'columns' in props ? (
          <div className="flex gap-4 h-full min-w-max">
            {props.columns.map((column) => (
              <div
                key={column.id}
                role="list"
                aria-label={`${column.title}${column.count !== undefined ? ` (${column.count})` : ""}`}
                className="flex flex-col w-[280px] shrink-0 rounded-lg bg-[color-mix(in_srgb,var(--color-border)_25%,transparent)]"
              >
                <div className="shrink-0 flex items-center gap-2 px-3 py-2.5">
                  <h3 className="text-sm font-semibold text-[var(--color-text)]">{column.title}</h3>
                  {column.count !== undefined && (
                    <span className="text-xs font-medium text-[var(--color-text-muted)]">{column.count}</span>
                  )}
                </div>
                <div className="flex-1 min-h-0 overflow-y-auto px-3 pb-3 flex flex-col gap-2">
                  {column.children}
                </div>
              </div>
            ))}
          </div>
        ) : (
          props.children
        )}
      </div>
    </div>
  )
}
