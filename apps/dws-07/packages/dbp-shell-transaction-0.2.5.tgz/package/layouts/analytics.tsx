import * as React from 'react'

interface AnalyticsLayoutProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is
   * now the page title. Move the filter bar into a content toolbar instead.
   * See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  children: React.ReactNode
}

export function AnalyticsLayout({ header, children }: AnalyticsLayoutProps) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}
      <div className="flex-1 w-full pt-4 pb-8">
        {children}
      </div>
    </div>
  )
}
