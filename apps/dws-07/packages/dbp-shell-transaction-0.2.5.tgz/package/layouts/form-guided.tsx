import * as React from 'react'
import { StepIndicator } from '@dbp/organisms/lve-workspace'
import { Button } from '@dbp/ui'

// StepIndicator styles itself with the LVE design-scope variables; outside the
// LveDsScope wrapper we map them back to DBP tokens here (mirrors
// features/workflow-binding/lib/step-vars.ts for the same component).
const STEP_VARS: React.CSSProperties = {
  ['--charcoal-950' as string]: 'var(--color-primary)',
  ['--rose-500' as string]: 'var(--color-secondary, var(--color-primary))',
  ['--gray-100' as string]: 'var(--color-surface)',
  ['--gray-200' as string]: 'var(--color-border-subtle)',
  ['--gray-400' as string]: 'var(--color-text-muted)',
  ['--gray-500' as string]: 'var(--color-text-muted)',
}

export interface FormGuidedStep {
  /** Unique step id (also used as the React key). */
  id: string
  /** Step label shown in the step indicator. */
  label: string
  /** Optional short description shown under the label in the step indicator. */
  description?: string
  /** Heading rendered above this step's body content. */
  title: string
}

export interface FormGuidedInfoRail {
  /** e.g. "Step 1 of 4" — the layout does not compute this so it stays data-driven. */
  progressLabel: string
  /** Short copy describing what this step is for, shown under the progress label. */
  progressDescription?: string
  /** Auto-save note text (e.g. "Your draft will be saved automatically."). */
  autoSaveNote?: string
  /** Help link shown at the bottom of the info rail. */
  helpLink?: { label: string; href: string }
}

export interface FormGuidedLayoutProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is
   * now the page title. Move step actions (Save draft, Cancel) into a
   * content toolbar instead. See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  /** Ordered step definitions driving the step indicator. */
  steps: FormGuidedStep[]
  /** Zero-based index of the active step. */
  currentStep: number
  /** Body content for the active step (the page supplies the form fields). */
  children: React.ReactNode
  /** Info rail content shown alongside the active step's form body. */
  infoRail?: FormGuidedInfoRail
  /**
   * Called with the zero-based index when a step indicator circle is clicked.
   * Only wire this if jumping to a NOT-YET-VISITED step should be allowed — the
   * layout itself does not decide this; see the comment on `onStepClick` below.
   */
  onStepClick?: (index: number) => void
  /** Back button handler. Omit or set undefined on the first step — layout hides it then. */
  onBack?: () => void
  /** Continue/submit button handler — always rendered. */
  onContinue: () => void
  /** Label for the continue button (default "Continue"). Last step should pass "Submit". */
  continueLabel?: string
  /** Disables the continue button (e.g. while the current step is invalid). */
  continueDisabled?: boolean
}

/**
 * FormGuidedLayout — multi-step guided form (form/form-guided).
 *
 * Chrome owned here: sticky header slot, StepIndicator (reused from
 * @dbp/organisms/lve-workspace, already used by the workflow-binding feature's
 * RecordWorkflowStepper — not reimplemented), a two-column step body + info
 * rail, and a Back/Continue navigation bar.
 *
 * Save-draft placement (Sharavi correction, 2026-07): the reference mockup
 * showed "Save draft" both in the top PageHeader AND in the bottom nav bar.
 * That is deliberately NOT replicated — Save draft lives in exactly one place,
 * the page's PageHeader `aside`. The bottom nav bar here renders ONLY Back and
 * Continue.
 *
 * Step-change announcement: the step body is wrapped in an `aria-live="polite"`
 * region with `aria-atomic` cleared, and the step heading receives programmatic
 * focus on step change (via a ref + `useEffect`) — belt-and-braces so screen
 * reader users get an announcement AND a predictable focus landing point,
 * matching how most production wizards behave (VoiceOver in particular does not
 * reliably announce aria-live in all reading modes).
 *
 * Step-indicator click-ahead: `onStepClick` is only forwarded to StepIndicator
 * for steps at or before `currentStep` (i.e. completed/active steps). Jumping
 * ahead to an unvisited step is refused — a guided form's later steps may depend
 * on earlier answers (e.g. "Scope" fields synthesized from "Request Details"),
 * so allowing a forward jump could show an step with invalid/undefined state.
 * The page can still choose not to pass `onStepClick` at all for a fully linear
 * flow with no direct navigation.
 */
export function FormGuidedLayout({
  header,
  steps,
  currentStep,
  children,
  infoRail,
  onStepClick,
  onBack,
  onContinue,
  continueLabel = 'Continue',
  continueDisabled = false,
}: FormGuidedLayoutProps) {
  const activeStep = steps[currentStep]
  const headingRef = React.useRef<HTMLHeadingElement>(null)

  React.useEffect(() => {
    headingRef.current?.focus()
  }, [currentStep])

  const handleStepClick = onStepClick
    ? (index: number) => {
        if (index <= currentStep) onStepClick(index)
      }
    : undefined

  return (
    <div className="flex flex-col min-h-full w-full">
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">{header}</div>
      )}

      <div
        className="shrink-0 pt-4 pb-6 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface-content)] px-4 sm:px-5 mt-4"
        style={STEP_VARS}
      >
        <StepIndicator steps={steps} currentStep={currentStep} {...(handleStepClick ? { onStepClick: handleStepClick } : {})} />
      </div>

      <div className="flex-1 min-h-0 w-full grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_280px] gap-6 pt-6 pb-8">
        <div
          aria-live="polite"
          aria-atomic="false"
          className="min-w-0 flex flex-col gap-6"
        >
          {activeStep && (
            <h2
              ref={headingRef}
              tabIndex={-1}
              className="text-lg font-semibold text-[var(--color-text)] outline-none"
            >
              {activeStep.title}
            </h2>
          )}
          {children}
        </div>

        {infoRail && (
          <aside className="flex flex-col gap-4 lg:border-l lg:border-[var(--color-border)] lg:pl-6">
            <div>
              <p className="text-sm font-semibold text-primary">{infoRail.progressLabel}</p>
              {infoRail.progressDescription && (
                <p className="mt-1 text-sm text-[var(--color-text-muted)]">
                  {infoRail.progressDescription}
                </p>
              )}
            </div>
            {infoRail.autoSaveNote && (
              <p className="text-xs text-[var(--color-text-muted)] border-t border-[var(--color-border)] pt-4">
                {infoRail.autoSaveNote}
              </p>
            )}
            {infoRail.helpLink && (
              <a
                href={infoRail.helpLink.href}
                className="text-xs font-medium text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)] rounded-sm"
              >
                {infoRail.helpLink.label}
              </a>
            )}
          </aside>
        )}
      </div>

      <div className="shrink-0 flex items-center justify-between gap-2 border-t border-[var(--color-border)] pt-4 pb-2">
        {onBack ? (
          <Button
            type="button"
            variant="ghost"
            onClick={onBack}
            className="min-h-11"
          >
            Back
          </Button>
        ) : (
          <span />
        )}
        <Button
          type="button"
          variant="orange"
          onClick={onContinue}
          disabled={continueDisabled}
          className="min-h-11"
        >
          {continueLabel}
        </Button>
      </div>
    </div>
  )
}
