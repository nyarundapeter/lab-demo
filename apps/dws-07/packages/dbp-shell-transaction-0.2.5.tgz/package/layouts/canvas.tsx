import * as React from 'react'

// Tailwind requires static class strings — dynamic template literals are purged.
const COL_SPAN: Record<number, string> = {
  1: 'col-span-1',
  2: 'col-span-2',
  3: 'col-span-3',
  4: 'col-span-4',
  6: 'col-span-6',
  12: 'col-span-12',
}

export interface CanvasSlot {
  /** Unique key for this slot */
  id: string
  /** Column span on the 12-col grid. Default: 4 (3 per row — the canonical 6-slot arrangement) */
  span?: 1 | 2 | 3 | 4 | 6 | 12
  content: React.ReactNode
}

interface CanvasLayoutProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar's breadcrumb terminal crumb is
   * now the page title, so a separate title row duplicates it. Move any
   * action buttons into a content toolbar at the top of the page body
   * instead. This slot remains for non-standard cases only.
   */
  header?: React.ReactNode
  slots?: CanvasSlot[]
  children?: React.ReactNode
  /** Fills the containing block height exactly and strips pt/pb so full-bleed content (e.g. LveWorkspace) can escape the shell gutters. */
  fullBleed?: boolean
}

export function CanvasLayout({ header, slots, children, fullBleed }: CanvasLayoutProps) {
  return (
    <div className={`flex flex-col w-full ${fullBleed ? 'h-full' : 'min-h-full'}`}>
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}
      <div className={`flex-1 min-h-0 w-full flex flex-col${fullBleed ? '' : ' pt-4 pb-8'}`}>
        {slots ? (
          <div className="grid grid-cols-12 gap-6">
            {slots.map(slot => (
              <div key={slot.id} className={COL_SPAN[slot.span ?? 4] ?? 'col-span-4'}>
                {slot.content}
              </div>
            ))}
          </div>
        ) : (
          children
        )}
      </div>
    </div>
  )
}
