import * as React from 'react'

export function ContentLandingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      <div className="w-full pt-4 pb-8 space-y-8">
        {children}
      </div>
    </div>
  )
}
