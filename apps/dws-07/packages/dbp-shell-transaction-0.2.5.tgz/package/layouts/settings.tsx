import * as React from 'react'

interface SettingsLayoutProps {
  /**
   * Optional sticky header row.
   * @deprecated For standard authenticated pages, do NOT pass `<PageHeader>`
   * here (Amendment D-2, component-architecture-standard.md §7b): the top bar breadcrumb terminal crumb is
   * now the page title. See CanvasLayout's `header` prop doc.
   */
  header?: React.ReactNode
  nav: React.ReactNode
  children: React.ReactNode
  /**
   * @deprecated Accepted as a no-op so pre-regen pages (e.g. DWS-01) continue to compile.
   * Pass title via `header={<PageHeader title="..." />}` instead.
   */
  pageTitle?: string
  /** @deprecated No-op — use `header` breadcrumb prop instead. */
  breadcrumb?: unknown
  /** @deprecated No-op — layout no longer owns a save button; pass via PageHeader aside. */
  saveFormId?: string
  /** @deprecated No-op. */
  saveLabel?: string
}

export function SettingsLayout({ header, nav, children }: SettingsLayoutProps) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      {header && (
        <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
          {header}
        </div>
      )}
      <div className="flex flex-1 w-full pt-4 pb-8 gap-8">
        <aside className="hidden md:block w-[var(--settings-nav-w)] shrink-0">{nav}</aside>
        <main className="flex-1 min-w-0">{children}</main>
      </div>
    </div>
  )
}
