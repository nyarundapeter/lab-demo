// Backward-compatibility alias. New code should import CanvasLayout from './canvas.js'.
// Generated pages using WorkingLayout continue to work; regenerating them (--force) will
// emit CanvasLayout directly.
export { CanvasLayout as WorkingLayout } from './canvas.js'
