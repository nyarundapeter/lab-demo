import * as React from "react";
import { z } from "zod";

export const NavItemSchema = z.object({
  id: z.string(),
  label: z.string(),
  /** Icon node rendered in collapsed and expanded states. */
  icon: z.custom<React.ReactNode>(),
  /** Route or href for the item. */
  href: z.string().optional(),
  /** Whether this item is currently active. */
  active: z.boolean().optional(),
  /**
   * Optional section/group heading rendered above this item as an overline.
   * When set, a mono-uppercase section label is rendered before this nav item.
   */
  section: z.string().optional(),
});
export type NavItem = z.infer<typeof NavItemSchema>;

export interface TransactionNavProps {
  logo?: React.ReactNode;
  /** Primary sidebar navigation items (Zod-typed). */
  items?: NavItem[];
  breadcrumb?: React.ReactNode;
  user?: React.ReactNode;
  /** Extra action nodes rendered in the top-bar trailing area (e.g. NotificationBell). */
  actions?: React.ReactNode;
}

/**
 * Nav pattern for SH.02.
 *
 * Two-part structure:
 *   1. Top bar (h:44 via --shell-header-h) — sidebar toggle + breadcrumb zone + actions zone
 *   2. Left sidebar — logo + primary nav items + optional sidebar slot content
 *
 * This component is a thin structural wrapper exported for documentation and for
 * consumers that need to compose the nav independently of the full shell.
 * The shell (index.tsx) owns layout and passes nav props into this pattern.
 */
export function TransactionNav({
  logo,
  items = [],
  breadcrumb,
  user,
  actions,
}: TransactionNavProps) {
  return (
    <nav aria-label="Transaction workspace navigation" className="flex flex-col">
      {logo && (
        <div className="flex shrink-0 items-center px-[var(--shell-gutter)]" style={{ height: "var(--shell-header-h)" }}>
          {logo}
        </div>
      )}
      {items.length > 0 && (
        <ul role="list" className="flex flex-col gap-1 px-3">
          {items.map((item) => (
            <li key={item.id}>
              {item.section && (
                <div className="sidebar-feature-area first:mt-1">{item.section}</div>
              )}
              <a
                href={item.href ?? "#"}
                aria-current={item.active ? "page" : undefined}
                className={[
                  "relative sidebar-feature-group",
                  item.active && "sidebar-feature-group-active",
                  "motion-safe:transition-colors",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                ]
                  .filter(Boolean)
                  .join(" ")}
              >
                {item.active && (
                  <span
                    aria-hidden
                    className="absolute bottom-1.5 left-0 top-1.5 w-0.5 rounded-r bg-secondary"
                  />
                )}
                {item.icon && (
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center" aria-hidden="true">
                    {item.icon}
                  </span>
                )}
                <span className="min-w-0 flex-1 truncate text-left">{item.label}</span>
              </a>
            </li>
          ))}
        </ul>
      )}
      {(breadcrumb || user || actions) && (
        <div className="flex items-center gap-2">
          {breadcrumb && <div className="flex-1 min-w-0">{breadcrumb}</div>}
          {actions && <div className="flex shrink-0 items-center gap-1">{actions}</div>}
          {user && <div className="shrink-0">{user}</div>}
        </div>
      )}
    </nav>
  );
}
