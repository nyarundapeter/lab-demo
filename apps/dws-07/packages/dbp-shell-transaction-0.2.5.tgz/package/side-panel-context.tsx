"use client";
import * as React from "react";

/**
 * SH.02 side panel — imperative open/close API (RULING N10, 2026-07-17).
 *
 * The context slot IS the persistent, anchored right-panel capability shared by
 * the AI assistant placements (APP.F14 territory) and overlay side-panel use
 * cases. `TransactionShell` provides this context whenever a `context` slot is
 * populated so any descendant (an AI assistant launcher deep in `slots.main`,
 * a record-detail "open inspector" button, etc.) can open/close the panel
 * without prop-drilling `contextOpen`/`onContextOpenChange` back up to the page
 * that renders the shell.
 */
export interface SidePanelApi {
  /** Whether the panel is currently visible (false if the context slot is empty). */
  open: boolean;
  setOpen: (open: boolean) => void;
  toggle: () => void;
}

export const SidePanelContext = React.createContext<SidePanelApi | null>(null);

/** Must be called from a descendant of `TransactionShell`. */
export function useSidePanel(): SidePanelApi {
  const ctx = React.useContext(SidePanelContext);
  if (!ctx) {
    throw new Error("useSidePanel must be used within TransactionShell");
  }
  return ctx;
}
