"use client";
import * as React from "react";
import { usePathname, useRouter } from "next/navigation";
import * as LucideIcons from "lucide-react";
import {
  AppSidebar,
  SidebarIdentity,
  SlotFrame,
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SectionLabel,
  ShortcutProvider,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  buildSidebarConfig,
  deriveActivePath,
  useShortcuts,
  Button,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from "@dbp/ui";
import type { ModuleNav, NavSection } from "@dbp/contracts";
import { type SlotName } from "./slots.js";
import { type NavItem } from "./nav.js";
import { mergeNavConfig } from "./nav-merge.js";
import { deriveNavSequenceShortcuts } from "./nav-shortcuts.js";
import { SessionGuard } from "./session-guard.js";
import { SidePanelContext, type SidePanelApi } from "./side-panel-context.js";
export { useSidePanel } from "./side-panel-context.js";
export type { SidePanelApi } from "./side-panel-context.js";

/** One tab of the side panel's tabbed content (RULING N10). */
export interface SidePanelTab {
  id: string;
  label: string;
  icon?: string;
  content: React.ReactNode;
}

/**
 * Render a named slot's content, or NOTHING when unfilled.
 *
 * Unfilled optional slots must not surface the dashed `slot:<name>` dev
 * placeholder at runtime (UI-audit fix; commit fe92b7c precedent). SlotFrame is
 * reserved for Storybook stories that pass `isEmpty`/placeholders explicitly.
 */
function Slot({ name, children }: { name: SlotName; children?: React.ReactNode }) {
  if (children == null) return null;
  return <SlotFrame slotName={name}>{children}</SlotFrame>;
}

/**
 * Deferral row 26 — registers `g <letter>` sequence shortcuts derived from the
 * shell's top-level nav sections (see nav-shortcuts.ts for the derivation rules:
 * one letter per section, later collisions skipped, reserved single-key letters
 * skipped). Must render INSIDE `<ShortcutProvider>` — useShortcuts reads the
 * provider's context, which isn't available in TransactionShell's own render
 * (it's the component creating that provider).
 */
function NavSequenceShortcuts({ sections }: { sections: NavSection[] }) {
  const router = useRouter();
  const { registrations } = React.useMemo(() => deriveNavSequenceShortcuts(sections), [sections]);

  useShortcuts(
    registrations.map((r) => ({
      keys: r.keys,
      description: `Go to ${r.label}`,
      group: "Navigation",
      handler: () => router.push(r.href),
    })),
    { scope: "global" },
  );

  return null;
}

type LucideGlyph = React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }>;

function resolveNavIcon(name: string): LucideGlyph | null {
  const icon = (LucideIcons as Record<string, unknown>)[name];
  if (typeof icon === "object" && icon !== null && "$$typeof" in icon) return icon as LucideGlyph;
  return null;
}

function NavGlyph({ name }: { name: string }) {
  const Icon = resolveNavIcon(name);
  if (!Icon) return null;
  return <Icon size={17} strokeWidth={1.5} />;
}

type CollapsedNavChild = {
  id: string;
  label: string;
  href?: string;
  icon?: string;
  children?: CollapsedNavChild[];
};

type CollapsedLinkComponent = React.ElementType<{
  href: string;
  className?: string;
  title?: string;
  "aria-current"?: "page";
  children: React.ReactNode;
}>;

function isChildActive(child: CollapsedNavChild, activePath: string): boolean {
  return Boolean(child.href) && (activePath === child.href || activePath.startsWith(child.href + "/"));
}

function anyDescendantActive(children: CollapsedNavChild[], activePath: string): boolean {
  return children.some(
    (c) => isChildActive(c, activePath) || (c.children ? anyDescendantActive(c.children, activePath) : false),
  );
}

/**
 * Renders one flyout row. A child with its OWN children is a nested group —
 * rendered as a `DropdownMenuSub` (Radix's built-in multi-level submenu
 * primitive), recursing arbitrarily deep. A leaf child is a real navigable
 * `<a href>` (D2 ruling) wrapped in `DropdownMenuItem asChild` so Radix's
 * roving-tabindex keyboard nav (Arrow keys, Enter, Escape) applies to it.
 */
function renderFlyoutChild(
  child: CollapsedNavChild,
  activePath: string,
  LinkComp: CollapsedLinkComponent,
): React.ReactNode {
  if (child.children && child.children.length > 0) {
    return (
      <DropdownMenuSub key={child.id}>
        <DropdownMenuSubTrigger>{child.label}</DropdownMenuSubTrigger>
        <DropdownMenuPortal>
          <DropdownMenuSubContent>
            {child.children.map((grandchild) => renderFlyoutChild(grandchild, activePath, LinkComp))}
          </DropdownMenuSubContent>
        </DropdownMenuPortal>
      </DropdownMenuSub>
    );
  }
  const active = isChildActive(child, activePath);
  return (
    <DropdownMenuItem key={child.id} asChild>
      <LinkComp
        href={child.href ?? "#"}
        {...(active ? { "aria-current": "page" as const } : {})}
        className="w-full cursor-pointer"
      >
        {child.label}
      </LinkComp>
    </DropdownMenuItem>
  );
}

/**
 * D1 fix (revised per Sharavi correction) — a collapsed sidebar icon for a
 * GROUP is not itself a navigation target; it is the anchor for a flyout
 * listing the group's children, the standard collapsed-rail pattern. Built
 * on the existing `DropdownMenu` primitive (Radix) rather than a hand-rolled
 * positioned div: portal-based rendering escapes the rail's
 * `overflow-hidden`, keyboard roving/Escape/ARIA menu semantics come for
 * free, and `aria-haspopup`/`aria-expanded` are set by Radix automatically.
 *
 * D6 fix — the open/close state is fully CONTROLLED by the parent (see
 * `openGroupId` on TransactionShell): `open` reflects whether this item is
 * the single active flyout; `onHoverEnter`/`onHoverLeave` request a
 * hover-debounced open/close; `onOpenChange` carries Radix's own
 * authoritative signals (click, Escape, outside-click, item select) and
 * applies them IMMEDIATELY, never debounced — only a hover-leave should ever
 * wait out a grace period. `sideOffset={0}` abuts the flyout directly
 * against the rail so there is no dead-space gap for the pointer to cross
 * while travelling from icon to menu (the D6 flicker's root geometry).
 */
function CollapsedGroupFlyout({
  id,
  label,
  icon,
  children,
  activePath,
  LinkComp,
  open,
  onHoverEnter,
  onHoverLeave,
  onOpenChange,
}: {
  id: string;
  label: string;
  icon?: string;
  children: CollapsedNavChild[];
  activePath: string;
  LinkComp: CollapsedLinkComponent;
  open: boolean;
  onHoverEnter: (id: string) => void;
  onHoverLeave: (id: string) => void;
  onOpenChange: (id: string, open: boolean) => void;
}) {
  const active = anyDescendantActive(children, activePath);

  return (
    // D6 (2nd root cause, found after the sideOffset fix): Radix DropdownMenu
    // is MODAL by default — while open it sets `pointer-events: none` on the
    // rest of the document, INCLUDING the trigger the pointer is resting on.
    // That fires a synthetic pointerleave on the trigger, which our own
    // hover-leave handler reads as "the user left" and closes the menu;
    // pointer-events is restored, the (unmoved) pointer re-enters the
    // trigger, and it reopens — a ~13Hz open/close loop while simply resting
    // on the icon. `modal={false}` is also correct on its own merits: a
    // navigation flyout should not trap focus or make the rest of the page
    // inert like a dialog.
    <DropdownMenu open={open} onOpenChange={(next) => onOpenChange(id, next)} modal={false}>
      <div onMouseEnter={() => onHoverEnter(id)} onMouseLeave={() => onHoverLeave(id)}>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            aria-label={label}
            className={[
              "relative sidebar-feature-group whitespace-nowrap w-full",
              active && "sidebar-feature-group-active",
              "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
            ]
              .filter(Boolean)
              .join(" ")}
          >
            {active && (
              <span
                aria-hidden
                className="absolute bottom-1.5 left-0 top-1.5 w-0.5 rounded-r bg-secondary"
              />
            )}
            {icon && (
              <span className="flex h-5 w-5 shrink-0 items-center justify-center" aria-hidden="true">
                <NavGlyph name={icon} />
              </span>
            )}
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          side="right"
          align="start"
          sideOffset={0}
          onMouseEnter={() => onHoverEnter(id)}
          onMouseLeave={() => onHoverLeave(id)}
          className="min-w-48"
        >
          <DropdownMenuLabel>{label}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {children.map((child) => renderFlyoutChild(child, activePath, LinkComp))}
        </DropdownMenuContent>
      </div>
    </DropdownMenu>
  );
}

/**
 * SH.02 fixed structural dimensions (from SCAFFOLD-SPEC Part A).
 * All shell dimensions are consumed from design tokens (base.css) so they are
 * the single source of truth and cannot drift from the spec. Never hardcode px.
 */
const SIDEBAR_W_EXPANDED = "var(--shell-sidebar-w)"; // 280px
const SIDEBAR_W_COLLAPSED = "var(--shell-sidebar-collapsed-w)"; // 64px
const CONTEXT_PANEL_W = "var(--shell-panel-w)"; // 320px (context panel + mobile drawer)

export interface TransactionShellProps {
  /** Named slot content. Every slot defaults to an empty SlotFrame when omitted. */
  slots?: Partial<Record<SlotName, React.ReactNode>>;
  /** Nav chrome configuration. */
  nav?: {
    /**
     * Solution identity block rendered at the top of the sidebar (shell v3
     * anatomy, N27 ruling) — logo/initials square + two-line code/name text,
     * collapsing to just the square when the sidebar is icon-only. Takes
     * precedence over `logo` when both are provided.
     */
    identity?: { code: string; name?: string; logoSrc?: string; logoAlt?: string };
    /**
     * Wired replacement for the sidebar identity block (N30 ruling — sidebar
     * identity merges with the tenant/workspace switcher). Takes precedence
     * over `identity` and `logo` when provided. The shell stays auth-free —
     * the app composes the wired switcher (e.g. @dbp/ui's bindings
     * TenantSwitcher) and passes it here, same pattern as `topBar`. Pass a
     * function to receive the live `collapsed` state (the shell owns the
     * sidebar collapse toggle) so the block can drop to icon-square-only.
     */
    identitySlot?: React.ReactNode | ((collapsed: boolean) => React.ReactNode);
    logo?: React.ReactNode;
    /** Primary sidebar nav items — Zod-typed via NavItem in nav.tsx. */
    items?: NavItem[];
    /**
     * Grouped sidebar nav — use this instead of `items` for the DWS.01-style
     * three-level hierarchy (section → group → children). When provided,
     * `items` is ignored. Each section may have an optional eyebrow label
     * (e.g. "ORIENTATION"), groups are collapsible, children are indented.
     */
    sections?: NavSection[];
    /**
     * Custom top-level section ids this solution declared (solution-manifest
     * `customNavSections`) — extends the six standard Feature-Area ids that
     * `mergeNavConfig()` accepts in `sections` above. Absent ⇒ only the six
     * standard ids are legal (unchanged behaviour).
     */
    allowedExtraSectionIds?: string[];
    breadcrumb?: React.ReactNode;
    user?: React.ReactNode;
    /**
     * Actions zone rendered in the top-bar trailing area.
     * Phase 4 bindings (NotificationBell / UserMenu) mount here.
     * See SHELL.md for the binding contract.
     */
    actions?: React.ReactNode;
    /**
     * Enriched, full-width top bar (e.g. `<AppChrome>` from @dbp/ui). When
     * provided it OWNS the entire top-bar content to the right of the sidebar
     * toggle — `breadcrumb`, `actions`, and `user` are then ignored. This is the
     * session + capability driven chrome inherited by every app. Omit it to keep
     * the legacy breadcrumb + actions layout (backward compatible).
     */
    topBar?: React.ReactNode;
    /**
     * Application footer (e.g. `<AppFooter>` from @dbp/ui) pinned to the bottom
     * of the main + context column — it sits to the RIGHT of the sidebar, which
     * stays full-height, so the footer never underlaps the nav. Workspace chrome
     * — defined once in solution-nav so every page inherits it. Omit it to render
     * no footer (backward compatible). Height: `--shell-footer-h`.
     */
    footer?: React.ReactNode;
    /**
     * Shell-owned banner region rendered directly below the global top bar,
     * spanning the same column as the top bar (main + context, not the
     * sidebar). Hosts app/page-level `Alert` banners (notification-system
     * NOT-03/NOT-15 — solid `critical` tone banners must be non-dismissible)
     * and the Collaboration announcement banner. Generic by design: any
     * `@dbp/ui` `Alert`/`ConflictBanner` element, or `null`/omitted to render
     * nothing (backward compatible).
     */
    banner?: React.ReactNode;
    /**
     * When true the sidebar starts collapsed (icon-only strip).
     * Default: false — sidebar starts expanded.
     * Use for Type 6 Conversational pages (/copilot) where spec §6 requires
     * the sidebar to collapse automatically.
     */
    defaultCollapsed?: boolean;
  };
  /**
   * Controls the context panel's open state when populated-but-closeable mode is
   * desired. When undefined and the `context` slot has content the panel is shown.
   * Pass false to force-close it even when content is present.
   */
  contextOpen?: boolean;
  /** Called when the panel requests a state change (close button, Sheet overlay). */
  onContextOpenChange?: (open: boolean) => void;
  /**
   * Panel chrome for the context slot (RULING N10 — the anchored right-panel
   * capability shared by the AI assistant placements and overlay side-panel
   * use cases). Omit for the legacy untitled panel (backward compatible).
   */
  sidePanel?: {
    /** Panel header title, e.g. "AI assistant" or "Details". */
    title?: React.ReactNode;
    /**
     * Tabbed content — when provided, the panel body renders a `Tabs` strip
     * instead of `slots.context` directly. Each tab supplies its own content.
     */
    tabs?: SidePanelTab[];
    /** Controlled active tab id. Defaults to the first tab, uncontrolled. */
    activeTab?: string;
    onTabChange?: (id: string) => void;
  };
  /** Solution identifier used to namespace the nav collapse localStorage key. */
  solutionId?: string;
  /**
   * Help affordance in the sidebar footer (ADR-0040). Defaults preserve today's
   * behaviour (`<a href="/help">Help / Support</a>`). `onClick` wins over `href`.
   * Before this prop, solutions rewrote the anchor with DOM polling — never again.
   */
  help?: {
    href?: string;
    onClick?: () => void;
    label?: string;
  };
  /**
   * Link component used for shell-rendered navigation anchors (collapsed nav
   * strip, help link) so framework routers get client-side navigation — pass
   * `next/link`'s Link in Next.js apps (the generator does). Defaults to a
   * plain `<a>`. The Logout link deliberately stays a real `<a>`: /logout is a
   * route handler that must receive a full request to clear the session cookie.
   */
  linkComponent?: React.ComponentType<{
    href: string;
    className?: string;
    title?: string;
    "aria-current"?: "page";
    children: React.ReactNode;
  }>;
}

/**
 * SH.02 — Transaction Workspace Shell
 *
 * Fixed three-column layout: collapsible sidebar | main content | optional context panel.
 * Structure is immutable across theme swaps — only the 9 tokens affect appearance.
 *
 * Slots: sidebar · header · main · context
 *
 * @see SHELL.md for full slot/dimension/responsive/PS-wiring documentation.
 */
export default function TransactionShell({
  slots = {},
  nav = {},
  contextOpen,
  onContextOpenChange,
  sidePanel,
  solutionId,
  help,
  linkComponent,
}: TransactionShellProps) {
  // Shell-rendered anchors go through the injected link component when provided
  // (client-side routing); otherwise a plain <a>. See linkComponent JSDoc.
  const LinkComp = linkComponent ?? "a";
  const pathname = usePathname();
  const router = useRouter();
  const [sidebarCollapsed, setSidebarCollapsed] = React.useState(nav?.defaultCollapsed === true);
  const [mobileSidebarOpen, setMobileSidebarOpen] = React.useState(false);
  const [mobileContextOpen, setMobileContextOpen] = React.useState(false);

  const sidebarId = React.useId();

  // D1/D6 — collapsed-rail flyout: exactly ONE group flyout open at a time,
  // owned here (not per-item local state) so switching between adjacent rail
  // icons flips synchronously in one render instead of two independent
  // components briefly overlapping (the D6 flicker). Only closing on
  // hover-leave is debounced (grace period so the pointer can travel from
  // icon to flyout); Radix's own authoritative open/close signals (click,
  // Escape, outside-click, item select) apply immediately.
  const [openGroupId, setOpenGroupId] = React.useState<string | null>(null);
  const closeTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const cancelPendingGroupClose = React.useCallback(() => {
    if (closeTimerRef.current) {
      clearTimeout(closeTimerRef.current);
      closeTimerRef.current = null;
    }
  }, []);
  const openGroup = React.useCallback(
    (id: string) => {
      cancelPendingGroupClose();
      setOpenGroupId(id);
    },
    [cancelPendingGroupClose],
  );
  const closeGroupNow = React.useCallback(
    (id: string) => {
      cancelPendingGroupClose();
      setOpenGroupId((prev) => (prev === id ? null : prev));
    },
    [cancelPendingGroupClose],
  );
  const closeGroupSoon = React.useCallback(
    (id: string) => {
      cancelPendingGroupClose();
      closeTimerRef.current = setTimeout(() => {
        setOpenGroupId((prev) => (prev === id ? null : prev));
      }, 150);
    },
    [cancelPendingGroupClose],
  );
  React.useEffect(() => cancelPendingGroupClose, [cancelPendingGroupClose]);

  const validatedSections = React.useMemo(
    () => (nav?.sections ? mergeNavConfig(nav.sections, nav.allowedExtraSectionIds) : []),
    [nav?.sections, nav?.allowedExtraSectionIds],
  );

  const hasContextContent = Boolean(slots.context) || Boolean(sidePanel?.tabs?.length);
  // Uncontrolled fallback so `useSidePanel().setOpen()`/`.toggle()` works even
  // when the page doesn't lift `contextOpen` state (imperative open/close, N10).
  const [uncontrolledOpen, setUncontrolledOpen] = React.useState(true);
  const isControlled = contextOpen !== undefined;
  const openState = isControlled ? (contextOpen as boolean) : uncontrolledOpen;
  const setOpenState = React.useCallback(
    (open: boolean) => {
      onContextOpenChange?.(open);
      if (!isControlled) setUncontrolledOpen(open);
    },
    [isControlled, onContextOpenChange],
  );
  // Panel is visible when: there is content AND contextOpen is not explicitly false.
  const contextPanelVisible = hasContextContent && openState;
  const sidePanelApi: SidePanelApi = React.useMemo(
    () => ({
      open: contextPanelVisible,
      setOpen: setOpenState,
      toggle: () => setOpenState(!openState),
    }),
    [contextPanelVisible, setOpenState, openState],
  );

  const [uncontrolledTab, setUncontrolledTab] = React.useState(
    sidePanel?.tabs?.[0]?.id,
  );
  const activeTab = sidePanel?.activeTab ?? uncontrolledTab ?? sidePanel?.tabs?.[0]?.id;
  const handleTabChange = React.useCallback(
    (id: string) => {
      sidePanel?.onTabChange?.(id);
      setUncontrolledTab(id);
    },
    [sidePanel],
  );

  const toggleSidebar = React.useCallback(() => {
    setSidebarCollapsed((prev) => !prev);
  }, []);

  const handleToggleKeyDown = React.useCallback(
    (e: React.KeyboardEvent<HTMLButtonElement>) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggleSidebar();
      }
    },
    [toggleSidebar],
  );

  const handleContextClose = React.useCallback(() => {
    setOpenState(false);
    setMobileContextOpen(false);
  }, [setOpenState]);

  const panelTitle = sidePanel?.title ?? "Context";
  const panelTabs = sidePanel?.tabs ?? [];

  const renderPanelBody = () =>
    panelTabs.length ? (
      <Tabs value={activeTab ?? panelTabs[0]!.id} onValueChange={handleTabChange} className="flex flex-1 min-h-0 flex-col">
        <TabsList aria-label="Panel tabs">
          {panelTabs.map((t) => (
            <TabsTrigger key={t.id} value={t.id}>
              {t.label}
            </TabsTrigger>
          ))}
        </TabsList>
        {panelTabs.map((t) => (
          <TabsContent key={t.id} value={t.id} className="flex-1 min-h-0 overflow-y-auto p-[var(--shell-gutter)]">
            {t.id === activeTab ? t.content : null}
          </TabsContent>
        ))}
      </Tabs>
    ) : (
      <div className="flex-1 overflow-y-auto p-[var(--shell-gutter)]" data-slot-name="context">
        <Slot name="context">{slots.context}</Slot>
      </div>
    );

  return (
    <SidePanelContext.Provider value={sidePanelApi}>
    <SessionGuard>
    <ShortcutProvider>
    <NavSequenceShortcuts sections={validatedSections} />
    {/* overflow-x-hidden is the shell's page-body backstop (DR-4): no descendant
        — header, banner, main, or a feature's internal scroll region — may ever
        push the document itself into horizontal scroll. Wide content must scroll
        inside its own bounded container instead. */}
    <div className="flex h-dvh min-h-0 overflow-x-hidden bg-[var(--color-surface)]">
      {/* ── Left Sidebar — full-viewport-height column, owns the top-left
          corner (SidebarIdentity sits at the very top of the screen). The top
          bar spans only the content column to its right (shell v3.1 / N29
          anatomy). Inline on ≥md; a Sheet drawer on mobile (below). ──────── */}
        <aside
          id={sidebarId}
          aria-label="Workspace navigation"
          style={{
            width: sidebarCollapsed ? SIDEBAR_W_COLLAPSED : SIDEBAR_W_EXPANDED,
          }}
          className={[
            "hidden md:flex flex-col shrink-0 border-r border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] overflow-hidden",
            "motion-safe:transition-[width] motion-safe:duration-200 motion-safe:ease-in-out",
          ].join(" ")}
        >
          {/* Identity / switcher / logo area */}
          {nav.identitySlot != null ? (
            typeof nav.identitySlot === "function" ? nav.identitySlot(sidebarCollapsed) : nav.identitySlot
          ) : nav.identity ? (
            <SidebarIdentity
              code={nav.identity.code}
              collapsed={sidebarCollapsed}
              {...(nav.identity.name !== undefined && { name: nav.identity.name })}
              {...(nav.identity.logoSrc !== undefined && { logoSrc: nav.identity.logoSrc })}
              {...(nav.identity.logoAlt !== undefined && { logoAlt: nav.identity.logoAlt })}
            />
          ) : (
            nav.logo && (
              <div
                style={{ height: "var(--shell-header-h)" }}
                className={[
                  "flex shrink-0 items-center border-b border-[var(--color-border-subtle)] overflow-hidden",
                  // D3 fix: the collapsed 64px rail centres the mark on the same
                  // axis as the nav icons below it; the expanded rail keeps the
                  // existing left-aligned treatment.
                  sidebarCollapsed ? "justify-center px-0" : "px-3",
                ].join(" ")}
              >
                <div className="shrink-0">{nav.logo}</div>
              </div>
            )
          )}

          {/* Primary nav items — AppSidebar when expanded; icon-only list when collapsed */}
          {(validatedSections.length || nav.items?.length) ? (
            (() => {
              // Build a unified ModuleNav for both code paths.
              const moduleNav = validatedSections.length
                ? ({ items: [], sections: validatedSections } as unknown as ModuleNav)
                : ({ items: nav.items ?? [] } as ModuleNav);
              const sidebarConfig = buildSidebarConfig(moduleNav);
              // Use the live pathname so AppSidebar auto-expands the correct
              // group and marks the correct child active on every navigation.
              const activePath = pathname ?? deriveActivePath(moduleNav);

              // Collapsed: icon-only strip. A group with children gets a
              // hover/keyboard flyout (D1); a childless group with its own
              // href navigates directly; a group with neither is a config
              // problem, rendered non-interactive.
              if (sidebarCollapsed) {
                const collapsedItems = sidebarConfig.sections.flatMap((s) => s.items as CollapsedNavChild[]);
                return (
                  <nav aria-label="Primary navigation" className="shrink-0 py-2">
                    <ul role="list" className="flex flex-col gap-1 px-3">
                      {collapsedItems.map((item) => (
                        <li key={item.id}>
                          {item.children && item.children.length > 0 ? (
                            <CollapsedGroupFlyout
                              id={item.id}
                              label={item.label}
                              {...(item.icon !== undefined && { icon: item.icon })}
                              children={item.children}
                              activePath={activePath}
                              LinkComp={LinkComp}
                              open={openGroupId === item.id}
                              onHoverEnter={openGroup}
                              onHoverLeave={closeGroupSoon}
                              onOpenChange={(gid, next) => (next ? openGroup(gid) : closeGroupNow(gid))}
                            />
                          ) : item.href ? (
                            <LinkComp
                              href={item.href}
                              {...((activePath === item.href || activePath.startsWith(item.href + "/"))
                                ? { "aria-current": "page" as const }
                                : {})}
                              title={item.label}
                              className={[
                                "relative sidebar-feature-group whitespace-nowrap",
                                (activePath === item.href || activePath.startsWith(item.href + "/")) &&
                                  "sidebar-feature-group-active",
                                "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                              ]
                                .filter(Boolean)
                                .join(" ")}
                            >
                              {(activePath === item.href || activePath.startsWith(item.href + "/")) && (
                                <span
                                  aria-hidden
                                  className="absolute bottom-1.5 left-0 top-1.5 w-0.5 rounded-r bg-secondary"
                                />
                              )}
                              {item.icon && (
                                <span className="flex h-5 w-5 shrink-0 items-center justify-center" aria-hidden="true">
                                  <NavGlyph name={item.icon} />
                                </span>
                              )}
                            </LinkComp>
                          ) : (
                            // No href on the group and no children — a real
                            // config problem. Render non-interactive rather
                            // than a dead link to "#" (D1 ruling).
                            <div
                              aria-disabled="true"
                              title={`${item.label} (no destination configured)`}
                              className="relative sidebar-feature-group whitespace-nowrap cursor-not-allowed opacity-40"
                            >
                              {item.icon && (
                                <span className="flex h-5 w-5 shrink-0 items-center justify-center" aria-hidden="true">
                                  <NavGlyph name={item.icon} />
                                </span>
                              )}
                            </div>
                          )}
                        </li>
                      ))}
                    </ul>
                  </nav>
                );
              }

              return (
                <AppSidebar
                  config={sidebarConfig}
                  activePath={activePath}
                  onNavigate={(href) => { router.push(href); }}
                  storageKey={`dbp-nav-state-${solutionId ?? 'default'}`}
                  showSearch
                />
              );
            })()
          ) : null}

          {/* sidebar slot — content region below primary nav; hidden when empty */}
          {slots.sidebar != null && (
            <div className="flex-1 overflow-y-auto p-2">
              <Slot name="sidebar">{slots.sidebar}</Slot>
            </div>
          )}

          {/* Footer nav — Help/Support + Logout, pinned to bottom */}
          <div className="shrink-0 border-t border-[var(--color-border-subtle)] py-2 px-1">
            {help?.onClick ? (
              <Button
                type="button"
                variant="ghost"
                onClick={help.onClick}
                title={help.label ?? "Help / Support"}
                className="sidebar-feature-group h-auto w-full justify-start font-normal text-left"
              >
                <svg aria-hidden width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>
                </svg>
                {!sidebarCollapsed && <span>{help.label ?? "Help / Support"}</span>}
              </Button>
            ) : (
              <LinkComp href={help?.href ?? "/help"} title={help?.label ?? "Help / Support"} className="sidebar-feature-group font-normal">
                <svg aria-hidden width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>
                </svg>
                {!sidebarCollapsed && <span>{help?.label ?? "Help / Support"}</span>}
              </LinkComp>
            )}
            <a href="/logout" title="Logout" className="sidebar-feature-group font-normal">
              <svg aria-hidden width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
              {!sidebarCollapsed && <span>Logout</span>}
            </a>
          </div>
        </aside>

        {/* ── Right column: top bar, then main + context row, footer pinned
            below (shell v3.1 / N29) — the top bar spans ONLY this column,
            starting at the sidebar's right edge. ────────────────────────── */}
        <div className="flex min-w-0 flex-1 flex-col min-h-0">
          <header
            style={{ height: "var(--shell-header-h)" }}
            className="flex shrink-0 items-center border-b border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] z-[var(--z-sticky)]"
          >
            {/* Sidebar toggle — visible on desktop; hamburger opens Sheet on mobile */}
            <div className="flex items-center px-2">
              {/* Desktop collapse toggle */}
              <Button
                type="button"
                variant="ghost"
                aria-expanded={!sidebarCollapsed}
                aria-controls={sidebarId}
                onClick={toggleSidebar}
                onKeyDown={handleToggleKeyDown}
                className="hidden md:flex h-8 w-8 p-0 rounded text-[color-mix(in_srgb,var(--color-text)_65%,transparent)] hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)] focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] focus-visible:ring-offset-1"
                title={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
              >
                {/* Hamburger / panel icon */}
                <svg
                  aria-hidden="true"
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2 3h12M2 8h12M2 13h12"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  />
                </svg>
                <span className="sr-only">
                  {sidebarCollapsed ? "Expand" : "Collapse"} sidebar
                </span>
              </Button>

              {/* Mobile hamburger — opens Sheet */}
              <Button
                type="button"
                variant="ghost"
                onClick={() => setMobileSidebarOpen(true)}
                className="md:hidden h-8 w-8 p-0 rounded text-[color-mix(in_srgb,var(--color-text)_65%,transparent)] hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)] focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] focus-visible:ring-offset-1"
                aria-label="Open navigation"
              >
                <svg
                  aria-hidden="true"
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2 3h12M2 8h12M2 13h12"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  />
                </svg>
              </Button>
            </div>

            {/* Enriched chrome (AppChrome) OWNS the rest of the bar when provided —
                session + capability driven. Falls back to the legacy breadcrumb +
                actions layout otherwise (backward compatible). */}
            {nav.topBar != null ? (
              <div data-slot-name="topBar" className="min-w-0 flex-1">
                {nav.topBar}
              </div>
            ) : (
              <>
                {/* Breadcrumb zone — header slot (nav.breadcrumb is the default content) */}
                {(slots.header ?? nav.breadcrumb) != null && (
                  <div className="flex-1 min-w-0 px-2">
                    <Slot name="header">{slots.header ?? nav.breadcrumb}</Slot>
                  </div>
                )}

                {/* Actions zone — Phase 4 bindings mount here (NotificationBell, UserMenu) */}
                <div
                  data-slot-name="actions"
                  className="flex shrink-0 items-center gap-1 px-3"
                  aria-label="Top bar actions"
                >
                  {nav.actions ?? null}
                  {nav.user && <div className="ml-1">{nav.user}</div>}
                </div>
              </>
            )}
          </header>

          {/* Banner zone — shell-owned region below the global nav (NOT-03/NOT-15).
              Renders app/page-level Alert banners; empty when nav.banner is absent. */}
          {nav.banner != null && (
            <div data-slot-name="banner" className="shrink-0 px-[var(--shell-gutter)] pt-[var(--shell-gutter)]">
              {nav.banner}
            </div>
          )}

          <div className="flex min-h-0 flex-1 overflow-hidden">
            {/* ── Main Content ─────────────────────────────────────────── */}
            <main
              className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden px-[var(--shell-gutter)] pb-[var(--shell-gutter)]"
              aria-label="Main content"
            >
              <Slot name="main">{slots.main}</Slot>
            </main>

        {/* ── Context Panel (inline on ≥lg) ────────────────────────────── */}
        {contextPanelVisible && (
          <aside
            style={{ width: CONTEXT_PANEL_W }}
            className="hidden lg:flex flex-col shrink-0 border-l border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] overflow-hidden"
            aria-label="Context panel"
          >
            {/* Panel header — title (RULING N10 chrome) + close */}
            <div className="flex shrink-0 items-center justify-between gap-2 px-3 py-2 border-b border-[var(--color-border-subtle)]">
              <span className="text-sm font-semibold text-[var(--color-text)] truncate">{panelTitle}</span>
              <Button
                type="button"
                variant="ghost"
                onClick={handleContextClose}
                className="h-7 w-7 rounded text-[color-mix(in_srgb,var(--color-text)_60%,transparent)] hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)] focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] focus-visible:ring-offset-1"
                aria-label="Close context panel"
              >
                <svg
                  aria-hidden="true"
                  width="14"
                  height="14"
                  viewBox="0 0 14 14"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M1 1l12 12M13 1L1 13"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  />
                </svg>
              </Button>
            </div>
            {renderPanelBody()}
          </aside>
        )}

          </div>{/* end main + context row */}

          {/* ── Footer — spans the main + context column, not the sidebar ── */}
          {nav.footer != null && (
            <footer
              data-slot-name="footer"
              className="flex shrink-0 items-center border-t border-[var(--color-border-subtle)] bg-[var(--color-surface-content)]"
              aria-label="Application footer"
            >
              {nav.footer}
            </footer>
          )}
        </div>{/* end right column */}

        {/* Context panel — stacks as Sheet below lg */}
        {hasContextContent && (
          <Sheet
            open={mobileContextOpen}
            onOpenChange={(open) => {
              setMobileContextOpen(open);
              if (!open) onContextOpenChange?.(false);
            }}
          >
            <SheetContent side="right" className="flex flex-col">
              <SheetHeader>
                <SheetTitle>{panelTitle}</SheetTitle>
              </SheetHeader>
              {renderPanelBody()}
            </SheetContent>
          </Sheet>
        )}

      {/* ── Mobile Sidebar Sheet ─────────────────────────────────────── */}
      <Sheet open={mobileSidebarOpen} onOpenChange={setMobileSidebarOpen}>
        <SheetContent side="left" className="flex flex-col p-0 gap-0 h-full w-[min(85vw,var(--shell-sidebar-w))]">
          <SheetHeader
            style={{ height: "var(--shell-header-h)" }}
            className="shrink-0 flex-row items-center justify-between px-3 border-b border-[var(--color-border-subtle)] space-y-0"
          >
            {nav.identitySlot != null ? (
              <>
                <div className="min-w-0 flex-1 overflow-hidden">
                  {typeof nav.identitySlot === "function" ? nav.identitySlot(false) : nav.identitySlot}
                </div>
                <SheetTitle className="sr-only">Navigation</SheetTitle>
              </>
            ) : nav.logo ? (
              <>
                <div className="min-w-0 shrink overflow-hidden">{nav.logo}</div>
                <SheetTitle className="sr-only">Navigation</SheetTitle>
              </>
            ) : (
              <SheetTitle asChild>
                <SectionLabel as="p" className="text-sm">Navigation</SectionLabel>
              </SheetTitle>
            )}
          </SheetHeader>
          {(validatedSections.length || nav.items?.length) ? (
            (() => {
              const moduleNav = validatedSections.length
                ? ({ items: [], sections: validatedSections } as unknown as ModuleNav)
                : ({ items: nav.items ?? [] } as ModuleNav);
              return (
                <AppSidebar
                  config={buildSidebarConfig(moduleNav)}
                  activePath={pathname ?? deriveActivePath(moduleNav)}
                  onNavigate={(href) => {
                    // D4 fix: previously discarded `href` — the drawer closed
                    // but the route never changed. Push first, close after: a
                    // React state update batches with the Sheet's animated
                    // close, so ordering here doesn't race the route change.
                    router.push(href);
                    setMobileSidebarOpen(false);
                  }}
                  storageKey={`dbp-nav-state-${solutionId ?? 'default'}`}
                  className="flex-1 min-h-0"
                />
              );
            })()
          ) : null}
          {slots.sidebar && (
            <div className="shrink-0 px-2 border-t border-[var(--color-border-subtle)]">
              <Slot name="sidebar">{slots.sidebar}</Slot>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>{/* end outer sidebar-row shell */}
    </ShortcutProvider>
    </SessionGuard>
    </SidePanelContext.Provider>
  );
}
