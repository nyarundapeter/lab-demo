import type { NavItem, NavSection } from "@dbp/contracts";

/** Bare single-key bindings already claimed elsewhere in the shell/features
 * (List navigation j/k, LVE detail-panel [/], and ShortcutProvider's built-in
 * ?). A derived "g <letter>" sequence is skipped when its letter collides with
 * one of these — avoids two different keyboard idioms overloading the same key. */
const RESERVED_LETTERS = new Set(["j", "k", "c", "n", "[", "]", "?"]);

export interface NavSequenceRegistration {
  /** The derived second key, e.g. "o" for "Orientation" → "g o". */
  letter: string;
  keys: string;
  label: string;
  href: string;
}

export interface NavSequenceSkip {
  label: string;
  letter: string;
  reason: string;
}

export interface DerivedNavSequences {
  registrations: NavSequenceRegistration[];
  skipped: NavSequenceSkip[];
}

/** First href reachable by walking a section's items/children depth-first. */
function firstHref(items: NavItem[] | undefined): string | undefined {
  if (!items) return undefined;
  for (const item of items) {
    if (item.href) return item.href;
    const nested = firstHref(item.children);
    if (nested) return nested;
  }
  return undefined;
}

/**
 * Derives `g <letter>` sequence-shortcut candidates from the shell's top-level
 * nav sections (deferral row 26). One candidate per section, keyed off the
 * first letter of its label; a later section whose first letter collides with
 * an earlier one (or with an already-reserved single-key binding) is skipped,
 * not silently overwritten — the caller can report `skipped` for visibility.
 * Sections with no navigable href anywhere in their tree are skipped too.
 */
export function deriveNavSequenceShortcuts(sections: NavSection[]): DerivedNavSequences {
  const registrations: NavSequenceRegistration[] = [];
  const skipped: NavSequenceSkip[] = [];
  const usedLetters = new Set<string>(RESERVED_LETTERS);

  for (const section of sections) {
    const label = section.label?.trim();
    if (!label) continue;
    const letter = label[0]!.toLowerCase();

    if (usedLetters.has(letter)) {
      skipped.push({
        label,
        letter,
        reason: RESERVED_LETTERS.has(letter)
          ? `"g ${letter}" collides with the existing "${letter}" single-key binding`
          : `"g ${letter}" already claimed by an earlier nav section`,
      });
      continue;
    }

    const href = firstHref(section.items);
    if (!href) {
      skipped.push({ label, letter, reason: "section has no navigable href" });
      continue;
    }

    usedLetters.add(letter);
    registrations.push({ letter, keys: `g ${letter}`, label, href });
  }

  return { registrations, skipped };
}
