import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { FileText, Globe, User, Paperclip } from "lucide-react";
import {
  Button,
  FormField,
  FieldLabel,
  Input,
  Textarea,
  FileDropzone,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@dbp/ui";
import { FormBasicLayout } from "../layouts/form-basic.js";

// ─── Mock data ───────────────────────────────────────────────────────────────────

function RequestTypeSelect() {
  return (
    <Select>
      <SelectTrigger>
        <SelectValue placeholder="Select request type" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="compliance">Compliance Review</SelectItem>
        <SelectItem value="filing">Regulatory Filing</SelectItem>
        <SelectItem value="disclosure">Disclosure Request</SelectItem>
      </SelectContent>
    </Select>
  );
}

function PrioritySelect() {
  return (
    <Select defaultValue="medium">
      <SelectTrigger>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="low">Low</SelectItem>
        <SelectItem value="medium">Medium</SelectItem>
        <SelectItem value="high">High</SelectItem>
      </SelectContent>
    </Select>
  );
}

function BusinessUnitSelect() {
  return (
    <Select>
      <SelectTrigger>
        <SelectValue placeholder="Select business unit" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="retail">Retail Banking</SelectItem>
        <SelectItem value="corporate">Corporate Banking</SelectItem>
        <SelectItem value="treasury">Treasury</SelectItem>
      </SelectContent>
    </Select>
  );
}

function JurisdictionSelect() {
  return (
    <Select>
      <SelectTrigger>
        <SelectValue placeholder="Select jurisdiction" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="uae">United Arab Emirates</SelectItem>
        <SelectItem value="ksa">Saudi Arabia</SelectItem>
        <SelectItem value="bh">Bahrain</SelectItem>
      </SelectContent>
    </Select>
  );
}

function FrameworkSelect() {
  return (
    <Select>
      <SelectTrigger>
        <SelectValue placeholder="Select framework" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="basel">Basel III</SelectItem>
        <SelectItem value="aml">AML/CFT</SelectItem>
      </SelectContent>
    </Select>
  );
}

function OwnerSelect() {
  return (
    <Select>
      <SelectTrigger>
        <SelectValue placeholder="Select owner" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="pa">Platform Admin</SelectItem>
        <SelectItem value="cm">Compliance Manager</SelectItem>
      </SelectContent>
    </Select>
  );
}

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof FormBasicLayout> = {
  title: "Layer 07 — App Scaffolds/Layouts/FormBasicLayout",
  component: FormBasicLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**FormBasicLayout** — a sectioned create/update form: a stack of \`FormSection\`s,
each rendering fields on the canonical 12-col Grid (2-up at md+, 1-up below).
Page title comes from the shell breadcrumb (shell v3, N27); actions (Save draft /
Submit) live in a toolbar row at the top of the body content.

Props: \`header?: ReactNode\` · \`sections: FormBasicSection[]\`

Each section: \`{ id, title, description?, icon?, fields: FormBasicField[] }\`.
Each field: \`{ id, span?: ColSpan (default 6), content: ReactNode }\` — content is
typically a \`<FormField>\` wrapping \`Input\`/\`Select\`/\`Textarea\`.

Deliberately has NO sticky/fixed bottom action bar — actions live only in the
body's top toolbar row.

Use for: form archetype, \`form-basic\` layout (create/update transactional requests).
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof FormBasicLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

export const Default: Story = {
  name: "Create Regulatory Request (populated)",
  render: () => (
    <div style={{ height: "900px" }}>
      <div className="flex justify-end gap-2 mb-4">
        <Button variant="outline">Save draft</Button>
        <Button variant="navy">Submit</Button>
      </div>
      <FormBasicLayout
        sections={[
          {
            id: "details",
            title: "Request Details",
            icon: <FileText size={16} strokeWidth={1.5} />,
            fields: [
              {
                id: "request-type",
                content: (
                  <FormField
                    label="Request Type"
                    required
                    helperText="Choose the category that best describes your request."
                  >
                    <RequestTypeSelect />
                  </FormField>
                ),
              },
              {
                id: "priority",
                content: (
                  <FormField label="Priority" required helperText="Select the priority level for this request.">
                    <PrioritySelect />
                  </FormField>
                ),
              },
              {
                id: "title",
                span: 12,
                content: (
                  <FormField
                    label="Title"
                    required
                    helperText="A short, descriptive title helps reviewers understand the request."
                  >
                    <Input placeholder="Enter a concise title for this request" />
                  </FormField>
                ),
              },
              {
                id: "summary",
                span: 12,
                content: (
                  <FormField
                    label="Summary"
                    required
                    helperText="Include the purpose and key context for this request."
                  >
                    <Textarea placeholder="Provide a brief summary of the request" />
                  </FormField>
                ),
              },
            ],
          },
          {
            id: "context",
            title: "Request Context",
            icon: <Globe size={16} strokeWidth={1.5} />,
            fields: [
              {
                id: "business-unit",
                content: (
                  <FormField label="Business Unit" required>
                    <BusinessUnitSelect />
                  </FormField>
                ),
              },
              {
                id: "jurisdiction",
                content: (
                  <FormField
                    label="Jurisdiction"
                    required
                    helperText="The regulatory jurisdiction this request relates to."
                  >
                    <JurisdictionSelect />
                  </FormField>
                ),
              },
              {
                id: "framework",
                content: (
                  <FormField
                    label="Related Framework"
                    helperText="Link to an applicable regulatory framework, if any."
                  >
                    <FrameworkSelect />
                  </FormField>
                ),
              },
              {
                id: "reference-id",
                content: (
                  <FormField label="Reference ID" helperText="Internal or external reference for tracking.">
                    <Input placeholder="Enter reference ID" />
                  </FormField>
                ),
              },
            ],
          },
          {
            id: "assignment",
            title: "Assignment",
            icon: <User size={16} strokeWidth={1.5} />,
            fields: [
              {
                id: "owner",
                content: (
                  <FormField label="Owner" required helperText="Request will be assigned to this person.">
                    <OwnerSelect />
                  </FormField>
                ),
              },
              {
                id: "due-date",
                content: (
                  <FormField label="Due Date" required helperText="Target date for completion of this request.">
                    <Input type="date" />
                  </FormField>
                ),
              },
            ],
          },
          {
            id: "documents",
            title: "Supporting Documents",
            icon: <Paperclip size={16} strokeWidth={1.5} />,
            fields: [
              {
                id: "attachments",
                span: 12,
                content: (
                  <div className="flex flex-col gap-1.5">
                    <FieldLabel>
                      Attachments <span className="normal-case font-normal text-[var(--color-text-muted)]">(Optional)</span>
                    </FieldLabel>
                    <FileDropzone
                      accept=".pdf,.docx,.xlsx,.pptx,.zip"
                      helperText="Upload any supporting documents. Max file size 25MB per file. Allowed types: PDF, DOCX, XLSX, PPTX, ZIP."
                    />
                  </div>
                ),
              },
            ],
          },
        ]}
      />
    </div>
  ),
};
