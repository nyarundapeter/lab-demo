import type { Meta, StoryObj } from "@storybook/react";
import { CollectionBoardLayout } from "../layouts/collection-board.js";
import {
  KanbanBoardWithToolbar,
} from "./collection-board-layout.stories.js";

/**
 * Cookbook/Workspace/Kanban Board (Collection Board)
 *
 * A thin, second title on top of the real `CollectionBoardLayout` "children mode"
 * composition — the same `KanbanBoardWithToolbar` (real APP.F04 `KanbanBoard` +
 * `CollectionToolbar`, wired to real client-side search state) demonstrated in
 * `collection-board-layout.stories.tsx`'s `ChildrenMode` story, re-exported here
 * under the Cookbook so builders browsing by standard-nav section find it without
 * needing to know the underlying layout's name. No render logic is duplicated —
 * this file imports the shared fixtures/component from the original story file.
 *
 * **Real solution:** none yet — no shipped solution's manifest currently wires
 * APP.F04 (Kanban) into a module. Both the layout wiring and the Kanban feature
 * itself are real and fully built (verified live this session), just not yet
 * adopted by an authored solution. This entry demonstrates the pattern ahead of
 * that first real adoption.
 *
 * See Reference/Layout Archetypes → collection → collection-board for the layout
 * contract itself.
 */

function KanbanBoardPage() {
  return (
    <div style={{ height: "640px" }}>
      <CollectionBoardLayout>
        <KanbanBoardWithToolbar />
      </CollectionBoardLayout>
    </div>
  );
}

const meta: Meta<typeof KanbanBoardPage> = {
  title: "Cookbook/Workspace/Kanban Board (Collection Board)",
  component: KanbanBoardPage,
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component:
          "Real APP.F04 Kanban + `CollectionBoardLayout` children-mode composition — see " +
          "`Layer 07 — App Scaffolds/Layouts/CollectionBoardLayout` → `ChildrenMode` for the " +
          "same story with full annotation.",
      },
    },
  },
};
export default meta;
type Story = StoryObj<typeof KanbanBoardPage>;

export const Default: Story = {};
