import * as React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { BuilderLayout } from '../layouts/builder.js'
import { FormBuilderView } from '../features/admin-config/form-builder.js'

const meta: Meta<typeof BuilderLayout> = {
  title: 'Layer 07 — App Scaffolds/Layouts/BuilderLayout',
  component: BuilderLayout,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: `
**BuilderLayout** — full-height header-slot layout for builder surfaces.

Props: \`header?: ReactNode\` · \`saveFormId?: string\` · \`saveLabel?: string\` · \`children: ReactNode\`

The \`header\` slot is deprecated (shell v3, N27 — the shell breadcrumb carries the page
title). The layout renders a thin toolbar row holding the
layout-owned Publish/Save action pushed to the right (when \`saveFormId\` is provided), then
the full-height \`children\` (the builder feature).

The toolbar Save submits a \`<form id>\` rendered by the builder feature via the HTML \`form\`
attribute — no JS coupling. The feature must NOT render its own submit button.

The body is a full-height, full-bleed region; the builder feature renders the 3-panel UI
(palette | canvas | properties) internally.

**ADR-0035 structural ReactNode seam rule:** the layout exposes only \`children\` as a
\`ReactNode\`. Panel composition (3-panel structure) is the feature's responsibility.
No \`leftPanel\` / \`rightPanel\` props.

Use for: APP.F11 Form Builder, APP.F12 Workflow Builder, APP.F13 Rule Builder, and any
drag-and-drop builder surface.
        `.trim(),
      },
    },
  },
}
export default meta
type Story = StoryObj<typeof BuilderLayout>

// ─── Stories ─────────────────────────────────────────────────────────────────

/**
 * FormBuilder — the canonical use case. BuilderLayout wraps FormBuilderView;
 * the toolbar Publish button targets the FormBuilderView's canvas form id.
 * This is the proof-of-concept for DWS.01 /admin/form-builder.
 */
export const FormBuilder: Story = {
  name: 'Form Builder (DWS.01)',
  render: () => (
    <div style={{ height: '720px' }}>
      <BuilderLayout
        saveFormId="form-builder"
        saveLabel="Publish"
      >
        <FormBuilderView />
      </BuilderLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'BuilderLayout with the FormBuilderView feature. The page title comes from the shell breadcrumb (N27). ' +
          'The layout-owned Publish button in the toolbar row submits the FormBuilderView\'s `<form id="form-builder">` ' +
          'via the HTML `form` attribute — no JS coupling. The 3-panel layout (palette | canvas | properties) ' +
          'is owned entirely by the feature; the layout provides only the toolbar + full-bleed body.',
      },
    },
  },
}

/**
 * No save action — layout without a primary CTA in the toolbar.
 */
export const WithoutSaveAction: Story = {
  name: 'BuilderLayout — no save action',
  render: () => (
    <div style={{ height: '400px' }}>
      <BuilderLayout>
        <div className="h-full flex items-center justify-center rounded-[var(--radius-card)] border-2 border-dashed border-[var(--color-border)] text-sm text-[var(--color-text-muted)]">
          Builder feature goes here (body-only)
        </div>
      </BuilderLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'When no saveFormId is provided, the toolbar row is omitted entirely.',
      },
    },
  },
}

/**
 * Minimal — no breadcrumb, custom save label.
 */
export const MinimalNoBreadcrumb: Story = {
  name: 'BuilderLayout — minimal, no breadcrumb',
  render: () => (
    <div style={{ height: '400px' }}>
      <BuilderLayout
        saveFormId="workflow-builder"
        saveLabel="Save draft"
      >
        <div className="h-full flex items-center justify-center rounded-[var(--radius-card)] border-2 border-dashed border-[var(--color-border)] text-sm text-[var(--color-text-muted)]">
          Workflow builder feature (body-only)
        </div>
      </BuilderLayout>
    </div>
  ),
}

/**
 * No header slot — layout without a page-supplied header.
 */
export const NoHeader: Story = {
  name: 'BuilderLayout — no header slot',
  render: () => (
    <div style={{ height: '400px' }}>
      <BuilderLayout saveFormId="inline-builder" saveLabel="Save">
        <div className="h-full flex items-center justify-center rounded-[var(--radius-card)] border-2 border-dashed border-[var(--color-border)] text-sm text-[var(--color-text-muted)]">
          Builder feature (no page header — toolbar save still visible)
        </div>
      </BuilderLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'When no header is supplied, the layout omits the sticky header area but still ' +
          'renders the toolbar row with the Save button.',
      },
    },
  },
}
