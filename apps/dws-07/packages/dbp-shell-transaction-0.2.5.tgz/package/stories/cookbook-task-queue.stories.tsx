import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureDataClient } from "@dbp/ps-data/client";
import { configureAuditClient } from "@dbp/ps-audit/client";
import { Breadcrumb, ShortcutProvider } from "@dbp/ui";
import LveWorkspace from "@dbp/organisms/lve-workspace";
import { CanvasLayout } from "../layouts/canvas.js";

/**
 * Cookbook/Workspace/Task Queue (LVE)
 *
 * The `lve-split` layout as it really ships (see `apps/dws-01/app/tasks/my-tasks/page.tsx`
 * and `packages/stack/app-scaffolds/features/lve-workspace/examples/task-workspace.config.tsx`,
 * the canonical APP.F19 reference config for the "My Tasks" page — adapted here into a
 * self-contained story fixture): `CanvasLayout` with `fullBleed` (page title carried by
 * the shell breadcrumb — shell v3, N27), and `LveWorkspace` mounted with `externalHeader`
 * so it never renders its own list-mode header. View-mode changes are driven by
 * `LveWorkspace`'s typed `callbacks.onViewChange` (ADR-0040) — not the deprecated
 * `dbp:lve:view-change` DOM CustomEvent.
 *
 * **Real solution:** Cookbook/Solution Manifests/DWS.01 — Digital Operations Workspace, `/tasks/my-tasks`
 * (DWS.01.M03 "My Tasks", journey stage 2). See that page for the full reference —
 * this entry is the canonical composition, not a variant.
 *
 * See Reference/Layout Archetypes → lve for the layout contract itself.
 */

const TASK_ROWS = [
  { title: "Modernise procurement portal", assignee: "Alice", priority: "high", status: "in-progress", category: "Delivery", dueDate: "2026-07-14" },
  { title: "Renew supplier contracts", assignee: "Bob", priority: "medium", status: "open", category: "Compliance", dueDate: "2026-07-18" },
  { title: "Close Q2 audit findings", assignee: "Priya", priority: "critical", status: "pending-approval", category: "Assurance", dueDate: "2026-07-10" },
  { title: "Rotate service account credentials", assignee: "Alice", priority: "high", status: "completed", category: "Security", dueDate: "2026-07-01" },
].map((data, i) => ({
  id: `task-${i + 1}`,
  tenantId: "demo",
  entityType: "task",
  createdAt: "2026-06-01T00:00:00Z",
  updatedAt: "2026-06-01T00:00:00Z",
  data,
}));

function makeDataFetch() {
  return (input: string): Promise<Response> => {
    const url = new URL(input);
    if (/\/entities\/[^/]+\/[^/]+$/.test(url.pathname)) {
      return Promise.resolve(
        new Response(JSON.stringify(TASK_ROWS[0]), {
          status: 200,
          headers: { "content-type": "application/json" },
        }),
      );
    }
    return Promise.resolve(
      new Response(JSON.stringify({ rows: TASK_ROWS, total: TASK_ROWS.length, page: 1, pageSize: 25 }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
  };
}

function makeAuditFetch() {
  return (): Promise<Response> =>
    Promise.resolve(
      new Response(JSON.stringify({ events: [], nextCursor: null }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

const TASK_COLUMNS = [
  { field: "title", label: "Title", sortable: true },
  { field: "assignee", label: "Assignee", sortable: true },
  {
    field: "priority",
    label: "Priority",
    sortable: true,
    format: "badge" as const,
    badgeTones: { low: "neutral" as const, medium: "info" as const, high: "warning" as const, critical: "danger" as const },
  },
  {
    field: "status",
    label: "Status",
    sortable: true,
    format: "badge" as const,
    editable: true,
    editType: "select" as const,
    editOptions: [
      { value: "open", label: "Open" },
      { value: "in-progress", label: "In Progress" },
      { value: "pending-approval", label: "Pending Approval" },
      { value: "completed", label: "Completed" },
    ],
    badgeTones: { open: "info" as const, "in-progress": "warning" as const, "pending-approval": "orange" as const, completed: "success" as const },
  },
  { field: "category", label: "Category", format: "badge" as const },
  { field: "dueDate", label: "Due Date", sortable: true, format: "date" as const },
];

const TASK_DETAIL_TABS = [
  {
    id: "details",
    label: "Details",
    sections: [
      {
        title: "Task Details",
        fields: [
          { field: "title", label: "Title", editable: true, editType: "text" as const },
          { field: "assignee", label: "Assignee", editable: true, editType: "text" as const },
          { field: "priority", label: "Priority", format: "badge" as const },
          { field: "status", label: "Status", format: "badge" as const },
          { field: "dueDate", label: "Due Date", format: "date" as const },
          { field: "category", label: "Category", format: "badge" as const },
        ],
      },
    ],
  },
];

const CRUMB = [{ label: "Workspace", href: "#" }, { label: "My Tasks" }];

function TaskQueuePage() {
  const qc = React.useMemo(() => new QueryClient({ defaultOptions: { queries: { retry: false, staleTime: 0 } } }), []);

  React.useEffect(() => {
    configureDataClient({ baseUrl: "http://mock.test/api/platform/data", fetch: makeDataFetch(), tenantId: "demo" });
    configureAuditClient({ baseUrl: "http://mock.test/api/platform/audit", fetch: makeAuditFetch(), tenantId: "demo" });
  }, []);

  return (
    <QueryClientProvider client={qc}>
      <ShortcutProvider disableHelp>
      <div style={{ height: "720px" }}>
        <CanvasLayout
          fullBleed
          header={
            <div className="py-1.5 bg-[var(--color-surface)] border-b border-[var(--color-border-subtle)]">
              <Breadcrumb items={CRUMB} />
            </div>
          }
        >
          <LveWorkspace
            entityType="task"
            entityLabel="Task"
            title="My Tasks"
            externalHeader
            columns={TASK_COLUMNS}
            detailTabs={TASK_DETAIL_TABS}
            header={{ titleField: "title", subtitleField: "assignee", statusField: "status" }}
          />
        </CanvasLayout>
      </div>
      </ShortcutProvider>
    </QueryClientProvider>
  );
}

const meta: Meta<typeof TaskQueuePage> = {
  title: "Cookbook/Workspace/Task Queue (LVE)",
  component: TaskQueuePage,
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component:
          "Real `lve-split` page composition — `CanvasLayout` + " +
          "`LveWorkspace` (`externalHeader`), adapted from the `apps/dws-01` My Tasks page. Click a " +
          "row to open the detail pane (page title carried by the shell breadcrumb, N27).",
      },
    },
  },
};
export default meta;
type Story = StoryObj<typeof TaskQueuePage>;

export const Default: Story = {};
