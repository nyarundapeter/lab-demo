import type { Meta, StoryObj } from "@storybook/react";
import WorkspaceDashboard, { WorkspaceDashboardActions } from "@dbp/organisms/workspace-dashboard";
import { OverviewGridLayout } from "../layouts/overview-grid.js";
import { StoryWrapper, CONFIG } from "./overview-grid-layout.stories.js";

/**
 * Cookbook/Orientation/My Dashboard (Overview Grid)
 *
 * A thin, second title on top of the real `overview-grid` + APP.F21
 * `WorkspaceDashboard` composition demonstrated in `overview-grid-layout.stories.tsx`'s
 * `Default` story — re-exported here under the Cookbook so builders browsing by
 * standard-nav section find it without needing to know the underlying layout's name.
 * No render logic or fixtures are duplicated — this file imports them from the
 * original story file.
 *
 * **Real solution:** not tied to one — "My Dashboard" is the standard-menu's
 * `orientation` section default (`scripts/standard-menu-layout-map.json`),
 * injected identically into every solution's demo surface. See any Solutions/*
 * page's resolved-module count (it's part of the standard-menu scaffold, not an
 * authored module).
 *
 * See Reference/Layout Archetypes → overview → overview-grid for the layout
 * contract itself.
 */

function MyDashboardPage() {
  return (
    <div style={{ height: "900px" }}>
      <StoryWrapper>
        <OverviewGridLayout>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: "8px", marginBottom: "16px" }}>
            <WorkspaceDashboardActions actions={CONFIG.actions ?? []} />
          </div>
          <WorkspaceDashboard {...CONFIG} />
        </OverviewGridLayout>
      </StoryWrapper>
    </div>
  );
}

const meta: Meta<typeof MyDashboardPage> = {
  title: "Cookbook/Orientation/My Dashboard (Overview Grid)",
  component: MyDashboardPage,
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component:
          "Real APP.F21 WorkspaceDashboard + `OverviewGridLayout` composition — see " +
          "`Layer 07 — App Scaffolds/Layouts/OverviewGridLayout` → `Default` for the same " +
          "story with full annotation.",
      },
    },
  },
};
export default meta;
type Story = StoryObj<typeof MyDashboardPage>;

export const Default: Story = {};
