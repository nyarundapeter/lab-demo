import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import {
  Button,
  FormField,
  FormSection,
  Grid,
  Col,
  Input,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@dbp/ui";
import { FormGuidedLayout } from "../layouts/form-guided.js";
import type { FormGuidedStep } from "../layouts/form-guided.js";

// ─── Mock steps + body content, matching the reference mockup ───────────────────

const STEPS: FormGuidedStep[] = [
  { id: "details", label: "Request Details", title: "Request Details" },
  { id: "scope", label: "Scope", title: "Scope" },
  { id: "review-setup", label: "Review Setup", title: "Review Setup" },
  { id: "confirm", label: "Confirm & Submit", title: "Confirm & Submit" },
];

function ScopeStepBody() {
  return (
    <>
      <FormSection
        title="Review Information"
        description="Provide key information to help us route and plan the review."
      >
        <Grid>
          <Col span={6}>
            <FormField label="Regulation / Framework" required>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select regulation or framework" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="aml">AML</SelectItem>
                  <SelectItem value="kyc">KYC</SelectItem>
                  <SelectItem value="gdpr">GDPR</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </Col>
          <Col span={6}>
            <FormField label="Business Unit" required>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select business unit" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="retail">Retail Banking</SelectItem>
                  <SelectItem value="corporate">Corporate Banking</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </Col>
          <Col span={6}>
            <FormField label="Reviewer Group" required>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select reviewer group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="compliance">Compliance Team</SelectItem>
                  <SelectItem value="legal">Legal Team</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </Col>
          <Col span={6}>
            <FormField label="Due Date" required>
              <Input type="date" />
            </FormField>
          </Col>
        </Grid>
      </FormSection>

      <FormSection
        title="Supporting Documents (Optional)"
        description="Upload any relevant documents to support this review request."
      >
        <label
          htmlFor="supporting-documents"
          className="flex flex-col items-center justify-center gap-2 rounded-[var(--radius-card)] border-2 border-dashed border-[var(--color-border)] py-10 text-center cursor-pointer hover:border-primary focus-within:[box-shadow:var(--focus-ring-navy)]"
        >
          <span className="text-sm text-[var(--color-text)]">
            Drag and drop files here, or{" "}
            <span className="font-semibold text-primary underline-offset-4 hover:underline">
              browse
            </span>
          </span>
          <span className="text-xs text-[var(--color-text-muted)]">
            PDF, DOCX, XLSX, PPTX up to 20MB each
          </span>
          <input id="supporting-documents" type="file" multiple className="sr-only" />
        </label>
      </FormSection>
    </>
  );
}

// ─── Storybook meta ──────────────────────────────────────────────────────────────

const meta: Meta<typeof FormGuidedLayout> = {
  title: "Layer 07 — App Scaffolds/Layouts/FormGuidedLayout",
  component: FormGuidedLayout,
  parameters: { layout: "fullscreen" },
};
export default meta;

type Story = StoryObj<typeof FormGuidedLayout>;

/**
 * Step 2 of 4 ("Scope"), with step 1 completed — matches the reference mockup's
 * content and confirms the "one Save draft, top only" correction: the bottom
 * navigation bar renders ONLY Back and Continue.
 */
export const MidFlow: Story = {
  render: () => (
    <FormGuidedLayout
      steps={STEPS}
      currentStep={1}
      infoRail={{
        progressLabel: "Step 2 of 4",
        progressDescription:
          "Provide the review's regulation, business unit, and reviewer routing details. You can save your progress and continue later.",
        autoSaveNote: "Your draft will be saved automatically.",
        helpLink: { label: "View request guidelines", href: "#" },
      }}
      onBack={() => {}}
      onContinue={() => {}}
    >
      <div className="flex justify-end gap-2 mb-4">
        <Button variant="outline">Save draft</Button>
        <Button variant="ghost">Cancel</Button>
      </div>
      <ScopeStepBody />
    </FormGuidedLayout>
  ),
};

/** First step — Back is hidden/absent, matching the mockup's disabled first-step state. */
export const FirstStep: Story = {
  render: () => (
    <FormGuidedLayout
      steps={STEPS}
      currentStep={0}
      infoRail={{
        progressLabel: "Step 1 of 4",
        progressDescription: "Provide the basic information about this compliance review request.",
        autoSaveNote: "Your draft will be saved automatically.",
        helpLink: { label: "View request guidelines", href: "#" },
      }}
      onContinue={() => {}}
    >
      <div className="flex justify-end gap-2 mb-4">
        <Button variant="outline">Save draft</Button>
        <Button variant="ghost">Cancel</Button>
      </div>
      <ScopeStepBody />
    </FormGuidedLayout>
  ),
};

/** Last step — continue button reads "Submit". */
export const FinalStep: Story = {
  render: () => (
    <FormGuidedLayout
      steps={STEPS}
      currentStep={3}
      infoRail={{
        progressLabel: "Step 4 of 4",
        progressDescription: "Review your answers, then submit the request.",
        autoSaveNote: "Your draft will be saved automatically.",
        helpLink: { label: "View request guidelines", href: "#" },
      }}
      onBack={() => {}}
      onContinue={() => {}}
      continueLabel="Submit"
    >
      <div className="flex justify-end gap-2 mb-4">
        <Button variant="outline">Save draft</Button>
        <Button variant="ghost">Cancel</Button>
      </div>
      <p className="text-sm text-[var(--color-text-muted)]">Confirmation summary goes here.</p>
    </FormGuidedLayout>
  ),
};
