import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { SlotFrame } from "@dbp/ui";
import TransactionShell, { useSidePanel } from "../index.js";

const meta: Meta<typeof TransactionShell> = {
  title: "Layer 07 — App Scaffolds/Shells/SH.WORKSPACE — Workspace Shell (Transaction)",
  component: TransactionShell,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**SH.02 — Transaction Workspace Shell** (Stage 02 Transact)

**Shell v3.1 anatomy (N29):** a full-viewport-height sidebar owns the top-left
corner — \`SidebarIdentity\` sits at the very top of the screen — and the top
bar (h:52 via --shell-header-h) spans ONLY the content column, starting at the
sidebar's right edge (hamburger + breadcrumb left, controls right). Two grid
columns: sidebar | content; the sidebar spans all rows, the content column
stacks top bar → [main content | context panel w:320 optional] → footer.

Slots: \`sidebar\` · \`header\` · \`main\` · \`context\`

The sidebar collapses from w:280 to w:64 — the identity shrinks to the icon
square and the narrow strip still runs full height; nav icons remain visible.
The context panel renders only when the \`context\` slot has content; below lg
it opens as a Sheet. Exactly ONE breadcrumb ever renders — the top bar's (via
\`nav.topBar\`/AppChrome) — pages never render a second, in-content breadcrumb.
Toggle the **Theme** toolbar button to verify zero structural change between "DBP default" and "Alt client".
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof TransactionShell>;

// ─── Mock helpers ──────────────────────────────────────────────────────────────

function MockIcon({ label }: { label: string }) {
  return (
    <svg
      aria-hidden="true"
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect
        x="1"
        y="1"
        width="14"
        height="14"
        rx="2"
        stroke="currentColor"
        strokeWidth="1.5"
      />
      <text
        x="8"
        y="11"
        textAnchor="middle"
        fontSize="7"
        fill="currentColor"
        fontFamily="monospace"
      >
        {label[0]}
      </text>
    </svg>
  );
}

const MOCK_NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: <MockIcon label="Dashboard" />, active: true, href: "#" },
  { id: "orders", label: "Orders", icon: <MockIcon label="Orders" />, href: "#" },
  { id: "products", label: "Products", icon: <MockIcon label="Products" />, href: "#" },
  { id: "customers", label: "Customers", icon: <MockIcon label="Customers" />, href: "#" },
  { id: "reports", label: "Reports", icon: <MockIcon label="Reports" />, href: "#" },
];

function MockMainContent() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <p style={{ margin: 0, fontSize: "14px", color: "var(--color-text)", opacity: 0.7 }}>
        slot:main — APP.F01 Entity List or similar feature mounts here at solution time.
      </p>
      {Array.from({ length: 5 }, (_, i) => (
        <div
          key={i}
          style={{
            padding: "12px 16px",
            background: "var(--color-surface)",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius)",
            color: "var(--color-text)",
            fontSize: "14px",
          }}
        >
          Row {i + 1} — entity data from PS.DATA
        </div>
      ))}
    </div>
  );
}

function MockContextContent() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <h3 style={{ margin: "0 0 4px", fontSize: "15px", fontWeight: 600, color: "var(--color-text)" }}>
        Entity Detail
      </h3>
      <p style={{ margin: 0, fontSize: "13px", color: "color-mix(in srgb, var(--color-text) 65%, transparent)" }}>
        APP.F02 Entity Detail Panel or APP.F06 Approval Surface mounts here at solution time.
      </p>
      {["Field A", "Field B", "Field C"].map((f) => (
        <div
          key={f}
          style={{
            display: "flex",
            justifyContent: "space-between",
            fontSize: "13px",
            color: "var(--color-text)",
            padding: "6px 0",
            borderBottom: "1px solid var(--color-border)",
          }}
        >
          <span style={{ opacity: 0.6 }}>{f}</span>
          <span>value</span>
        </div>
      ))}
    </div>
  );
}

// ─── Empty Shell ──────────────────────────────────────────────────────────────

/**
 * All 4 slots render as labeled SlotFrame placeholders.
 *
 * At RUNTIME unfilled slots collapse (render nothing); this story passes
 * SlotFrame placeholders EXPLICITLY so the slot layout (incl. the context panel)
 * is visible in Storybook. Renders correctly in both toolbar themes.
 */
export const EmptyShell: Story = {
  name: "Empty shell (all 4 SlotFrames, context open)",
  render: () => (
    <div style={{ height: "600px" }}>
      <TransactionShell
        slots={{
          sidebar: <SlotFrame slotName="sidebar" isEmpty />,
          header: <SlotFrame slotName="header" isEmpty />,
          main: <SlotFrame slotName="main" isEmpty />,
          context: <SlotFrame slotName="context" isEmpty />,
        }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "All 4 slots shown as labeled SlotFrame placeholders (passed explicitly — at runtime unfilled slots collapse). Renders correctly in both toolbar themes.",
      },
    },
  },
};

// ─── Populated ────────────────────────────────────────────────────────────────

export const Populated: Story = {
  name: "Populated shell",
  render: () => (
    <div style={{ height: "600px" }}>
      <TransactionShell
        nav={{
          logo: (
            <span
              style={{
                fontWeight: 700,
                color: "var(--color-primary)",
                fontSize: "16px",
                whiteSpace: "nowrap",
              }}
            >
              DBP Tx
            </span>
          ),
          items: MOCK_NAV_ITEMS,
          breadcrumb: (
            <nav aria-label="Breadcrumb">
              <ol
                style={{
                  display: "flex",
                  gap: "4px",
                  listStyle: "none",
                  margin: 0,
                  padding: 0,
                  fontSize: "13px",
                  color: "color-mix(in srgb, var(--color-text) 60%, transparent)",
                }}
              >
                <li>Workspace</li>
                <li aria-hidden="true">/</li>
                <li style={{ color: "var(--color-text)", fontWeight: 500 }}>Orders</li>
              </ol>
            </nav>
          ),
          actions: (
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: "var(--radius)",
                background: "color-mix(in srgb, var(--color-border) 40%, transparent)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "11px",
                color: "var(--color-text)",
              }}
            >
              {/* Phase 4: NotificationBell mounts here */}
              🔔
            </div>
          ),
          user: (
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: "50%",
                background: "var(--color-primary)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "11px",
                color: "#fff",
                fontWeight: 600,
              }}
            >
              U
            </div>
          ),
        }}
        slots={{
          sidebar: (
            <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
              <p
                style={{
                  margin: "0 0 8px",
                  fontSize: "11px",
                  fontWeight: 600,
                  textTransform: "uppercase",
                  letterSpacing: "0.05em",
                  color: "color-mix(in srgb, var(--color-text) 50%, transparent)",
                }}
              >
                Filters
              </p>
              {["All", "Pending", "In Progress", "Completed"].map((s) => (
                <button
                  key={s}
                  style={{
                    padding: "4px 8px",
                    background: "none",
                    border: "none",
                    borderRadius: "var(--radius)",
                    color: "var(--color-text)",
                    fontSize: "13px",
                    cursor: "pointer",
                    textAlign: "left",
                  }}
                >
                  {s}
                </button>
              ))}
            </div>
          ),
          main: <MockMainContent />,
          context: <MockContextContent />,
        }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: "Shell populated with representative content in every slot.",
      },
    },
  },
};

// ─── Full-height sidebar (Shell v3.1 / N29) ────────────────────────────────────

export const FullHeightSidebar: Story = {
  name: "Full-height sidebar — identity at top (Shell v3.1 / N29)",
  render: () => (
    <div style={{ height: "600px" }}>
      <TransactionShell
        nav={{
          identity: { code: "DBP.01", name: "DBP Platform Showcase" },
          items: MOCK_NAV_ITEMS,
          topBar: (
            <nav aria-label="Breadcrumb" style={{ display: "flex", alignItems: "center", height: "100%", fontSize: "13px" }}>
              <span style={{ color: "color-mix(in srgb, var(--color-text) 60%, transparent)" }}>Workspace</span>
              <span aria-hidden="true" style={{ margin: "0 6px" }}>/</span>
              <span style={{ color: "var(--color-text)", fontWeight: 500 }}>Orders</span>
            </nav>
          ),
        }}
        slots={{ main: <MockMainContent /> }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "The sidebar is a full-viewport-height column that owns the top-left corner — `SidebarIdentity` (\"DBP.01 / DBP Platform Showcase\") renders at the very top of the screen, above the primary nav. The top bar (breadcrumb via `nav.topBar`) spans ONLY the content column, starting at the sidebar's right edge — it never crosses over the sidebar. Collapse the sidebar via the ≡ toggle to see the identity shrink to its icon square while the strip stays full height.",
      },
    },
  },
};

// ─── Sidebar Collapsed ────────────────────────────────────────────────────────

export const SidebarCollapsed: Story = {
  name: "Sidebar — collapsed state",
  render: () => (
    <div style={{ height: "500px" }}>
      <TransactionShell
        nav={{
          logo: (
            <span style={{ fontWeight: 700, color: "var(--color-primary)", fontSize: "16px" }}>
              DBP
            </span>
          ),
          items: MOCK_NAV_ITEMS,
          breadcrumb: (
            <span style={{ fontSize: "13px", color: "var(--color-text)" }}>
              Orders / New Order
            </span>
          ),
        }}
        slots={{
          main: <MockMainContent />,
        }}
      />
      <p
        style={{
          position: "absolute",
          bottom: 8,
          left: 8,
          margin: 0,
          fontSize: "12px",
          color: "var(--color-text)",
          background: "var(--color-surface)",
          padding: "4px 8px",
          borderRadius: "var(--radius)",
          border: "1px solid var(--color-border)",
        }}
      >
        Click the ≡ toggle in the top bar to collapse/expand the sidebar. Icons remain visible collapsed.
      </p>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Sidebar in collapsed state (w:64). Icons remain visible; labels are hidden. The ≡ toggle in the top bar controls the collapse with a width transition (skipped under prefers-reduced-motion).",
      },
    },
  },
};

// ─── Mobile Viewport ──────────────────────────────────────────────────────────

export const MobileViewport: Story = {
  name: "Mobile viewport (< md)",
  render: () => (
    <div style={{ width: "375px", height: "667px", overflow: "hidden" }}>
      <TransactionShell
        nav={{
          logo: (
            <span style={{ fontWeight: 700, color: "var(--color-primary)", fontSize: "15px" }}>
              DBP
            </span>
          ),
          items: MOCK_NAV_ITEMS,
          breadcrumb: (
            <span style={{ fontSize: "13px", color: "var(--color-text)" }}>Orders</span>
          ),
        }}
        slots={{
          main: <MockMainContent />,
        }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "375px viewport. The sidebar is hidden from layout and opens as a Sheet via the hamburger button. The context panel is also hidden at this breakpoint (opens as a Sheet when triggered).",
      },
    },
  },
};

// ─── ADR-0040 capability props ────────────────────────────────────────────────

export const CustomHelpAffordance: Story = {
  name: "Custom help affordance (ADR-0040)",
  render: () => (
    <div style={{ height: "600px" }}>
      <TransactionShell
        help={{ href: "/support/portal", label: "Support Portal" }}
        nav={{
          items: [
            { id: "home", label: "Home", href: "#home" },
            { id: "work", label: "Work Queue", href: "#work" },
          ],
        }}
        slots={{ main: <SlotFrame slotName="main" isEmpty /> }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "The sidebar-footer help link is configured via the `help` prop (`href`/`label`; an `onClick` variant renders a button and wins over `href`). Before ADR-0040, solutions rewrote the hardcoded `/help` anchor with DOM polling — this prop retires that hack. Defaults preserve the original `/help` link.",
      },
    },
  },
};

export const CustomLinkComponent: Story = {
  name: "Injected link component (ADR-0040)",
  render: () => {
    // Stand-in for next/link: renders <a> with a data-marker so the story can
    // demonstrate that shell-rendered anchors go through the injected component.
    const MarkerLink = ({ href, children, ...rest }: { href: string; children: React.ReactNode; className?: string; title?: string }) => (
      <a href={href} data-injected-link {...rest}>{children}</a>
    );
    return (
      <div style={{ height: "600px" }}>
        <TransactionShell
          linkComponent={MarkerLink}
          nav={{
            defaultCollapsed: true,
            sections: [
              {
                id: "workspace",
                items: [
                  { id: "queue", label: "Work Queue", icon: "ListChecks", href: "#queue", children: [] },
                  { id: "approvals", label: "Approvals", icon: "CheckSquare", href: "#approvals", children: [] },
                ],
              },
            ],
          }}
          slots={{ main: <SlotFrame slotName="main" isEmpty /> }}
        />
      </div>
    );
  },
  parameters: {
    docs: {
      description: {
        story:
          "`linkComponent` (e.g. `next/link`) is used for the shell-rendered anchors — the collapsed icon-strip nav and the help link — giving client-side routing instead of full page reloads. The Logout link intentionally stays a plain `<a>`: `/logout` is a route handler that must receive a full request. The generator passes `linkComponent={Link}` automatically.",
      },
    },
  },
};

// ─── Side Panel (RULING N10) ───────────────────────────────────────────────────
//
// The `context` slot IS the anchored, persistent right-panel capability shared
// by both the AI assistant placements (APP.F14) and overlay side-panel use
// cases: non-modal, no scrim, content reflows the main canvas. The `sidePanel`
// prop adds chrome (title + tabbed content) on top of that existing slot; the
// `useSidePanel()` hook lets any descendant open/close it imperatively without
// the page having to lift `contextOpen` state itself.

function SidePanelLauncher() {
  const panel = useSidePanel();
  return (
    <button
      type="button"
      onClick={panel.toggle}
      style={{
        padding: "6px 12px",
        borderRadius: "var(--radius)",
        border: "1px solid var(--color-border)",
        background: "var(--color-primary)",
        color: "#fff",
        fontSize: "13px",
        cursor: "pointer",
      }}
    >
      {panel.open ? "Close" : "Open"} assistant panel
    </button>
  );
}

export const SidePanelTabbed: Story = {
  name: "Persistent side panel — tabbed chrome (RULING N10)",
  render: () => (
    <div style={{ height: "600px" }}>
      <TransactionShell
        nav={{ logo: <span style={{ fontWeight: 700 }}>DBP Tx</span> }}
        sidePanel={{
          title: "Assistant",
          tabs: [
            {
              id: "ai",
              label: "AI assistant",
              content: (
                <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  <p style={{ fontSize: "13px", lineHeight: 1.5, margin: 0 }}>
                    All 6 grants are still active and the contractor's last day has passed.
                    I can draft the revocation sequence.
                  </p>
                  <button style={{ alignSelf: "flex-start", fontSize: "12px", padding: "4px 10px" }}>
                    Draft revocation
                  </button>
                </div>
              ),
            },
            {
              id: "activity",
              label: "Activity",
              content: <p style={{ fontSize: "13px", margin: 0 }}>3 events today · last: SLA breach flagged.</p>,
            },
            {
              id: "inspector",
              label: "Inspector",
              content: <p style={{ fontSize: "13px", margin: 0 }}>Status: Open · Priority: High · Owner: A. Okafor</p>,
            },
          ],
        }}
        slots={{
          main: (
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              <p style={{ fontSize: "13px", color: "var(--color-text-muted)" }}>
                The panel is part of the workspace, not a temporary overlay — no scrim, no
                focus trap, content reflows around it.
              </p>
              <SidePanelLauncher />
            </div>
          ),
        }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "The panel's tabbed chrome (title, tab strip, close) driven by the `sidePanel` prop. The launcher button in `main` calls `useSidePanel().toggle()` to open/close the panel imperatively — the same mechanism an AI assistant launcher (APP.F14) or a record-detail 'open inspector' action would use, without the page lifting `contextOpen` state itself.",
      },
    },
  },
};
