import { SixSlots } from './canvas-layout.stories.js'

const meta = {
  title: 'Layer 07 — App Scaffolds/Layouts/WorkingLayout',
  component: SixSlots,
}

export default meta
export { SixSlots as Default }
