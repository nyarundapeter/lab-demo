import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureDataClient } from "@dbp/ps-data/client";
import { configureAuthClient } from "@dbp/ps-auth/client";
import type { BreadcrumbItem } from "@dbp/ui";
import WorkspaceDashboard, {
  WorkspaceDashboardActions,
} from "@dbp/organisms/workspace-dashboard";
import type { WorkspaceDashboardConfigInput } from "@dbp/organisms/workspace-dashboard";
import { OverviewGridLayout } from "../layouts/overview-grid.js";

// ─── Mock data client (WorkspaceDashboard's TasksCard reads via PS.DATA) ──────────

const FAKE_TASKS = Array.from({ length: 12 }).map((_, i) => ({
  id: `task-${String(i + 1).padStart(3, "0")}`,
  tenantId: "demo",
  entityType: "task",
  createdAt: "2026-01-01T00:00:00Z",
  updatedAt: "2026-01-01T00:00:00Z",
  data: {
    title: `Task ${String(i + 1).padStart(2, "0")}: Complete platform milestone`,
    status: ["in-progress", "open", "blocked"][i % 3],
    priority: ["high", "medium", "low"][i % 3],
    dueDate: i === 0 ? new Date().toISOString().slice(0, 10) : `2026-07-${String(10 + i).padStart(2, "0")}`,
  },
}));

const FAKE_REMINDERS = [
  { id: "reminder-001", tenantId: "demo", entityType: "reminder", createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z", data: { title: "Assess any new risks identified in the morning governance meeting", dueAt: "Today", done: false, userId: "usr-story-demo" } },
  { id: "reminder-002", tenantId: "demo", entityType: "reminder", createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z", data: { title: "Q2 compliance attestation due in 7 days", dueAt: "Due Jun 26, 2026", done: false, userId: "usr-story-demo" } },
  { id: "reminder-003", tenantId: "demo", entityType: "reminder", createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z", data: { title: "Outline key points for audit finding remediation stand-up", dueAt: "Due Jun 26, 2026", done: false, userId: "usr-story-demo" } },
];

export function StoryWrapper({ children }: { children: React.ReactNode }) {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false, staleTime: 0 } } });
  configureDataClient({
    baseUrl: "http://mock.test/api/platform/data",
    fetch: (input: string) => {
      const rows = input.includes("/entities/reminder") ? FAKE_REMINDERS : FAKE_TASKS;
      return Promise.resolve(
        new Response(JSON.stringify({ rows, total: rows.length, page: 1, pageSize: rows.length }), {
          status: 200,
          headers: { "content-type": "application/json" },
        }),
      );
    },
    tenantId: "demo",
  });
  configureAuthClient({
    baseUrl: "http://mock.test/api/platform/auth",
    fetch: () =>
      Promise.resolve(
        new Response(
          JSON.stringify({
            session: {
              userId: "usr-story-demo",
              email: "demo@story.test",
              roles: ["user"],
              tenantId: "demo",
              exp: Math.floor(Date.now() / 1000) + 3600,
            },
            user: { id: "usr-story-demo", email: "demo@story.test", displayName: "Story Demo", roles: ["user"], tenantId: "demo" },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
      ),
  });
  return <QueryClientProvider client={qc}>{children}</QueryClientProvider>;
}

export const CONFIG: WorkspaceDashboardConfigInput = {
  userName: "Alex",
  actions: [{ label: "Ask AI", primary: true }, { label: "New Task" }],
  tasksEntityType: "task",
  taskGroups: [
    { key: "in-progress", label: "IN PROGRESS", statuses: ["in-progress"] },
    { key: "to-do", label: "TO DO", statuses: ["open"] },
    { key: "upcoming", label: "UPCOMING", statuses: ["blocked"] },
  ],
  taskFields: { name: "title", priority: "priority", dueDate: "dueDate", status: "status" },
  goals: [
    { label: "Q2 GRC compliance readiness", context: "Governance & Compliance", value: 72 },
    { label: "Close high priority audit findings", context: "Assurance", value: 48 },
    { label: "Policy review and rationalization", context: "Governance", value: 65 },
  ],
  projects: [
    { name: "SAMA ITGF readiness", tasks: 6, teammates: 4, icon: "S", tone: "primary" },
    { name: "Cyber risk reassessment", tasks: 4, teammates: 3, icon: "C", tone: "secondary" },
    { name: "Policy annual review", tasks: 4, teammates: 2, icon: "P", tone: "success" },
  ],
  calendar: {
    month: "June 2026",
    days: [
      { dow: "Mon", day: 16 },
      { dow: "Tue", day: 17 },
      { dow: "Wed", day: 18 },
      { dow: "Thu", day: 19, active: true },
      { dow: "Fri", day: 20 },
      { dow: "Sat", day: 21 },
      { dow: "Sun", day: 22 },
    ],
    events: [{ title: "Governance committee prep", time: "Today · 10:00 – 11:00", provider: "Teams" }],
  },
  remindersEntityType: "reminder",
};

export const BREADCRUMB: BreadcrumbItem[] = [{ label: "Workspace", href: "#" }, { label: "Overview" }];

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof OverviewGridLayout> = {
  title: "Layer 07 — App Scaffolds/Layouts/OverviewGridLayout",
  component: OverviewGridLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**OverviewGridLayout** — a sticky-header shell for a personal "My Dashboard" widget grid.

Props: \`header?: ReactNode\` · \`children\`

The widget grid content (task list, goals, projects, calendar, reminders) comes from
APP.F21 WorkspaceDashboard mounted in \`children\`; page-level actions (Ask AI, New Task, ...)
render in a toolbar row at the top of the body via \`WorkspaceDashboardActions\`, consistent
with the single-header-owner rule (ADR-0034) and breadcrumb-as-title (shell v3, N27).
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof OverviewGridLayout>;

export const Default: Story = {
  name: "Default (My Dashboard)",
  render: () => (
    <div style={{ height: "900px" }}>
      <StoryWrapper>
        <OverviewGridLayout>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: "8px", marginBottom: "16px" }}>
            <WorkspaceDashboardActions actions={CONFIG.actions ?? []} />
          </div>
          <WorkspaceDashboard {...CONFIG} />
        </OverviewGridLayout>
      </StoryWrapper>
    </div>
  ),
};
