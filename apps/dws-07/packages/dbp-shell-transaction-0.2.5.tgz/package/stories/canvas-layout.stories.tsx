import type { Meta, StoryObj } from '@storybook/react'
import * as React from 'react'
import { Button } from '@dbp/ui'
import { CanvasLayout } from '../layouts/canvas.js'
import type { CanvasSlot } from '../layouts/canvas.js'

const meta: Meta<typeof CanvasLayout> = {
  title: 'Layer 07 — App Scaffolds/Layouts/CanvasLayout',
  component: CanvasLayout,
  parameters: { layout: 'fullscreen' },
}
export default meta
type Story = StoryObj<typeof CanvasLayout>

const Widget = ({ label, tall }: { label: string; tall?: boolean }) => (
  <div className={`rounded-xl border border-[var(--color-border)] bg-white p-4 ${tall ? 'h-48' : 'h-32'} flex items-center justify-center text-sm text-[var(--color-text-muted)]`}>
    {label}
  </div>
)

// Canonical 6-slot arrangement: 2 rows × 3 columns (span-4 each)
// Note: span 8 is not valid — use span 6 for the wide slot
const SIX_SLOTS: CanvasSlot[] = [
  { id: 'kpi-1',    span: 4, content: <Widget label="KPI · Incidents" /> },
  { id: 'kpi-2',    span: 4, content: <Widget label="KPI · SLA %" /> },
  { id: 'kpi-3',    span: 4, content: <Widget label="KPI · Open Requests" /> },
  { id: 'chart',    span: 6, content: <Widget label="Trend Chart" tall /> },
  { id: 'activity', span: 6, content: <Widget label="Recent Activity" tall /> },
]

// Wide + narrow split (6+6) — suitable for a primary panel + side rail
const WIDE_NARROW_SLOTS: CanvasSlot[] = [
  { id: 'main',     span: 6, content: <Widget label="Primary Panel" tall /> },
  { id: 'rail',     span: 6, content: <Widget label="Side Rail" tall /> },
  { id: 'footer-a', span: 6, content: <Widget label="Summary A" /> },
  { id: 'footer-b', span: 6, content: <Widget label="Summary B" /> },
]

// Single full-width slot — equivalent to old WorkingLayout usage (children mode)
const FULL_WIDTH_SLOT: CanvasSlot[] = [
  { id: 'content', span: 12, content: <Widget label="Full-width content area" tall /> },
]

export const SixSlots: Story = {
  name: '6-slot dashboard (canonical)',
  render: () => (
    <CanvasLayout
      slots={SIX_SLOTS}
    />
  ),
}

export const WideNarrow: Story = {
  name: 'Wide + narrow (6+6 split)',
  render: () => (
    <CanvasLayout
      slots={[
        { id: 'toolbar', span: 12, content: (
          <div className="flex justify-end gap-2 mb-4">
            <Button>New Incident</Button>
          </div>
        ) },
        ...WIDE_NARROW_SLOTS,
      ]}
    />
  ),
}

export const FullWidth: Story = {
  name: 'Full-width (WorkingLayout backward-compat)',
  render: () => (
    <CanvasLayout
      slots={FULL_WIDTH_SLOT}
    />
  ),
}

export const ChildrenFallback: Story = {
  name: 'Children fallback (no slots)',
  render: () => (
    <CanvasLayout>
      <div className="p-6">
        <Widget label="Rendered via children prop — no slots declared" tall />
      </div>
    </CanvasLayout>
  ),
}
