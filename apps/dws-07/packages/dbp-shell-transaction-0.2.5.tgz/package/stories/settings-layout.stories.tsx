import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { SettingsLayout } from "../layouts/settings.js";
import { Button, FieldLabel, Input, Switch } from "@dbp/ui";

// ─── Mock form ───────────────────────────────────────────────────────────────────

/** A generic mock settings form using @dbp/ui primitives (body-only, no chrome). */
function MockSettingsForm({ section }: { section: string }) {
  return (
    <div className="flex flex-col gap-6">
      <p className="text-sm text-[var(--color-text-muted)]">
        Configure your {section.toLowerCase()} settings.
      </p>

      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="display-name">Display name</FieldLabel>
        <Input
          id="display-name"
          type="text"
          defaultValue="Alpha Finance Approver"
          className="max-w-sm"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="email">Email address</FieldLabel>
        <Input
          id="email"
          type="email"
          defaultValue="approver@alpha.dev.local"
          className="max-w-sm"
        />
      </div>

      <div className="flex items-center justify-between py-3 border-b border-[var(--color-border)]">
        <div className="flex flex-col gap-0.5">
          <span className="text-sm font-semibold text-[var(--color-text)]">Email notifications</span>
          <span className="text-xs text-[var(--color-text-muted)]">
            Receive activity digests and workflow alerts
          </span>
        </div>
        <Switch defaultChecked aria-label="Email notifications" />
      </div>

      <div>
        <Button type="button">Save changes</Button>
      </div>
    </div>
  );
}

// ─── Mock nav ────────────────────────────────────────────────────────────────────

/** A minimal settings nav for stories — mirrors what a real solution supplies. */
function MockSettingsNav() {
  const links = ["General", "User Preferences", "Security", "Notifications"];
  return (
    <nav className="flex flex-col gap-1">
      {links.map((l) => (
        <a
          key={l}
          href="#"
          className="rounded px-3 py-2 text-sm text-[var(--color-text)] hover:bg-[var(--color-surface)]"
        >
          {l}
        </a>
      ))}
    </nav>
  );
}

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof SettingsLayout> = {
  title: "Layer 07 — App Scaffolds/Layouts/SettingsLayout",
  component: SettingsLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**SettingsLayout** — a sticky-header + nav-rail + body-column layout for settings pages.

Props: \`header?: ReactNode\` · \`nav: ReactNode\` (required) · \`children: ReactNode\`

The \`header\` prop is deprecated (shell v3, N27) — the shell breadcrumb carries the page title.
The \`nav\` prop is required — pass the settings navigation sidebar.
Body content is constrained to a readable column width.

Use for: APP.F15 Settings hub, APP.F16 User Preferences, single-section admin config pages.
For multi-section pages, prefer \`ConfigTabsLayout\`.
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof SettingsLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/**
 * Default — a single-section settings page with header and nav rail.
 */
export const Default: Story = {
  name: "Default (with nav rail)",
  render: () => (
    <div style={{ height: "560px" }}>
      <SettingsLayout
        nav={<MockSettingsNav />}
      >
        <MockSettingsForm section="General" />
      </SettingsLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Settings page with left nav rail; page title comes from the shell breadcrumb (N27). " +
          "Use ConfigTabsLayout for tab-based multi-section pages.",
      },
    },
  },
};

/**
 * With breadcrumb — the trail is carried by the shell chrome (breadcrumb-as-title, N27).
 */
export const WithBreadcrumb: Story = {
  name: "With breadcrumb",
  render: () => (
    <div style={{ height: "560px" }}>
      <SettingsLayout
        nav={<MockSettingsNav />}
      >
        <MockSettingsForm section="Preferences" />
      </SettingsLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "SettingsLayout with the breadcrumb trail carried by the shell chrome (breadcrumb-as-title, N27).",
      },
    },
  },
};

/**
 * Header-less — nav and children only, no sticky header.
 */
export const NoHeader: Story = {
  name: "No header (nav + body only)",
  render: () => (
    <div style={{ height: "560px" }}>
      <SettingsLayout nav={<MockSettingsNav />}>
        <MockSettingsForm section="Security" />
      </SettingsLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Omitting the header prop renders the nav rail and body column without a sticky header block.",
      },
    },
  },
};
