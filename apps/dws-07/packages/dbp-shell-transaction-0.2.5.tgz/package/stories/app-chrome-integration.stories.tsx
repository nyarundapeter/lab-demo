import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import type { NavSection } from "@dbp/contracts";
import { AppChrome, Input } from "@dbp/ui";
import type { AppChromeSession } from "@dbp/ui";
import { Bell } from "lucide-react";
import TransactionShell from "../index.js";
// SOURCE OF TRUTH: scripts/standard-menu.json — the curated default standard menu.
// Mirrors the approach in standard-nav.stories.tsx so the top-bar integration
// story exercises the same nav that the generator emits.
import standardMenu from "../../../../../../scripts/standard-menu.json";

// ─── Nav helpers (mirror of standard-nav.stories.tsx buildNavSections) ─────────
// Keep in sync with buildNavSections() in scripts/standard-menu-scaffold.mjs.
// areas → sections, groups → items, features → children.

interface MenuArea {
  id: string;
  label: string;
  groups: { id: string; label: string; icon: string; features: { id: string; label: string; route: string }[] }[];
}

function buildNavSections(): NavSection[] {
  return (standardMenu.areas as MenuArea[]).map((a) => ({
    id: a.id,
    label: a.label.toUpperCase(),
    items: a.groups.map((g) => ({
      id: g.id,
      label: g.label,
      icon: g.icon,
      children: g.features.map((f) => ({ id: f.id, label: f.label, href: f.route })),
    })),
  }));
}

const STD_NAV = buildNavSections();

// ─── QueryClient (required by AppChrome's SearchBar / NotificationBell bindings) ─
const client = new QueryClient();

// ─── Search/notification slot placeholders ──────────────────────────────────────
// AppChrome takes pre-built elements for these slots (Layer 06/07 boundary — @dbp/ui
// never fetches PS.SEARCH/PS.NOTIF itself); presence of the prop IS the capability
// flag. Mirrors the pattern in packages/shared/ui/src/stories/app-chrome.stories.tsx.
function SearchSlotPlaceholder() {
  return <Input type="text" placeholder="Search shifts, people, requests…" className="w-full" />;
}
function NotificationSlotPlaceholder() {
  return (
    <button type="button" aria-label="Notifications">
      <Bell size={17} strokeWidth={1.5} aria-hidden="true" />
    </button>
  );
}

// ─── Mock sessions ──────────────────────────────────────────────────────────────

const approverSession: AppChromeSession = {
  userId: "usr-alpha-approver",
  email: "approver@alpha.dev.local",
  displayName: "Alpha Finance Approver",
  primaryRole: "Finance Approver",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
};

// ─── Mock logo ──────────────────────────────────────────────────────────────────

function DemoLogo() {
  return (
    <span style={{ fontWeight: 700, color: "var(--color-primary)", fontSize: "16px", whiteSpace: "nowrap" }}>
      DBP Platform
    </span>
  );
}

// ─── Mock main content ──────────────────────────────────────────────────────────

function DemoMain({ title }: { title: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <h2 style={{ margin: 0, fontSize: "18px", fontWeight: 600, color: "var(--color-text)" }}>{title}</h2>
      <p style={{ margin: 0, fontSize: "14px", color: "color-mix(in srgb, var(--color-text) 65%, transparent)" }}>
        The selected feature page mounts here at solution time. This story focuses on the
        AppChrome top bar integration — expand the sidebar groups on the left to walk the
        standard information architecture.
      </p>
      {Array.from({ length: 3 }, (_, i) => (
        <div
          key={i}
          style={{
            padding: "12px 16px",
            background: "var(--color-surface)",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius)",
            color: "var(--color-text)",
            fontSize: "14px",
          }}
        >
          Row {i + 1} — entity data from PS.DATA
        </div>
      ))}
    </div>
  );
}

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof TransactionShell> = {
  title: "Layer 07 — App Scaffolds/Shells/SH.WORKSPACE — Workspace Shell (Transaction)/AppChrome Top Bar",
  component: TransactionShell,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**SH.02 + AppChrome integration** — the connected top-bar path every PS.AUTH solution takes.

\`TransactionShell\` accepts \`nav.topBar\` which OWNS the entire bar area to the right of the sidebar
toggle. When \`<AppChrome>\` is mounted there it becomes the single, canonical session + capability
driven chrome shared by all four apps.

\`AppChrome\` requires a \`QueryClientProvider\` decorator (its \`SearchBar\` and \`NotificationBell\`
bindings call \`@tanstack/react-query\` hooks). This is set up as a story decorator so every story
in this file inherits it automatically.

The standard nav uses real generator data from \`scripts/standard-menu.json\` (same source as
\`standard-nav.stories.tsx\`) so the sidebar always reflects the actual out-of-the-box information
architecture.
        `.trim(),
      },
    },
  },
  decorators: [
    (Story) => (
      <QueryClientProvider client={client}>
        <Story />
      </QueryClientProvider>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof TransactionShell>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/**
 * Fully wired — AppChrome with search + notifications, the complete standard nav,
 * and an authenticated session. This is the exact mount point every PS.AUTH
 * solution uses: AppChrome passed into `nav.topBar`, taking ownership of the
 * entire top-bar content area.
 */
export const FullyWired: Story = {
  name: "Fully wired (session + search + notifications)",
  render: () => (
    <div style={{ height: "680px" }}>
      <TransactionShell
        solutionId="storybook-appchrome-full"
        nav={{
          logo: <DemoLogo />,
          sections: STD_NAV,
          topBar: (
            <AppChrome
              productCode="DWS.05"
              productName="Digital WFMS"
              session={approverSession}
              search={<SearchSlotPlaceholder />}
              notifications={<NotificationSlotPlaceholder />}
            />
          ),
        }}
        slots={{ main: <DemoMain title="Dashboard" /> }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "AppChrome mounted in nav.topBar with search + notifications enabled, multi-area standard nav, and an authenticated session. " +
          "The sidebar toggle on the far left coexists with AppChrome because the shell controls that button; AppChrome owns everything to its right.",
      },
    },
  },
};

/**
 * No session (loading / unauthenticated) — session is null so AppChrome renders
 * without the avatar block. Demonstrates the loading state every app shows
 * before PS.AUTH resolves the session identity.
 */
export const NoSession: Story = {
  name: "No session (loading / unauthenticated)",
  render: () => (
    <div style={{ height: "560px" }}>
      <TransactionShell
        solutionId="storybook-appchrome-nosession"
        nav={{
          logo: <DemoLogo />,
          sections: STD_NAV,
          topBar: (
            <AppChrome
              productCode="DXP.01A"
              productName="Digital Channels Web"
              session={null}
              search={<SearchSlotPlaceholder />}
              notifications={<NotificationSlotPlaceholder />}
            />
          ),
        }}
        slots={{ main: <DemoMain title="Loading…" /> }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "session={null} — AppChrome renders without the avatar lockup. " +
          "This is the state before PS.AUTH resolves, or on public pages that fall outside SessionGuard.",
      },
    },
  },
};
