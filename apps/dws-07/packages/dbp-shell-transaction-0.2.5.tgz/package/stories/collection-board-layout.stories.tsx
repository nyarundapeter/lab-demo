import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureWorkflowClient } from "@dbp/ps-workflow/client";
import type { WorkflowInstance } from "@dbp/ps-workflow/client";
import type { BreadcrumbItem } from "@dbp/ui";
import { BoardCard, CollectionToolbar } from "@dbp/ui";
import KanbanBoard from "@dbp/organisms/kanban";
import { CollectionBoardLayout } from "../layouts/collection-board.js";
import type { CollectionBoardColumn } from "../layouts/collection-board.js";

// ─── Mock helpers ────────────────────────────────────────────────────────────────

type Priority = "Low" | "Medium" | "High";

const PRIORITY_TONE: Record<Priority, "default" | "warning" | "danger"> = {
  Low: "default",
  Medium: "warning",
  High: "danger",
};

interface BoardRecord {
  title: string;
  owner: string;
  category: string;
  date: string;
  priority: Priority;
}

const RECORDS: { open: BoardRecord[]; inProgress: BoardRecord[]; review: BoardRecord[]; done: BoardRecord[] } = {
  open: [
    { title: "CDD Clarification Request", owner: "Ahmed Al-Mansoori", category: "Compliance", date: "Jun 18, 2026", priority: "High" },
    { title: "KYC Documentation Follow-up", owner: "Sara Al-Zaabi", category: "KYC", date: "Jun 17, 2026", priority: "Medium" },
    { title: "PEP Screening Clarification", owner: "Khalid Al-Nuaimi", category: "Compliance", date: "Jun 14, 2026", priority: "High" },
  ],
  inProgress: [
    { title: "Cross-Border Reporting Query", owner: "Fatima Al-Rashid", category: "Reporting", date: "Jun 16, 2026", priority: "Medium" },
    { title: "Beneficial Ownership Query", owner: "Sara Al-Zaabi", category: "KYC", date: "Jun 19, 2026", priority: "Medium" },
    { title: "Transaction Monitoring Alert", owner: "Khalid Al-Nuaimi", category: "Monitoring", date: "Jun 12, 2026", priority: "High" },
  ],
  review: [
    { title: "AML Threshold Review", owner: "Omar Al-Hashimi", category: "Compliance", date: "Jun 15, 2026", priority: "High" },
    { title: "Sanctions Match Investigation", owner: "Ahmed Al-Mansoori", category: "Compliance", date: "Jun 13, 2026", priority: "High" },
  ],
  done: [
    { title: "Demo Record 04", owner: "Sara Al-Zaabi", category: "Compliance", date: "Jun 13, 2026", priority: "Low" },
    { title: "Demo Record 08", owner: "Fatima Al-Rashid", category: "Customer", date: "Jun 17, 2026", priority: "Medium" },
  ],
};

function renderRecordCard(r: BoardRecord) {
  return (
    <BoardCard
      key={r.title}
      title={r.title}
      subtitle={r.owner}
      meta={`${r.category} · ${r.date}`}
      badgeTone={PRIORITY_TONE[r.priority]}
      badgeLabel={r.priority}
    />
  );
}

function boardColumns(): CollectionBoardColumn[] {
  return [
    { id: "open", title: "Open", count: 32, children: RECORDS.open.map(renderRecordCard) },
    { id: "inProgress", title: "In Progress", count: 28, children: RECORDS.inProgress.map(renderRecordCard) },
    { id: "review", title: "Review", count: 18, children: RECORDS.review.map(renderRecordCard) },
    { id: "done", title: "Done", count: 50, children: RECORDS.done.map(renderRecordCard) },
  ];
}

export const BREADCRUMB: BreadcrumbItem[] = [
  { label: "Transactions", href: "#" },
  { label: "Enquiries" },
];

// ─── Kanban children-mode mock helpers ────────────────────────────────────────────

const KANBAN_INSTANCES: WorkflowInstance[] = [
  {
    workflowId: "wf-draft-001",
    definitionId: "invoice-approval",
    definitionVersion: "1.0.0",
    tenantId: "demo",
    status: "running",
    currentStep: "draft",
    revision: 1,
    assignedUserId: null,
    sortOrder: null,
    steps: [],
    context: { invoiceNumber: "INV-001", amount: 5000, vendor: "Acme Corp" },
    createdAt: "2026-01-10T09:00:00.000Z",
    updatedAt: "2026-01-10T09:00:00.000Z",
  },
  {
    workflowId: "wf-pending-002",
    definitionId: "invoice-approval",
    definitionVersion: "1.0.0",
    tenantId: "demo",
    status: "running",
    currentStep: "pending-approval",
    revision: 1,
    assignedUserId: null,
    sortOrder: null,
    steps: [],
    context: { invoiceNumber: "INV-002", amount: 12500, vendor: "Beta LLC" },
    createdAt: "2026-01-09T08:00:00.000Z",
    updatedAt: "2026-01-09T10:00:00.000Z",
  },
  {
    workflowId: "wf-approved-003",
    definitionId: "invoice-approval",
    definitionVersion: "1.0.0",
    tenantId: "demo",
    status: "completed",
    currentStep: "approved",
    revision: 1,
    assignedUserId: null,
    sortOrder: null,
    steps: [],
    context: { invoiceNumber: "INV-003", amount: 3200, vendor: "Gamma Inc" },
    createdAt: "2026-01-08T07:00:00.000Z",
    updatedAt: "2026-01-08T15:00:00.000Z",
  },
];

const KANBAN_COLUMNS = [
  { stepId: "draft", label: "Draft", color: "amber" },
  { stepId: "pending-approval", label: "Pending Approval", color: "blue" },
  { stepId: "approved", label: "Approved", color: "green" },
];

function makeKanbanFetch(instances: WorkflowInstance[]) {
  return (input: string): Promise<Response> => {
    const url = new URL(input);
    const segments = url.pathname.split("/").filter(Boolean);
    const found = instances.find((i) => i.workflowId === segments[segments.length - 1]);
    return Promise.resolve(
      found
        ? new Response(JSON.stringify(found), {
            status: 200,
            headers: { "content-type": "application/json" },
          })
        : new Response(JSON.stringify({ error: "not found" }), { status: 404 }),
    );
  };
}

/**
 * Stateful wrapper: real CollectionToolbar search field wired to real client-side
 * search state, driving a real KanbanBoard's `searchQuery` prop (children mode).
 */
export function KanbanBoardWithToolbar() {
  const [query, setQuery] = React.useState("");
  const qc = React.useMemo(
    () => new QueryClient({ defaultOptions: { queries: { retry: false, staleTime: 0 } } }),
    [],
  );
  React.useEffect(() => {
    configureWorkflowClient({
      baseUrl: "http://mock.test/api/platform/workflow",
      fetch: makeKanbanFetch(KANBAN_INSTANCES),
      tenantId: "demo",
    });
  }, []);

  return (
    <QueryClientProvider client={qc}>
      <div className="flex flex-col gap-3 h-full">
        <CollectionToolbar
          searchValue={query}
          onSearchChange={setQuery}
          searchPlaceholder="Search invoices…"
        />
        <div className="flex-1 min-h-0">
          <KanbanBoard
            definitionId="invoice-approval"
            instanceIds={KANBAN_INSTANCES.map((i) => i.workflowId)}
            columns={KANBAN_COLUMNS}
            cardFields={{ titleField: "invoiceNumber", subtitleField: "vendor", badgeField: "amount" }}
            searchQuery={query}
          />
        </div>
      </div>
    </QueryClientProvider>
  );
}

/** Stateful wrapper around the real CollectionToolbar, wired to the story's status tabs. */
function BoardToolbar() {
  const [status, setStatus] = React.useState("all");
  return (
    <CollectionToolbar
      statusOptions={[
        { value: "all", label: "All", count: 128 },
        { value: "open", label: "Open", count: 32 },
        { value: "inProgress", label: "In Progress", count: 28 },
        { value: "review", label: "Review", count: 18 },
        { value: "done", label: "Done", count: 50 },
      ]}
      statusValue={status}
      onStatusChange={setStatus}
    />
  );
}

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof CollectionBoardLayout> = {
  title: "Layer 07 — App Scaffolds/Layouts/CollectionBoardLayout",
  component: CollectionBoardLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**CollectionBoardLayout** — a sticky-header, horizontally-scrolling kanban board for
grouping many-item collections by status (e.g. enquiry/request pipelines).

Props: \`header?: ReactNode\` · \`filters?: ReactNode\` · then either \`columns: CollectionBoardColumn[]\`
or \`children: ReactNode\` (mutually exclusive).

Each \`CollectionBoardColumn\` is \`{ id, title, count?, children }\` — the layout renders
the column header (title + count) and a scrollable card stack per column; card content
and drag/drop interaction are owned by the feature, not this layout.

Alternatively, a fully self-contained board feature (e.g. APP.F04 Kanban, which renders
its own columns/cards/title) can be mounted via \`children\` — the layout then renders only
the outer sticky-header + filters + scroll-container chrome (same structural ReactNode seam
as \`BuilderLayout\`).

**Status:** catalogue entry \`collection / collection-board\` is still \`"gap"\` — this
component exists and has a story, but is not yet wired into \`scaffold-solution.mjs\`'s
\`chooseLayout()\`/\`LAYOUT_COMPONENT\` pipeline, so no manifest can declare it yet.

Use for: many-item collections better browsed by status/stage than as a flat table
(e.g. APP.F01-style entity lists with a small, stable set of pipeline stages).

Cards use the real \`BoardCard\` from \`@dbp/ui\` (sets \`role="listitem"\`); the
filter bar uses the real \`CollectionToolbar\` from \`@dbp/ui\`.
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof CollectionBoardLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/** Standard board — sticky header, four status columns, no filter bar. */
export const Default: Story = {
  name: "Default (4 columns)",
  render: () => (
    <div style={{ height: "640px" }}>
      <CollectionBoardLayout
        columns={boardColumns()}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: "Four status columns, each independently scrollable; page title comes from the shell breadcrumb (N27).",
      },
    },
  },
};

/** With an inline filter/status bar between the header and the board. */
export const WithFilterBar: Story = {
  name: "With filter bar",
  render: () => (
    <div style={{ height: "640px" }}>
      <CollectionBoardLayout
        filters={<BoardToolbar />}
        columns={boardColumns()}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: "filters prop — an inline bar (status tabs, search, sort) rendered above the board columns.",
      },
    },
  },
};

/** Fewer columns — a simple two-stage board (e.g. Draft / Published). */
export const TwoColumns: Story = {
  name: "Two columns (minimal board)",
  render: () => (
    <div style={{ height: "480px" }}>
      <CollectionBoardLayout
        columns={[
          { id: "draft", title: "Draft", count: 6, children: RECORDS.open.slice(0, 2).map(renderRecordCard) },
          { id: "published", title: "Published", count: 12, children: RECORDS.done.map(renderRecordCard) },
        ]}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: "A minimal two-column board — the column count is entirely feature-defined, not fixed by the layout.",
      },
    },
  },
};

/** children mode: a self-contained board feature (APP.F04 Kanban) owns its own columns/cards. */
export const ChildrenMode: Story = {
  name: "children mode (self-contained Kanban feature)",
  render: () => (
    <div style={{ height: "640px" }}>
      <CollectionBoardLayout>
        <KanbanBoardWithToolbar />
      </CollectionBoardLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "`children` is mutually exclusive with `columns` — when the board feature is fully " +
          "self-contained (renders its own columns, cards, and title internally, like APP.F04 " +
          "Kanban), the layout mounts it as opaque children and keeps only the outer sticky-header " +
          "+ scroll-container chrome. The real CollectionToolbar search field is wired to real " +
          "client-side state, which drives the real KanbanBoard's `searchQuery` prop.",
      },
    },
  },
};
