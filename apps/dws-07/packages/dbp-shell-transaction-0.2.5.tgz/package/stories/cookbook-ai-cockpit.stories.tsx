import type { Meta, StoryObj } from "@storybook/react";
import { ConversationalLayout } from "../layouts/conversational.js";
import { thread, input } from "./conversational-layout.stories.js";

/**
 * Cookbook/Operational Intelligence/AI Cockpit (Conversational)
 *
 * A thin, second title on top of `ConversationalLayout`'s existing `Default` story
 * (`conversational-layout.stories.tsx`) — reusing the same `thread`/`input` fixtures
 * rather than re-typing them, so this entry can never drift from the layout story.
 *
 * `ConversationalLayout` itself is catalogued `unwired` (see Reference/Layout
 * Archetypes → canvas): the `canvas-conversational` layout id was retired
 * 2026-07-09 (v9 reconcile) — doc-declared `'conversational'` pages now
 * resolve to `canvas-workspace` — and `ConversationalLayout` remains a real,
 * deliberately-kept reference composition with no manifest-declarable path to
 * it. It is not a hypothetical mockup — the component and this rendering are
 * real — it just isn't wired into `chooseLayout()`. Included in the Cookbook
 * because it is the best available example of what an AI-cockpit / chat-page
 * composition looks like on this stack.
 *
 * **Real solution:** none — do NOT confuse this with Cookbook/Solution Manifests/DWS.01's actual
 * `/copilot` route. That page renders APP.F15 `CopilotPage` (an insight-card
 * grid + composer canvas, a visually different "AI Cockpit" design — see its
 * FEATURE.md). No shipped solution renders through `ConversationalLayout` today.
 *
 * See Reference/Layout Archetypes → canvas (canvas-workspace) for full status;
 * canvas-conversational was retired 2026-07-09.
 */

function AiCockpitPage() {
  return (
    <ConversationalLayout
      thread={thread}
      input={input}
    />
  );
}

const meta: Meta<typeof AiCockpitPage> = {
  title: "Cookbook/Operational Intelligence/AI Cockpit (Conversational)",
  component: AiCockpitPage,
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component:
          "Real `ConversationalLayout` composition — see `Layer 07 — App Scaffolds/Layouts/" +
          "ConversationalLayout` → `Default` for the same story with full annotation.",
      },
    },
  },
};
export default meta;
type Story = StoryObj<typeof AiCockpitPage>;

export const Default: Story = {};
