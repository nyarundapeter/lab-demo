import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ConfigTabsLayout } from "../layouts/config-tabs.js";
import {
  FieldLabel,
  Input,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
  Switch,
} from "@dbp/ui";

// ─── Mock tab content ────────────────────────────────────────────────────────────

function GeneralSettingsForm() {
  return (
    <div className="flex flex-col gap-6">
      <p className="text-sm text-[var(--color-text-muted)]">
        Configure general authentication behaviour for this workspace.
      </p>
      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="session-timeout">Session timeout (minutes)</FieldLabel>
        <Input id="session-timeout" type="number" defaultValue="60" className="max-w-xs" />
      </div>
      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="max-sessions">Max concurrent sessions per user</FieldLabel>
        <Select defaultValue="5">
          <SelectTrigger id="max-sessions" className="max-w-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1</SelectItem>
            <SelectItem value="3">3</SelectItem>
            <SelectItem value="5">5</SelectItem>
            <SelectItem value="10">10</SelectItem>
            <SelectItem value="unlimited">Unlimited</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex items-center justify-between py-3 border-b border-[var(--color-border)]">
        <div className="flex flex-col gap-0.5">
          <span className="text-sm font-semibold text-[var(--color-text)]">
            Require multi-factor authentication
          </span>
          <span className="text-xs text-[var(--color-text-muted)]">
            All users must enrol an MFA device to access the workspace.
          </span>
        </div>
        <Switch defaultChecked aria-label="Require MFA" />
      </div>
      <div className="flex items-center justify-between py-3 border-b border-[var(--color-border)]">
        <div className="flex flex-col gap-0.5">
          <span className="text-sm font-semibold text-[var(--color-text)]">
            Enforce password complexity rules
          </span>
          <span className="text-xs text-[var(--color-text-muted)]">
            Minimum 12 characters, uppercase, number, and special character required.
          </span>
        </div>
        <Switch defaultChecked aria-label="Enforce password complexity" />
      </div>
    </div>
  );
}

function OAuthSettingsForm() {
  return (
    <div className="flex flex-col gap-6">
      <p className="text-sm text-[var(--color-text-muted)]">
        Configure OAuth 2.0 clients for third-party integrations and API access.
      </p>
      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="oauth-client-id">Client ID</FieldLabel>
        <Input id="oauth-client-id" type="text" placeholder="e.g. dws01-api-client" className="max-w-md" />
      </div>
      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="oauth-secret">Client secret</FieldLabel>
        <Input id="oauth-secret" type="password" placeholder="••••••••••••••••" className="max-w-md" />
      </div>
      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="oauth-redirect">Allowed redirect URI</FieldLabel>
        <Input
          id="oauth-redirect"
          type="url"
          defaultValue="https://dws01.digitalqatalyst.com/auth/callback"
          className="max-w-md"
        />
      </div>
    </div>
  );
}

function SamlSettingsForm() {
  return (
    <div className="flex flex-col gap-6">
      <p className="text-sm text-[var(--color-text-muted)]">
        Upload your identity provider metadata to enable SAML 2.0 single sign-on.
      </p>
      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="saml-entity-id">SP Entity ID</FieldLabel>
        <Input
          id="saml-entity-id"
          type="text"
          defaultValue="https://dws01.digitalqatalyst.com/saml/metadata"
          className="max-w-md"
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <FieldLabel htmlFor="saml-idp-url">IdP metadata URL</FieldLabel>
        <Input id="saml-idp-url" type="url" placeholder="https://idp.example.com/saml/metadata" className="max-w-md" />
      </div>
      <div className="flex items-center justify-between py-3 border-b border-[var(--color-border)]">
        <div className="flex flex-col gap-0.5">
          <span className="text-sm font-semibold text-[var(--color-text)]">
            Sign authentication requests
          </span>
          <span className="text-xs text-[var(--color-text-muted)]">
            SAML AuthnRequests will be signed with the SP private key.
          </span>
        </div>
        <Switch aria-label="Sign SAML requests" />
      </div>
    </div>
  );
}

const AUTH_TABS = [
  { id: "general", label: "General", content: <GeneralSettingsForm /> },
  { id: "oauth", label: "OAuth 2.0", content: <OAuthSettingsForm /> },
  { id: "saml", label: "SAML 2.0", content: <SamlSettingsForm /> },
];

const AUTH_TABS_WITH_SAVE = [
  { id: "general", label: "General", content: <GeneralSettingsForm />, formId: "auth-general-form", saveLabel: "Save changes" },
  { id: "oauth", label: "OAuth 2.0", content: <OAuthSettingsForm />, formId: "auth-oauth-form" },
  { id: "saml", label: "SAML 2.0", content: <SamlSettingsForm />, formId: "auth-saml-form" },
];

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof ConfigTabsLayout> = {
  title: "Layer 07 — App Scaffolds/Layouts/ConfigTabsLayout",
  component: ConfigTabsLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**ConfigTabsLayout** — a header-slot layout for settings pages with multiple sections.

Props: \`header?: ReactNode\` · \`tabs: ConfigTab[]\` · \`defaultTab?: string\`

The \`header\` slot is deprecated (shell v3, N27) — the shell breadcrumb carries the page
title. The layout renders an underline tab row
(using \`@dbp/ui\` \`Tabs\` primitives) and a body-only content area constrained to
\`max-w-[var(--settings-form-max-w,720px)]\`.

The layout-owned Save button (state-dependent: targets the ACTIVE tab's \`formId\`) is placed
at the **right end of the tab-strip row** — it submits the active tab's \`<form id>\` via the
HTML \`form\` attribute with no JS coupling.

**Key contract rules:**
- Page title comes from the shell breadcrumb (N27) — features/tab content must be body-only.
- Tab bar uses \`@dbp/ui\` \`TabsList\`/\`TabsTrigger\` — no raw \`<button>\`, no inline hex.
- Content area has no inner card wrapper — the shell surface is the content surface.
- Save button is layout-owned (not page-owned) because it is state-dependent (tracks active tab).

Use for: APP.F17 Admin Configuration, APP.F15 Settings hub, any settings page with distinct sub-sections.
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof ConfigTabsLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/**
 * Authentication Settings — the canonical three-tab pattern (General | OAuth 2.0 | SAML 2.0).
 * Save button in tab-strip row targets the active tab's form.
 */
export const AuthenticationSettings: Story = {
  name: "Authentication Settings (General tab, with Save)",
  render: () => (
    <div style={{ height: "640px" }}>
      <ConfigTabsLayout
        tabs={AUTH_TABS_WITH_SAVE}
        defaultTab="general"
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Auth settings page with General tab active. Page title comes from the shell breadcrumb (N27). " +
          "The layout-owned Save button sits at the right end of the tab-strip row and targets the " +
          "active tab's form id. Switch to OAuth / SAML tabs to see the save button update its target.",
      },
    },
  },
};

export const OAuthTabActive: Story = {
  name: "Authentication Settings (OAuth 2.0 tab)",
  render: () => (
    <div style={{ height: "640px" }}>
      <ConfigTabsLayout
        tabs={AUTH_TABS_WITH_SAVE}
        defaultTab="oauth"
      />
    </div>
  ),
};

export const SamlTabActive: Story = {
  name: "Authentication Settings (SAML 2.0 tab)",
  render: () => (
    <div style={{ height: "640px" }}>
      <ConfigTabsLayout
        tabs={AUTH_TABS_WITH_SAVE}
        defaultTab="saml"
      />
    </div>
  ),
};

/**
 * No save — tabs without any formId. Tab bar only, no save button.
 */
export const NoSaveAction: Story = {
  name: "Authentication Settings (no save action)",
  render: () => (
    <div style={{ height: "640px" }}>
      <ConfigTabsLayout
        tabs={AUTH_TABS}
        defaultTab="general"
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "When no tab has a formId, no Save button renders.",
      },
    },
  },
};

/**
 * Minimal variant — two tabs, no breadcrumb. Shows the layout without breadcrumb.
 */
export const MinimalTwoTabs: Story = {
  name: "Minimal — two tabs, no breadcrumb",
  render: () => (
    <div style={{ height: "480px" }}>
      <ConfigTabsLayout
        tabs={[
          {
            id: "email",
            label: "Email",
            formId: "notif-email-form",
            content: (
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <FieldLabel htmlFor="notif-email">Sender address</FieldLabel>
                  <Input id="notif-email" type="email" defaultValue="noreply@example.com" className="max-w-sm" />
                </div>
              </div>
            ),
          },
          {
            id: "sms",
            label: "SMS",
            formId: "notif-sms-form",
            content: (
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <FieldLabel htmlFor="notif-sms">SMS provider</FieldLabel>
                  <Select defaultValue="twilio">
                    <SelectTrigger id="notif-sms" className="max-w-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="twilio">Twilio</SelectItem>
                      <SelectItem value="vonage">Vonage</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ),
          },
        ]}
      />
    </div>
  ),
};

/**
 * No header slot — layout without a page-supplied header.
 */
export const NoHeader: Story = {
  name: "No header slot",
  render: () => (
    <div style={{ height: "400px" }}>
      <ConfigTabsLayout
        tabs={[
          { id: "a", label: "Tab A", content: <p className="text-sm">Content for Tab A</p> },
          { id: "b", label: "Tab B", content: <p className="text-sm">Content for Tab B</p> },
        ]}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: "When no header is supplied, the layout omits the sticky header area entirely.",
      },
    },
  },
};
