import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { TEMPLATE_CATALOGUE, type TemplateCatalogueEntry } from "@dbp/contracts";

/**
 * The Template Catalogue (Pick 3 Move 1 — "ship the reusable vocabulary").
 *
 * Answers a builder's first question faster than writing JSX: "which template
 * do I instantiate, and what do I configure on it?" Rendered directly from
 * TEMPLATE_CATALOGUE (@dbp/contracts) — this page can never drift from the
 * data, and the data itself is ratcheted against real components/stories by
 * template-catalogue.test.ts.
 */

const STATUS_LABEL: Record<TemplateCatalogueEntry["status"], string> = {
  implemented: "✅ Implemented",
  bespoke: "🧩 Bespoke schema",
  unwired: "⚠️ Unwired",
  gap: "🚧 Gap",
};

const STATUS_COLOR: Record<TemplateCatalogueEntry["status"], string> = {
  implemented: "#0a7d34",
  bespoke: "#1d4ed8",
  unwired: "#b45309",
  gap: "#991b1b",
};

function groupByArchetype(entries: TemplateCatalogueEntry[]) {
  const groups = new Map<string, TemplateCatalogueEntry[]>();
  for (const e of entries) {
    if (!groups.has(e.archetype)) groups.set(e.archetype, []);
    groups.get(e.archetype)!.push(e);
  }
  return groups;
}

function CatalogueTable() {
  const groups = groupByArchetype(TEMPLATE_CATALOGUE);
  return (
    <div style={{ fontFamily: "system-ui, sans-serif", padding: 24, maxWidth: 1100 }}>
      <h1 style={{ fontSize: 20, marginBottom: 4 }}>Template Catalogue</h1>
      <p style={{ color: "#666", fontSize: 13, marginBottom: 24 }}>
        Shell &gt; Archetype &gt; Layout. Every declarable layout, its component, its
        Storybook story, and where its config comes from.
      </p>
      {[...groups.entries()].map(([archetype, entries]) => (
        <div key={archetype} style={{ marginBottom: 28 }}>
          <h2 style={{ fontSize: 15, fontFamily: "monospace", marginBottom: 8, color: "#111" }}>
            {archetype}
          </h2>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ textAlign: "left", borderBottom: "1px solid #ddd" }}>
                <th style={{ padding: "6px 8px" }}>Layout</th>
                <th style={{ padding: "6px 8px" }}>Status</th>
                <th style={{ padding: "6px 8px" }}>Component</th>
                <th style={{ padding: "6px 8px" }}>Story</th>
                <th style={{ padding: "6px 8px" }}>Config source</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((e) => (
                <tr key={e.layout} style={{ borderBottom: "1px solid #f0f0f0" }}>
                  <td style={{ padding: "6px 8px", fontFamily: "monospace" }}>{e.layout}</td>
                  <td style={{ padding: "6px 8px", color: STATUS_COLOR[e.status] }}>
                    {STATUS_LABEL[e.status]}
                  </td>
                  <td style={{ padding: "6px 8px" }}>{e.component ?? "—"}</td>
                  <td style={{ padding: "6px 8px" }}>{e.storybookTitle ?? "—"}</td>
                  <td style={{ padding: "6px 8px", color: "#555" }}>{e.configSource}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}

const meta: Meta<typeof CatalogueTable> = {
  title: "Layer 07 — App Scaffolds/Template Catalogue",
  component: CatalogueTable,
  parameters: { layout: "fullscreen" },
};
export default meta;
type Story = StoryObj<typeof CatalogueTable>;

export const Default: Story = {};
