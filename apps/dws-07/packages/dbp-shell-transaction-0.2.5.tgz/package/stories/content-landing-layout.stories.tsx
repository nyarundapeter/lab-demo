import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ContentLandingLayout } from "../layouts/content-landing.js";

// ─── Mock helpers ────────────────────────────────────────────────────────────────

/** A greeting/hero card — typical landing page top section. */
function GreetingCard({ name }: { name: string }) {
  return (
    <div
      style={{
        padding: "28px 32px",
        background: "color-mix(in srgb, var(--color-primary) 6%, var(--color-surface))",
        border: "1px solid color-mix(in srgb, var(--color-primary) 20%, transparent)",
        borderRadius: "var(--radius)",
        display: "flex",
        flexDirection: "column",
        gap: "6px",
      }}
    >
      <p
        style={{
          margin: 0,
          fontSize: "11px",
          fontWeight: 700,
          textTransform: "uppercase",
          letterSpacing: "0.1em",
          color: "var(--color-primary)",
        }}
      >
        Welcome back
      </p>
      <h1 style={{ margin: 0, fontSize: "22px", fontWeight: 700, color: "var(--color-text)" }}>
        {name}
      </h1>
      <p style={{ margin: 0, fontSize: "14px", color: "color-mix(in srgb, var(--color-text) 65%, transparent)" }}>
        Here's a summary of your workspace activity and pending items.
      </p>
    </div>
  );
}

/** A generic section card with a title and mock content rows. */
function SectionCard({
  title,
  itemCount = 3,
  accent = false,
}: {
  title: string;
  itemCount?: number;
  accent?: boolean;
}) {
  return (
    <div
      style={{
        padding: "20px 24px",
        background: "var(--color-surface)",
        border: "1px solid var(--color-border)",
        borderRadius: "var(--radius)",
        display: "flex",
        flexDirection: "column",
        gap: "12px",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2 style={{ margin: 0, fontSize: "15px", fontWeight: 600, color: "var(--color-text)" }}>{title}</h2>
        <a
          href="#"
          style={{
            fontSize: "12px",
            color: accent ? "var(--color-primary)" : "color-mix(in srgb, var(--color-text) 55%, transparent)",
            textDecoration: "none",
          }}
        >
          View all
        </a>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
        {Array.from({ length: itemCount }, (_, i) => (
          <div
            key={i}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "8px 10px",
              background: "color-mix(in srgb, var(--color-border) 20%, transparent)",
              borderRadius: "calc(var(--radius) / 2)",
              fontSize: "13px",
              color: "var(--color-text)",
            }}
          >
            <span>Item {i + 1} — {title.replace(/s$/, "")}</span>
            <span
              style={{
                padding: "2px 8px",
                borderRadius: "9999px",
                fontSize: "11px",
                fontWeight: 600,
                background: i === 0
                  ? "color-mix(in srgb, var(--color-primary) 12%, transparent)"
                  : "color-mix(in srgb, var(--color-border) 60%, transparent)",
                color: i === 0 ? "var(--color-primary)" : "color-mix(in srgb, var(--color-text) 55%, transparent)",
              }}
            >
              {i === 0 ? "Action needed" : "In progress"}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/** A two-column grid of section cards. */
function TwoColSections() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
      <SectionCard title="Pending Approvals" itemCount={3} accent />
      <SectionCard title="Recent Requests" itemCount={3} />
    </div>
  );
}

/** A full-width section card. */
function WideSection() {
  return <SectionCard title="Recent Activity" itemCount={4} />;
}

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof ContentLandingLayout> = {
  title: "Layer 07 — App Scaffolds/Layouts/ContentLandingLayout",
  component: ContentLandingLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**ContentLandingLayout** — a transparent passthrough layout for home / landing pages.

Props: \`children: ReactNode\` only.

No sticky header, no sidebar. Pure scrollable content constrained to
\`max-w-[1400px] mx-auto px-6 py-8\` with \`space-y-8\` between sections. The solution's
shell (TransactionShell) provides the chrome; this layout owns only the content region.

Use for: APP.F08 Dashboard / Home landing, DXP public pages, welcome/overview pages that
should not have a PageHeader eyebrow (the greeting card IS the hero).
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof ContentLandingLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/**
 * Default — greeting card + two section cards. Typical home page composition:
 * hero greeting at top, then a row of summary panels below.
 */
export const Default: Story = {
  name: "Default (greeting + sections)",
  render: () => (
    <div style={{ height: "680px" }}>
      <ContentLandingLayout>
        <GreetingCard name="Alpha Finance Approver" />
        <TwoColSections />
        <WideSection />
      </ContentLandingLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Greeting hero card + two-column summary sections + a full-width activity feed. " +
          "ContentLandingLayout simply wraps children in a max-width constrained, vertically spaced container — " +
          "the solution controls all structural choices above.",
      },
    },
  },
};

/**
 * Minimal — a single full-width greeting card. Verifies the layout renders
 * cleanly with a single child and no grid.
 */
export const Minimal: Story = {
  name: "Minimal (single child)",
  render: () => (
    <div style={{ height: "400px" }}>
      <ContentLandingLayout>
        <GreetingCard name="Platform Admin" />
      </ContentLandingLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Single child — confirms the transparent passthrough renders without adding unwanted structure. " +
          "Useful baseline for solution teams building out their home page incrementally.",
      },
    },
  },
};
