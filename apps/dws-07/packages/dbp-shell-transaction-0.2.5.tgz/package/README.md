# @dbp/shell-transaction

registryId: `SH.02`

Transaction Workspace Shell — the fixed three-column app shell (collapsible
sidebar, main content, optional context panel) used for Stage 2 "Transact"
pages. Renders the top bar, sidebar, footer, and slot-based layout described
in `SHELL.md`; solutions mount features (entity lists, forms, kanban,
approval surfaces) into the `sidebar` / `header` / `main` / `context` slots
and wire `PS.AUTH`, `PS.WORKFLOW`, `PS.DATA`, `PS.NOTIF` at solution time. The
shell itself never reads auth state or fetches data — see `SHELL.md` for the
full slot/dimension/responsive/PS-wiring contract.

**Tier:** shell

## Exports
| Export | Path |
|---|---|
| `.` | `./index.tsx` |
| `./slots` | `./slots.ts` |
| `./nav` | `./nav.tsx` |
| `./layouts` | `./layouts/index.ts` |
| `./features/admin-config/form-builder` | `./features/admin-config/form-builder.tsx` |

No `publishConfig.exports` override — the package publishes source paths as-is (`publishConfig` only sets `registry`/`access`).

## Config schema
N/A — no config schema in this package. Nav validation (`NavSection`/`NavItem`) is Zod-typed via `@dbp/contracts`, consumed through `nav-merge.ts`.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` maps `SH.02`/`SH.WORKSPACE` to `packageName: "@dbp/shell-transaction"` and every generated solution app imports `TransactionShell` from `@dbp/shell-transaction` directly (`import TransactionShell from "@dbp/shell-transaction"`), plus `@dbp/shell-transaction/layouts` (`BuilderLayout`, `CanvasLayout`) across multiple generated pages in `apps/*`.

## Shipping
Within the monorepo this package resolves via pnpm workspace linking (no tarball needed). For standalone/client delivery it ships as a packed tarball, committed into the standalone's `packages/` dir and resolved via `file:` paths plus a `.pnpmfile.cjs` hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
