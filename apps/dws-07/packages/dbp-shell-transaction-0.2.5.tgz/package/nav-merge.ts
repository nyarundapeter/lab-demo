import type { NavSection } from '@dbp/contracts'

// The six canonical Feature-Area ids (the standard navigation model). A solution
// SELECTS the relevant subset and renames labels for its context, but section ids
// must be drawn from this set so layout inference + nav merge stay stable across
// solutions. See docs/01-Architecture/Standard-Navigation-and-Layout-Map.md.
const KNOWN_SECTION_IDS = [
  'orientation',
  'marketplace',
  'workspace',
  'service-operations',
  'operational-intelligence',
  'platform-management',
] as const

const KNOWN_SECTION_ID_SET = new Set<string>(KNOWN_SECTION_IDS)

// Retired pre-rename ids. Never legal, even if a solution declares them as a
// "custom" section id — they must not be revived under the extensibility
// escape hatch below.
const RETIRED_SECTION_IDS = new Set<string>(['platform-admin', 'analytics'])

/**
 * Validate a solution's nav sections against the standard 6-id model, plus any
 * builder-declared extra ids (solution-manifest `customNavSections`).
 *
 * Presence is OPTIONAL — a solution may declare any subset of the six sections.
 * Every declared section id MUST be one of the known ids OR one of `allowedExtraIds`
 * (when provided); an unrecognised id is a hard error (it silently emits clean YAML
 * yet 500s at runtime otherwise). Retired ids are always rejected, even when passed
 * in `allowedExtraIds`.
 */
export function mergeNavConfig(sections: NavSection[], allowedExtraIds?: string[]): NavSection[] {
  const extraIdSet = allowedExtraIds && allowedExtraIds.length > 0 ? new Set(allowedExtraIds) : undefined
  for (const section of sections) {
    if (RETIRED_SECTION_IDS.has(section.id)) {
      throw new Error(
        `Nav config uses retired section id "${section.id}". Retired ids are never revived, ` +
        `even via a declared custom nav section. Check your nav-config.ts.`
      )
    }
    if (KNOWN_SECTION_ID_SET.has(section.id)) continue
    if (extraIdSet?.has(section.id)) continue
    throw new Error(
      `Nav config has an unknown section id "${section.id}". ` +
      `Section ids must be one of the standard Feature-Area ids ` +
      `(${KNOWN_SECTION_IDS.join(', ')}), or a custom id declared in the solution manifest's ` +
      `customNavSections list. Check your nav-config.ts.`
    )
  }
  return sections
}
