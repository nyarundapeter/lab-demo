# @dbp/ps-org

An organization/group/membership platform service with CASL-based contextual authorization. The client exposes fetchers for orgs, org groups, group members, and a user's orgs, plus an `OrgContextProvider`/`useOrgContext` for tracking the active org in a session or layout, `useContextualAbility`/`useOrgCan`/`OrgGate` for org-scoped CASL ability checks (built from `@dbp/ps-rbac` rule payloads via `AbilityBuilder`/`createMongoAbility`), and admin hooks (`useOrgs`, `useOrgGroups`, `useUserOrgs`).

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `client/index.ts` (dist: `dist/client/index.js`) |
| `./server` | `server/index.ts` (dist: `dist/server/index.js`) |

`publishConfig.exports` points both subpaths at the built `dist/` output (with `.d.ts` types) instead of the `.ts` sources used in the workspace.

## Config schema
N/A — no standalone Zod config-schema file for client config; response payloads (`OrgListResponseSchema`, `OrgGroupListResponseSchema`, `MemberListResponseSchema`, `UserOrgsResponseSchema`, `OrgAbilityResponseSchema`) are defined and parsed in `client/types.ts`.

## Consumed by
Generator emit — grepping `scripts/scaffold-solution.mjs` did not find a dedicated `PS.ORG` route/client-config wiring block analogous to `PS.DATA`/`PS.EVENTS`/`PS.NOTIF`; usage across `apps/` (e.g. `providers.tsx`, `.ai/context.md` references) could not be confirmed as generator-emitted vs. manually wired in a couple of greps. Marking as TBD.

## Shipping
Inside this monorepo, apps resolve `@dbp/ps-org` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed `.tgz` tarball, resolved through `.pnpmfile.cjs` rewriting the `@dbp/ps-org` dependency to `file:packages/dbp-ps-org-<version>.tgz`. See `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
