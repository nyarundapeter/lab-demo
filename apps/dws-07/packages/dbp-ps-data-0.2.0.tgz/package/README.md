# @dbp/ps-data

A generic entity CRUD platform service. Solutions register Zod-schema-defined entity types (`defineEntity`/`registerEntityType`) and get REST-style create/read/update/delete/list operations plus a client SDK, TanStack Query hooks (`useEntity`, `useEntityList`), and a pluggable storage backend (see `storage-selection.ts`/`init-database.ts`) without writing their own data-access layer.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `client/index.ts` (dist: `dist/client/index.js`) |
| `./server` | `server/index.ts` (dist: `dist/server/index.js`) |
| `./server/init-database` | `server/init-database.ts` (dist: `dist/server/init-database.js`) |

`publishConfig.exports` points the same three subpaths at the built `dist/` output (with `.d.ts` types) instead of the `.ts` sources used in the workspace.

## Config schema
N/A — no standalone Zod config-schema file; entity shapes are defined per solution via `defineEntity` (`client/sdk.ts`) using `ZodEntitySchema`, and request/response contracts are generated into `contract.yaml` via `scripts/generate-contract.ts`.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` wires `PS.DATA` into every scaffolded solution's `/api/platform/data/[[...path]]` route, calls `configureDataClient` from `@dbp/ps-data/client`, and imports `dispatch`/`getDataService` from `@dbp/ps-data/server` (the app's sole `server` import site, per the route-chunk-bootstrap pattern) plus `initializePlatformDatabase` from `@dbp/ps-data/server/init-database`. Also imported directly for typed SDK re-exports in solution `lib/data-client.ts` files (e.g. `apps/dws-01/solution/lib/data-client.ts`).

## Shipping
Inside this monorepo, apps resolve `@dbp/ps-data` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed `.tgz` tarball, resolved through `.pnpmfile.cjs` rewriting the `@dbp/ps-data` dependency to `file:packages/dbp-ps-data-<version>.tgz`. See `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
