# @dbp/scaffold-tools

Not a library of exported utilities — this package has no `exports` field and no `src/index.ts`. It is a Vitest **conformance-gate suite** (`src/__tests__/*.test.ts`, 20+ test files) that runs against the generator (`scripts/scaffold-solution.mjs`) output and the built apps: archetype blocks, page-frame contract, solution manifest, theme policy, UI conformance, workflow interactability/binding/registration, admin archetypes, i18n baseline, interaction-state, Storybook taxonomy, the Factory Operations Map, and more. These are the tests referenced by `CLAUDE.md`'s "mechanically enforced" rules (e.g. the Factory Operations Map, generator-ownership contract).

**Tier:** shared

## Exports
N/A — no `exports` field in `package.json`; this package is not imported by other code, only run via `pnpm test` / `pnpm typecheck`.

## Config schema
N/A — no config schema in this package (it validates other packages' output, it doesn't define a schema of its own). It depends on `@dbp/contracts` to check emitted output against those schemas.

## Consumed by
Not imported anywhere — TBD confirmed via grep of `scripts/scaffold-solution.mjs` and `apps/`, no `@dbp/scaffold-tools` import found. It is a standalone CI/dev-time gate run directly (`pnpm --filter @dbp/scaffold-tools test`), not a runtime dependency of any app or the generator itself.

## Shipping
Workspace-only in practice — it is devDependency-shaped tooling (Vitest conformance tests), not consumed by generated solutions, so it is not expected to appear in standalone `packages/*.tgz` bundles. See `docs/08-contributing/package-distribution.md` for the general tarball/registry model that applies to `@dbp/*` packages that are consumed.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
