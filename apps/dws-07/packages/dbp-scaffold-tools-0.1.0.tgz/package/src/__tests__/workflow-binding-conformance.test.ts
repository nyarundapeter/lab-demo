import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parse as parseYaml } from "yaml";

/**
 * PS-WORKFLOW-UI §5b ratchet: for every route-group-era app under apps/ whose
 * source manifest (docs/solutions/<ID>-SOLUTION.md, resolved via the app's
 * generated solution/_arch/SOLUTION.md `solution:` id) declares an
 * entities[].workflows[] binding AND the app consumes PS.WORKFLOW, every page
 * under solution/pages/** (or app/**) rendering that entity via LveWorkspace
 * must reference @dbp/organisms/workflow-binding with BOTH
 * RecordWorkflowStepper and RecordProgressHistory.
 *
 * Static text analysis (comments stripped) — no generator invocation, no build.
 *
 * Excluded apps (documented, not silently skipped):
 *   - dws-04: pre-route-group era per repo convention (matches the existing
 *     SP-5 workflow-registration-conformance ratchet's exclusion set).
 *   - dws-03: was excluded on the same basis until it adopted the ADR-0039
 *     relational-data-model pilot and gained real entities[].workflows
 *     bindings — now included and checked.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const APPS_DIR = path.join(REPO_ROOT, "apps");
const SOLUTIONS_DIR = path.join(REPO_ROOT, "docs/10-Solutions");

const EXCLUDED_APPS = new Set(["dws-04", "__boundary-fixtures__", "hello"]);

function stripComments(src: string): string {
  return src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, "");
}

/** Extracts the YAML frontmatter block (between the first two `---` lines). */
function readFrontmatter(mdPath: string): Record<string, unknown> | null {
  if (!fs.existsSync(mdPath)) return null;
  const src = fs.readFileSync(mdPath, "utf8");
  const lines = src.split(/\r?\n/);
  if (lines[0]?.trim() !== "---") return null;
  const endIdx = lines.findIndex((l, i) => i > 0 && l.trim() === "---");
  if (endIdx === -1) return null;
  const yamlSrc = lines.slice(1, endIdx).join("\n");
  try {
    return parseYaml(yamlSrc) as Record<string, unknown>;
  } catch {
    return null;
  }
}

type EntityBinding = { type: string; workflows: string[] };

/** Entities declaring a non-empty workflows[] binding, from a manifest's entities[] block. */
function boundEntities(manifest: Record<string, unknown> | null): EntityBinding[] {
  const entities = Array.isArray(manifest?.entities) ? (manifest!.entities as unknown[]) : [];
  const out: EntityBinding[] = [];
  for (const e of entities) {
    if (!e || typeof e !== "object") continue;
    const rec = e as Record<string, unknown>;
    const workflows = Array.isArray(rec.workflows) ? (rec.workflows as unknown[]).filter((w) => typeof w === "string") as string[] : [];
    if (workflows.length > 0 && typeof rec.type === "string") {
      out.push({ type: rec.type, workflows });
    }
  }
  return out;
}

function consumesWorkflow(manifest: Record<string, unknown> | null): boolean {
  const consumed = Array.isArray(manifest?.consumes_platform_services)
    ? (manifest!.consumes_platform_services as unknown[])
    : [];
  return consumed.includes("PS.WORKFLOW");
}

/** Collects all .tsx source files under solution/pages/** and app/** for a given app. */
function collectPageSources(appDir: string): { file: string; src: string }[] {
  const out: { file: string; src: string }[] = [];
  const roots = [path.join(appDir, "solution/pages"), path.join(appDir, "app")];
  for (const root of roots) {
    if (!fs.existsSync(root)) continue;
    const stack = [root];
    while (stack.length) {
      const dir = stack.pop()!;
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) stack.push(full);
        else if (entry.isFile() && (entry.name.endsWith(".tsx") || entry.name.endsWith(".ts"))) {
          out.push({ file: full, src: stripComments(fs.readFileSync(full, "utf8")) });
        }
      }
    }
  }
  return out;
}

/**
 * True iff `src` renders the given entity via LveWorkspace (Pattern A) AND
 * wires @dbp/organisms/workflow-binding with both RecordWorkflowStepper and
 * RecordProgressHistory (stepper-without-history does NOT count).
 */
function hasFullLveWorkflowBinding(src: string, entityType: string): boolean {
  const rendersEntity =
    src.includes("organisms/lve-workspace") && src.includes(entityType);
  if (!rendersEntity) return false;
  const importsBinding = /from\s+["']@dbp\/organisms\/workflow-binding["']/.test(src);
  const hasStepper = /\bRecordWorkflowStepper\b/.test(src);
  const hasHistory = /\bRecordProgressHistory\b/.test(src);
  return importsBinding && hasStepper && hasHistory;
}

/**
 * True iff `src` renders the given entity via EntityList (Pattern B, §5b) AND
 * wires @dbp/organisms/workflow-binding's RecordWorkflowStepper into the
 * drawer via `drawerExtras` (stepper-without-import does NOT count).
 */
function hasFullEntityListWorkflowBinding(src: string, entityType: string): boolean {
  const rendersEntity =
    /from\s+["']@dbp\/organisms\/entity-list["']/.test(src) && src.includes(entityType);
  if (!rendersEntity) return false;
  const importsBinding = /from\s+["']@dbp\/organisms\/workflow-binding["']/.test(src);
  const hasStepper = /\bRecordWorkflowStepper\b/.test(src);
  const hasDrawerExtras = /\bdrawerExtras\s*=/.test(src) || /\bdrawerExtras\s*:/.test(src);
  return importsBinding && hasStepper && hasDrawerExtras;
}

/** True iff `src` demonstrates either Pattern A or Pattern B binding for `entityType`. */
function hasFullWorkflowBinding(src: string, entityType: string): boolean {
  return (
    hasFullLveWorkflowBinding(src, entityType) ||
    hasFullEntityListWorkflowBinding(src, entityType)
  );
}

const apps = fs.existsSync(APPS_DIR)
  ? fs
      .readdirSync(APPS_DIR, { withFileTypes: true })
      .filter((e) => e.isDirectory() && !EXCLUDED_APPS.has(e.name))
      .map((e) => e.name)
  : [];

describe("PS-WORKFLOW-UI §5b: workflow-bound stepper conformance ratchet", () => {
  for (const app of apps) {
    const appDir = path.join(APPS_DIR, app);
    const archManifestPath = path.join(appDir, "solution/_arch/SOLUTION.md");
    const archManifest = readFrontmatter(archManifestPath);
    const solutionId = typeof archManifest?.solution === "string" ? (archManifest.solution as string) : null;

    // The app's own generator-owned _arch/SOLUTION.md does not carry entities[]
    // in every case (e.g. hand-wired reference apps) — the source-of-truth
    // manifest under docs/solutions/<ID>-SOLUTION.md is authoritative for
    // entities[].workflows[] bindings.
    const sourceManifestPath = solutionId ? path.join(SOLUTIONS_DIR, `${solutionId}-SOLUTION.md`) : null;
    const sourceManifest = sourceManifestPath ? readFrontmatter(sourceManifestPath) : null;

    const bindings = boundEntities(sourceManifest);
    const consumesWf = consumesWorkflow(sourceManifest) || consumesWorkflow(archManifest);

    if (bindings.length === 0 || !consumesWf) continue; // nothing bound — trivially passes

    it(`apps/${app}: every workflow-bound entity (${bindings.map((b) => b.type).join(", ")}) has the stepper wiring on its LVE surface(s)`, () => {
      const pageSources = collectPageSources(appDir);
      const missing: string[] = [];
      for (const binding of bindings) {
        const wired = pageSources.some(({ src }) => hasFullWorkflowBinding(src, binding.type));
        if (!wired) missing.push(binding.type);
      }
      expect(
        missing,
        `apps/${app}: entities [${missing.join(", ")}] declare workflows[] bindings and PS.WORKFLOW ` +
          `is consumed, but no page under solution/pages/** or app/** renders them via LveWorkspace ` +
          `wired to @dbp/organisms/workflow-binding (RecordWorkflowStepper + RecordProgressHistory).`,
      ).toEqual([]);
    });
  }

  // ── Self-tests: guard the matcher against false passes/failures ───────────
  describe("matcher self-tests (negative fixtures)", () => {
    const fullyWired = `
      import LveWorkspace from "@dbp/organisms/lve-workspace";
      import { RecordProgressHistory, RecordWorkflowActions, RecordWorkflowStepper } from "@dbp/organisms/workflow-binding";
      export default function Page() {
        return <LveWorkspace entityType="purchase-request" detailExtras={{
          stepper: (r) => <RecordWorkflowStepper recordId={r.id} config={{}} />,
          extraTab: { label: "Progress History", content: (r) => <RecordProgressHistory recordId={r.id} config={{}} /> },
        }} />;
      }`;

    it("accepts a fully-wired page (stepper + history + import)", () => {
      expect(hasFullWorkflowBinding(stripComments(fullyWired), "purchase-request")).toBe(true);
    });

    it("rejects when the binding is only mentioned in a comment", () => {
      const src = stripComments(`
        import LveWorkspace from "@dbp/organisms/lve-workspace";
        // import { RecordWorkflowStepper, RecordProgressHistory } from "@dbp/organisms/workflow-binding";
        /* <RecordWorkflowStepper /> */
        export default function Page() {
          return <LveWorkspace entityType="purchase-request" />;
        }`);
      expect(hasFullWorkflowBinding(src, "purchase-request")).toBe(false);
    });

    it("rejects stepper-without-history (Progress History tab missing)", () => {
      const src = stripComments(`
        import LveWorkspace from "@dbp/organisms/lve-workspace";
        import { RecordWorkflowStepper } from "@dbp/organisms/workflow-binding";
        export default function Page() {
          return <LveWorkspace entityType="purchase-request" detailExtras={{
            stepper: (r) => <RecordWorkflowStepper recordId={r.id} config={{}} />,
          }} />;
        }`);
      expect(hasFullWorkflowBinding(src, "purchase-request")).toBe(false);
    });

    it("rejects a page that doesn't render the entity via LveWorkspace at all", () => {
      const src = stripComments(`
        import { RecordWorkflowStepper, RecordProgressHistory } from "@dbp/organisms/workflow-binding";
        export default function Page() {
          return <div>no LVE here</div>;
        }`);
      expect(hasFullWorkflowBinding(src, "purchase-request")).toBe(false);
    });

    // ── Pattern B: EntityList drawerExtras seam (ADR-0038 §5b) ────────────────

    const entityListWired = `
      import EntityList from "@dbp/organisms/entity-list";
      import { RecordWorkflowStepper } from "@dbp/organisms/workflow-binding";
      export default function Page() {
        return <EntityList entityType="purchase-request" detailDrawer drawerExtras={{
          stepper: (r) => <RecordWorkflowStepper recordId={r.id} config={{}} />,
        }} />;
      }`;

    it("accepts an EntityList page wired via drawerExtras (Pattern B)", () => {
      expect(hasFullWorkflowBinding(stripComments(entityListWired), "purchase-request")).toBe(true);
    });

    it("rejects an EntityList page rendering the entity without drawerExtras", () => {
      const src = stripComments(`
        import EntityList from "@dbp/organisms/entity-list";
        export default function Page() {
          return <EntityList entityType="purchase-request" detailDrawer />;
        }`);
      expect(hasFullWorkflowBinding(src, "purchase-request")).toBe(false);
    });

    it("rejects an EntityList page with drawerExtras but no RecordWorkflowStepper import", () => {
      const src = stripComments(`
        import EntityList from "@dbp/organisms/entity-list";
        export default function Page() {
          return <EntityList entityType="purchase-request" detailDrawer drawerExtras={{
            stepper: () => <div>fake</div>,
          }} />;
        }`);
      expect(hasFullWorkflowBinding(src, "purchase-request")).toBe(false);
    });
  });
});
