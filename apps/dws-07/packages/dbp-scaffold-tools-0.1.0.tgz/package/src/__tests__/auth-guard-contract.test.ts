import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * (authenticated)/layout.tsx auth-guard contract.
 *
 * useAuth() (packages/stack/platform-services/auth/client/index.ts) returns
 * { user, login, logout, status } — there is NO `loading` field. A prior
 * generator template destructured a nonexistent `loading` field (always
 * `undefined`/falsy), which made the guard collapse to `if (!user) redirect`
 * on the very first render, before the session query resolved — a hard
 * redirect loop on every authenticated route (bug found regenerating SDO.01).
 *
 * The emitted layout must derive its loading state from the real `status`
 * union ("loading" | "authenticated" | "unauthenticated"), matching the
 * established pattern in packages/stack/app-scaffolds/shells/transaction/session-guard.tsx.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const GENERATOR = path.join(REPO_ROOT, "scripts", "scaffold-solution.mjs");

// Async, NOT execFileSync: the generator runs ~250s, and a sync call blocks the
// Node event loop for its whole duration, so the vitest worker cannot answer the
// reporter's "onTaskUpdate" RPC ping. That surfaced as an unhandled error and a
// non-zero exit code even when every assertion passed — i.e. a green test that
// still failed CI. Awaiting keeps the loop responsive. (2026-07-24)
const execFileAsync = promisify(execFile);

const FIXTURE_MD = `---
platform: DWS
solution: DWS.98
name: Auth Guard Contract Test
journey_stages: [0, 2]
deploy_layer: L03
consumes_platform_services: [PS.AUTH, PS.DATA, PS.SEARCH]
modules:
  - id: DWS.98.M01
    name: Work Queue
    journey: 2
    scaffold: SH.02
    features:
      - id: APP.F01
        role: work-queue
        wires: [PS.DATA, PS.SEARCH]
        config:
          entityType: task
          columns:
            - { field: title, label: Title }
---

# DWS.98 — Auth guard contract fixture
`;

// The generator emits the authenticated route group as TWO files:
//   layout.tsx                      — server component, the security boundary;
//                                     renders <AuthenticatedClientShell>.
//   authenticated-client-shell.tsx  — client component, holds the useAuth()
//                                     guard this contract is about.
// Assert against the client shell. Pointing these assertions at layout.tsx
// (as this test originally did) makes them pass VACUOUSLY — layout.tsx has no
// useAuth() call at all, so a reintroduced `loading` bug in the shell would
// sail straight through. Corrected 2026-07-24.
const AUTH_SHELL_REL = "app/(authenticated)/authenticated-client-shell.tsx";

let tmpRoot: string;
let mdPath: string;
let outDir: string;

beforeAll(async () => {
  tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-gen-authguard-"));
  mdPath = path.join(tmpRoot, "SOLUTION.md");
  outDir = path.join(tmpRoot, "out");
  fs.writeFileSync(mdPath, FIXTURE_MD, "utf8");
  await execFileAsync(process.execPath, [GENERATOR, mdPath, "--out-dir", outDir, "--force"], {
    cwd: REPO_ROOT,
    encoding: "utf8",
    maxBuffer: 32 * 1024 * 1024,
  });
// 600s: a full generator run against the fixture measured ~355s on Windows
// (2026-07-24). The original 120s budget timed out in beforeAll, silently
// skipping both assertions. Sibling generator-invoking tests in this dir use
// 300_000-400_000; this sits above the slowest of them for headroom.
}, 600_000);

afterAll(() => {
  if (tmpRoot && fs.existsSync(tmpRoot)) fs.rmSync(tmpRoot, { recursive: true, force: true });
});

describe("emitted authenticated-client-shell.tsx auth guard", () => {
  it("emits the client shell that actually holds the useAuth() guard", () => {
    const shellPath = path.join(outDir, AUTH_SHELL_REL);
    expect(fs.existsSync(shellPath)).toBe(true);
    // Anti-vacuity: if the guard ever moves file again, fail loudly here rather
    // than silently passing the assertions below against a file with no useAuth().
    expect(fs.readFileSync(shellPath, "utf8")).toContain("useAuth()");
  });

  it("does not destructure a nonexistent `loading` field from useAuth()", () => {
    const shell = fs.readFileSync(path.join(outDir, AUTH_SHELL_REL), "utf8");
    expect(shell).not.toMatch(/const\s*{\s*user,\s*loading\s*}\s*=\s*useAuth\(\)/);
  });

  it("derives the loading state from useAuth()'s real `status` field", () => {
    const shell = fs.readFileSync(path.join(outDir, AUTH_SHELL_REL), "utf8");
    expect(shell).toMatch(/const\s*{\s*user,\s*status\s*}\s*=\s*useAuth\(\)/);
    expect(shell).toMatch(/status\s*===\s*["']loading["']/);
  });
});
