import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * D2 ratchet for the Factory Operations Map
 * (docs/00-moc/factory-operations-moc.md, spec: factory-knowledge-controls-spec-2026-07-10.md).
 *
 * Current-state truth about factory mechanisms was scattered chronological
 * sediment with no index. This ratchet keeps the map from drifting again:
 * (a) the map must exist; (b) every scripts/*.mjs|*.sh basename must appear
 * in it (allowlist with honest reasons permitted, starting EMPTY); (c) every
 * repo-relative backtick file reference in the map must resolve on disk.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const SCRIPTS_DIR = path.join(REPO_ROOT, "scripts");
const MOC_PATH = path.join(REPO_ROOT, "docs/00-moc/factory-operations-moc.md");

/** scripts/*.mjs|*.sh basename → honest reason it is not (yet) referenced in the MOC. */
const ALLOWLIST: Record<string, string> = {};

const mocExists = fs.existsSync(MOC_PATH);
const mocText = mocExists ? fs.readFileSync(MOC_PATH, "utf8") : "";

const scriptBasenames = fs.existsSync(SCRIPTS_DIR)
  ? fs
      .readdirSync(SCRIPTS_DIR, { withFileTypes: true })
      .filter((e) => e.isFile() && (e.name.endsWith(".mjs") || e.name.endsWith(".sh")))
      .map((e) => e.name)
  : [];

/** Repo-relative backtick paths that look like a file reference. */
function extractFileRefs(text: string): string[] {
  const refs = new Set<string>();
  const codeMatches = text.matchAll(/`([^`]+)`/g);
  for (const m of codeMatches) {
    const raw = m[1];
    if (raw === undefined) continue;
    for (const candidate of raw.split(/[,\s]+/)) {
      let cleaned = candidate.replace(/[.:;]+$/, "");
      // Strip trailing "source line" pointers like ":564-650".
      cleaned = cleaned.replace(/:\d+(-\d+)?$/, "");
      if (!cleaned || cleaned.includes("<")) continue;
      // Only treat as a resolvable reference when it is repo-relative (contains
      // a "/"): bare filenames like `instrumentation.ts` or `next.config.ts`
      // are per-app generated files named for context, not map file references.
      const looksLikePath =
        /^(scripts|docs|packages|apps|infra|\.storybook)\//.test(cleaned) && cleaned.includes("/");
      if (looksLikePath) refs.add(cleaned.replace(/\\/g, "/"));
    }
  }
  return [...refs];
}

describe("Factory Operations Map conformance (D2)", () => {
  it("the map exists", () => {
    expect(mocExists, `missing ${path.relative(REPO_ROOT, MOC_PATH)}`).toBe(true);
  });

  it("every scripts/*.mjs|*.sh basename appears in the map (or has an honest allowlist reason)", () => {
    const violations: string[] = [];
    for (const name of scriptBasenames) {
      if (ALLOWLIST[name]) continue;
      if (!mocText.includes(name)) violations.push(name);
    }
    expect(
      violations,
      `scripts not referenced in docs/00-moc/factory-operations-moc.md:\n${violations.join("\n")}`,
    ).toEqual([]);
  });

  it("every allowlisted script has an honest, non-empty reason", () => {
    for (const [name, reason] of Object.entries(ALLOWLIST)) {
      expect(reason.length, `empty/too-short allowlist reason for ${name}`).toBeGreaterThan(10);
    }
  });

  it("allowlist entries still exist and are still missing from the map (prune stale allowlist)", () => {
    for (const [name, reason] of Object.entries(ALLOWLIST)) {
      const abs = path.join(SCRIPTS_DIR, name);
      expect(fs.existsSync(abs), `allowlisted script missing: ${name}`).toBe(true);
      expect(mocText.includes(name), `allowlist entry no longer needed (remove it): ${name} — ${reason}`).toBe(
        false,
      );
    }
  });

  it("every repo-relative file reference in the map resolves to an existing file or directory", () => {
    if (!mocExists) return;
    const refs = extractFileRefs(mocText);
    const missing: string[] = [];
    for (const ref of refs) {
      const abs = path.join(REPO_ROOT, ref);
      if (!fs.existsSync(abs)) missing.push(ref);
    }
    expect(missing, `dead links in docs/00-moc/factory-operations-moc.md:\n${missing.join("\n")}`).toEqual([]);
  });
});
