import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Ratchet: everything `@dbp/organisms`' entrypoints import must actually ship.
 *
 * The package exports raw `.tsx` (one subpath per organism), so a consumer type-checks OUR
 * source. If an entrypoint imports `./components/x.js` and `components/` is not in the
 * package's `files` allowlist, the tarball installs fine, resolves nothing, and the consumer
 * gets a wall of TS2307s inside `node_modules` that reads as their fault.
 *
 * That is not hypothetical. `platform/v1.5.0` shipped a `files` allowlist whose entries for
 * `components` and `hooks` were BARE DIRECTORY patterns (star-slash-components, with no
 * trailing glob). Those matched nothing: `index.tsx`, `types.ts` and `README.md` shipped,
 * `components/` and `hooks/` did not. `lib/`, `logic/`, `renderer/` and `client/` were never
 * listed at all. Every consumer of the package was broken; DTMP's export reported 127 type
 * errors, all of them ours.
 *
 * Nothing caught it, because the monorepo resolves these paths from source and never consults
 * `files`. Only a `pnpm pack` and an install exercise the allowlist — which happens at export
 * time, in someone else's repository.
 *
 * This test reads what the entrypoints actually import and asserts each subdirectory is
 * covered. It is deliberately derived from the imports rather than a hardcoded list, so a new
 * subdirectory added to an organism fails here rather than in a consumer's build.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const ORGANISMS_DIR = path.join(REPO_ROOT, "packages/stack/app-scaffolds/features");
const PKG_PATH = path.join(ORGANISMS_DIR, "package.json");

/** Any relative import specifier. Resolved against the importing file to find its subdir. */
const RELATIVE_IMPORT = /from\s+["'](\.\.?\/[^"']+)["']/g;

/** Not shipped, so what they import does not need to be. */
const NON_SHIPPED_DIRS = new Set(["stories", "tests", "examples"]);

function readPkg(): { files?: string[]; exports?: Record<string, string> } {
  return JSON.parse(fs.readFileSync(PKG_PATH, "utf8"));
}

/**
 * Subdirs reachable from ANY shipped file, mapped to an example importer.
 *
 * Deliberately not limited to `index.tsx`. The first version of this test only scanned
 * entrypoints and passed while `server/` was still missing, because the only importer is
 * `form-builder/hooks/use-form-submit.ts` — a nested file, two hops from the entrypoint.
 * A transitive dependency is just as load-bearing as a direct one.
 */
function importedSubdirs(): Map<string, string> {
  const found = new Map<string, string>();

  const walkOrganism = (organism: string, dir: string) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (NON_SHIPPED_DIRS.has(entry.name)) continue;
        walkOrganism(organism, full);
        continue;
      }
      if (!/\.tsx?$/.test(entry.name) || /\.test\.tsx?$/.test(entry.name)) continue;

      const src = fs.readFileSync(full, "utf8");
      for (const match of src.matchAll(RELATIVE_IMPORT)) {
        const resolved = path.relative(
          path.join(ORGANISMS_DIR, organism),
          path.resolve(dir, match[1]!),
        );
        const [subdir] = resolved.split(path.sep);
        // Only directories inside this organism — skip files (types.ts) and any
        // specifier climbing out of the organism entirely.
        if (!subdir || subdir === ".." || subdir.includes(".")) continue;
        if (!found.has(subdir)) {
          found.set(subdir, path.relative(ORGANISMS_DIR, full).replaceAll(path.sep, "/"));
        }
      }
    }
  };

  for (const organism of fs.readdirSync(ORGANISMS_DIR, { withFileTypes: true })) {
    if (!organism.isDirectory()) continue;
    walkOrganism(organism.name, path.join(ORGANISMS_DIR, organism.name));
  }
  return found;
}

/** `files` patterns that positively include a star-slash-subdir-slash-glob path. */
function includedSubdirs(files: string[]): Set<string> {
  const included = new Set<string>();
  for (const pattern of files) {
    if (pattern.startsWith("!")) continue;
    // "*/components/**" -> "components". A BARE "*/components" is deliberately not
    // counted: that is the exact form that shipped nothing in v1.5.0.
    const match = /^\*\/([a-z0-9-]+)\/\*\*$/.exec(pattern);
    if (match) included.add(match[1]!);
  }
  return included;
}

describe("@dbp/organisms package files allowlist", () => {
  it("ships every subdirectory its entrypoints import", () => {
    const files = readPkg().files ?? [];
    const included = includedSubdirs(files);
    const missing = [...importedSubdirs()].filter(([subdir]) => !included.has(subdir));

    expect(
      missing.map(([subdir, importer]) => `${subdir}/ (imported by ${importer})`),
      "These subdirectories are imported by a shipped entrypoint but are not in " +
        "packages/stack/app-scaffolds/features/package.json#files, so they will be MISSING from " +
        "the published tarball. Consumers will see TS2307 'Cannot find module' inside " +
        "node_modules. Add a \"*/<subdir>/**\" pattern (with the /** — a bare \"*/<subdir>\" " +
        "matches nothing).",
    ).toEqual([]);
  });

  it("has no bare directory patterns, which silently match nothing", () => {
    const files = readPkg().files ?? [];
    const bare = files.filter((p) => /^\*\/[a-z0-9-]+$/.test(p));

    expect(
      bare,
      'Bare directory patterns like "*/components" do not ship the directory contents — this is ' +
        "exactly how v1.5.0 shipped a broken @dbp/organisms. Use \"*/components/**\".",
    ).toEqual([]);
  });

  it("excludes tests from the tarball", () => {
    const files = readPkg().files ?? [];
    const hasTestNegation = files.some((p) => p.startsWith("!") && p.includes("test"));

    expect(
      hasTestNegation,
      "Runtime subdirectories can contain nested tests (e.g. form-builder/logic/tests/**). A " +
        "wholesale \"*/logic/**\" ships them, and a consumer then type-checks vitest imports it " +
        "has no reason to have installed. Keep the \"!*/**/tests/**\" negations.",
    ).toBe(true);
  });

  it("every exported subpath resolves to a file that exists", () => {
    const exportsMap = readPkg().exports ?? {};
    const dangling = Object.entries(exportsMap)
      .filter(([key]) => key.startsWith("./"))
      .filter(([, target]) => !fs.existsSync(path.join(ORGANISMS_DIR, target)))
      .map(([key, target]) => `${key} -> ${target}`);

    expect(dangling, "Exported subpaths pointing at files that do not exist.").toEqual([]);
  });
});
