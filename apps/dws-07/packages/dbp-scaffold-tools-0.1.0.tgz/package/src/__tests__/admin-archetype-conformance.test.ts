import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Admin-archetype conformance ratchet (ENFORCING - runs against FRESH generator output).
 *
 * WHAT THIS ENFORCES
 * ------------------
 * Every app/(authenticated)/admin/* /page.tsx emitted by the generator must:
 *
 *   1. Use exactly ONE of {CanvasLayout, SettingsLayout, ConfigTabsLayout, BuilderLayout}
 *      - no self-rolled <header>, no bespoke nav, no layout-less admin pages.
 *   2. Contain NO <PageHeader (shell v3 / N27): the top bar's breadcrumb terminal
 *      crumb is the page title, so a page-level PageHeader would duplicate it.
 *      Action CTAs live in a content-body toolbar instead.
 *   3. ConfigTabsLayout and BuilderLayout pages must NOT contain `pageTitle=`
 *      (that prop lives on SettingsLayout/CanvasLayout only - these two use header-slot only).
 *   4. No "neutral" tone in any `badgeTones` block (CVA silently ignores it => unstyled badge).
 *   5. Each well-known admin route uses the EXPECTED layout archetype per ADMIN_ARCHETYPE_MAP.
 *
 * HOW IT WORKS
 * ------------
 * 1. `beforeAll` regenerates DXP.01A into an OS temp directory via:
 *      node scripts/scaffold-solution.mjs docs/10-solutions/dxp/dxp-01a-solution.md --out-dir <tmp> --force
 *    This never touches the committed apps/ tree.
 * 2. All assertions share the single regenerated output - no repeated generator invocations.
 * 3. `afterAll` cleans the temp directory.
 *
 * WHY DXP.01A
 * -----------
 * DXP.01A is the canonical reference solution that exercises all four admin archetypes
 * (list, config-single, config-tabs, builder), making it the best single-manifest
 * regression target for the archetype map.
 */

// Route -> expected layout component (mirrors ADMIN_ARCHETYPE_MAP in scaffold-solution.mjs).
//
// Builder routes follow the list-first pattern (ADR-0035):
//   admin/<route>/page.tsx → CanvasLayout (list + EntityList + "New" action button)
// The [id] detail page (BuilderLayout) is planned but not yet emitted by the generator.

const ADMIN_ARCHETYPE_MAP: Record<string, string> = {
  // Builder routes — list page (CanvasLayout + EntityList; detail page not yet emitted)
  "admin/form-builder":     "CanvasLayout",
  "admin/workflow-builder": "CanvasLayout",
  "admin/data-flows":       "CanvasLayout",
  "admin/data-model":       "CanvasLayout",
  // Config-tabs routes
  "admin/organisation":     "ConfigTabsLayout",
  // access-control renders the real PS.RBAC role-permission matrix (AdminAccessMatrix)
  // inside CanvasLayout (2026-07-17 admin coherence pass) — no longer a config form.
  "admin/access-control":   "CanvasLayout",
  "admin/auth":             "ConfigTabsLayout",
  // Config-single route
  "admin/data-import":      "SettingsLayout",
  // List routes
  "admin/rules":            "CanvasLayout",
  "admin/users":            "CanvasLayout",
  "admin/roles":            "CanvasLayout",
  "admin/security-logs":    "CanvasLayout",
  "admin/apis":             "CanvasLayout",
  "admin/connectors":       "CanvasLayout",
  "admin/policies":         "CanvasLayout",
  "admin/controls":         "CanvasLayout",
  "admin/risks":            "CanvasLayout",
  "admin/master-data":      "CanvasLayout",
  "admin/reference-data":   "CanvasLayout",
  "admin/data-quality":     "CanvasLayout",
  "admin/data-lineage":     "CanvasLayout",
};

// Constants

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const GENERATOR = path.join(REPO_ROOT, "scripts", "scaffold-solution.mjs");
const MANIFEST  = path.join(REPO_ROOT, "docs", "10-solutions", "dxp", "dxp-01a-solution.md");

const VALID_LAYOUTS = new Set([
  "CanvasLayout",
  "SettingsLayout",
  "ConfigTabsLayout",
  "BuilderLayout",
]);

// Layouts that use header-slot only - must NOT have a pageTitle= prop
const HEADER_SLOT_ONLY_LAYOUTS = new Set(["ConfigTabsLayout", "BuilderLayout"]);

// Setup / teardown

let tmpDir: string;
let outDir: string;

beforeAll(() => {
  tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-admin-ratchet-"));
  outDir = path.join(tmpDir, "out");
  fs.mkdirSync(outDir, { recursive: true });

  execFileSync(process.execPath, [GENERATOR, MANIFEST, "--out-dir", outDir, "--force"], {
    cwd: REPO_ROOT,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
  });
}, 300_000);

afterAll(() => {
  if (tmpDir && fs.existsSync(tmpDir)) {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

// Helpers

/** Recursively collect page.tsx files under a directory. */
function collectPageFiles(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  const results: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === "node_modules" || entry.name === ".next") continue;
      results.push(...collectPageFiles(abs));
    } else if (entry.name === "page.tsx") {
      results.push(abs);
    }
  }
  return results;
}

/** Return the route segment relative to the admin base dir (e.g. "admin/users"). */
function routeSegment(pageFile: string, adminBase: string): string {
  const rel = path.relative(adminBase, path.dirname(pageFile)).replace(/\\/g, "/");
  return rel ? `admin/${rel}` : "admin";
}

/** Detect which approved layout component the file uses (first match). */
function detectLayout(src: string): string | null {
  for (const layout of VALID_LAYOUTS) {
    if (src.includes(layout)) return layout;
  }
  return null;
}

/** Count occurrences of `<PageHeader` in source. */
function countPageHeaders(src: string): number {
  return (src.match(/<PageHeader\b/g) ?? []).length;
}

/** Return true if `pageTitle=` appears anywhere in the source. */
function hasPageTitle(src: string): boolean {
  return /\bpageTitle=/.test(src);
}

/** Return true if "neutral" appears in a badgeTones block. */
function hasNeutralTone(src: string): boolean {
  if (!src.includes("badgeTones")) return false;
  const blockRe = /badgeTones[^}]+\}/g;
  let block: RegExpExecArray | null;
  while ((block = blockRe.exec(src)) !== null) {
    if (/"neutral"/.test(block[0])) return true;
  }
  return false;
}

// Discovery

it("generator emits at least one admin page in the temp output", () => {
  const adminBase = path.join(outDir, "app", "(authenticated)", "admin");
  expect(
    fs.existsSync(adminBase),
    `admin dir not found in generator output -- expected at: ${adminBase}`
  ).toBe(true);

  const pages = collectPageFiles(adminBase);
  expect(
    pages.length,
    "Expected at least 1 admin page.tsx in generator output"
  ).toBeGreaterThan(0);
});

// Main ratchet suite

describe("admin-archetype conformance -- fresh DXP.01A generator output", () => {
  function getAdminPages(): string[] {
    const adminBase = path.join(outDir, "app", "(authenticated)", "admin");
    return collectPageFiles(adminBase);
  }

  // 1. Every admin page uses an approved layout

  it("every admin page uses exactly one approved layout (CanvasLayout | SettingsLayout | ConfigTabsLayout | BuilderLayout)", () => {
    const pages = getAdminPages();
    const violations: string[] = [];

    for (const abs of pages) {
      const src = fs.readFileSync(abs, "utf8");
      const detected = detectLayout(src);

      if (detected === null) {
        violations.push(
          `${path.relative(outDir, abs)}: no approved layout found -- uses raw chrome or no layout`
        );
        continue;
      }

      // Ensure no second layout name also appears (each page must use exactly one)
      const otherLayouts = [...VALID_LAYOUTS].filter((l) => l !== detected);
      for (const other of otherLayouts) {
        if (src.includes(other)) {
          violations.push(
            `${path.relative(outDir, abs)}: uses both ${detected} and ${other} -- must use exactly one`
          );
        }
      }
    }

    expect(
      violations,
      [
        "ADMIN_LAYOUT violations -- every admin page must use exactly one approved layout.",
        "Approved layouts: CanvasLayout, SettingsLayout, ConfigTabsLayout, BuilderLayout.",
        "Fix: ensure the generator emits the correct layout for each admin route.",
        ...violations.slice(0, 5),
      ].join("\n")
    ).toEqual([]);
  });

  // 2. No <PageHeader on any admin page (shell v3 / N27)

  it("no admin page renders a <PageHeader (shell v3 / N27 -- breadcrumb terminal crumb is the title)", () => {
    const pages = getAdminPages();
    const violations: string[] = [];

    for (const abs of pages) {
      const src = fs.readFileSync(abs, "utf8");
      const count = countPageHeaders(src);
      if (count > 0) {
        violations.push(
          `${path.relative(outDir, abs)}: ${count} <PageHeader occurrence(s) -- ` +
          "shell v3 (N27) removed the page-level PageHeader; move action CTAs into a content-body toolbar"
        );
      }
    }

    expect(
      violations,
      [
        "PAGEHEADER violations -- admin pages must not render a PageHeader (shell v3 / N27).",
        "The top bar's breadcrumb terminal crumb is the page title; a PageHeader duplicates it.",
        ...violations.slice(0, 5),
      ].join("\n")
    ).toEqual([]);
  });

  // 3. ConfigTabsLayout and BuilderLayout pages must NOT use pageTitle=

  it("ConfigTabsLayout and BuilderLayout pages do not use pageTitle= (header-slot only)", () => {
    const pages = getAdminPages();
    const violations: string[] = [];

    for (const abs of pages) {
      const src = fs.readFileSync(abs, "utf8");
      const layout = detectLayout(src);
      if (layout !== null && HEADER_SLOT_ONLY_LAYOUTS.has(layout) && hasPageTitle(src)) {
        violations.push(
          `${path.relative(outDir, abs)}: ${layout} page uses pageTitle= -- ` +
          "this layout uses header-slot only; pass title via header={<PageHeader title=.../>} instead"
        );
      }
    }

    expect(
      violations,
      [
        "PAGETITLE violations -- ConfigTabsLayout and BuilderLayout use header-slot only.",
        "These layouts have no pageTitle prop. Supply the title via header={<PageHeader title=\"...\" />}.",
        ...violations.slice(0, 5),
      ].join("\n")
    ).toEqual([]);
  });

  // 4. No "neutral" badge tone in any admin page

  it('no admin page uses "neutral" in badgeTones (invalid tone -- CVA ignores it silently)', () => {
    const pages = getAdminPages();
    const violations: string[] = [];

    for (const abs of pages) {
      const src = fs.readFileSync(abs, "utf8");
      if (hasNeutralTone(src)) {
        violations.push(
          `${path.relative(outDir, abs)}: "neutral" in badgeTones -- invalid tone; badge renders unstyled. ` +
          "Use: default|success|warning|danger|info|gray|orange|navy"
        );
      }
    }

    expect(
      violations,
      [
        'BAD_TONE violations -- "neutral" is not a valid Badge tone (not in CVA variants).',
        "CVA silently ignores unknown tones -- the badge renders completely unstyled.",
        'Fix the generator template to emit a valid tone instead of "neutral".',
        ...violations.slice(0, 5),
      ].join("\n")
    ).toEqual([]);
  });

  // 5. Well-known routes use the expected layout archetype

  it("each well-known admin route uses the expected layout component per ADMIN_ARCHETYPE_MAP", () => {
    const adminBase = path.join(outDir, "app", "(authenticated)", "admin");
    const pages = getAdminPages();
    const violations: string[] = [];

    for (const abs of pages) {
      const seg = routeSegment(abs, adminBase);
      const expected = ADMIN_ARCHETYPE_MAP[seg];
      if (!expected) continue; // route not in the map - not checked here

      const src = fs.readFileSync(abs, "utf8");
      const actual = detectLayout(src);

      if (actual !== expected) {
        violations.push(
          `${seg}: expected ${expected}, got ${actual ?? "no layout"} -- ` +
          "ADMIN_ARCHETYPE_MAP mismatch between test and generator"
        );
      }
    }

    expect(
      violations,
      [
        "ARCHETYPE_MAP violations -- admin route uses wrong layout.",
        "This ratchet mirrors ADMIN_ARCHETYPE_MAP in scaffold-solution.mjs.",
        "If the map changed in the generator, update this test to match.",
        ...violations.slice(0, 10),
      ].join("\n")
    ).toEqual([]);
  });
});
