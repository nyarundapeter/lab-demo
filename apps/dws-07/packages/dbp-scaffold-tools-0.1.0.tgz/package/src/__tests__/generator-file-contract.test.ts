import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Generator-owned vs solution-owned FILE CONTRACT — round-trip safety tests.
 *
 * These guard the keystone P0 fix: `scaffold-solution.mjs --force` must be
 * NON-DESTRUCTIVE for solution-owned files. The previous behaviour
 * (`fs.rmSync(outDirBase)` then re-emit) deleted everything the generator did not
 * re-emit — instrumentation.ts, solution/entities|workflows|modules/**, and the
 * hand-seeded platform-data route — twice causing data loss in real apps.
 *
 * Contract under test (must run the REAL generator into a temp --out-dir; never apps/):
 *   1. A first scaffold writes the solution-owned data-route TEMPLATE and emits the
 *      generator-owned chrome (app/page.tsx, middleware.ts, package.json, …).
 *   2. After hand-adding a solution-owned entity + workflow + instrumentation.ts and
 *      hand-editing a seed marker in the data route, a `--force` regen PRESERVES all
 *      of those hand edits byte-for-byte, while REFRESHING a tampered generator-owned
 *      file (app/page.tsx) back to the canonical emit.
 *   3. Two consecutive `--force` regens are byte-identical for generator-owned files.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const GENERATOR = path.join(REPO_ROOT, "scripts", "scaffold-solution.mjs");

// Minimal manifest: PS.DATA consumed (so the data route is emitted) + one module.
// A non-DXP solution still emits a generator-owned app/page.tsx ("/" → /login
// redirect) we can tamper-test. (DWS solutions may not declare a landing block.)
const FIXTURE_MD = `---
platform: DWS
solution: DWS.97
name: File Contract Test
journey_stages: [0, 2]
deploy_layer: L03
consumes_platform_services: [PS.AUTH, PS.DATA, PS.SEARCH]
modules:
  - id: DWS.97.M01
    name: Work Queue
    journey: 2
    scaffold: SH.02
    features:
      - id: APP.F01
        role: work-queue
        wires: [PS.DATA, PS.SEARCH]
        config:
          entityType: task
          columns:
            - { field: title, label: Title }
---

# DWS.97 — File Contract fixture
`;

// Relative path to the platform-data route — kept as a constant because the
// "[[...path]]" segment is a glob to some shells; Node fs handles it literally.
const DATA_ROUTE_REL = "app/api/platform/data/[[...path]]/route.ts";

// G13/F4: a realistic hand-authored solution-owned entity (enums, a nested array
// schema, ~25 fields — mirrors STCB's real compliance-obligation.ts). The old
// fixture was a one-line marker string, so a "silently reduced to a plausible
// stub" regression would slip past `.toContain(...)`. We assert this survives a
// `--force` regen BYTE-IDENTICAL, which is the only assertion that catches a
// content-shrinking overwrite (exactly the G13 wipe class).
const COMPLIANCE_OBLIGATION_FIXTURE = `// ComplianceObligation entity schema — solution-owned for compliance obligations workspace.
import { z } from "zod";

export const RegulationFramework = z.enum([
  "SAMA_ITGF", "NCA_ECC", "SAMA_CSF", "PDPL", "CMA", "ZATCA", "Internal",
]);
export const ObligationPriority = z.enum(["P0", "P1", "P2", "P3"]);
export const ObligationEvidenceStatus = z.enum(["missing", "partial", "complete"]);
export const ObligationRegulator = z.enum(["SAMA", "CMA", "ZATCA", "NCA", "internal"]);
export const ObligationStatus = z.enum([
  "compliant", "partially-compliant", "non-compliant", "under-review",
]);

export const ObligationAuditTrailEntrySchema = z.object({
  action: z.string(),
  by: z.string(),
  timestamp: z.string(),
  detail: z.string().optional(),
});

export const ComplianceObligationSchema = z.object({
  name: z.string(),
  summary: z.string().optional(),
  regulator: ObligationRegulator,
  category: z.string().optional(),
  status: ObligationStatus,
  dueDate: z.string().optional(),
  owner: z.string().optional(),
  ownerId: z.string().optional(),
  code: z.string(),
  displayId: z.string().optional(),
  priority: ObligationPriority.optional(),
  evidenceStatus: ObligationEvidenceStatus.optional(),
  controlLinked: z.boolean().optional(),
  framework: RegulationFramework.optional(),
  frameworkLabel: z.string().optional(),
  escalationOwner: z.string().optional(),
  linkedControlCodes: z.string().optional(),
  linkedRiskCodes: z.string().optional(),
  linkedPolicyCodes: z.string().optional(),
  evidenceSummary: z.string().optional(),
  delegationHistory: z.string().optional(),
  auditTrail: z.array(ObligationAuditTrailEntrySchema).optional(),
  auditTrailSummary: z.string().optional(),
  isOverdue: z.boolean().optional(),
  dueSoon: z.boolean().optional(),
  dueFuture: z.boolean().optional(),
});

export type ComplianceObligation = z.infer<typeof ComplianceObligationSchema>;

export const complianceObligationEntityTypeDefinition = {
  type: "compliance-obligation",
} as const;
`;

let tmpRoot: string;
let mdPath: string;
let outDir: string;

function runGenerator(out: string): void {
  execFileSync(process.execPath, [GENERATOR, mdPath, "--out-dir", out, "--force"], {
    cwd: REPO_ROOT,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
  });
}

function abs(rel: string): string {
  return path.join(outDir, rel);
}
function read(rel: string): string {
  return fs.readFileSync(abs(rel), "utf8");
}
function exists(rel: string): boolean {
  return fs.existsSync(abs(rel));
}

beforeAll(() => {
  tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-gen-contract-"));
  mdPath = path.join(tmpRoot, "SOLUTION.md");
  outDir = path.join(tmpRoot, "out");
  fs.writeFileSync(mdPath, FIXTURE_MD, "utf8");
  // First scaffold.
  runGenerator(outDir);
}, 300_000);

afterAll(() => {
  if (tmpRoot && fs.existsSync(tmpRoot)) fs.rmSync(tmpRoot, { recursive: true, force: true });
});

describe("file contract — first scaffold", () => {
  it("writes the solution-owned data-route TEMPLATE (clearly marked hand-editable)", () => {
    expect(exists(DATA_ROUTE_REL)).toBe(true);
    const route = read(DATA_ROUTE_REL);
    expect(route).toContain("SOLUTION-OWNED");
    expect(route).toContain("bootstrapData");
    // The template must NOT pre-bake tenant/seed — that is the solution's to add.
    expect(route).toContain("@dbp/ps-data/server");
  });

  it("emits the generator-owned chrome (page/middleware/package.json)", () => {
    expect(read("app/page.tsx")).toContain("Generated by scaffold-solution");
    expect(exists("middleware.ts")).toBe(true);
    expect(exists("package.json")).toBe(true);
  });

  it("authors instrumentation.ts + instrumentation.node.ts when PS.DATA is consumed (create-if-missing)", () => {
    // When PS.DATA is wired, the generator emits a working instrumentation template using
    // the create-if-missing contract (solution-owned: preserved byte-for-byte on --force regen
    // once a developer hand-authors it). instrumentation.ts is a thin dispatcher (kept edge-safe
    // — see its own header comment for why); the actual bootstrap logic lives in
    // instrumentation.node.ts. Standard-menu demo entity injection means hasManifestEntities=true
    // here, so the emitted node template calls registerAndSeedData().
    expect(exists("instrumentation.ts")).toBe(true);
    expect(read("instrumentation.ts")).toContain("NEXT_RUNTIME");
    expect(exists("instrumentation.node.ts")).toBe(true);
    expect(read("instrumentation.node.ts")).toContain("registerAndSeedData");
  });
});

describe("file contract — --force regen preserves solution-owned, refreshes generator-owned", () => {
  beforeAll(() => {
    // Hand-add solution-owned assets the way a real solution author would.
    fs.mkdirSync(abs("solution/entities"), { recursive: true });
    fs.mkdirSync(abs("solution/workflows"), { recursive: true });
    fs.writeFileSync(
      abs("solution/entities/task.ts"),
      "// HAND-AUTHORED ENTITY — MUST SURVIVE REGEN\nexport const taskEntityTypeDefinition = { type: 'task' };\n",
      "utf8",
    );
    // G13/F4: a realistic multi-field entity, written byte-for-byte from the fixture
    // so the regen can be asserted byte-identical (not just marker-substring present).
    fs.writeFileSync(
      abs("solution/entities/compliance-obligation.ts"),
      COMPLIANCE_OBLIGATION_FIXTURE,
      "utf8",
    );
    fs.writeFileSync(
      abs("solution/workflows/task-approval.ts"),
      "// HAND-AUTHORED WORKFLOW — MUST SURVIVE REGEN\nexport const taskWorkflow = { id: 'task-approval' };\n",
      "utf8",
    );
    fs.writeFileSync(
      abs("instrumentation.ts"),
      "// HAND-AUTHORED INSTRUMENTATION — MUST SURVIVE REGEN\nexport async function register() { /* SEED_MARKER_INSTRUMENTATION_V2 */ }\n",
      "utf8",
    );
    // Hand-edit the seed seam inside the (solution-owned) data route.
    const route = read(DATA_ROUTE_REL).replace(
      "void dataSvc;",
      "void dataSvc; /* HAND_EDITED_SEED_ROW_MARKER_42 */",
    );
    fs.writeFileSync(abs(DATA_ROUTE_REL), route, "utf8");
    // Tamper a GENERATOR-OWNED file's BODY while keeping its "Generated by
    // scaffold-solution" header intact. Wave-2's R5 pre-regen safety check ABORTS a
    // --force regen only when the header is STRIPPED (that signals genuine hand-
    // authoring the operator must not lose). A header-intact drifted file is still
    // generator-owned and must be refreshed back to canonical — which is what this
    // block asserts. (Stripping the header here would make R5 fail closed and abort
    // the regen, which is correct wave-2 behaviour but a different scenario.)
    fs.writeFileSync(abs("app/page.tsx"), read("app/page.tsx") + "\n// TAMPERED-BODY-MARKER\n", "utf8");

    // Regenerate with --force.
    runGenerator(outDir);
  }, 300_000);

  it("preserves a hand-added solution-owned entity file", () => {
    expect(exists("solution/entities/task.ts")).toBe(true);
    expect(read("solution/entities/task.ts")).toContain("MUST SURVIVE REGEN");
  });

  it("preserves a hand-added solution-owned workflow file", () => {
    expect(exists("solution/workflows/task-approval.ts")).toBe(true);
    expect(read("solution/workflows/task-approval.ts")).toContain("MUST SURVIVE REGEN");
  });

  it("preserves a realistic multi-field entity BYTE-IDENTICAL across --force (G13/F4)", () => {
    // The regression this guards: a publication/regen path that silently overwrites a
    // 107-line hand-authored entity with a generic scaffold stub (the G13 wipe class).
    // A substring check would pass on a stub; byte-equality is the only thing that fails.
    expect(exists("solution/entities/compliance-obligation.ts")).toBe(true);
    expect(read("solution/entities/compliance-obligation.ts")).toBe(COMPLIANCE_OBLIGATION_FIXTURE);
  });

  it("preserves the hand-written instrumentation.ts edit", () => {
    expect(exists("instrumentation.ts")).toBe(true);
    expect(read("instrumentation.ts")).toContain("SEED_MARKER_INSTRUMENTATION_V2");
  });

  it("overwrites data route on regen when entities are present (generator-owned)", () => {
    // The standard-menu scaffold injects demo entities whenever PS.DATA is consumed without
    // an explicit entities: block, making hasManifestEntities=true. This flips the data route
    // to generator-owned (always-overwrite via fs.writeFileSync, bypassing writeFile()).
    // The hand-edit attempt in beforeAll was a no-op (entities-present template has no
    // "void dataSvc;" to replace), and the regen restored the canonical template.
    const route = read(DATA_ROUTE_REL);
    expect(route).toContain("SOLUTION-OWNED"); // canonical template marker is present
    expect(route).not.toContain("HAND_EDITED_SEED_ROW_MARKER_42"); // hand edit was overwritten
  });

  it("refreshes the tampered generator-owned app/page.tsx back to canonical", () => {
    const page = read("app/page.tsx");
    expect(page).toContain("Generated by scaffold-solution");
    expect(page).not.toContain("TAMPERED");
  });
});

describe("file contract — consecutive --force regens are byte-identical (generator-owned)", () => {
  it("two regens into separate dirs produce identical generator-owned files", () => {
    const a = path.join(tmpRoot, "byteA");
    const b = path.join(tmpRoot, "byteB");
    runGenerator(a);
    runGenerator(b);
    const genOwned = [
      "app/page.tsx",
      // 2-shell model (ADR-0027): module pages live under app/(authenticated)/ route group
      "app/(authenticated)/m01/page.tsx",
      "app/providers.tsx",
      "app/layout.tsx",
      "middleware.ts",
      "package.json",
      "next.config.ts",
      "tailwind.config.mjs",
      // Data route is generator-owned (demo entities injected when PS.DATA wired without
      // explicit entities), so two fresh emits are deterministic and byte-identical.
      DATA_ROUTE_REL,
    ];
    for (const f of genOwned) {
      const x = fs.readFileSync(path.join(a, f), "utf8");
      const y = fs.readFileSync(path.join(b, f), "utf8");
      expect(y, `${f} differs across regenerations`).toBe(x);
    }
    fs.rmSync(a, { recursive: true, force: true });
    fs.rmSync(b, { recursive: true, force: true });
    // Note: solution-owned files (AGENTS.md, CLAUDE.md, .ai/context.md etc.) are excluded
    // from this check — they use new Date() and are create-if-missing, so two fresh
    // scaffolds into separate dirs produce different timestamps, which is correct.
  }, 360_000);
});

/**
 * sweep-ownership-authority fix (2026-07-25) — regression tests for the defect where
 * `sweepStaleGeneratorOwned()` deleted ANY file under app/ that was neither
 * solution-owned nor re-emitted this run, including a hand-added file no manifest
 * module emits. The fix makes the PREVIOUS run's solution/_arch/generator-owned.json
 * the deletion authority: a file is only deleted when it is additionally listed there
 * (provably a generator artifact from a prior run). See scripts/scaffold-solution.mjs
 * sweepStaleGeneratorOwned() and the priorGeneratorOwned Set for the implementation.
 */
describe("sweep-ownership-authority fix — hand-added files under app/ survive --force regen", () => {
  let swOutDir: string;

  beforeAll(() => {
    swOutDir = path.join(tmpRoot, "sweep-authority");
    runGenerator(swOutDir); // first scaffold — writes solution/_arch/generator-owned.json
  }, 300_000);

  it("preserves a hand-added .tsx file under app/ that no manifest module emits", () => {
    const handAddedRel = "app/(authenticated)/hand-added-route/page.tsx";
    fs.mkdirSync(path.dirname(path.join(swOutDir, handAddedRel)), { recursive: true });
    fs.writeFileSync(
      path.join(swOutDir, handAddedRel),
      "// HAND-ADDED ROUTE — NOT A GENERATOR ARTIFACT — MUST SURVIVE REGEN\nexport default function Page() { return null; }\n",
      "utf8",
    );

    execFileSync(process.execPath, [GENERATOR, mdPath, "--out-dir", swOutDir, "--force", "--allow-dirty"], {
      cwd: REPO_ROOT,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    });

    expect(fs.existsSync(path.join(swOutDir, handAddedRel))).toBe(true);
    expect(fs.readFileSync(path.join(swOutDir, handAddedRel), "utf8")).toContain("MUST SURVIVE REGEN");
  });

  it("preserves a hand-added non-.ts/.tsx file under app/ (e.g. .json) that no manifest module emits", () => {
    const handAddedRel = "app/hand-added-config.json";
    fs.writeFileSync(path.join(swOutDir, handAddedRel), JSON.stringify({ handAdded: true }), "utf8");

    execFileSync(process.execPath, [GENERATOR, mdPath, "--out-dir", swOutDir, "--force", "--allow-dirty"], {
      cwd: REPO_ROOT,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    });

    expect(fs.existsSync(path.join(swOutDir, handAddedRel))).toBe(true);
    expect(JSON.parse(fs.readFileSync(path.join(swOutDir, handAddedRel), "utf8"))).toEqual({ handAdded: true });
  });

  it("still deletes a genuinely stale generator-owned file listed in a prior generator-owned.json", () => {
    const ownershipPath = path.join(swOutDir, "solution/_arch/generator-owned.json");
    const owned: string[] = JSON.parse(fs.readFileSync(ownershipPath, "utf8"));
    const staleRel = "app/stale-generator-route/page.tsx";
    fs.mkdirSync(path.dirname(path.join(swOutDir, staleRel)), { recursive: true });
    fs.writeFileSync(
      path.join(swOutDir, staleRel),
      "// Generated by scaffold-solution — do not edit\nexport default function Page() { return null; }\n",
      "utf8",
    );
    // Claim it as a prior-run generator artifact so the sweep is provably allowed to delete it.
    fs.writeFileSync(ownershipPath, JSON.stringify([...owned, staleRel].sort(), null, 2) + "\n", "utf8");

    execFileSync(process.execPath, [GENERATOR, mdPath, "--out-dir", swOutDir, "--force"], {
      cwd: REPO_ROOT,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    });

    expect(fs.existsSync(path.join(swOutDir, staleRel))).toBe(false);
  }, 300_000);

  it("takes the preserve-everything fallback when generator-owned.json is missing/malformed", () => {
    const fbOutDir = path.join(tmpRoot, "sweep-authority-fallback");
    runGenerator(fbOutDir); // first scaffold

    const ownershipPath = path.join(fbOutDir, "solution/_arch/generator-owned.json");
    fs.writeFileSync(ownershipPath, "{ not valid json", "utf8"); // malformed

    // A file that a real regen would normally consider "not re-emitted" — here we
    // just verify a hand-added unknown file under app/ is not deleted when the
    // manifest can't be trusted, i.e. the fallback preserves rather than deletes.
    const handAddedRel = "app/fallback-hand-added/page.tsx";
    fs.mkdirSync(path.dirname(path.join(fbOutDir, handAddedRel)), { recursive: true });
    fs.writeFileSync(
      path.join(fbOutDir, handAddedRel),
      "// HAND-ADDED — FALLBACK MUST PRESERVE\nexport default function Page() { return null; }\n",
      "utf8",
    );

    const output = execFileSync(
      process.execPath,
      [GENERATOR, mdPath, "--out-dir", fbOutDir, "--force", "--allow-dirty"],
      { cwd: REPO_ROOT, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] },
    );

    expect(output).toContain("sweep-ownership-authority");
    expect(fs.existsSync(path.join(fbOutDir, handAddedRel))).toBe(true);
  }, 300_000);
});
