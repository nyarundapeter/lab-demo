import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Storybook sidebar taxonomy ratchet.
 *
 * The sidebar was reorganized so every story/MDX title sits under one of the
 * locked roots below (the full 10-layer stack plus Overview, Solutions,
 * Design System, and Reference — note the em-dashes). This locks that
 * taxonomy so a new story can't silently land outside it (or get auto-titled
 * into an extra root by omitting `title:` entirely).
 *
 * File discovery mirrors the `stories:` globs in `.storybook/main.ts` exactly —
 * update both together if that config changes.
 *
 * Mirrors the pattern in feature-conformance.test.ts and ui-conformance.test.ts.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");

function rel(abs: string): string {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

function listFiles(dir: string, matches: (name: string) => boolean): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === "node_modules") continue;
      out.push(...listFiles(abs, matches));
    } else if (matches(e.name)) {
      out.push(abs);
    }
  }
  return out;
}

// ── File collection (mirrors .storybook/main.ts `stories:` globs) ─────────────
//
// main.ts globs today: ".storybook/**/*.mdx", "packages/shared/ui/**/*.stories.tsx",
// "packages/shared/feature-flags/**/*.stories.tsx",
// "packages/stack/app-scaffolds/**/*.stories.tsx".

const mdxFiles = listFiles(path.join(REPO_ROOT, ".storybook"), (n) => n.endsWith(".mdx"));
const uiStoryFiles = listFiles(path.join(REPO_ROOT, "packages/shared/ui"), (n) => n.endsWith(".stories.tsx"));
const featureFlagStoryFiles = listFiles(path.join(REPO_ROOT, "packages/shared/feature-flags"), (n) =>
  n.endsWith(".stories.tsx"),
);
const appScaffoldStoryFiles = listFiles(path.join(REPO_ROOT, "packages/stack/app-scaffolds"), (n) =>
  n.endsWith(".stories.tsx"),
);
const storyFiles = [...uiStoryFiles, ...featureFlagStoryFiles, ...appScaffoldStoryFiles];

// ── Title extraction ───────────────────────────────────────────────────────────

const ALLOWED_ROOTS = [
  "Overview",
  "Solutions",
  "Layer 01 — Standards & Reference Architecture",
  "Layer 02 — Infrastructure as Code",
  "Layer 03 — Environment as Code",
  "Layer 04 — Pipeline as Code",
  "Layer 05 — Policy & Compliance as Code",
  "Layer 06 — Platform Services",
  "Layer 07 — App Scaffolds",
  "Layer 08 — Observability as Code",
  "Layer 09 — AI-Assisted Engineering",
  "Layer 10 — Provisioning as Code",
  "Design System",
  "Reference",
  // Cookbook added 2026-07-10 (H1 red-abnormal pass): the sidebar root list was stale —
  // .storybook/Cookbook/** and several packages' Cookbook/* stories were already committed
  // (see `git log -- .storybook/Cookbook`, e.g. 49d0cf48, 4beb6ad5, cac6bb56) but never added
  // here, so this ratchet was red for a legitimate, intentional taxonomy root.
  "Cookbook",
  // Design References added 2026-07-13 (develop-integration verification): the design-intake
  // wave committed .storybook/Design-References.mdx ("Design References/Accepted References")
  // embedding the accepted claude.ai design refs live in Storybook — an intentional taxonomy
  // root, ruled intentional (not sprawl) during the develop merge prep.
  "Design References",
];

/** Extracts `<Meta title="..." />` from an MDX doc. */
function extractMdxTitle(src: string): string | null {
  const m = src.match(/<Meta\s+title=["']([^"']+)["']/);
  return m ? (m[1] ?? null) : null;
}

/**
 * Extracts the `title:` belonging to the story file's actual `export default`
 * meta object — not any stray `title:` elsewhere in the file (fixture data,
 * component props, or dead demo code also commonly use a `title` key).
 *
 * Resolution: find `export default <identifier>`, then find that identifier's
 * `const <identifier>: Meta<...> = { ... }` declaration, then read the first
 * `title:` inside that declaration.
 */
function extractStoryTitle(src: string): string | null {
  const exportMatch = src.match(/^export default\s+(\w+)/m);
  if (!exportMatch) return null;
  const metaName = exportMatch[1];

  const declRe = new RegExp(`const\\s+${metaName}\\s*(?::\\s*Meta[^=]*)?=\\s*{`, "m");
  const declMatch = declRe.exec(src);
  if (!declMatch) return null;

  const bodyStart = declMatch.index + declMatch[0].length;
  const nextConstMatch = src.slice(bodyStart).match(/\n\s*(?:const|export)\s/);
  const bodyEnd = nextConstMatch ? bodyStart + nextConstMatch.index! : src.length;
  const body = src.slice(bodyStart, bodyEnd);

  const titleMatch = body.match(/title:\s*["'`]([^"'`]+)["'`]/);
  return titleMatch ? (titleMatch[1] ?? null) : null;
}

function startsWithAllowedRoot(title: string): boolean {
  return ALLOWED_ROOTS.some((root) => title === root || title.startsWith(`${root}/`));
}

describe("Storybook sidebar taxonomy ratchet", () => {
  it("found MDX docs and story files to scan", () => {
    expect(mdxFiles.length, "Expected to find at least 10 .storybook/*.mdx docs").toBeGreaterThan(10);
    expect(storyFiles.length, "Expected to find at least 50 *.stories.tsx files").toBeGreaterThan(50);
  });

  it("every MDX doc has a parseable <Meta title=\"...\" />", () => {
    const missing = mdxFiles.filter((f) => extractMdxTitle(fs.readFileSync(f, "utf8")) === null).map(rel);
    expect(missing, `MDX docs missing a parseable <Meta title="..." />:\n${missing.join("\n")}`).toEqual([]);
  });

  it("every .stories.tsx has a parseable meta title (no autotitle fallback)", () => {
    const missing: string[] = [];
    for (const f of storyFiles) {
      if (extractStoryTitle(fs.readFileSync(f, "utf8")) === null) missing.push(rel(f));
    }
    expect(
      missing,
      [
        "Story files with no parseable `title:` on their exported meta object.",
        "A story without an explicit title is auto-titled by Storybook and can land",
        "outside the locked taxonomy — every story must declare `title:` explicitly.",
        "Offenders:",
        ...missing.map((f) => `  ${f}`),
      ].join("\n"),
    ).toEqual([]);
  });

  it("every MDX and story title sits under one of the locked sidebar roots", () => {
    const bad: string[] = [];

    for (const f of mdxFiles) {
      const title = extractMdxTitle(fs.readFileSync(f, "utf8"));
      if (title && !startsWithAllowedRoot(title)) bad.push(`${rel(f)} :: "${title}"`);
    }
    for (const f of storyFiles) {
      const title = extractStoryTitle(fs.readFileSync(f, "utf8"));
      if (title && !startsWithAllowedRoot(title)) bad.push(`${rel(f)} :: "${title}"`);
    }

    expect(
      bad,
      [
        "Storybook titles must start with one of the locked sidebar roots:",
        ...ALLOWED_ROOTS.map((r) => `  ${r}/`),
        "Offenders (file :: title):",
        ...bad.map((f) => `  ${f}`),
      ].join("\n"),
    ).toEqual([]);
  });

  it("the five Overview docs are exactly the architect narrative set (no more, no less)", () => {
    const expected = [
      "Overview/Welcome",
      "Overview/Why a Factory",
      "Overview/Definition of Done",
      "Overview/The DBP Hierarchy",
      "Overview/Solution Catalog",
    ];

    const actual = mdxFiles
      .map((f) => extractMdxTitle(fs.readFileSync(f, "utf8")))
      .filter((t): t is string => t !== null && t.startsWith("Overview/"))
      .sort();

    expect(actual, `Overview root must contain exactly:\n${expected.join("\n")}\n\nFound:\n${actual.join("\n")}`).toEqual(
      [...expected].sort(),
    );
  });
});
