import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const execFileAsync = promisify(execFile);

/**
 * Generator emission tests.
 *
 * These run the REAL generator (scripts/scaffold-solution.mjs) against a fixture
 * SOLUTION.md that exercises the key archetype blocks, emitting into a temp
 * --out-dir (never the apps/ tree). They assert that:
 *   - each route file is emitted at the correct route-group path,
 *   - the (authenticated) layout owns the shell + nav (ADR-0027 2-shell model),
 *   - middleware is slim — no enumerated PROTECTED_PATH_PREFIXES (ADR-0027),
 *   - the emitted package.json pulls in the expected feature + shell packages,
 *   - re-running with --force is idempotent (regenerate twice → byte-identical).
 *
 * Model: 2-shell SH.PUBLIC / SH.WORKSPACE (route-group model).
 *   app/(public)/login/page.tsx   — login, unauthenticated
 *   app/(authenticated)/layout.tsx — TransactionShell + SOLUTION_NAV + auth guard
 *   app/(authenticated)/**        — body-only pages
 *   app/solution-chrome.tsx       — connected app chrome (when PS.AUTH wired)
 *
 * DWS solutions (non-DXP) have no public landing page — app/page.tsx redirects to /home.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const GENERATOR = path.join(REPO_ROOT, "scripts", "scaffold-solution.mjs");

// Fixture manifest: DWS solution exercising home, marketplace, copilot, and a module page.
// Note: no `landing:` block (DWS solutions cannot expose a public landing — DXP policy).
// Note: no top-level `nav:` block (that is for the public landing page nav, DXP only).
// Note: PS.DATA is deliberately NOT consumed. The standard-menu demo scaffold is
// gated on PS.DATA and would inject ~76 synthetic modules, each triggering a tsx
// config-validation subprocess (~85s per generator run — 3-minute test). The
// 2-shell emission contract under test (route groups, layout/shell ownership,
// middleware, nav, chrome, deps, idempotency) does not depend on that injection;
// standard-menu behaviour is covered by scripts/standard-menu-scaffold.mjs's own users.
const FIXTURE_MD = `---
platform: DWS
solution: DWS.09
name: Generator Emission Test
journey_stages: [0, 1, 2, 4]
deploy_layer: L03
consumes_platform_services: [PS.AUTH, PS.SEARCH, PS.AI, PS.AUDIT]
modules:
  - id: DWS.09.M01
    name: Work Queue
    journey: 2
    scaffold: SH.02
    nav:
      items:
        - { id: work-queue, label: Work Queue, href: /m01 }
        - { id: approvals, label: Approvals, href: /m02 }
      sections:
        # Must be a standard Feature-Area id (or listed in customNavSections) —
        # develop's generate-time nav validator rejects retired ids like "work".
        - id: workspace
          label: WORK QUEUE
          items:
            - { id: work-queue, label: Work Queue, href: /m01 }
            - { id: approvals, label: Approvals, href: /m02 }
    features:
      - id: APP.F01
        role: work-queue
        wires: [PS.SEARCH]
        config:
          entityType: task
          columns:
            - { field: title, label: Title }
            - { field: amount, label: Amount, format: currency }
  - id: DWS.09.M02
    name: Custom Workspace
    journey: 2
    scaffold: SH.02
    route: /custom-workspace
    pageComponent: solution/pages/CustomWorkspace
    composesOrganism: kanban
    features:
      - id: APP.F01
        role: custom-workspace-seed
        wires: [PS.SEARCH]
        config:
          entityType: task
          columns:
            - { field: title, label: Title }
home:
  greeting: { tagline: "Keep priorities moving." }
  hero:
    headline: "your workspace"
    headlinePrefix: "Welcome to"
    headlineAccent: "in one place."
    headlineSuffix: "Built for your team."
    artwork: "/img/home-hero-artwork.png"
  aiSearchPlaceholder: "Ask about tasks…"
  kpis:
    - { id: open-tasks, label: "Open Tasks", entityType: task, metric: { aggregate: count }, format: number, icon: FileText }
  quickLinks:
    - { id: queue, label: "Work Queue", href: /m01, icon: ListChecks, description: "Triage." }
  features:
    headline: "Everything your workspace needs"
    lead: { index: "00", title: "One workspace", description: "Everything in one hub." }
    items:
      - { icon: ListChecks, index: "01", title: "Work queue", description: "Triage tasks.", chips: ["Assignments", "Approvals"] }
  howItWorks:
    headline: "Up and running in minutes"
    steps:
      - { title: "Request access", metricValue: "< 5 min", metricLabel: "Provisioning time" }
  cta:
    headline: "Ready to get started?"
    outcomes:
      - { title: "Governed workflows", description: "Full audit trails." }
marketplace:
  entityType: service-offering
  headline: "Governed catalogue."
  itemLabel: "service"
  categories:
    - { id: data, label: "Data" }
  categoryField: category
  cardFields:
    title: name
    description: summary
    typeLabel: category
    status: status
    footerId: code
  filterFields:
    - { field: category, label: "Category" }
  detail:
    summaryField: summary
    badgeFields:
      - { field: category, style: pill }
      - { field: version, style: mono }
    tabs:
      - { id: overview, label: "Overview" }
    railActions:
      - { id: attach, label: "Attach to Task", icon: CheckSquare }
    acknowledgement: { required: true, label: "Acknowledge" }
copilot:
  eyebrow: "Ask / assist"
  title: "AI Cockpit"
  description: "Use AI to assist with your work."
  insightCards:
    - { id: open, title: "Open items", valueMetric: { entityType: task, aggregate: count }, icon: Hash }
  composerPlaceholder: "Ask about your work…"
  submitLabel: "Generate work brief"
  suggestedPrompts:
    - "Summarize my open approvals"
  entityType: task
  ragScope: workspace-knowledge
  assistantContext: { useCase: workspace }
---

# DWS.09 — Generator Emission Test fixture
`;

let tmpRoot: string;
let mdPath: string;
let outDir: string;

// Async (never execFileSync): a synchronous child spawn blocks the vitest worker's
// event loop, so the worker cannot answer the pool's onTaskUpdate RPC — vitest then
// reports "Timeout calling onTaskUpdate" as an unhandled error and exits 1 even
// with all tests green.
async function runGenerator(out: string): Promise<void> {
  await execFileAsync(process.execPath, [GENERATOR, mdPath, "--out-dir", out, "--force"], {
    cwd: REPO_ROOT,
    encoding: "utf8",
  });
}

function read(rel: string): string {
  return fs.readFileSync(path.join(outDir, rel), "utf8");
}

beforeAll(async () => {
  tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-gen-emit-"));
  mdPath = path.join(tmpRoot, "SOLUTION.md");
  outDir = path.join(tmpRoot, "out");
  fs.writeFileSync(mdPath, FIXTURE_MD, "utf8");
  await runGenerator(outDir);
}, 120_000);

afterAll(() => {
  if (tmpRoot && fs.existsSync(tmpRoot)) fs.rmSync(tmpRoot, { recursive: true, force: true });
});

describe("generator — route structure emission", () => {
  it("root page redirects to /home for non-DXP solutions (no public landing)", () => {
    const page = read("app/page.tsx");
    expect(page).toContain("// Generated by scaffold-solution");
    expect(page).toContain('redirect("/home")');
    expect(page).not.toContain("LandingShell");
    expect(page).not.toContain("LandingHero");
  });

  it("emits app/(public)/login/page.tsx with LoginPage component", () => {
    const login = read("app/(public)/login/page.tsx");
    expect(login).toContain('from "@dbp/ps-auth/client"');
    expect(login).toContain("LoginPage");
  });

  it("emits the server auth gate in layout.tsx and the shell in authenticated-client-shell.tsx", () => {
    // Audit 2.3 split: layout.tsx is a SERVER component enforcing auth via the
    // middleware-verified x-dbp-session header; the TransactionShell mount lives
    // in the client shell it wraps.
    const layout = read("app/(authenticated)/layout.tsx");
    expect(layout).not.toContain('"use client"');
    expect(layout).toContain("x-dbp-session");
    expect(layout).toContain("redirect(");
    expect(layout).toContain("AuthenticatedClientShell");

    const shell = read("app/(authenticated)/authenticated-client-shell.tsx");
    expect(shell).toContain('from "@dbp/shell-transaction"');
    expect(shell).toContain("TransactionShell");
  });

  it("emits app/(authenticated)/home/page.tsx", () => {
    expect(() => read("app/(authenticated)/home/page.tsx")).not.toThrow();
  });

  it("home page renders the APP.F12 fixed 4-section composition and never the old WorkspaceGreetingCard", () => {
    const page = read("app/(authenticated)/home/page.tsx");
    expect(page).toContain("WorkspaceHomeHero");
    expect(page).toContain("WorkspaceHomePlatform");
    expect(page).toContain("WorkspaceHomeJourney");
    expect(page).toContain("WorkspaceHomeClosing");
    expect(page).not.toContain("WorkspaceGreetingCard");
    expect(page).not.toContain("LandingFeatures");
    expect(page).not.toContain("LandingHowItWorks");
    expect(page).not.toContain("LandingCta");
  });

  it("home page passes hero.headlinePrefix/headlineSuffix/artwork through to WorkspaceHomeHero", () => {
    const page = read("app/(authenticated)/home/page.tsx");
    expect(page).toContain('headlinePrefix={"Welcome to"}');
    expect(page).toContain('headlineSuffix={"Built for your team."}');
    expect(page).toContain('artwork={"/img/home-hero-artwork.png"}');
  });

  it("home page passes home.features.lead and per-item index/chips through to WorkspaceHomePlatform, deriving kind by rotation", () => {
    const page = read("app/(authenticated)/home/page.tsx");
    expect(page).toContain('feature={{"index":"00","title":"One workspace","description":"Everything in one hub."}}');
    expect(page).toContain('"index":"01"');
    expect(page).toContain('"chips":["Assignments","Approvals"]');
    // Fixture's single item omits `kind` — the generator rotates onto "repository".
    expect(page).toContain('"kind":"repository"');
  });

  it("home page passes home.howItWorks per-step metricValue/metricLabel through to WorkspaceHomeJourney, deriving badge/stage by position", () => {
    const page = read("app/(authenticated)/home/page.tsx");
    expect(page).toContain('"metricValue":"< 5 min"');
    expect(page).toContain('"metricLabel":"Provisioning time"');
    // Fixture's single step omits `badge`/`step` — the generator derives both from position.
    expect(page).toContain('"badge":"STEP 01"');
    expect(page).toContain('"stage":"01"');
  });

  it("home page maps home.cta.outcomes onto WorkspaceHomeClosing's outcomes", () => {
    const page = read("app/(authenticated)/home/page.tsx");
    expect(page).toContain('outcomes={[{"title":"Governed workflows","description":"Full audit trails."}]}');
  });

  // Pinned to develop's current behaviour: /home wraps its sections in
  // `min-h-full -m-[var(--shell-gutter)]` so they reach the shell edges,
  // matching every other solution's /home. Whether this full-bleed escape is
  // actually correct is an OPEN QUESTION (content-box width vs. sibling
  // routes) to be settled by a browser measurement pass, not by this test —
  // see docs/09-plans/app-f12-home-redo-2026-07-27/plan.md Wave 3.
  it("home page wraps sections in the shell's negative-margin gutter escape (pinned, current develop behaviour)", () => {
    const page = read("app/(authenticated)/home/page.tsx");
    expect(page).toContain('<div className="min-h-full -m-[var(--shell-gutter)]">');
  });

  it("emits app/(authenticated)/marketplace/page.tsx with CatalogGrid", () => {
    const page = read("app/(authenticated)/marketplace/page.tsx");
    expect(page).toContain('from "@dbp/organisms/catalog-grid"');
    expect(page).toContain("CatalogGrid");
  });

  it("emits app/(authenticated)/marketplace/[id]/page.tsx with MarketplaceItemDetail", () => {
    const page = read("app/(authenticated)/marketplace/[id]/page.tsx");
    expect(page).toContain('from "@dbp/organisms/marketplace-item-detail"');
    expect(page).toContain("MarketplaceItemDetail");
  });

  it("injects titleField from listing.cardFields.title into the detail page config", () => {
    const page = read("app/(authenticated)/marketplace/[id]/page.tsx");
    // The fixture has cardFields.title = "name", so titleField must be "name".
    expect(page).toContain('"titleField": "name"');
  });

  it("emits app/(authenticated)/copilot/page.tsx with CopilotPage", () => {
    const page = read("app/(authenticated)/copilot/page.tsx");
    expect(page).toContain('from "@dbp/organisms/copilot-page"');
    expect(page).toContain("CopilotPage");
  });

  it("does NOT emit a Sparkles import in any key emitted file", () => {
    const files = [
      "app/page.tsx",
      "app/(public)/login/page.tsx",
      "app/(authenticated)/layout.tsx",
      "app/(authenticated)/authenticated-client-shell.tsx",
      "app/(authenticated)/home/page.tsx",
      "app/(authenticated)/marketplace/page.tsx",
      "app/(authenticated)/copilot/page.tsx",
    ];
    for (const f of files) {
      expect(read(f), `${f} must not import Sparkles`).not.toMatch(/Sparkles/);
    }
  });
});

describe("generator — pageComponent seam (G-SEAM/P1: composesOrganism stub)", () => {
  it("emits a composition-only stub when the module declares composesOrganism", () => {
    const stub = read("solution/pages/CustomWorkspace.tsx");
    expect(stub).toContain('from "@dbp/organisms/kanban"');
    expect(stub).toContain("Kanban");
    expect(stub).toContain("// composes: @dbp/organisms/kanban");
    expect(stub).not.toContain("Replace this stub");
    expect(stub).not.toContain("<h1");
  });

  it("still emits the thin generator-owned wrapper page for a composesOrganism module", () => {
    const page = read("app/(authenticated)/custom-workspace/page.tsx");
    expect(page).toContain("CustomWorkspace");
    expect(page).toContain('from "../../../solution/pages/CustomWorkspace"');
  });
});

describe("generator — middleware contract (ADR-0027)", () => {
  it("emits a slim middleware with session-cookie and verify-path constants", () => {
    const mw = read("middleware.ts");
    expect(mw).toContain('SESSION_COOKIE = "dbp_session"');
    expect(mw).toContain('AUTH_VERIFY_PATH = "/api/platform/auth/verify"');
  });

  it("middleware does NOT enumerate PROTECTED_PATH_PREFIXES (auth guard moved to layout)", () => {
    const mw = read("middleware.ts");
    expect(mw).not.toContain("PROTECTED_PATH_PREFIXES");
  });

  it("authenticated layout enforces auth SERVER-SIDE; client shell keeps the UX guard", () => {
    // Security boundary: the server gate redirects when the middleware-verified
    // x-dbp-session header is absent — before any authenticated markup renders.
    const layout = read("app/(authenticated)/layout.tsx");
    expect(layout).toContain("x-dbp-session");
    expect(layout).toContain("/login");
    // UX guard (session expiry mid-navigation) stays in the client shell.
    const shell = read("app/(authenticated)/authenticated-client-shell.tsx");
    expect(shell).toContain('from "@dbp/ps-auth/client"');
    expect(shell).toContain("useAuth");
    expect(shell).toContain("/login");
  });

  it("login redirect default targets /home", () => {
    const login = read("app/(public)/login/page.tsx");
    expect(login).toContain('"/home"');
  });
});

describe("generator — dependency derivation", () => {
  it("emits the required feature + shell packages in package.json", () => {
    const pkg = JSON.parse(read("package.json")) as { dependencies: Record<string, string> };
    const deps = Object.keys(pkg.dependencies);
    // Shells
    expect(deps).toContain("@dbp/shell-transaction");
    // Feature packages for each emitted archetype (post-U4: single @dbp/organisms
    // package, one dependency entry regardless of how many organisms are used)
    expect(deps).toContain("@dbp/organisms");
    // Core
    expect(deps).toContain("lucide-react");
    expect(deps).toContain("@dbp/ps-auth");
    expect(deps).toContain("@tanstack/react-query");
  });

  it("does NOT include the superseded per-page shell packages", () => {
    const pkg = JSON.parse(read("package.json")) as { dependencies: Record<string, string> };
    const deps = Object.keys(pkg.dependencies);
    expect(deps).not.toContain("@dbp/shell-marketplace");
    expect(deps).not.toContain("@dbp/shell-workbench");
  });

  it("does NOT include @dbp/shell-landing for a non-DXP solution without landing block", () => {
    const pkg = JSON.parse(read("package.json")) as { dependencies: Record<string, string> };
    const deps = Object.keys(pkg.dependencies);
    expect(deps).not.toContain("@dbp/shell-landing");
  });
});

describe("generator — --force idempotency", () => {
  it("re-generating into a second dir produces byte-identical key files", async () => {
    const outDir2 = path.join(tmpRoot, "out2");
    await runGenerator(outDir2);
    const files = [
      "app/page.tsx",
      "app/(authenticated)/layout.tsx",
      "app/(authenticated)/home/page.tsx",
      "app/(authenticated)/marketplace/page.tsx",
      "app/(authenticated)/marketplace/[id]/page.tsx",
      "app/(authenticated)/copilot/page.tsx",
      "app/(public)/login/page.tsx",
      "middleware.ts",
      "package.json",
    ];
    for (const f of files) {
      const a = fs.readFileSync(path.join(outDir, f), "utf8");
      const b = fs.readFileSync(path.join(outDir2, f), "utf8");
      expect(b, `${f} differs across regenerations`).toBe(a);
    }
    fs.rmSync(outDir2, { recursive: true, force: true });
  }, 120_000);
});

describe("generator — layout-owned nav (2-shell model)", () => {
  // In the 2-shell model, the nav constant (SOLUTION_NAV) is defined ONCE in
  // app/(authenticated)/layout.tsx — pages are body-only and never own nav state.

  it("emits SOLUTION_NAV in the authenticated client shell, not in individual module pages", () => {
    const layout = read("app/(authenticated)/authenticated-client-shell.tsx");
    expect(layout).toContain("SOLUTION_NAV");

    const modulePage = read("app/(authenticated)/m01/page.tsx");
    // Module page is body-only — it must NOT redefine a nav constant.
    expect(modulePage).not.toContain("SOLUTION_NAV");
    expect(modulePage).not.toContain("DWS09_NAV");
  });

  it("SOLUTION_NAV in the client shell includes the module nav items", () => {
    const layout = read("app/(authenticated)/authenticated-client-shell.tsx");
    expect(layout).toContain('"/m01"');
    expect(layout).toContain('"work-queue"');
  });

  it("client shell mounts SolutionChrome in the topBar slot of SOLUTION_NAV", () => {
    const layout = read("app/(authenticated)/authenticated-client-shell.tsx");
    expect(layout).toContain("topBar: <SolutionChrome />");
    expect(layout).toContain('from "../solution-chrome"');
  });

  it("preserves column `format` hints from the feature config through emission", () => {
    const page = read("app/(authenticated)/m01/page.tsx");
    // The Amount column declares format: currency in SOLUTION.md — it must survive emission.
    expect(page).toContain('"format": "currency"');
  });
});

describe("generator — connected app chrome", () => {
  it("emits app/solution-chrome.tsx when PS.AUTH is wired", () => {
    const chrome = read("app/solution-chrome.tsx");
    expect(chrome).toContain('from "@dbp/ps-auth/client"');
    expect(chrome).toContain('from "@dbp/ui"');
    expect(chrome).toContain("export function SolutionChrome");
  });

  it("mounts search/notification organisms into AppChrome's slots based on consumes_platform_services", () => {
    // The fixture wires PS.SEARCH but NOT PS.NOTIF, so the search slot is
    // populated and the notifications slot is omitted entirely.
    const chrome = read("app/solution-chrome.tsx");
    expect(chrome).toContain('import { SearchBar } from "@dbp/organisms/search-bar"');
    expect(chrome).toContain("search={");
    expect(chrome).not.toContain('import { NotificationBell } from "@dbp/organisms/notification-bell"');
    expect(chrome).not.toContain("notifications={");
  });

  it("uses the manifest solution code + name as the product lockup", () => {
    const chrome = read("app/solution-chrome.tsx");
    expect(chrome).toContain('const PRODUCT_CODE = "DWS.09"');
    expect(chrome).toContain('const PRODUCT_NAME = "Generator Emission Test"');
  });

  it("authenticated client shell imports and mounts SolutionChrome in the topBar slot", () => {
    const layout = read("app/(authenticated)/authenticated-client-shell.tsx");
    expect(layout).toContain("SolutionChrome");
    expect(layout).toContain("topBar: <SolutionChrome />");
  });
});
