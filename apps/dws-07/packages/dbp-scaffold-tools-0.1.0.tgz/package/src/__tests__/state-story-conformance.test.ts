import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * DoD §6.1 "Data / UI states" ratchet
 * (docs/03-features/specs/layout-template-definition-of-done.md).
 *
 * §6.1: "loading (skeleton), empty, error, and populated states are all
 * implemented. Test: a story per state ... no silent blank on empty/error."
 * "Renders without crashing" is explicitly NOT the bar (see the DoD's opening
 * paragraph) — a feature with only a happy-path story does not meet it.
 *
 * This is a WARN-BASELINE ratchet, not a hard gate: it allowlists every
 * feature currently missing full coverage (rather than failing CI today) so
 * the mechanism can land and prove itself; Phase B work closes the allowlist
 * over time. `alert-view` is the positive example every entry above the
 * allowlist matches: Loading, Empty, Error (Error/FetchError/ConfigError) and
 * at least one populated/default story, all as real exported Storybook
 * stories — not just "it renders".
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const FEATURES_DIR = path.join(REPO_ROOT, "packages/stack/app-scaffolds/features");

/** Relative-to-repo path of a feature's stories file → honest reason it is not (yet) conformant. */
const ALLOWLIST: Record<string, string> = {
  "packages/stack/app-scaffolds/features/approval-surface/stories/index.stories.tsx":
    "Single-entity approval instance, not a list — no empty-collection state applicable; " +
    "Loading/Error/populated are already covered. §6.1 judgment call, not a fetch gap — " +
    "see layout-template-definition-of-done.md.",
  "packages/stack/app-scaffolds/features/contact-form/stories/index.stories.tsx":
    "Form feature with no list data — no empty-collection state applicable; Loading " +
    "(SubmitLoading) and Error (ConfigError/SubmitError) are already covered. §6.1 — " +
    "layout-template-definition-of-done.md.",
  "packages/stack/app-scaffolds/features/widget-grid/stories/index.stories.tsx":
    "Config-driven widget grid — each widget independently fetches; per-widget emptiness is " +
    "handled via WidgetRenderer isolation (OneWidgetError/AllError model per-widget failure), no " +
    "page-level empty-collection concept. §6.1 — layout-template-definition-of-done.md.",
  "packages/stack/app-scaffolds/features/form-builder/stories/index.stories.tsx":
    "Form feature with no list data — no empty-collection state applicable; Loading (0.1.1 " +
    "edit-mode prefetch skeleton) and Error/populated covered. Same judgment class as " +
    "contact-form. §6.1 — layout-template-definition-of-done.md.",
  "packages/stack/app-scaffolds/features/service-offering-request/stories/index.stories.tsx":
    "Submit form with no list data — no empty-collection state applicable; Loading (0.1.2) and " +
    "Error/populated covered. Same judgment class as contact-form. §6.1 — " +
    "layout-template-definition-of-done.md.",
  "packages/stack/app-scaffolds/features/multi-step-form/stories/index.stories.tsx":
    "Wizard form with no list data — no empty-collection state applicable; Loading (definition " +
    "fetch-by-id skeleton) and Error (ConfigError)/populated covered. Same judgment class as " +
    "contact-form/form-builder. §6.1 — layout-template-definition-of-done.md.",
  "packages/stack/app-scaffolds/features/workbench-surface/stories/index.stories.tsx":
    "Single-entity workbench — no empty-collection state applicable; Loading (0.1.1) and " +
    "Error/populated covered. Same judgment class as approval-surface. §6.1 — " +
    "layout-template-definition-of-done.md.",
};
// 2026-07-11 §6 burn-down: 9 gap entries removed (real state stories landed, batches 1-3).
// The 5 remaining are one structural judgment class (no empty-collection concept) — pending
// Sharavi's G10 allowlist policy.

function rel(abs: string) {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

// One features/<name>/stories/index.stories.tsx per feature directory.
const featureDirs = fs.existsSync(FEATURES_DIR)
  ? fs
      .readdirSync(FEATURES_DIR, { withFileTypes: true })
      .filter((e) => e.isDirectory())
      .map((e) => e.name)
  : [];
const storyFiles = featureDirs
  .map((name) => path.join(FEATURES_DIR, name, "stories", "index.stories.tsx"))
  .filter((f) => fs.existsSync(f));

const LOADING_RE = /loading/i;
const EMPTY_RE = /empty/i;
const ERROR_RE = /error/i;

function storyNames(src: string): string[] {
  return [...src.matchAll(/export const (\w+)/g)]
    .map((m) => m[1])
    .filter((name): name is string => name !== undefined);
}

/** Does this stories file have a Loading-, Empty-, Error-equivalent AND at least one populated/default export? */
function coverage(names: string[]) {
  const hasLoading = names.some((n) => LOADING_RE.test(n));
  const hasEmpty = names.some((n) => EMPTY_RE.test(n));
  const hasError = names.some((n) => ERROR_RE.test(n));
  const hasPopulated = names.some((n) => !LOADING_RE.test(n) && !EMPTY_RE.test(n) && !ERROR_RE.test(n));
  return { hasLoading, hasEmpty, hasError, hasPopulated };
}

function isConformant(abs: string): boolean {
  const { hasLoading, hasEmpty, hasError, hasPopulated } = coverage(storyNames(fs.readFileSync(abs, "utf8")));
  return hasLoading && hasEmpty && hasError && hasPopulated;
}

describe("DoD §6.1 data/UI-state story conformance", () => {
  it("finds the feature story files to scan", () => {
    expect(featureDirs.length).toBeGreaterThan(15);
    expect(storyFiles.length).toBeGreaterThan(15);
  });

  it("every feature without a documented §6.1 gap has Loading + Empty + Error + Populated story coverage", () => {
    const violations: string[] = [];
    for (const abs of storyFiles) {
      const r = rel(abs);
      if (ALLOWLIST[r]) continue;
      const { hasLoading, hasEmpty, hasError, hasPopulated } = coverage(storyNames(fs.readFileSync(abs, "utf8")));
      const missing = [
        !hasLoading && "Loading",
        !hasEmpty && "Empty",
        !hasError && "Error",
        !hasPopulated && "Populated/Default",
      ].filter(Boolean);
      if (missing.length > 0) violations.push(`${r}: missing ${missing.join(", ")}`);
    }
    expect(
      violations,
      `DoD §6.1 (docs/03-features/specs/layout-template-definition-of-done.md) — story state gaps:\n${violations.join("\n")}`,
    ).toEqual([]);
  });

  it("every allowlisted feature has an honest, non-empty reason referencing the DoD", () => {
    for (const [relPath, reason] of Object.entries(ALLOWLIST)) {
      expect(reason.length, `empty/too-short allowlist reason for ${relPath}`).toBeGreaterThan(20);
      expect(
        /§6\.1|layout-template-definition-of-done\.md/.test(reason),
        `allowlist reason for ${relPath} does not reference the DoD §6.1: "${reason}"`,
      ).toBe(true);
    }
  });

  it("allowlist entries still exist and are still missing full coverage (prune stale allowlist)", () => {
    for (const [relPath, reason] of Object.entries(ALLOWLIST)) {
      const abs = path.join(REPO_ROOT, relPath);
      expect(fs.existsSync(abs), `allowlisted file missing: ${relPath}`).toBe(true);
      expect(
        isConformant(abs),
        `allowlist entry no longer needed (remove it): ${relPath} — ${reason}`,
      ).toBe(false);
    }
  });
});
