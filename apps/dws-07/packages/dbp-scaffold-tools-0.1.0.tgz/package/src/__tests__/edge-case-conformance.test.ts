import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Edge-case fixture ratchet (docs/03-features/specs/layout-template-definition-of-done.md
 * §6.8 "Edge cases" — long text, overflow, very many / very few items, missing optional
 * data must all be handled; Test: edge-case Storybook fixtures + a no-horizontal-body-
 * overflow Playwright assertion).
 *
 * This is the static half of that DoD line: a story-coverage check. It does NOT verify
 * that a story actually renders without overflow (that is a separate Playwright
 * assertion) — it only verifies each feature's Storybook file HAS at least one story
 * that plausibly exercises an edge case, via a best-effort static heuristic:
 *
 *   - an exported story name matching /long|overflow|many|empty|zero|max|edge/i, OR
 *   - a string literal longer than 80 chars anywhere in the file (long-text fixture), OR
 *   - an array literal with more than 20 elements anywhere in the file (many-items fixture)
 *
 * Features that don't yet have a qualifying story are tracked in the allowlist below
 * (WARN-BASELINE — ratchets forward as fixtures are added, never silently loosens).
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const FEATURES_DIR = path.join(REPO_ROOT, "packages/stack/app-scaffolds/features");

const GAP_REASON =
  "§6.8 gap — tracked in layout-template-definition-of-done.md, needs long-text/overflow/many-items fixture";

/** Relative-to-repo path → reason it has no edge-case story yet. */
const ALLOWLIST: Record<string, string> = {
  "packages/stack/app-scaffolds/features/approval-surface/stories/index.stories.tsx": GAP_REASON,
  "packages/stack/app-scaffolds/features/widget-grid/stories/index.stories.tsx": GAP_REASON,
};
// 2026-07-11 §6 burn-down: 7 entries removed (real edge fixtures landed: case-workspace,
// entity-detail, form-builder, kpi-scorecard, service-offering-request, sla-tracking,
// workflow-binding). approval-surface + widget-grid remain pending Sharavi's G10 policy.

function rel(abs: string) {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

function listFiles(dir: string, predicate: (f: string) => boolean): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listFiles(abs, predicate));
    else if (predicate(abs)) out.push(abs);
  }
  return out;
}

// Every features/<name>/stories/index.stories.tsx
const storyFiles = listFiles(
  FEATURES_DIR,
  (f) => f.endsWith(path.join("stories", "index.stories.tsx")),
);

const EDGE_CASE_NAME_RE = /long|overflow|many|empty|zero|max|edge/i;
const LONG_STRING_RE = /["'`][^"'`\n]{80,}["'`]/;
const ARRAY_FROM_LENGTH_RE = /Array\.from\(\s*\{\s*length:\s*(\d+)/g;
const MANY_ITEMS_THRESHOLD = 20;

/**
 * Best-effort array-literal size check: tracks bracket nesting so that commas inside
 * a nested object (`{ id: 1, name: "x" }`) are attributed to that object, not the
 * enclosing array — only commas directly inside a `[...]` frame count as elements.
 * Does not parse strings/comments, so bracket-like characters inside them can skew
 * the count; acceptable for a static, best-effort heuristic.
 */
function hasLargeArrayLiteral(src: string, threshold: number): boolean {
  const stack: { isArray: boolean; commas: number }[] = [];
  for (const ch of src) {
    if (ch === "[" || ch === "{") {
      stack.push({ isArray: ch === "[", commas: 0 });
    } else if (ch === "]" || ch === "}") {
      const top = stack.pop();
      if (top?.isArray && top.commas + 1 > threshold) return true;
    } else if (ch === ",") {
      const top = stack[stack.length - 1];
      if (top) top.commas++;
    }
  }
  return false;
}

function hasEdgeCaseStory(src: string): boolean {
  const storyNames = [...src.matchAll(/export const (\w+)/g)]
    .map((m) => m[1])
    .filter((name): name is string => name !== undefined);
  if (storyNames.some((name) => EDGE_CASE_NAME_RE.test(name))) return true;
  if (LONG_STRING_RE.test(src)) return true;
  for (const m of src.matchAll(ARRAY_FROM_LENGTH_RE)) {
    if (Number(m[1]) > MANY_ITEMS_THRESHOLD) return true;
  }
  if (hasLargeArrayLiteral(src, MANY_ITEMS_THRESHOLD)) return true;
  return false;
}

function missingEdgeCaseCoverage(files: string[]): string[] {
  const found: string[] = [];
  for (const abs of files) {
    const r = rel(abs);
    if (ALLOWLIST[r]) continue;
    const src = fs.readFileSync(abs, "utf8");
    if (!hasEdgeCaseStory(src)) found.push(r);
  }
  return found;
}

describe("edge-case fixture conformance (DoD §6.8)", () => {
  it("finds the feature story files to scan", () => {
    expect(storyFiles.length).toBeGreaterThan(10);
  });

  it("every non-allowlisted feature has at least one edge-case-flavored story", () => {
    const found = missingEdgeCaseCoverage(storyFiles);
    expect(
      found,
      `Missing edge-case story coverage — see docs/03-features/specs/layout-template-definition-of-done.md §6.8:\n${found.join("\n")}`,
    ).toEqual([]);
  });

  it("allowlist entries still exist and still lack edge-case story coverage (prune stale allowlist)", () => {
    for (const [relPath, reason] of Object.entries(ALLOWLIST)) {
      const abs = path.join(REPO_ROOT, relPath);
      expect(fs.existsSync(abs), `allowlisted file missing: ${relPath}`).toBe(true);
      const src = fs.readFileSync(abs, "utf8");
      expect(
        hasEdgeCaseStory(src),
        `allowlist entry no longer needed (remove it): ${relPath} — ${reason}`,
      ).toBe(false);
    }
  });
});
