import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
// @ts-expect-error — plain .mjs script module, no types
import { findUncoveredTables, loadAllowlist, findMigrationSets, ALLOWLIST_PATH } from "../../../../../scripts/check-tenant-rls-coverage.mjs";

/**
 * GG-26: tenant-isolation coverage gate tests.
 *
 * The two real omissions this gate exists to catch (grc.maturity_target,
 * grc.policy_documents) live in a GRC solution repo not reachable from this
 * checkout (confirmed: no `db/migrations/grc/**` path exists anywhere in this
 * repo's history, on any branch). These fixtures reproduce the SAME shape
 * instead: a mutable, tenant-scoped table with an insert/update grant and no
 * RLS, created in the same migration set as genuinely tenant-agnostic
 * select-only reference tables — the exact proximity that caused the real
 * omission twice.
 */

const REPO_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../../../..");

// ─── fixture (a): mirrors the maturity_target shape — FAIL ────────────────
const FIXTURE_A_MIGRATION = `
-- reference tables: genuinely tenant-agnostic, select-only, no tenant_id
create table grc.rating_scale (
  id    text primary key,
  label text not null
);

create table grc.rating_level (
  id       text primary key,
  scale_id text not null references grc.rating_scale(id)
);

-- mutable, tenant-scoped business data sitting right next to the reference
-- tables above — this is the shape that got missed twice.
create table grc.maturity_target (
  id                    uuid primary key default gen_random_uuid(),
  tenant_id             text not null references iam.tenant(id) on delete cascade,
  authority_document_id text not null,
  target_level          int  not null,
  unique (tenant_id, authority_document_id)
);
grant select, insert, update on grc.maturity_target to dbp_app;
grant select on grc.rating_scale to dbp_app;
grant select on grc.rating_level to dbp_app;
`;

// ─── fixture (b): correctly isolated table — PASS ──────────────────────────
const FIXTURE_B_CREATE = `
create table grc.policy_documents (
  id        uuid primary key default gen_random_uuid(),
  tenant_id text not null references iam.tenant(id) on delete cascade,
  title     text not null
);
`;
const FIXTURE_B_RLS = `
alter table grc.policy_documents enable row level security;
create policy tenant_isolation on grc.policy_documents
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());
`;

// ─── fixture (c): allowlisted reference table — PASS ───────────────────────
const FIXTURE_C_MIGRATION = `
-- GLOBAL default with an optional tenant override (nullable tenant_id) —
-- deliberately exempt, declared in infra/05-policy/tenant-rls-allowlist.json.
create table rbac.role (
  id        text primary key,
  label     text not null,
  tenant_id text references iam.tenant(id) on delete cascade
);
`;

describe("GG-26: tenant-RLS coverage gate", () => {
  it("fixture (a): a mutable tenant_id table with no RLS FAILS", () => {
    const uncovered = findUncoveredTables([
      { path: "fixture/0050_grc_maturity_scale_scoped.sql", text: FIXTURE_A_MIGRATION },
    ]);
    expect(uncovered).toContain("grc.maturity_target");
    // the tenant-agnostic reference tables must NOT be flagged
    expect(uncovered).not.toContain("grc.rating_scale");
    expect(uncovered).not.toContain("grc.rating_level");
  });

  it("fixture (b): a table with RLS enabled + a matching tenant_isolation policy PASSES", () => {
    const uncovered = findUncoveredTables([
      { path: "fixture/0068a_grc_policy_documents.sql", text: FIXTURE_B_CREATE },
      { path: "fixture/0068b_grc_policy_documents_rls.sql", text: FIXTURE_B_RLS },
    ]);
    expect(uncovered).not.toContain("grc.policy_documents");
  });

  it("fixture (b) proves the check WOULD have caught policy_documents pre-fix (RLS file omitted)", () => {
    const uncovered = findUncoveredTables([
      { path: "fixture/0068a_grc_policy_documents.sql", text: FIXTURE_B_CREATE },
    ]);
    expect(uncovered).toContain("grc.policy_documents");
  });

  it("fixture (c): a table with tenant_id and no RLS is uncovered by the raw scan, but allowlisted", () => {
    const uncovered = findUncoveredTables([
      { path: "fixture/0000_rbac_role.sql", text: FIXTURE_C_MIGRATION },
    ]);
    expect(uncovered).toContain("rbac.role");

    const allowlist = loadAllowlist();
    expect(allowlist["rbac.role"]).toBeTruthy();
    expect(allowlist["rbac.role"].length).toBeGreaterThan(10);
  });

  it("the real allowlist file exists, is valid JSON, and every entry has a real reason", () => {
    expect(fs.existsSync(ALLOWLIST_PATH), `missing ${ALLOWLIST_PATH}`).toBe(true);
    const allowlist: Record<string, string> = loadAllowlist();
    for (const [table, reason] of Object.entries(allowlist)) {
      expect(typeof reason, `${table}: reason must be a string`).toBe("string");
      expect(reason.length, `${table}: reason too short`).toBeGreaterThan(10);
    }
  });

  it("end-to-end: the live repo's migration sets pass the gate (allowlist applied)", () => {
    const sets: Map<string, string[]> = findMigrationSets(REPO_ROOT);
    const allowlist: Record<string, string> = loadAllowlist();
    const failures: string[] = [];

    for (const [dir, relFiles] of sets.entries()) {
      const files = relFiles.map((rel: string) => ({
        path: rel,
        text: fs.readFileSync(path.join(REPO_ROOT, rel), "utf8"),
      }));
      const uncovered = findUncoveredTables(files).filter((t: string) => !allowlist[t]);
      for (const table of uncovered) failures.push(`${table} (${dir})`);
    }

    expect(failures, `uncovered tenant_id tables:\n${failures.join("\n")}`).toEqual([]);
  });
});
