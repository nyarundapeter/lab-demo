import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Page-frame ownership guard (docs/PAGE-FRAME-OWNERSHIP-CONTRACT.md).
 *
 * A component rendered into a shell slot is BODY-ONLY: the shell `main` owns the
 * gutter, max-width and background. Features/layouts must NOT paint their own page
 * frame, or they double-pad and re-background (the recurring "double padding" bug).
 *
 * This test ratchets the current clean state: it bans the page-frame tells in
 * feature roots and transaction layout bodies. Known, tracked exceptions are
 * allowlisted with a reason — add to the allowlist ONLY with a docs reference,
 * never silently.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const FEATURES_DIR = path.join(REPO_ROOT, "packages/stack/app-scaffolds/features");
const LAYOUTS_DIR = path.join(REPO_ROOT, "packages/stack/app-scaffolds/shells/transaction/layouts");

/** Relative-to-repo path → reason it is allowed to keep a page-frame class. */
const ALLOWLIST: Record<string, string> = {
  // Self-headered chat layout: no flush PageHeader above it, so its own px gutter
  // is not a double gutter. (Copilot now uses WorkingLayout; this stays for chat.)
  "packages/stack/app-scaffolds/shells/transaction/layouts/conversational.tsx": "px-6 — self-headered chat, single gutter",
};

function rel(abs: string) {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

function listFiles(dir: string, predicate: (f: string) => boolean): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listFiles(abs, predicate));
    else if (predicate(abs)) out.push(abs);
  }
  return out;
}

// Feature roots: every features/<name>/index.tsx
const featureFiles = listFiles(FEATURES_DIR, (f) => f.endsWith(path.join("", "index.tsx")) && path.basename(f) === "index.tsx" && path.basename(path.dirname(path.dirname(f))) === "features");
// Transaction layout bodies: layouts/*.tsx
const layoutFiles = listFiles(LAYOUTS_DIR, (f) => f.endsWith(".tsx") && !f.endsWith(".stories.tsx"));

/**
 * Page-frame tells. `min-h-full` is allowed (fills the shell main).
 *
 * `min-h-screen` and `mx-auto max-w-[` are high-signal: a body-only component has
 * no reason to own full viewport height or centre itself. They apply everywhere.
 *
 * `px-6 / px-8` is only banned on LAYOUT bodies — inside features it is commonly
 * legitimate (composer bars, chips, conditional standalone frames), so scanning
 * feature files for it false-positives (e.g. copilot's `externalHeader ? "" : …px-8`).
 */
const FRAME_BANNED = [
  { label: "min-h-screen (page owns full viewport height)", re: /\bmin-h-screen\b/ },
  { label: "mx-auto max-w-[…] (page owns its own centering/width)", re: /\bmx-auto\s+max-w-\[/ },
];
const LAYOUT_EXTRA_BANNED = [
  { label: "outer px-6/px-8 (double gutter on top of the shell)", re: /\bpx-[68]\b/ },
];

function violations(files: string[], rules: { label: string; re: RegExp }[]) {
  const found: string[] = [];
  for (const abs of files) {
    const r = rel(abs);
    if (ALLOWLIST[r]) continue;
    const src = fs.readFileSync(abs, "utf8");
    for (const { label, re } of rules) {
      if (re.test(src)) found.push(`${r}: ${label}`);
    }
  }
  return found;
}

describe("page-frame ownership contract", () => {
  it("finds the feature files to scan", () => {
    expect(featureFiles.length).toBeGreaterThan(10);
    expect(layoutFiles.length).toBeGreaterThan(4);
  });

  it("no feature root paints its own page frame (min-h-screen / mx-auto max-w)", () => {
    const found = violations(featureFiles, FRAME_BANNED);
    expect(found, `Page-frame violations — see docs/PAGE-FRAME-OWNERSHIP-CONTRACT.md:\n${found.join("\n")}`).toEqual([]);
  });

  it("no transaction layout body adds a page frame (incl. outer px-6/8)", () => {
    const found = violations(layoutFiles, [...FRAME_BANNED, ...LAYOUT_EXTRA_BANNED]);
    expect(found, `Page-frame violations — see docs/PAGE-FRAME-OWNERSHIP-CONTRACT.md:\n${found.join("\n")}`).toEqual([]);
  });

  it("allowlist entries still exist and still violate (prune stale allowlist)", () => {
    const ALL_RULES = [...FRAME_BANNED, ...LAYOUT_EXTRA_BANNED];
    for (const [relPath, reason] of Object.entries(ALLOWLIST)) {
      const abs = path.join(REPO_ROOT, relPath);
      expect(fs.existsSync(abs), `allowlisted file missing: ${relPath}`).toBe(true);
      const src = fs.readFileSync(abs, "utf8");
      const stillViolates = ALL_RULES.some(({ re }) => re.test(src));
      expect(stillViolates, `allowlist entry no longer needed (remove it): ${relPath} — ${reason}`).toBe(true);
    }
  });
});
