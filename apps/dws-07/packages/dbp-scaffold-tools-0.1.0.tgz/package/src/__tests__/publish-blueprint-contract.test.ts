import { describe, it, expect, beforeAll, afterAll } from "vitest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";

/**
 * Publication-layer contract test — the G13 acceptance test for F1.
 *
 * The generator's own contract only protects the tree it runs against; G13's wipe
 * happened one hop downstream, in the publish step that overlays a generated app onto
 * a *separate* standalone repo. `scripts/publish-blueprint.mjs` (F1) makes that step
 * contract-aware by classifying against the app's emitted generator-owned.json. This
 * test builds a fake app + a fake standalone target that already contains hand-authored
 * work, runs the publish, and asserts the hand work survives, generator-owned chrome is
 * refreshed, stale generator-owned files are swept, and blueprint-release.json is
 * accurate — plus the fail-closed guards.
 *
 * See docs/99-archive/plans/factory-generator-g13/g13-f1-contract-aware-publication-spec-2026-07-04.md.
 */

const __filename = fileURLToPath(import.meta.url);
// __tests__ → src → scaffold-tools → shared → packages → repo root (5 up).
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const MODULE_PATH = path.join(REPO_ROOT, "scripts", "publish-blueprint.mjs");

type Manifest = {
  schema: string;
  created: string[];
  overwritten: string[];
  preserved: string[];
  deleted: string[] | null;
  blueprint_version: string;
  generator_rev: string;
  generated_at: string;
};
let publishBlueprint: (opts: { appDir: string; targetDir: string; dryRun?: boolean }) => Manifest;

let tmpRoot: string;
let appDir: string;
let targetDir: string;
let manifest: Manifest;

const HAND_ENTITY = `// HAND-AUTHORED compliance obligation — MUST SURVIVE publish.
import { z } from "zod";
export const ComplianceObligationSchema = z.object({
  name: z.string(),
  regulator: z.enum(["SAMA", "CMA", "ZATCA", "NCA", "internal"]),
  status: z.enum(["compliant", "non-compliant", "under-review"]),
  code: z.string(),
});
export type ComplianceObligation = z.infer<typeof ComplianceObligationSchema>;
`;
const HAND_PAGE = `// HAND-WIRED obligations workspace page — MUST SURVIVE publish.
export default function ObligationsPage() {
  return <div>Obligations</div>;
}
`;
const STALE_PAGE = "// stale generator-owned page from a previous publish\nexport default function Legacy() { return null; }\n";
const OLD_MIDDLEWARE = "// OLD generator-owned middleware — should be overwritten\n";
const NEW_MIDDLEWARE = "// FRESH generator-owned middleware from this emission\n";
const NEW_DASHBOARD = "// generator-owned dashboard page (new this emission)\nexport default function D() { return null; }\n";
const NEW_SOLUTION_MD = "---\ntitle: Solution\n---\ngenerator_rev: abc1234\n";

// The app's emitted ownership manifest — exactly the generator-owned paths for this run.
const NEW_OWNED = [
  "solution/_arch/SOLUTION.md",
  "solution/_arch/generator-owned.json",
  "middleware.ts",
  "app/(authenticated)/dashboard/page.tsx",
];
// The target's OLD manifest — lists a now-stale page the new emission no longer produces.
const OLD_OWNED = ["middleware.ts", "app/(authenticated)/legacy/page.tsx"];

function writeFile(base: string, rel: string, content: string): void {
  const abs = path.join(base, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, content, "utf8");
}
function readFile(base: string, rel: string): string {
  return fs.readFileSync(path.join(base, rel), "utf8");
}
function present(base: string, rel: string): boolean {
  return fs.existsSync(path.join(base, rel));
}

beforeAll(async () => {
  publishBlueprint = (await import(pathToFileURL(MODULE_PATH).href)).publishBlueprint;

  tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-publish-contract-"));
  appDir = path.join(tmpRoot, "app-src");
  targetDir = path.join(tmpRoot, "standalone");

  // ── Fake generated app (source) ──
  writeFile(appDir, "solution/_arch/generator-owned.json", JSON.stringify(NEW_OWNED, null, 2));
  writeFile(appDir, "solution/_arch/SOLUTION.md", NEW_SOLUTION_MD);
  writeFile(appDir, "middleware.ts", NEW_MIDDLEWARE);
  writeFile(appDir, "app/(authenticated)/dashboard/page.tsx", NEW_DASHBOARD);

  // ── Fake standalone target with pre-existing hand work + stale state ──
  writeFile(targetDir, "solution/entities/compliance-obligation.ts", HAND_ENTITY); // hand-authored, only in target
  writeFile(targetDir, "app/(authenticated)/obligations/page.tsx", HAND_PAGE); // hand-wired, only in target
  writeFile(targetDir, "middleware.ts", OLD_MIDDLEWARE); // generator-owned, differs → overwrite
  writeFile(targetDir, "app/(authenticated)/legacy/page.tsx", STALE_PAGE); // stale generator-owned → delete
  writeFile(targetDir, "solution/_arch/generator-owned.json", JSON.stringify(OLD_OWNED, null, 2));

  manifest = publishBlueprint({ appDir, targetDir });
}, 60_000);

afterAll(() => {
  if (tmpRoot && fs.existsSync(tmpRoot)) fs.rmSync(tmpRoot, { recursive: true, force: true });
});

describe("publish-blueprint — contract-aware preservation (G13 F1 acceptance)", () => {
  it("preserves a hand-authored solution-owned entity byte-for-byte", () => {
    expect(readFile(targetDir, "solution/entities/compliance-obligation.ts")).toBe(HAND_ENTITY);
    expect(manifest.preserved).toContain("solution/entities/compliance-obligation.ts");
  });

  it("preserves a hand-wired page absent from the generated app", () => {
    expect(readFile(targetDir, "app/(authenticated)/obligations/page.tsx")).toBe(HAND_PAGE);
    expect(manifest.preserved).toContain("app/(authenticated)/obligations/page.tsx");
  });

  it("overwrites a differing generator-owned file", () => {
    expect(readFile(targetDir, "middleware.ts")).toBe(NEW_MIDDLEWARE);
    expect(manifest.overwritten).toContain("middleware.ts");
  });

  it("creates a generator-owned file new to the target", () => {
    expect(present(targetDir, "app/(authenticated)/dashboard/page.tsx")).toBe(true);
    expect(manifest.created).toContain("app/(authenticated)/dashboard/page.tsx");
  });

  it("sweeps a stale generator-owned file (old ∖ new manifest)", () => {
    expect(present(targetDir, "app/(authenticated)/legacy/page.tsx")).toBe(false);
    expect(manifest.deleted).toContain("app/(authenticated)/legacy/page.tsx");
  });

  it("never deletes anything outside the old generator-owned manifest", () => {
    // The hand-wired page + hand-authored entity are not in OLD_OWNED, so they can
    // never appear in the deletion set — the core G13 guarantee.
    expect(manifest.deleted).not.toContain("app/(authenticated)/obligations/page.tsx");
    expect(manifest.deleted).not.toContain("solution/entities/compliance-obligation.ts");
  });
});

describe("publish-blueprint — provenance (F2)", () => {
  it("stamps generator_rev from the app's SOLUTION.md", () => {
    expect(manifest.generator_rev).toBe("abc1234");
  });

  it("writes blueprint-release.json with an ISO generated_at at the target root", () => {
    expect(present(targetDir, "blueprint-release.json")).toBe(true);
    const release = JSON.parse(readFile(targetDir, "blueprint-release.json"));
    expect(release.generator_rev).toBe("abc1234");
    expect(release.generated_at).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/);
    expect(release.schema).toBe("dbp-blueprint-release/1");
  });
});

describe("publish-blueprint — fails closed", () => {
  it("throws when the target directory does not exist", () => {
    expect(() => publishBlueprint({ appDir, targetDir: path.join(tmpRoot, "does-not-exist") })).toThrow();
  });

  it("throws when the app has no generator-owned.json (cannot classify)", () => {
    const bareApp = path.join(tmpRoot, "bare-app");
    fs.mkdirSync(bareApp, { recursive: true });
    expect(() => publishBlueprint({ appDir: bareApp, targetDir })).toThrow();
  });
});
