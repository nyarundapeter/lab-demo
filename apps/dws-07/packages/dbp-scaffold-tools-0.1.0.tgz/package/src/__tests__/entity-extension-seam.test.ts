import { describe, it, expect, afterEach } from "vitest";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const execFileAsync = promisify(execFile);

/**
 * GG-01 entity-schema extension seam tests.
 * docs/09-plans/stcb-generator-gaps-triage-2026-07-25.md GG-01
 *
 * Runs the REAL generator (scripts/scaffold-solution.mjs) against fixture SOLUTION.md
 * manifests declaring manifest.entities, asserting:
 *   - solution/entities/extensions.ts is emitted with a per-type `<TypePascal>Extensions`
 *     z.object() overlay, and the generated solution/entities/<type>.ts merges it onto
 *     the base schema (BaseSchema.merge(Extensions)) instead of emitting a closed schema,
 *   - extensions.ts is create-if-missing: a hand-added field survives a --force regen
 *     byte-for-byte, and the field it added is present in the generated schema's merge,
 *   - a hand-added extension field colliding with a manifest.entities[].fields name for
 *     the same type fails generation with a clear error (checked before any write).
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const GENERATOR = path.join(REPO_ROOT, "scripts", "scaffold-solution.mjs");

const tmpDirs: string[] = [];

function makeTmp(): { tmpRoot: string; mdPath: string; outDir: string } {
  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-gen-ext-"));
  tmpDirs.push(tmpRoot);
  return {
    tmpRoot,
    mdPath: path.join(tmpRoot, "SOLUTION.md"),
    outDir: path.join(tmpRoot, "out"),
  };
}

async function runGenerator(mdPath: string, out: string): Promise<void> {
  await execFileAsync(process.execPath, [GENERATOR, mdPath, "--out-dir", out, "--force"], {
    cwd: REPO_ROOT,
    encoding: "utf8",
  });
}

function baseManifest(extra: string): string {
  return `---
platform: DWS
solution: DWS.09
name: Entity Extension Seam Test
journey_stages: [2]
deploy_layer: L03
consumes_platform_services: [PS.DATA]
modules:
  - id: DWS.09.M01
    name: Work Queue
    journey: 2
    scaffold: SH.02
    features:
      - id: APP.F01
        role: work-queue
        wires: [PS.DATA]
        config:
          entityType: task
          columns:
            - { field: title, label: Title }
${extra}
---

# DWS.09 — Entity Extension Seam Test fixture
`;
}

afterEach(() => {
  for (const dir of tmpDirs.splice(0)) {
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
  }
});

describe("generator — GG-01 entity extension seam", () => {
  it("emits extensions.ts and merges it onto the generated entity schema, and preserves hand-added fields across --force regen", async () => {
    const { mdPath, outDir } = makeTmp();
    const manifest = baseManifest(`entities:
  - type: task
    fields:
      - { name: title, type: string, required: true }
`);
    fs.writeFileSync(mdPath, manifest, "utf8");
    await runGenerator(mdPath, outDir);

    const extensionsPath = path.join(outDir, "solution/entities/extensions.ts");
    expect(fs.existsSync(extensionsPath)).toBe(true);
    const extensionsContent = fs.readFileSync(extensionsPath, "utf8");
    expect(extensionsContent).toContain("export const TaskExtensions = z.object({");

    const taskSchemaPath = path.join(outDir, "solution/entities/task.ts");
    const taskSchemaContent = fs.readFileSync(taskSchemaPath, "utf8");
    expect(taskSchemaContent).toContain('import { TaskExtensions } from "./extensions.js";');
    expect(taskSchemaContent).toContain("TaskBaseSchema.merge(TaskExtensions)");

    // Hand-add a field a solution needs but the manifest doesn't declare (e.g.
    // maturityLevel) — this is exactly the GG-01 repro scenario.
    const handEdited = extensionsContent.replace(
      "export const TaskExtensions = z.object({\n  // Example: maturityLevel: z.string().optional(),\n});",
      "export const TaskExtensions = z.object({\n  maturityLevel: z.string().optional(),\n});",
    );
    expect(handEdited).not.toBe(extensionsContent); // sanity: replacement actually matched
    fs.writeFileSync(extensionsPath, handEdited, "utf8");

    // Regen: extensions.ts is create-if-missing, so the hand-added field must survive
    // byte-for-byte, and the (always-overwritten) task.ts must still merge it in.
    await runGenerator(mdPath, outDir);
    expect(fs.readFileSync(extensionsPath, "utf8")).toBe(handEdited);
    const taskSchemaAfterRegen = fs.readFileSync(taskSchemaPath, "utf8");
    expect(taskSchemaAfterRegen).toContain("TaskBaseSchema.merge(TaskExtensions)");
  }, 480_000);

  it("fails generation when a hand-added extension field collides with a manifest.entities[].fields name", async () => {
    const { mdPath, outDir } = makeTmp();
    const manifest = baseManifest(`entities:
  - type: task
    fields:
      - { name: title, type: string, required: true }
`);
    fs.writeFileSync(mdPath, manifest, "utf8");

    // First run creates extensions.ts (empty stub).
    await runGenerator(mdPath, outDir);
    const extensionsPath = path.join(outDir, "solution/entities/extensions.ts");

    // Hand-add a field that collides with the manifest-declared "title" field.
    const collidingContent = fs.readFileSync(extensionsPath, "utf8").replace(
      "export const TaskExtensions = z.object({\n  // Example: maturityLevel: z.string().optional(),\n});",
      "export const TaskExtensions = z.object({\n  title: z.string().optional(),\n});",
    );
    fs.writeFileSync(extensionsPath, collidingContent, "utf8");

    await expect(runGenerator(mdPath, outDir)).rejects.toThrow(/GG-01/);
  }, 480_000);
});
