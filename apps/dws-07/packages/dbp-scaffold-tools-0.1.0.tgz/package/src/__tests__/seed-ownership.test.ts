import { describe, it, expect, afterEach } from "vitest";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const execFileAsync = promisify(execFile);

/**
 * Seed / migration ownership emission tests (STCB GG-06/GG-07/GG-22).
 * docs/09-plans/seed-migration-ownership-design-2026-07-25.md
 *
 * Runs the REAL generator (scripts/scaffold-solution.mjs) against fixture
 * SOLUTION.md manifests exercising manifest.entities + seed, asserting:
 *   - seedData() is emitted with a row-existence gate (bulk list()-per-type probe),
 *     not the old memory-only-gated unconditional upsert (GG-06/GG-07),
 *   - seedPolicy threads through into the emitted seedData() calls,
 *   - a fixture id colliding across two entity types fails generation with a
 *     clear message (the collision guard added alongside the composite
 *     (type, id) identity fix in @dbp/platform-db),
 *   - solutionOwnedOverrides for solution/fixtures/seed.ts is honoured
 *     (create-if-missing, GG-22) instead of unconditionally overwritten.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const GENERATOR = path.join(REPO_ROOT, "scripts", "scaffold-solution.mjs");

const tmpDirs: string[] = [];

function makeTmp(): { tmpRoot: string; mdPath: string; outDir: string } {
  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-gen-seed-"));
  tmpDirs.push(tmpRoot);
  return {
    tmpRoot,
    mdPath: path.join(tmpRoot, "SOLUTION.md"),
    outDir: path.join(tmpRoot, "out"),
  };
}

async function runGenerator(mdPath: string, out: string, extraArgs: string[] = []): Promise<void> {
  await execFileAsync(process.execPath, [GENERATOR, mdPath, "--out-dir", out, "--force", ...extraArgs], {
    cwd: REPO_ROOT,
    encoding: "utf8",
  });
}

function baseManifest(extra: string): string {
  return `---
platform: DWS
solution: DWS.09
name: Seed Ownership Test
journey_stages: [2]
deploy_layer: L03
consumes_platform_services: [PS.DATA]
modules:
  - id: DWS.09.M01
    name: Work Queue
    journey: 2
    scaffold: SH.02
    features:
      - id: APP.F01
        role: work-queue
        wires: [PS.DATA]
        config:
          entityType: task
          columns:
            - { field: title, label: Title }
${extra}
---

# DWS.09 — Seed Ownership Test fixture
`;
}

afterEach(() => {
  for (const dir of tmpDirs.splice(0)) {
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
  }
});

describe("generator — seedData() row-existence gate emission", () => {
  it("emits a bulk list()-based existence gate, threading seedPolicy through per type", async () => {
    const { mdPath, outDir } = makeTmp();
    const manifest = baseManifest(`entities:
  - type: task
    fields:
      - { name: title, type: string, required: true }
    seed:
      - { id: task-0001, data: { title: Demo Task } }
  - type: audit-note
    fields:
      - { name: title, type: string, required: true }
    seedPolicy: always
    seed:
      - { id: note-0001, data: { title: Demo Note } }
`);
    fs.writeFileSync(mdPath, manifest, "utf8");
    await runGenerator(mdPath, outDir);

    const seedTs = fs.readFileSync(path.join(outDir, "solution/fixtures/seed.ts"), "utf8");

    // Row-existence gate: no more memory-only `kind === "memory"` branch.
    expect(seedTs).not.toContain('kind === "memory"');
    // Bulk list()-per-type probe, diffed client-side (not a per-record get()).
    expect(seedTs).toContain("dataSvc.storage.list(TENANT, gateType");
    expect(seedTs).toContain("existingIds");

    // seedPolicy threaded through per entity type.
    // Var-name casing matches generateSeedFileContent()'s arrName builder:
    // e.type.replace(/-([a-z])/g, (_, c) => c.toUpperCase()) + "Seed" (lowercase-first camelCase).
    expect(seedTs).toContain('await seedData(dataSvc, "task", taskSeed, "once");');
    expect(seedTs).toContain('await seedData(dataSvc, "audit-note", auditNoteSeed, "always");');
  }, 240_000);

  it("fails generation when a fixture id collides across two entity types' seed arrays", async () => {
    const { mdPath, outDir } = makeTmp();
    const manifest = baseManifest(`entities:
  - type: task
    fields:
      - { name: title, type: string, required: true }
    seed:
      - { id: shared-id-0001, data: { title: Demo Task } }
  - type: audit-note
    fields:
      - { name: title, type: string, required: true }
    seed:
      - { id: shared-id-0001, data: { title: Demo Note } }
`);
    fs.writeFileSync(mdPath, manifest, "utf8");

    await expect(runGenerator(mdPath, outDir)).rejects.toThrow(/collision/i);
  }, 240_000);

  it("honours solutionOwnedOverrides for solution/fixtures/seed.ts (GG-22)", async () => {
    const { mdPath, outDir } = makeTmp();
    const manifest = baseManifest(`entities:
  - type: task
    fields:
      - { name: title, type: string, required: true }
    seed:
      - { id: task-0001, data: { title: Demo Task } }
solutionOwnedOverrides:
  - solution/fixtures/seed.ts
`);
    fs.writeFileSync(mdPath, manifest, "utf8");

    // First run: file does not exist yet, so it is created (create-if-missing).
    await runGenerator(mdPath, outDir);
    const seedPath = path.join(outDir, "solution/fixtures/seed.ts");
    expect(fs.existsSync(seedPath)).toBe(true);

    // Hand-edit the file, then regen — the override must preserve it byte-for-byte.
    const handEdited = "// HAND-AUTHORED: probe-batching fix\nexport const HAND_EDITED_MARKER = true;\n";
    fs.writeFileSync(seedPath, handEdited, "utf8");

    await runGenerator(mdPath, outDir);
    expect(fs.readFileSync(seedPath, "utf8")).toBe(handEdited);
  }, 480_000);
});
