import { describe, it, expect } from "vitest";
import { SolutionManifestSchema } from "@dbp/contracts/solution-manifest";

// ─── Minimal valid base manifest (no archetype blocks) ───────────────────────

const BASE = {
  platform: "DWS",
  solution: "DWS.09",
  name: "Archetype Test",
  journey_stages: [2],
  deploy_layer: "L03",
  consumes_platform_services: ["PS.AUTH", "PS.DATA", "PS.SEARCH", "PS.AI", "PS.AUDIT"],
  modules: [
    {
      id: "DWS.09.M01",
      name: "Work Queue",
      journey: 2,
      scaffold: "SH.02",
      features: [
        {
          id: "APP.F01",
          role: "work-queue",
          wires: ["PS.DATA", "PS.SEARCH"],
          config: { entityType: "task", columns: [{ field: "title", label: "Title" }] },
        },
      ],
    },
  ],
} as const;

// ─── Absence ⇒ valid (every archetype block is optional) ──────────────────────

describe("Archetype blocks — all optional", () => {
  it("accepts a manifest with NO archetype blocks", () => {
    const r = SolutionManifestSchema.safeParse(BASE);
    expect(r.success).toBe(true);
    if (r.success) {
      expect(r.data.nav).toBeUndefined();
      expect(r.data.landing).toBeUndefined();
      expect(r.data.home).toBeUndefined();
      expect(r.data.marketplace).toBeUndefined();
      expect(r.data.copilot).toBeUndefined();
    }
  });
});

// ─── nav: ─────────────────────────────────────────────────────────────────────

describe("nav block", () => {
  it("accepts links + sign_in", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      nav: {
        links: [{ label: "Features", href: "#features" }],
        sign_in: { label: "Sign in", href: "/login" },
      },
    });
    expect(r.success).toBe(true);
  });

  it("rejects a nav link missing href", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      nav: { links: [{ label: "Features" }] },
    });
    expect(r.success).toBe(false);
  });
});

// ─── landing: ─────────────────────────────────────────────────────────────────

const LANDING = {
  hero: {
    overline: "DWS · DWS.09",
    headline: "Run your workspace.",
    headline_accent: "Built on the platform.",
    body: "Zero-rebuild solution.",
    primary_cta: { label: "Open", href: "/home" },
    trust_bullets: [{ icon: "ShieldCheck", label: "Governed" }],
  },
  features: {
    headline: "Everything",
    items: [{ icon: "BarChart3", title: "Queue", description: "Triage." }],
  },
  how_it_works: { steps: [{ step: "01", title: "Sign in" }] },
  cta: { headline: "Ready?", primary_cta: { label: "Sign in", href: "/login" } },
  footer: {
    tagline: "A workspace.",
    columns: [{ heading: "Product", links: [{ label: "Home", href: "/home" }] }],
    legal: "© 2026",
  },
} as const;

describe("landing block", () => {
  it("accepts a full landing block", () => {
    const r = SolutionManifestSchema.safeParse({ ...BASE, landing: LANDING });
    expect(r.success).toBe(true);
  });

  it("accepts a landing block with only a hero (other sections omitted)", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      landing: { hero: { headline: "Hi" } },
    });
    expect(r.success).toBe(true);
  });

  it("rejects a landing hero missing the required headline", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      landing: { hero: { overline: "x" } },
    });
    expect(r.success).toBe(false);
  });

  it("rejects a features section with an empty items array", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      landing: { hero: { headline: "Hi" }, features: { items: [] } },
    });
    expect(r.success).toBe(false);
  });
});

// ─── home: ──────────────────────────────────────────────────────────────────

const HOME = {
  greeting: { tagline: "Keep moving." },
  kpis: [{ id: "open", label: "Open", entityType: "task", metric: { aggregate: "count" } }],
  quickLinks: [{ id: "q", label: "Queue", href: "/m01" }],
} as const;

describe("home block", () => {
  it("accepts a minimal home block", () => {
    const r = SolutionManifestSchema.safeParse({ ...BASE, home: HOME });
    expect(r.success).toBe(true);
  });

  it("rejects home with zero kpis", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      home: { ...HOME, kpis: [] },
    });
    expect(r.success).toBe(false);
  });

  it("rejects home with more than 5 kpis", () => {
    const kpi = HOME.kpis[0];
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      home: { ...HOME, kpis: [kpi, kpi, kpi, kpi, kpi, kpi] },
    });
    expect(r.success).toBe(false);
  });

  it("rejects home with zero quickLinks", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      home: { ...HOME, quickLinks: [] },
    });
    expect(r.success).toBe(false);
  });
});

// ─── marketplace: (+ detail) ──────────────────────────────────────────────────

const MARKETPLACE = {
  entityType: "service-offering",
  headline: "Catalogue.",
  cardFields: { title: "name", description: "summary", footerId: "code" },
  filterFields: [{ field: "category", label: "Category" }],
  detail: {
    summaryField: "summary",
    badgeFields: [{ field: "category", style: "pill" }],
    tabs: [{ id: "overview", label: "Overview" }],
    acknowledgement: { required: true, label: "Acknowledge" },
  },
} as const;

describe("marketplace block", () => {
  it("accepts a marketplace block with a detail sub-key", () => {
    const r = SolutionManifestSchema.safeParse({ ...BASE, marketplace: MARKETPLACE });
    expect(r.success).toBe(true);
  });

  it("accepts a marketplace listing WITHOUT detail", () => {
    const { detail, ...listing } = MARKETPLACE;
    void detail;
    const r = SolutionManifestSchema.safeParse({ ...BASE, marketplace: listing });
    expect(r.success).toBe(true);
  });

  it("rejects marketplace missing cardFields.title (required)", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      marketplace: { entityType: "svc", headline: "x", cardFields: { description: "d" } },
    });
    expect(r.success).toBe(false);
  });

  it("rejects an invalid detail badge style", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      marketplace: {
        ...MARKETPLACE,
        detail: { summaryField: "summary", badgeFields: [{ field: "x", style: "neon" }] },
      },
    });
    expect(r.success).toBe(false);
  });
});

// ─── copilot: ─────────────────────────────────────────────────────────────────

const COPILOT = {
  eyebrow: "Ask / assist",
  title: "AI Cockpit",
  description: "Use AI to assist.",
  insightCards: [
    { id: "open", title: "Open", valueMetric: { entityType: "task", aggregate: "count" }, icon: "Hash" },
  ],
  composerPlaceholder: "Ask…",
  submitLabel: "Generate",
  suggestedPrompts: ["Summarize approvals"],
  entityType: "task",
} as const;

describe("copilot block", () => {
  it("accepts a minimal copilot block", () => {
    const r = SolutionManifestSchema.safeParse({ ...BASE, copilot: COPILOT });
    expect(r.success).toBe(true);
  });

  it("rejects copilot with zero insightCards", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      copilot: { ...COPILOT, insightCards: [] },
    });
    expect(r.success).toBe(false);
  });

  it("rejects copilot with more than 3 insightCards", () => {
    const c = COPILOT.insightCards[0];
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      copilot: { ...COPILOT, insightCards: [c, c, c, c] },
    });
    expect(r.success).toBe(false);
  });

  it("rejects copilot with zero suggestedPrompts", () => {
    const r = SolutionManifestSchema.safeParse({
      ...BASE,
      copilot: { ...COPILOT, suggestedPrompts: [] },
    });
    expect(r.success).toBe(false);
  });

  it("rejects copilot missing the required title", () => {
    const { title, ...rest } = COPILOT;
    void title;
    const r = SolutionManifestSchema.safeParse({ ...BASE, copilot: rest });
    expect(r.success).toBe(false);
  });
});
