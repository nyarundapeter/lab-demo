import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const execFileAsync = promisify(execFile);

/**
 * End-to-end proof (real generator, temp --out-dir, never apps/dbp) that the Wave 2
 * mount seam — manifest `standard_menu_organisms` — actually reaches a standard-menu-
 * SYNTHESIZED route through the full scaffold-solution.mjs pipeline: buildModules()
 * (scripts/standard-menu-scaffold.mjs) sets pageComponent/composesOrganism on the
 * synthesized module, which is merged into manifest.modules and picked up by the
 * SAME pageComponent emission code hand-authored modules use (see
 * generator-emission.test.ts's "pageComponent seam" describe block).
 *
 * Kept in its OWN file (not generator-emission.test.ts): scaffold-solution.mjs only
 * runs standard-menu synthesis at all when PS.DATA is consumed (see its "Standard
 * menu" block), which makes buildModules() synthesize ~74 modules — each running a
 * tsx feature-config-validation subprocess, the documented ~85s/3-minute cost
 * generator-emission.test.ts's fixture deliberately avoids for the same reason.
 * There is no way to exercise the real end-to-end pipeline for this seam without
 * paying that cost, so it is isolated here (own file, generous timeout) instead of
 * slowing down the fast fixture every other generator-emission assertion shares.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const GENERATOR = path.join(REPO_ROOT, "scripts", "scaffold-solution.mjs");

// /manage-work/cases is the standard-menu "lve" archetype route — its DEFAULT
// synthesized body renders @dbp/organisms/lve-workspace (APP.F19, featLve()). The
// override below retargets it onto @dbp/organisms/case-workspace instead, so a
// passing test proves the override REPLACES the default archetype body (not just
// that composesOrganism happens to match what the default would emit anyway).
const FIXTURE_MD = `---
platform: DWS
solution: DWS.10
name: Standard Menu Organism Override Test
journey_stages: [0, 2]
deploy_layer: L03
consumes_platform_services: [PS.AUTH, PS.DATA]
modules:
  - id: DWS.10.M01
    name: Placeholder
    journey: 2
    scaffold: SH.02
    route: /placeholder
    features:
      - id: APP.F01
        role: placeholder
        wires: [PS.DATA]
        config:
          entityType: task
          columns:
            - { field: title, label: Title }
standard_menu_organisms:
  - route: /manage-work/cases
    composesOrganism: case-workspace
---

# DWS.10 — Standard Menu Organism Override Test fixture
`;

let tmpRoot: string;
let mdPath: string;
let outDir: string;

async function runGenerator(out: string): Promise<void> {
  await execFileAsync(process.execPath, [GENERATOR, mdPath, "--out-dir", out, "--force"], {
    cwd: REPO_ROOT,
    encoding: "utf8",
  });
}

function read(rel: string): string {
  return fs.readFileSync(path.join(outDir, rel), "utf8");
}

beforeAll(async () => {
  tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-gen-std-menu-organism-"));
  mdPath = path.join(tmpRoot, "SOLUTION.md");
  outDir = path.join(tmpRoot, "out");
  fs.writeFileSync(mdPath, FIXTURE_MD, "utf8");
  await runGenerator(outDir);
}, 400_000);

afterAll(() => {
  if (tmpRoot && fs.existsSync(tmpRoot)) fs.rmSync(tmpRoot, { recursive: true, force: true });
});

describe("standard-menu organism override — real generator emission", () => {
  it("emits the thin generator-owned wrapper page importing the solution-owned stub", () => {
    const page = read("app/(authenticated)/manage-work/cases/page.tsx");
    expect(page).toContain("// Layout: pageComponent");
    expect(page).toContain('from "../../../../solution/pages/CaseWorkspace"');
    // Replaced the default archetype body — no lve-workspace import in the wrapper page.
    expect(page).not.toContain("@dbp/organisms/lve-workspace");
  });

  it("emits a create-if-missing composition-only stub composing the overridden organism, not the default archetype's", () => {
    const stub = read("solution/pages/CaseWorkspace.tsx");
    expect(stub).toContain('from "@dbp/organisms/case-workspace"');
    expect(stub).toContain("CaseWorkspace");
    expect(stub).toContain("// composes: @dbp/organisms/case-workspace");
    expect(stub).not.toContain("Kanban");
    expect(stub).not.toContain("Replace this stub");
  });

  it("does not synthesize the default 'lve' archetype body for the overridden route", () => {
    const page = read("app/(authenticated)/manage-work/cases/page.tsx");
    expect(page).not.toContain("LveWorkspace");
  });

  // Whether a re-run preserves a hand-edited solution-owned stub is a property of the
  // SHARED writeFile()/isSolutionOwned() create-if-missing mechanism scaffold-solution.mjs
  // uses for every solution/pages/** file — not something specific to this override's new
  // code (which only affects how buildModules() constructs the synthesized module, not the
  // downstream write/overwrite-protection logic). That mechanism is already generically
  // proven by generator-file-contract.test.ts's "--force regen preserves solution-owned"
  // suite, so it is not re-proven here — re-running the full ~74-module standard-menu
  // synthesis a second time to re-check it would double this file's already-expensive
  // runtime for no new coverage.
});
