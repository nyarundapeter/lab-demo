import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * UX copy / microcopy ratchet (docs/03-features/specs/layout-template-definition-of-done.md
 * §6.7 "UX copy / microcopy" — real labels, helper text, empty-state guidance, and error
 * messages; no lorem/placeholder. Test: a lorem/placeholder ratchet + an
 * empty-state-copy-present assertion).
 *
 * Two independent checks:
 *
 *  1. Placeholder-copy ban — real feature source (`features/**` /*.ts,.tsx*, and shared
 *     `@dbp/ui` components) must not contain unfinished-copy tells (lorem ipsum, "TODO:
 *     copy", etc). Story and test files are excluded: canned lorem text in a Storybook
 *     fixture used purely to exercise long-text/overflow layout is fine and out of scope —
 *     only *shipped* copy matters here. Comments are stripped before matching, because
 *     "Placeholder text for X" is a completely legitimate JSDoc description of an HTML
 *     `placeholder` attribute, not unfinished copy.
 *
 *  2. Empty-state copy presence — every feature that ships an `Empty` story (the
 *     convention from alert-view/stories/index.stories.tsx) must render non-trivial
 *     guidance text for that state, not just an icon. Checked via a best-effort static
 *     heuristic: the feature's non-story source either (a) uses the shared `<EmptyState>`
 *     component (which always renders a headline, defaulting to "Nothing here yet"), or
 *     (b) has a quoted fallback string of a few words near an "empty" reference (e.g.
 *     `config.emptyText ?? "No exceptions."`).
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const FEATURES_DIR = path.join(REPO_ROOT, "packages/stack/app-scaffolds/features");
const UI_COMPONENTS_DIR = path.join(REPO_ROOT, "packages/shared/ui/src/components");

/** Relative-to-repo path → reason a real placeholder-copy ban violation is tolerated. */
const PLACEHOLDER_ALLOWLIST: Record<string, string> = {
  // (empty — no genuine unfinished-copy tells found in feature/ui source as of writing)
};

/** Relative-to-repo path → reason a feature's Empty story lacks guidance copy. */
const EMPTY_COPY_ALLOWLIST: Record<string, string> = {
  // (empty — every feature with an Empty story currently renders guidance text)
};

function rel(abs: string) {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

function listFiles(dir: string, predicate: (f: string) => boolean): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listFiles(abs, predicate));
    else if (predicate(abs)) out.push(abs);
  }
  return out;
}

/** Real source only: .ts/.tsx, excluding Storybook fixtures and unit tests. */
function isRealSource(f: string): boolean {
  if (!f.endsWith(".ts") && !f.endsWith(".tsx")) return false;
  if (f.endsWith(".stories.tsx")) return false;
  if (f.endsWith(".test.tsx") || f.endsWith(".test.ts")) return false;
  return true;
}

function stripComments(src: string): string {
  return src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
}

const featureSourceFiles = listFiles(FEATURES_DIR, isRealSource);
const uiComponentFiles = listFiles(UI_COMPONENTS_DIR, isRealSource);

/**
 * Placeholder-copy tells. All are high-signal markers of copy that was never finished —
 * a real label/helper/error string would never legitimately contain any of these.
 */
const PLACEHOLDER_BANNED = [
  { label: "lorem ipsum", re: /lorem\s+ipsum/i },
  { label: "placeholder text", re: /placeholder\s+text/i },
  { label: "TODO: copy", re: /todo:\s*copy/i },
  { label: "TBD copy", re: /tbd\s+copy/i },
  { label: "xxxxx", re: /xxxxx/i },
  { label: "dolor sit amet", re: /dolor\s+sit\s+amet/i },
];

function placeholderViolations(files: string[]): string[] {
  const found: string[] = [];
  for (const abs of files) {
    const r = rel(abs);
    if (PLACEHOLDER_ALLOWLIST[r]) continue;
    const src = stripComments(fs.readFileSync(abs, "utf8"));
    for (const { label, re } of PLACEHOLDER_BANNED) {
      if (re.test(src)) found.push(`${r}: ${label}`);
    }
  }
  return found;
}

// ─── Empty-state copy presence ─────────────────────────────────────────────────

const EMPTY_STORY_RE = /export\s+const\s+Empty\s*[:=]/;

/** features/<name>/stories/index.stories.tsx that export a story literally named `Empty`. */
function featuresWithEmptyStory(): string[] {
  const storyFiles = listFiles(
    FEATURES_DIR,
    (f) => f.endsWith(path.join("stories", "index.stories.tsx")),
  );
  return storyFiles
    .filter((f) => EMPTY_STORY_RE.test(fs.readFileSync(f, "utf8")))
    .map((f) => path.dirname(path.dirname(f))); // features/<name>/stories/.. → features/<name>
}

const MIN_GUIDANCE_LEN = 8;

/** True if `src` contains a plausible non-trivial empty-state guidance string. */
function hasEmptyStateCopy(src: string): boolean {
  if (/<EmptyState\b/.test(src)) return true; // shared component always renders a headline
  const emptyRefRe = /empty/gi;
  let m: RegExpExecArray | null;
  while ((m = emptyRefRe.exec(src))) {
    const window = src.slice(Math.max(0, m.index - 200), m.index + 200);
    const quoted = window.match(/["'`]([^"'`]{4,})["'`]/g) ?? [];
    for (const q of quoted) {
      const inner = q.slice(1, -1).trim();
      if (inner.length >= MIN_GUIDANCE_LEN && /\s/.test(inner)) return true;
    }
  }
  return false;
}

function emptyCopyViolations(featureDirs: string[]): string[] {
  const found: string[] = [];
  for (const dir of featureDirs) {
    const r = rel(dir);
    if (EMPTY_COPY_ALLOWLIST[r]) continue;
    const src = listFiles(dir, isRealSource)
      .map((f) => fs.readFileSync(f, "utf8"))
      .join("\n---\n");
    if (!hasEmptyStateCopy(src)) found.push(r);
  }
  return found;
}

describe("UX copy / microcopy conformance (DoD §6.7)", () => {
  it("finds the feature and ui component files to scan", () => {
    expect(featureSourceFiles.length).toBeGreaterThan(10);
    expect(uiComponentFiles.length).toBeGreaterThan(10);
  });

  it("no feature source ships lorem/placeholder/unfinished copy — see layout-template-definition-of-done.md §6.7", () => {
    const found = placeholderViolations(featureSourceFiles);
    expect(
      found,
      `Placeholder-copy violations — see docs/03-features/specs/layout-template-definition-of-done.md §6.7:\n${found.join("\n")}`,
    ).toEqual([]);
  });

  it("no shared ui component ships lorem/placeholder/unfinished copy — see layout-template-definition-of-done.md §6.7", () => {
    const found = placeholderViolations(uiComponentFiles);
    expect(
      found,
      `Placeholder-copy violations — see docs/03-features/specs/layout-template-definition-of-done.md §6.7:\n${found.join("\n")}`,
    ).toEqual([]);
  });

  it("every feature with an Empty story renders non-trivial empty-state guidance copy — see layout-template-definition-of-done.md §6.7", () => {
    const featureDirs = featuresWithEmptyStory();
    expect(featureDirs.length).toBeGreaterThan(3);
    const found = emptyCopyViolations(featureDirs);
    expect(
      found,
      `Missing empty-state guidance copy — see docs/03-features/specs/layout-template-definition-of-done.md §6.7:\n${found.join("\n")}`,
    ).toEqual([]);
  });

  it("allowlist entries still exist and still violate (prune stale allowlist)", () => {
    for (const [relPath, reason] of Object.entries(PLACEHOLDER_ALLOWLIST)) {
      const abs = path.join(REPO_ROOT, relPath);
      expect(fs.existsSync(abs), `allowlisted file missing: ${relPath}`).toBe(true);
      const src = stripComments(fs.readFileSync(abs, "utf8"));
      const stillViolates = PLACEHOLDER_BANNED.some(({ re }) => re.test(src));
      expect(stillViolates, `allowlist entry no longer needed (remove it): ${relPath} — ${reason}`).toBe(true);
    }
    for (const [relPath, reason] of Object.entries(EMPTY_COPY_ALLOWLIST)) {
      const abs = path.join(REPO_ROOT, relPath);
      expect(fs.existsSync(abs), `allowlisted feature dir missing: ${relPath}`).toBe(true);
      const src = listFiles(abs, isRealSource)
        .map((f) => fs.readFileSync(f, "utf8"))
        .join("\n---\n");
      expect(
        hasEmptyStateCopy(src),
        `allowlist entry no longer needed (remove it): ${relPath} — ${reason}`,
      ).toBe(false);
    }
  });
});
