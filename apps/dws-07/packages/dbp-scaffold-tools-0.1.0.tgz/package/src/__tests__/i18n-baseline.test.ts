import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * i18n baseline ratchet (DoD §6.5 — docs/03-features/specs/layout-template-definition-of-done.md).
 *
 * There is currently NO i18n infrastructure in this repo (no translation library,
 * no locale files, no `dir="rtl"` handling anywhere). Every feature hardcodes
 * 100% of its user-facing copy today — that is the expected pre-i18n state, not
 * a zero-tolerance violation. A "no hardcoded copy" ban would fail on every
 * feature file that exists and block all work.
 *
 * This is therefore a BASELINE-TRACKING RATCHET, not a ban, mirroring the
 * warn-baseline philosophy used elsewhere in this repo (`.size-limit.json`'s
 * "baseline + headroom, not a hard limit today"; `check-coverage-ratchet.mjs`'s
 * adoption-mode gate). It measures the CURRENT volume of hardcoded user-facing
 * copy across feature source and asserts it does not exceed the last-recorded
 * baseline in `__fixtures__/i18n-baseline.json`. The test:
 *   - passes today (current count == committed baseline)
 *   - fails if hardcoded-copy volume INCREASES without a conscious update to
 *     the baseline file (i.e. it catches regression — new features/edits piling
 *     on more un-internationalized copy — even before real i18n exists)
 *   - is expected to eventually be replaced by a real "zero hardcoded copy"
 *     ratchet once a translation layer lands (tracked as future work in the DoD)
 *
 * Heuristic (pragmatic, not a JSX parser): two regexes, tested against real
 * feature source in this repo before being chosen —
 *   1. JSX text nodes: `>Some Words<` — catches literal text between tags
 *      (headings, buttons, empty-state copy, e.g. `<h2>Details</h2>`).
 *   2. Copy-bearing prop string literals: `label="..."`, `placeholder="..."`,
 *      `title="..."`, `helperText="..."`, etc. — catches copy passed as props
 *      to components rather than as JSX children (e.g. `title="Entity not found"`).
 * Config-driven copy (strings that come from a manifest/Zod config object at
 * runtime, e.g. `{action.label}`) is correctly NOT counted — only literal
 * string copy baked into the source is in scope, since that's what a future
 * translation-extraction pass would need to touch.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const FEATURES_DIR = path.join(REPO_ROOT, "packages/stack/app-scaffolds/features");
const BASELINE_PATH = path.join(__dirname, "__fixtures__/i18n-baseline.json");

function rel(abs: string): string {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

function listFeatureSourceFiles(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === "node_modules") continue;
      out.push(...listFeatureSourceFiles(abs));
    } else if (e.name.endsWith(".tsx")) {
      if (e.name.endsWith(".stories.tsx") || e.name.endsWith(".test.tsx")) continue;
      out.push(abs);
    }
  }
  return out;
}

/** Heuristic 1: literal JSX text nodes, e.g. `<h2>Details</h2>` or `>Quick actions</p>`. */
const JSX_TEXT_RE = />[ \t]*[A-Z][a-zA-Z]+[^<{}\n]*?</g;

/** Heuristic 2: copy-bearing prop string literals, e.g. `title="Entity not found"`. */
const COPY_PROP_RE =
  /\b(label|placeholder|title|helperText|description|emptyMessage|errorMessage|buttonText|heading|subtitle)\s*=\s*"[^"]+"/g;

function countHardcodedCopy(src: string): number {
  const jsxTextMatches = src.match(JSX_TEXT_RE)?.length ?? 0;
  const copyPropMatches = src.match(COPY_PROP_RE)?.length ?? 0;
  return jsxTextMatches + copyPropMatches;
}

const featureSourceFiles = listFeatureSourceFiles(FEATURES_DIR);

function currentCount(): number {
  let total = 0;
  for (const abs of featureSourceFiles) {
    total += countHardcodedCopy(fs.readFileSync(abs, "utf8"));
  }
  return total;
}

const baseline: { count: number; measuredAt: string; note: string } = JSON.parse(
  fs.readFileSync(BASELINE_PATH, "utf8"),
);

describe("i18n hardcoded-copy baseline ratchet (DoD §6.5)", () => {
  it("found feature source files to scan", () => {
    expect(featureSourceFiles.length, `Expected feature .tsx files under ${rel(FEATURES_DIR)}`).toBeGreaterThan(50);
  });

  it("hardcoded user-facing copy volume does not exceed the committed baseline", () => {
    const count = currentCount();
    expect(
      count,
      [
        `Hardcoded-copy heuristic count is ${count}, baseline is ${baseline.count}.`,
        "This is a baseline ratchet, not a zero-tolerance ban (no i18n infra exists yet — see",
        "docs/03-features/specs/layout-template-definition-of-done.md §6.5). If this increase is",
        "intentional (new feature copy, expected pre-i18n), update the baseline:",
        `  ${rel(BASELINE_PATH)} → set "count" to ${count} and "measuredAt" to today's date.`,
        "If it's unintentional copy sprawl, extract/reduce it instead of bumping the baseline.",
      ].join("\n"),
    ).toBeLessThanOrEqual(baseline.count);
  });

  // Expected-to-fail tracking test — flips to a real ratchet once RTL support ships.
  // See docs/03-features/specs/layout-template-definition-of-done.md §6.5: "RTL-safe".
  // This repo currently has ZERO RTL handling (no `dir="rtl"`, no `rtl:` Tailwind
  // variants) anywhere in the design-token or shared UI source. When RTL support is
  // added, remove `.fails` here — this then becomes a real, permanent ratchet that
  // guards against RTL support being silently removed later.
  it.fails("design tokens or shared UI declare RTL handling (dir=\"rtl\" or rtl: variants)", () => {
    const DESIGN_TOKENS_DIR = path.join(REPO_ROOT, "packages/shared/design-tokens");
    const UI_SRC_DIR = path.join(REPO_ROOT, "packages/shared/ui/src");
    const RTL_RE = /dir=["']rtl["']|(?:^|[\s"'`])rtl:/;

    function anyFileHasRtl(dir: string): boolean {
      if (!fs.existsSync(dir)) return false;
      for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const abs = path.join(dir, e.name);
        if (e.isDirectory()) {
          if (e.name === "node_modules") continue;
          if (anyFileHasRtl(abs)) return true;
        } else if (/\.(tsx?|css)$/.test(e.name)) {
          if (RTL_RE.test(fs.readFileSync(abs, "utf8"))) return true;
        }
      }
      return false;
    }

    expect(anyFileHasRtl(DESIGN_TOKENS_DIR) || anyFileHasRtl(UI_SRC_DIR)).toBe(true);
  });
});
