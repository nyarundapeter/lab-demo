import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Ratchet: @dbp/scaffold-cli's version must equal the platform version.
 *
 * scaffold-cli vendors the generator toolchain a standalone repo runs when its
 * builder regenerates. Its version is pinned to docs/REGISTRY.yaml#blueprint_version
 * BY DESIGN — that pin is how a consumer knows which generator produced their tree.
 *
 * Nothing enforced the pin. Bumping the platform touches six mirror locations
 * (PLATFORM-VERSION, docs/REGISTRY.yaml, contracts' version.ts + its smoke test,
 * dbp-upgrade.mjs, scaffold-solution.mjs) and this package was in none of them, so
 * platform/v1.5.0 shipped while scaffold-cli sat on 1.4.1. The failure is silent and
 * lands on the consumer, not on us: they regenerate from a v1.5.0 export and run a
 * two-releases-old generator, missing every generator fix in between.
 *
 * The pin is now a seventh mirror with a gate on it.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const CLI_PKG = path.join(REPO_ROOT, "packages/shared/scaffold-cli/package.json");
const REGISTRY = path.join(REPO_ROOT, "docs/REGISTRY.yaml");
const CHANGELOG = path.join(REPO_ROOT, "packages/shared/scaffold-cli/CHANGELOG.md");

/** "platform/v1.5.0" -> "1.5.0" */
function platformVersionFromRegistry(): string {
  const src = fs.readFileSync(REGISTRY, "utf8");
  const match = src.match(/^blueprint_version:\s*platform\/v(\d+\.\d+\.\d+)\s*$/m);
  if (!match) {
    throw new Error(
      `Could not read blueprint_version from ${REGISTRY}. Expected a line of the form ` +
        `"blueprint_version: platform/vMAJOR.MINOR.PATCH".`,
    );
  }
  return match[1]!;
}

describe("@dbp/scaffold-cli version alignment", () => {
  it("matches docs/REGISTRY.yaml#blueprint_version", () => {
    const expected = platformVersionFromRegistry();
    const actual = JSON.parse(fs.readFileSync(CLI_PKG, "utf8")).version as string;

    expect(
      actual,
      `@dbp/scaffold-cli is ${actual} but the platform is ${expected}. This package vendors the ` +
        `generator a standalone repo regenerates with, so a stale version ships consumers an old ` +
        `generator. Bump packages/shared/scaffold-cli/package.json to ${expected} and add a ` +
        `CHANGELOG entry in the same change.`,
    ).toBe(expected);
  });

  it("has a CHANGELOG entry for its current version", () => {
    const version = JSON.parse(fs.readFileSync(CLI_PKG, "utf8")).version as string;
    const changelog = fs.readFileSync(CHANGELOG, "utf8");

    expect(
      changelog.includes(`## [${version}]`),
      `packages/shared/scaffold-cli/CHANGELOG.md has no "## [${version}]" entry. Version bump and ` +
        `CHANGELOG entry travel together (docs/02-guides/02-operations/package-versioning-and-updates.md).`,
    ).toBe(true);
  });
});
