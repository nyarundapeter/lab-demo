import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Apps page-contract ratchet (ADR-0035 — "pages are declarations: the
 * data-not-chrome layout contract", Layer 4 extended).
 *
 * WHAT THIS ENFORCES
 * ------------------
 * A page file is a DECLARATION: which layout, which feature, what data.
 * It has zero chrome and zero design. Four violation classes are checked:
 *
 *   1. RAW_CHROME   — <nav, page-level <a href clusters (≥3), raw <table>/<form>
 *                      outside @dbp/ui in page files
 *   2. DESIGN_CLASS — color-mix(, arbitrary [hex/spacing/type] in classNames,
 *                      raw hex strings in page files
 *   3. BAD_TONE     — Badge tone string outside the valid union:
 *                      default|success|warning|danger|info|gray|orange|navy
 *                      ("neutral" flagged specifically — CVA silently ignores it,
 *                      badge renders unstyled)
 *   4. LAYOUT_SEAM  — Layout file exposes ReactNode for a structural region
 *                      (prop named nav/rail/header/aside/filter/filters/tabs/
 *                      filterBar/toolbar — NOT children). This is the structural
 *                      lever that prevents the next settings-style seam.
 *
 * ENFORCEMENT MODEL — BASELINE RATCHET (Pick 3 "lock what we have down", 2026-07-04)
 * -----------------------------------------------------------------------------------
 * The all-apps regen that would take every class to zero has not happened yet.
 * Rather than stay dormant behind `.skip`, this test is ENFORCED against a
 * committed baseline (apps-page-contract-baseline.json): current violations may
 * never exceed the baseline (no NEW violations), and the baseline may never
 * contain an entry that no longer reproduces (it may only shrink — fix the
 * violation, then remove its entry; never add an entry to silence a new one).
 * See docs/09-plans/pick3/pick3-lockdown-decisions-2026-07-04.md.
 */
describe("apps page-contract ratchet (ADR-0035 — baseline-enforced)", () => {
  const __filename = fileURLToPath(import.meta.url);
  const HERE = path.dirname(__filename);
  const REPO_ROOT = path.resolve(HERE, "../../../../..");
  const APPS_DIR = path.join(REPO_ROOT, "apps");
  const LAYOUTS_DIR = path.join(
    REPO_ROOT,
    "packages/stack/app-scaffolds/shells/transaction/layouts"
  );
  const BASELINE_PATH = path.join(HERE, "apps-page-contract-baseline.json");
  const baseline: { violations: string[] } = JSON.parse(
    fs.readFileSync(BASELINE_PATH, "utf8")
  );
  const baselineSet = new Set(baseline.violations);

  // ── helpers ─────────────────────────────────────────────────────────────────

  function rel(abs: string) {
    return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
  }

  function listFiles(dir: string, predicate: (f: string) => boolean): string[] {
    if (!fs.existsSync(dir)) return [];
    const out: string[] = [];
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === "node_modules" || entry.name === ".next") continue;
        out.push(...listFiles(abs, predicate));
      } else if (predicate(abs)) {
        out.push(abs);
      }
    }
    return out;
  }

  function listPageFiles(): string[] {
    return listFiles(
      APPS_DIR,
      (f) =>
        path.basename(f) === "page.tsx" &&
        !f.includes("__boundary-fixtures__") &&
        !f.includes(`${path.sep}hello${path.sep}`)
    );
  }

  // ── key construction (shared by seeding and checking — must never drift) ────
  //
  // Stable key, no line numbers (line numbers are brittle): "<file>::<RULE>::<token>"

  function normToken(s: string): string {
    return s.replace(/\s+/g, " ").trim();
  }

  function makeKey(fileRel: string, rule: string, token: string): string {
    return `${fileRel}::${rule}::${normToken(token)}`;
  }

  // ── check implementations ────────────────────────────────────────────────────

  // Check 1: Raw structural chrome
  function hasRawChrome(src: string): string | null {
    if (/<nav\b/.test(src)) return "<nav element";
    if (/<table\b/.test(src)) return "<table element";
    if (/<form\b/.test(src)) return "<form element";
    const aHits = (src.match(/<a\s+href=/g) || []).length;
    if (aHits >= 3) return `<a href cluster (${aHits} links)`;
    return null;
  }

  // Check 2: Design in className
  function hasDesignClass(src: string): string | null {
    if (/color-mix\(/.test(src)) return "color-mix()";
    if (/\[#[0-9a-fA-F]{3,8}[\]/]/.test(src)) return "arbitrary [#hex] in className";
    if (/\[[0-9]+(?:px|rem|em|%|vw|vh|ch)\]/.test(src)) return "arbitrary [value] unit";
    if (/"[^"]*#[0-9a-fA-F]{3,8}[^"]*"/.test(src)) return "raw hex in string";
    return null;
  }

  // Check 3: Invalid Badge tone
  const VALID_TONES = new Set([
    "default", "success", "warning", "danger", "info", "gray", "orange", "navy",
  ]);

  function findInvalidTone(src: string): string | null {
    if (!src.includes("badgeTones") && !src.includes("tone=")) return null;
    const blockRe = /badgeTones[^}]+\}/g;
    let block;
    while ((block = blockRe.exec(src)) !== null) {
      const valueRe = /:\s*"([a-z][a-z-]*)"/g;
      let m;
      while ((m = valueRe.exec(block[0])) !== null) {
        const tone = m[1];
        if (tone !== undefined && !VALID_TONES.has(tone)) return tone;
      }
    }
    const toneProps = [...src.matchAll(/tone=["']([a-z][a-z-]*)["']/g)];
    for (const m of toneProps) {
      const tone = m[1];
      if (tone !== undefined && !VALID_TONES.has(tone)) return tone;
    }
    return null;
  }

  // Check 4: Structural ReactNode seam in layout
  const STRUCTURAL_NAMES = [
    "nav", "rail", "header", "aside", "filter", "filters",
    "tabs", "subNav", "filterBar", "toolbar",
  ];
  const STRUCTURAL_SEAM_RE = new RegExp(
    `\\b(${STRUCTURAL_NAMES.join("|")})\\??\\s*:\\s*(React\\.ReactNode|ReactNode)`,
    "g"
  );

  function findLayoutSeam(src: string): string | null {
    const m = STRUCTURAL_SEAM_RE.exec(src);
    STRUCTURAL_SEAM_RE.lastIndex = 0; // reset stateful regex
    if (m) return m[1] ?? null;
    return null;
  }

  // ── gather current violation keys across the whole apps/* + layouts tree ────

  function collectCurrentViolations(): Set<string> {
    const keys = new Set<string>();

    for (const abs of listPageFiles()) {
      const r = rel(abs);
      const src = fs.readFileSync(abs, "utf8");

      const chrome = hasRawChrome(src);
      if (chrome) keys.add(makeKey(r, "RAW_CHROME", chrome));

      const design = hasDesignClass(src);
      if (design) keys.add(makeKey(r, "DESIGN_CLASS", design));

      const tone = findInvalidTone(src);
      if (tone) keys.add(makeKey(r, "BAD_TONE", tone));
    }

    const layoutFiles = listFiles(
      LAYOUTS_DIR,
      (f) => f.endsWith(".tsx") && !f.endsWith(".stories.tsx")
    );
    for (const abs of layoutFiles) {
      const r = rel(abs);
      const src = fs.readFileSync(abs, "utf8");
      const seam = findLayoutSeam(src);
      if (seam) keys.add(makeKey(r, "LAYOUT_SEAM", seam));
    }

    return keys;
  }

  // ── test: discovery ───────────────────────────────────────────────────────────

  it("finds page files to scan", () => {
    const pages = listPageFiles();
    expect(pages.length).toBeGreaterThan(100);
  });

  // ── test: baseline ratchet ────────────────────────────────────────────────────

  it("has no new GATE.06 chrome/design violations beyond the committed baseline", () => {
    const current = [...collectCurrentViolations()];
    const novel = current.filter((k) => !baselineSet.has(k));
    expect(
      novel,
      "New GATE.06 chrome/design violations — fix or use a registered seam, do NOT add to baseline"
    ).toEqual([]);
  });

  it("has no stale baseline entries (baseline may only shrink)", () => {
    const currentSet = collectCurrentViolations();
    const stale = [...baselineSet].filter((k) => !currentSet.has(k));
    expect(
      stale,
      "Baseline entries no longer reproduce — remove them from apps-page-contract-baseline.json (baseline may only shrink)"
    ).toEqual([]);
  });
});
