import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parse as parseYaml } from "yaml";

/**
 * Workflow interactability ratchet: a module that declares `wires: [...PS.WORKFLOW...]`
 * is a claim that PS.WORKFLOW is actually usable from that surface — not just that the
 * platform service is mounted. This closes the gap found while activating DWS.03's
 * ADR-0039 relational-data-model pilot: three modules declared `wires: [PS.WORKFLOW, ...]`
 * with zero `solution/workflows/*.ts` definitions anywhere in the app, so the workflow
 * route mount had nothing to register and those surfaces were non-interactable.
 *
 * Checks, per module with PS.WORKFLOW in `wires`:
 *   - APP.F19 (LVE) with `config.entityType` set: the manifest's matching `entities[]`
 *     entry must declare a non-empty `workflows[]`, and every id in it must match a
 *     real `solution/workflows/*.ts` definition's `id`.
 *   - APP.F06 (approval surface) with `config.workflowId` set: that id must match a
 *     real `solution/workflows/*.ts` definition's `id`.
 *   - Any other module shape (e.g. APP.F03 form-submission, custom pageComponent
 *     wiring): we can't statically map it to a specific definition id without deeper
 *     analysis, so the bar is the coarser "the app has at least one real workflow
 *     definition somewhere" — still catches the zero-definitions failure mode this
 *     ratchet exists for, without false-positiving on legitimate custom wiring.
 *
 * Static text/YAML analysis (comments stripped) — no generator invocation, no build.
 *
 * Excluded apps (documented, not silently skipped — known gaps, not fixed here):
 *   - dia-03, sdo-01: PS.WORKFLOW-wiring modules present, zero solution/workflows/*.ts
 *     definitions anywhere in the app. Same defect class this ratchet targets;
 *     tracked as follow-up debt, not fixed in this pass (DWS.03 was the concrete fix).
 *   - dws-01: task-approvals (APP.F06, workflowId: task-approval) correctly resolves
 *     to task-approval.ts. But my-tasks-workspace (APP.F19, entityType: task) has no
 *     entities[].workflows binding for "task" — same LVE-binding gap DWS.03 had before
 *     its fix. Tracked as follow-up debt.
 *   - dws-04: pre-route-group era per repo convention (matches the existing SP-5 ratchets).
 *   - __boundary-fixtures__, hello: not real solutions.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const APPS_DIR = path.join(REPO_ROOT, "apps");
const SOLUTIONS_DIR = path.join(REPO_ROOT, "docs/10-Solutions");

const EXCLUDED_APPS = new Set(["dia-03", "sdo-01", "dws-01", "dws-04", "__boundary-fixtures__", "hello"]);

function stripComments(src: string): string {
  return src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, "");
}

/** Extracts the YAML frontmatter block (between the first two `---` lines). */
function readFrontmatter(mdPath: string): Record<string, unknown> | null {
  if (!fs.existsSync(mdPath)) return null;
  const src = fs.readFileSync(mdPath, "utf8");
  const lines = src.split(/\r?\n/);
  if (lines[0]?.trim() !== "---") return null;
  const endIdx = lines.findIndex((l, i) => i > 0 && l.trim() === "---");
  if (endIdx === -1) return null;
  const yamlSrc = lines.slice(1, endIdx).join("\n");
  try {
    return parseYaml(yamlSrc) as Record<string, unknown>;
  } catch {
    return null;
  }
}

type WfModule = { moduleFeatureId: string; config: Record<string, unknown> };

/** Every module.features[] entry whose `wires` includes "PS.WORKFLOW". */
function workflowWiringModules(manifest: Record<string, unknown> | null): WfModule[] {
  const modules = Array.isArray(manifest?.modules) ? (manifest!.modules as unknown[]) : [];
  const out: WfModule[] = [];
  for (const mod of modules) {
    if (!mod || typeof mod !== "object") continue;
    const features = Array.isArray((mod as Record<string, unknown>).features)
      ? ((mod as Record<string, unknown>).features as unknown[])
      : [];
    for (const feat of features) {
      if (!feat || typeof feat !== "object") continue;
      const rec = feat as Record<string, unknown>;
      const wires = Array.isArray(rec.wires) ? (rec.wires as unknown[]) : [];
      if (!wires.includes("PS.WORKFLOW")) continue;
      out.push({
        moduleFeatureId: typeof rec.id === "string" ? rec.id : "unknown",
        config: (rec.config && typeof rec.config === "object" ? rec.config : {}) as Record<string, unknown>,
      });
    }
  }
  return out;
}

/** entityType -> workflows[] map, from a manifest's entities[] block. */
function entityWorkflowsMap(manifest: Record<string, unknown> | null): Map<string, string[]> {
  const entities = Array.isArray(manifest?.entities) ? (manifest!.entities as unknown[]) : [];
  const map = new Map<string, string[]>();
  for (const e of entities) {
    if (!e || typeof e !== "object") continue;
    const rec = e as Record<string, unknown>;
    if (typeof rec.type !== "string") continue;
    const workflows = Array.isArray(rec.workflows)
      ? (rec.workflows as unknown[]).filter((w) => typeof w === "string") as string[]
      : [];
    map.set(rec.type, workflows);
  }
  return map;
}

/** Every WorkflowDefinition `id` declared under an app's solution/workflows/*.ts. */
function declaredWorkflowIds(appDir: string): string[] {
  const dir = path.join(appDir, "solution/workflows");
  if (!fs.existsSync(dir)) return [];
  const ids: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (!entry.isFile() || !entry.name.endsWith(".ts") || entry.name.endsWith(".d.ts")) continue;
    const src = stripComments(fs.readFileSync(path.join(dir, entry.name), "utf8"));
    const m = /WorkflowDefinition\s*=\s*\{\s*id:\s*["']([^"']+)["']/.exec(src);
    if (m?.[1]) ids.push(m[1]);
  }
  return ids;
}

const apps = fs.existsSync(APPS_DIR)
  ? fs
      .readdirSync(APPS_DIR, { withFileTypes: true })
      .filter((e) => e.isDirectory() && !EXCLUDED_APPS.has(e.name))
      .map((e) => e.name)
  : [];

describe("workflow interactability ratchet: PS.WORKFLOW-wiring modules must resolve to a real definition", () => {
  for (const app of apps) {
    const appDir = path.join(APPS_DIR, app);
    const archManifestPath = path.join(appDir, "solution/_arch/SOLUTION.md");
    const archManifest = readFrontmatter(archManifestPath);
    const solutionId = typeof archManifest?.solution === "string" ? (archManifest.solution as string) : null;
    const sourceManifestPath = solutionId ? path.join(SOLUTIONS_DIR, `${solutionId}-SOLUTION.md`) : null;
    const sourceManifest = sourceManifestPath ? readFrontmatter(sourceManifestPath) : null;

    const wfModules = workflowWiringModules(sourceManifest);
    if (wfModules.length === 0) continue; // nothing wires PS.WORKFLOW — trivially passes

    it(`apps/${app}: every module wiring PS.WORKFLOW resolves to a real workflow definition`, () => {
      const definedIds = new Set(declaredWorkflowIds(appDir));
      const entityWorkflows = entityWorkflowsMap(sourceManifest);
      const problems: string[] = [];

      for (const mod of wfModules) {
        if (mod.moduleFeatureId === "APP.F19" && typeof mod.config.entityType === "string") {
          const entityType = mod.config.entityType;
          const bound = entityWorkflows.get(entityType) ?? [];
          if (bound.length === 0) {
            problems.push(`entity "${entityType}" (APP.F19) has no entities[].workflows binding`);
          } else if (!bound.some((id) => definedIds.has(id))) {
            problems.push(`entity "${entityType}" (APP.F19) binds workflows [${bound.join(", ")}], none of which have a solution/workflows/*.ts definition`);
          }
        } else if (mod.moduleFeatureId === "APP.F06" && typeof mod.config.workflowId === "string") {
          const workflowId = mod.config.workflowId;
          if (!definedIds.has(workflowId)) {
            problems.push(`workflowId "${workflowId}" (APP.F06) has no matching solution/workflows/*.ts definition`);
          }
        } else if (definedIds.size === 0) {
          problems.push(`module ${mod.moduleFeatureId} wires PS.WORKFLOW but the app has zero solution/workflows/*.ts definitions`);
        }
      }

      expect(problems, `apps/${app}:\n  - ${problems.join("\n  - ")}`).toEqual([]);
    });
  }

  // ── Self-tests: guard the checker logic itself ─────────────────────────────
  describe("matcher self-tests", () => {
    it("declaredWorkflowIds extracts the id from a well-formed definition file", () => {
      // Exercises the same regex the app-loop above uses, on a realistic fixture.
      const src = stripComments(`
        import type { WorkflowDefinition } from "@dbp/contracts/workflow-definition";
        export const riskReviewWorkflow: WorkflowDefinition = {
          id: "risk-review",
          name: "Risk Review",
          version: "1.0.0",
          initialStep: "identified",
          steps: [{ id: "identified", name: "Identified", type: "task", assigneeRoles: ["risk-manager"] }],
        };`);
      const m = /WorkflowDefinition\s*=\s*\{\s*id:\s*["']([^"']+)["']/.exec(src);
      expect(m?.[1]).toBe("risk-review");
    });

    it("workflowWiringModules only matches features whose wires include PS.WORKFLOW", () => {
      const manifest = {
        modules: [
          {
            features: [
              { id: "APP.F19", wires: ["PS.DATA"], config: { entityType: "control" } },
              { id: "APP.F06", wires: ["PS.WORKFLOW", "PS.RBAC"], config: { workflowId: "policy-approval" } },
            ],
          },
        ],
      };
      const result = workflowWiringModules(manifest);
      expect(result).toHaveLength(1);
      expect(result[0]?.moduleFeatureId).toBe("APP.F06");
      expect(result[0]?.config.workflowId).toBe("policy-approval");
    });

    it("entityWorkflowsMap ignores entities with no workflows[] and non-string entries", () => {
      const manifest = {
        entities: [
          { type: "risk", workflows: ["risk-review"] },
          { type: "control" },
          { type: "policy", workflows: [] },
        ],
      };
      const map = entityWorkflowsMap(manifest);
      expect(map.get("risk")).toEqual(["risk-review"]);
      expect(map.get("control")).toEqual([]);
      expect(map.get("policy")).toEqual([]);
    });
  });
});
