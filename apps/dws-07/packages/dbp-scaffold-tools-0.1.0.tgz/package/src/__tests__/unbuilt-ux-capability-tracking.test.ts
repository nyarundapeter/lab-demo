import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Tracks base-UX capabilities required by
 * docs/03-features/specs/layout-template-definition-of-done.md §6 that were
 * found (2026-07-09) to have zero underlying implementation — not merely
 * untested, genuinely unbuilt.
 *
 * Pattern for a genuine gap: `it.fails(...)` — Vitest's built-in "expected to
 * fail" API (stable since 0.31; this repo is on vitest@3.2.6, see
 * packages/shared/scaffold-tools/package.json). The suite stays green while
 * the capability is missing. The moment someone implements it, the wrapped
 * assertion starts passing, `it.fails` flips to a real failure ("this test
 * unexpectedly passed"), and CI goes red — forcing whoever shipped the
 * capability to remove `.fails` and turn the block into a real ratchet (see
 * page-frame-contract.test.ts for that shape: a positive assertion plus an
 * "allowlist entries still needed" prune check).
 *
 * This is the inverse of a normal ratchet: a normal ratchet bans a pattern
 * that must stay absent; `it.fails` here tracks a capability that must stay
 * present-as-missing until built.
 *
 * Not every capability below turned out to be missing — see §6.4 for a case
 * where the grep that motivated this file was wrong and the real state is a
 * passing ratchet, not a gap tracker.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");

function readIfExists(relPath: string): string {
  const abs = path.join(REPO_ROOT, relPath);
  return fs.existsSync(abs) ? fs.readFileSync(abs, "utf8") : "";
}

function listFiles(dir: string, predicate: (f: string) => boolean): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listFiles(abs, predicate));
    else if (predicate(abs)) out.push(abs);
  }
  return out;
}

function concatMatchingFiles(relDirs: string[], extensions: string[]): string {
  const files = relDirs.flatMap((relDir) =>
    listFiles(path.join(REPO_ROOT, relDir), (f) => extensions.some((ext) => f.endsWith(ext)))
  );
  return files.map((f) => fs.readFileSync(f, "utf8")).join("\n");
}

// ─────────────────────────────────────────────────────────────────────────
// §6.2 Theming / dark mode
// docs/03-features/specs/layout-template-definition-of-done.md §6.2
//
// BUILT (2026-07-27, PR #64): packages/shared/design-tokens/theme.css now
// carries a contrast-gated dark override mechanism (dark toggle + dark
// ramp). Retired from `it.fails` gap tracker to a real ratchet — it must
// keep passing; if it starts failing, someone removed the dark-mode
// mechanism and it must be restored before ship.
describe("§6.2 dark mode — capability ratchet", () => {
  it("theme.css defines a dark-mode override mechanism", () => {
    const themeCss = readIfExists("packages/shared/design-tokens/theme.css");
    const hasDarkOverride = /\.dark\b/.test(themeCss) || /prefers-color-scheme:\s*dark/.test(themeCss);
    expect(
      hasDarkOverride,
      "No dark-mode override found in packages/shared/design-tokens/theme.css. " +
        "This capability was previously built (PR #64) — if it's gone, restore it before shipping. " +
        "See docs/03-features/specs/layout-template-definition-of-done.md §6.2."
    ).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────
// §6.4 Motion
// docs/03-features/specs/layout-template-definition-of-done.md §6.4
//
// NOT A GAP (verified 2026-07-09, contra the initial assumption that
// motivated this file): packages/shared/design-tokens/base.css already
// carries a global `@media (prefers-reduced-motion: reduce)` block that
// zeroes animation/transition duration and forces `scroll-behavior: auto`
// for every element, and packages/shared/ui/src/bindings/AssistantPanel.tsx
// reads `matchMedia("(prefers-reduced-motion: reduce)")` directly in JS.
// That satisfies the DoD's required test verbatim ("an assertion that motion
// is gated behind the reduced-motion media query"), so — unlike §6.2/§6.9 —
// this is written as a REAL ratchet, not `it.fails`. It must keep passing.
// If it starts failing, someone removed the reduced-motion gate and it must
// be restored before ship; only then would this legitimately become a gap
// tracker again.
describe("§6.4 motion — reduced-motion ratchet", () => {
  it("prefers-reduced-motion is gated somewhere in design-tokens or ui", () => {
    const src = concatMatchingFiles(
      ["packages/shared/design-tokens", "packages/shared/ui/src"],
      [".css", ".ts", ".tsx"]
    );
    const hasReducedMotionGate = /prefers-reduced-motion/.test(src);
    expect(
      hasReducedMotionGate,
      "No prefers-reduced-motion handling found under packages/shared/design-tokens or " +
        "packages/shared/ui/src. This capability was previously built (see base.css's global " +
        "@media (prefers-reduced-motion: reduce) block) — if it's gone, restore it before shipping. " +
        "See docs/03-features/specs/layout-template-definition-of-done.md §6.4."
    ).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────
// §6.9 Density
// docs/03-features/specs/layout-template-definition-of-done.md §6.9
//
// BUILT (2026-07-27, PR #64): 3-mode dashboard density now has a real
// consumer (`data-density` / `.density-compact` / `.density-comfortable` or
// a `getPropertyValue("--density")` read). Retired from `it.fails` gap
// tracker to a real ratchet — it must keep passing; if it starts failing,
// someone removed the density consumer and it must be restored before ship.
describe("§6.9 density — capability ratchet", () => {
  it("something reads/branches on --density", () => {
    const src = concatMatchingFiles(
      ["packages/shared/ui/src", "packages/stack/app-scaffolds"],
      [".css", ".ts", ".tsx"]
    );
    const hasDensityConsumer =
      /data-density/.test(src) ||
      /density-compact|density-comfortable/.test(src) ||
      /getPropertyValue\(\s*["']--density["']\s*\)/.test(src);
    expect(
      hasDensityConsumer,
      "No consumer of --density found under packages/shared/ui/src or packages/stack/app-scaffolds " +
        "(no data-density attribute, no .density-compact/.density-comfortable class, no JS reading the CSS var). " +
        "This capability was previously built (PR #64) — if it's gone, restore it before shipping. " +
        "See docs/03-features/specs/layout-template-definition-of-done.md §6.9."
    ).toBe(true);
  });
});
