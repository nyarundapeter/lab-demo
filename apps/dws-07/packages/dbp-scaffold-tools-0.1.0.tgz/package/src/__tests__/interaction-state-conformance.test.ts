import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * DoD §6.3 "Interaction states" ratchet (docs/03-features/specs/layout-template-definition-of-done.md):
 * "hover / focus / active / disabled / selected are styled and correct... lint for
 * interactive elements missing focus styles."
 *
 * This test is scoped to focus-visible: every `@dbp/ui` component that renders a native
 * interactive control must carry SOME visible focus-state styling. It is a WARN-BASELINE
 * ratchet — it locks in today's (mostly clean) state and tracks known gaps in an explicit
 * allowlist, rather than requiring 100% coverage up front.
 *
 * Detection is file-level and heuristic in both directions:
 *  - "is this component interactive?" — literal native tags/attrs (<button>, <input>,
 *    <select>, <textarea>, role="button|tab|checkbox|switch", onClick=), PLUS Radix
 *    primitives that render a focusable trigger/item under the hood (checkbox, switch,
 *    tabs, select, dialog, dropdown-menu, toast) and the button.tsx `asChild ? Slot : "button"`
 *    polymorphic-button pattern. Purely decorative/non-focusable Radix primitives
 *    (separator, scroll-area, progress, tooltip content) are deliberately NOT treated
 *    as interactive markers — they don't render a native focusable control themselves.
 *  - "does it have focus styling?" — the string `focus-visible` (covers both the
 *    `focus-visible:` variant and arbitrary-selector forms like `has-[:focus-visible]`),
 *    or a `focus:` Tailwind variant anywhere in the file. This is file-level, not
 *    per-element — matching the coarse grain of the existing ratchets in this directory.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const COMPONENTS_DIR = path.join(REPO_ROOT, "packages/shared/ui/src/components");

/** Relative-to-repo path → reason it is allowed to lack focus-visible styling. */
// 2026-07-10 (H1 red-abnormal pass): workspace-greeting-card.tsx and featured-carousel.tsx
// both now carry focus-visible styling — allowlist is empty.
const ALLOWLIST: Record<string, string> = {
  // 2026-07-17: the only interactive markers in this file are onClick handlers passed to
  // @dbp/ui <Button> components, which carry their own focus-visible styling internally
  // (button.tsx). The file renders no native interactive control of its own — file-level
  // heuristic false positive, not a real focus-visible gap.
  "packages/shared/ui/src/components/workflow-status-summary.tsx":
    "interactive markers are @dbp/ui Button usages (Button owns its focus-visible styling); no native controls in this file",
};

function rel(abs: string) {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

function listFiles(dir: string, predicate: (f: string) => boolean): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listFiles(abs, predicate));
    else if (predicate(abs)) out.push(abs);
  }
  return out;
}

const componentFiles = listFiles(
  COMPONENTS_DIR,
  (f) => f.endsWith(".tsx") && !f.endsWith(".stories.tsx")
);

/** Markers that identify a component as rendering (or driving) a native interactive control. */
const INTERACTIVE_MARKERS: { label: string; re: RegExp }[] = [
  { label: "<button>", re: /<button\b/ },
  { label: "<input>", re: /<input\b/ },
  { label: "<select>", re: /<select\b/ },
  { label: "<textarea>", re: /<textarea\b/ },
  { label: 'role="button"', re: /role=["']button["']/ },
  { label: 'role="tab"', re: /role=["']tab["']/ },
  { label: 'role="checkbox"', re: /role=["']checkbox["']/ },
  { label: 'role="switch"', re: /role=["']switch["']/ },
  { label: "onClick=", re: /onClick=/ },
  {
    label: 'polymorphic button (Comp = asChild ? Slot : "button")',
    re: /["']button["']/,
  },
  {
    label: "Radix interactive primitive (checkbox/switch/tabs/select/dialog/dropdown-menu/toast)",
    re: /@radix-ui\/react-(checkbox|switch|tabs|dialog|dropdown-menu|select|toast)/,
  },
];

/** Any visible focus-state styling, however it is expressed. */
const FOCUS_STYLED_RE = /focus-visible|focus:/;

function isInteractive(src: string): string[] {
  const hits: string[] = [];
  for (const { label, re } of INTERACTIVE_MARKERS) {
    if (re.test(src)) hits.push(label);
  }
  return hits;
}

describe("interaction-state conformance (DoD §6.3 focus-visible ratchet)", () => {
  it("finds component files to scan", () => {
    expect(componentFiles.length).toBeGreaterThan(20);
  });

  it("every interactive @dbp/ui component has some focus-visible styling", () => {
    const missing: string[] = [];
    for (const abs of componentFiles) {
      const r = rel(abs);
      if (ALLOWLIST[r]) continue;
      const src = fs.readFileSync(abs, "utf8");
      const interactiveHits = isInteractive(src);
      if (interactiveHits.length === 0) continue;
      if (!FOCUS_STYLED_RE.test(src)) {
        missing.push(`${r}: interactive via [${interactiveHits.join(", ")}] but no focus-visible/focus: styling found`);
      }
    }
    expect(
      missing,
      `Interactive elements missing focus-visible styling — see docs/03-features/specs/layout-template-definition-of-done.md §6.3:\n${missing.join("\n")}`
    ).toEqual([]);
  });

  it("allowlist entries still exist and are still interactive without focus-visible styling", () => {
    for (const [relPath, reason] of Object.entries(ALLOWLIST)) {
      const abs = path.join(REPO_ROOT, relPath);
      expect(fs.existsSync(abs), `allowlisted file missing: ${relPath}`).toBe(true);
      const src = fs.readFileSync(abs, "utf8");
      const stillInteractive = isInteractive(src).length > 0;
      expect(stillInteractive, `allowlist entry no longer interactive (remove it): ${relPath} — ${reason}`).toBe(true);
      const stillMissingFocus = !FOCUS_STYLED_RE.test(src);
      expect(stillMissingFocus, `allowlist entry no longer needed (remove it): ${relPath} — ${reason}`).toBe(true);
    }
  });
});
