import { describe, it, expect, vi, afterEach } from "vitest";
// Unit-level proof of the Wave 2 mount seam: manifest `standard_menu_organisms`
// (packages/shared/contracts/src/solution-manifest.ts) lets a manifest author
// route-target a standard-menu-SYNTHESIZED page onto the durable pageComponent +
// composesOrganism seam (same seam a hand-authored module uses — see
// generator-emission.test.ts's "generator — pageComponent seam" describe block,
// which proves the DOWNSTREAM scaffold-solution.mjs emission for that seam).
// This file only exercises buildModules() itself — cheap, no subprocess spawn —
// since buildModules() is the new code (translating the override into
// mod.pageComponent/mod.composesOrganism on the synthesized module object before
// it is merged into manifest.modules by scaffold-solution.mjs).
// @ts-expect-error — plain .mjs script, no types
import { buildModules, buildNavSections } from "../../../../../scripts/standard-menu-scaffold.mjs";

interface SynthModule {
  route: string;
  pageComponent?: string;
  composesOrganism?: string;
  features: Array<{ id: string }>;
}

function manifest(overrides: Record<string, unknown>[] = [], consumes: string[] = ["PS.DATA"]) {
  return {
    platform: "TST",
    solution: "TST.01",
    name: "Organism Override Test",
    consumes_platform_services: consumes,
    modules: [] as Array<{ route: string }>,
    standard_menu_organisms: overrides,
  };
}

const navSections = buildNavSections();

describe("standard-menu organism override seam — buildModules()", () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("sets pageComponent + composesOrganism on the matched synthesized module, deriving the default pageComponent path", () => {
    const mods = buildModules(
      manifest([{ route: "/manage-work/tasks", composesOrganism: "case-workspace" }], ["PS.WORKFLOW"]),
      navSections,
    ) as SynthModule[];
    const mod = mods.find((m) => m.route === "/manage-work/tasks");
    expect(mod).toBeTruthy();
    expect(mod!.pageComponent).toBe("solution/pages/CaseWorkspace");
    expect(mod!.composesOrganism).toBe("case-workspace");
  });

  it("honors an explicit pageComponent path instead of deriving one", () => {
    const mods = buildModules(
      manifest(
        [{ route: "/manage-work/tasks", composesOrganism: "case-workspace", pageComponent: "solution/pages/Cases" }],
        ["PS.WORKFLOW"],
      ),
      navSections,
    ) as SynthModule[];
    const mod = mods.find((m) => m.route === "/manage-work/tasks");
    expect(mod!.pageComponent).toBe("solution/pages/Cases");
  });

  it("leaves modules with no matching override untouched (no pageComponent/composesOrganism fields)", () => {
    const mods = buildModules(
      manifest([{ route: "/manage-work/tasks", composesOrganism: "case-workspace" }], ["PS.WORKFLOW"]),
      navSections,
    ) as SynthModule[];
    const sla = mods.find((m) => m.route === "/monitor-work/sla");
    expect(sla).toBeTruthy();
    expect(sla!.pageComponent).toBeUndefined();
    expect(sla!.composesOrganism).toBeUndefined();
  });

  it("warns and does not throw when an override route matches no synthesized module (typo / gated-off service)", () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    const mods = buildModules(
      manifest([{ route: "/no/such/route", composesOrganism: "case-workspace" }], ["PS.WORKFLOW"]),
      navSections,
    ) as SynthModule[];
    expect(mods.every((m) => m.pageComponent === undefined)).toBe(true);
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining("/no/such/route"));
  });

  it("warns (does not silently apply) when the override targets a route already owned by a real hand-authored module", () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    const m = manifest([{ route: "/manage-work/tasks", composesOrganism: "case-workspace" }], ["PS.WORKFLOW"]);
    m.modules = [{ route: "/manage-work/tasks" }];
    const mods = buildModules(m, navSections) as SynthModule[];
    expect(mods.find((mod) => mod.route === "/manage-work/tasks")).toBeUndefined();
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining("/manage-work/tasks"));
  });
});
