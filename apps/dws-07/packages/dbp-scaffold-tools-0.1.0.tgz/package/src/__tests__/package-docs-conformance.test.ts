import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * D7.4 ratchet for package-level docs
 * (docs/09-plans/factory-knowledge-controls-spec-2026-07-10.md Wave 2).
 *
 * Every workspace package under packages/ must carry a README.md and
 * CHANGELOG.md that stay honest: the README must name the package, and the
 * CHANGELOG's topmost version heading must match package.json#version, so a
 * version bump without a changelog entry (or a rename without a README
 * update) fails the build instead of drifting silently.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const PACKAGES_DIR = path.join(REPO_ROOT, "packages");

/** package.json dir (repo-relative) → honest reason it is exempt from a check. */
const ALLOWLIST: Record<string, string> = {};

interface PackageInfo {
  dir: string;
  relDir: string;
  name: string;
  version: string;
}

/** Recursively find every package.json not under node_modules. */
function findPackageJsonDirs(startDir: string): string[] {
  const results: string[] = [];
  if (!fs.existsSync(startDir)) return results;
  const entries = fs.readdirSync(startDir, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.isDirectory()) {
      if (entry.name === "node_modules") continue;
      results.push(...findPackageJsonDirs(path.join(startDir, entry.name)));
    } else if (entry.isFile() && entry.name === "package.json") {
      results.push(startDir);
    }
  }
  return results;
}

const packageDirs = findPackageJsonDirs(PACKAGES_DIR);

const packages: PackageInfo[] = packageDirs.map((dir) => {
  const pkgJson = JSON.parse(fs.readFileSync(path.join(dir, "package.json"), "utf8"));
  return {
    dir,
    relDir: path.relative(REPO_ROOT, dir).replace(/\\/g, "/"),
    name: pkgJson.name ?? "",
    version: pkgJson.version ?? "",
  };
});

/** First `## [x.y.z]`-style heading in a changelog. */
function extractTopVersionHeading(text: string): string | null {
  const match = text.match(/^##\s*\[?([^\]\s]+)\]?/m);
  return match ? (match[1] ?? null) : null;
}

describe("Package docs conformance (D7.4)", () => {
  it("discovered at least one workspace package", () => {
    expect(packages.length).toBeGreaterThan(0);
  });

  it("every package has a non-empty README.md", () => {
    const violations: string[] = [];
    for (const pkg of packages) {
      if (ALLOWLIST[pkg.relDir]) continue;
      const readmePath = path.join(pkg.dir, "README.md");
      const exists = fs.existsSync(readmePath);
      const nonEmpty = exists && fs.readFileSync(readmePath, "utf8").trim().length > 0;
      if (!exists || !nonEmpty) violations.push(pkg.relDir);
    }
    expect(violations, `packages missing a non-empty README.md:\n${violations.join("\n")}`).toEqual([]);
  });

  it("every package has a non-empty CHANGELOG.md", () => {
    const violations: string[] = [];
    for (const pkg of packages) {
      if (ALLOWLIST[pkg.relDir]) continue;
      const changelogPath = path.join(pkg.dir, "CHANGELOG.md");
      const exists = fs.existsSync(changelogPath);
      const nonEmpty = exists && fs.readFileSync(changelogPath, "utf8").trim().length > 0;
      if (!exists || !nonEmpty) violations.push(pkg.relDir);
    }
    expect(violations, `packages missing a non-empty CHANGELOG.md:\n${violations.join("\n")}`).toEqual([]);
  });

  it("every README states the package's own name", () => {
    const violations: string[] = [];
    for (const pkg of packages) {
      if (ALLOWLIST[pkg.relDir]) continue;
      const readmePath = path.join(pkg.dir, "README.md");
      if (!fs.existsSync(readmePath)) continue;
      const text = fs.readFileSync(readmePath, "utf8");
      if (!pkg.name || !text.includes(pkg.name)) violations.push(`${pkg.relDir} (name: ${pkg.name})`);
    }
    expect(
      violations,
      `README does not mention package.json#name (rename drift):\n${violations.join("\n")}`,
    ).toEqual([]);
  });

  it("every CHANGELOG's topmost version heading matches package.json#version", () => {
    const violations: string[] = [];
    for (const pkg of packages) {
      if (ALLOWLIST[pkg.relDir]) continue;
      const changelogPath = path.join(pkg.dir, "CHANGELOG.md");
      if (!fs.existsSync(changelogPath)) continue;
      const text = fs.readFileSync(changelogPath, "utf8");
      const topHeading = extractTopVersionHeading(text);
      if (topHeading !== pkg.version) {
        violations.push(`${pkg.relDir}: changelog top=${topHeading ?? "<none>"} vs package.json=${pkg.version}`);
      }
    }
    expect(
      violations,
      `CHANGELOG top version heading does not match package.json#version:\n${violations.join("\n")}`,
    ).toEqual([]);
  });

  it("every allowlisted package has an honest, non-empty reason", () => {
    for (const [relDir, reason] of Object.entries(ALLOWLIST)) {
      expect(reason.length, `empty/too-short allowlist reason for ${relDir}`).toBeGreaterThan(10);
    }
  });

  it("allowlist entries still exist as packages (prune stale allowlist)", () => {
    const knownDirs = new Set(packages.map((p) => p.relDir));
    for (const [relDir, reason] of Object.entries(ALLOWLIST)) {
      expect(knownDirs.has(relDir), `allowlisted package no longer exists (remove it): ${relDir} — ${reason}`).toBe(
        true,
      );
    }
  });
});
