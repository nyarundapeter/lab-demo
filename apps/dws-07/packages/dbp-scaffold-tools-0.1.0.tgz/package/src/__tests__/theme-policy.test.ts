import { describe, it, expect } from "vitest";
// @ts-expect-error — plain .mjs script module, no types
import { assertThemeColours, firstFontFamily, hexToHsl } from "../../../../../scripts/theme-policy.mjs";

/**
 * Unit tests for the generator's theme-token policy (scripts/theme-policy.mjs):
 *   - colour gate (brand = accent, neutral surfaces)
 *   - font guard (the Arial-fallback trap)
 *   - radius advisory
 * Run the pure functions directly — no generator boot.
 */

/** Collect die()/warn() instead of exiting, so we can assert on them. */
function run(theme: Record<string, string>) {
  const died: string | null = null;
  const warnings: string[] = [];
  assertThemeColours(theme, "TEST.01", {
    die: (m: string) => { throw new Error(m); },
    warn: (m: string) => warnings.push(m),
  });
  return { died, warnings };
}

describe("firstFontFamily", () => {
  it("parses the first family, stripping quotes + casing", () => {
    expect(firstFontFamily("'Inter', sans-serif")).toBe("inter");
    expect(firstFontFamily('"Plus Jakarta Sans", system-ui')).toBe("plus jakarta sans");
    expect(firstFontFamily("Plus Jakarta Sans")).toBe("plus jakarta sans");
    expect(firstFontFamily(undefined as unknown as string)).toBeNull();
  });
});

describe("colour gate", () => {
  it("passes DQ navy primary + orange accent (#030F35 / #FB5535)", () => {
    expect(() => run({ "--color-primary": "#030F35", "--color-secondary": "#FB5535" })).not.toThrow();
  });

  it("rejects a primary that IS the brand hue (orange primary + orange accent)", () => {
    expect(() => run({ "--color-primary": "#FB5535", "--color-secondary": "#F4632E" }))
      .toThrow(/same colour|brand hue must be/i);
  });

  it("rejects a brand-tinted surface", () => {
    expect(() => run({ "--color-primary": "#030F35", "--color-secondary": "#FB5535", "--color-surface": "#FBE3DC" }))
      .toThrow(/tint of the brand/i);
  });
});

describe("font guard (Arial trap)", () => {
  it("rejects a font pinned to an un-loaded family (Inter)", () => {
    expect(() => run({ "--color-primary": "#030F35", "--color-secondary": "#FB5535", "--font-body": "'Inter', sans-serif" }))
      .toThrow(/does not @import|fall back to the system default|Arial/i);
  });

  it("allows the loaded DQ font", () => {
    expect(() => run({ "--color-primary": "#030F35", "--color-secondary": "#FB5535", "--font-body": "'Plus Jakarta Sans', sans-serif" }))
      .not.toThrow();
  });

  it("allows a bare generic keyword", () => {
    expect(() => run({ "--color-primary": "#030F35", "--color-secondary": "#FB5535", "--font-body": "sans-serif" }))
      .not.toThrow();
  });

  it("guards --font-display too", () => {
    expect(() => run({ "--color-primary": "#030F35", "--color-secondary": "#FB5535", "--font-display": "Roboto" }))
      .toThrow(/font policy/i);
  });
});

describe("radius advisory", () => {
  it("warns (does not throw) on a sub-6px radius", () => {
    const { warnings } = run({ "--color-primary": "#030F35", "--color-secondary": "#FB5535", "--radius": "4px" });
    expect(warnings.some((w) => /below 6px|dated hard corner/i.test(w))).toBe(true);
  });

  it("is silent at the 8px default", () => {
    const { warnings } = run({ "--color-primary": "#030F35", "--color-secondary": "#FB5535", "--radius": "8px" });
    expect(warnings).toHaveLength(0);
  });
});

describe("hexToHsl", () => {
  it("returns near-zero chroma for neutrals and high chroma for saturated hues", () => {
    expect(hexToHsl("#FFFFFF")!.c).toBeCloseTo(0, 5);
    expect(hexToHsl("#FB5535")!.c).toBeGreaterThan(0.5);
    expect(hexToHsl("not-a-hex")).toBeNull();
  });
});
