import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * SP-5 ratchet: every apps/<app>/solution/workflows/*.ts definition must be
 * registered in that app's generated PS.WORKFLOW route mount's
 * bootstrapWorkflow() — the route-chunk-bootstrap rule: registration must
 * happen in the SAME chunk that serves workflow requests. Registration via
 * instrumentation.ts alone does NOT satisfy this contract (it populates a
 * different chunk's module-scoped service instance) and is not accepted as a
 * satisfying source.
 *
 * Static analysis of source text (no generator invocation, no build). To avoid
 * false passes, comments are stripped before matching and the export name must
 * appear as an argument to an actual putDefinition(...) call — a name that only
 * appears in a comment or an unused import does not count.
 *
 * Excluded apps (documented, not silently skipped):
 *   - dws-04: pre-route-group era per repo convention; currently declares ZERO
 *     solution/workflows/*.ts definitions, so the exclusion is inert today.
 *     Excluded defensively so a future workflow addition is caught by a human
 *     decision, not a silent pass.
 *   - dws-03: was excluded on the same basis until it adopted the ADR-0039
 *     relational-data-model pilot and gained real workflows (risk-review,
 *     finding-remediation, policy-approval) — now included and checked.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const APPS_DIR = path.join(REPO_ROOT, "apps");

const EXCLUDED_APPS = new Set(["dws-04", "__boundary-fixtures__", "hello"]);

/**
 * Strips // line comments and block comments (string-literal-naive, fine for
 * generated route mounts which never embed those tokens in string literals).
 */
function stripComments(src: string): string {
  return src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/[^\n]*/g, "");
}

function findWorkflowExports(workflowsDir: string): string[] {
  if (!fs.existsSync(workflowsDir)) return [];
  const names: string[] = [];
  for (const entry of fs.readdirSync(workflowsDir, { withFileTypes: true })) {
    if (!entry.isFile() || !entry.name.endsWith(".ts") || entry.name.endsWith(".d.ts")) continue;
    const src = stripComments(fs.readFileSync(path.join(workflowsDir, entry.name), "utf8"));
    const re = /export const (\w+)\s*:\s*WorkflowDefinition\b/g;
    let m;
    while ((m = re.exec(src))) if (m[1] !== undefined) names.push(m[1]);
  }
  return names;
}

/** True iff `exportName` appears as an argument to a putDefinition(...) call. */
function isRegisteredViaPutDefinition(strippedSrc: string, exportName: string): boolean {
  const re = new RegExp(`putDefinition\\s*\\([^)]*\\b${exportName}\\b[^)]*\\)`);
  return re.test(strippedSrc);
}

const apps = fs.existsSync(APPS_DIR)
  ? fs.readdirSync(APPS_DIR, { withFileTypes: true })
      .filter((e) => e.isDirectory() && !EXCLUDED_APPS.has(e.name))
      .map((e) => e.name)
  : [];

describe("SP-5: workflow auto-registration ratchet", () => {
  for (const app of apps) {
    const workflowsDir = path.join(APPS_DIR, app, "solution/workflows");
    const exportNames = findWorkflowExports(workflowsDir);
    if (exportNames.length === 0) continue; // nothing to register for this app

    it(`apps/${app}: every solution/workflows/*.ts definition is putDefinition()'d in the workflow route mount`, () => {
      const routeFile = path.join(APPS_DIR, app, "app/api/platform/workflow/[[...path]]/route.ts");
      expect(
        fs.existsSync(routeFile),
        `apps/${app} declares solution workflows (${exportNames.join(", ")}) but has no ` +
          `generated PS.WORKFLOW route mount at app/api/platform/workflow/[[...path]]/route.ts. ` +
          `Registration via instrumentation.ts alone does not populate the chunk that serves ` +
          `workflow requests (route-chunk-bootstrap rule).`,
      ).toBe(true);

      const routeSrc = stripComments(fs.readFileSync(routeFile, "utf8"));
      const unregistered = exportNames.filter((name) => !isRegisteredViaPutDefinition(routeSrc, name));
      expect(
        unregistered,
        `apps/${app}: the following solution/workflows/*.ts exports are never passed to ` +
          `putDefinition(...) in the workflow route mount — they will never be registered in ` +
          `the chunk that serves workflow requests (comments/imports alone do not count; ` +
          `instrumentation.ts registration does not satisfy the route-chunk-bootstrap rule): ` +
          `${unregistered.join(", ")}`,
      ).toEqual([]);
    });
  }

  // ── Self-tests: guard the matcher itself against false passes/failures ────
  describe("matcher self-tests (negative fixtures)", () => {
    const registered = `
      async function bootstrapWorkflow(): Promise<void> {
        const { demoWorkflow } = await import("../../../../../solution/workflows/demo.js");
        await wfSvc.storage.putDefinition(TENANT, demoWorkflow);
      }`;

    it("accepts a real putDefinition(TENANT, <name>) call", () => {
      expect(isRegisteredViaPutDefinition(stripComments(registered), "demoWorkflow")).toBe(true);
    });

    it("rejects a name that appears only in comments", () => {
      const src = stripComments(`
        // TODO: register demoWorkflow via putDefinition here
        /* const { demoWorkflow } = ...; await wfSvc.storage.putDefinition(TENANT, demoWorkflow); */
        async function bootstrapWorkflow(): Promise<void> { void wfSvc; }`);
      expect(isRegisteredViaPutDefinition(src, "demoWorkflow")).toBe(false);
    });

    it("rejects a name that is imported but never putDefinition()'d", () => {
      const src = stripComments(`
        const { demoWorkflow } = await import("../../../../../solution/workflows/demo.js");
        void demoWorkflow;`);
      expect(isRegisteredViaPutDefinition(src, "demoWorkflow")).toBe(false);
    });

    it("rejects a putDefinition call for a DIFFERENT workflow", () => {
      expect(isRegisteredViaPutDefinition(stripComments(registered), "otherWorkflow")).toBe(false);
    });
  });
});
