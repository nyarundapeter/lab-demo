import { describe, it, expect } from "vitest";
// The standard-menu scaffold is the generator path that turns each menu Feature into
// a synthetic demo module in its archetype's layout. buildModules applies the real
// LAYOUT_EMIT (lve/conversational -> bare), featuresFor (archetype -> feature
// template), and ARCH_WIRES gating (conversational needs PS.AI). Locking it here
// fails the build if anyone edits the archetype map without updating
// docs/03-Features/specs/ARCHETYPE-REFERENCE-SPEC.md §6/§7.
//
// NOTE: chooseLayout() in scripts/scaffold-solution.mjs (the feature-mix inference
// ladder) is NOT exercised here — it is a closure in the generator core and a safe
// extraction is a separate follow-up (see the enforcement plan). The standard-menu
// path below is the dominant layout-selection path and is fully locked.
// @ts-expect-error — plain .mjs script, no types
import { buildModules, buildNavSections, STANDARD_MENU } from "../../../../../scripts/standard-menu-scaffold.mjs";

// Routes the generator emits via dedicated archetype emitters, NOT buildModules.
const ARCHETYPE_ROUTES = new Set(["/home", "/copilot", "/home/onboarding"]);

// Shape of scripts/standard-menu.json as consumed by this test (route + archetype
// per feature) — the JSON has more fields (icon, layout, label, …) that we don't
// assert on here, so this intentionally only models what's read below.
interface StandardMenuFeature {
  route: string;
  archetype: string;
}
interface StandardMenuGroup {
  features: StandardMenuFeature[];
}
interface StandardMenuArea {
  groups: StandardMenuGroup[];
}
interface StandardMenu {
  areas: StandardMenuArea[];
}

// archetype -> { emitted layout id, feature template ids } (spec §6/§7).
// Emit ids are the canonical LAYOUT_IDS (page-vocabulary.ts, decided 2026-07-07);
// the archetype keys here are the DOC vocabulary (Tier 2, not yet renamed).
const EXPECT: Record<string, { layout: string; features: string[] }> = {
  working: { layout: "object-page-detail", features: ["APP.F01"] },
  // LVE under object-page-detail layout (standard PageHeader) + externalHeader;
  // list & detail render within the framed content. Was "bare" — looked
  // non-compliant. See §4.3.
  lve: { layout: "object-page-detail", features: ["APP.F19"] },
  analytics: { layout: "analytics-dashboard", features: ["ANL.F03", "ANL.F02"] },
  // CatalogueLayout provides the factory PageHeader; CatalogGrid renders header-less
  // (headline/lede omitted) → single header. See ARCHETYPE-REFERENCE-SPEC §4.4.
  catalogue: { layout: "collection-grid", features: ["APP.F10"] },
  conversational: { layout: "overview-grid", features: ["APP.F15"] },
  settings: { layout: "config-form-custom", features: ["APP.F01"] },
};

// Per-route overrides: /dashboards/operational and /dashboards/executive mount two
// extra ANL.F02 (Analytics Chart Panel) instances on top of the analytics baseline —
// funnel+ranking for operational, heatmap+summary for executive — to genuinely
// differentiate the two audiences (DR-7 fidelity, see featAnalytics() in
// scripts/standard-menu-scaffold.mjs). Same feature id, multiple mounted instances
// (different role/config per instance), which is expected — not a dedup bug.
const ROUTE_FEATURE_OVERRIDES: Record<string, string[]> = {
  "/dashboards/operational": ["ANL.F03", "ANL.F02", "ANL.F02", "ANL.F02"],
  "/dashboards/executive": ["ANL.F03", "ANL.F02", "ANL.F02", "ANL.F02"],
};

function manifest(consumes: string[]) {
  return {
    platform: "TST",
    solution: "TST.01",
    name: "Archetype Map Test",
    consumes_platform_services: consumes,
    modules: [],
  };
}

const navSections = buildNavSections();
const FULL = buildModules(manifest(["PS.DATA", "PS.AI"]), navSections) as Array<{
  route: string;
  layout: string;
  features: Array<{ id: string }>;
}>;
const byRoute = new Map(FULL.map((m) => [m.route, m]));

describe("standard-menu archetype map — layout + feature template", () => {
  // Walk the real menu; for every Feature whose archetype we lock, assert the
  // emitted module has the expected layout id and feature template ids.
  for (const area of (STANDARD_MENU as StandardMenu).areas) {
    for (const group of area.groups) {
      for (const feat of group.features) {
        if (ARCHETYPE_ROUTES.has(feat.route)) continue;
        const exp = EXPECT[feat.archetype as string];
        if (!exp) continue;
        const expectedFeatures = ROUTE_FEATURE_OVERRIDES[feat.route] ?? exp.features;
        it(`${feat.archetype} @ ${feat.route} -> layout '${exp.layout}', features [${expectedFeatures.join(", ")}]`, () => {
          const mod = byRoute.get(feat.route);
          expect(mod, `no module emitted for ${feat.route}`).toBeTruthy();
          expect(mod!.layout).toBe(exp.layout);
          expect(mod!.features.map((f) => f.id).sort()).toEqual([...expectedFeatures].sort());
        });
      }
    }
  }
});

describe("standard-menu archetype map — LAYOUT_EMIT normalization", () => {
  it("normalizes conversational to 'overview-grid' (copilot feature composed in a grid overview); lve to 'object-page-detail' (externalHeader)", () => {
    const lve = FULL.find((m) => m.features.some((f) => f.id === "APP.F19"));
    const conv = FULL.find((m) => m.features.some((f) => f.id === "APP.F15"));
    expect(lve?.layout).toBe("object-page-detail");
    expect(conv?.layout).toBe("overview-grid");
  });

  it("keeps working/analytics/catalogue/settings mapped to their own distinct layout ids", () => {
    expect(FULL.find((m) => m.layout === "object-page-detail")).toBeTruthy();
    expect(FULL.find((m) => m.layout === "analytics-dashboard")).toBeTruthy();
    expect(FULL.find((m) => m.layout === "collection-grid")).toBeTruthy();
    expect(FULL.find((m) => m.layout === "config-form-custom")).toBeTruthy();
  });
});

describe("standard-menu archetype map — ARCH_WIRES gating", () => {
  it("emits conversational (PS.AI) demo pages only when PS.AI is consumed", () => {
    const withAI = FULL.some((m) => m.features.some((f) => f.id === "APP.F15"));
    const withoutAI = (
      buildModules(manifest(["PS.DATA"]), navSections) as Array<{ features: Array<{ id: string }> }>
    ).some((m) => m.features.some((f) => f.id === "APP.F15"));
    expect(withAI).toBe(true);
    expect(withoutAI).toBe(false);
  });
});
