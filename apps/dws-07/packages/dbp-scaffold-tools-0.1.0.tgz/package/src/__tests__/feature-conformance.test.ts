import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Feature conformance ratchet (docs/plans/factory-conformance-enforcement-plan.md).
 *
 * Makes the factory self-policing: a NEW feature that hardcodes a colour, types
 * its config as `Record<string, unknown>`, ships no stories, or paints its own
 * page header fails the build — before review. Mirrors the page-frame-contract
 * ratchet: scan source, ban the tell, allowlist tracked debt WITH A REASON.
 *
 * Allowlist entries are debt to burn down — never add one without a reason, and
 * the "prune stale allowlist" test removes them once the file is clean.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const FEATURES_DIR = path.join(REPO_ROOT, "packages/stack/app-scaffolds/features");

function rel(abs: string): string {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

function listTsx(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === "node_modules") continue;
      out.push(...listTsx(abs));
    } else if (e.name.endsWith(".tsx") || e.name.endsWith(".ts")) {
      out.push(abs);
    }
  }
  return out;
}

// Non-package dirs that can appear inside the @dbp/organisms package root (which
// IS packages/stack/app-scaffolds/features) once it's built/typechecked/tested via
// turbo — mirrors the NON_PACKAGE_DIRS fix in infra/05-policy/check-drift.mjs
// (commit 0680a82b): a directory scan must not mistake tooling output for a feature.
const NON_FEATURE_DIRS = new Set(["node_modules", ".turbo"]);

const featureDirs = fs.existsSync(FEATURES_DIR)
  ? fs
      .readdirSync(FEATURES_DIR, { withFileTypes: true })
      .filter((e) => e.isDirectory() && !e.name.startsWith("_") && !e.name.startsWith(".") && !NON_FEATURE_DIRS.has(e.name))
      .map((e) => path.join(FEATURES_DIR, e.name))
  : [];

const isStory = (f: string) => f.endsWith(".stories.tsx");
const isTest = (f: string) => f.includes(`${path.sep}tests${path.sep}`) || f.endsWith(".test.ts") || f.endsWith(".test.tsx");
const indexOf = (dir: string) => path.join(dir, "index.tsx");

// ── Allowlists (path → reason). Burn these down. ──────────────────────────────

/** Features whose config param is still `Record<string, unknown>` (gap #15). */
const LOOSE_CONFIG_ALLOW: Record<string, string> = {
  // copilot-page + workbench-surface fixed (now z.input<typeof Config>) — burned down.
};

/** Feature roots allowed to import PageHeader/BreadcrumbBar (declared self-headered). */
const SELF_HEADERED_ALLOW: Record<string, string> = {
  "packages/stack/app-scaffolds/features/marketplace-item-detail/index.tsx": "detail page is self-headered: renders its own PageHeader + breadcrumb by design",
};

/** Feature dirs allowed to ship without stories (tracked DoD debt). */
const STORIES_ALLOW: Record<string, string> = {
  // contact-form stories added — burned down.
};

/** Files allowed to contain a hardcoded hex (tracked design-token debt). */
const HEX_ALLOW: Record<string, string> = {
  "packages/stack/app-scaffolds/features/case-workspace/index.tsx": "var(--color-surface,#fff) fallback — drop the hex fallback (RC-C/C4)",
  "packages/stack/app-scaffolds/features/contact-form/email-tokens.ts": "email HTML palette — email clients don't support CSS var(); literal hex required (legit exception, not debt)",
  // chart-colors.ts is already token-DERIVED at runtime (resolveCssVar); the hex is the
  // unavoidable SSR/test fallback for a JS-resolved palette. Legit exception, not debt.
  "packages/stack/app-scaffolds/features/chart-panel/components/chart-colors.ts": "SSR/test fallback for runtime token-resolved chart palette (legit exception)",
  "packages/stack/app-scaffolds/features/widget-grid/components/chart-colors.ts": "SSR/test fallback for runtime token-resolved chart palette (legit exception)",
  "packages/stack/app-scaffolds/features/marketplace-item-detail/index.tsx": "var(--color-surface-secondary,#F5F7FA) + var(--color-surface,#fff) fallbacks for detail page rendering",
};

const HEX_RE = /#[0-9a-fA-F]{3,8}\b|var\(\s*--[^,)]+,\s*#[0-9a-fA-F]{3,8}/;
// Only the public config alias — not internal data handlers like form-builder's
// onValid(data: Record<string, unknown>).
const LOOSE_CONFIG_RE = /type\s+ConfigInput\s*=\s*Record<string,\s*unknown>/;
const HEADER_IMPORT_RE = /import\s*\{[^}]*\b(PageHeader|BreadcrumbBar)\b[^}]*\}\s*from\s*["']@dbp\/ui["']/;

describe("feature conformance ratchet", () => {
  it("found the feature packages to scan", () => {
    expect(featureDirs.length).toBeGreaterThan(15);
  });

  it("every feature ships Storybook stories (Definition of Done)", () => {
    const missing = featureDirs
      .filter((d) => listTsx(d).filter(isStory).length === 0)
      .map((d) => rel(d))
      .filter((r) => !STORIES_ALLOW[r]);
    expect(missing, `Features missing *.stories.tsx:\n${missing.join("\n")}`).toEqual([]);
  });

  it("no feature types its public config as Record<string, unknown> (gap #15)", () => {
    const bad: string[] = [];
    for (const d of featureDirs) {
      const idx = indexOf(d);
      if (!fs.existsSync(idx)) continue;
      const r = rel(idx);
      if (LOOSE_CONFIG_ALLOW[r]) continue;
      if (LOOSE_CONFIG_RE.test(fs.readFileSync(idx, "utf8"))) bad.push(r);
    }
    expect(bad, `Feature config must be a typed Zod input, not Record<string, unknown>:\n${bad.join("\n")}`).toEqual([]);
  });

  it("no feature root paints its own header (single-header / body-only)", () => {
    const bad: string[] = [];
    for (const d of featureDirs) {
      const idx = indexOf(d);
      if (!fs.existsSync(idx)) continue;
      const r = rel(idx);
      if (SELF_HEADERED_ALLOW[r]) continue;
      if (HEADER_IMPORT_RE.test(fs.readFileSync(idx, "utf8"))) bad.push(r);
    }
    expect(bad, `Features must be body-only — the shell layout owns PageHeader/breadcrumb:\n${bad.join("\n")}`).toEqual([]);
  });

  it("no feature hardcodes a hex colour (tokens only)", () => {
    const bad: string[] = [];
    for (const d of featureDirs) {
      for (const f of listTsx(d)) {
        if (isStory(f) || isTest(f)) continue;
        const r = rel(f);
        if (HEX_ALLOW[r]) continue;
        if (HEX_RE.test(fs.readFileSync(f, "utf8"))) bad.push(r);
      }
    }
    expect(bad, `Hardcoded hex in feature source — use var(--color-*) tokens:\n${bad.join("\n")}`).toEqual([]);
  });

  it("allowlist entries still exist and still violate (prune stale allowlist)", () => {
    for (const [r, reason] of Object.entries({ ...LOOSE_CONFIG_ALLOW, ...SELF_HEADERED_ALLOW, ...HEX_ALLOW, ...STORIES_ALLOW })) {
      const abs = path.join(REPO_ROOT, r);
      expect(fs.existsSync(abs), `allowlisted file missing (remove it): ${r} — ${reason}`).toBe(true);
    }
  });
});

describe("public-shell layout archetype conformance (ADR-0036)", () => {
  // Public pages compose from the locked archetypes (A1 PublicPageHeader, A2 hero,
  // A3 white body, A4 tabs, A5 cta/footer). The clearest recurring defect was a
  // stray "← Back" link hand-rolled inside a header band — navigation is the shell
  // nav's job, not a per-page back-bar. Ban it across all public pages + the
  // generator templates so it cannot regress.
  const APPS_DIR = path.join(REPO_ROOT, "apps");
  const BACK_LINK_RE = /←\s*Back|Back to (home|marketplace)/i;

  function publicPageFiles(): string[] {
    if (!fs.existsSync(APPS_DIR)) return [];
    const out: string[] = [];
    for (const app of fs.readdirSync(APPS_DIR, { withFileTypes: true })) {
      if (!app.isDirectory() || app.name === "node_modules") continue;
      const appRoot = path.join(APPS_DIR, app.name, "app");
      for (const f of listTsx(appRoot)) {
        const p = rel(f);
        if (/\/app\/(\(public\)|marketplace|contact)\//.test(p)) out.push(f);
      }
    }
    return out;
  }

  it("no public page hand-rolls a '← Back' header link (shell nav owns navigation)", () => {
    const bad = publicPageFiles()
      .filter((f) => BACK_LINK_RE.test(fs.readFileSync(f, "utf8")))
      .map(rel);
    expect(
      bad,
      `Public pages must not contain a stray back-link (use the shell nav). Offending files:\n${bad.join("\n")}`,
    ).toEqual([]);
  });

  it("the generator does not emit a '← Back' header link in public templates", () => {
    const gen = path.join(REPO_ROOT, "scripts/scaffold-solution.mjs");
    if (!fs.existsSync(gen)) return;
    expect(
      BACK_LINK_RE.test(fs.readFileSync(gen, "utf8")),
      "scaffold-solution.mjs emits a '← Back' header link — public pages must use PublicPageHeader (ADR-0035)",
    ).toBe(false);
  });
});

describe("feature flags conformance — generated apps", () => {
  // Scans apps/ directories: any app whose solution/_arch/SOLUTION.md frontmatter
  // declares a feature_flags: block must have solution/flags/config.ts emitted.
  const APPS_DIR = path.join(REPO_ROOT, "apps");

  function parseFrontmatterFlags(solutionMdPath: string): boolean {
    if (!fs.existsSync(solutionMdPath)) return false;
    const content = fs.readFileSync(solutionMdPath, "utf8");
    // Presence check only — avoid pulling in the full YAML parser here
    return /^feature_flags:/m.test(content);
  }

  const appDirs = fs.existsSync(APPS_DIR)
    ? fs.readdirSync(APPS_DIR, { withFileTypes: true })
        .filter((e) => e.isDirectory() && e.name !== "node_modules")
        .map((e) => path.join(APPS_DIR, e.name))
    : [];

  it("every generated app with feature_flags in its arch manifest has solution/flags/config.ts", () => {
    const missing: string[] = [];
    for (const appDir of appDirs) {
      const archManifest = path.join(appDir, "solution/_arch/SOLUTION.md");
      if (!parseFrontmatterFlags(archManifest)) continue;
      const configTs = path.join(appDir, "solution/flags/config.ts");
      if (!fs.existsSync(configTs)) {
        missing.push(rel(appDir));
      }
    }
    expect(
      missing,
      `Apps with feature_flags in manifest but missing solution/flags/config.ts — regen with --force:\n${missing.join("\n")}`,
    ).toEqual([]);
  });
});

describe("solution-pages test coverage ratchet (STCB reinforcement lever 2)", () => {
  // Every SOLUTION-OWNED page component (solution/pages/*.tsx) must ship a matching
  // test at solution/pages/__tests__/<Name>.test.tsx. The generator emits a smoke
  // stub with every pageComponent stub, so new pages comply by construction — this
  // ratchet stops hand-added pages (or deleted stubs) from shipping untested.
  const APPS_DIR = path.join(REPO_ROOT, "apps");

  // Tracked debt — pages that predate the test-stub emission. Burn down, never add
  // without a reason; the prune test below removes entries once a test exists.
  // 2026-07-10 (H1 red-abnormal pass): apps/wfd-01/solution/pages/ApprovalsWorkspace.tsx
  // now has __tests__/ApprovalsWorkspace.test.tsx — entry pruned, allowlist is empty.
  const UNTESTED_PAGE_ALLOWLIST: Record<string, string> = {};

  function solutionPages(appDir: string): string[] {
    const pagesDir = path.join(appDir, "solution/pages");
    if (!fs.existsSync(pagesDir)) return [];
    return fs
      .readdirSync(pagesDir, { withFileTypes: true })
      .filter((e) => e.isFile() && e.name.endsWith(".tsx"))
      .map((e) => path.join(pagesDir, e.name));
  }

  const appDirs = fs.existsSync(APPS_DIR)
    ? fs
        .readdirSync(APPS_DIR, { withFileTypes: true })
        .filter((e) => e.isDirectory() && e.name !== "node_modules")
        .map((e) => path.join(APPS_DIR, e.name))
    : [];

  it("every solution/pages component has a matching test file", () => {
    const untested: string[] = [];
    for (const appDir of appDirs) {
      for (const page of solutionPages(appDir)) {
        const name = path.basename(page, ".tsx");
        const testPath = path.join(appDir, "solution/pages/__tests__", `${name}.test.tsx`);
        if (fs.existsSync(testPath)) continue;
        if (rel(page) in UNTESTED_PAGE_ALLOWLIST) continue;
        untested.push(rel(page));
      }
    }
    expect(
      untested,
      `solution/pages components without a test (add solution/pages/__tests__/<Name>.test.tsx):\n${untested.join("\n")}`,
    ).toEqual([]);
  });

  it("untested-page allowlist entries still exist and still lack a test (prune stale allowlist)", () => {
    const stale: string[] = [];
    for (const relPath of Object.keys(UNTESTED_PAGE_ALLOWLIST)) {
      const abs = path.join(REPO_ROOT, relPath);
      const name = path.basename(abs, ".tsx");
      const testPath = path.join(path.dirname(abs), "__tests__", `${name}.test.tsx`);
      if (!fs.existsSync(abs) || fs.existsSync(testPath)) stale.push(relPath);
    }
    expect(
      stale,
      `Allowlist entries that no longer violate — remove them:\n${stale.join("\n")}`,
    ).toEqual([]);
  });
});
