import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * @dbp/ui component library conformance ratchet.
 *
 * Bans hardcoded hex colours in component source. All colours must be expressed
 * as design tokens (`var(--color-*)`). The `var(--token, #hex)` fallback form is
 * equally banned — it silently defeats theming because the browser resolves the
 * fallback when the token is missing, so a solution that forgets to declare the
 * token renders the hardcoded hex instead of its brand colour.
 *
 * Known current violations are allowlisted with a reason. Each entry is debt to
 * burn down — never add one without a reason. The "prune stale allowlist" test
 * ensures entries are removed once the file is clean.
 *
 * Mirrors the pattern in feature-conformance.test.ts and page-frame-contract.test.ts.
 */

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = path.resolve(path.dirname(__filename), "../../../../..");
const UI_COMPONENTS_DIR = path.join(REPO_ROOT, "packages/shared/ui/src/components");

function rel(abs: string): string {
  return path.relative(REPO_ROOT, abs).replace(/\\/g, "/");
}

function listComponentTsx(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === "node_modules") continue;
      out.push(...listComponentTsx(abs));
    } else if (e.name.endsWith(".tsx")) {
      // Exclude stories, tests, and barrel index files
      if (e.name.endsWith(".stories.tsx")) continue;
      if (e.name.endsWith(".test.tsx")) continue;
      if (e.name === "index.tsx") continue;
      out.push(abs);
    }
  }
  return out;
}

// ── Allowlist (path relative to repo root → reason). Burn these down. ──────────
//
// Each entry is tracked design-token debt. Migrate the component to var(--color-*)
// tokens, verify theming still works, then remove the entry here.

/**
 * @dbp/ui component files allowed to contain a hardcoded hex colour.
 * Entries are removed once the component is migrated to tokens.
 */
const HEX_ALLOW: Record<string, string> = {
  // All five prior entries cleaned — allowlist is now empty.
};

// ── Regex ──────────────────────────────────────────────────────────────────────

/**
 * Matches:
 * 1. Bare hex: `#abc` / `#aabbcc` / `#aabbccdd`
 * 2. Token-with-hex-fallback: `var(--some-token, #aabbcc)`
 *
 * The second form is called out separately in failure messages because it is
 * the more insidious case — a green `next build` won't catch it.
 */
const HEX_RE = /#[0-9a-fA-F]{3,8}\b|var\(\s*--[^,)]+,\s*#[0-9a-fA-F]{3,8}/;

// ── File collection ────────────────────────────────────────────────────────────

const componentFiles = listComponentTsx(UI_COMPONENTS_DIR);

// ── Tests ──────────────────────────────────────────────────────────────────────

describe("@dbp/ui component library conformance ratchet", () => {
  it("found @dbp/ui component files to scan", () => {
    expect(componentFiles.length, "Expected to find at least 20 component files").toBeGreaterThan(20);
  });

  it("no @dbp/ui component hardcodes a hex colour — use var(--color-*) tokens only", () => {
    const bad: string[] = [];
    for (const abs of componentFiles) {
      const r = rel(abs);
      if (HEX_ALLOW[r]) continue;
      const src = fs.readFileSync(abs, "utf8");
      if (HEX_RE.test(src)) {
        bad.push(r);
      }
    }
    expect(
      bad,
      [
        "Hardcoded hex colour in @dbp/ui component source.",
        "Use var(--color-*) design tokens. var(--token,#hex) fallbacks are also banned —",
        "they silently defeat theming when the token is undeclared.",
        "Offenders:",
        ...bad.map((f) => `  ${f}`),
      ].join("\n"),
    ).toEqual([]);
  });

  it("allowlist entries still exist and still contain a hex (prune stale allowlist)", () => {
    for (const [r, reason] of Object.entries(HEX_ALLOW)) {
      const abs = path.join(REPO_ROOT, r);
      expect(fs.existsSync(abs), `allowlisted file no longer exists — remove it from HEX_ALLOW: ${r} — ${reason}`).toBe(true);
      const src = fs.readFileSync(abs, "utf8");
      expect(
        HEX_RE.test(src),
        `allowlisted file no longer contains a hex — remove it from HEX_ALLOW: ${r} — ${reason}`,
      ).toBe(true);
    }
  });
});
