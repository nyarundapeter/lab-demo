import { describe, it, expect } from "vitest";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { ManifestNavSection } from "@dbp/contracts/solution-manifest";
// @ts-expect-error — scripts/nav-validation.mjs is plain ESM JS, no type declarations.
import { validateNavSectionIds, validateSidebarAreas, standardSectionIds, RETIRED_SECTION_IDS } from "../../../../../scripts/nav-validation.mjs";

const REPO_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../../../..");
const MENU_JSON = path.join(REPO_ROOT, "scripts/standard-menu.json");

const STANDARD = [
  "orientation",
  "marketplace",
  "workspace",
  "service-operations",
  "operational-intelligence",
  "platform-management",
];

/** Minimal manifest shaped like the real thing — only the fields the validator reads. */
function manifest({
  sections = [],
  customNavSections = undefined,
}: { sections?: ManifestNavSection[]; customNavSections?: string[] } = {}) {
  return {
    solution: "TST.01",
    customNavSections,
    modules: [{ id: "TST.01.M01", nav: { sections } }],
  };
}

describe("standardSectionIds", () => {
  it("derives exactly the six Feature-Area ids from standard-menu.json", () => {
    // Guards the anti-drift claim: the validator reads the same file the menu is
    // built from, so this failing means the menu changed and the nav contract
    // (nav-merge.ts, the builder guide, the Storybook page) needs updating too.
    expect(standardSectionIds(MENU_JSON)).toEqual(STANDARD);
  });
});

describe("validateNavSectionIds", () => {
  it("accepts every standard Feature-Area id", () => {
    const m = manifest({ sections: STANDARD.map((id) => ({ id, label: id.toUpperCase(), items: [] })) });
    expect(() => validateNavSectionIds(m, { standardIds: STANDARD })).not.toThrow();
  });

  it("accepts a module with no nav at all", () => {
    expect(() =>
      validateNavSectionIds({ modules: [{ id: "TST.01.M01" }] }, { standardIds: STANDARD }),
    ).not.toThrow();
  });

  it("accepts a custom id once declared in customNavSections", () => {
    const m = manifest({
      sections: [{ id: "finance-ops", label: "FINANCE OPS", items: [] }],
      customNavSections: ["finance-ops"],
    });
    expect(() => validateNavSectionIds(m, { standardIds: STANDARD })).not.toThrow();
  });

  it("throws on a custom id that was NOT declared, naming the id and the fix", () => {
    const m = manifest({ sections: [{ id: "finance-ops", label: "FINANCE OPS", items: [] }] });
    expect(() => validateNavSectionIds(m, { standardIds: STANDARD })).toThrow(/finance-ops/);
    expect(() => validateNavSectionIds(m, { standardIds: STANDARD })).toThrow(/customNavSections/);
  });

  it("names the offending module so a multi-module manifest is diagnosable", () => {
    const m = {
      modules: [
        { id: "TST.01.M01", nav: { sections: [{ id: "workspace", label: "W", items: [] }] } },
        { id: "TST.01.M02", nav: { sections: [{ id: "bogus", label: "B", items: [] }] } },
      ],
    };
    expect(() => validateNavSectionIds(m, { standardIds: STANDARD })).toThrow(/TST\.01\.M02/);
  });

  it.each(RETIRED_SECTION_IDS as string[])("rejects retired id %s even when declared", (retired: string) => {
    const m = manifest({
      sections: [{ id: retired, label: "X", items: [] }],
      customNavSections: [retired],
    });
    expect(() => validateNavSectionIds(m, { standardIds: STANDARD })).toThrow(/retired/i);
  });

  it("agrees with the runtime validator: three custom top-level workspaces are legal once declared", () => {
    // The driving use case — three named workspaces as TOP-LEVEL sections.
    const ids = ["workspace-delivery", "workspace-finance", "workspace-clients"];
    const m = manifest({
      sections: ids.map((id) => ({ id, label: id.toUpperCase(), items: [] })),
      customNavSections: ids,
    });
    expect(() => validateNavSectionIds(m, { standardIds: STANDARD })).not.toThrow();
  });
});

describe("validateSidebarAreas", () => {
  it("accepts a subset of the standard ids, in any order", () => {
    expect(() => validateSidebarAreas(["platform-management", "orientation"], STANDARD)).not.toThrow();
  });

  it("accepts absent / empty sidebar_areas", () => {
    expect(() => validateSidebarAreas(undefined, STANDARD)).not.toThrow();
    expect(() => validateSidebarAreas([], STANDARD)).not.toThrow();
  });

  it("throws on an unknown id instead of silently dropping it", () => {
    // The regression this guard exists for: `.filter(Boolean)` used to swallow it.
    expect(() => validateSidebarAreas(["orientation", "typo-area"], STANDARD)).toThrow(/typo-area/);
  });

  it("gives a declared custom id its own message explaining where it belongs", () => {
    expect(() => validateSidebarAreas(["my-area"], STANDARD, ["my-area"])).toThrow(/nav\.sections/);
  });
});
