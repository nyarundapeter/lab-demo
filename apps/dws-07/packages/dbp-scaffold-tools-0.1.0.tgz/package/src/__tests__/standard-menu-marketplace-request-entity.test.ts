import { describe, it, expect } from "vitest";
// @ts-expect-error — plain .mjs script, no types
import { buildModules, buildNavSections } from "../../../../../scripts/standard-menu-scaffold.mjs";

/**
 * Marketplace spine Phase A — My Requests + Service Requests must bind the
 * marketplace request entity when it is registered, not the solution's primary
 * lifecycle entity (often `capability` / unrelated domain types).
 */

const navSections = buildNavSections();

function manifestWithEntities(entities: Array<Record<string, unknown>>) {
  return {
    platform: "TST",
    solution: "TST.01",
    name: "Marketplace request entity wiring",
    consumes_platform_services: ["PS.DATA"],
    modules: [],
    entities,
  };
}

const CAPABILITY = {
  type: "capability",
  lifecycle: { states: ["active", "draft"], transitions: [] },
  fields: [
    { name: "name", type: "string" },
    { name: "status", type: "enum", enum: ["active", "draft"] },
  ],
};

const SERVICE_OFFERING_REQUEST = {
  type: "service-offering-request",
  fields: [
    { name: "description", type: "string", required: true },
    { name: "urgency", type: "enum", enum: ["low", "medium", "high"], required: true },
    { name: "serviceId", type: "string", required: true },
    { name: "justification", type: "string", required: false },
  ],
};

describe("standard-menu marketplace request queue entity wiring", () => {
  it("binds /transactions/requests and /manage-services/requests to service-offering-request when registered", () => {
    const mods = buildModules(
      manifestWithEntities([CAPABILITY, SERVICE_OFFERING_REQUEST]),
      navSections,
    ) as Array<{
      route: string;
      features: Array<{ config?: { entityType?: string; columns?: Array<{ field: string }> } }>;
    }>;

    const myRequests = mods.find((m) => m.route === "/transactions/requests");
    const serviceRequests = mods.find((m) => m.route === "/manage-services/requests");

    expect(myRequests, "My Requests module missing").toBeTruthy();
    expect(serviceRequests, "Service Requests module missing").toBeTruthy();
    expect(myRequests!.features[0]?.config?.entityType).toBe("service-offering-request");
    expect(serviceRequests!.features[0]?.config?.entityType).toBe("service-offering-request");

    const myCols = (myRequests!.features[0]?.config?.columns ?? []) as Array<{ field: string }>;
    const serviceCols = (serviceRequests!.features[0]?.config?.columns ?? []) as Array<{ field: string }>;
    for (const required of ["description", "urgency", "serviceId"]) {
      expect(myCols.map((c) => c.field), `My Requests missing ${required}`).toContain(required);
      expect(serviceCols.map((c) => c.field), `Service Requests missing ${required}`).toContain(required);
    }
  });

  it("does not retarget unrelated standard-menu routes away from the primary lifecycle entity", () => {
    const mods = buildModules(
      manifestWithEntities([CAPABILITY, SERVICE_OFFERING_REQUEST]),
      navSections,
    ) as Array<{ route: string; features: Array<{ config?: { entityType?: string } }> }>;

    const cases = mods.find((m) => m.route === "/manage-work/cases");
    expect(cases, "cases module missing").toBeTruthy();
    expect(cases!.features[0]?.config?.entityType).toBe("capability");
  });

  it("falls back to primary entity when service-offering-request is not registered", () => {
    const mods = buildModules(
      manifestWithEntities([CAPABILITY]),
      navSections,
    ) as Array<{ route: string; features: Array<{ config?: { entityType?: string } }> }>;

    const myRequests = mods.find((m) => m.route === "/transactions/requests");
    expect(myRequests?.features[0]?.config?.entityType).toBe("capability");
  });
});
