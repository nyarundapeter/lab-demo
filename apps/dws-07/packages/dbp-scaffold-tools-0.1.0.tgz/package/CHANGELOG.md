# Changelog

All notable changes to this package are documented here.

## [0.1.0] - 2026-07-10
Initial documented baseline.
