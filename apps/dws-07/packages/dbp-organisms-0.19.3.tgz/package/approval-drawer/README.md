# @dbp/organisms/approval-drawer

**registryId:** `APP.F54`

Right-side approval decision drawer — current step, key evidence, previous decisions and the
approve/reject action panel against a single PS.WORKFLOW instance. Composes `approval-surface`'s
`ActionPanel`/`useApprovalWorkflow` plus the new `EvidencePanel` molecule on the same Sheet shell
primitives this session's other drawer organisms use. See `FEATURE.md` for the reuse rationale.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ApprovalDrawerConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — no caller mounts this drawer yet (same "not yet wired" state as `data-mapping`
at build time).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/approval-drawer` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
