import * as React from "react";
import { Scale, FileText, Link2, Database } from "lucide-react";
import {
  Alert,
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  EvidencePanel,
  Skeleton,
  type EvidenceItem,
} from "@dbp/ui";
import { ActionPanel, StepHistory, useApprovalWorkflow, type ApprovalSurfaceConfig } from "@dbp/organisms/approval-surface";
import { WorkflowServiceError } from "@dbp/ps-workflow/client";
import { ApprovalDrawerConfig, type ApprovalDrawerConfigInput, type ApprovalDrawerProps } from "./types.js";

const EVIDENCE_ICON: Record<ApprovalDrawerConfig["evidence"][number]["kind"], EvidenceItem["icon"]> = {
  document: FileText,
  record: Link2,
  data: Database,
};

/**
 * APP.F54 — Approval Drawer
 *
 * Composes three existing pieces rather than a ground-up organism
 * (wave3-family3-tier-audit.md row 17): the Sheet shell this session's other
 * drawer organisms use (rule-builder's `RuleTestDrawer`), approval-surface's
 * own `ActionPanel` pinned as a footer, and the new `EvidencePanel` molecule
 * for the "key evidence" section. Reference:
 * docs/03-features/specs/claude-design-briefs/design-run-pack-2026-07-12/
 * _outputs/workflow-system/wf-approval.jsx `ApprovalDrawer`.
 *
 * `record-drawer`'s own Sheet-based tabbed shell is a generic entity/config
 * renderer (RecordDrawerConfig) — its "workflow" tab already binds a
 * different, more general workflow-status view (workflow-binding's
 * `RecordWorkflowActions`), so this drawer builds its own narrower
 * approval-decision shell from the same @dbp/ui Sheet primitives rather than
 * bending record-drawer's generic config schema around one specific flow.
 */
export default function ApprovalDrawer(rawConfig: ApprovalDrawerConfigInput & Pick<ApprovalDrawerProps, "open" | "onOpenChange">) {
  const { open, onOpenChange, ...configInput } = rawConfig;
  const parsed = ApprovalDrawerConfig.safeParse(configInput);

  // Config error renders bare (no Sheet) — same choice as record-drawer's
  // own config-error path: an invalid config isn't a valid dialog to open,
  // and skipping the Sheet avoids a DialogTitle-less Dialog a11y warning.
  if (!parsed.success) {
    return (
      <Alert tone="danger" title="ApprovalDrawer configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parsed.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" size="standard" className="flex flex-col">
        <SheetHeader>
          <div className="flex items-center gap-2">
            <Scale size={15} className="text-[var(--color-active)]" aria-hidden="true" />
            <SheetTitle data-testid="approval-drawer-title">{parsed.data.title}</SheetTitle>
          </div>
        </SheetHeader>
        <ApprovalDrawerBody config={parsed.data} />
      </SheetContent>
    </Sheet>
  );
}

const DEMO_SESSION = btoa(
  JSON.stringify({
    userId: "demo-approver",
    roles: ["finance-approver", "platform-admin", "user"],
    tenantId: "demo",
  }),
);

function ApprovalDrawerBody({ config }: { config: ApprovalDrawerConfig }) {
  const { instance, isLoading, error, isAdvancing, isRejecting, advance, reject } =
    useApprovalWorkflow(config.workflowId);
  const [serviceError, setServiceError] = React.useState<string | null>(null);

  async function handleApprove(comment: string) {
    setServiceError(null);
    try {
      await advance({ comment: comment || undefined }, DEMO_SESSION);
    } catch (err) {
      setServiceError(
        err instanceof WorkflowServiceError && err.status === 403
          ? "The workflow engine denied the transition. You may not have permission to approve this step."
          : err instanceof WorkflowServiceError
            ? err.message
            : "Failed to approve. Please try again.",
      );
    }
  }

  async function handleReject(comment: string) {
    setServiceError(null);
    try {
      await reject({ comment: comment || undefined }, DEMO_SESSION);
    } catch (err) {
      setServiceError(
        err instanceof WorkflowServiceError && err.status === 403
          ? "The workflow engine denied the transition. You may not have permission to reject this step."
          : err instanceof WorkflowServiceError
            ? err.message
            : "Failed to reject. Please try again.",
      );
    }
  }

  if (isLoading) {
    return (
      <div className="flex flex-1 flex-col gap-3" data-testid="approval-drawer-loading" aria-busy="true">
        <Skeleton className="h-4 w-32" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }

  if (error && instance === null) {
    return (
      <Alert tone="danger" title="Failed to load workflow instance" data-testid="approval-drawer-error">
        {error instanceof WorkflowServiceError ? error.message : "Unexpected error loading the approval."}
      </Alert>
    );
  }

  if (instance === null) return null;

  const isTerminal = instance.status === "completed" || instance.status === "rejected";
  const evidenceItems: EvidenceItem[] = config.evidence.map((item) => ({
    id: item.id,
    name: item.name,
    meta: item.meta,
    icon: EVIDENCE_ICON[item.kind],
    verified: item.verified,
  }));

  // ActionPanel's own inline evidence list is intentionally left empty here
  // (evidence !== undefined) — this drawer renders the richer EvidencePanel
  // above instead, so the two don't duplicate the same list.
  const actionPanelConfig: ApprovalSurfaceConfig = {
    workflowId: config.workflowId,
    approveAction: config.approveAction,
    ...(config.resource !== undefined && { resource: config.resource }),
    ...(config.approveLabel !== undefined && { approveLabel: config.approveLabel }),
    ...(config.rejectLabel !== undefined && { rejectLabel: config.rejectLabel }),
    requireComment: config.requireComment,
    showHistory: false,
    allowDelegate: config.allowDelegate,
    allowRequestInfo: config.allowRequestInfo,
  };

  return (
    <>
      <div className="flex flex-1 flex-col gap-4 overflow-y-auto py-1" data-testid="approval-drawer-body">
        <div className="flex items-center justify-between gap-3 text-sm">
          <span className="font-medium text-[var(--color-text-primary)]" data-testid="current-step">
            {instance.currentStep ?? "—"}
          </span>
          <span className="text-xs text-[var(--color-text-muted)]">{instance.status}</span>
        </div>

        {evidenceItems.length > 0 && (
          <div className="flex flex-col gap-2">
            <h3 className="dq-overline">Key evidence</h3>
            <EvidencePanel items={evidenceItems} />
          </div>
        )}

        <div className="flex flex-col gap-2">
          <h3 className="dq-overline">Previous decisions</h3>
          <StepHistory steps={instance.steps} />
        </div>
      </div>

      <div className="mt-auto border-t border-[var(--color-border)] pt-4">
        {isTerminal ? (
          <div
            className="rounded border border-[var(--color-border)] bg-[var(--color-bg)] px-4 py-3 text-sm text-[var(--color-text)] opacity-70"
            data-testid="terminal-outcome"
          >
            This instance is <strong>{instance.status}</strong>. No further actions are available.
          </div>
        ) : (
          <ActionPanel
            config={actionPanelConfig}
            isAdvancing={isAdvancing}
            isRejecting={isRejecting}
            serviceError={serviceError}
            onApprove={handleApprove}
            onReject={handleReject}
          />
        )}
      </div>
    </>
  );
}
