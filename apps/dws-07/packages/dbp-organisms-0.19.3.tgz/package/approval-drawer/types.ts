import { z } from "zod";

/**
 * ApprovalDrawerConfig — the single typed contract for APP.F54.
 *
 * Data contract only (no function fields — Zod schemas are data-only, same
 * rule as approval-surface/types.ts). Evidence items carry a `kind` string
 * rather than a lucide icon component; index.tsx maps kind → icon.
 */
const ApprovalDrawerEvidenceItemSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  /** e.g. "PDF · 2.4 MB" or "Linked record · PO-2207". */
  meta: z.string().min(1),
  kind: z.enum(["document", "record", "data"]).default("document"),
  verified: z.boolean(),
});
export type ApprovalDrawerEvidenceItem = z.infer<typeof ApprovalDrawerEvidenceItemSchema>;

export const ApprovalDrawerConfig = z
  .object({
    /** The PS.WORKFLOW instance ID to load and act on — same field as approval-surface. */
    workflowId: z.string().min(1),
    /** Drawer header title, e.g. "Approve · PO-2207". */
    title: z.string().min(1),
    approveAction: z.string().min(1),
    resource: z.string().optional(),
    approveLabel: z.string().optional(),
    rejectLabel: z.string().optional(),
    requireComment: z.enum(["never", "on-reject", "always"]).default("on-reject"),
    allowDelegate: z.boolean().default(true),
    allowRequestInfo: z.boolean().default(true),
    evidence: z.array(ApprovalDrawerEvidenceItemSchema).default([]),
  })
  .strict();

export type ApprovalDrawerConfig = z.infer<typeof ApprovalDrawerConfig>;
export type ApprovalDrawerConfigInput = z.input<typeof ApprovalDrawerConfig>;

/** Runtime props: the drawer is mounted with open state by its host (same shape as record-drawer's props). */
export type ApprovalDrawerProps = {
  config: ApprovalDrawerConfigInput;
  open: boolean;
  onOpenChange: (open: boolean) => void;
};
