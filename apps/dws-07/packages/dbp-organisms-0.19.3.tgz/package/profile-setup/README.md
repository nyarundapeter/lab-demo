# @dbp/organisms/profile-setup

**registryId:** `APP.F69` (placeholder — assigned during central registration)

First-login profile setup — a thin `WizardDefinition` composition over `@dbp/organisms/multi-step-form`.
See `FEATURE.md`.

**Tier:** organism/template

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ProfileSetupConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — no `FEATURE_COMPONENT` route in `scripts/scaffold-solution.mjs` targets this
organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/profile-setup` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
