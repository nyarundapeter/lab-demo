import * as React from "react";
import { Alert } from "@dbp/ui";
import MultiStepForm from "@dbp/organisms/multi-step-form";
import type { WizardDefinition } from "@dbp/organisms/multi-step-form/types";
import { ProfileSetupConfig, type ProfileSetupConfigInput } from "./types.js";

/**
 * ProfileSetup — first-login profile setup (name/title, then timezone +
 * notification defaults, then a confirmation nudging toward 2FA). Port of
 * `identity-firstrun.jsx`'s `ProfileSetup`. Reuse win per the Wave 3 build
 * plan: rather than a bespoke stepper, this builds a `WizardDefinition` and
 * renders the existing `@dbp/organisms/multi-step-form` organism — the
 * wizard's own auto-generated Review + submitted-confirmation step stands
 * in for the reference's "All set" step 3.
 *
 * `entityType: "profile-setup"` is illustrative — no dedicated PS.DATA
 * entity type or profile-update platform service exists for this yet, same
 * open-architecture posture as `feature-flags-admin`'s PS.FLAGS note.
 */
export default function ProfileSetup(config: ProfileSetupConfigInput) {
  const parsed = ProfileSetupConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="ProfileSetup — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <ProfileSetupInner config={parsed.data} />;
}

function ProfileSetupInner({ config }: { config: ProfileSetupConfig }) {
  const definition = React.useMemo<WizardDefinition>(() => buildWizardDefinition(config), [config]);
  return <MultiStepForm wizardDefinition={definition} orientation="horizontal" />;
}

function buildWizardDefinition(config: ProfileSetupConfig): WizardDefinition {
  return {
    id: "profile-setup",
    entityType: "profile-setup",
    version: 1,
    status: "published",
    submitLabel: "Finish setup",
    reviewStepLabel: "Review",
    successMessage:
      "Your profile is ready. We recommend turning on two-factor authentication next to keep your account secure.",
    requireTermsAcceptance: false,
    labels: {},
    crossFieldRules: [],
    createdAt: "2026-07-12T00:00:00.000Z",
    updatedAt: "2026-07-12T00:00:00.000Z",
    steps: [
      {
        id: "profile",
        label: "Your profile",
        description: `Let's set up your profile. This is how teammates at ${config.orgName} will see you.`,
        optional: false,
        sections: [
          {
            id: "profile-section",
            title: "Profile",
            fields: [
              { id: "fullName", label: "Full name", type: "text", required: true, span: "full" },
              { id: "jobTitle", label: "Job title", type: "text", required: false, span: "full" },
            ],
          },
        ],
      },
      {
        id: "preferences",
        label: "Preferences",
        description: "Set your timezone and how you'd like to be notified. You can change these anytime.",
        optional: false,
        sections: [
          {
            id: "preferences-section",
            title: "Preferences",
            fields: [
              {
                id: "timezone",
                label: "Timezone",
                type: "select",
                required: true,
                span: "full",
                helperText: "Used for reminders, digests and activity times.",
                options: config.timezones.map((tz) => ({ value: tz, label: tz })),
              },
              {
                id: "emailNotifications",
                label: "Email notifications",
                type: "checkbox-group",
                required: false,
                span: "full",
                options: [
                  { value: "mentions", label: "Mentions & replies" },
                  { value: "assignments", label: "Assignments" },
                  { value: "digest", label: "Daily digest" },
                  { value: "product", label: "Product updates" },
                ],
              },
            ],
          },
        ],
      },
    ],
  };
}

export type { ProfileSetupConfig, ProfileSetupConfigInput } from "./types.js";
