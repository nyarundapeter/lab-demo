import { z } from "zod";

export const ProfileSetupConfig = z.object({
  orgName: z.string().min(1),
  /** Timezone select options for the preferences step. */
  timezones: z.array(z.string()).min(1),
});
export type ProfileSetupConfig = z.infer<typeof ProfileSetupConfig>;
export type ProfileSetupConfigInput = z.input<typeof ProfileSetupConfig>;
