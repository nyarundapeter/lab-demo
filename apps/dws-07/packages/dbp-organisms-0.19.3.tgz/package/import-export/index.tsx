import React from "react";
import { CalendarClock, Download, X } from "lucide-react";
import { Alert, Badge, Button, FormField, Tabs, TabsList, TabsTrigger, TabsContent } from "@dbp/ui";
import { ImportWizard } from "./components/import-wizard.js";
import { ImportExportConfig, type ImportExportConfigInput, EXPORT_FORMAT_OPTIONS } from "./types.js";

const RESULT_BADGE: Record<"success" | "partial" | "failed", { tone: "success" | "warning" | "danger"; label: string }> = {
  success: { tone: "success", label: "Success" },
  partial: { tone: "warning", label: "Partial" },
  failed: { tone: "danger", label: "Failed" },
};

interface Callbacks {
  onRunImport?: () => void;
  onRequestExport?: () => void;
  onScheduleExport?: () => void;
  /** Demo-only: preset the active tab (Storybook doesn't have interaction-tooling to click it). */
  initialMode?: "import" | "export" | "history";
}

/**
 * Import & export workbench: guided import wizard (upload → map → validate →
 * run), an export request builder, and a job history table. Port of
 * admin-specimens3.jsx's `ImportExportPage`. Owns local `mode`
 * (import/export/history) and the import wizard's `step` (via
 * `ImportWizard`). UI-only, prop-driven — no `PS.IMPORT_EXPORT`-class
 * platform service exists (same gap as `integration-catalogue`/`data-mapping`).
 */
export default function ImportExport(config: ImportExportConfigInput & Callbacks) {
  const { onRunImport, onRequestExport, onScheduleExport, initialMode, ...rest } = config;
  const parsed = ImportExportConfig.safeParse(rest);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="ImportExport — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const c = parsed.data;

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="text-lg font-semibold">Import &amp; export</h2>
        <p className="mt-1 text-xs text-text-muted">
          Bring data in or take it out — with mapping, validation, duplicate handling, and history.
        </p>
      </div>

      <Tabs defaultValue={initialMode ?? "import"}>
        <TabsList>
          <TabsTrigger value="import">Import</TabsTrigger>
          <TabsTrigger value="export">Export</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="import" className="mt-4">
          <ImportWizard
            jobName={c.importJobName}
            fieldMappings={c.fieldMappings}
            duplicateHandling={c.duplicateHandling}
            validation={c.validation}
            onRunImport={onRunImport}
          />
        </TabsContent>

        <TabsContent value="export" className="mt-4">
          <div className="flex flex-col gap-4">
            <FormField label="Dataset">
              <select className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm">
                {c.exportDatasetOptions.map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </select>
            </FormField>

            <FormField label="Fields">
              <div className="flex flex-wrap items-center gap-2">
                {c.exportFields.map((field) => (
                  <Badge key={field} tone="default" className="gap-1">
                    {field}
                    <X size={11} aria-hidden="true" />
                  </Badge>
                ))}
                <Button type="button" variant="outline" size="sm">
                  + Add
                </Button>
              </div>
            </FormField>

            <FormField label="Filters">
              <input
                defaultValue={c.exportFilters.map((f) => `${f.field} = ${f.value}`).join(", ")}
                className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm"
              />
            </FormField>

            <FormField label="Format">
              <select
                defaultValue={c.exportFormat}
                className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm"
              >
                {EXPORT_FORMAT_OPTIONS.map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </select>
            </FormField>

            {c.exportSensitiveDataWarning && (
              <Alert tone="warning" title="Contains sensitive data">
                {c.exportSensitiveDataWarning}
              </Alert>
            )}

            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onScheduleExport}>
                <CalendarClock size={14} />
                Schedule
              </Button>
              <Button type="button" onClick={onRequestExport}>
                <Download size={14} />
                Request export
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <div className="overflow-x-auto rounded-card border border-border-default bg-[var(--color-surface-content)]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border-default text-left text-xs text-text-muted">
                  <th className="px-3.5 py-2.5 font-medium">Job</th>
                  <th className="px-3.5 py-2.5 font-medium">Type</th>
                  <th className="px-3.5 py-2.5 font-medium">Result</th>
                  <th className="px-3.5 py-2.5 font-medium">When</th>
                  <th className="w-24" />
                </tr>
              </thead>
              <tbody>
                {c.history.map((job, i) => (
                  <tr key={`${job.name}-${i}`} className={i < c.history.length - 1 ? "border-b border-border-default" : undefined}>
                    <td className="px-3.5 py-2.5 font-medium">{job.name}</td>
                    <td className="px-3.5 py-2.5">
                      <Badge tone="gray" size="sm">
                        {job.type === "import" ? "Import" : "Export"}
                      </Badge>
                    </td>
                    <td className="px-3.5 py-2.5">
                      <Badge tone={RESULT_BADGE[job.result].tone} size="sm">
                        {RESULT_BADGE[job.result].label}
                      </Badge>
                    </td>
                    <td className="px-3.5 py-2.5 text-xs text-text-muted">{job.when}</td>
                    <td className="px-3.5 py-2.5">
                      <Button type="button" variant="ghost" size="sm">
                        <Download size={13} />
                        {job.result === "failed" ? "Errors" : "File"}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
