import { z } from "zod";

const FieldMappingRow = z.object({
  csvColumn: z.string().min(1),
  /** Target field path, or "— skip —" to exclude the column from import. */
  targetField: z.string().min(1),
  sample: z.string().min(1),
});

const ValidationSummary = z.object({
  totalRows: z.number(),
  willCreate: z.number(),
  willUpdate: z.number(),
  errorCount: z.number(),
  warningCount: z.number(),
  /** Freeform detail shown in the validation Alert body, e.g. "Row 42: invalid email." */
  message: z.string().min(1),
});

const ExportFilter = z.object({
  field: z.string().min(1),
  value: z.string().min(1),
});

const HistoryJob = z.object({
  name: z.string().min(1),
  type: z.enum(["import", "export"]),
  result: z.enum(["success", "partial", "failed"]),
  when: z.string().min(1),
});

export const DUPLICATE_HANDLING_OPTIONS = [
  "Update existing (match on email)",
  "Skip duplicates",
  "Create new anyway",
] as const;

export const EXPORT_FORMAT_OPTIONS = ["CSV", "Excel", "JSON"] as const;

export const ImportExportConfig = z.object({
  /** Descriptive name of the in-progress import job, e.g. "bulk user import". */
  importJobName: z.string().min(1),
  fieldMappings: z.array(FieldMappingRow).default([]),
  duplicateHandling: z.enum(DUPLICATE_HANDLING_OPTIONS).default(DUPLICATE_HANDLING_OPTIONS[0]),
  validation: ValidationSummary.optional(),
  exportDatasetOptions: z.array(z.string().min(1)).min(1).default(["Cases", "Service Requests", "Accounts", "Users"]),
  exportFields: z.array(z.string().min(1)).default([]),
  exportFilters: z.array(ExportFilter).default([]),
  exportFormat: z.enum(EXPORT_FORMAT_OPTIONS).default("CSV"),
  /** Set when the selected export dataset/fields include sensitive data (e.g. reporter emails). */
  exportSensitiveDataWarning: z.string().optional(),
  history: z.array(HistoryJob).default([]),
});

export type ImportExportConfig = z.infer<typeof ImportExportConfig>;
export type ImportExportConfigInput = z.input<typeof ImportExportConfig>;
export type FieldMappingRow = z.infer<typeof FieldMappingRow>;
export type ValidationSummary = z.infer<typeof ValidationSummary>;
export type HistoryJob = z.infer<typeof HistoryJob>;
