# @dbp/organisms/import-export

**registryId:** `APP.F50`

Import & export workbench: guided import wizard, export request builder, and job history
table. Reuses `FileDropzone`, `StatTile`, `Alert`, and `Badge` — see `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ImportExportConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/data/import-export` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/import-export` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
