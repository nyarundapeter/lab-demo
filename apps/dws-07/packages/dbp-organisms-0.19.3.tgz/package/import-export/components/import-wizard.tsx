import React from "react";
import { ChevronLeft, ChevronRight, Play } from "lucide-react";
import { Alert, Button, Card, FileDropzone, FormField, StatTile, StepNav, type StepNavItem } from "@dbp/ui";
import type { FieldMappingRow, ImportExportConfig } from "../types.js";
import { DUPLICATE_HANDLING_OPTIONS } from "../types.js";

const STEP_LABELS = ["Upload", "Type", "Map fields", "Validate", "Preview", "Run"];
const MAP_FIELDS_STEP = 2;

interface Props {
  jobName: string;
  fieldMappings: FieldMappingRow[];
  duplicateHandling: ImportExportConfig["duplicateHandling"];
  validation?: ImportExportConfig["validation"] | undefined;
  onRunImport?: (() => void) | undefined;
}

/**
 * Import-mode step content: Upload / Type / Map fields / Validate / Preview /
 * Run. Port of admin-specimens3.jsx's `ImportExportPage` import steps. Uses
 * `StepNav` (@dbp/ui) for the step rail rather than `multi-step-form` — the
 * same re-confirmed call as `integration-catalogue`'s connector wizard:
 * `multi-step-form` is tied to `form-builder`'s `FormDefinition` field-schema
 * contract, which doesn't fit this wizard's free-form step content (a
 * dropzone, a mapping table, a validation summary).
 */
export function ImportWizard({ jobName, fieldMappings, duplicateHandling, validation, onRunImport }: Props) {
  const [step, setStep] = React.useState(MAP_FIELDS_STEP);

  const steps: StepNavItem[] = STEP_LABELS.map((label, i) => ({
    id: String(i),
    label,
    state: i < step ? "done" : i === step ? "active" : "upcoming",
  }));

  return (
    <div className="flex flex-col gap-4">
      <StepNav
        steps={steps}
        onStepClick={(id) => {
          const target = Number(id);
          if (target <= step) setStep(target);
        }}
      />

      <Card className="min-h-[220px] shadow-none">
        {step < MAP_FIELDS_STEP && (
          <FileDropzone
            promptText="Drop a CSV or Excel file here, or"
            browseLabel="browse"
            helperText="Accepts .csv, .xls, .xlsx · max 50MB"
            accept=".csv,.xls,.xlsx"
          />
        )}

        {step === MAP_FIELDS_STEP && (
          <div className="flex flex-col gap-3">
            <h3 className="text-sm font-semibold">Map columns → fields ({jobName})</h3>
            <div className="overflow-x-auto rounded-card border border-border-default bg-[var(--color-surface-content)]">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border-default text-left text-xs text-text-muted">
                    <th className="px-3.5 py-2.5 font-medium">CSV column</th>
                    <th className="w-10" />
                    <th className="px-3.5 py-2.5 font-medium">Target field</th>
                    <th className="px-3.5 py-2.5 font-medium">Sample</th>
                  </tr>
                </thead>
                <tbody>
                  {fieldMappings.map((row, i) => (
                    <tr key={row.csvColumn} className={i < fieldMappings.length - 1 ? "border-b border-border-default" : undefined}>
                      <td className="px-3.5 py-2.5 font-mono text-xs">{row.csvColumn}</td>
                      <td className="px-1 text-text-muted">
                        <ChevronRight size={13} aria-hidden="true" />
                      </td>
                      <td className="px-3.5 py-2.5">
                        <select
                          defaultValue={row.targetField}
                          className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm"
                        >
                          <option>{row.targetField}</option>
                          <option>— skip —</option>
                        </select>
                      </td>
                      <td className="px-3.5 py-2.5 text-xs text-text-muted">{row.sample}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <FormField label="Duplicate handling">
              <select
                defaultValue={duplicateHandling}
                className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm"
              >
                {DUPLICATE_HANDLING_OPTIONS.map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </select>
            </FormField>
          </div>
        )}

        {step > MAP_FIELDS_STEP && validation && (
          <div className="flex flex-col gap-3">
            <Alert tone="warning" title={`Validation: ${validation.warningCount} warnings, ${validation.errorCount} error`}>
              {validation.message}
            </Alert>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <StatTile label="Total rows" value={validation.totalRows} />
              <StatTile label="Will create" value={validation.willCreate} tone="success" />
              <StatTile label="Will update" value={validation.willUpdate} tone="info" />
              <StatTile label="Errors" value={validation.errorCount} tone="danger" />
            </div>
          </div>
        )}
      </Card>

      <div className="flex gap-2">
        {step > 0 && (
          <Button type="button" variant="outline" onClick={() => setStep(step - 1)}>
            <ChevronLeft size={14} />
            Back
          </Button>
        )}
        <div className="flex-1" />
        {step < STEP_LABELS.length - 1 ? (
          <Button type="button" onClick={() => setStep(step + 1)}>
            Continue
            <ChevronRight size={14} />
          </Button>
        ) : (
          <Button type="button" onClick={onRunImport}>
            <Play size={14} />
            Run import
          </Button>
        )}
      </div>
    </div>
  );
}
