import { z } from "zod";

// Config schema for the @dbp/organisms/tenant-switcher organism. Promoted
// from packages/shared/ui/src/bindings (2026-07-21 Bindings/Admin
// resolution — it owns useMemberships()+useSwitchTenant() fetch/mutation
// state, so it is an organism, not a presentation-layer binding). `onSwitch`
// and `labelFn` are callbacks and are not representable in a Zod schema, so
// TenantSwitcherProps extends the parsed config with them directly.
export const TenantSwitcherConfig = z.object({
  currentTenantId: z.string(),
  solutionName: z.string().optional(),
  collapsed: z.boolean().optional(),
  className: z.string().optional(),
});

export type TenantSwitcherConfig = z.infer<typeof TenantSwitcherConfig>;
