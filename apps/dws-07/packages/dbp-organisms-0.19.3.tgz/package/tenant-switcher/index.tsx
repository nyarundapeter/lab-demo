import * as React from "react";
import { ChevronDown, Check, LogOut } from "lucide-react";
import { useMemberships, useSwitchTenant } from "@dbp/ps-auth/client";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  cn,
  Button,
} from "@dbp/ui";
import type { TenantSwitcherConfig } from "./types.js";

export interface TenantSwitcherProps extends TenantSwitcherConfig {
  /** Called with the new tenant id after a successful switch. */
  onSwitch?: (tenantId: string) => void;
  /** Formats a tenant id into a display label. Defaults to the raw id. */
  labelFn?: (tenantId: string) => string;
}

/** Derives up-to-two-letter initials from a display label for the identity square. */
function squareInitials(label: string): string {
  const parts = label.trim().split(/[\s./]+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return (parts[0]![0]! + parts[1]![0]!).toUpperCase();
}

/**
 * TenantSwitcher — the sidebar identity block AND workspace/tenant switcher,
 * merged into one control (N30 ruling, supersedes T4's top-bar placement).
 *
 * Reference: docs/03-features/specs/claude-design-briefs/design-run-pack-2026-07-12/
 * _outputs/dashboard-system/shell.jsx (TenantSwitcher component, lines ~34-95).
 *
 * Anatomy: icon square + two-line block (primary = active tenant label,
 * subtitle = solution name) + chevron. Clicking opens a popover listing the
 * user's memberships (switch on select) with a sign-out item at the bottom.
 *
 * Single-tenant users (memberships.length <= 1) get the same block rendered
 * as a static, non-interactive `<div>` — no chevron, no popover.
 *
 * Collapsed sidebar: icon square only. Multi-tenant users can still click it
 * to open the popover; single-tenant users see an inert square.
 */
export function TenantSwitcher({
  currentTenantId,
  solutionName,
  onSwitch,
  labelFn = (id) => id,
  collapsed,
  className,
}: TenantSwitcherProps): React.ReactNode {
  const memberships = useMemberships();
  const { mutate, isPending } = useSwitchTenant(onSwitch ? { onSuccess: onSwitch } : {});
  const interactive = memberships.length > 1;
  const currentLabel = labelFn(currentTenantId);

  const rowClass = cn(
    "flex h-[var(--shell-header-h)] w-full shrink-0 items-center gap-2.5 border-b border-[var(--color-border-subtle)] px-3",
    collapsed && "justify-center px-0",
    className,
  );

  const square = (
    <span
      aria-hidden
      className="flex h-6 w-6 shrink-0 items-center justify-center rounded-[6px] bg-primary text-xs font-bold text-white"
    >
      {squareInitials(currentLabel)}
    </span>
  );

  const textBlock = !collapsed && (
    <span className="flex min-w-0 flex-1 flex-col overflow-hidden text-left">
      <span className="truncate text-sm font-bold leading-tight text-primary">{currentLabel}</span>
      {solutionName && (
        <span className="truncate text-xs leading-tight text-[var(--color-text-muted)]">{solutionName}</span>
      )}
    </span>
  );

  if (!interactive) {
    return (
      <div className={rowClass}>
        {square}
        {textBlock}
      </div>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          aria-label="Switch workspace"
          disabled={isPending}
          className={cn(
            rowClass,
            // D3 fix: this unconditional "justify-start" was appended AFTER
            // rowClass's `collapsed && "justify-center px-0"` — since `cn` is
            // tailwind-merge, the later conflicting justify-* utility always
            // won, so the collapsed rail never actually centered for any
            // multi-tenant user (the non-interactive branch below was
            // unaffected). Only apply justify-start when expanded.
            !collapsed && "justify-start",
            "font-normal transition-colors hover:bg-[var(--color-surface)]",
            "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
          )}
        >
          {square}
          {textBlock}
          {!collapsed && (
            <ChevronDown size={14} strokeWidth={1.5} className="shrink-0 opacity-60" aria-hidden="true" />
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64">
        {memberships.map((tenantId) => (
          <DropdownMenuItem
            key={tenantId}
            onSelect={() => {
              if (tenantId !== currentTenantId) mutate(tenantId);
            }}
          >
            <span className="min-w-0 flex-1 truncate">{labelFn(tenantId)}</span>
            {tenantId === currentTenantId && (
              <Check size={14} strokeWidth={1.5} className="ml-2 shrink-0" aria-hidden="true" />
            )}
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <a href="/logout" className="flex w-full items-center gap-2">
            <LogOut size={14} strokeWidth={1.5} aria-hidden="true" />
            <span>Sign out</span>
          </a>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export type { TenantSwitcherConfig } from "./types.js";
