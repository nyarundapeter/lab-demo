# @dbp/organisms/tenant-switcher

**registryId:** `APP.F17`

Sidebar identity block AND workspace/tenant switcher, merged into one control (N30 ruling).

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`TenantSwitcherConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Bespoke import — mounted directly by the solution's chrome composition (e.g. `apps/dbp/app/solution-chrome.tsx`).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/tenant-switcher` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
