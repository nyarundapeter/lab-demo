# @dbp/organisms/form-builder

**registryId:** `APP.F03`

Config-driven record create/edit form (react-hook-form + Zod), with an existing-record edit mode.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |
| `./hooks` | `hooks/index.ts` — `useFormDraft`, `AUTOSAVE_DEBOUNCE_MS` |

## Config schema
`FormBuilderConfig` — Zod schema exported from `types.ts` (source of truth).

## Extending the derived-field op set

`derived` fields (`FormFieldDefSchema.derived`, spec §2.3) compute from a **fixed, closed set**
of named operations — `sum | subtract | multiply | divide | concat | dateDiffDays` — over
named field-id operands. There is no expression string, no `eval`/`new Function`, no
expression-language parser, and this is deliberate, not an oversight (F1, decision-pack Table 4):

- Every derived-field use case named by the forms-maturity mandate (a total, a duration, a
  concatenated code) is expressible as one of the six ops today.
- **If a future need genuinely doesn't fit the six ops, the process is: come back and add a new
  named op to the closed set (`logic/derived.ts`'s switch statement + `DerivedValueOpSchema` in
  `@dbp/contracts/predicate`) — never open arbitrary eval, even sandboxed.** A closed op set is
  trivially reviewable (no parser, no injection surface) and trivially diffable in
  `FormDefinition` version history; a string expression is neither.
- Adding a new op is itself a deliberate escalation, not something a build session decides
  silently under deadline pressure — see spec §7 item 1 and build plan §7 ("Any future op needed
  beyond the closed 6 derived-value ops... is a deliberate ask back to Sharavi").

## Publish-time immutability — client-layer convention, by design

`FormDefinition.version`/`status` (spec §2.1, §2.7) follow the same immutability posture
PS.WORKFLOW already ships for its own definitions (ADR-0009 SP-7): a `published` definition is
never edited in place — an edit creates a new row at `version: n+1`. **This is enforced as a
`form-builder/logic` client-layer convention, not a PS.DATA server hook** (F7, resolved
2026-07-11) — matching PS.DATA's existing "generic CRUD only, no entity-type-specific server
logic anywhere" precedent. A server-side hook here would be the first exception to that
invariant, and is deliberately left as a distinct future decision rather than a side-effect of
this package's build. This is a stated posture, not a gap being silently accepted.

## File uploads — not built (blocked on `ps-storage`)

`type: "file"` exists in the `FormFieldType` schema (spec §2.5) so a `FormDefinition` never needs
a breaking migration once file uploads land, but no functional upload control is built in this
package yet. `FieldSet` renders a disabled placeholder with a "File uploads require ps-storage
(GAP-BRS-1) — not yet available" notice instead. Draft autosave (`useFormDraft`) additionally
refuses (throws) on any `FormDefinition` containing a `file` field, per the F3 split — drafting a
form with a file field needs a stable object reference to round-trip through a partial,
unvalidated draft save, which doesn't exist until `ps-storage` ships. Tracked as build-plan
Session 9 (`docs/09-plans/forms-maturity-build-plan-2026-07-11.md`), not designed or attempted
here.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `object-page-detail` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/form-builder` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
