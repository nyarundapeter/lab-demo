import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEntity } from "@dbp/ps-data/client";
import { Button, Alert, toast } from "@dbp/ui";
import type { EntityData } from "@dbp/ps-data/client";
import { FormBuilderConfig } from "./types.js";
import type { FieldDef, FormDefinition, FormFieldDef, FormSection } from "./types.js";
import { FormSkeleton } from "./components/form-skeleton.js";
import { FieldSet } from "./renderer/field-set.js";
import { compileDynamicSchema } from "./logic/index.js";
import { useFieldSchema } from "./hooks/use-field-schema.js";
import { useFormSubmit } from "./hooks/use-form-submit.js";
import { useFormDefinition } from "./hooks/use-form-definition.js";

type ConfigInput = Omit<FormBuilderConfig, "submitLabel" | "successMessage"> &
  Partial<Pick<FormBuilderConfig, "submitLabel" | "successMessage">>;

/**
 * Third config-input shape (S4) — fetches a `FormDefinition` at runtime via
 * PS.DATA instead of taking a compile-time `fields[]` prop (spec §1.1's
 * named gap). `entityId` present = edit mode; omitted = create mode.
 */
interface FormDefinitionConfigInput {
  formDefinitionId: string;
  entityId?: string;
}

function isFormDefinitionConfigInput(v: unknown): v is FormDefinitionConfigInput {
  return (
    typeof v === "object" &&
    v !== null &&
    "formDefinitionId" in v &&
    typeof (v as FormDefinitionConfigInput).formDefinitionId === "string"
  );
}

/**
 * APP.F03 — Form Builder (Create / Edit)
 *
 * Receives CONFIG, never data. In edit mode, entity data is fetched via PS.DATA.
 * `fields[]` (legacy `FormBuilderConfig`) drives the dynamic Zod schema at
 * render time; `formDefinitionId` (S4) fetches a versioned `FormDefinition`
 * at runtime instead.
 */
export default function FormBuilder(rawConfig: ConfigInput | FormDefinitionConfigInput) {
  if (isFormDefinitionConfigInput(rawConfig)) {
    return <FormDefinitionInner formDefinitionId={rawConfig.formDefinitionId} entityId={rawConfig.entityId} />;
  }

  const parseResult = FormBuilderConfig.safeParse(rawConfig);
  if (!parseResult.success) {
    return (
      <Alert
        tone="danger"
        title="FormBuilder configuration error"
        data-testid="config-error"
      >
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>{e.path.join(".") || "root"}: {e.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }

  const config = parseResult.data;
  return <FormBuilderInner config={config} />;
}

// ─── Public re-exports (types only) ──────────────────────────────────────────
export type { FormBuilderConfig } from "./types.js";

// ─── Inner component (config guaranteed valid here) ───────────────────────────

interface FormBuilderInnerProps {
  config: FormBuilderConfig;
}

function FormBuilderInner({ config }: FormBuilderInnerProps) {
  const fieldSchema = useFieldSchema(config.fields);
  const submitMutation = useFormSubmit(config);

  const {
    register,
    control,
    handleSubmit,
    watch,
    reset,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<Record<string, unknown>>({
    resolver: zodResolver(fieldSchema),
    defaultValues: buildDefaultValues(config.fields),
  });

  const values = watch();
  const section: FormSection = React.useMemo(
    () => ({ id: "default", title: "", fields: config.fields.map(legacyToFormFieldDef) }),
    [config.fields],
  );

  // Edit-mode prefetch
  const {
    data: entityData,
    isLoading: entityLoading,
    error: entityError,
  } = useEntity<EntityData>(
    config.entityType,
    config.entityId ?? "",
  );

  // Populate default values once entity data arrives in edit mode
  const populated = React.useRef(false);
  React.useEffect(() => {
    if (config.mode === "edit" && entityData && !populated.current) {
      populated.current = true;
      reset(entityData as Record<string, unknown>);
    }
  }, [config.mode, entityData, reset]);

  const [successVisible, setSuccessVisible] = React.useState(false);
  const [serverError, setServerError] = React.useState<string | null>(null);

  const isPending = isSubmitting || submitMutation.isPending;

  async function onValid(data: Record<string, unknown>) {
    setServerError(null);
    setSuccessVisible(false);

    try {
      await submitMutation.mutateAsync(data as EntityData);
      setSuccessVisible(true);
      toast({
        tone: "success",
        title: config.successMessage ?? "Saved successfully.",
      });
      if (config.mode === "create") {
        reset(buildDefaultValues(config.fields));
        populated.current = false;
      }
    } catch (err: unknown) {
      // Surface server 400 validation issues inline per field
      if (isServerValidationError(err)) {
        for (const issue of err.issues) {
          setError(issue.path as string, { message: issue.message });
        }
      } else {
        setServerError(err instanceof Error ? err.message : "An unexpected error occurred.");
      }
    }
  }

  // Edit-mode loading state
  if (config.mode === "edit" && entityLoading) {
    return <FormSkeleton fieldCount={config.fields.length} />;
  }

  // Edit-mode not-found / fetch error
  if (config.mode === "edit" && entityError) {
    return (
      <Alert tone="danger" title="Could not load entity" data-testid="entity-error">
        {entityError.message}
      </Alert>
    );
  }

  return (
    <form
      onSubmit={handleSubmit(onValid)}
      noValidate
      className="flex flex-col gap-4"
      data-testid="form-builder"
    >
      {/* Server-level error banner */}
      {serverError && (
        <Alert tone="danger" data-testid="server-error">
          {serverError}
        </Alert>
      )}

      {/* Success banner */}
      {successVisible && (
        <Alert tone="success" data-testid="success-message">
          {config.successMessage ?? "Saved successfully."}
        </Alert>
      )}

      {/* Fields */}
      <FieldSet
        sections={[section]}
        register={register}
        control={control}
        errors={errors}
        values={values}
        disabled={isPending}
      />

      {/* Submit */}
      <Button
        type="submit"
        loading={isPending}
        disabled={isPending}
        data-testid="submit-button"
        className="self-start"
      >
        {isPending ? "Saving…" : (config.submitLabel ?? "Save")}
      </Button>
    </form>
  );
}

// ─── FormDefinition-driven inner component (S4) ────────────────────────────────

interface FormDefinitionInnerProps {
  formDefinitionId: string;
  entityId?: string | undefined;
}

function FormDefinitionInner({ formDefinitionId, entityId }: FormDefinitionInnerProps) {
  const { definition, isLoading: definitionLoading, error: definitionError } = useFormDefinition(formDefinitionId);

  if (definitionLoading) {
    return <FormSkeleton fieldCount={4} />;
  }

  if (definitionError || !definition) {
    return (
      <Alert tone="danger" title="Could not load form definition" data-testid="definition-error">
        {definitionError?.message ?? "Form definition not found."}
      </Alert>
    );
  }

  return <FormDefinitionForm definition={definition} entityId={entityId} />;
}

interface FormDefinitionFormProps {
  definition: FormDefinition;
  entityId?: string | undefined;
}

function FormDefinitionForm({ definition, entityId }: FormDefinitionFormProps) {
  const mode: "create" | "edit" = entityId ? "edit" : "create";
  const submitConfig = React.useMemo(
    () => ({
      entityType: definition.entityType,
      mode,
      entityId,
      onSubmitWorkflow: definition.onSubmitWorkflow,
    }),
    [definition.entityType, definition.onSubmitWorkflow, entityId, mode],
  );
  const submitMutation = useFormSubmit(submitConfig, definition);

  const {
    register,
    control,
    handleSubmit,
    watch,
    reset,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<Record<string, unknown>>({
    resolver: zodResolver(compileDynamicSchema(definition)),
    defaultValues: buildDefinitionDefaultValues(definition),
  });

  const values = watch();

  const { data: entityData, isLoading: entityLoading, error: entityError } = useEntity<EntityData>(
    definition.entityType,
    entityId ?? "",
    { enabled: mode === "edit" },
  );

  const populated = React.useRef(false);
  React.useEffect(() => {
    if (mode === "edit" && entityData && !populated.current) {
      populated.current = true;
      reset(entityData as Record<string, unknown>);
    }
  }, [mode, entityData, reset]);

  const [successVisible, setSuccessVisible] = React.useState(false);
  const [serverError, setServerError] = React.useState<string | null>(null);

  const isPending = isSubmitting || submitMutation.isPending;

  async function onValid(data: Record<string, unknown>) {
    setServerError(null);
    setSuccessVisible(false);

    try {
      await submitMutation.mutateAsync(data as EntityData);
      setSuccessVisible(true);
      toast({ tone: "success", title: definition.successMessage });
      if (mode === "create") {
        reset(buildDefinitionDefaultValues(definition));
        populated.current = false;
      }
    } catch (err: unknown) {
      if (isServerValidationError(err)) {
        for (const issue of err.issues) {
          setError(issue.path as string, { message: issue.message });
        }
      } else {
        setServerError(err instanceof Error ? err.message : "An unexpected error occurred.");
      }
    }
  }

  if (mode === "edit" && entityLoading) {
    return <FormSkeleton fieldCount={definition.sections.reduce((n, s) => n + s.fields.length, 0)} />;
  }

  if (mode === "edit" && entityError) {
    return (
      <Alert tone="danger" title="Could not load entity" data-testid="entity-error">
        {entityError.message}
      </Alert>
    );
  }

  return (
    <form onSubmit={handleSubmit(onValid)} noValidate className="flex flex-col gap-4" data-testid="form-builder">
      {serverError && (
        <Alert tone="danger" data-testid="server-error">
          {serverError}
        </Alert>
      )}
      {successVisible && (
        <Alert tone="success" data-testid="success-message">
          {definition.successMessage}
        </Alert>
      )}
      <FieldSet
        sections={definition.sections}
        register={register}
        control={control}
        errors={errors}
        values={values}
        disabled={isPending}
      />
      <Button type="submit" loading={isPending} disabled={isPending} data-testid="submit-button" className="self-start">
        {isPending ? "Saving…" : definition.submitLabel}
      </Button>
    </form>
  );
}

function buildDefinitionDefaultValues(definition: FormDefinition): Record<string, unknown> {
  const defaults: Record<string, unknown> = {};
  for (const section of definition.sections) {
    for (const field of section.fields) {
      if (field.type === "checkbox" || field.type === "switch") defaults[field.id] = false;
      else if (field.type === "number") defaults[field.id] = undefined;
      else if (field.type === "checkbox-group" || field.type === "tags") defaults[field.id] = [];
      else if (field.type === "date-range") defaults[field.id] = {};
      // Seeded with one empty row, matching forms-blocks.jsx's RepeatableGroup
      // ("at least one row visible" convention) — useFieldArray otherwise
      // starts empty and renders no row at all.
      else if (field.type === "repeatable-group") {
        defaults[field.id] = [
          Object.fromEntries(
            (field.subFields ?? []).map((sf) => [sf.id, sf.type === "checkbox" || sf.type === "switch" ? false : ""]),
          ),
        ];
      } else defaults[field.id] = "";
    }
  }
  return defaults;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function buildDefaultValues(fields: FieldDef[]): Record<string, unknown> {
  const defaults: Record<string, unknown> = {};
  for (const fd of fields) {
    if (fd.type === "checkbox") defaults[fd.field] = false;
    else if (fd.type === "number") defaults[fd.field] = undefined;
    else defaults[fd.field] = "";
  }
  return defaults;
}

/**
 * Adapts a legacy `FieldDef` (flat, `field`-keyed) into the `FormFieldDef`
 * shape `FieldSet` renders — lossless round-trip (FieldSet's own internal
 * adapter converts back to a `FieldDef`-shaped object for `FieldRenderer`),
 * so legacy `FormBuilderConfig` consumers render byte-for-byte the same DOM
 * as before this refactor (proven by `tests/form-builder.test.tsx` passing
 * unmodified).
 */
function legacyToFormFieldDef(fd: FieldDef): FormFieldDef {
  return {
    id: fd.field,
    label: fd.label,
    type: fd.type,
    required: fd.required ?? false,
    placeholder: fd.placeholder,
    options: fd.options?.map((opt) => ({ value: opt, label: opt })),
    span: "full",
    min: fd.min,
    max: fd.max,
    pattern: fd.pattern,
  };
}

type ServerValidationError = {
  issues: Array<{ path: string; message: string }>;
};

function isServerValidationError(err: unknown): err is ServerValidationError {
  return (
    typeof err === "object" &&
    err !== null &&
    "issues" in err &&
    Array.isArray((err as ServerValidationError).issues)
  );
}
