import { z } from "zod";
import { DerivedValueSchema, PredicateSchema } from "@dbp/contracts/predicate";

const FieldType = z.enum(["text", "number", "date", "select", "textarea", "checkbox"]);

/**
 * @deprecated Use `FormFieldDefSchema` (below) — kept for `FormBuilderConfig` back-compat.
 */
const FieldDef = z.object({
  /** The entity data field key this form field writes. */
  field: z.string().min(1),
  /** Human-readable label displayed above the field. */
  label: z.string().min(1),
  /** Input type — drives both the renderer and the dynamic Zod validation schema. */
  type: FieldType,
  /** When true, the field is required in the generated Zod schema. Defaults to false. */
  required: z.boolean().optional(),
  /** Placeholder text shown inside the field while empty. */
  placeholder: z.string().optional(),
  /** Options list — required when type is "select". */
  options: z.array(z.string()).optional(),
  /** Minimum numeric value (number fields) or minimum string length (text/textarea). */
  min: z.number().optional(),
  /** Maximum numeric value (number fields) or maximum string length (text/textarea). */
  max: z.number().optional(),
  /** Regex pattern string for text/textarea validation (without delimiters, e.g. "^[A-Z]"). */
  pattern: z.string().optional(),
});
export type FieldDef = z.infer<typeof FieldDef>;

const OnSubmitWorkflow = z.object({
  /** Workflow definition ID to start after a successful entity save. */
  definitionId: z.string().min(1),
  /**
   * Additional fields to merge into the workflow context alongside the saved entity.
   * Example: { tenantId: "acme", priority: "high" }
   */
  contextFields: z.record(z.string(), z.unknown()).optional(),
});
export type OnSubmitWorkflow = z.infer<typeof OnSubmitWorkflow>;

/**
 * @deprecated Use `FormDefinitionSchema` (below) — `FormBuilderConfig` is kept, unremoved,
 * for existing solutions passing a flat `fields: FieldDef[]` compile-time prop. See
 * `docs/03-features/specs/spec-forms-maturity-2026-07-10.md` §4.3 for the migration posture.
 *
 * FormBuilderConfig — the single typed contract for APP.F03.
 *
 * Data-only contract (no function fields). Callbacks are surfaced via DOM
 * CustomEvents: "dbp:form-builder:submitted" and "dbp:form-builder:workflow-started".
 */
export const FormBuilderConfig = z
  .object({
    /** PS.DATA entity type to create or edit (e.g. "invoice", "purchase-order"). */
    entityType: z.string().min(1),
    /** "create" renders a blank form; "edit" prefetches the entity and populates fields. */
    mode: z.enum(["create", "edit"]),
    /** Required when mode is "edit". The ID of the entity to fetch and patch. */
    entityId: z.string().optional(),
    /** Field definitions driving the form layout and validation. */
    fields: z.array(FieldDef).min(1),
    /** Text shown on the submit button. Defaults to "Save". */
    submitLabel: z.string().optional(),
    /**
     * When present, a successful PS.DATA save also triggers PS.WORKFLOW startWorkflow.
     * The saved entity record is available in the workflow context as { entity: saved, ...contextFields }.
     */
    onSubmitWorkflow: OnSubmitWorkflow.optional(),
    /** Success banner text shown after submit completes. Defaults to "Saved successfully." */
    successMessage: z.string().optional(),
  })
  .refine(
    (v) => v.mode !== "edit" || (v.entityId !== undefined && v.entityId.length > 0),
    { message: "entityId is required when mode is 'edit'", path: ["entityId"] },
  );

export type FormBuilderConfig = z.infer<typeof FormBuilderConfig>;

// ─── FormDefinition — versioned, PS.DATA-stored form artifact ─────────────────
//
// Supersedes FormBuilderConfig's flat fields[] (kept, deprecated, unremoved —
// see the @deprecated notes above). Spec: spec-forms-maturity-2026-07-10.md §2.1.
// `visibleWhen`/`requiredWhen`/`derived` reuse the shared predicate/derived-value
// vocabulary from `@dbp/contracts/predicate` — imported, not redeclared.

export const FormFieldType = z.enum([
  "text", "textarea", "number", "date", "select", "checkbox", // existing FieldDef primitives, unchanged
  "radio-cards", "switch",                                     // new — record-form-v2 "right control per question"
  "file",                                                       // P2, gated behind ps-storage (spec §2.5)
  "checkbox-group",                                             // new — multi-step-form spec §4: array-of-strings value
  "search-select",                                              // new — multi-step-form spec §4: options-driven searchable select (also covers user-picker via options source)
  "tags",                                                       // new — design-audit-2026-07-17 form-kanban: chips input, string[] value
  "date-range",                                                 // new — design-audit-2026-07-17 form-kanban: { from, to } value, `to` min-constrained by `from`
  "time",                                                       // new — design-audit-2026-07-17 form-kanban: native time input, string value ("HH:mm")
  "rich-text",                                                  // new — design-audit-2026-07-17 form-kanban: Tiptap HTML string value, reuses ActivityComposer's minimal profile
  "repeatable-group",                                           // new — design-audit-2026-07-17 form-kanban: array of `subFields` rows (line-items pattern), see `subFields` below
]);
export type FormFieldType = z.infer<typeof FormFieldType>;

/**
 * RepeatableSubField — the row shape for a `type: "repeatable-group"` field's
 * `subFields`. Deliberately a restricted, non-recursive sibling of
 * `FormFieldDefSchema` (no `repeatable-group` in its own type union, no
 * `visibleWhen`/`requiredWhen`/`derived`) rather than a self-referential
 * `z.lazy(() => FormFieldDefSchema)` — a nested repeatable-inside-repeatable
 * or conditional sub-field is out of scope for the line-items pattern
 * (forms-blocks.jsx:104-120's `RepeatableGroup`) and a lazy self-reference
 * would force every other `FormFieldDefSchema` consumer (record-form,
 * multi-step-form, `z.infer` call sites) onto an explicit `z.ZodType`
 * annotation for no behavioural gain.
 */
export const RepeatableSubFieldSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  type: FormFieldType.exclude(["repeatable-group", "file"]),
  required: z.boolean().default(false),
  placeholder: z.string().optional(),
  helperText: z.string().optional(),
  options: z
    .array(z.object({ value: z.string(), label: z.string(), description: z.string().optional() }))
    .optional(),
});
export type RepeatableSubField = z.infer<typeof RepeatableSubFieldSchema>;

export const FormFieldDefSchema = z.object({
  /** Field id — was `field` on FieldDef, renamed for record-form-v2 alignment. */
  id: z.string().min(1),
  label: z.string().min(1),
  type: FormFieldType,
  required: z.boolean().default(false),
  placeholder: z.string().optional(),
  /** New — record-form-v2 requirement. */
  helperText: z.string().optional(),
  options: z
    .array(z.object({
      value: z.string(),
      label: z.string(),
      description: z.string().optional(),
      /** New — multi-step-form spec §4 (Access step's "Admin console" option, disabled + gated by role). */
      disabled: z.boolean().optional(),
    }))
    .optional(),
  /** New — record-form-v2 §1 "tightly-coupled short pairs". */
  span: z.enum(["full", "half"]).default("full"),
  /** New — character-counter requirement. */
  maxLength: z.number().int().optional(),
  min: z.number().optional(),
  max: z.number().optional(),
  pattern: z.string().optional(),
  /** AND-combined; omit = always visible. */
  visibleWhen: z.array(PredicateSchema).optional(),
  /** AND-combined; overrides `required` when matched. */
  requiredWhen: z.array(PredicateSchema).optional(),
  /** Present = read-only, computed, never user-edited. */
  derived: DerivedValueSchema.optional(),
  /** Required when `type` is `"repeatable-group"` — the row sub-field-set (forms-blocks.jsx's `RepeatableGroup`, line-items pattern). Ignored for every other type. */
  subFields: z.array(RepeatableSubFieldSchema).optional(),
  /** Label for the "add another" affordance on a `"repeatable-group"` field. Defaults to "Add another" at render time. */
  addLabel: z.string().optional(),
});
export type FormFieldDef = z.infer<typeof FormFieldDefSchema>;

export const FormSectionSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  description: z.string().optional(),
  fields: z.array(FormFieldDefSchema).min(1),
});
export type FormSection = z.infer<typeof FormSectionSchema>;

/**
 * CrossFieldRuleSchema is deliberately forms-owned — NOT unified with
 * `@dbp/contracts/predicate` (it compares two fields against each other, a
 * different shape from a field-vs-value predicate).
 */
export const CrossFieldRuleSchema = z.object({
  id: z.string().min(1),
  /** Shown as a field-level error on `appliesTo`. */
  message: z.string().min(1),
  /** Field id the error attaches to. */
  appliesTo: z.string().min(1),
  check: z.object({
    op: z.enum(["lessThanField", "greaterThanField", "equalsField", "dateBeforeField", "dateAfterField"]),
    /** The other field id. */
    compareTo: z.string().min(1),
  }),
});
export type CrossFieldRule = z.infer<typeof CrossFieldRuleSchema>;

export const FormDefinitionSchema = z.object({
  /** Stable id, e.g. "technology-standard-proposal". */
  id: z.string().min(1),
  /** PS.DATA entity type this form creates/edits. */
  entityType: z.string().min(1),
  /** P3 versioning — see spec §2.7. */
  version: z.number().int().min(1),
  status: z.enum(["draft", "published", "archived"]).default("draft"),
  sections: z.array(FormSectionSchema).min(1),
  crossFieldRules: z.array(CrossFieldRuleSchema).default([]),
  submitLabel: z.string().default("Submit"),
  labels: z.record(z.string()).default({}),
  /** Unchanged from FormBuilderConfig. */
  onSubmitWorkflow: OnSubmitWorkflow.optional(),
  successMessage: z.string().default("Saved successfully."),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
export type FormDefinition = z.infer<typeof FormDefinitionSchema>;

// ─── FormDraft — per-user, per-definition autosaved scratch document ──────────
//
// Spec §2.6, verbatim. Stored as a PS.DATA entity type "form-draft" — same
// "notes/comments = PS.DATA sub-entity" platform pattern
// `organism-record-drawer-spec-2026-07-10.md` §6 decision 5 establishes for a
// structurally identical need. Scope guard (F3 split, decision-pack Table 4):
// only `FormDefinition`s with no `type: "file"` field may draft — see
// `hooks/use-form-draft.ts`. `formVersion` pins the definition version the
// draft was created against (spec §2.7); it is never silently migrated.

export const FormDraftSchema = z.object({
  id: z.string(),
  formDefinitionId: z.string(),
  formVersion: z.number().int(),
  userId: z.string(),
  tenantId: z.string(),
  /** Partial, unvalidated — a draft may be incomplete by definition. */
  values: z.record(z.unknown()),
  dirtyFieldIds: z.array(z.string()).default([]),
  savedAt: z.string().datetime(),
});
export type FormDraft = z.infer<typeof FormDraftSchema>;

// ─── WizardDefinition — multi-step-form (APP.F27) config, form-builder-owned ──
//
// Spec: docs/03-features/specs/multi-step-form-spec-2026-07-12.md §4. A new,
// sibling schema to FormDefinitionSchema — NOT an extension of it, per
// spec-forms-maturity-2026-07-10.md §5's explicit scoping-out of step-sequencing.
// Reuses FormSectionSchema/FormFieldDefSchema/CrossFieldRuleSchema verbatim —
// a step is "a FormSection[] with a label," never a parallel field vocabulary.

export const WizardStepSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1), // shown in the step-nav
  description: z.string().optional(), // shown under the step title on the active step
  sections: z.array(FormSectionSchema).min(1), // reuses FormSection/FormFieldDef verbatim
  optional: z.boolean().default(false), // matches reference's "(optional)" step-nav suffix
  /**
   * AND-combined; omit = step always present. Reuses the same PredicateSchema
   * visibleWhen already uses at field level — evaluated against accumulated
   * cross-step values (spec §4, §5).
   */
  visibleWhen: z.array(PredicateSchema).optional(),
  /** Step-level informational callout rendered above the step's sections
   *  (spec §2 — the Finance step's warning panel). Maps onto @dbp/ui Alert. */
  notice: z
    .object({
      tone: z.enum(["info", "warning"]).default("info"),
      title: z.string().min(1),
      body: z.string().optional(),
    })
    .optional(),
});
export type WizardStep = z.infer<typeof WizardStepSchema>;

export const WizardDefinitionSchema = z.object({
  id: z.string().min(1),
  entityType: z.string().min(1), // PS.DATA entity type the final submit creates
  version: z.number().int().min(1),
  status: z.enum(["draft", "published", "archived"]).default("draft"),
  steps: z.array(WizardStepSchema).min(1), // review step is auto-generated, NOT authored here
  crossFieldRules: z.array(CrossFieldRuleSchema).default([]), // evaluated across ALL step values combined
  submitLabel: z.string().default("Submit"),
  labels: z.record(z.string()).default({}),
  onSubmitWorkflow: OnSubmitWorkflow.optional(),
  successMessage: z.string().default("Submitted successfully."),
  reviewStepLabel: z.string().default("Review"),
  requireTermsAcceptance: z.boolean().default(false), // must-accept checkbox alongside final submit
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
export type WizardDefinition = z.infer<typeof WizardDefinitionSchema>;

// Organism-level wrapper — thin, same posture as the (deprecated) FormBuilderConfig.
export const MultiStepFormOrganismConfigSchema = z
  .object({
    wizardDefinitionId: z.string().min(1).optional(),
    wizardDefinition: WizardDefinitionSchema.optional(),
    orientation: z.enum(["horizontal", "vertical"]).default("horizontal"),
  })
  .refine((v) => v.wizardDefinitionId || v.wizardDefinition, {
    message: "one of wizardDefinitionId or wizardDefinition is required",
  });
export type MultiStepFormOrganismConfig = z.infer<typeof MultiStepFormOrganismConfigSchema>;

// ─── WizardDraft — form-draft PS.DATA sub-entity, wizard-shaped ───────────────
//
// Superset of FormDraftSchema (spec §4 schema-gap table, "Draft persistence"
// row): adds `currentStepId` so a resumed draft reopens on the step the user
// left, and is keyed by `wizardDefinitionId`/`wizardVersion` instead of
// `formDefinitionId`/`formVersion`. Stored in the same "form-draft" PS.DATA
// entity type FormDraftSchema already uses — one sub-entity, two shapes
// (record-form drafts carry no `currentStepId`; wizard drafts do).

export const WizardDraftSchema = z.object({
  id: z.string(),
  wizardDefinitionId: z.string(),
  wizardVersion: z.number().int(),
  userId: z.string(),
  tenantId: z.string(),
  currentStepId: z.string(),
  /** Partial, unvalidated — a draft may be incomplete by definition. */
  values: z.record(z.unknown()),
  dirtyFieldIds: z.array(z.string()).default([]),
  savedAt: z.string().datetime(),
});
export type WizardDraft = z.infer<typeof WizardDraftSchema>;
