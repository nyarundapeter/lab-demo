import * as React from "react";
import { Skeleton } from "@dbp/ui";

interface FormSkeletonProps {
  fieldCount: number;
}

export function FormSkeleton({ fieldCount }: FormSkeletonProps) {
  return (
    <div className="flex flex-col gap-4" data-testid="form-skeleton">
      {Array.from({ length: fieldCount }).map((_, i) => (
        <div key={i} className="flex flex-col gap-1">
          <Skeleton className="h-4 w-24 rounded" />
          <Skeleton className="h-10 w-full rounded" />
        </div>
      ))}
      <Skeleton className="h-10 w-28 rounded" />
    </div>
  );
}
