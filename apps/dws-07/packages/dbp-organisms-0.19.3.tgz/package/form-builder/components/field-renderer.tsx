import * as React from "react";
import { Controller, useWatch, type Control, type UseFormRegisterReturn } from "react-hook-form";
import {
  Input,
  FormField,
  Checkbox,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
  Textarea,
  RadioGroup,
  Switch,
  SearchSelect,
  TagsField,
  TimeField,
  DateRangeField,
  RichTextField,
  type DateRangeValue,
} from "@dbp/ui";
import type { FieldDef } from "../types.js";

/** A single select/radio-cards/checkbox-group option, either a bare string or a richer shape carrying a description/disabled flag. */
export type FieldOption =
  | string
  | { value: string; label: string; description?: string | undefined; disabled?: boolean | undefined };

/**
 * Widens the legacy (deprecated) `FieldDef.type`/`options` shape to what
 * `FieldRenderer` actually renders today — `radio-cards`/`switch` plus
 * richer options (for card descriptions) and `maxLength` (for the
 * character-counter). Deliberately NOT folded into `types.ts`'s shared,
 * `@deprecated` `FieldDef`/`FormBuilderConfig` schema — that schema is still
 * consumed as-is by `FormBuilderConfig`'s flat `fields[]` legacy path
 * (`hooks/use-field-schema.ts`), and widening it there would force that
 * unrelated code to handle types it never needs to accept from raw config.
 * `renderer/field-set.tsx`'s adapter (`toLegacyFieldDef`) targets this type.
 */
export type RenderableFieldDef = Omit<FieldDef, "type" | "options"> & {
  type:
    | FieldDef["type"]
    | "radio-cards"
    | "switch"
    | "checkbox-group"
    | "search-select"
    | "tags"
    | "date-range"
    | "time"
    | "rich-text";
  options?: FieldOption[] | undefined;
  maxLength?: number | undefined;
};

interface FieldRendererProps {
  fieldDef: RenderableFieldDef;
  registration: UseFormRegisterReturn;
  /** RHF control — used by select/checkbox/radio-cards/switch fields via Controller, and for the character counter's live watch. */
  control: Control<Record<string, unknown>>;
  errorMessage?: string;
  disabled?: boolean | undefined;
}

function normalizeOption(
  option: FieldOption,
): { value: string; label: string; description?: string | undefined; disabled?: boolean | undefined } {
  return typeof option === "string" ? { value: option, label: option } : option;
}

function cnCheckboxRow(disabled?: boolean): string {
  return disabled
    ? "flex cursor-not-allowed items-start gap-2.5 opacity-55"
    : "flex cursor-pointer items-start gap-2.5";
}

/**
 * Maps a FieldDef.type to the appropriate DQ control, wired to React Hook Form.
 * Text/number/textarea/date use uncontrolled `register`; select/checkbox/
 * radio-cards/switch use Controller so the Radix-based @dbp/ui controls stay
 * in sync with RHF.
 *
 * Each field is wrapped in @dbp/ui FormField for consistent label + error
 * treatment. When an error is present, FormField renders the error <p> (with
 * role="alert" + aria-describedby) and the wrapping div carries the stable
 * `data-testid="field-error-{field}"` so the test harness can locate it.
 */
export function FieldRenderer({
  fieldDef,
  registration,
  control,
  errorMessage,
  disabled,
}: FieldRendererProps) {
  const hasError = !!errorMessage;
  const errorTestId = hasError ? `field-error-${fieldDef.field}` : undefined;

  // ── Checkbox: inline label beside the box (FormField label would duplicate) ─
  if (fieldDef.type === "checkbox") {
    return (
      <div className="flex flex-col gap-1.5" data-testid={errorTestId}>
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => (
            <label
              htmlFor={fieldDef.field}
              className="flex cursor-pointer items-center gap-2 text-sm text-[var(--color-text-secondary)]"
            >
              <Checkbox
                id={fieldDef.field}
                checked={Boolean(field.value)}
                onCheckedChange={(v) => field.onChange(v === true)}
                disabled={disabled}
                aria-invalid={hasError}
              />
              <span>
                {fieldDef.label}
                {fieldDef.required ? (
                  <>
                    <span className="ml-0.5 text-[var(--color-danger)]" aria-hidden="true">
                      *
                    </span>
                    <span className="sr-only">(required)</span>
                  </>
                ) : (
                  <span className="ml-1 text-xs font-normal text-[var(--color-text-muted)]">
                    (optional)
                  </span>
                )}
              </span>
            </label>
          )}
        />
        {hasError && (
          <p className="text-xs leading-snug text-[var(--color-danger-text)]" role="alert">
            {errorMessage}
          </p>
        )}
      </div>
    );
  }

  // ── Switch: @dbp/ui Switch via Controller (was silently falling back to Checkbox) ─
  if (fieldDef.type === "switch") {
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => (
            <Switch
              id={fieldDef.field}
              checked={Boolean(field.value)}
              onCheckedChange={field.onChange}
              disabled={disabled}
              aria-invalid={hasError}
            />
          )}
        />
      </FormField>
    );
  }

  // ── Radio-cards: @dbp/ui RadioGroup card variant via Controller (was silently falling back to Select) ─
  if (fieldDef.type === "radio-cards") {
    const options = (fieldDef.options ?? []).map(normalizeOption);
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => (
            <RadioGroup
              name={fieldDef.field}
              value={typeof field.value === "string" ? field.value : ""}
              onValueChange={field.onChange}
              options={options}
              variant="card"
              disabled={disabled}
              aria-invalid={hasError}
            />
          )}
        />
      </FormField>
    );
  }

  // ── Checkbox-group: N @dbp/ui Checkbox rows via Controller, array value ───
  // (multi-step-form spec §3 — the Application access field: multi-value form
  // state, per-option `disabled` + `description`, e.g. Admin console gated by role.)
  if (fieldDef.type === "checkbox-group") {
    const options = (fieldDef.options ?? []).map(normalizeOption);
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => {
            const current: string[] = Array.isArray(field.value) ? field.value : [];
            return (
              <div className="flex flex-col gap-2">
                {options.map((opt) => {
                  const checked = current.includes(opt.value);
                  return (
                    <label
                      key={opt.value}
                      className={cnCheckboxRow(opt.disabled)}
                    >
                      <Checkbox
                        checked={checked}
                        disabled={disabled || opt.disabled}
                        aria-invalid={hasError}
                        onCheckedChange={(v) => {
                          const next =
                            v === true ? [...current, opt.value] : current.filter((val) => val !== opt.value);
                          field.onChange(next);
                        }}
                      />
                      <span className="flex flex-col gap-0.5">
                        <span className="text-sm text-[var(--color-text-secondary)]">{opt.label}</span>
                        {opt.description && (
                          <span className="text-xs text-[var(--color-text-muted)]">{opt.description}</span>
                        )}
                      </span>
                    </label>
                  );
                })}
              </div>
            );
          }}
        />
      </FormField>
    );
  }

  // ── Tags: @dbp/ui TagsField via Controller, string[] value ────────────────
  if (fieldDef.type === "tags") {
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => (
            <TagsField
              id={fieldDef.field}
              tags={Array.isArray(field.value) ? (field.value as string[]) : []}
              onChange={field.onChange}
              placeholder={fieldDef.placeholder}
              disabled={disabled}
              aria-invalid={hasError}
            />
          )}
        />
      </FormField>
    );
  }

  // ── Time: @dbp/ui TimeField, native time input ─────────────────────────────
  if (fieldDef.type === "time") {
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <TimeField
          id={fieldDef.field}
          disabled={disabled}
          {...(hasError ? { state: "error" as const } : {})}
          {...registration}
        />
      </FormField>
    );
  }

  // ── Date-range: @dbp/ui DateRangeField via Controller, { from, to } value ──
  if (fieldDef.type === "date-range") {
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => (
            <DateRangeField
              id={fieldDef.field}
              label={fieldDef.label}
              value={(field.value as DateRangeValue | undefined) ?? {}}
              onChange={field.onChange}
              disabled={disabled}
              aria-invalid={hasError}
            />
          )}
        />
      </FormField>
    );
  }

  // ── Rich-text: @dbp/ui RichTextField via Controller, HTML string value ────
  // Reuses ActivityComposer's Tiptap v3 minimal-profile setup (ADR-0048) —
  // not a second independent editor integration.
  if (fieldDef.type === "rich-text") {
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => (
            <RichTextField
              id={fieldDef.field}
              value={typeof field.value === "string" ? field.value : ""}
              onChange={field.onChange}
              placeholder={fieldDef.placeholder}
              disabled={disabled}
              aria-invalid={hasError}
            />
          )}
        />
      </FormField>
    );
  }

  // ── Search-select: @dbp/ui SearchSelect via Controller ────────────────────
  // Also covers the "user-picker" shape (spec §3): pass options resolved from
  // PS.DATA users, each with an `icon` (an @dbp/ui Avatar) at the consuming layer.
  if (fieldDef.type === "search-select") {
    const options = (fieldDef.options ?? []).map(normalizeOption);
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => (
            <SearchSelect
              id={fieldDef.field}
              value={typeof field.value === "string" ? field.value : ""}
              onValueChange={field.onChange}
              options={options}
              placeholder={fieldDef.placeholder ?? `Select ${fieldDef.label}…`}
              disabled={disabled}
              aria-invalid={hasError}
            />
          )}
        />
      </FormField>
    );
  }

  // ── Select: Radix Select via Controller ──────────────────────────────────
  if (fieldDef.type === "select") {
    const options = (fieldDef.options ?? []).map(normalizeOption);
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Controller
          name={fieldDef.field}
          control={control}
          render={({ field }) => (
            <Select
              value={typeof field.value === "string" ? field.value : ""}
              onValueChange={field.onChange}
              {...(disabled !== undefined && { disabled })}
            >
              <SelectTrigger id={fieldDef.field} error={hasError}>
                <SelectValue placeholder={fieldDef.placeholder ?? `Select ${fieldDef.label}…`} />
              </SelectTrigger>
              <SelectContent>
                {options.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        />
      </FormField>
    );
  }

  // ── Textarea ──────────────────────────────────────────────────────────────
  if (fieldDef.type === "textarea") {
    return (
      <FormField
        label={fieldDef.label}
        id={fieldDef.field}
        required={!!fieldDef.required}
        optional={!fieldDef.required}
        {...(errorMessage !== undefined && { error: errorMessage })}
        {...(errorTestId !== undefined && { "data-testid": errorTestId })}
      >
        <Textarea
          id={fieldDef.field}
          placeholder={fieldDef.placeholder}
          disabled={disabled}
          error={hasError}
          maxLength={fieldDef.maxLength}
          {...registration}
        />
        {fieldDef.maxLength !== undefined && (
          <CharacterCounter control={control} field={fieldDef.field} maxLength={fieldDef.maxLength} />
        )}
      </FormField>
    );
  }

  // ── Default: text / number / date via Input ───────────────────────────────
  return (
    <FormField
      label={fieldDef.label}
      id={fieldDef.field}
      required={!!fieldDef.required}
      optional={!fieldDef.required}
      {...(errorMessage !== undefined && { error: errorMessage })}
      {...(errorTestId !== undefined && { "data-testid": errorTestId })}
    >
      <Input
        id={fieldDef.field}
        type={fieldDef.type}
        placeholder={fieldDef.placeholder}
        disabled={disabled}
        maxLength={fieldDef.maxLength}
        {...(hasError ? { className: "border-danger focus-visible:[box-shadow:var(--focus-ring-error)]" } : {})}
        {...registration}
      />
      {fieldDef.type === "text" && fieldDef.maxLength !== undefined && (
        <CharacterCounter control={control} field={fieldDef.field} maxLength={fieldDef.maxLength} />
      )}
    </FormField>
  );
}

/**
 * Character counter (record-form spec §3/§4: "genuine gap, not in the
 * reference either" — build item at the FieldRenderer layer, not a @dbp/ui
 * promotion, since counter text is form-specific chrome, not a reusable
 * control). Live via `useWatch` so it updates on every keystroke without the
 * field itself needing to be a controlled `Input`/`Textarea`.
 */
function CharacterCounter({
  control,
  field,
  maxLength,
}: {
  control: Control<Record<string, unknown>>;
  field: string;
  maxLength: number;
}) {
  const value = useWatch({ control, name: field });
  const length = typeof value === "string" ? value.length : 0;
  return (
    <p
      className="self-end text-xs text-[var(--color-text-muted)]"
      aria-live="polite"
    >
      {length}/{maxLength}
    </p>
  );
}
