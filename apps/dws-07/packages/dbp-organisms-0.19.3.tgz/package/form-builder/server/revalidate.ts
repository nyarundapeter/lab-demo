import type { ZodIssue } from "zod";
import { compileDynamicSchema } from "../logic/index.js";
import type { FormDefinition } from "../types.js";

export type RevalidateResult =
  | { ok: true; data: Record<string, unknown> }
  | { ok: false; issues: ZodIssue[] };

/**
 * Server-side revalidation pre-flight (directive-driven addition, build plan
 * §1 and §6 "Security checklist"). Re-runs the exact same
 * `compileDynamicSchema(definition).safeParse(values)` the client used —
 * this is the enforcement point: a client that bypasses or tampers with the
 * UI cannot submit a payload the definition itself wouldn't accept.
 *
 * `form-builder`-owned, sits in front of PS.DATA's existing generic write —
 * does not add entity-type-specific logic to PS.DATA itself (spec §4).
 */
export function revalidateFormSubmission(definition: FormDefinition, values: unknown): RevalidateResult {
  const schema = compileDynamicSchema(definition, isRecord(values) ? values : undefined);
  const result = schema.safeParse(values);

  if (!result.success) {
    return { ok: false, issues: result.error.issues };
  }

  return { ok: true, data: result.data as Record<string, unknown> };
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null;
}
