import { z } from "zod";
import type { FormDefinition, FormFieldDef } from "../types.js";
import { evaluateRequiredWhen, evaluateVisibility } from "./visibility.js";
import { compileCrossFieldRules } from "./cross-field.js";

/**
 * Compiles a `FormDefinition` into a Zod schema — supersedes
 * `hooks/use-field-schema.ts`'s inline builder for the legacy `FieldDef[]`
 * shape, richer input (sections, visibility, derived, cross-field rules).
 *
 * `currentValues` drives the visibility-aware variant: a field whose
 * `visibleWhen` evaluates false is excluded from the required set for this
 * render (spec §2.2 anti-pattern guard — an invisible required field must
 * never block submit). When `currentValues` is omitted (static/SSR use),
 * every field is treated as visible and `requiredWhen` is ignored in favour
 * of the field's static `required` flag.
 */
export function compileDynamicSchema(
  definition: FormDefinition,
  currentValues?: Record<string, unknown>,
): z.ZodTypeAny {
  const shape: z.ZodRawShape = {};

  for (const section of definition.sections) {
    for (const field of section.fields) {
      shape[field.id] = buildFieldSchema(field, currentValues);
    }
  }

  const objectSchema = z.object(shape);
  if (definition.crossFieldRules.length === 0) return objectSchema;
  return compileCrossFieldRules(definition.crossFieldRules)(objectSchema);
}

function buildFieldSchema(field: FormFieldDef, currentValues?: Record<string, unknown>): z.ZodTypeAny {
  // Derived fields are computed, never user-edited — never force-required.
  if (field.derived) {
    return baseSchemaFor(field, false).optional();
  }

  const visible = currentValues === undefined ? true : evaluateVisibility(field, currentValues);
  const required = currentValues === undefined ? field.required : evaluateRequiredWhen(field, currentValues);
  const effectiveRequired = visible && required;

  const base = baseSchemaFor(field, effectiveRequired);
  return effectiveRequired ? base : base.optional();
}

function baseSchemaFor(field: FormFieldDef, required: boolean): z.ZodTypeAny {
  switch (field.type) {
    case "checkbox":
    case "switch":
      return z.boolean();

    case "number": {
      let schema = z.coerce.number();
      if (field.min !== undefined) schema = schema.min(field.min);
      if (field.max !== undefined) schema = schema.max(field.max);
      return schema;
    }

    case "text":
    case "textarea": {
      let schema = z.string();
      if (required) {
        schema = schema.min(1, `${field.label} is required`);
      }
      if (field.min !== undefined) {
        schema = schema.min(field.min, `${field.label} must be at least ${field.min} characters`);
      }
      if (field.maxLength !== undefined) {
        schema = schema.max(field.maxLength, `${field.label} must be at most ${field.maxLength} characters`);
      } else if (field.max !== undefined) {
        schema = schema.max(field.max, `${field.label} must be at most ${field.max} characters`);
      }
      if (field.pattern !== undefined) {
        schema = schema.regex(new RegExp(field.pattern), `${field.label} format is invalid`);
      }
      return schema;
    }

    case "date":
    case "select":
    case "radio-cards":
    case "search-select": {
      let schema = z.string();
      if (required) {
        schema = schema.min(1, `${field.label} is required`);
      }
      return schema;
    }

    // multi-step-form spec §4 — array-of-strings value (Application access).
    case "checkbox-group": {
      let schema = z.array(z.string());
      if (required) {
        schema = schema.min(1, `${field.label} is required`);
      }
      return schema;
    }

    // design-audit-2026-07-17 form-kanban — chips input, string[] value.
    case "tags": {
      let schema = z.array(z.string());
      if (required) {
        schema = schema.min(1, `${field.label} is required`);
      }
      return schema;
    }

    // design-audit-2026-07-17 form-kanban — native time input, "HH:mm" string.
    case "time": {
      let schema = z.string();
      if (required) {
        schema = schema.min(1, `${field.label} is required`);
      }
      return schema;
    }

    // design-audit-2026-07-17 form-kanban — { from, to } value, `to` min-constrained by `from` in the control itself.
    case "date-range": {
      const schema = z.object({ from: z.string().optional(), to: z.string().optional() });
      if (required) {
        return schema.refine((v) => !!v.from && !!v.to, { message: `${field.label} is required` });
      }
      return schema;
    }

    // design-audit-2026-07-17 form-kanban — Tiptap HTML string value.
    case "rich-text": {
      let schema = z.string();
      if (required) {
        schema = schema.min(1, `${field.label} is required`);
      }
      return schema;
    }

    // design-audit-2026-07-17 form-kanban — array of `subFields` rows (line-items pattern). Row-level validation is out of scope here (RepeatableSubFieldSchema options don't carry min/max/pattern) — only presence is enforced.
    case "repeatable-group": {
      let schema = z.array(z.record(z.string(), z.unknown()));
      if (required) {
        schema = schema.min(1, `${field.label} is required`);
      }
      return schema;
    }

    // P2: gated behind ps-storage — schema-only placeholder until the live
    // control lands (spec §2.5). Accepts any value shape (object ref or
    // unset) without validating upload contents.
    case "file":
      return z.unknown();
  }
}
