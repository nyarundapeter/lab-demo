import { z } from "zod";
import type { CrossFieldRule } from "../types.js";

/**
 * Compiles `crossFieldRules[]` into a Zod `.superRefine()` wrapper — one
 * `ctx.addIssue` per failing rule, attached to `path: [rule.appliesTo]`.
 */
export function compileCrossFieldRules(rules: CrossFieldRule[]) {
  return <Schema extends z.ZodTypeAny>(schema: Schema) =>
    schema.superRefine((values, ctx) => {
      if (typeof values !== "object" || values === null) return;
      const record = values as Record<string, unknown>;
      for (const rule of rules) {
        if (!checkCrossFieldRule(rule, record)) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: rule.message,
            path: [rule.appliesTo],
          });
        }
      }
    });
}

/** Returns true when the rule is satisfied (no issue), false when it fails. */
function checkCrossFieldRule(rule: CrossFieldRule, values: Record<string, unknown>): boolean {
  const a = values[rule.appliesTo];
  const b = values[rule.check.compareTo];

  switch (rule.check.op) {
    case "lessThanField":
      return !(typeof a === "number" && typeof b === "number") || a < b;
    case "greaterThanField":
      return !(typeof a === "number" && typeof b === "number") || a > b;
    case "equalsField":
      return a === b;
    case "dateBeforeField": {
      const da = toDate(a);
      const db = toDate(b);
      return !da || !db || da.getTime() < db.getTime();
    }
    case "dateAfterField": {
      const da = toDate(a);
      const db = toDate(b);
      return !da || !db || da.getTime() > db.getTime();
    }
  }
}

function toDate(v: unknown): Date | null {
  if (typeof v !== "string" && typeof v !== "number") return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}
