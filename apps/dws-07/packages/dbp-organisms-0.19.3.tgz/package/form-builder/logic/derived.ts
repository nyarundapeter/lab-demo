import type { DerivedValue } from "@dbp/contracts/predicate";

/**
 * Evaluates a closed-set derived-value expression (spec §2.3 — `sum | subtract |
 * multiply | divide | concat | dateDiffDays`, never arbitrary eval). A derived
 * field must never crash the form: divide-by-zero and non-numeric inputs
 * coerce-fail gracefully to `0`/empty string rather than throwing.
 */
export function evaluateDerivedField(expr: DerivedValue, values: Record<string, unknown>): string | number {
  switch (expr.op) {
    case "sum": {
      const nums = expr.inputs.map((id) => toNumber(values[id]));
      if (nums.some((n) => n === null)) return 0;
      const safeNums = nums as number[];
      return round(safeNums.reduce((a, b) => a + b, 0), expr.round);
    }
    case "subtract": {
      const nums = expr.inputs.map((id) => toNumber(values[id]));
      if (nums.length === 0 || nums.some((n) => n === null)) return 0;
      const [first, ...rest] = nums as number[];
      return round(rest.reduce((a, b) => a - b, first ?? 0), expr.round);
    }
    case "multiply": {
      const nums = expr.inputs.map((id) => toNumber(values[id]));
      if (nums.some((n) => n === null)) return 0;
      const safeNums = nums as number[];
      return round(safeNums.reduce((a, b) => a * b, 1), expr.round);
    }
    case "divide": {
      const nums = expr.inputs.map((id) => toNumber(values[id]));
      if (nums.length === 0 || nums.some((n) => n === null)) return 0;
      const [first, ...rest] = nums as number[];
      let result: number = first ?? 0;
      for (const divisor of rest) {
        // Divide-by-zero guard (spec §6 checklist item) — never throws, returns 0.
        if (divisor === 0) return 0;
        result = result / divisor;
      }
      if (!Number.isFinite(result)) return 0;
      return round(result, expr.round);
    }
    case "concat": {
      const parts = expr.inputs.map((id) => stringify(values[id]));
      return parts.join(expr.separator ?? "");
    }
    case "dateDiffDays": {
      const [fromId, toId] = expr.inputs;
      const from = fromId ? toDate(values[fromId]) : null;
      const to = toId ? toDate(values[toId]) : null;
      if (!from || !to) return 0;
      const diffMs = to.getTime() - from.getTime();
      return Math.round(diffMs / (1000 * 60 * 60 * 24));
    }
  }
}

function toNumber(v: unknown): number | null {
  if (typeof v === "number") return Number.isFinite(v) ? v : null;
  if (typeof v === "string" && v.trim() !== "") {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

function toDate(v: unknown): Date | null {
  if (typeof v !== "string" && typeof v !== "number") return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

function stringify(v: unknown): string {
  if (v === undefined || v === null) return "";
  return String(v);
}

function round(n: number, precision?: number): number {
  if (precision === undefined) return n;
  const factor = 10 ** precision;
  return Math.round(n * factor) / factor;
}
