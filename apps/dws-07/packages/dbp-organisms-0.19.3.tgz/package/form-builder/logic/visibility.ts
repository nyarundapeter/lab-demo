import type { Predicate } from "@dbp/contracts/predicate";
import type { FormFieldDef } from "../types.js";

/**
 * Pure predicate evaluation — same closed-op-set switch shape as
 * `workflow-maturity-p1-plan-2026-07-10.md` §3 Step 2.7's `evalPredicate`
 * (copied, not re-derived — see forms-maturity build plan §8 cross-references).
 * No I/O, no `new Function`, no `eval`. Missing/malformed values never throw —
 * they fall through to `false`/`undefined` comparisons.
 */
export function evalPredicate(p: Predicate, values: Record<string, unknown>): boolean {
  const actual = values[p.field];
  switch (p.op) {
    case "eq": return actual === p.value;
    case "neq": return actual !== p.value;
    case "gt": return typeof actual === "number" && typeof p.value === "number" && actual > p.value;
    case "gte": return typeof actual === "number" && typeof p.value === "number" && actual >= p.value;
    case "lt": return typeof actual === "number" && typeof p.value === "number" && actual < p.value;
    case "lte": return typeof actual === "number" && typeof p.value === "number" && actual <= p.value;
    case "in": return Array.isArray(p.value) && typeof actual === "string" && p.value.includes(actual);
    case "notIn": return Array.isArray(p.value) && typeof actual === "string" && !p.value.includes(actual);
    case "contains":
      if (Array.isArray(actual) && typeof p.value === "string") return actual.includes(p.value);
      return typeof actual === "string" && typeof p.value === "string" && actual.includes(p.value);
    case "isEmpty": return actual === undefined || actual === null || actual === "";
    case "isNotEmpty": return !(actual === undefined || actual === null || actual === "");
  }
}

/** AND-combines a field's `visibleWhen` predicates. Omitted `visibleWhen` = always visible. */
export function evaluateVisibility(field: FormFieldDef, values: Record<string, unknown>): boolean {
  if (!field.visibleWhen || field.visibleWhen.length === 0) return true;
  return field.visibleWhen.every((p) => evalPredicate(p, values));
}

/** AND-combines a field's `requiredWhen` predicates. Omitted `requiredWhen` = defer to `field.required`. */
export function evaluateRequiredWhen(field: FormFieldDef, values: Record<string, unknown>): boolean {
  if (!field.requiredWhen || field.requiredWhen.length === 0) return field.required;
  return field.requiredWhen.every((p) => evalPredicate(p, values));
}
