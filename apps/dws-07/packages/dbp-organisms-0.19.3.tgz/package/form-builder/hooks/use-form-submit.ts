import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createEntity, updateEntity } from "@dbp/ps-data/client";
import { startWorkflow } from "@dbp/ps-workflow/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import { revalidateFormSubmission } from "../server/revalidate.js";
import type { FormDefinition, OnSubmitWorkflow } from "../types.js";

export type SubmitResult = {
  record: EntityRecord<EntityData>;
  workflowStarted: boolean;
};

/**
 * Structural subset of `FormBuilderConfig` this hook actually needs —
 * `FormBuilderConfig` satisfies it as-is; the `FormDefinition`-driven path
 * (S4, `use-form-definition.ts`) builds this shape directly without needing
 * a full (fields-bearing) `FormBuilderConfig`.
 */
export interface SubmitConfig {
  entityType: string;
  mode: "create" | "edit";
  entityId?: string | undefined;
  onSubmitWorkflow?: OnSubmitWorkflow | undefined;
}

/**
 * Mirrors the shape/contract of PS.DATA's `DataServiceError` (`issues: [{
 * path, message }]`) so `FormBuilderInner`'s existing `isServerValidationError`
 * catch-branch surfaces a revalidation rejection identically to a real
 * PS.DATA 400 — zero UI changes needed.
 */
export class FormRevalidationError extends Error {
  readonly issues: Array<{ path: string; message: string }>;

  constructor(issues: Array<{ path: string; message: string }>) {
    super("Form submission failed server-side revalidation");
    this.name = "FormRevalidationError";
    this.issues = issues;
  }
}

/**
 * Encapsulates the PS.DATA create/update + optional PS.WORKFLOW startWorkflow call.
 * Returns a TanStack useMutation handle wrapping the two-step sequence.
 *
 * `formDefinition` (optional) activates the server-side revalidation
 * pre-flight (build plan §1/§6): `revalidateFormSubmission` re-runs the
 * dynamic schema's `safeParse` before the PS.DATA write, so a payload that
 * bypasses/tampers with client validation is rejected with the same
 * `{ issues: [{ path, message }] }` shape a PS.DATA 400 already produces —
 * the existing inline-error-surfacing code needs zero changes. Legacy
 * `FormBuilderConfig` consumers (no `formDefinition`) keep today's
 * client-only-then-PS.DATA-generic-400 behavior, since they have no
 * server-fetchable definition to revalidate against.
 */
export function useFormSubmit(config: SubmitConfig, formDefinition?: FormDefinition) {
  const queryClient = useQueryClient();

  return useMutation<SubmitResult, Error, EntityData>({
    mutationFn: async (formData) => {
      if (formDefinition) {
        const revalidated = revalidateFormSubmission(formDefinition, formData);
        if (!revalidated.ok) {
          throw new FormRevalidationError(
            revalidated.issues.map((issue) => ({
              path: issue.path.join("."),
              message: issue.message,
            })),
          );
        }
      }

      let saved: EntityRecord<EntityData>;

      if (config.mode === "edit" && config.entityId) {
        saved = await updateEntity(config.entityType, config.entityId, formData);
      } else {
        saved = await createEntity(config.entityType, formData);
      }

      document.dispatchEvent(
        new CustomEvent("dbp:form-builder:submitted", {
          detail: { entityType: config.entityType, entityId: saved.id, mode: config.mode },
          bubbles: true,
        }),
      );

      let workflowStarted = false;

      if (config.onSubmitWorkflow) {
        const { definitionId, contextFields } = config.onSubmitWorkflow;
        try {
          const instance = await startWorkflow(definitionId, {
            entity: saved,
            ...contextFields,
          });
          workflowStarted = true;
          document.dispatchEvent(
            new CustomEvent("dbp:form-builder:workflow-started", {
              detail: { definitionId, instanceId: instance.workflowId },
              bubbles: true,
            }),
          );
        } catch (err) {
          console.warn("[APP.F03] workflow start failed after successful save:", err);
          document.dispatchEvent(
            new CustomEvent("dbp:form-builder:workflow-error", {
              detail: { definitionId, error: err },
              bubbles: true,
            }),
          );
        }
      }

      return { record: saved, workflowStarted };
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity-list", config.entityType] });
      if (config.mode === "edit" && config.entityId) {
        void queryClient.invalidateQueries({
          queryKey: ["ps-data", "entity", config.entityType, config.entityId],
        });
      }
    },
  });
}
