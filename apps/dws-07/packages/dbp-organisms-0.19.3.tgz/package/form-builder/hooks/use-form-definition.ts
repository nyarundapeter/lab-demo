import { useEntity } from "@dbp/ps-data/client";
import { FormDefinitionSchema } from "../types.js";
import type { FormDefinition } from "../types.js";

/**
 * Fetches a `FormDefinition` at runtime via PS.DATA's existing generic CRUD
 * route (`GET /api/platform/data/form-definition/:id`, unchanged — spec §2.1)
 * — the gap spec §1.1 names: `FormBuilderConfig` is a compile-time prop only,
 * `FormDefinition` is fetchable/runtime-editable.
 */
export function useFormDefinition(id: string, options: { enabled?: boolean } = {}) {
  const { data, isLoading, error } = useEntity<FormDefinition>("form-definition", id, options);

  let definition: FormDefinition | undefined;
  let parseError: Error | undefined;

  if (data) {
    const parsed = FormDefinitionSchema.safeParse(data);
    if (parsed.success) {
      definition = parsed.data;
    } else {
      parseError = new Error(
        `Invalid form-definition record (id: ${id}): ${parsed.error.issues.map((i) => i.message).join("; ")}`,
      );
    }
  }

  return {
    definition,
    isLoading,
    error: error ?? parseError,
  };
}
