import * as React from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createEntity, listEntities, updateEntity } from "@dbp/ps-data/client";
import { FormDraftSchema } from "../types.js";
import type { FormDefinition, FormDraft } from "../types.js";

/**
 * Autosave debounce (F2, spec §2.6 / decision-pack Table 4, locked
 * 2026-07-11): **3s-after-change-or-on-blur**. Shared verbatim with whichever
 * session builds record-form V2's "Unsaved changes" indicator — one shared UX
 * timing, not two builds independently guessing. Exported via
 * `@dbp/form-builder/hooks` so that build imports the same constant instead
 * of re-deriving it.
 */
export const AUTOSAVE_DEBOUNCE_MS = 3000;

export interface UseFormDraftOptions {
  userId: string;
  tenantId: string;
  enabled?: boolean;
}

export type DraftVersionResolution = "pending" | "continue-old-version" | "restart";

export interface UseFormDraftResult {
  draft: FormDraft | undefined;
  isLoading: boolean;
  /** True while an autosave (scheduled or flushed) is in flight. */
  isSaving: boolean;
  /**
   * True when a resumed draft was saved against an older
   * `FormDefinition.version` than `definition.version` and the user has not
   * yet chosen how to proceed (spec §2.7). No automatic migration (F4) — the
   * caller must show the "continue with your version" / "start over with the
   * latest version" choice and call `continueWithOldVersion`/`restart`.
   */
  versionMismatch: boolean;
  resolution: DraftVersionResolution;
  /** Debounced autosave — resets the 3s timer on every call (F2). */
  scheduleAutosave: (values: Record<string, unknown>, dirtyFieldIds: string[]) => void;
  /** Immediate save, bypassing the debounce — call on field blur (F2). */
  flushAutosave: (values: Record<string, unknown>, dirtyFieldIds: string[]) => void;
  /** User chose "continue with your version" — dismisses the mismatch banner. Values and the pinned `formVersion` are left exactly as saved; no migration (F4). */
  continueWithOldVersion: () => void;
  /** User chose "start over with the latest version" — clears the draft's values and re-pins `formVersion` to the current `definition.version`. */
  restart: () => void;
}

const draftListKey = (formDefinitionId: string, userId: string) =>
  ["ps-data", "entity-list", "form-draft", formDefinitionId, userId] as const;

/**
 * Draft persistence for `FormDefinition`-driven forms (spec §2.6, build plan
 * Session 5). One draft per (formDefinitionId, userId) — resumed via a
 * PS.DATA list-filter lookup, not a client-guessed id (PS.DATA assigns ids
 * server-side on create, per `sdk.ts#createEntity`).
 *
 * **Scope guard (F3 split, decision-pack Table 4):** only `FormDefinition`s
 * with no `type: "file"` field may draft — file-field drafts are blocked on
 * `ps-storage` (GAP-BRS-1), tracked as build-plan Session 9. Calling this
 * against a file-bearing definition is a dev-time error, not a silent no-op.
 */
export function useFormDraft(definition: FormDefinition, options: UseFormDraftOptions): UseFormDraftResult {
  const hasFileField = definition.sections.some((section) =>
    section.fields.some((field) => field.type === "file"),
  );
  if (hasFileField) {
    throw new Error(
      `[APP.F03] useFormDraft: "${definition.id}" has a file-typed field — file-upload drafts require ` +
        "ps-storage (GAP-BRS-1) and are not yet available. Tracked as build-plan Session 9 " +
        "(docs/09-plans/forms-maturity-build-plan-2026-07-11.md). Do not call useFormDraft against a " +
        "FormDefinition containing a file field until then.",
    );
  }

  const { userId, tenantId, enabled = true } = options;
  const queryClient = useQueryClient();
  const listKey = draftListKey(definition.id, userId);
  const draftIdRef = React.useRef<string | undefined>(undefined);
  const timerRef = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [resolution, setResolution] = React.useState<DraftVersionResolution>("pending");

  const query = useQuery({
    queryKey: listKey,
    queryFn: async () => {
      const result = await listEntities<FormDraft>("form-draft", {
        filters: { formDefinitionId: definition.id, userId },
        pageSize: 1,
      });
      // TanStack Query rejects a queryFn returning `undefined` — `null`
      // stands in for "no draft found" and is unwrapped below.
      return result.rows[0]?.data ?? null;
    },
    enabled,
  });

  const draft = query.data ?? undefined;
  React.useEffect(() => {
    if (draft) draftIdRef.current = draft.id;
  }, [draft]);

  const saveMutation = useMutation({
    mutationFn: async (payload: {
      values: Record<string, unknown>;
      dirtyFieldIds: string[];
      formVersion: number;
    }) => {
      const savedAt = new Date().toISOString();
      if (draftIdRef.current) {
        const updated = await updateEntity<FormDraft>("form-draft", draftIdRef.current, {
          values: payload.values,
          dirtyFieldIds: payload.dirtyFieldIds,
          // Included so `restart()` can re-pin `formVersion` to the current
          // definition version — a plain autosave on an existing draft
          // passes the same (unchanged) value through here.
          formVersion: payload.formVersion,
          savedAt,
        });
        return updated.data;
      }
      // PS.DATA assigns the record id server-side (`sdk.ts#createEntity` never
      // sends one) — `FormDraftSchema.id` is the draft's own data-level id per
      // the spec's literal schema, generated here since it has no other source.
      const created = await createEntity<FormDraft>(
        "form-draft",
        FormDraftSchema.parse({
          id: crypto.randomUUID(),
          formDefinitionId: definition.id,
          formVersion: payload.formVersion,
          userId,
          tenantId,
          values: payload.values,
          dirtyFieldIds: payload.dirtyFieldIds,
          savedAt,
        }),
      );
      draftIdRef.current = created.id;
      return created.data;
    },
    onSuccess: (saved) => {
      queryClient.setQueryData(listKey, saved);
    },
  });

  const clearTimer = React.useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = undefined;
    }
  }, []);

  const save = React.useCallback(
    (values: Record<string, unknown>, dirtyFieldIds: string[], formVersion?: number) => {
      saveMutation.mutate({
        values,
        dirtyFieldIds,
        formVersion: formVersion ?? draft?.formVersion ?? definition.version,
      });
    },
    [saveMutation, draft?.formVersion, definition.version],
  );

  const scheduleAutosave = React.useCallback(
    (values: Record<string, unknown>, dirtyFieldIds: string[]) => {
      clearTimer();
      timerRef.current = setTimeout(() => {
        timerRef.current = undefined;
        save(values, dirtyFieldIds);
      }, AUTOSAVE_DEBOUNCE_MS);
    },
    [clearTimer, save],
  );

  const flushAutosave = React.useCallback(
    (values: Record<string, unknown>, dirtyFieldIds: string[]) => {
      clearTimer();
      save(values, dirtyFieldIds);
    },
    [clearTimer, save],
  );

  React.useEffect(() => clearTimer, [clearTimer]);

  const versionMismatch =
    Boolean(draft) && draft!.formVersion !== definition.version && resolution === "pending";

  const continueWithOldVersion = React.useCallback(() => setResolution("continue-old-version"), []);

  const restart = React.useCallback(() => {
    setResolution("restart");
    // Re-pin to the *current* published version explicitly — `save`'s
    // default falls back to the stale `draft.formVersion`, which is exactly
    // the value a restart must NOT reuse.
    save({}, [], definition.version);
  }, [save, definition.version]);

  return {
    draft,
    isLoading: query.isLoading,
    isSaving: saveMutation.isPending,
    versionMismatch,
    resolution,
    scheduleAutosave,
    flushAutosave,
    continueWithOldVersion,
    restart,
  };
}
