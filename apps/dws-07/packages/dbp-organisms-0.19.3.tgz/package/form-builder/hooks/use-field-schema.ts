import { useMemo } from "react";
import { z } from "zod";
import type { FieldDef } from "../types.js";

/**
 * Builds a Zod object schema from the field definitions in FormBuilderConfig.
 *
 * Each field type maps to a specific Zod type and applies optional/required,
 * min, max, and pattern constraints. The resulting schema is used as the
 * zodResolver source for React Hook Form.
 *
 * Approach: build a `z.ZodRawShape` record keyed by `field`, then wrap in `z.object`.
 * Memoised on the fields array reference — stable when config doesn't change.
 */
export function useFieldSchema(fields: FieldDef[]): z.ZodObject<z.ZodRawShape> {
  return useMemo(() => buildFieldSchema(fields), [fields]);
}

export function buildFieldSchema(fields: FieldDef[]): z.ZodObject<z.ZodRawShape> {
  const shape: z.ZodRawShape = {};

  for (const fd of fields) {
    shape[fd.field] = buildSingleFieldSchema(fd);
  }

  return z.object(shape);
}

function buildSingleFieldSchema(fd: FieldDef): z.ZodTypeAny {
  switch (fd.type) {
    case "checkbox":
      return z.boolean();

    case "number": {
      let schema = z.coerce.number();
      if (fd.min !== undefined) schema = schema.min(fd.min);
      if (fd.max !== undefined) schema = schema.max(fd.max);
      if (!fd.required) return schema.optional();
      return schema;
    }

    case "text":
    case "textarea": {
      let schema = z.string();
      if (fd.required) {
        schema = schema.min(1, `${fd.label} is required`);
      }
      if (fd.min !== undefined) {
        schema = schema.min(fd.min, `${fd.label} must be at least ${fd.min} characters`);
      }
      if (fd.max !== undefined) {
        schema = schema.max(fd.max, `${fd.label} must be at most ${fd.max} characters`);
      }
      if (fd.pattern !== undefined) {
        schema = schema.regex(new RegExp(fd.pattern), `${fd.label} format is invalid`);
      }
      if (!fd.required) return schema.optional();
      return schema;
    }

    case "date": {
      let schema = z.string();
      if (fd.required) {
        schema = schema.min(1, `${fd.label} is required`);
      }
      if (!fd.required) return schema.optional();
      return schema;
    }

    case "select": {
      let schema = z.string();
      if (fd.required) {
        schema = schema.min(1, `${fd.label} is required`);
      }
      if (!fd.required) return schema.optional();
      return schema;
    }
  }
}
