import * as React from "react";
import { useForm, type Resolver } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@dbp/ui";
import { compileDynamicSchema } from "../logic/index.js";
import type { FormDefinition } from "../types.js";
import { FieldSet } from "./field-set.js";
import { useDerivedFieldSync, useFormDefinitionSchema } from "./use-form-definition-schema.js";

export { FieldSet } from "./field-set.js";
export type { FieldSetProps } from "./field-set.js";
export { useFormDefinitionSchema, useDerivedFieldSync } from "./use-form-definition-schema.js";

export interface FormRendererProps {
  definition: FormDefinition;
  defaultValues?: Record<string, unknown>;
  onSubmit: (values: Record<string, unknown>) => void | Promise<void>;
  disabled?: boolean;
  submitLabel?: string;
}

/**
 * FormRenderer — the whole "form shell" (useForm + FieldSet + submit button)
 * for consumers that want field-stack + validation choreography for free,
 * without any PS.DATA wiring. `record-form`/`multi-step-form` own their own
 * submit handler and mount this directly; `form-builder`'s own PS.DATA-fetching
 * wrapper (`FormBuilderInner`) composes `FieldSet` itself instead, since it
 * already owns its own submit/error-surfacing flow.
 *
 * Validation is visibility-aware: the resolver recompiles `compileDynamicSchema`
 * against the values RHF is about to validate on every call (not a memoized
 * schema captured at mount) — a field hidden by `visibleWhen` is excluded from
 * the required set for that submit/blur, matching `FieldSet`'s DOM exclusion
 * (spec §2.2).
 */
export function FormRenderer({ definition, defaultValues, onSubmit, disabled, submitLabel }: FormRendererProps) {
  const resolver: Resolver<Record<string, unknown>> = React.useCallback(
    async (values, context, options) => {
      const schema = compileDynamicSchema(definition, values);
      return zodResolver(schema)(values, context, options);
    },
    [definition],
  );

  const {
    register,
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<Record<string, unknown>>({
    resolver,
    defaultValues: defaultValues ?? buildDefaultValues(definition),
  });

  const values = watch();
  // Available to consumers that want the compiled schema directly (e.g. to
  // pre-validate before this component mounts); FormRenderer itself validates
  // via the resolver above, which recompiles per-call rather than per-render.
  useFormDefinitionSchema(definition, values);
  useDerivedFieldSync(definition, values, setValue);

  const isPending = isSubmitting || Boolean(disabled);

  return (
    <form
      onSubmit={handleSubmit((data) => onSubmit(data))}
      noValidate
      className="flex flex-col gap-6"
      data-testid="form-renderer"
    >
      <FieldSet
        sections={definition.sections}
        register={register}
        control={control}
        errors={errors}
        values={values}
        disabled={isPending}
      />
      <Button type="submit" loading={isPending} disabled={isPending} data-testid="submit-button" className="self-start">
        {isPending ? "Saving…" : (submitLabel ?? definition.submitLabel)}
      </Button>
    </form>
  );
}

function buildDefaultValues(definition: FormDefinition): Record<string, unknown> {
  const defaults: Record<string, unknown> = {};
  for (const section of definition.sections) {
    for (const field of section.fields) {
      if (field.type === "checkbox" || field.type === "switch") defaults[field.id] = false;
      else if (field.type === "number") defaults[field.id] = undefined;
      else if (field.type === "checkbox-group" || field.type === "tags") defaults[field.id] = [];
      else if (field.type === "date-range") defaults[field.id] = {};
      // Seeded with one empty row, matching forms-blocks.jsx's RepeatableGroup
      // ("at least one row visible" convention) — useFieldArray otherwise
      // starts empty and renders no row at all.
      else if (field.type === "repeatable-group") {
        defaults[field.id] = [
          Object.fromEntries(
            (field.subFields ?? []).map((sf) => [sf.id, sf.type === "checkbox" || sf.type === "switch" ? false : ""]),
          ),
        ];
      } else defaults[field.id] = "";
    }
  }
  return defaults;
}
