import * as React from "react";
import { useFieldArray, type Control, type FieldErrors, type UseFormRegister } from "react-hook-form";
import { Alert, RepeatableGroup } from "@dbp/ui";
import { FieldRenderer, type RenderableFieldDef } from "../components/field-renderer.js";
import type { FormFieldDef, FormSection, RepeatableSubField } from "../types.js";
import { evaluateVisibility } from "../logic/visibility.js";

export interface FieldSetProps {
  sections: FormSection[];
  register: UseFormRegister<Record<string, unknown>>;
  control: Control<Record<string, unknown>>;
  errors: FieldErrors<Record<string, unknown>>;
  values: Record<string, unknown>;
  disabled?: boolean | undefined;
}

/**
 * FieldSet — the embeddable field-composition primitive (`@dbp/form-builder/renderer`).
 *
 * Pure, prop-driven: renders `FormSection[]` against an already-created RHF
 * instance (`register`/`control`/`errors`). Owns no data-fetch, no submit
 * wiring — every consumer (record-drawer, lve-workspace, record-form,
 * multi-step-form, or `form-builder`'s own legacy path) supplies those.
 *
 * - A field whose `visibleWhen` evaluates false against `values` is excluded
 *   from the DOM entirely (not just visually hidden) — spec §2.2.
 * - A `derived` field renders read-only/disabled — it is computed, never
 *   user-edited — enforced here, not left to convention (spec §2.3).
 * - `type: "file"` renders a disabled placeholder with a "requires
 *   ps-storage" notice until P2 wires the live control (spec §2.5).
 */
export function FieldSet({ sections, register, control, errors, values, disabled }: FieldSetProps) {
  return (
    <>
      {sections.map((section) => (
        <div key={section.id} className="flex flex-col gap-4" data-testid={`form-section-${section.id}`}>
          {section.title.trim() !== "" && (
            <div className="flex flex-col gap-0.5">
              <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">{section.title}</h3>
              {section.description && (
                <p className="text-xs text-[var(--color-text-secondary)]">{section.description}</p>
              )}
            </div>
          )}
          {/*
            Single-column baseline (record-form spec §7 item 6, P1 UX baseline #1):
            a 12-col track where a "full" field always spans the whole row and
            only a "half" field opts into sitting two-up, next to another half
            field. `sm:` keeps half pairs stacked on narrow viewports instead of
            squeezing two short-pair fields into a cramped row.
          */}
          <div className="grid grid-cols-12 gap-4">
            {section.fields.map((field) => {
              // Hidden fields are excluded from the DOM entirely, not just visually hidden.
              if (!evaluateVisibility(field, values)) return null;

              const spanClass = field.span === "half" ? "col-span-12 sm:col-span-6" : "col-span-12";

              if (field.type === "file") {
                return (
                  <div key={field.id} className={spanClass} data-testid={`field-file-placeholder-${field.id}`}>
                    <Alert tone="info" title={field.label}>
                      File uploads require ps-storage (GAP-BRS-1) — not yet available.
                    </Alert>
                  </div>
                );
              }

              // Repeatable-group carries an array value + a `subFields` row shape —
              // outside what the flat RenderableFieldDef/FieldRenderer adapter can
              // express, so it's rendered here directly (same posture as `file` above).
              if (field.type === "repeatable-group") {
                return (
                  <div key={field.id} className={spanClass}>
                    <RepeatableGroupField field={field} register={register} control={control} disabled={disabled} />
                  </div>
                );
              }

              return (
                <div key={field.id} className={spanClass}>
                  <FieldRenderer
                    fieldDef={toLegacyFieldDef(field)}
                    registration={register(field.id, { valueAsNumber: field.type === "number" })}
                    control={control}
                    errorMessage={(errors[field.id]?.message as string) ?? undefined}
                    disabled={disabled || Boolean(field.derived)}
                  />
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </>
  );
}

// ─── Adapter — FormFieldDef → RenderableFieldDef shape for FieldRenderer ──────
// `components/field-renderer.tsx` renders `radio-cards`/`switch` with their
// real controls (@dbp/ui RadioGroup card variant / Switch) — no more falling
// back onto `select`/`checkbox` and losing the intended visual. Options carry
// their `description` through (needed for the RadioGroup card variant);
// `maxLength` passes through for the character-counter. `file` never reaches
// this adapter (handled above).

function toLegacyFieldDef(field: FormFieldDef): RenderableFieldDef {
  return {
    field: field.id,
    label: field.label,
    type:
      field.type === "file" || field.type === "repeatable-group"
        ? "text" /* unreachable — both intercepted above */
        : field.type,
    required: field.required,
    placeholder: field.placeholder,
    options: field.options,
    min: field.min,
    max: field.max,
    pattern: field.pattern,
    maxLength: field.maxLength,
  };
}

// ─── Repeatable-group row rendering ────────────────────────────────────────
// Array-of-`subFields` (line-items pattern, forms-blocks.jsx:104-120): each
// row's sub-fields are registered under the dotted path `${field.id}.${index}.${subField.id}`
// and rendered with the same `FieldRenderer` every other field type uses —
// only the row add/remove chrome is new (`@dbp/ui` `RepeatableGroup`).
// `field` is the row-scoped dotted path (unique per row) — the sub-field's own
// `id` would collide across rows (every row's "team" sub-field would render
// `id="team"` and `getByLabelText`/DOM ids would no longer be unique).
function toSubFieldRenderableDef(subField: RepeatableSubField, rowFieldPath: string): RenderableFieldDef {
  return {
    field: rowFieldPath,
    label: subField.label,
    type: subField.type,
    required: subField.required,
    placeholder: subField.placeholder,
    options: subField.options,
  };
}

function RepeatableGroupField({
  field,
  register,
  control,
  disabled,
}: {
  field: FormFieldDef;
  register: UseFormRegister<Record<string, unknown>>;
  control: Control<Record<string, unknown>>;
  disabled?: boolean | undefined;
}) {
  const arrayControl = control as unknown as Control<Record<string, Array<Record<string, unknown>>>>;
  const { fields: rows, append, remove } = useFieldArray({ control: arrayControl, name: field.id });
  const subFields = field.subFields ?? [];

  return (
    <RepeatableGroup
      items={rows}
      onAdd={() => append(Object.fromEntries(subFields.map((sf) => [sf.id, sf.type === "checkbox" || sf.type === "switch" ? false : ""])))}
      onRemove={(index) => remove(index)}
      addLabel={field.addLabel ?? "Add another"}
      renderItem={(_row, index) => (
        <div className="grid grid-cols-12 gap-4">
          {subFields.map((subField) => {
            const rowFieldPath = `${field.id}.${index}.${subField.id}`;
            return (
              <div key={subField.id} className="col-span-12">
                <FieldRenderer
                  fieldDef={toSubFieldRenderableDef(subField, rowFieldPath)}
                  registration={register(rowFieldPath, {
                    valueAsNumber: subField.type === "number",
                  })}
                  control={control}
                  disabled={disabled}
                />
              </div>
            );
          })}
        </div>
      )}
    />
  );
}
