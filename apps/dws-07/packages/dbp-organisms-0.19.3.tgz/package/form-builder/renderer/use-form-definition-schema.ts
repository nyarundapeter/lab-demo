import { useEffect, useMemo } from "react";
import type { UseFormSetValue } from "react-hook-form";
import { z } from "zod";
import { compileDynamicSchema, evaluateDerivedField } from "../logic/index.js";
import type { FormDefinition } from "../types.js";

/**
 * Compiles the visibility-aware Zod schema for a `FormDefinition` against the
 * current live values — re-evaluated whenever `values` changes so a field
 * hidden by `visibleWhen` stays excluded from the required set (spec §2.2).
 */
export function useFormDefinitionSchema(
  definition: FormDefinition,
  values: Record<string, unknown>,
): z.ZodTypeAny {
  // Stringify keeps the memo stable across renders that don't change field
  // values (RHF's `watch()` returns a fresh object reference every render).
  const key = JSON.stringify(values);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(() => compileDynamicSchema(definition, values), [definition, key]);
}

/**
 * Recomputes every `derived` field on each relevant value change and writes
 * the result into RHF via `setValue(id, result, { shouldValidate: false })` —
 * spec §2.3. Derived fields are rendered read-only by `FieldSet`; this hook
 * is what actually keeps their value current.
 */
export function useDerivedFieldSync(
  definition: FormDefinition,
  values: Record<string, unknown>,
  setValue: UseFormSetValue<Record<string, unknown>>,
): void {
  const key = JSON.stringify(values);
  useEffect(() => {
    for (const section of definition.sections) {
      for (const field of section.fields) {
        if (!field.derived) continue;
        const computed = evaluateDerivedField(field.derived, values);
        if (values[field.id] !== computed) {
          setValue(field.id, computed, { shouldValidate: false });
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [definition, key, setValue]);
}
