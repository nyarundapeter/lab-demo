# @dbp/organisms/mfa-enrol

**registryId:** `APP.F66` (placeholder — assigned during central registration)

TOTP enrollment (QR scan + manual key → verify → backup codes). See `FEATURE.md` — **not wired
to a real service**, PS.AUTH has no TOTP support yet.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`MfaEnrolConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — Storybook-only until PS.AUTH TOTP support exists.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/mfa-enrol` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
