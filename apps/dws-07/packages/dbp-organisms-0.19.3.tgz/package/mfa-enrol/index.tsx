import React from "react";
import { Shield, Copy, Check, ArrowRight, Download, FileText, AlertTriangle } from "lucide-react";
import { Alert, Button, Card, CodeInput } from "@dbp/ui";
import { MfaEnrolConfig, type MfaEnrolConfigInput } from "./types.js";
import { verifyTotpCode } from "./mock-totp-client.js";

/**
 * Two-factor (TOTP) enrollment — QR scan (+ manual-key fallback) → verify
 * code → save backup codes. Port of `identity-mfa.jsx`'s `MfaEnrol`
 * (backup-code generation/display/download is step 3 of this same flow in
 * the reference, not a separate component — built here rather than split
 * into an artificial second package).
 *
 * **Not wired to a real service.** `packages/stack/platform-services/auth`
 * has zero TOTP/MFA/backup-code code (confirmed by grep) — the verify step
 * below calls a typed mock client (`mock-totp-client.ts`), not the real
 * PS.AUTH. Storybook-only until that Layer-06 capability lands. See
 * `wave3-build-plan.md`'s "Blocked-row build policy" (Amendment A).
 */
export default function MfaEnrol(config: MfaEnrolConfigInput) {
  const parsed = MfaEnrolConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="MfaEnrol — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <MfaEnrolInner config={parsed.data} />;
}

function MfaEnrolInner({ config }: { config: MfaEnrolConfig }) {
  const [step, setStep] = React.useState<0 | 1 | 2>(0);
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState(false);
  const [saved, setSaved] = React.useState(false);
  const [copied, setCopied] = React.useState(false);

  async function verify(code: string) {
    setBusy(true);
    const result = await verifyTotpCode(code);
    setBusy(false);
    if (result.ok) {
      setErr(false);
      setStep(2);
    } else {
      setErr(true);
    }
  }

  function copyKey() {
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <Card className="w-full max-w-[440px] overflow-hidden shadow-none">
      <div className="flex items-center gap-2.5 border-b border-[var(--color-border-subtle)] px-5 py-4">
        <span className="flex h-[30px] w-[30px] items-center justify-center rounded-[var(--radius-button)] bg-[var(--color-primary-surface)]">
          <Shield size={16} className="text-primary" />
        </span>
        <div className="text-base font-semibold">Set up two-factor authentication</div>
        <div className="flex-1" />
        <div className="flex gap-1" aria-hidden="true">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="h-1.5 w-1.5 rounded-full"
              style={{ background: i === step ? "var(--color-primary)" : "var(--color-border-default)" }}
            />
          ))}
        </div>
      </div>

      <div className="p-5">
        {step === 0 && (
          <div>
            <p className="mb-5 text-sm leading-relaxed text-[var(--color-text-muted)]">
              Scan this QR code with an authenticator app like 1Password, Authy or Google Authenticator.
            </p>
            <div className="flex items-center gap-5">
              <QrPlaceholder />
              <div className="flex-1">
                <div className="mb-1.5 text-xs font-medium">Can&apos;t scan? Enter this code:</div>
                <div className="mb-2 break-all rounded-[var(--radius-input)] border border-[var(--color-border-default)] bg-[var(--color-surface)] px-3 py-2.5 font-mono text-sm tracking-[0.06em]">
                  {config.manualKey}
                </div>
                <Button type="button" variant="outline" size="sm" className="w-full" onClick={copyKey}>
                  {copied ? <Check size={13} /> : <Copy size={13} />}
                  {copied ? "Copied" : "Copy setup key"}
                </Button>
              </div>
            </div>
            <Button type="button" className="mt-5 w-full" onClick={() => setStep(1)}>
              Continue
              <ArrowRight size={15} />
            </Button>
          </div>
        )}

        {step === 1 && (
          <div>
            <p className="mb-5 text-sm leading-relaxed text-[var(--color-text-muted)]">
              Enter the 6-digit code from your authenticator app to confirm it&apos;s working.
            </p>
            <div className="mb-3 flex justify-center">
              <CodeInput autoFocus error={err} disabled={busy} onComplete={verify} />
            </div>
            {err && (
              <div className="mb-3 flex items-center justify-center gap-1.5 text-xs font-medium text-danger">
                <AlertTriangle size={12} />
                That code didn&apos;t match. Try again.
              </div>
            )}
            <div className="flex gap-2">
              <Button type="button" variant="outline" className="flex-1" onClick={() => setStep(0)}>
                Back
              </Button>
              <Button type="button" className="flex-[2]" disabled={busy} onClick={() => verify("123456")}>
                {busy ? "Verifying…" : "Verify & continue"}
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <Alert tone="success" title="Two-factor is on">
              Save these backup codes somewhere safe. Each can be used once if you lose access to your
              authenticator.
            </Alert>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {config.backupCodes.map((code, i) => (
                <div
                  key={code}
                  className="flex items-center gap-2 rounded-[var(--radius-input)] border border-[var(--color-border-default)] bg-[var(--color-surface)] px-3 py-2 font-mono text-sm"
                >
                  <span className="text-[var(--color-text-muted)]">{String(i + 1).padStart(2, "0")}</span>
                  {code}
                </div>
              ))}
            </div>
            <div className="mt-3.5 flex gap-2">
              <Button type="button" variant="outline" size="sm" className="flex-1">
                <Download size={13} />
                Download
              </Button>
              <Button type="button" variant="outline" size="sm" className="flex-1">
                <FileText size={13} />
                Print
              </Button>
              <Button type="button" variant="outline" size="sm" className="flex-1" onClick={copyKey}>
                {copied ? <Check size={13} /> : <Copy size={13} />}
                {copied ? "Copied" : "Copy"}
              </Button>
            </div>
            <label className="my-5 flex cursor-pointer items-start gap-2 text-xs">
              <input
                type="checkbox"
                checked={saved}
                onChange={() => setSaved((s) => !s)}
                className="mt-0.5"
              />
              I&apos;ve saved my backup codes in a safe place
            </label>
            <Button type="button" className="w-full" disabled={!saved} onClick={() => setStep(0)}>
              Finish setup
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}

/**
 * Visual QR-code placeholder. PS.AUTH has no `otpauth://` provisioning-URI
 * endpoint to encode (same TOTP gap as `verifyTotpCode` above) — this is an
 * honest "not wired" placeholder, not a fake scannable code.
 */
function QrPlaceholder() {
  return (
    <div
      className="flex h-[132px] w-[132px] shrink-0 items-center justify-center rounded-[var(--radius-input)] border border-[var(--color-border-default)] bg-[var(--color-surface)] text-center text-xs leading-tight text-[var(--color-text-muted)]"
      role="img"
      aria-label="QR code placeholder — not wired to a real TOTP provisioning URI"
    >
      QR code
      <br />
      (not wired)
    </div>
  );
}
