import { z } from "zod";

export const MfaEnrolConfig = z.object({
  /** Manual setup key shown as a fallback to scanning the QR. */
  manualKey: z.string().min(1),
  /** One-time backup codes generated for this enrollment. */
  backupCodes: z.array(z.string().min(1)).min(1),
});

export type MfaEnrolConfig = z.infer<typeof MfaEnrolConfig>;
export type MfaEnrolConfigInput = z.input<typeof MfaEnrolConfig>;
