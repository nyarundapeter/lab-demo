import React from "react";
import { Rocket, CalendarClock, Save, X } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  Button,
  Input,
  Alert,
  VersionCompare,
  ChangeImpactPanel,
} from "@dbp/ui";
import { PublishReviewConfig, type PublishReviewConfigInput } from "./types.js";

export interface PublishReviewProps extends PublishReviewConfigInput {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPublish?: () => void;
  onSaveDraft?: () => void;
  onSchedule?: () => void;
}

/**
 * Draft→review→publish gate: version diff + blast-radius impact panel +
 * type-to-confirm + Schedule/Save draft/Publish actions. Port of
 * admin-detail.jsx's `PublishReview` — also duplicated near-verbatim in
 * admin-workflow-builder.jsx as `WfPublishReview` (same composition, two
 * names). Promoted once here per the tier audit's §F finding; both
 * `config-detail` (APP.F37) and `workflow-builder` (APP.F39) should compose
 * this instead of reimplementing it.
 */
export default function PublishReview(props: PublishReviewProps) {
  const { open, onOpenChange, onPublish, onSaveDraft, onSchedule, ...config } = props;
  const parsed = PublishReviewConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="right" size="wide">
          <SheetHeader>
            <SheetTitle>PublishReview — invalid config</SheetTitle>
          </SheetHeader>
          <Alert tone="danger" title="PublishReview — invalid config">
            <ul className="mt-1 list-disc pl-5">
              {parsed.error.issues.map((issue, i) => (
                <li key={i}>
                  {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
                  {issue.message}
                </li>
              ))}
            </ul>
          </Alert>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <PublishReviewInner
      {...parsed.data}
      open={open}
      onOpenChange={onOpenChange}
      {...(onPublish !== undefined && { onPublish })}
      {...(onSaveDraft !== undefined && { onSaveDraft })}
      {...(onSchedule !== undefined && { onSchedule })}
    />
  );
}

function PublishReviewInner(
  config: PublishReviewConfig & {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onPublish?: () => void;
    onSaveDraft?: () => void;
    onSchedule?: () => void;
  }
) {
  const [confirmText, setConfirmText] = React.useState("");
  const confirmed = !config.requireTypeConfirm || confirmText === config.itemName;
  const publishDisabled = Boolean(config.disablePublishReason) || !confirmed;

  return (
    <Sheet open={config.open} onOpenChange={config.onOpenChange}>
      <SheetContent side="right" size="wide">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Rocket size={16} className="text-[var(--color-primary)]" aria-hidden="true" />
            Publish review — {config.itemName}
          </SheetTitle>
          <SheetDescription>
            Review changes and impact before this goes live in <strong>{config.environment}</strong>.
          </SheetDescription>
        </SheetHeader>

        <div className="flex flex-col gap-4 overflow-y-auto">
          <h4 className="text-xs font-semibold uppercase tracking-wide text-text-muted">
            Changes from current version
          </h4>
          <VersionCompare
            versions={config.versions}
            diff={config.diff}
            {...(config.defaultLeft !== undefined && { defaultLeft: config.defaultLeft })}
            {...(config.defaultRight !== undefined && { defaultRight: config.defaultRight })}
          />
          <ChangeImpactPanel items={config.impactItems} riskLevel={config.riskLevel} />

          {config.requireTypeConfirm && (
            <Alert tone="warning" title="Stronger confirmation required">
              Type <strong>{config.itemName}</strong> to confirm you understand the downstream impact.
              <Input
                className="mt-2 h-8 text-xs"
                placeholder={config.itemName}
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                aria-label="Type the configuration name to confirm"
              />
            </Alert>
          )}
        </div>

        <div className="mt-auto flex items-center gap-2 border-t border-border-default pt-4">
          <label className="mr-auto flex items-center gap-1.5 text-xs text-text-muted">
            <CalendarClock size={14} aria-hidden="true" />
            Schedule for later
          </label>
          <Button type="button" variant="outline" onClick={() => config.onOpenChange(false)}>
            <X size={14} />
            Cancel
          </Button>
          <Button type="button" variant="outline" onClick={config.onSaveDraft}>
            <Save size={14} />
            Save draft
          </Button>
          {config.onSchedule && (
            <Button type="button" variant="outline" onClick={config.onSchedule}>
              <CalendarClock size={14} />
              Schedule
            </Button>
          )}
          <Button
            type="button"
            onClick={config.onPublish}
            disabled={publishDisabled}
            title={config.disablePublishReason}
          >
            <Rocket size={14} />
            {config.disablePublishReason ? `Publish (${config.disablePublishReason})` : `Publish to ${config.environment}`}
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
