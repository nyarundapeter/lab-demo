# @dbp/organisms/publish-review

**registryId:** `APP.F39`

Draft→review→publish gate: version diff + blast-radius impact panel + type-to-confirm +
Schedule/Save draft/Publish actions. The single promoted pattern behind both
`admin-detail.jsx`'s `PublishReview` and `admin-workflow-builder.jsx`'s `WfPublishReview` — see
`FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`PublishReviewConfig` — Zod schema exported from `types.ts` (source of truth). Component props
also take `open`/`onOpenChange` (controlled) and optional `onPublish`/`onSaveDraft`/
`onSchedule` callbacks (not part of the Zod config — arbitrary functions, not serializable
data).

## Consumed by
`@dbp/organisms/workflow-builder` (APP.F40). Not yet wired into `config-detail` (APP.F37) —
see FEATURE.md.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/publish-review` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
