import { z } from "zod";

const DiffLineType = z.enum(["context", "add", "remove"]);
const DiffLine = z.object({ type: DiffLineType, text: z.string().min(1) });
const CompareVersionOption = z.object({ value: z.string().min(1), author: z.string().min(1) });

const ImpactItem = z.object({
  type: z.string().min(1),
  count: z.number().int().nonnegative(),
  items: z.array(z.string()),
  to: z.string().optional(),
  conflict: z.boolean().optional(),
});

export const PublishReviewConfig = z.object({
  /** Name of the item being published, e.g. "Tier 1 routing" or "Leave approval". */
  itemName: z.string().min(1),
  environment: z.string().default("Production"),
  versions: z.array(CompareVersionOption).min(1),
  defaultLeft: z.string().optional(),
  defaultRight: z.string().optional(),
  diff: z.array(DiffLine),
  impactItems: z.array(ImpactItem),
  riskLevel: z.enum(["low", "medium", "high"]).default("medium"),
  /** Type-to-confirm gate before Publish is enabled. @default true */
  requireTypeConfirm: z.boolean().default(true),
  /** Disables the Publish button (e.g. unresolved validation errors) with an explanatory reason shown on the button. */
  disablePublishReason: z.string().optional(),
});

export type PublishReviewConfig = z.infer<typeof PublishReviewConfig>;
export type PublishReviewConfigInput = z.input<typeof PublishReviewConfig>;
