import React from "react";
import { ChevronDown, ChevronRight, Tag } from "lucide-react";
import { cn, Button } from "@dbp/ui";
import type { TaxonomyNode } from "../types.js";

interface Props {
  node: TaxonomyNode;
  depth: number;
  expanded: Set<string>;
  onToggle: (id: string) => void;
  selectedId: string | undefined;
  onSelect: (node: TaxonomyNode) => void;
}

/**
 * Recursive taxonomy-tree-node renderer — port of admin-specimens3.jsx's
 * `TaxonomyPage.Node`. Kept internal to this organism (not promoted to
 * `@dbp/ui`) — see FEATURE.md for the reasoning. Same call as
 * `rule-builder`'s `ConditionGroupEditor` staying local.
 */
export function TaxonomyTreeNode({ node, depth, expanded, onToggle, selectedId, onSelect }: Props) {
  const hasChildren = !!node.children?.length;
  const isExpanded = expanded.has(node.id);
  const isSelected = selectedId === node.id;

  return (
    <>
      <div
        role="treeitem"
        aria-selected={isSelected}
        aria-expanded={hasChildren ? isExpanded : undefined}
        onClick={() => onSelect(node)}
        style={{ paddingLeft: 8 + depth * 18 }}
        className={cn(
          "flex cursor-pointer items-center gap-1.5 rounded-[4px] py-1.5 pr-2 text-sm",
          isSelected ? "bg-[var(--color-primary-surface)] text-primary" : "hover:bg-[var(--color-surface)]"
        )}
      >
        {hasChildren ? (
          <Button
            type="button"
            variant="ghost"
            aria-label={isExpanded ? `Collapse ${node.label}` : `Expand ${node.label}`}
            onClick={(e) => {
              e.stopPropagation();
              onToggle(node.id);
            }}
            className="h-[13px] w-[13px] shrink-0 p-0 text-text-muted"
          >
            {isExpanded ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
          </Button>
        ) : (
          <span className="w-[13px] shrink-0" aria-hidden="true" />
        )}
        <Tag
          size={13}
          className={cn("shrink-0", node.status === "deprecated" ? "text-[var(--color-warning)]" : "text-text-muted")}
          aria-hidden="true"
        />
        <span className={cn("flex-1 truncate", node.status === "deprecated" && "line-through")}>{node.label}</span>
        <span className="font-mono text-xs text-text-muted">{node.count.toLocaleString()}</span>
      </div>
      {hasChildren &&
        isExpanded &&
        node.children!.map((child) => (
          <TaxonomyTreeNode
            key={child.id}
            node={child}
            depth={depth + 1}
            expanded={expanded}
            onToggle={onToggle}
            selectedId={selectedId}
            onSelect={onSelect}
          />
        ))}
    </>
  );
}
