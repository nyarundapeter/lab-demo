import { z } from "zod";

/**
 * Recursive taxonomy node (a category can have child categories) — `z.lazy`
 * is required since the schema references itself via `children`. No
 * `.default()` on any field here (unlike most optional fields in this
 * codebase) — a `z.lazy` recursive schema's inferred input/output types
 * must match exactly, or `TaxonomyTreeConfigInput`/`TaxonomyTreeConfig`
 * diverge. Same idiom as `rule-builder`'s `ConditionGroup`.
 */
export const TaxonomyNode: z.ZodType<TaxonomyNodeShape> = z.lazy(() =>
  z.object({
    id: z.string().min(1),
    label: z.string().min(1),
    code: z.string().min(1),
    count: z.number(),
    status: z.enum(["active", "deprecated"]),
    /** Alternate terms that map to this category. Undefined/empty renders a hint, not an error. */
    synonyms: z.array(z.string()).optional(),
    children: z.array(TaxonomyNode).optional(),
  })
);
interface TaxonomyNodeShape {
  id: string;
  label: string;
  code: string;
  count: number;
  status: "active" | "deprecated";
  /** `| undefined` spelled out (not just `?`) — required for `exactOptionalPropertyTypes`
   * to accept `z.array(...).optional()`'s inferred `T[] | undefined` output type. */
  synonyms?: string[] | undefined;
  children?: TaxonomyNodeShape[] | undefined;
}
export type TaxonomyNode = TaxonomyNodeShape;

export const TaxonomyTreeConfig = z.object({
  /** Top-level taxonomy categories; each may nest further categories via `children`. */
  nodes: z.array(TaxonomyNode).min(1),
  /**
   * Flat list of "Parent → Child" replacement-candidate labels for the
   * deprecated-term "Replace with…" dropdown. Kept as a simple flat list
   * (rather than re-deriving paths from the tree at render time) so the
   * caller controls exactly which categories are valid merge targets —
   * e.g. a deprecated leaf shouldn't offer itself or its own descendants.
   */
  replacementOptions: z.array(z.string()).default([]),
});

export type TaxonomyTreeConfig = z.infer<typeof TaxonomyTreeConfig>;
export type TaxonomyTreeConfigInput = z.input<typeof TaxonomyTreeConfig>;
