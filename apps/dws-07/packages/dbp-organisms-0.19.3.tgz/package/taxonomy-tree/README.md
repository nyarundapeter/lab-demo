# @dbp/organisms/taxonomy-tree

**registryId:** `APP.F49`

Hierarchical service-catalogue taxonomy browser: expandable category tree + read-only detail
panel + deprecated-term merge warning. Recursive tree-node renderer kept internal (not a shared
`@dbp/ui` primitive) — see `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`TaxonomyTreeConfig` — Zod schema exported from `types.ts` (source of truth). Recursive via
`z.lazy` (see `TaxonomyNode`).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/service-catalog/taxonomy` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/taxonomy-tree` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
