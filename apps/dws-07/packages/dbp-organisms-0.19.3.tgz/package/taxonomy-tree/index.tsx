import React from "react";
import { Upload, Plus, Check } from "lucide-react";
import { Alert, Badge, Button, InfoCard } from "@dbp/ui";
import { TaxonomyTreeConfig, type TaxonomyTreeConfigInput, type TaxonomyNode } from "./types.js";
import { TaxonomyTreeNode } from "./components/taxonomy-tree-node.js";

/**
 * Hierarchical service-catalogue taxonomy browser: expandable tree on the
 * left, read-only detail panel + deprecated-term merge warning on the
 * right. Port of admin-specimens3.jsx's `TaxonomyPage`. Owns `expanded`
 * (Set of node ids) and `selected` (currently-selected node) as local
 * state — no external state manager, no drag-to-reorder (the reference's
 * "drag to reorder" is aspirational copy, never implemented there either).
 * UI-only, prop-driven — no `PS.TAXONOMY`-class platform service exists.
 */
export default function TaxonomyTree(config: TaxonomyTreeConfigInput) {
  const parsed = TaxonomyTreeConfig.safeParse(config);

  const [selected, setSelected] = React.useState<TaxonomyNode | undefined>(
    parsed.success ? parsed.data.nodes[0] : undefined
  );
  const [expanded, setExpanded] = React.useState<Set<string>>(() =>
    parsed.success
      ? new Set(parsed.data.nodes.filter((n) => n.children?.length).map((n) => n.id))
      : new Set()
  );

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="TaxonomyTree — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const c = parsed.data;

  const toggle = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Service catalogue taxonomy</h2>
          <p className="mt-1 text-xs text-text-muted">
            Hierarchical categories with codes, synonyms, and usage counts. Drag to reorder; merge or deprecate
            terms safely.
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <Button type="button" variant="outline" size="sm">
            <Upload size={13} />
            Import
          </Button>
          <Button type="button" size="sm">
            <Plus size={13} />
            Add term
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[340px_1fr]">
        <div role="tree" aria-label="Taxonomy categories" className="rounded-card border border-border-default bg-[var(--color-surface-content)] p-2">
          {c.nodes.map((node) => (
            <TaxonomyTreeNode
              key={node.id}
              node={node}
              depth={0}
              expanded={expanded}
              onToggle={toggle}
              selectedId={selected?.id}
              onSelect={setSelected}
            />
          ))}
        </div>

        {selected && (
          <div className="flex flex-col gap-3">
            <h3 className="text-sm font-semibold">{selected.label}</h3>

            <InfoCard
              title="Term details"
              rows={[
                { label: "Label", value: selected.label },
                { label: "Code", value: <span className="font-mono text-xs">{selected.code}</span> },
                {
                  label: "Status",
                  value: (
                    <Badge tone={selected.status === "deprecated" ? "warning" : "success"} size="sm">
                      {selected.status === "deprecated" ? "Deprecated" : "Active"}
                    </Badge>
                  ),
                },
                {
                  label: "Synonyms",
                  value: selected.synonyms?.length ? (
                    selected.synonyms.join(", ")
                  ) : (
                    <span className="italic text-text-muted">e.g. computer, PC, workstation</span>
                  ),
                },
                { label: "Usage", value: `${selected.count.toLocaleString()} records currently categorised` },
              ]}
            />

            {selected.status === "deprecated" && (
              <Alert tone="warning" title="Deprecated term — replacement required">
                <p>
                  This term is deprecated. Choose a replacement so its {selected.count.toLocaleString()} records
                  can be re-categorised.
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <select
                    aria-label="Replace with"
                    defaultValue=""
                    className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm"
                  >
                    <option value="" disabled>
                      Replace with…
                    </option>
                    {c.replacementOptions.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                  <Button type="button" size="sm">
                    <Check size={13} />
                    Merge &amp; replace
                  </Button>
                </div>
              </Alert>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
