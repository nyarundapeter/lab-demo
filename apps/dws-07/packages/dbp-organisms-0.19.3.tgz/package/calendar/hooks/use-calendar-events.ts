import { useEntityList } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { CalendarConfig } from "../types.js";
import { isInRange, toDateKey } from "../components/date-utils.js";

export interface CalendarEvent {
  id: string;
  title: string;
  startKey: string;
  endKey: string;
  color: string | undefined;
  raw: EntityRecord<EntityData>;
}

interface UseCalendarEventsResult {
  eventsByDay: Map<string, CalendarEvent[]>;
  isLoading: boolean;
  error: Error | null;
}

const PAGE_SIZE = 200;

/**
 * Fetches entities via PS.DATA and bins them by start-date day key.
 *
 * PS.DATA limitation: filters support equality only, not date ranges.
 * We fetch a generous page (200 records) with any static config filters
 * and then filter client-side to the visible range. This is documented
 * in FEATURE.md §Known Limitations as a PS.DATA minor needed item.
 */
export function useCalendarEvents(
  config: CalendarConfig,
  startKey: string,
  endKey: string,
): UseCalendarEventsResult {
  const { rows, isLoading, error } = useEntityList(config.entityType, {
    ...(config.filters !== undefined && { filters: config.filters }),
    page: 1,
    pageSize: PAGE_SIZE,
  });

  const eventsByDay = new Map<string, CalendarEvent[]>();

  if (!isLoading && !error) {
    for (const record of rows) {
      const data = record.data as Record<string, unknown>;
      const rawStart = data[config.dateField];
      if (!rawStart) continue;

      const startDate = new Date(String(rawStart));
      if (isNaN(startDate.getTime())) continue;

      const startKey_ = toDateKey(startDate);

      // Determine end key (defaults to start when no endDateField or invalid)
      let endKey_: string = startKey_;
      if (config.endDateField) {
        const rawEnd = data[config.endDateField];
        if (rawEnd) {
          const endDate = new Date(String(rawEnd));
          if (!isNaN(endDate.getTime())) {
            endKey_ = toDateKey(endDate);
          }
        }
      }

      // Skip events entirely outside the visible range
      if (endKey_ < startKey || startKey_ > endKey) continue;

      const title = String(data[config.titleField] ?? record.id);
      const color = config.colorField ? String(data[config.colorField] ?? "") || undefined : undefined;

      const event: CalendarEvent = {
        id: record.id,
        title,
        startKey: startKey_,
        endKey: endKey_,
        color,
        raw: record,
      };

      // Place event on every day it spans within the range
      const spanStart = startKey_ < startKey ? startKey : startKey_;
      const spanEnd = endKey_ > endKey ? endKey : endKey_;

      // Walk days from spanStart to spanEnd (max 42 days for a month grid)
      const startDate2 = new Date(
        Number(spanStart.slice(0, 4)),
        Number(spanStart.slice(5, 7)) - 1,
        Number(spanStart.slice(8, 10)),
      );
      const endDate2 = new Date(
        Number(spanEnd.slice(0, 4)),
        Number(spanEnd.slice(5, 7)) - 1,
        Number(spanEnd.slice(8, 10)),
      );

      let cur = new Date(startDate2);
      let safety = 0;
      while (cur <= endDate2 && safety < 42) {
        const dayKey = toDateKey(cur);
        if (isInRange(dayKey, startKey, endKey)) {
          if (!eventsByDay.has(dayKey)) eventsByDay.set(dayKey, []);
          eventsByDay.get(dayKey)!.push(event);
        }
        cur = new Date(cur.getFullYear(), cur.getMonth(), cur.getDate() + 1);
        safety++;
      }
    }
  }

  return { eventsByDay, isLoading, error: error as Error | null };
}
