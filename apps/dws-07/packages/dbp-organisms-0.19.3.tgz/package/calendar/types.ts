import { z } from "zod";

/**
 * CalendarConfig — the single typed contract for APP.F05.
 *
 * Data contract only (no function fields — Zod schemas are data-only).
 *
 * LIMITATION: PS.DATA filters support field-equality only (no date-range
 * query). The calendar fetches a generous page of entities and filters
 * client-side to the visible range. A PS.DATA minor for range-filter support
 * (e.g. filter.startDate[gte]=X&filter.startDate[lte]=Y) would remove this
 * client-side fan-out. See FEATURE.md §Known Limitations.
 *
 * initialDate is an optional ISO date string (YYYY-MM-DD) used to pin the
 * starting cursor. Intended for deterministic testing/demo only — leave unset
 * in production so the calendar opens to today.
 */
export const CalendarConfig = z.object({
  /** The PS.DATA entity type to query (e.g. "meeting", "task", "appointment"). */
  entityType: z.string().min(1),

  /**
   * Field name in entity.data that holds the event start date/datetime.
   * Must be parseable by new Date(value). ISO 8601 recommended.
   */
  dateField: z.string().min(1),

  /** Field name in entity.data used as the event chip label. */
  titleField: z.string().min(1),

  /**
   * Optional field name for event end date/datetime.
   * When present, events with endDate > startDate span visually
   * across cells in month view (multi-day event). In week view
   * the event appears on the startDate column only (future minor).
   */
  endDateField: z.string().optional(),

  /**
   * Optional field name whose value maps to a design-token palette key
   * (e.g. "blue", "amber", "green"). Never a hex value.
   */
  colorField: z.string().optional(),

  /** Calendar view to render. Defaults to "month". */
  view: z.enum(["month", "week"]).default("month"),

  /**
   * Static equality filters forwarded to PS.DATA on every fetch.
   * E.g. { "status": "active" } restricts to active events only.
   */
  filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),

  /**
   * Day the week starts on: 0 = Sunday, 1 = Monday. Defaults to 1.
   * Affects both month grid leading-day calculation and week view column order.
   */
  weekStartsOn: z.union([z.literal(0), z.literal(1)]).default(1),

  /**
   * ISO date string (YYYY-MM-DD) pinning the initial cursor date.
   * Test/demo affordance — omit in production.
   */
  initialDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

export type CalendarConfig = z.infer<typeof CalendarConfig>;
