/**
 * Pure date-math helpers using only native Date + Intl.
 *
 * Key design decisions:
 * - All day keys use YYYY-MM-DD strings derived from local-time parts
 *   (getFullYear / getMonth / getDate) — this is intentionally DST-agnostic
 *   because we care about the calendar day in the user's locale, not a UTC
 *   instant. Storing/comparing raw timestamps would cause day-boundary drift
 *   during DST transitions.
 * - We never mutate Date objects; all helpers return new values.
 */

/** Return "YYYY-MM-DD" for any Date using local time. */
export function toDateKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Parse "YYYY-MM-DD" to a local-midnight Date. Safe for year/month boundaries. */
export function fromDateKey(key: string): Date {
  const [y, m, d] = key.split("-").map(Number) as [number, number, number];
  return new Date(y, m - 1, d);
}

/** Add N calendar months (handles year rollover correctly). */
export function addMonths(d: Date, n: number): Date {
  const result = new Date(d.getFullYear(), d.getMonth() + n, 1);
  return result;
}

/** Add N calendar weeks. */
export function addWeeks(d: Date, n: number): Date {
  const result = new Date(d);
  result.setDate(result.getDate() + n * 7);
  return result;
}

/** First day of the month containing d. */
export function startOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

/** Last day of the month containing d. */
export function endOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth() + 1, 0);
}

/**
 * Build the grid cells for a month view.
 *
 * The grid always has complete rows of 7. Leading/trailing days from adjacent
 * months are included so every row is full (standard calendar convention).
 *
 * weekStartsOn: 0 = Sunday, 1 = Monday.
 *
 * Returns an array of YYYY-MM-DD strings in calendar order.
 */
export function buildMonthGrid(year: number, month: number, weekStartsOn: 0 | 1): string[] {
  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);

  // How many leading blank cells before the 1st of the month?
  const rawDow = first.getDay(); // 0=Sun…6=Sat
  const leadingBlanks = (rawDow - weekStartsOn + 7) % 7;

  const gridStart = new Date(year, month, 1 - leadingBlanks);
  const totalDays = leadingBlanks + last.getDate();
  // Round up to nearest multiple of 7
  const cellCount = Math.ceil(totalDays / 7) * 7;

  const cells: string[] = [];
  for (let i = 0; i < cellCount; i++) {
    const d = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + i);
    cells.push(toDateKey(d));
  }
  return cells;
}

/**
 * Build the 7 day keys for a week view starting from the week that contains
 * `cursor`, aligned to weekStartsOn.
 */
export function buildWeekGrid(cursor: Date, weekStartsOn: 0 | 1): string[] {
  const rawDow = cursor.getDay();
  const offset = (rawDow - weekStartsOn + 7) % 7;
  const weekStart = new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() - offset);
  const days: string[] = [];
  for (let i = 0; i < 7; i++) {
    days.push(
      toDateKey(new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate() + i)),
    );
  }
  return days;
}

/**
 * Returns the start and end date keys for the visible range, expanded by one
 * month on each side to allow client-side range filtering against a generous
 * PS.DATA page fetch.
 *
 * The PS.DATA limitation (equality filters only) means we fetch broadly and
 * filter client-side — having a ±1-month buffer keeps visible events fully
 * covered while preventing a unbounded query.
 */
export function visibleRangePadded(
  view: "month" | "week",
  cursor: Date,
  weekStartsOn: 0 | 1,
): { start: string; end: string } {
  if (view === "month") {
    const som = startOfMonth(cursor);
    const eom = endOfMonth(cursor);
    // Expand by 7 days on each side to cover leading/trailing grid cells
    const s = new Date(som.getFullYear(), som.getMonth(), som.getDate() - 7);
    const e = new Date(eom.getFullYear(), eom.getMonth(), eom.getDate() + 7);
    return { start: toDateKey(s), end: toDateKey(e) };
  }
  // week view
  const days = buildWeekGrid(cursor, weekStartsOn);
  return { start: days[0]!, end: days[6]! };
}

/** Determine if a date key falls within [startKey, endKey] inclusive. */
export function isInRange(key: string, startKey: string, endKey: string): boolean {
  return key >= startKey && key <= endKey;
}

/**
 * Format a month header label using Intl (locale-aware, no external dep).
 * e.g. "June 2026"
 */
export function formatMonthLabel(year: number, month: number): string {
  return new Intl.DateTimeFormat(undefined, { month: "long", year: "numeric" }).format(
    new Date(year, month, 1),
  );
}

/**
 * Short weekday labels (Mon, Tue…) respecting weekStartsOn.
 */
export function weekdayLabels(weekStartsOn: 0 | 1): string[] {
  const labels: string[] = [];
  for (let i = 0; i < 7; i++) {
    const day = (weekStartsOn + i) % 7;
    labels.push(
      new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(
        // 2026-01-04 is a Sunday; day 0 = Sun, 1 = Mon, ...
        new Date(2026, 0, 4 + day),
      ),
    );
  }
  return labels;
}
