import * as React from "react";
import { Button, SectionLabel } from "@dbp/ui";
import type { CalendarEvent } from "../hooks/use-calendar-events.js";
import { EventChip } from "./event-chip.js";

interface WeekGridProps {
  days: string[];
  weekdayLabels: string[];
  eventsByDay: Map<string, CalendarEvent[]>;
  focusedKey: string;
  onDayFocus: (key: string) => void;
  todayKey: string;
}

export function WeekGrid({
  days,
  weekdayLabels,
  eventsByDay,
  focusedKey,
  onDayFocus,
  todayKey,
}: WeekGridProps) {
  const cellRefs = React.useRef<Map<string, HTMLButtonElement>>(new Map());

  React.useEffect(() => {
    const el = cellRefs.current.get(focusedKey);
    if (el && document.activeElement !== el) el.focus();
  }, [focusedKey]);

  function handleKeyDown(e: React.KeyboardEvent, key: string) {
    const idx = days.indexOf(key);
    if (idx === -1) return;
    let next = -1;
    if (e.key === "ArrowRight") next = idx + 1;
    else if (e.key === "ArrowLeft") next = idx - 1;
    else return;

    e.preventDefault();
    const nextKey = days[next];
    if (nextKey !== undefined) onDayFocus(nextKey);
  }

  return (
    <div
      role="grid"
      aria-label="Week calendar grid"
      data-testid="week-grid"
      className="w-full"
    >
      {/* Header */}
      <div
        role="row"
        className="grid gap-px border-b border-[var(--color-border-subtle)]"
        style={{ gridTemplateColumns: "repeat(7, minmax(0, 1fr))" }}
      >
        {days.map((key, i) => {
          const kd = Number(key.slice(8, 10));
          const isToday = key === todayKey;
          const isFocused = key === focusedKey;
          const events = eventsByDay.get(key) ?? [];

          return (
            <div
              key={key}
              role="columnheader"
              className="flex flex-col items-center py-2"
            >
              <SectionLabel size="2xs" className="tracking-[0.12em] font-mono">
                {weekdayLabels[i]}
              </SectionLabel>
              <Button
                variant="ghost"
                ref={(el) => {
                  if (el) cellRefs.current.set(key, el);
                  else cellRefs.current.delete(key);
                }}
                tabIndex={isFocused ? 0 : -1}
                aria-label={`${key}${isToday ? ", today" : ""}${events.length > 0 ? `, ${events.length} event${events.length !== 1 ? "s" : ""}` : ""}`}
                className={[
                  "relative mt-1 h-7 w-7 rounded-full p-0 text-sm font-medium focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--color-secondary)]",
                  isToday
                    ? "bg-[var(--color-navy-50)] font-bold text-[var(--color-primary)]"
                    : "text-[var(--color-text-secondary)]",
                ].join(" ")}
                onClick={() => onDayFocus(key)}
                onKeyDown={(e) => handleKeyDown(e, key)}
                data-testid={`week-day-btn-${key}`}
              >
                {kd}
                {isToday && (
                  <span
                    aria-hidden="true"
                    className="absolute -right-0.5 -top-0.5 h-1.5 w-1.5 rounded-full bg-[var(--color-secondary)]"
                  />
                )}
              </Button>
            </div>
          );
        })}
      </div>

      {/* Event cells */}
      <div
        role="row"
        className="grid gap-px"
        style={{ gridTemplateColumns: "repeat(7, minmax(0, 1fr))" }}
      >
        {days.map((key) => {
          const events = eventsByDay.get(key) ?? [];
          const isToday = key === todayKey;
          return (
            <div
              key={key}
              role="gridcell"
              data-testid={`week-cell-${key}`}
              className={[
                "min-h-[8rem] border border-[var(--color-border-subtle)] p-1",
                isToday ? "bg-[var(--color-navy-50)]" : "bg-[var(--color-surface-content)]",
              ].join(" ")}
            >
              <div className="flex flex-col gap-0.5">
                {events.map((ev) => (
                  <EventChip key={ev.id} title={ev.title} color={ev.color} />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
