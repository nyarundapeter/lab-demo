import * as React from "react";
import { Skeleton } from "@dbp/ui";

interface CalendarSkeletonProps {
  rows?: number;
  cols?: number;
}

export function CalendarSkeleton({ rows = 5, cols = 7 }: CalendarSkeletonProps) {
  return (
    <div
      data-testid="calendar-skeleton"
      aria-busy="true"
      aria-label="Loading calendar"
    >
      {/* Header row */}
      <div className="grid gap-px" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
        {Array.from({ length: cols }).map((_, i) => (
          <Skeleton key={i} className="h-6 rounded bg-[var(--color-border)] opacity-40" />
        ))}
      </div>
      {/* Cell rows */}
      {Array.from({ length: rows }).map((_, ri) => (
        <div
          key={ri}
          className="mt-px grid gap-px"
          style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
        >
          {Array.from({ length: cols }).map((_, ci) => (
            <Skeleton key={ci} className="h-20 rounded bg-[var(--color-surface)] opacity-60 border border-[var(--color-border)]">
              <div className="m-1 h-3 w-6 rounded bg-[var(--color-border)] opacity-50" />
            </Skeleton>
          ))}
        </div>
      ))}
    </div>
  );
}
