import * as React from "react";
import { Button, SectionLabel } from "@dbp/ui";
import type { CalendarEvent } from "../hooks/use-calendar-events.js";
import { EventChip } from "./event-chip.js";

const MAX_CHIPS = 3;

interface MonthGridProps {
  /** All YYYY-MM-DD keys for this grid (leading/trailing days included). */
  cells: string[];
  /** Year/month of the displayed month (0-indexed month). */
  year: number;
  month: number;
  weekdayLabels: string[];
  eventsByDay: Map<string, CalendarEvent[]>;
  focusedKey: string;
  onDayFocus: (key: string) => void;
  todayKey: string;
}

export function MonthGrid({
  cells,
  year,
  month,
  weekdayLabels,
  eventsByDay,
  focusedKey,
  onDayFocus,
  todayKey,
}: MonthGridProps) {
  const cellRefs = React.useRef<Map<string, HTMLButtonElement>>(new Map());

  // Roving tabindex: focus the focused cell when it changes
  React.useEffect(() => {
    const el = cellRefs.current.get(focusedKey);
    if (el && document.activeElement !== el) el.focus();
  }, [focusedKey]);

  function handleKeyDown(e: React.KeyboardEvent, key: string) {
    const idx = cells.indexOf(key);
    if (idx === -1) return;
    let next = -1;
    if (e.key === "ArrowRight") next = idx + 1;
    else if (e.key === "ArrowLeft") next = idx - 1;
    else if (e.key === "ArrowDown") next = idx + 7;
    else if (e.key === "ArrowUp") next = idx - 7;
    else return;

    e.preventDefault();
    const nextKey = cells[next];
    if (nextKey !== undefined) onDayFocus(nextKey);
  }

  return (
    <div
      role="grid"
      aria-label="Month calendar grid"
      data-testid="month-grid"
      className="w-full"
    >
      {/* Weekday header row */}
      <div
        role="row"
        className="grid gap-px"
        style={{ gridTemplateColumns: "repeat(7, minmax(0, 1fr))" }}
      >
        {weekdayLabels.map((label) => (
          <SectionLabel
            key={label}
            as="div"
            role="columnheader"
            size="2xs"
            className="py-1.5 text-center font-mono tracking-[0.12em]"
          >
            {label}
          </SectionLabel>
        ))}
      </div>

      {/* Cell rows — cells.length is always a multiple of 7 */}
      {Array.from({ length: cells.length / 7 }).map((_, rowIdx) => (
        <div
          key={rowIdx}
          role="row"
          className="grid gap-px"
          style={{ gridTemplateColumns: "repeat(7, minmax(0, 1fr))" }}
        >
          {cells.slice(rowIdx * 7, rowIdx * 7 + 7).map((key) => {
            const [ky, km, kd] = key.split("-").map(Number) as [number, number, number];
            const isCurrentMonth = km - 1 === month && ky === year;
            const isToday = key === todayKey;
            const isFocused = key === focusedKey;
            const events = eventsByDay.get(key) ?? [];
            const overflow = events.length > MAX_CHIPS ? events.length - MAX_CHIPS : 0;
            const visible = events.slice(0, MAX_CHIPS);

            return (
              <div
                key={key}
                role="gridcell"
                data-testid={`day-cell-${key}`}
                className={[
                  "relative min-h-[5rem] border border-[var(--color-border-subtle)] p-1",
                  isToday
                    ? "bg-[var(--color-navy-50)]"
                    : isCurrentMonth
                    ? "bg-[var(--color-surface-content)]"
                    : "bg-[var(--color-surface)]",
                ].join(" ")}
              >
                {isToday && (
                  <span
                    aria-hidden="true"
                    className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-[var(--color-secondary)]"
                    data-testid={`today-dot-${key}`}
                  />
                )}
                <Button
                  variant="ghost"
                  ref={(el) => {
                    if (el) cellRefs.current.set(key, el);
                    else cellRefs.current.delete(key);
                  }}
                  tabIndex={isFocused ? 0 : -1}
                  aria-label={`${key}${isToday ? ", today" : ""}${events.length > 0 ? `, ${events.length} event${events.length !== 1 ? "s" : ""}` : ""}`}
                  aria-pressed={undefined}
                  className={[
                    "mb-0.5 h-6 w-6 rounded-full p-0 text-xs font-medium focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--color-secondary)]",
                    isToday
                      ? "font-bold text-[var(--color-primary)]"
                      : isCurrentMonth
                      ? "text-[var(--color-text-secondary)]"
                      : "text-[var(--color-text-disabled)]",
                  ].join(" ")}
                  onClick={() => onDayFocus(key)}
                  onKeyDown={(e) => handleKeyDown(e, key)}
                  data-testid={`day-btn-${key}`}
                >
                  {kd}
                </Button>

                <div className="flex flex-col gap-0.5">
                  {visible.map((ev) => (
                    <EventChip key={ev.id} title={ev.title} color={ev.color} />
                  ))}
                  {overflow > 0 && (
                    <span
                      className="text-[0.6rem] text-[var(--color-text)] opacity-60"
                      data-testid={`overflow-${key}`}
                    >
                      +{overflow} more
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
