import * as React from "react";

/**
 * Maps a config palette key to a DQ tone class pair (status triad / brand tints).
 * Keys are kept stable for the config contract; the visual mapping is tokenised
 * so theme swaps propagate and no raw Tailwind palette colours are used.
 */
const PALETTE: Record<string, { bg: string; text: string }> = {
  blue:   { bg: "bg-[var(--color-info-surface)]",    text: "text-[var(--color-info-text)]" },
  amber:  { bg: "bg-[var(--color-warning-surface)]", text: "text-[var(--color-warning-text)]" },
  green:  { bg: "bg-[var(--color-success-surface)]", text: "text-[var(--color-success-text)]" },
  red:    { bg: "bg-[var(--color-danger-surface)]",  text: "text-[var(--color-danger-text)]" },
  purple: { bg: "bg-[var(--color-navy-50)]",         text: "text-[var(--color-primary)]" },
  teal:   { bg: "bg-[var(--color-info-surface)]",    text: "text-[var(--color-info-text)]" },
  pink:   { bg: "bg-[var(--color-orange-50)]",       text: "text-[var(--color-secondary)]" },
};

const DEFAULT_PALETTE = {
  bg: "bg-[var(--color-navy-50)]",
  text: "text-[var(--color-primary)]",
};

interface EventChipProps {
  title: string;
  color: string | undefined;
  "data-testid"?: string;
}

export function EventChip({ title, color, "data-testid": testId }: EventChipProps) {
  const resolved = color ? (PALETTE[color] ?? DEFAULT_PALETTE) : DEFAULT_PALETTE;
  const { bg, text } = resolved;
  return (
    <span
      className={`block truncate rounded px-1.5 py-0.5 text-[0.65rem] font-medium leading-tight ${bg} ${text}`}
      title={title}
      data-testid={testId ?? "event-chip"}
    >
      {title}
    </span>
  );
}
