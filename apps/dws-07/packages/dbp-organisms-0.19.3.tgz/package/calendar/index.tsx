import * as React from "react";
import { ChevronLeft, ChevronRight, CalendarX } from "lucide-react";
import { Alert, Button, EmptyState } from "@dbp/ui";
import { CalendarConfig } from "./types.js";
import type { CalendarConfig as CalendarConfigType } from "./types.js";
import { useCalendarEvents } from "./hooks/use-calendar-events.js";
import { MonthGrid } from "./components/month-grid.js";
import { WeekGrid } from "./components/week-grid.js";
import { CalendarSkeleton } from "./components/calendar-skeleton.js";
import {
  addMonths,
  addWeeks,
  buildMonthGrid,
  buildWeekGrid,
  formatMonthLabel,
  toDateKey,
  visibleRangePadded,
  weekdayLabels,
} from "./components/date-utils.js";

type ConfigInput = Omit<CalendarConfigType, "view" | "weekStartsOn"> &
  Partial<Pick<CalendarConfigType, "view" | "weekStartsOn">>;

/**
 * APP.F05 — Calendar / Scheduler
 *
 * Receives CONFIG, never data. Events are fetched via PS.DATA (useEntityList).
 *
 * PS.DATA limitation: range-filter is not supported natively — we fetch a
 * generous page and filter client-side. See FEATURE.md §Known Limitations.
 *
 * Config is validated at render time via CalendarConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 */
export default function Calendar(rawConfig: ConfigInput) {
  const parseResult = CalendarConfig.safeParse(rawConfig);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="Calendar configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>{e.path.join(".") || "root"}: {e.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <CalendarInner config={parseResult.data} />;
}

export type { CalendarConfig } from "./types.js";

// ─── Inner component (config guaranteed valid) ────────────────────────────────

interface CalendarInnerProps {
  config: CalendarConfigType;
}

function CalendarInner({ config }: CalendarInnerProps) {
  const todayKey = toDateKey(new Date());

  // Initial cursor: use initialDate if provided (test/demo affordance), else today
  const [cursor, setCursor] = React.useState<Date>(() => {
    if (config.initialDate) {
      const [y, m, d] = config.initialDate.split("-").map(Number) as [number, number, number];
      return new Date(y, m - 1, d);
    }
    return new Date();
  });

  const [focusedKey, setFocusedKey] = React.useState<string>(() =>
    config.initialDate ?? todayKey,
  );

  const { start: rangeStart, end: rangeEnd } = visibleRangePadded(
    config.view,
    cursor,
    config.weekStartsOn,
  );

  const { eventsByDay, isLoading, error } = useCalendarEvents(config, rangeStart, rangeEnd);

  const labels = weekdayLabels(config.weekStartsOn);

  // ── Grid data ────────────────────────────────────────────────────────────
  const monthCells = buildMonthGrid(cursor.getFullYear(), cursor.getMonth(), config.weekStartsOn);
  const weekDays = buildWeekGrid(cursor, config.weekStartsOn);

  // ── Navigation ──────────────────────────────────────────────────────────
  function handlePrev() {
    setCursor((c) => (config.view === "month" ? addMonths(c, -1) : addWeeks(c, -1)));
  }
  function handleNext() {
    setCursor((c) => (config.view === "month" ? addMonths(c, 1) : addWeeks(c, 1)));
  }
  function handleToday() {
    const today = new Date();
    setCursor(today);
    setFocusedKey(toDateKey(today));
  }

  // ── Heading ──────────────────────────────────────────────────────────────
  const headingLabel = buildHeadingLabel(config.view, cursor, weekDays);

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="dq-card flex flex-col gap-4" data-testid="calendar">
      {/* Controls bar */}
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleToday}
          aria-label="Go to today"
          data-testid="btn-today"
        >
          Today
        </Button>

        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={handlePrev}
          aria-label={config.view === "month" ? "Previous month" : "Previous week"}
          data-testid="btn-prev"
        >
          <ChevronLeft size={16} strokeWidth={1.5} />
        </Button>

        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={handleNext}
          aria-label={config.view === "month" ? "Next month" : "Next week"}
          data-testid="btn-next"
        >
          <ChevronRight size={16} strokeWidth={1.5} />
        </Button>

        <h2
          className="dq-card-title flex-1 text-center"
          aria-live="polite"
          aria-atomic="true"
          data-testid="calendar-heading"
        >
          {headingLabel}
        </h2>
      </div>

      {/* Grid area */}
      {isLoading && (
        <CalendarSkeleton rows={config.view === "month" ? 5 : 1} cols={7} />
      )}

      {!isLoading && error && (
        <Alert tone="danger" title="Failed to load events" data-testid="error-state">
          {error.message}
        </Alert>
      )}

      {!isLoading && !error && config.view === "month" && (
        <div data-testid="month-view">
          <MonthGrid
            cells={monthCells}
            year={cursor.getFullYear()}
            month={cursor.getMonth()}
            weekdayLabels={labels}
            eventsByDay={eventsByDay}
            focusedKey={focusedKey}
            onDayFocus={setFocusedKey}
            todayKey={todayKey}
          />
          {eventsByDay.size === 0 && (
            <EmptyState
              icon={<CalendarX size={22} strokeWidth={1.5} />}
              title="No events this month"
              data-testid="empty-state"
              className="py-8"
            />
          )}
        </div>
      )}

      {!isLoading && !error && config.view === "week" && (
        <div data-testid="week-view">
          <WeekGrid
            days={weekDays}
            weekdayLabels={labels}
            eventsByDay={eventsByDay}
            focusedKey={focusedKey}
            onDayFocus={setFocusedKey}
            todayKey={todayKey}
          />
          {eventsByDay.size === 0 && (
            <EmptyState
              icon={<CalendarX size={22} strokeWidth={1.5} />}
              title="No events this week"
              data-testid="empty-state"
              className="py-8"
            />
          )}
        </div>
      )}
    </div>
  );
}

// ─── Heading label builder (pure, extracted for readability) ─────────────────

function buildHeadingLabel(
  view: "month" | "week",
  cursor: Date,
  weekDays: string[],
): string {
  if (view === "month") {
    return formatMonthLabel(cursor.getFullYear(), cursor.getMonth());
  }
  const first = weekDays[0]!;
  const last = weekDays[6]!;
  const [fy, fm, fd] = first.split("-").map(Number) as [number, number, number];
  const [ly, lm, ld] = last.split("-").map(Number) as [number, number, number];
  if (fy === ly && fm === lm) {
    return formatMonthLabel(fy, fm - 1);
  }
  const fmt = new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" });
  const fmtYear = new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
  return `${fmt.format(new Date(fy, fm - 1, fd))} – ${fmtYear.format(new Date(ly, lm - 1, ld))}`;
}
