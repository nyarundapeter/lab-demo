import * as React from "react";
import { Button, cn } from "@dbp/ui";
import type { Notification } from "@dbp/ps-notif/client";
import type { Severity, SeverityMapEntry } from "../types.js";
import { relativeTime } from "./relative-time.js";
import { severityDotClass } from "./severity-utils.js";

interface AlertRowProps {
  notification: Notification;
  severity: Severity;
  severityMap: SeverityMapEntry[];
  markRead: (id: string) => void;
}

export function AlertRow({ notification, severity, markRead }: AlertRowProps) {
  return (
    <div
      role="row"
      className={cn(
        "flex items-start gap-3 px-3 py-2.5",
        notification.status === "unread"
          ? "bg-[color-mix(in_srgb,var(--color-primary)_4%,transparent)]"
          : "opacity-70",
      )}
      data-testid="alert-row"
      data-status={notification.status}
      data-id={notification.id}
    >
      <span
        aria-hidden="true"
        className={cn(
          "mt-1.5 h-2 w-2 shrink-0 rounded-full",
          severityDotClass(severity),
        )}
      />

      <div className="min-w-0 flex-1">
        <p className="truncate text-sm text-[var(--color-text)]">
          {notification.message}
        </p>
        <div className="mt-0.5 flex items-center gap-2">
          <span className="text-xs text-[var(--color-text)] opacity-50">
            {relativeTime(notification.ts)}
          </span>
          {notification.link && (
            <a
              href={notification.link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-[var(--color-primary)] underline-offset-2 hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--color-primary)]"
              data-testid="alert-link"
            >
              View
            </a>
          )}
        </div>
      </div>

      {notification.status === "unread" && (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => markRead(notification.id)}
          aria-label={`Mark as read: ${notification.message}`}
          className="h-auto shrink-0 rounded px-1.5 py-0.5 text-xs text-[var(--color-text)] opacity-50 hover:opacity-100 hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)]"
          data-testid="mark-read-btn"
        >
          Dismiss
        </Button>
      )}
    </div>
  );
}
