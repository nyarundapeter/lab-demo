import * as React from "react";
import { Badge, Button, cn } from "@dbp/ui";
import type { Notification } from "@dbp/ps-notif/client";
import type { Severity, SeverityMapEntry } from "../types.js";
import {
  severityBadgeVariant,
  sectionBorderClass,
  type BadgeTone,
} from "./severity-utils.js";
import { AlertRow } from "./alert-row.js";

interface AlertSectionProps {
  label: string;
  severity: Severity;
  items: Notification[];
  severityMap: SeverityMapEntry[];
  markRead: (id: string) => void;
  markAllRead: () => void;
}

export function AlertSection({
  label,
  severity,
  items,
  severityMap,
  markRead,
  markAllRead,
}: AlertSectionProps) {
  const [expanded, setExpanded] = React.useState(true);
  const hasUnread = items.some((n) => n.status === "unread");
  const badgeVariant: BadgeTone = severityBadgeVariant(severity);
  const borderClass = sectionBorderClass(severity);

  return (
    <section
      className={cn("rounded border border-[var(--color-border)]", borderClass)}
      data-testid="alert-section"
      data-severity={severity}
    >
      <div className="flex items-center gap-2 px-3 py-2">
        <Button
          variant="ghost"
          size="sm"
          aria-expanded={expanded}
          onClick={() => setExpanded((v) => !v)}
          className="h-auto flex-1 justify-start gap-2 rounded px-0 text-left text-sm font-semibold text-[var(--color-text)] hover:bg-transparent"
          data-testid="section-toggle"
        >
          <span>{label}</span>
          <Badge tone={badgeVariant} data-testid="section-count">
            {items.length}
          </Badge>
          <span
            aria-hidden="true"
            className={cn(
              "ml-auto text-[var(--color-text)] opacity-50 transition-transform",
              expanded ? "rotate-0" : "-rotate-90",
            )}
          >
            ▾
          </span>
        </Button>

        {hasUnread && (
          <Button
            variant="link"
            onClick={markAllRead}
            aria-label="Mark all as read"
            className="h-auto shrink-0 rounded text-xs text-[var(--color-primary)]"
            data-testid="mark-all-read-btn"
          >
            Mark all read
          </Button>
        )}
      </div>

      {expanded && (
        <div
          role="rowgroup"
          className="divide-y divide-[var(--color-border)]"
          data-testid="section-body"
        >
          {items.map((n) => (
            <AlertRow
              key={n.id}
              notification={n}
              severity={severity}
              severityMap={severityMap}
              markRead={markRead}
            />
          ))}
        </div>
      )}
    </section>
  );
}
