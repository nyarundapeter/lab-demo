import type { Severity, SeverityMapEntry } from "../types.js";

export function resolveSeverity(
  type: string,
  severityMap: SeverityMapEntry[],
): Severity {
  const entry = severityMap.find((e) => e.type === type);
  return entry?.severity ?? "info";
}

export const SEVERITY_ORDER: Severity[] = ["critical", "warning", "info"];

export function severityDotClass(severity: Severity): string {
  if (severity === "critical") return "bg-[var(--color-danger)]";
  if (severity === "warning") return "bg-[var(--color-warning)]";
  return "bg-[var(--color-border-strong)]";
}

export function sectionBorderClass(severity: Severity): string {
  if (severity === "critical") return "border-l-2 border-l-[var(--color-danger)]";
  if (severity === "warning") return "border-l-2 border-l-[var(--color-warning)]";
  return "";
}

/* Points at Badge's consolidated tones (2026-07-17) — "critical" is the
 * first-class notification tone, distinct from generic "danger". */
export type BadgeTone = "critical" | "warning" | "gray";

export function severityBadgeVariant(severity: Severity): BadgeTone {
  if (severity === "critical") return "critical";
  if (severity === "warning") return "warning";
  return "gray";
}
