export { relativeTimeCompact as relativeTime } from "@dbp/ui";
