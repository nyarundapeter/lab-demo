import * as React from "react";
import { Skeleton, Alert } from "@dbp/ui";
import { AlertViewConfig } from "./types.js";
import { useAlertGroups } from "./hooks/use-alert-groups.js";
import { AlertSection } from "./components/alert-section.js";

type ConfigInput = Omit<AlertViewConfig, "groupBy" | "showRead" | "maxItems"> &
  Partial<Pick<AlertViewConfig, "groupBy" | "showRead" | "maxItems" | "emptyText" | "title">>;

export default function AlertView(rawConfig: ConfigInput) {
  const parseResult = AlertViewConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="AlertView configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const config = parseResult.data;
  return <AlertViewInner config={config} />;
}

export type { AlertViewConfig } from "./types.js";

interface AlertViewInnerProps {
  config: AlertViewConfig;
}

function AlertViewInner({ config }: AlertViewInnerProps) {
  const { groups, markRead, markAllRead, isLoading, error } = useAlertGroups(config);

  if (error) {
    return (
      <Alert tone="danger" title="Failed to load notifications" data-testid="alert-view-error">
        {error.message}
      </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-2" data-testid="alert-view">
      {config.title && <h2 className="dq-card-title">{config.title}</h2>}

      {isLoading && (
        <div data-testid="alert-view-loading" className="flex flex-col gap-2">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full rounded" />
          ))}
        </div>
      )}

      {!isLoading && groups.length === 0 && (
        <p
          className="py-6 text-center text-sm text-[var(--color-text-muted)]"
          data-testid="alert-view-empty"
        >
          {config.emptyText ?? "No exceptions."}
        </p>
      )}

      {!isLoading &&
        groups.map((group) => (
          <AlertSection
            key={group.key}
            label={group.label}
            severity={group.severity}
            items={group.items}
            severityMap={config.severityMap}
            markRead={markRead}
            markAllRead={markAllRead}
          />
        ))}
    </div>
  );
}
