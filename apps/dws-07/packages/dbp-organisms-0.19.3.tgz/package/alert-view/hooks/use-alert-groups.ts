import { useMemo } from "react";
import { useNotifications } from "@dbp/ps-notif/client";
import type { Notification } from "@dbp/ps-notif/client";
import type { AlertViewConfig, Severity } from "../types.js";
import { resolveSeverity, SEVERITY_ORDER } from "../components/severity-utils.js";

export type AlertGroup = {
  key: string;
  label: string;
  severity: Severity;
  items: Notification[];
};

export type UseAlertGroupsResult = {
  groups: AlertGroup[];
  markRead: (id: string) => void;
  markAllRead: () => void;
  isLoading: boolean;
  error: Error | null;
};

export function useAlertGroups(config: AlertViewConfig): UseAlertGroupsResult {
  const { items, markRead, markAllRead, isLoading, error } = useNotifications();

  const groups = useMemo(() => {
    let filtered = config.showRead
      ? items
      : items.filter((n) => n.status === "unread");

    filtered = filtered.slice(0, config.maxItems);

    if (config.groupBy === "severity") {
      const buckets: Map<Severity, Notification[]> = new Map([
        ["critical", []],
        ["warning", []],
        ["info", []],
      ]);

      for (const n of filtered) {
        const sev = resolveSeverity(n.type, config.severityMap);
        buckets.get(sev)!.push(n);
      }

      return SEVERITY_ORDER
        .filter((sev) => (buckets.get(sev)?.length ?? 0) > 0)
        .map((sev): AlertGroup => {
          const labelMap: Record<Severity, string> = {
            critical: "Critical",
            warning: "Warning",
            info: "Info",
          };
          return {
            key: sev,
            label: labelMap[sev],
            severity: sev,
            items: buckets.get(sev)!,
          };
        });
    }

    // groupBy === "type"
    const typeOrder: string[] = [];
    const typeBuckets: Map<string, Notification[]> = new Map();

    for (const n of filtered) {
      if (!typeBuckets.has(n.type)) {
        typeOrder.push(n.type);
        typeBuckets.set(n.type, []);
      }
      typeBuckets.get(n.type)!.push(n);
    }

    // Alphabetical order for type grouping
    typeOrder.sort();

    return typeOrder.map((type): AlertGroup => {
      const typeItems = typeBuckets.get(type)!;
      const severity = resolveSeverity(type, config.severityMap);
      const mapEntry = config.severityMap.find((e) => e.type === type);
      return {
        key: type,
        label: mapEntry?.label ?? type,
        severity,
        items: typeItems,
      };
    });
  }, [items, config]);

  return { groups, markRead, markAllRead, isLoading, error };
}
