import { z } from "zod";
import { NotificationSeveritySchema } from "@dbp/contracts";

/* ANL.F04's local severityMap is sourced from @dbp/contracts's consolidated
 * notification-taxonomy schema (ruled opportunistic migration, N2 —
 * docs/09-plans/sharavi-decision-pack-2026-07-11.md). alert-view only
 * renders the critical/warning/info subset (it has no "success"/"error"
 * treatment), so the local enum stays the same 3 values, excluded from the
 * shared 5-level NotificationSeveritySchema rather than hand-rolled. */
const AlertViewSeveritySchema = NotificationSeveritySchema.exclude(["success", "error"]);

const SeverityMapEntrySchema = z.object({
  type: z.string().min(1),
  severity: AlertViewSeveritySchema,
  label: z.string().optional(),
});

export const AlertViewConfig = z.object({
  title: z.string().optional(),
  severityMap: z.array(SeverityMapEntrySchema),
  groupBy: z.enum(["severity", "type"]).default("severity"),
  showRead: z.boolean().default(false),
  maxItems: z.number().int().min(1).max(500).default(50),
  emptyText: z.string().optional(),
});

export type AlertViewConfig = z.infer<typeof AlertViewConfig>;
export type SeverityMapEntry = z.infer<typeof SeverityMapEntrySchema>;
export type Severity = z.infer<typeof AlertViewSeveritySchema>;
