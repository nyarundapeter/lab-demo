# @dbp/organisms/alert-view

**registryId:** `ANL.F04`

Severity-grouped exception/alert list — the DoD §6.1 reference example (Loading/Empty/Error/Populated all covered).

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`AlertViewConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `analytics-dashboard` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/alert-view` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
