# @dbp/organisms/admin-role-list

**registryId:** `APP.F30`

Read-only PS.RBAC role catalog list for the admin/roles page.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`AdminRoleListConfig` — empty Zod schema (no props; self-fetches).

## Consumed by
Bespoke import — `apps/dbp/app/(authenticated)/admin/roles/page.tsx`.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/admin-role-list` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
