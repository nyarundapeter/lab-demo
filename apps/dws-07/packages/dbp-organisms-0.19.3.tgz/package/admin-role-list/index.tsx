"use client"

import * as React from "react"
import { useQuery } from "@tanstack/react-query"
import { fetchMatrix } from "@dbp/ps-rbac/client"
import { Badge, EmptyState } from "@dbp/ui"

/* ─── AdminRoleList ──────────────────────────────────────────────────────
 * Role Management (admin/roles) — real PS.RBAC data (GET /admin/rbac/matrix),
 * not a generic demo entity. Read-only: role catalog is provisioned by the
 * platform, not editable from this list. Shows each role plus how many
 * distinct permissions it carries in the current matrix.
 * ─────────────────────────────────────────────────────────────────────── */

export function AdminRoleList() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["ps-rbac", "admin", "roles-page"],
    queryFn: fetchMatrix,
  })

  if (isLoading) {
    return <p className="text-sm text-[var(--color-text-secondary)] py-6">Loading roles…</p>
  }
  if (error) {
    return <EmptyState tone="danger" headline="Failed to load roles" description={error instanceof Error ? error.message : String(error)} />
  }
  if (!data || data.roles.length === 0) {
    return <EmptyState title="No roles" description="No roles are configured for this tenant yet." />
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-[var(--color-border-subtle)]">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]">
            <th className="text-left font-medium px-4 py-2.5 text-[var(--color-text-secondary)]">Role</th>
            <th className="text-left font-medium px-4 py-2.5 text-[var(--color-text-secondary)]">Scope</th>
            <th className="text-left font-medium px-4 py-2.5 text-[var(--color-text-secondary)]">Permissions</th>
          </tr>
        </thead>
        <tbody>
          {data.roles.map((role) => {
            const grantCount = data.matrix.filter((entry) => entry.role === role.id).length
            return (
              <tr key={role.id} className="border-b border-[var(--color-border-subtle)] last:border-0">
                <td className="px-4 py-2.5 font-medium text-[var(--color-text-primary)]">{role.label}</td>
                <td className="px-4 py-2.5">
                  <Badge tone={role.tenantId ? "info" : "gray"}>{role.tenantId ? "Tenant-custom" : "Platform-global"}</Badge>
                </td>
                <td className="px-4 py-2.5 text-[var(--color-text-secondary)]">
                  {grantCount} permission{grantCount === 1 ? "" : "s"}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export type { AdminRoleListConfig } from "./types.js";
