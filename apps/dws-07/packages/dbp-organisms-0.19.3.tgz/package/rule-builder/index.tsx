import React from "react";
import { Play, CheckCircle, XCircle, Send, Settings, X, Plus, GitBranch, ExternalLink } from "lucide-react";
import {
  Alert,
  Badge,
  Button,
  InfoCard,
  Switch,
  Input,
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue,
  SuggestedAction,
} from "@dbp/ui";
import { ConditionGroupEditor } from "./components/condition-group.js";
import { RuleTestDrawer } from "./components/rule-test-drawer.js";
import { RuleBuilderConfig, type RuleBuilderConfigInput, type RuleAction } from "./types.js";

let idCounter = 1000;
function nextId(): string {
  idCounter += 1;
  return `action-${idCounter}`;
}

/**
 * WHEN/IF/THEN/ELSE rule authoring surface — port of
 * admin-rule-builder.jsx's `RuleBuilder`. UI-only, prop-driven: `config`
 * supplies the initial state, the component owns all editing interaction
 * locally (matches the reference's own `useState` shape). No backend call —
 * `PS.RULES` vs. manifest-config-time vs. thin-orchestration is an open
 * architecture ruling, not resolved here. See FEATURE.md.
 */
export default function RuleBuilder(config: RuleBuilderConfigInput) {
  const parsed = RuleBuilderConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="RuleBuilder — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <RuleBuilderInner {...parsed.data} />;
}

function RuleBuilderInner(config: RuleBuilderConfig) {
  const [rootGroup, setRootGroup] = React.useState(config.rootGroup);
  const [actions, setActions] = React.useState(config.actions);
  const [elseActions, setElseActions] = React.useState(config.elseActions);
  const [showElse, setShowElse] = React.useState(config.elseActions.length > 0);
  const [testOpen, setTestOpen] = React.useState(false);
  const [dirty, setDirty] = React.useState(false);
  const [showConflicts, setShowConflicts] = React.useState(config.conflicts.length > 0);
  const [addActionOpen, setAddActionOpen] = React.useState(false);

  const addAction = (type: string) => {
    const t = config.actionTypes.find((a) => a.type === type);
    setActions([...actions, { id: nextId(), type, icon: t?.icon, config: "Configure…" }]);
    setDirty(true);
    setAddActionOpen(false);
  };

  const removeAction = (id: string) => {
    setActions(actions.filter((a) => a.id !== id));
    setDirty(true);
  };

  const validations = [
    ...config.validations,
    ...(actions.some((a) => a.config === "Configure…")
      ? [{ level: "error" as const, msg: "One or more actions are not fully configured." }]
      : []),
  ];
  const errorCount = validations.filter((v) => v.level === "error").length;
  const warningCount = validations.filter((v) => v.level === "warning").length;

  return (
    <div className="mx-auto flex max-w-[1120px] flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="mb-1 flex items-center gap-2">
            <h2 className="text-lg font-semibold">{config.ruleName}</h2>
            <Badge tone="info">{config.statusLabel}</Badge>
            <Badge tone="gray">{config.env}</Badge>
          </div>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button type="button" variant="outline" onClick={() => setTestOpen(true)}>
            <Play size={14} />
            Test rule
          </Button>
          <Button type="button" variant="outline">
            <CheckCircle size={14} />
            Validate
          </Button>
          <Button type="button">
            <Send size={14} />
            Submit for approval
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[1fr_320px]">
        {/* Builder */}
        <div className="flex flex-col gap-4">
          <RuleBlock keyword="WHEN" description="this happens (trigger)">
            <Select defaultValue={config.trigger}>
              <SelectTrigger className="h-8 w-full text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={config.trigger}>{config.trigger}</SelectItem>
                {config.triggerOptions
                  .filter((o) => o !== config.trigger)
                  .map((o) => (
                    <SelectItem key={o} value={o}>
                      {o}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </RuleBlock>

          <RuleBlock keyword="IF" description="these conditions are met">
            <ConditionGroupEditor
              group={rootGroup}
              onChange={(g) => {
                setRootGroup(g);
                setDirty(true);
              }}
              fields={config.fields}
              operators={config.operators}
            />
          </RuleBlock>

          <RuleBlock keyword="THEN" description="perform these actions">
            <div className="flex flex-col gap-2">
              {actions.map((action) => (
                <ActionRow key={action.id} action={action} onRemove={() => removeAction(action.id)} />
              ))}
              <div className="relative inline-block self-start">
                <Button type="button" variant="outline" size="sm" onClick={() => setAddActionOpen(!addActionOpen)}>
                  <Plus size={13} />
                  Add action
                </Button>
                {addActionOpen && (
                  <div className="absolute left-0 top-9 z-10 max-h-[280px] w-[220px] overflow-y-auto rounded-[var(--radius-card)] border border-border-default bg-[var(--color-surface-content)] shadow-[var(--shadow-md)]">
                    {config.actionTypes.map((a) => (
                      <button
                        type="button"
                        key={a.type}
                        onClick={() => addAction(a.type)}
                        className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs hover:bg-[var(--color-neutral-surface)]"
                      >
                        {a.type}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </RuleBlock>

          {showElse ? (
            <RuleBlock
              keyword="ELSE"
              description="otherwise"
              headerExtra={
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="ml-auto h-7 w-7 p-0"
                  aria-label="Remove else branch"
                  onClick={() => setShowElse(false)}
                >
                  <X size={13} />
                </Button>
              }
            >
              <div className="flex flex-col gap-2">
                {elseActions.map((action) => (
                  <ActionRow
                    key={action.id}
                    action={action}
                    onRemove={() => setElseActions(elseActions.filter((a) => a.id !== action.id))}
                  />
                ))}
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="self-start"
                  onClick={() =>
                    setElseActions([...elseActions, { id: nextId(), type: "Assign owner", config: "Configure…" }])
                  }
                >
                  <Plus size={13} />
                  Add else action
                </Button>
              </div>
            </RuleBlock>
          ) : (
            <Button type="button" variant="ghost" size="sm" className="self-start" onClick={() => setShowElse(true)}>
              <Plus size={13} />
              Add ELSE branch
            </Button>
          )}
        </div>

        {/* Right rail */}
        <div className="flex flex-col gap-4">
          <InfoCard title="Rule settings">
            <div className="flex flex-col gap-3">
              <FieldRow label="Priority" help="Lower numbers run first.">
                <Input className="h-8 text-xs" defaultValue={config.priority} />
              </FieldRow>
              <FieldRow label="On match">
                <Select defaultValue={config.onMatchOptions[0] ?? "Stop after match"}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {config.onMatchOptions.map((o) => (
                      <SelectItem key={o} value={o}>
                        {o}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FieldRow>
              <label className="mt-1 flex items-center gap-2 text-xs">
                <Switch defaultChecked />
                Log every execution
              </label>
            </div>
          </InfoCard>

          <InfoCard
            title="Validation"
            icon={errorCount > 0 ? XCircle : CheckCircle}
            badge={
              <span className="text-xs text-text-muted">
                {errorCount} error{errorCount === 1 ? "" : "s"} · {warningCount} warning{warningCount === 1 ? "" : "s"}
              </span>
            }
          >
            {validations.length === 0 ? (
              <div className="flex items-center gap-2 text-xs text-[var(--color-success)]">
                <CheckCircle size={14} />
                Rule is valid and ready to test.
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {validations.map((v, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs">
                    <span className={v.level === "error" ? "text-[var(--color-danger)]" : "text-[var(--color-warning)]"}>
                      ●
                    </span>
                    <span>{v.msg}</span>
                  </div>
                ))}
              </div>
            )}
          </InfoCard>

          {showConflicts &&
            config.conflicts.map((c, i) => (
              <InfoCard
                key={i}
                tone="danger"
                icon={GitBranch}
                title="Rule conflict detected"
                rows={[
                  { label: "Reason", value: c.reason },
                  { label: "Order", value: c.order },
                  { label: "Fix", value: c.resolution },
                ]}
                actions={
                  <>
                    <Button type="button" variant="outline" size="sm">
                      <ExternalLink size={12} />
                      Open conflicting rule
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={() => setShowConflicts(false)}>
                      Dismiss
                    </Button>
                  </>
                }
              >
                <div className="mb-1 text-sm font-medium">{c.rule}</div>
              </InfoCard>
            ))}

          {config.suggestion && (
            <SuggestedAction
              title={config.suggestion.title}
              reason={config.suggestion.reason}
              impact={config.suggestion.impact}
              records={config.suggestion.records}
              {...(config.suggestion.confidence !== undefined && { confidence: config.suggestion.confidence })}
              permission={config.suggestion.permission}
              onExplain={() => setShowConflicts(true)}
            />
          )}
        </div>
      </div>

      {dirty && (
        <div className="fixed inset-x-0 bottom-0 z-20 flex items-center gap-3 border-t border-border-default bg-[var(--color-surface-content)] px-4 py-3 shadow-[var(--shadow-md)]">
          <span className="text-sm">Unsaved changes</span>
          <div className="flex-1" />
          <Button type="button" variant="outline" size="sm" onClick={() => setDirty(false)}>
            Discard
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => setDirty(false)}>
            Save draft
          </Button>
        </div>
      )}

      <RuleTestDrawer
        open={testOpen}
        onOpenChange={setTestOpen}
        conditionTrace={config.testConditionTrace}
        resultActions={config.testResultActions}
      />
    </div>
  );
}

function RuleBlock({
  keyword,
  description,
  headerExtra,
  children,
}: {
  keyword: string;
  description: string;
  headerExtra?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-[var(--radius-card)] border border-border-default bg-[var(--color-surface-content)]">
      <div className="flex items-center gap-1.5 border-b border-border-default px-3.5 py-2.5 text-sm">
        <span className="font-mono text-xs font-bold text-[var(--color-primary)]">{keyword}</span>
        {description}
        {headerExtra}
      </div>
      <div className="p-3.5">{children}</div>
    </div>
  );
}

function ActionRow({ action, onRemove }: { action: RuleAction; onRemove: () => void }) {
  const unconfigured = action.config === "Configure…";
  return (
    <div className="flex items-center gap-2.5 rounded-[var(--radius-card)] border border-border-default px-3 py-2.5">
      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-[4px] bg-[var(--color-neutral-surface)]">
        <Settings size={13} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium">{action.type}</div>
        <div className={unconfigured ? "text-xs text-[var(--color-danger)]" : "text-xs text-text-muted"}>
          {action.config}
        </div>
      </div>
      <Button type="button" variant="ghost" size="sm" className="h-7 w-7 p-0" aria-label="Configure">
        <Settings size={13} />
      </Button>
      <Button type="button" variant="ghost" size="sm" className="h-7 w-7 p-0" aria-label="Remove" onClick={onRemove}>
        <X size={13} />
      </Button>
    </div>
  );
}

function FieldRow({ label, help, children }: { label: string; help?: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1 text-xs">
      <span className="font-medium text-text-secondary">{label}</span>
      {children}
      {help && <span className="text-xs text-text-muted">{help}</span>}
    </label>
  );
}
