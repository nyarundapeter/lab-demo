# @dbp/organisms/rule-builder

**registryId:** `APP.F38`

WHEN/IF/THEN/ELSE rule authoring surface: trigger + recursive condition-group tree + action
list + optional ELSE branch + settings/validation/conflict rail + test-mode simulation drawer.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`RuleBuilderConfig` — Zod schema exported from `types.ts` (source of truth). See `FEATURE.md`
for the recursive `ConditionGroup` shape and why this component is UI-only (no `PS.RULES`
service exists — see FEATURE.md's "UI-only" section for the open architecture ruling).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/rules/[id]` to this organism. Generator wiring is a follow-up (lift-and-shift scope).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/rule-builder` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
