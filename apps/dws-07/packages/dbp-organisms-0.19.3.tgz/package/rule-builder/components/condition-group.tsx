import React from "react";
import { GripVertical, X, Plus } from "lucide-react";
import {
  Button,
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue,
  Input,
  cn,
} from "@dbp/ui";
import type { ConditionGroup as ConditionGroupType, RuleCondition } from "../types.js";

let idCounter = 100;
function nextId(): string {
  idCounter += 1;
  return `cond-${idCounter}`;
}

const NO_VALUE_OPERATORS = new Set(["is empty", "is not empty", "changed"]);

interface Props {
  group: ConditionGroupType;
  onChange: (group: ConditionGroupType) => void;
  fields: string[];
  operators: string[];
  depth?: number;
}

/**
 * Recursive WHEN/IF condition-group tree — port of admin-rule-builder.jsx's
 * `ConditionGroup`. Depth capped at 2 nested groups, matching the reference.
 * No real drag-and-drop: the grip icon is decorative, same as the source.
 */
export function ConditionGroupEditor({ group, onChange, fields, operators, depth = 0 }: Props) {
  const setOp = (op: "AND" | "OR") => onChange({ ...group, op });

  const updateCondition = (index: number, patch: Partial<RuleCondition>) => {
    const conditions = group.conditions.map((c, i) => (i === index ? { ...c, ...patch } : c));
    onChange({ ...group, conditions });
  };

  const removeCondition = (index: number) => {
    onChange({ ...group, conditions: group.conditions.filter((_, i) => i !== index) });
  };

  const addCondition = () => {
    onChange({
      ...group,
      conditions: [
        ...group.conditions,
        { id: nextId(), field: fields[0] ?? "", operator: operators[0] ?? "equals", value: "" },
      ],
    });
  };

  const addGroup = () => {
    onChange({
      ...group,
      groups: [
        ...group.groups,
        {
          id: nextId(),
          op: "AND",
          conditions: [{ id: nextId(), field: fields[0] ?? "", operator: operators[0] ?? "equals", value: "" }],
          groups: [],
        },
      ],
    });
  };

  const updateGroup = (index: number, updated: ConditionGroupType) => {
    onChange({ ...group, groups: group.groups.map((g, i) => (i === index ? updated : g)) });
  };

  const removeGroup = (index: number) => {
    onChange({ ...group, groups: group.groups.filter((_, i) => i !== index) });
  };

  const rows: Array<{ kind: "condition"; index: number; condition: RuleCondition } | { kind: "group"; index: number; group: ConditionGroupType }> = [
    ...group.conditions.map((condition, index) => ({ kind: "condition" as const, index, condition })),
    ...group.groups.map((g, index) => ({ kind: "group" as const, index, group: g })),
  ];

  return (
    <div className="flex flex-col gap-2" data-op={group.op}>
      {rows.map((row, rowIndex) => (
        <div key={row.kind === "condition" ? row.condition.id : row.group.id}>
          {rowIndex > 0 && (
            <button
              type="button"
              onClick={() => setOp(group.op === "AND" ? "OR" : "AND")}
              title="Toggle AND/OR"
              className="mb-2 inline-flex items-center gap-1 rounded-[4px] border border-border-default bg-[var(--color-surface-content)] px-2 py-0.5 text-xs font-semibold uppercase tracking-wide text-text-secondary hover:bg-[var(--color-neutral-surface)]"
            >
              {group.op}
            </button>
          )}
          {row.kind === "condition" ? (
            <div className="flex items-center gap-2">
              <GripVertical size={14} className="shrink-0 cursor-grab text-text-muted" aria-hidden="true" />
              <Select value={row.condition.field} onValueChange={(v) => updateCondition(row.index, { field: v })}>
                <SelectTrigger aria-label="Field" className="h-8 w-[160px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {fields.map((f) => (
                    <SelectItem key={f} value={f}>
                      {f}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={row.condition.operator} onValueChange={(v) => updateCondition(row.index, { operator: v })}>
                <SelectTrigger aria-label="Operator" className="h-8 w-[150px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {operators.map((o) => (
                    <SelectItem key={o} value={o}>
                      {o}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!NO_VALUE_OPERATORS.has(row.condition.operator) && (
                <Input
                  aria-label="Value"
                  placeholder="value…"
                  className="h-8 flex-1 text-xs"
                  value={row.condition.value}
                  onChange={(e) => updateCondition(row.index, { value: e.target.value })}
                />
              )}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 w-8 shrink-0 p-0"
                aria-label="Remove condition"
                onClick={() => removeCondition(row.index)}
              >
                <X size={14} />
              </Button>
            </div>
          ) : (
            <div className={cn("rounded-[var(--radius-card)] border border-border-default bg-[var(--color-neutral-surface)] p-3")}>
              <div className="mb-2 flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wide text-text-muted">Group</span>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="ml-auto h-7 w-7 p-0"
                  aria-label="Remove group"
                  onClick={() => removeGroup(row.index)}
                >
                  <X size={13} />
                </Button>
              </div>
              <ConditionGroupEditor
                group={row.group}
                onChange={(g) => updateGroup(row.index, g)}
                fields={fields}
                operators={operators}
                depth={depth + 1}
              />
            </div>
          )}
        </div>
      ))}
      <div className="mt-1 flex gap-2">
        <Button type="button" variant="outline" size="sm" onClick={addCondition}>
          <Plus size={13} />
          Add condition
        </Button>
        {depth < 2 && (
          <Button type="button" variant="ghost" size="sm" onClick={addGroup}>
            <Plus size={13} />
            Add group
          </Button>
        )}
      </div>
    </div>
  );
}
