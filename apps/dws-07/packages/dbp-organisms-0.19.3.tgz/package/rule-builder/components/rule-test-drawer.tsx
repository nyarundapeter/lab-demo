import React from "react";
import { RefreshCw, CircleCheck } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, Button, Alert, Badge } from "@dbp/ui";
import type { RuleBuilderConfig } from "../types.js";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  conditionTrace: RuleBuilderConfig["testConditionTrace"];
  resultActions: RuleBuilderConfig["testResultActions"];
}

/**
 * Test-mode simulation drawer — port of admin-rule-builder.jsx's
 * `RuleTestDrawer`. "Running" is a local 700ms timer (matches the
 * reference exactly), not a real rules-engine call: this organism is
 * UI-only, prop-driven (see FEATURE.md).
 */
export function RuleTestDrawer({ open, onOpenChange, conditionTrace, resultActions }: Props) {
  const [running, setRunning] = React.useState(false);
  const [ran, setRan] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setRan(false);
      setRunning(false);
    }
  }, [open]);

  const run = () => {
    setRunning(true);
    setTimeout(() => {
      setRunning(false);
      setRan(true);
    }, 700);
  };

  const matchedActions = resultActions.filter((a) => a.wouldRun).length;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" size="wide">
        <SheetHeader>
          <SheetTitle>Test rule</SheetTitle>
          <SheetDescription>Runs against a sample record. No changes are applied.</SheetDescription>
        </SheetHeader>

        {running && (
          <div className="flex items-center justify-center gap-2 py-8 text-sm text-text-muted">
            <RefreshCw size={16} className="animate-spin" aria-hidden="true" />
            Running rule against sample…
          </div>
        )}

        {ran && !running && (
          <div className="flex flex-col gap-4">
            <Alert tone="success" title={`Rule matched — ${matchedActions} action${matchedActions === 1 ? "" : "s"} would run`}>
              No changes were applied. This is a preview only.
            </Alert>

            <div>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-text-muted">
                Condition trace
              </h4>
              <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
                {conditionTrace.map((c, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-2 px-3 py-2.5 text-xs"
                    style={i < conditionTrace.length - 1 ? { borderBottom: "1px solid var(--color-border-subtle)" } : undefined}
                  >
                    <CircleCheck size={14} className="shrink-0 text-[var(--color-success)]" aria-hidden="true" />
                    <span className="flex-1">{c.label}</span>
                    <span className="font-mono text-[var(--color-success)]">{c.detail}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-text-muted">
                Resulting actions (preview)
              </h4>
              <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
                {resultActions.map((a, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-2 px-3 py-2.5 text-xs"
                    style={{
                      opacity: a.wouldRun ? 1 : 0.5,
                      ...(i < resultActions.length - 1 ? { borderBottom: "1px solid var(--color-border-subtle)" } : {}),
                    }}
                  >
                    <span className="flex-1">{a.label}</span>
                    <Badge tone={a.wouldRun ? "success" : "gray"}>{a.wouldRun ? "would run" : "skipped"}</Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="mt-auto flex justify-end gap-2 border-t border-border-default pt-4">
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button type="button" onClick={run} loading={running}>
            Run test
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
