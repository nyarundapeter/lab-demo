import { z } from "zod";

export const RuleCondition = z.object({
  id: z.string().min(1),
  field: z.string().min(1),
  operator: z.string().min(1),
  /** No default here (unlike most optional strings in this codebase) — a z.lazy recursive schema's inferred input/output types must match exactly. */
  value: z.string(),
});
export type RuleCondition = z.infer<typeof RuleCondition>;

/**
 * Recursive condition group (WHEN/IF tree) — `z.lazy` is required since the
 * schema references itself via `groups`.
 */
export const ConditionGroup: z.ZodType<ConditionGroupShape> = z.lazy(() =>
  z.object({
    id: z.string().min(1),
    op: z.enum(["AND", "OR"]),
    conditions: z.array(RuleCondition),
    groups: z.array(ConditionGroup),
  })
);
interface ConditionGroupShape {
  id: string;
  op: "AND" | "OR";
  conditions: RuleCondition[];
  groups: ConditionGroupShape[];
}
export type ConditionGroup = ConditionGroupShape;

export const RuleAction = z.object({
  id: z.string().min(1),
  type: z.string().min(1),
  /** Lucide icon name. */
  icon: z.string().optional(),
  /** One-line config summary, e.g. "Assign owner → EMEA Infrastructure Desk". Literal "Configure…" flags an unconfigured action (validation error). */
  config: z.string().min(1),
});
export type RuleAction = z.infer<typeof RuleAction>;

const ActionTypeOption = z.object({
  type: z.string().min(1),
  icon: z.string().optional(),
});

const Validation = z.object({
  level: z.enum(["error", "warning"]),
  msg: z.string().min(1),
});

const Conflict = z.object({
  rule: z.string().min(1),
  reason: z.string().min(1),
  order: z.string().min(1),
  resolution: z.string().min(1),
});

const AiSuggestion = z.object({
  title: z.string().min(1),
  reason: z.string().min(1),
  impact: z.string().min(1),
  records: z.string().min(1),
  confidence: z.enum(["high", "medium", "low", "insufficient"]).optional(),
  permission: z.string().min(1),
});

const TestConditionTrace = z.object({
  label: z.string().min(1),
  detail: z.string().min(1),
});

const TestResultAction = z.object({
  icon: z.string().optional(),
  label: z.string().min(1),
  wouldRun: z.boolean(),
});

export const RuleBuilderConfig = z.object({
  ruleName: z.string().min(1),
  statusLabel: z.string().default("Editing draft"),
  env: z.string().default("dev"),
  trigger: z.string().min(1),
  triggerOptions: z.array(z.string()).default([
    "When a record is created",
    "When a field changes",
    "On a schedule",
  ]),
  /** Field options for condition rows. */
  fields: z.array(z.string()).min(1),
  /** Operator options for condition rows. */
  operators: z.array(z.string()).min(1),
  /** Action-type palette for "Add action". */
  actionTypes: z.array(ActionTypeOption).min(1),
  rootGroup: ConditionGroup,
  actions: z.array(RuleAction),
  elseActions: z.array(RuleAction).default([]),
  priority: z.string().default("100"),
  onMatchOptions: z.array(z.string()).default(["Stop after match", "Continue processing"]),
  /** Pre-computed validation messages. This component does not evaluate rules — the caller supplies the result. */
  validations: z.array(Validation).default([]),
  /** Present + non-empty to show the conflict panel. */
  conflicts: z.array(Conflict).default([]),
  /** Optional AI suggestion card in the right rail. */
  suggestion: AiSuggestion.optional(),
  /** Fixed condition-trace + resulting-actions preview shown after "Run test" — this component simulates the test locally (matches the reference), it does not call a rules engine. */
  testConditionTrace: z.array(TestConditionTrace).default([]),
  testResultActions: z.array(TestResultAction).default([]),
});

export type RuleBuilderConfig = z.infer<typeof RuleBuilderConfig>;
export type RuleBuilderConfigInput = z.input<typeof RuleBuilderConfig>;
