import { z } from "zod";

// ─── Metric config ─────────────────────────────────────────────────────────────

const KpiMetricSchema = z
  .object({
    /** Entity data field to aggregate. Required for sum/avg; omitted only for count. */
    field: z.string().min(1).optional(),
    /** Aggregation applied client-side to the fetched rows. */
    aggregate: z.enum(["count", "sum", "avg"]),
  })
  .superRefine((val, ctx) => {
    if (val.aggregate !== "count" && !val.field) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `field is required when aggregate is "${val.aggregate}"`,
        path: ["field"],
      });
    }
  });

export type KpiMetric = z.infer<typeof KpiMetricSchema>;

// ─── Per-KPI definition ────────────────────────────────────────────────────────

const KpiDefinitionSchema = z.object({
  /** Stable identifier — used as React key and for error isolation. */
  id: z.string().min(1),
  /** Human-readable label shown above the value. */
  label: z.string().min(1),
  /** PS.DATA entity type this KPI queries. */
  entityType: z.string().min(1),
  /** Aggregation applied to the primary entity query. */
  metric: KpiMetricSchema,
  /**
   * Lucide icon name to render in the tile header icon slot.
   * Supported names: "Hash" | "TrendingUp" | "BarChart3" | "DollarSign" |
   * "Percent" | "Activity" | "Target" | "Users" | "ShoppingCart" | "Package".
   * When omitted a sensible default is chosen by aggregate type:
   *   count → Hash, sum → TrendingUp, avg → BarChart3.
   */
  icon: z
    .enum([
      "Hash",
      "TrendingUp",
      "BarChart3",
      "DollarSign",
      "Percent",
      "Activity",
      "Target",
      "Users",
      "ShoppingCart",
      "Package",
    ])
    .optional(),
  /** Number formatting for the displayed value. Defaults to "number". */
  format: z.enum(["number", "currency", "percent"]).default("number"),
  /**
   * When present, a progress bar and attainment percentage are rendered
   * (actual / target × 100). Must be a positive number.
   */
  target: z.number().positive().optional(),
  /**
   * How the target attainment is visualised when `target` is set.
   * "progress" (default) — StatTile's built-in progress bar + percentage.
   * "bullet" — an actual-vs-target BulletChart (dash-charts.jsx:285-297)
   * rendered below the delta badge instead of the progress bar.
   */
  targetDisplay: z.enum(["progress", "bullet"]).default("progress"),
  /**
   * Shows a trend Sparkline below the delta badge. The spark series buckets
   * this KPI's own fetched rows into up to 8 equal time windows by
   * `createdAt` and aggregates each bucket the same way as the KPI metric
   * — never fabricated data. Requires at least 2 rows spanning more than
   * one instant to render (a flat/empty series is silently omitted).
   */
  showSpark: z.boolean().default(false),
  /**
   * Semantic direction used to color delta indicators.
   * "higher-is-better" (default) → positive delta is "good" (primary token).
   * "lower-is-better" → positive delta is "bad" (destructive token).
   */
  direction: z
    .enum(["higher-is-better", "lower-is-better"])
    .default("higher-is-better"),
  /**
   * Visual tone of the tile — controls border-top colour and icon container.
   * Defaults to "primary".
   */
  tone: z
    .enum(["primary", "success", "warning", "danger", "info"])
    .default("primary"),
  /**
   * Static field-equality filters forwarded to the primary PS.DATA request.
   */
  filters: z
    .record(z.string(), z.union([z.string(), z.number(), z.boolean()]))
    .optional(),
  /**
   * When present, a second PS.DATA request is made with these filters.
   * The delta (actual − comparison) / |comparison| × 100 is shown with
   * an up/down arrow coloured by `direction` semantics.
   */
  comparisonFilters: z
    .record(z.string(), z.union([z.string(), z.number(), z.boolean()]))
    .optional(),
});

export type KpiDefinition = z.infer<typeof KpiDefinitionSchema>;

// ─── Scorecard config ──────────────────────────────────────────────────────────

/**
 * KpiScorecardConfig — the single typed contract for ANL.F03.
 *
 * This is a DATA contract only (no function fields — Zod schemas are data-only).
 */
export const KpiScorecardConfig = z.object({
  /**
   * 1–6 KPI tile definitions.
   */
  kpis: z.array(KpiDefinitionSchema).min(1).max(6),
  /**
   * "row" — horizontal strip of tiles (suitable for the header slot).
   * "grid" — 2–3 column grid (suitable for the main slot).
   * Defaults to "row".
   */
  layout: z.enum(["row", "grid"]).default("row"),
});

export type KpiScorecardConfig = z.infer<typeof KpiScorecardConfig>;
