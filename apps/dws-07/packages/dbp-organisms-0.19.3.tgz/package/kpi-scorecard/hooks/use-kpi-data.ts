import { useQuery } from "@tanstack/react-query";
import { listAllEntities } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { KpiDefinition } from "../types.js";

export interface KpiDataResult {
  rows: EntityRecord<EntityData>[];
  comparisonRows: EntityRecord<EntityData>[] | null;
  isLoading: boolean;
  error: Error | null;
  /**
   * True when the primary query hit the `listAllEntities` 2000-row safety cap
   * (i.e. the server reports more matching rows than were fetched). The
   * aggregate shown is computed over a partial dataset when this is true.
   */
  capped: boolean;
  /** Server-reported total row count for the primary query (undefined while loading). */
  total: number | undefined;
}

/**
 * Fetches entity rows for a single KPI tile from PS.DATA.
 *
 * NOTE — client-side aggregation:
 * PS.DATA has no server-side aggregate endpoint. The tile pages through all
 * available rows (up to 2000) using MAX_PAGE_SIZE (200) per request and
 * computes count/sum/avg entirely in the browser.
 * A future PS.DATA aggregate endpoint can replace this without changing KpiScorecardConfig.
 */
export function useKpiData(kpi: KpiDefinition): KpiDataResult {
  const primaryQuery = useQuery({
    queryKey: ["ps-data", "all-entities", kpi.entityType, kpi.filters ?? {}],
    queryFn: () => listAllEntities(kpi.entityType, { ...(kpi.filters !== undefined && { filters: kpi.filters }) }),
  });

  // comparisonFilters drives a second independent query.
  // useQuery is called unconditionally (Rules of Hooks); when
  // comparisonFilters is absent we pass the same filters as primary so the
  // result is simply ignored and not shown.
  const hasComparison = kpi.comparisonFilters !== undefined;
  const comparisonQuery = useQuery({
    queryKey: [
      "ps-data",
      "all-entities",
      kpi.entityType,
      kpi.comparisonFilters ?? kpi.filters ?? {},
      "comparison",
    ],
    queryFn: () => {
      const compFilters = kpi.comparisonFilters ?? kpi.filters;
      return compFilters !== undefined
        ? listAllEntities(kpi.entityType, { filters: compFilters })
        : listAllEntities(kpi.entityType, {});
    },
  });

  const rows = primaryQuery.data?.rows ?? [];
  const total = primaryQuery.data?.total;

  return {
    rows,
    comparisonRows: hasComparison ? (comparisonQuery.data?.rows ?? []) : null,
    isLoading: primaryQuery.isLoading || (hasComparison && comparisonQuery.isLoading),
    error: (primaryQuery.error ??
      (hasComparison ? comparisonQuery.error : null)) as Error | null,
    capped: total !== undefined && total > rows.length,
    total,
  };
}
