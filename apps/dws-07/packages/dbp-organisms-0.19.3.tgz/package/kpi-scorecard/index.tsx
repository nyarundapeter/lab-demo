import * as React from "react";
import { z } from "zod";
import { Alert } from "@dbp/ui";
import { KpiScorecardConfig } from "./types.js";
import { KpiTile } from "./components/kpi-tile.js";

// The raw caller-facing props use the Zod *input* shape so that fields with
// .default() (format, direction, layout) are correctly treated as optional.
type ConfigInput = z.input<typeof KpiScorecardConfig>;

/**
 * ANL.F03 — KPI Scorecard
 *
 * Receives CONFIG, never data. Each KPI tile independently fetches entity rows
 * via PS.DATA (useEntityList, pageSize 500) and computes count/sum/avg
 * client-side. See FEATURE.md for the client-side aggregation limitation notice.
 *
 * Tile failures are isolated — one tile erroring does not affect siblings.
 *
 * Config is validated at render time via KpiScorecardConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 */
export default function KpiScorecard(rawConfig: ConfigInput) {
  const parseResult = KpiScorecardConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="KpiScorecard configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const config = parseResult.data;
  return <KpiScorecardInner config={config} />;
}

// Re-export the config type so consumers can import from the root.
export type { KpiScorecardConfig, KpiDefinition, KpiMetric } from "./types.js";

// ─── Inner component (config is guaranteed valid here) ────────────────────────

interface KpiScorecardInnerProps {
  config: KpiScorecardConfig;
}

function KpiScorecardInner({ config }: KpiScorecardInnerProps) {
  const { kpis, layout } = config;

  // "row" → single horizontal strip; "grid" → balanced columns by KPI count
  // (4 → 2×2 then 4-up so it never leaves a lone wrapped tile; 3/5/6 → 3-up).
  const gridClass =
    layout === "row"
      ? "flex flex-row gap-4 overflow-x-auto"
      : kpis.length <= 2
        ? "grid grid-cols-2 gap-4"
        : kpis.length === 4
          ? "grid grid-cols-2 gap-4 lg:grid-cols-4"
          : "grid grid-cols-2 gap-4 sm:grid-cols-3";

  return (
    <div
      className={gridClass}
      data-testid="kpi-scorecard"
      data-layout={layout}
    >
      {kpis.map((kpi) => (
        <KpiTile key={kpi.id} kpi={kpi} />
      ))}
    </div>
  );
}
