import * as React from "react";
import {
  Hash,
  TrendingUp,
  BarChart3,
  DollarSign,
  Percent,
  Activity,
  Target,
  Users,
  ShoppingCart,
  Package,
  type LucideProps,
} from "lucide-react";
import { Skeleton, StatTile, formatNumber, Alert, Sparkline, BulletChart, EmptyState } from "@dbp/ui";
import type { KpiDefinition } from "../types.js";
import { aggregate, formatValue, buildSparkSeries } from "./aggregation.js";
import { useKpiData } from "../hooks/use-kpi-data.js";

/** Mono caption like "SUM OF AMOUNT · 40 RECORDS" describing the aggregate basis. */
function aggregateCaption(kpi: KpiDefinition, recordCount: number): string {
  const op = kpi.metric.aggregate.toUpperCase();
  const field = kpi.metric.field ? ` OF ${kpi.metric.field.toUpperCase()}` : "";
  const records = `${formatNumber(recordCount)} RECORD${recordCount === 1 ? "" : "S"}`;
  return kpi.metric.aggregate === "count" ? records : `${op}${field} · ${records}`;
}

// ─── Icon registry ────────────────────────────────────────────────────────────

type KpiIconName = NonNullable<KpiDefinition["icon"]>;

const ICON_MAP: Record<KpiIconName, React.FC<LucideProps>> = {
  Hash,
  TrendingUp,
  BarChart3,
  DollarSign,
  Percent,
  Activity,
  Target,
  Users,
  ShoppingCart,
  Package,
};

/** Returns the default icon component for a given aggregate operation. */
function defaultIconForAggregate(
  aggregate: "count" | "sum" | "avg",
): React.FC<LucideProps> {
  if (aggregate === "count") return Hash;
  if (aggregate === "sum") return TrendingUp;
  return BarChart3;
}

function KpiIcon({
  kpi,
  className,
}: {
  kpi: KpiDefinition;
  className?: string;
}) {
  const IconComponent = kpi.icon
    ? (ICON_MAP[kpi.icon] ?? defaultIconForAggregate(kpi.metric.aggregate))
    : defaultIconForAggregate(kpi.metric.aggregate);

  return <IconComponent size={20} aria-hidden="true" className={className} />;
}

interface KpiTileProps {
  kpi: KpiDefinition;
}

/**
 * Self-contained KPI tile. Fetches its own data, computes the aggregate,
 * and renders value / attainment / delta in isolation via StatTile.
 */
export function KpiTile({ kpi }: KpiTileProps) {
  const { rows, comparisonRows, isLoading, error, capped, total } = useKpiData(kpi);

  const value = React.useMemo(
    () => aggregate(rows, kpi.metric.field, kpi.metric.aggregate),
    [rows, kpi.metric.field, kpi.metric.aggregate],
  );

  const comparisonValue = React.useMemo(
    () =>
      comparisonRows !== null
        ? aggregate(comparisonRows, kpi.metric.field, kpi.metric.aggregate)
        : null,
    [comparisonRows, kpi.metric.field, kpi.metric.aggregate],
  );

  const formatted = React.useMemo(
    () => formatValue(value, kpi.format),
    [value, kpi.format],
  );

  // Attainment: actual / target × 100, cap at 100%.
  const attainmentPct =
    kpi.target !== undefined && kpi.target > 0
      ? (value / kpi.target) * 100
      : null;

  // Delta % = (actual − comparison) / |comparison| × 100.
  const deltaPct =
    comparisonValue !== null && comparisonValue !== 0
      ? ((value - comparisonValue) / Math.abs(comparisonValue)) * 100
      : null;

  const isGoodDelta =
    deltaPct !== null &&
    (kpi.direction === "higher-is-better"
      ? deltaPct > 0
      : deltaPct < 0);

  const tone = kpi.tone ?? "primary";

  const useBullet = kpi.targetDisplay === "bullet" && kpi.target !== undefined;

  const sparkSeries = React.useMemo(
    () => (kpi.showSpark ? buildSparkSeries(rows, kpi.metric.field, kpi.metric.aggregate) : []),
    [kpi.showSpark, rows, kpi.metric.field, kpi.metric.aggregate],
  );

  // Sub-label shown below the value when there is no comparison period but rows exist.
  const subLabel =
    !isLoading && !error && rows.length > 0
      ? aggregateCaption(kpi, rows.length)
      : undefined;

  // Target formatted string appended to attainment label so consumers can see the goal.
  const attainmentLabel =
    attainmentPct !== null && kpi.target !== undefined
      ? `of target (${formatValue(kpi.target, kpi.format)})`
      : "of target";

  const tileIcon = (
    <KpiIcon
      kpi={kpi}
      className="h-5 w-5"
    />
  );

  return (
    <div data-testid={`kpi-tile-${kpi.id}`}>
      {isLoading ? (
        <div
          className="dq-card flex min-h-[124px] flex-col gap-3"
          role="status"
          aria-label="Loading"
        >
          <p className="dq-card-title truncate">{kpi.label}</p>
          <div className="flex flex-col gap-2">
            <Skeleton className="h-7 w-2/3" />
            <Skeleton className="h-3 w-full" />
          </div>
        </div>
      ) : error ? (
        <div
          className="dq-card flex min-h-[124px] flex-col gap-3"
          data-testid={`kpi-tile-error-${kpi.id}`}
          role="alert"
        >
          <p className="dq-card-title truncate">{kpi.label}</p>
          <div className="rounded-[var(--radius-button)] border border-[var(--color-danger-border)] bg-[var(--color-danger-surface)] p-2 text-xs text-[var(--color-danger-text)]">
            Failed to load
          </div>
        </div>
      ) : rows.length === 0 ? (
        <div
          className="dq-card flex min-h-[124px] flex-col gap-2"
          data-testid={`kpi-tile-empty-${kpi.id}`}
        >
          <p className="dq-card-title truncate">{kpi.label}</p>
          <EmptyState
            icon={tileIcon}
            title="No data yet"
            description="Records matching this KPI's filters haven't been created."
            className="flex-1 gap-2 py-2"
          />
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {capped && (
            <Alert
              tone="warning"
              variant="compact"
              data-testid={`kpi-cap-banner-${kpi.id}`}
            >
              Showing first {formatNumber(rows.length)} of {formatNumber(total ?? rows.length)} — totals are partial
            </Alert>
          )}
          <StatTile
            label={kpi.label}
            value={formatted}
            tone={tone}
            icon={tileIcon}
            {...(subLabel !== undefined && { subLabel })}
            {...(deltaPct !== null && {
              trend: {
                value: parseFloat(deltaPct.toFixed(1)),
                label: "vs prior",
              },
            })}
            {...(sparkSeries.length > 1 && {
              sparkline: (
                <Sparkline
                  data={sparkSeries}
                  showDot
                  color={
                    deltaPct !== null && deltaPct < 0
                      ? "var(--color-danger)"
                      : "var(--color-success)"
                  }
                />
              ),
            })}
            {...(useBullet && {
              sparkline: (
                <div data-testid={`kpi-bullet-${kpi.id}`}>
                  <BulletChart
                    value={value}
                    target={kpi.target!}
                    max={Math.max(value, kpi.target!) * 1.2}
                    valueLabel={`${formatValue(value, kpi.format)} / ${formatValue(kpi.target!, kpi.format)}`}
                  />
                </div>
              ),
            })}
            {...(attainmentPct !== null && !useBullet && {
              attainment: Math.round(Math.min(attainmentPct, 100)),
              attainmentLabel,
              attainmentTestId: `kpi-attainment-${kpi.id}`,
            })}
            attainmentColorMode={kpi.direction ?? "higher-is-better"}
            {...(deltaPct !== null && { deltaIsGood: isGoodDelta, deltaTestId: `kpi-delta-${kpi.id}` })}
            valueTestId={`kpi-value-${kpi.id}`}
            className="min-h-[124px]"
          />
        </div>
      )}
    </div>
  );
}
