import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import { formatCurrency, formatNumber, formatPercent } from "@dbp/ui";

type AggregateOp = "count" | "sum" | "avg";

/**
 * Computes count / sum / avg of a numeric field across the provided rows.
 * Non-numeric values coerce to 0 so a partially-typed entity does not
 * corrupt the result.
 */
export function aggregate(
  rows: EntityRecord<EntityData>[],
  field: string | undefined,
  op: AggregateOp,
): number {
  if (op === "count") return rows.length;

  if (!field) return 0;

  const nums = rows.map((r) => {
    const v = (r.data as Record<string, unknown>)[field];
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  });

  if (nums.length === 0) return 0;

  const total = nums.reduce((acc, n) => acc + n, 0);
  return op === "sum" ? total : total / nums.length;
}

const SPARK_BUCKETS = 8;

/**
 * Buckets rows into up to `SPARK_BUCKETS` equal time windows by `createdAt`
 * and aggregates each bucket the same way as the KPI's own metric — a
 * derived trend of the tile's own data, never fabricated. Returns an empty
 * array when there are fewer than 2 rows or all rows share one instant
 * (nothing meaningful to plot).
 */
export function buildSparkSeries(
  rows: EntityRecord<EntityData>[],
  field: string | undefined,
  op: AggregateOp,
): number[] {
  if (rows.length < 2) return [];

  const timestamps = rows
    .map((r) => Date.parse(r.createdAt))
    .filter((t) => Number.isFinite(t));
  if (timestamps.length < 2) return [];

  const min = Math.min(...timestamps);
  const max = Math.max(...timestamps);
  if (max === min) return [];

  const bucketRows: EntityRecord<EntityData>[][] = Array.from({ length: SPARK_BUCKETS }, () => []);
  const span = max - min;

  for (const row of rows) {
    const t = Date.parse(row.createdAt);
    if (!Number.isFinite(t)) continue;
    const bucketIndex = Math.min(
      SPARK_BUCKETS - 1,
      Math.floor(((t - min) / span) * SPARK_BUCKETS),
    );
    bucketRows[bucketIndex]!.push(row);
  }

  return bucketRows.map((bucket) => aggregate(bucket, field, op));
}

type FormatStyle = "number" | "currency" | "percent";

/** Threshold above which numbers are displayed in compact notation. */
const COMPACT_THRESHOLD = 10_000;

/**
 * Formats a KPI value for tile display.
 * Uses compact notation for large values (>=10,000) to prevent clipping.
 */
export function formatValue(value: number, style: FormatStyle): string {
  const compact = Math.abs(value) >= COMPACT_THRESHOLD;
  switch (style) {
    case "currency":
      return formatCurrency(value, "USD", { compact });
    case "percent":
      // KPI percent values are passed as 0–100 (not 0–1 ratio)
      return formatPercent(value / 100);
    default:
      return formatNumber(value, { compact });
  }
}
