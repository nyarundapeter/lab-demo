import * as React from "react";
import { Clock, CheckCircle2, ArrowRight, RefreshCw } from "lucide-react";
import { Alert, Avatar, Badge, Button, FormField, Input, OrgBadge, passwordScore, PwField, StrengthMeter } from "@dbp/ui";
import { AcceptCardConfig, type AcceptCardConfigInput } from "./types.js";

export interface AcceptCardProps {
  config: AcceptCardConfigInput;
  /** Password path: called with the name + password the recipient entered. */
  onAccept?: (input: { name: string; password: string }) => void;
  /** SSO path: called when the recipient accepts and continues with SSO. */
  onContinueWithSso?: () => void;
  /** Expired state: request a fresh invitation. */
  onRequestNewInvitation?: () => void;
  /** Used state: route to sign-in. */
  onSignIn?: () => void;
}

/**
 * AcceptCard (R6: `first-login-setpassword`) — the public, unauthenticated
 * invitation-accept card: set-password and SSO paths in one card, plus
 * honest expired/already-used edge states. Port of `identity-invite.jsx`'s
 * `AcceptCard`. Meant to be rendered as the child of `AuthLayout`
 * (`@dbp/ui/auth-layout`), which owns the surrounding split panel — this
 * component only renders the card's own content.
 */
export default function AcceptCard({ config, onAccept, onContinueWithSso, onRequestNewInvitation, onSignIn }: AcceptCardProps) {
  const parsed = AcceptCardConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="AcceptCard — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const c = parsed.data;

  if (c.state === "expired") {
    return (
      <div className="flex flex-col gap-4 text-center">
        <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-[var(--radius-card)] bg-[var(--color-surface)]">
          <Clock size={20} className="text-[var(--color-text-muted)]" aria-hidden="true" />
        </span>
        <h1 className="text-lg font-semibold text-primary">This invitation has expired</h1>
        <p className="text-sm text-[var(--color-text-muted)]">
          Your invitation to join <strong className="text-primary">{c.orgName}</strong> is no longer valid. Ask{" "}
          {c.inviterName} to send a new one.
        </p>
        <Button size="lg" onClick={onRequestNewInvitation} data-testid="accept-card-request-new">
          <RefreshCw size={15} aria-hidden="true" />
          Request a new invitation
        </Button>
        <p className="text-xs text-[var(--color-text-disabled)]">Sent to {c.inviteeEmail}</p>
      </div>
    );
  }

  if (c.state === "used") {
    return (
      <div className="flex flex-col gap-4 text-center">
        <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-[var(--radius-card)] bg-[var(--color-success-surface)]">
          <CheckCircle2 size={20} className="text-[var(--color-success)]" aria-hidden="true" />
        </span>
        <h1 className="text-lg font-semibold text-primary">You&rsquo;re already a member</h1>
        <p className="text-sm text-[var(--color-text-muted)]">
          This invitation has already been accepted. Your account for{" "}
          <strong className="text-primary">{c.orgName}</strong> is ready.
        </p>
        <Button size="lg" onClick={onSignIn} data-testid="accept-card-sign-in">
          Sign in to continue
          <ArrowRight size={15} aria-hidden="true" />
        </Button>
      </div>
    );
  }

  return <ValidAcceptCard config={c} onAccept={onAccept} onContinueWithSso={onContinueWithSso} />;
}

function ValidAcceptCard({
  config,
  onAccept,
  onContinueWithSso,
}: {
  config: AcceptCardConfig;
  onAccept?: ((input: { name: string; password: string }) => void) | undefined;
  onContinueWithSso?: (() => void) | undefined;
}) {
  const [mode, setMode] = React.useState<"password" | "sso">("password");
  const [name, setName] = React.useState(config.inviteeName);
  const [password, setPassword] = React.useState("");
  const score = password ? passwordScore(password) : undefined;

  return (
    <div className="flex flex-col gap-5" data-testid="accept-card">
      <OrgBadge name={config.orgName} />
      <h1 className="text-lg font-semibold text-primary">Join {config.orgName}</h1>
      <div className="flex items-center gap-2.5 rounded-[var(--radius-card)] border border-[color-mix(in_srgb,var(--color-primary)_15%,transparent)] bg-[color-mix(in_srgb,var(--color-primary)_5%,transparent)] px-3 py-2.5">
        <Avatar name={config.inviterName} size="sm" />
        <p className="text-xs leading-snug">
          <strong className="text-primary">{config.inviterName}</strong> invited you as a{" "}
          <Badge tone="navy" size="sm">{config.roleName}</Badge>
        </p>
      </div>

      {mode === "password" ? (
        <div className="flex flex-col gap-4">
          <FormField label="Your name" required>
            <Input value={name} onChange={(e) => setName(e.target.value)} data-testid="accept-card-name" />
          </FormField>
          <FormField label="Create a password" required helperText="At least 12 characters.">
            <PwField value={password} onChange={(e) => setPassword(e.target.value)} data-testid="accept-card-password" />
          </FormField>
          {password && <StrengthMeter score={score} />}
          <Button
            size="lg"
            className="w-full"
            disabled={!name || (score ?? 0) < 4}
            onClick={() => onAccept?.({ name, password })}
            data-testid="accept-card-submit"
          >
            Accept &amp; create account
          </Button>
          {config.allowSso && (
            <>
              <div className="flex items-center gap-3 text-xs text-[var(--color-text-disabled)]">
                <span className="h-px flex-1 bg-[var(--color-border-default)]" />or<span className="h-px flex-1 bg-[var(--color-border-default)]" />
              </div>
              <Button variant="outline" className="w-full" onClick={() => setMode("sso")} data-testid="accept-card-use-sso">
                Continue with {config.ssoProviderName}
              </Button>
            </>
          )}
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <Alert tone="info" title="Single sign-on">
            {config.orgName} uses {config.ssoProviderName}. You&rsquo;ll sign in with your work account — no password
            to manage.
          </Alert>
          <Button className="w-full" onClick={onContinueWithSso} data-testid="accept-card-continue-sso">
            Accept &amp; continue with {config.ssoProviderName}
          </Button>
          <Button variant="ghost" className="w-full" onClick={() => setMode("password")} data-testid="accept-card-use-password">
            Use a password instead
          </Button>
        </div>
      )}

      <p className="text-center text-xs text-[var(--color-text-disabled)]">
        Invitation for {config.inviteeEmail} · expires in {config.expiresInDays} days
      </p>
    </div>
  );
}

export type { AcceptCardConfig, AcceptCardConfigInput } from "./types.js";
