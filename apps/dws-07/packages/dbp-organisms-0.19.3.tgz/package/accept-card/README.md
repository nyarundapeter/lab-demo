# @dbp/organisms/accept-card

**registryId:** `APP.F51` (placeholder — assigned during central registration)

Public invitation-accept card: password or SSO acceptance, plus expired/already-used edge
states. See `FEATURE.md` for composition with `@dbp/ui/auth-layout`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`AcceptCardConfig` — Zod schema exported from `types.ts` (source of truth). Action callbacks
(`onAccept`, `onContinueWithSso`, `onRequestNewInvitation`, `onSignIn`) are plain props, not part
of the Zod config, same pattern as `record-drawer`.

## Consumed by
Not yet wired — no `FEATURE_COMPONENT` route in `scripts/scaffold-solution.mjs` targets this
organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/accept-card` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
