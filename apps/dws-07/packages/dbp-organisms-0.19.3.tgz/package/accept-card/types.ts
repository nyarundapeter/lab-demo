import { z } from "zod";

export const AcceptCardState = z.enum(["valid", "expired", "used"]);
export type AcceptCardState = z.infer<typeof AcceptCardState>;

export const AcceptCardConfig = z.object({
  /** Which state of the invitation link this card renders. */
  state: AcceptCardState.default("valid"),
  orgName: z.string().min(1),
  inviterName: z.string().min(1),
  roleName: z.string().min(1),
  inviteeEmail: z.string().email(),
  /** Prefilled from the invite payload — the recipient can still edit it. */
  inviteeName: z.string().default(""),
  expiresInDays: z.number().int().positive().default(7),
  ssoProviderName: z.string().default("Microsoft SSO"),
  allowSso: z.boolean().default(true),
});
export type AcceptCardConfig = z.infer<typeof AcceptCardConfig>;
export type AcceptCardConfigInput = z.input<typeof AcceptCardConfig>;
