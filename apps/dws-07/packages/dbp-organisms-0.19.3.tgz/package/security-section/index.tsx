import React from "react";
import { Shield, RefreshCw, X, Lock, Monitor, Smartphone, Server } from "lucide-react";
import { Alert, Badge, Button, Card, DestructiveConfirmDialog, FormField, PwField, StrengthMeter } from "@dbp/ui";
import { SecuritySectionConfig, type SecuritySectionConfigInput, type SecuritySession } from "./types.js";
import { changePassword, revokeSession, revokeAllOtherSessions } from "./mock-security-client.js";

export type SecuritySectionProps = SecuritySectionConfigInput & {
  /** Launches the MFA enrollment flow (`@dbp/organisms/mfa-enrol`, composed by the caller). */
  onManageMfa?: () => void;
};

/**
 * Security section — password change, two-factor status, and active
 * sessions with per-device revoke. Port of `identity-account.jsx`'s
 * `SecuritySection`.
 *
 * **Not wired to a real service, in full.** The plan
 * (`wave3-build-plan.md` Family 4g) claimed the password-change half was
 * "fully reusable against real primitives" — that is **incorrect**, verified
 * by direct read: `packages/stack/platform-services/auth` has no
 * change-password mutation anywhere (only `login` authenticates with a
 * password). The sessions-table half is also blocked, as the plan
 * predicted: `server/session-store.ts` is a cookie-backed single-session
 * store with no listing query. Both halves call a typed mock client
 * (`mock-security-client.ts`) — see `wave3-build-plan.md`'s "Blocked-row
 * build policy" (Amendment A).
 */
export default function SecuritySection(rawConfig: SecuritySectionProps) {
  const { onManageMfa, ...configInput } = rawConfig;
  const parsed = SecuritySectionConfig.safeParse(configInput);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="SecuritySection — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <SecuritySectionInner config={parsed.data} onManageMfa={onManageMfa} />;
}

/** Simple local heuristic (length + character variety) — deliberately not owned by StrengthMeter itself. */
function pwScore(pw: string): 0 | 1 | 2 | 3 | 4 {
  if (pw.length === 0) return 0;
  if (pw.length < 8) return 1;
  let variety = 0;
  if (/[a-z]/.test(pw)) variety++;
  if (/[A-Z]/.test(pw)) variety++;
  if (/[0-9]/.test(pw)) variety++;
  if (/[^a-zA-Z0-9]/.test(pw)) variety++;
  if (variety <= 1) return 1;
  if (variety === 2) return 2;
  if (variety === 3) return pw.length >= 12 ? 4 : 3;
  return 4;
}

function deviceIcon(device: string) {
  if (/iphone|ipad|android/i.test(device)) return Smartphone;
  if (/macbook|mac|pc|windows/i.test(device)) return Monitor;
  return Server;
}

function SecuritySectionInner({ config, onManageMfa }: { config: SecuritySectionConfig; onManageMfa?: (() => void) | undefined }) {
  const [currentPassword, setCurrentPassword] = React.useState("");
  const [newPassword, setNewPassword] = React.useState("");
  const [confirmPassword, setConfirmPassword] = React.useState("");
  const [pwBusy, setPwBusy] = React.useState(false);
  const [pwSaved, setPwSaved] = React.useState(false);
  const [pwError, setPwError] = React.useState<string | null>(null);

  const [sessions, setSessions] = React.useState<SecuritySession[]>(config.sessions);
  const [revokeTarget, setRevokeTarget] = React.useState<SecuritySession | null>(null);
  const [signOutAll, setSignOutAll] = React.useState(false);
  const [turnOff2fa, setTurnOff2fa] = React.useState(false);
  const [sessionBusy, setSessionBusy] = React.useState(false);

  const mismatch = confirmPassword.length > 0 && confirmPassword !== newPassword;
  const score = pwScore(newPassword);

  async function updatePassword() {
    setPwBusy(true);
    setPwError(null);
    try {
      await changePassword({ currentPassword, newPassword });
      setPwSaved(true);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setTimeout(() => setPwSaved(false), 2000);
    } catch {
      setPwError("Couldn't update your password. Try again.");
    } finally {
      setPwBusy(false);
    }
  }

  async function confirmRevoke() {
    if (!revokeTarget) return;
    setSessionBusy(true);
    await revokeSession(revokeTarget.id);
    setSessionBusy(false);
    setSessions((s) => s.filter((x) => x.id !== revokeTarget.id));
    setRevokeTarget(null);
  }

  async function confirmSignOutAll() {
    setSessionBusy(true);
    await revokeAllOtherSessions();
    setSessionBusy(false);
    setSessions((s) => s.filter((x) => x.current));
    setSignOutAll(false);
  }

  return (
    <div className="flex max-w-[720px] flex-col gap-8">
      {/* Password */}
      <section>
        <div className="mb-5">
          <SecHead title="Password" desc="Update the password you use to sign in." />
        </div>
        <Card className="p-5 shadow-none">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <FormField label="Current password">
              <PwField value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
            </FormField>
            <div />
            <FormField label="New password">
              <PwField value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            </FormField>
            <FormField
              label="Confirm new password"
              {...(mismatch && { error: "Passwords don't match" })}
            >
              <PwField value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
            </FormField>
          </div>
          {newPassword && (
            <div className="mt-3.5">
              <StrengthMeter score={score} />
            </div>
          )}
          {pwError && (
            <p role="alert" className="mt-3 text-xs text-danger">
              {pwError}
            </p>
          )}
          <div className="mt-4 flex items-center gap-3">
            <Button
              type="button"
              disabled={pwBusy || !currentPassword || !newPassword || mismatch}
              onClick={updatePassword}
            >
              {pwBusy ? "Updating…" : "Update password"}
            </Button>
            {pwSaved && <span className="text-xs font-medium text-[var(--color-success-text)]">Password updated</span>}
          </div>
        </Card>
      </section>

      {/* Two-factor authentication */}
      <section>
        <div className="mb-5">
          <SecHead title="Two-factor authentication" desc="Add a second step to your sign-in for extra protection." />
        </div>
        <Card className="overflow-hidden p-0 shadow-none">
          <div className="flex items-center gap-3.5 p-5">
            <span
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[var(--radius-button)]"
              style={{ background: config.mfaEnabled ? "var(--color-success-surface)" : "var(--color-surface)" }}
            >
              <Shield size={20} className={config.mfaEnabled ? "text-[var(--color-success-text)]" : "text-[var(--color-text-muted)]"} />
            </span>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold">Authenticator app</span>
                <Badge tone={config.mfaEnabled ? "success" : "gray"}>{config.mfaEnabled ? "On" : "Off"}</Badge>
              </div>
              <div className="mt-0.5 text-xs text-[var(--color-text-muted)]">
                {config.mfaEnabled
                  ? `Added ${config.mfaAddedLabel ?? "recently"}${
                      config.backupCodesRemaining !== undefined
                        ? ` · ${config.backupCodesRemaining} of 10 backup codes remaining`
                        : ""
                    }`
                  : "Not set up yet"}
              </div>
            </div>
            <Button type="button" variant="outline" size="sm" onClick={onManageMfa}>
              {config.mfaEnabled ? "Manage" : "Set up"}
            </Button>
          </div>
          {config.mfaEnabled && (
            <div className="flex gap-2 border-t border-[var(--color-border-subtle)] p-3">
              <Button type="button" variant="ghost" size="sm">
                <RefreshCw size={13} />
                Regenerate backup codes
              </Button>
              <Button type="button" variant="ghost" size="sm" className="text-danger" onClick={() => setTurnOff2fa(true)}>
                <X size={13} />
                Turn off 2FA
              </Button>
            </div>
          )}
        </Card>
      </section>

      {/* Active sessions */}
      <section>
        <div className="mb-5 flex items-end justify-between gap-4">
          <SecHead title="Active sessions" desc="Devices currently signed in to your account. Revoke any you don't recognise." />
          <Button type="button" variant="outline" size="sm" className="shrink-0 border-[var(--color-danger)] text-danger" onClick={() => setSignOutAll(true)}>
            <Lock size={13} />
            Sign out everywhere
          </Button>
        </div>
        <div className="overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border-default)]">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)] text-xs text-[var(--color-text-muted)]">
              <tr>
                <th className="px-3.5 py-2.5 font-medium">Device</th>
                <th className="px-3.5 py-2.5 font-medium">Location</th>
                <th className="px-3.5 py-2.5 font-medium">IP address</th>
                <th className="px-3.5 py-2.5 font-medium">Last active</th>
                <th className="px-3.5 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {sessions.map((s) => {
                const DeviceIcon = deviceIcon(s.device);
                return (
                  <tr key={s.id} className="border-t border-[var(--color-border-subtle)]">
                    <td className="px-3.5 py-2.5">
                      <div className="flex items-center gap-2.5">
                        <DeviceIcon size={16} className="text-[var(--color-text-muted)]" />
                        <div>
                          <div className="flex items-center gap-1.5 font-medium">
                            {s.device}
                            {s.current && <Badge tone="success">This device</Badge>}
                          </div>
                          <div className="text-xs text-[var(--color-text-muted)]">
                            {s.browser} · {s.os}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3.5 py-2.5 text-[var(--color-text-muted)]">{s.location}</td>
                    <td className="px-3.5 py-2.5 font-mono text-xs text-[var(--color-text-muted)]">{s.ip}</td>
                    <td
                      className={
                        s.current
                          ? "px-3.5 py-2.5 font-semibold text-[var(--color-success-text)]"
                          : "px-3.5 py-2.5 text-[var(--color-text-muted)]"
                      }
                    >
                      {s.lastActiveLabel}
                    </td>
                    <td className="px-3.5 py-2.5 text-right">
                      {s.current ? (
                        <span className="text-xs text-[var(--color-text-muted)]">—</span>
                      ) : (
                        <Button type="button" variant="link" className="h-auto text-xs font-medium text-danger" onClick={() => setRevokeTarget(s)}>
                          Revoke
                        </Button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      <DestructiveConfirmDialog
        open={revokeTarget !== null}
        onOpenChange={(open) => !open && setRevokeTarget(null)}
        title="Revoke this session?"
        description={revokeTarget ? `"${revokeTarget.device}" will be signed out immediately.` : ""}
        confirmLabel="Revoke session"
        busy={sessionBusy}
        onConfirm={confirmRevoke}
      />
      <DestructiveConfirmDialog
        open={signOutAll}
        onOpenChange={setSignOutAll}
        title="Sign out everywhere?"
        description="Every other device will be signed out immediately. This device stays signed in."
        confirmLabel="Sign out everywhere"
        busy={sessionBusy}
        onConfirm={confirmSignOutAll}
      />
      <DestructiveConfirmDialog
        open={turnOff2fa}
        onOpenChange={setTurnOff2fa}
        title="Turn off two-factor authentication?"
        description="Your account will no longer require a second step at sign-in."
        confirmLabel="Turn off 2FA"
        onConfirm={() => setTurnOff2fa(false)}
      />
    </div>
  );
}

function SecHead({ title, desc }: { title: string; desc?: string }) {
  return (
    <div>
      <h2 className="text-lg font-semibold">{title}</h2>
      {desc && <p className="mt-1 text-sm leading-relaxed text-[var(--color-text-muted)]">{desc}</p>}
    </div>
  );
}
