# @dbp/organisms/security-section

**registryId:** `APP.F73` (placeholder — assigned during central registration)

Password change + 2FA status + active-sessions table. See `FEATURE.md` — **not wired to a real
service, both halves** (corrects a wrong claim in the wave3 plan about password-change).

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`SecuritySectionConfig` — Zod schema exported from `types.ts` (source of truth). The default
export's prop type (`SecuritySectionProps`) adds an `onManageMfa` callback.

## Consumed by
Not yet wired — Storybook-only until PS.AUTH gains a change-password mutation and a
session-listing query. Composed by `AccountArea`'s "Security" tab.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/security-section` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
