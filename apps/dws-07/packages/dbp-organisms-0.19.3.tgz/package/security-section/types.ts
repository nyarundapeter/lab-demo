import { z } from "zod";

export const SecuritySession = z.object({
  id: z.string().min(1),
  device: z.string().min(1),
  browser: z.string().min(1),
  os: z.string().min(1),
  location: z.string().min(1),
  ip: z.string().min(1),
  lastActiveLabel: z.string().min(1),
  /** This is the session the request is coming from — can't be individually revoked. */
  current: z.boolean().default(false),
});
export type SecuritySession = z.infer<typeof SecuritySession>;

export const SecuritySectionConfig = z.object({
  sessions: z.array(SecuritySession).min(1),
  mfaEnabled: z.boolean().default(false),
  mfaAddedLabel: z.string().optional(),
  backupCodesRemaining: z.number().int().nonnegative().optional(),
});

export type SecuritySectionConfig = z.infer<typeof SecuritySectionConfig>;
export type SecuritySectionConfigInput = z.input<typeof SecuritySectionConfig>;
