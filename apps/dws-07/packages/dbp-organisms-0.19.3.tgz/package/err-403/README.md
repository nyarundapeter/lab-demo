# @dbp/organisms/err-403

**registryId:** `APP.F59` (placeholder — assigned during central registration)

Access-denied page naming who can grant access. See `FEATURE.md` — config-driven granters list,
no PS.RBAC reverse-lookup exists to fetch it from.

**Tier:** organism (light)

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`Err403Config` — Zod schema exported from `types.ts` (source of truth). The default export's
prop type (`Err403Props`) adds `onRequestAccess`/`onGoBack` callbacks.

## Consumed by
Not yet wired — no route-level permission-denied page exists yet to mount this.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/err-403` via plain pnpm workspace resolution
(`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
