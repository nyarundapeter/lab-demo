import { z } from "zod";

export const Err403Granter = z.object({
  name: z.string().min(1),
  role: z.string().min(1),
});
export type Err403Granter = z.infer<typeof Err403Granter>;

export const Err403Config = z.object({
  /** The resource/page the user was denied, e.g. "Reports". */
  resourceLabel: z.string().min(1),
  /** Admins/owners who could grant access — the real data need this row exists for. */
  granters: z.array(Err403Granter).min(1),
});

export type Err403Config = z.infer<typeof Err403Config>;
export type Err403ConfigInput = z.input<typeof Err403Config>;
