import React from "react";
import { Lock, Send, ChevronLeft } from "lucide-react";
import { Alert, Avatar, Button, Card } from "@dbp/ui";
import { Err403Config, type Err403ConfigInput } from "./types.js";

export type Err403Props = Err403ConfigInput & {
  onRequestAccess?: () => void;
  onGoBack?: () => void;
};

/**
 * 403 — Forbidden. Rather than a dead end, names the specific resource and
 * lists the admins/owners who can grant access, with a one-click request.
 * Port of `identity-errors.jsx`'s `Err403`.
 *
 * "Light organism" — the `granters` list is the real data need this row
 * exists for (per `wave3-build-plan.md`'s note); it's injected config here
 * rather than fetched (no PS.RBAC "who holds role X" reverse-lookup exists
 * to fetch it from — `admin.ts`'s user/role/group queries are all
 * forward-lookups). The only owned state is the local request-access toggle.
 */
export default function Err403(rawConfig: Err403Props) {
  const { onRequestAccess, onGoBack, ...configInput } = rawConfig;
  const parsed = Err403Config.safeParse(configInput);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="Err403 — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <Err403Inner config={parsed.data} onRequestAccess={onRequestAccess} onGoBack={onGoBack} />;
}

function Err403Inner({
  config,
  onRequestAccess,
  onGoBack,
}: {
  config: Err403Config;
  onRequestAccess?: (() => void) | undefined;
  onGoBack?: (() => void) | undefined;
}) {
  const [requested, setRequested] = React.useState(false);

  function requestAccess() {
    setRequested(true);
    onRequestAccess?.();
  }

  return (
    <div className="px-6 py-12 text-center">
      <span className="mx-auto mb-5 flex h-[52px] w-[52px] items-center justify-center rounded-full bg-[var(--color-warning-surface)]">
        <Lock size={26} className="text-[var(--color-warning-text)]" />
      </span>
      <div className="mb-1.5 text-sm font-bold tracking-[0.08em] text-[var(--color-text-muted)]">
        403 · FORBIDDEN
      </div>
      <h1 className="mb-2 text-xl font-semibold">You don&apos;t have access to {config.resourceLabel}</h1>
      <p className="mb-6 text-sm leading-relaxed text-[var(--color-text-muted)]">
        {config.resourceLabel} is limited to admins and owners in this workspace. Ask one of the
        people below to grant you access.
      </p>

      {requested ? (
        <Alert tone="success" title="Access requested">
          We&apos;ve notified your admins. You&apos;ll get an email when someone responds.
        </Alert>
      ) : (
        <Card className="mb-5 p-2 text-left shadow-none">
          {config.granters.map((g, i) => (
            <div
              key={g.name}
              className={
                i < config.granters.length - 1
                  ? "flex items-center gap-2.5 border-b border-[var(--color-border-subtle)] px-2.5 py-2.5"
                  : "flex items-center gap-2.5 px-2.5 py-2.5"
              }
            >
              <Avatar name={g.name} size="sm" />
              <div>
                <div className="text-sm font-medium">{g.name}</div>
                <div className="text-xs capitalize text-[var(--color-text-muted)]">{g.role}</div>
              </div>
            </div>
          ))}
        </Card>
      )}

      <div className="flex justify-center gap-2.5">
        {!requested && (
          <Button type="button" onClick={requestAccess}>
            <Send size={14} />
            Request access
          </Button>
        )}
        <Button type="button" variant="outline" onClick={onGoBack}>
          <ChevronLeft size={14} />
          Go back
        </Button>
      </div>
    </div>
  );
}
