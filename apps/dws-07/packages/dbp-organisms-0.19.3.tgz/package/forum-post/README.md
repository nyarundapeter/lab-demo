# @dbp/organisms/forum-post

**registryId:** `APP.F60` (placeholder — assigned during central registration)

A single forum discussion or Q&A post with replies, upvoting, and accept-answer.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ForumPostConfig` — Zod schema exported from `types.ts` (source of truth). The post and its
replies arrive fully resolved via config; no PS.DATA fetch is owned by this organism (see
FEATURE.md).

## Consumed by
Bespoke import — mounted at a forum post detail route/drawer, reached from an `entity-list`
configured for forum-post rows (see FEATURE.md's `ForumsPage` composition note).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/forum-post` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.
