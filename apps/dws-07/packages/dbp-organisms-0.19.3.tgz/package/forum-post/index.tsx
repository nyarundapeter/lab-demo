import * as React from "react";
import { ArrowUp, CheckCircle2, Eye } from "lucide-react";
import { Alert, Avatar, Badge, Button, ActivityComposer } from "@dbp/ui";
import type { ActivityDraft, ActivityTimelineConfig } from "@dbp/ui";
import { ForumPostConfig, type ForumReply, type ForumPostConfigInput } from "./types.js";

export interface ForumPostProps extends ForumPostConfigInput {
  onAcceptAnswer?: (replyId: string) => void;
  onReply?: (body: string) => void;
}

const composerConfig: ActivityTimelineConfig = {
  activityTypes: {},
  mentions: true,
  tags: false,
  attachments: false,
};

/**
 * APP.F60 — Forum Post (registry id assigned during central registration)
 *
 * collaboration-system/forums.jsx `ForumPost`/`ForumReply`. Receives a
 * fully-resolved post + reply list via config (no PS.DATA fetch owned here
 * — see types.ts doc comment); owns local upvote/accept-answer UI state,
 * reuses `ActivityComposer` for the reply box.
 */
export default function ForumPost(rawConfig: ForumPostProps) {
  const { onAcceptAnswer, onReply, ...rest } = rawConfig;
  const parseResult = ForumPostConfig.safeParse(rest);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="ForumPost configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>{e.path.join(".") || "root"}: {e.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <ForumPostInner
      config={parseResult.data}
      {...(onAcceptAnswer !== undefined && { onAcceptAnswer })}
      {...(onReply !== undefined && { onReply })}
    />
  );
}

function ForumPostInner({
  config,
  onAcceptAnswer,
  onReply,
}: {
  config: ForumPostConfig;
  onAcceptAnswer?: (replyId: string) => void;
  onReply?: (body: string) => void;
}) {
  const { post } = config;
  const [replies, setReplies] = React.useState<ForumReply[]>(config.replies);
  const [votes, setVotes] = React.useState<Record<string, number>>({});

  React.useEffect(() => setReplies(config.replies), [config.replies]);

  const sorted = [...replies].sort((a, b) => (b.accepted ? 1 : 0) - (a.accepted ? 1 : 0));
  const answered = post.isQuestion && replies.some((r) => r.accepted);

  function accept(replyId: string) {
    setReplies((rs) => rs.map((r) => ({ ...r, accepted: r.id === replyId ? !r.accepted : false })));
    onAcceptAnswer?.(replyId);
  }

  function upvote(replyId: string) {
    setVotes((v) => ({ ...v, [replyId]: (v[replyId] ?? 0) + 1 }));
  }

  function addReply(body: string) {
    const reply: ForumReply = {
      id: `r${Date.now()}`,
      author: { id: config.currentUserId, name: "You" },
      body,
      createdAtLabel: "just now",
      votes: 0,
      accepted: false,
    };
    setReplies((rs) => [...rs, reply]);
    onReply?.(body);
  }

  return (
    <div data-testid="forum-post">
      <div className="mb-2.5 flex flex-wrap items-center gap-2">
        <span
          className="inline-flex h-[19px] items-center rounded-[5px] px-2 text-xs font-semibold"
          style={{
            background: `color-mix(in srgb, ${post.categoryColor ?? "var(--color-info)"} 12%, transparent)`,
            color: post.categoryColor ?? "var(--color-info)",
          }}
        >
          {post.category}
        </span>
        {post.isQuestion && <Badge tone="gray">Question</Badge>}
        {answered && (
          <Badge tone="success">
            <CheckCircle2 size={12} aria-hidden="true" /> Answered
          </Badge>
        )}
      </div>

      <h1 className="mb-3 text-xl font-bold leading-tight">{post.title}</h1>

      <div className="mb-4 flex items-center gap-2.5 text-xs text-[var(--color-text-muted)]">
        <Avatar name={post.author.name} size="sm" {...(post.author.avatarSrc !== undefined && { src: post.author.avatarSrc })} />
        <span className="font-semibold text-[var(--color-text)]">{post.author.name}</span>
        <span>· {post.createdAtLabel}</span>
        <span className="inline-flex items-center gap-1">
          <Eye size={13} aria-hidden="true" /> {post.viewCount} views
        </span>
      </div>

      <p className="mb-6 whitespace-pre-wrap text-sm leading-relaxed text-[var(--color-text)]">{post.body}</p>

      <div className="mb-5 text-sm font-semibold" data-testid="reply-count">
        {replies.length} {replies.length === 1 ? "reply" : "replies"}
      </div>

      <div className="flex flex-col gap-1">
        {sorted.map((r) => (
          <div
            key={r.id}
            data-testid={`forum-reply-${r.id}`}
            className={
              r.accepted
                ? "rounded-[10px] border border-[var(--color-success-border)] bg-[var(--color-success-surface)] p-3"
                : "p-3"
            }
          >
            {r.accepted && (
              <div className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-[var(--color-success)]">
                <CheckCircle2 size={15} aria-hidden="true" /> Accepted answer
              </div>
            )}
            <div className="flex gap-3">
              <div className="flex flex-col items-center gap-0.5">
                <Button
                  type="button"
                  variant="ghost"
                  aria-label="Upvote"
                  onClick={() => upvote(r.id)}
                  className="h-auto w-auto rounded-[4px] p-1 text-[var(--color-text-muted)] hover:text-primary"
                >
                  <ArrowUp size={15} aria-hidden="true" />
                </Button>
                <span className="text-xs font-semibold">{r.votes + (votes[r.id] ?? 0)}</span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-2">
                  <Avatar name={r.author.name} size="sm" {...(r.author.avatarSrc !== undefined && { src: r.author.avatarSrc })} />
                  <span className="text-sm font-semibold">{r.author.name}</span>
                  {r.author.role && <Badge tone="gray" size="sm">{r.author.role}</Badge>}
                  <span className="text-xs text-[var(--color-text-disabled)]">{r.createdAtLabel}</span>
                </div>
                <p className="mt-1 whitespace-pre-wrap text-sm text-[var(--color-text)]">{r.body}</p>
                {post.isQuestion && post.canAccept && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="mt-1.5"
                    onClick={() => accept(r.id)}
                    data-testid={`accept-${r.id}`}
                  >
                    <CheckCircle2 size={13} aria-hidden="true" /> {r.accepted ? "Accepted" : "Accept answer"}
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-5">
        <div className="mb-2 text-sm font-semibold">Your reply</div>
        <ActivityComposer
          config={config.replyPlaceholder ? { ...composerConfig, labels: { composerPlaceholder: config.replyPlaceholder } } : composerConfig}
          onSave={(draft: ActivityDraft) => addReply(draft.plainText)}
        />
      </div>
    </div>
  );
}

export type {
  ForumPostConfig,
  ForumPostConfigInput,
  ForumPost as ForumPostData,
  ForumPostInput as ForumPostDataInput,
  ForumAuthor,
  ForumReply,
  ForumReplyInput,
} from "./types.js";
