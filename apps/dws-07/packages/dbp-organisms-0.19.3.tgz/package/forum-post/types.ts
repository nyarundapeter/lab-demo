import { z } from "zod";

// Config schema for the @dbp/organisms/forum-post organism
// (collaboration-system/forums.jsx `ForumPost`/`ForumReply`). UI-tier build
// per Wave 3 Family 4f scope — the post + its replies arrive fully resolved
// via config; a host binds this to a real forum-post/forum-reply PS.DATA
// entity by supplying `post`/`replies` from its own query and wiring the
// `on*` callback props to real mutations.

export const ForumAuthorSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  role: z.string().optional(),
  avatarSrc: z.string().optional(),
});
export type ForumAuthor = z.infer<typeof ForumAuthorSchema>;

export const ForumReplySchema = z.object({
  id: z.string().min(1),
  author: ForumAuthorSchema,
  body: z.string().min(1),
  createdAtLabel: z.string().min(1),
  votes: z.number().int().default(0),
  accepted: z.boolean().optional().default(false),
});
export type ForumReply = z.infer<typeof ForumReplySchema>;
export type ForumReplyInput = z.input<typeof ForumReplySchema>;

export const ForumPostSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  category: z.string().min(1),
  categoryColor: z.string().optional(),
  author: ForumAuthorSchema,
  createdAtLabel: z.string().min(1),
  viewCount: z.number().int().default(0),
  body: z.string().min(1),
  /** Q&A mode — enables the "accept answer" affordance on replies. */
  isQuestion: z.boolean().optional().default(false),
  /** Whether the current viewer may accept an answer (typically the post author or an admin). */
  canAccept: z.boolean().optional().default(false),
});
export type ForumPost = z.infer<typeof ForumPostSchema>;
export type ForumPostInput = z.input<typeof ForumPostSchema>;

export const ForumPostConfig = z.object({
  post: ForumPostSchema,
  replies: z.array(ForumReplySchema).default([]),
  currentUserId: z.string().min(1),
  replyPlaceholder: z.string().optional(),
});
export type ForumPostConfig = z.infer<typeof ForumPostConfig>;
/** Pre-parse shape (defaulted fields optional) — what callers/stories/tests construct. */
export type ForumPostConfigInput = z.input<typeof ForumPostConfig>;
