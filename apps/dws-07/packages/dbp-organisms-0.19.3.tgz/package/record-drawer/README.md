# @dbp/organisms/record-drawer

**registryId:** `APP.F25`

Config-driven, tabbed detail drawer for collection pages (entity-list,
catalog-grid, marketplace-item detail). See [FEATURE.md](./FEATURE.md) for
the full contract and [CHANGELOG.md](./CHANGELOG.md) for release history.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`RecordDrawerConfig` / `RecordDrawerConfigSchema` — Zod schema exported from
`types.ts` (source of truth).

## Consumed by
`@dbp/organisms/entity-list` (`detailDrawer: boolean | RecordDrawerConfig`) —
composition-via-dependency, the house pattern for this organism family.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/record-drawer` via plain
pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a
committed tarball per `docs/08-contributing/package-distribution.md`.
