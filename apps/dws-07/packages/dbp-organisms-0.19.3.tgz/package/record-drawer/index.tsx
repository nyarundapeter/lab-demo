"use client";
// APP.F25 — record-drawer: a config-driven, tabbed detail drawer that mounts
// inside collection-table / collection-grid / marketplace pages. See
// docs/03-features/specs/organism-record-drawer-spec-2026-07-10.md.
//
// Reuse over reimplementation (spec §1): workflow tab composes APP.F23
// (RecordWorkflowStepper + RecordWorkflowActions); audit tab composes
// PS.AUDIT's useActivityFeed; comments tab is a PS.DATA sub-entity
// (`<entityType>-note`) — the three-stream separation ruled 2026-07-10 (§6.1
// of the spec's Decisions): notes ≠ workflow's own process trail ≠ platform
// audit. Metrics tab kind is CUT for v1 (spec Decision 3) — config accepts it
// but the organism renders an honest "not available" notice, never invented
// trends.
import * as React from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  Badge,
  Button,
  Alert,
  Skeleton,
  toast,
  formatDate,
  Avatar,
  FormField,
  Input,
  Textarea,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@dbp/ui";
import { useEntity, useEntityList, createEntity, updateEntity } from "@dbp/ps-data/client";
import { useActivityFeed } from "@dbp/ps-audit/client";
import { WorkflowStatusSummary } from "@dbp/ui";
import {
  RecordWorkflowStepper,
  RecordWorkflowActions,
  RecordProgressHistory,
  useRecordWorkflow,
} from "@dbp/organisms/workflow-binding";
import { RecordDrawerConfigSchema } from "./types.js";
import type {
  RecordDrawerConfig,
  RecordDrawerField,
  RecordDrawerProps,
  RecordDrawerSection,
  RecordDrawerTab,
} from "./types.js";

export type { RecordDrawerConfig, RecordDrawerProps, RecordDrawerNav } from "./types.js";
export { RecordDrawerConfigSchema } from "./types.js";

// ─── Width presets (spec §2 — reference's responsive 100/60/40vw) ────────────
// Kept as a resizable drag handle (min 360px / max 100vw) rather than a fixed
// breakpoint switch — the reference's real value per the spec's "keep all of
// it" ruling on the resize + shortcut behaviours.
const WIDTH_MIN = 420;
const WIDTH_COMPACT = 480; // ~40vw desktop baseline
const WIDTH_EXPANDED_RATIO = 0.9; // "expand" ≈ 100vw minus a peek margin

function label(config: RecordDrawerConfig, key: string, fallback: string): string {
  return config.labels[key] ?? fallback;
}

// "capability-record" → "Capability record" (eyebrow fallback when no entityLabel).
function humanize(s: string): string {
  const words = s.replace(/[-_]+/g, " ").trim();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

type BadgeTone = React.ComponentProps<typeof Badge>["tone"];

function toneFor(config: RecordDrawerConfig, value: string | undefined): BadgeTone {
  if (!value) return "default";
  return (config.statusTones[value] as BadgeTone) ?? "default";
}

// ─── Typed field renderers (N37 — overlay-system reference parity) ────────────

const STATUS_DOT_COLORS: Record<string, string> = {
  success: "var(--color-success)",
  warning: "var(--color-warning)",
  danger: "var(--color-danger)",
  info: "var(--color-info)",
  default: "var(--color-text-muted)",
};

function PersonValue({ name }: { name: string }) {
  return (
    <span className="inline-flex items-center gap-2" data-render="person">
      <Avatar name={name} size="sm" />
      <span className="text-sm font-medium text-[var(--color-text)]">{name}</span>
    </span>
  );
}

// Not composing @dbp/ui's StatusDot: that component always renders a status
// icon (CircleCheck/CircleAlert/…) plus its own fixed 5-state label text,
// while this field renderer needs a plain colour dot beside the config's
// arbitrary field value string (e.g. "Active", a workflow status) — the tone
// vocabulary lines up (success/warning/danger/info/default), but the dot vs.
// icon visual treatment doesn't, so this stays local.
function StatusDotValue({ value, tone }: { value: string; tone: string }) {
  return (
    <span className="inline-flex items-center gap-2" data-render="status-dot">
      <span
        aria-hidden="true"
        className="h-2 w-2 rounded-full"
        style={{ background: STATUS_DOT_COLORS[tone] ?? STATUS_DOT_COLORS.default }}
      />
      <span className="text-sm font-medium text-[var(--color-text)]">{value}</span>
    </span>
  );
}

function formatDateValue(value: unknown): string {
  return formatDate(String(value), "medium");
}

// SLA countdown chip vs a target-date field value. Local light calc:
// @dbp/organisms/sla-tracking's sla-math is workflow-instance-shaped
// (computeSlaRow(instance, slas, …)) and its package exports only the root
// organism, so it is not importable for a field-level countdown — documented
// per the N37 "reuse if importable, else local calc" seam.
function SlaValue({ value }: { value: unknown }) {
  const target = new Date(String(value)).getTime();
  if (Number.isNaN(target)) return <span className="text-sm text-[var(--color-text)]">{String(value)}</span>;
  const diffMin = (target - Date.now()) / 60_000;
  const abs = Math.abs(diffMin);
  const human = abs >= 1440 ? `${Math.floor(abs / 1440)}d` : abs >= 60 ? `${Math.floor(abs / 60)}h` : `${Math.max(1, Math.floor(abs))}m`;
  if (diffMin < 0) {
    return (
      <Badge tone="danger" size="sm" data-render="sla">
        Overdue by {human}
      </Badge>
    );
  }
  return (
    <Badge tone={diffMin < 1440 ? "warning" : "default"} size="sm" data-render="sla">
      {human} left
    </Badge>
  );
}

function FieldValue({ field, value }: { field: RecordDrawerField; value: unknown }) {
  if (value === undefined || value === null || value === "") {
    return <span className="text-sm text-[var(--color-text-muted)]">—</span>;
  }
  switch (field.render) {
    case "person":
      return <PersonValue name={String(value)} />;
    case "status-dot":
      return <StatusDotValue value={String(value)} tone={field.badgeTones?.[String(value)] ?? "default"} />;
    case "date":
      return <span className="text-sm font-medium text-[var(--color-text)]">{formatDateValue(value)}</span>;
    case "sla":
      return <SlaValue value={value} />;
    default:
      break;
  }
  switch (field.format) {
    case "badge":
      return <Badge tone="default">{String(value)}</Badge>;
    case "tags":
      return (
        <div className="flex flex-wrap gap-1">
          {(Array.isArray(value) ? value : [value]).map((v, i) => (
            <Badge key={i} tone="default" size="sm">
              {String(v)}
            </Badge>
          ))}
        </div>
      );
    case "date":
    case "datetime":
      return <span className="text-sm text-[var(--color-text)]">{String(value)}</span>;
    case "link":
      return (
        <a
          href={String(value)}
          target="_blank"
          rel="noreferrer"
          className="text-sm text-[var(--color-primary)] underline"
        >
          {String(value)}
        </a>
      );
    default:
      return <span className="text-sm text-[var(--color-text)]">{String(value)}</span>;
  }
}

// ─── Inline field editing (Overview tab — mirrors LVE's DetailField, N35) ─────

function EditableFieldInput({
  field,
  value,
  onSave,
}: {
  field: RecordDrawerField;
  value: unknown;
  onSave: (fieldId: string, next: string | number) => void;
}) {
  // N37 scope ruling: editable drawer fields use the standard @dbp/ui form
  // components (FormField + Input/Select/Textarea, --form-* token block,
  // FieldState validation) — never hand-rolled input styling.
  const [draft, setDraft] = React.useState(value === undefined || value === null ? "" : String(value));
  const [validationError, setValidationError] = React.useState<string | undefined>(undefined);
  const commit = () => {
    if (field.editType === "number") {
      const n = Number(draft);
      if (Number.isNaN(n)) {
        setValidationError("Enter a number");
        return;
      }
      setValidationError(undefined);
      onSave(field.id, n);
      return;
    }
    onSave(field.id, draft);
  };
  if (field.editType === "select" && field.editOptions) {
    return (
      <FormField label={field.label}>
        <Select
          value={draft}
          onValueChange={(v: string) => {
            setDraft(v);
            onSave(field.id, v);
          }}
        >
          <SelectTrigger data-testid={`record-drawer-field-${field.id}`}>
            <SelectValue placeholder="Select…" />
          </SelectTrigger>
          <SelectContent>
            {field.editOptions.map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </FormField>
    );
  }
  if (field.editType === "text" && field.format === "richtext") {
    return (
      <FormField label={field.label}>
        <Textarea
          rows={3}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={commit}
          data-testid={`record-drawer-field-${field.id}`}
        />
      </FormField>
    );
  }
  return (
    <FormField label={field.label} {...(validationError ? { error: validationError } : {})}>
      <Input
        type={field.editType === "number" ? "number" : field.editType === "date" ? "date" : "text"}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        data-testid={`record-drawer-field-${field.id}`}
      />
    </FormField>
  );
}

function SectionList({
  sections,
  record,
  onFieldSave,
}: {
  sections: RecordDrawerSection[];
  record: Record<string, unknown>;
  onFieldSave?: ((fieldId: string, next: string | number) => void) | undefined;
}) {
  // Definition-list rhythm lifted from the overlay-system reference's KV rows
  // (N37): one field per row, muted label column (fixed width), strong value
  // column, generous vertical padding, hairline row separators. Editable
  // fields switch to the real @dbp/ui FormField block instead of a KV row.
  return (
    <div className="flex flex-col gap-6" data-testid="record-drawer-fields">
      {sections.map((section) => (
        <div key={section.id} className="flex flex-col gap-1">
          {section.title && (
            <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
              {section.title}
            </h3>
          )}
          <dl className="flex flex-col">
            {section.fields.map((field) =>
              field.editable && onFieldSave ? (
                <div key={field.id} className="py-2.5">
                  <EditableFieldInput field={field} value={record[field.id]} onSave={onFieldSave} />
                </div>
              ) : (
                <div
                  key={field.id}
                  className="flex items-center gap-3 border-b border-[var(--color-border)] py-2.5 last:border-b-0"
                >
                  <dt className="w-28 flex-shrink-0 text-sm text-[var(--color-text-muted)]">{field.label}</dt>
                  <dd className="min-w-0 flex-1 text-sm font-medium text-[var(--color-text)]">
                    <FieldValue field={field} value={record[field.id]} />
                  </dd>
                </div>
              ),
            )}
          </dl>
        </div>
      ))}
    </div>
  );
}

// ─── KPI strip (header — dashboard-system reference's amount/weighted/probability) ─

function KpiStrip({ fields, record }: { fields: RecordDrawerField[]; record: Record<string, unknown> }) {
  if (fields.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-6 border-b border-[var(--color-border)] px-6 py-3" data-testid="record-drawer-kpi-strip">
      {fields.map((field) => (
        <div key={field.id} className="flex flex-col gap-0.5">
          <span className="text-xs text-[var(--color-text-muted)]">{field.label}</span>
          <span className="text-sm font-semibold text-[var(--color-text)]" data-testid={`record-drawer-kpi-${field.id}`}>
            <FieldValue field={field} value={record[field.id]} />
          </span>
        </div>
      ))}
    </div>
  );
}

// ─── Footer action bar (N37 — reference's sticky OverlayFooter) ───────────────
// Replaces the N35 inline quick-action row: the overlay-system reference puts
// record actions in a sticky bottom bar — destructive left, primary/secondary
// right (last action primary). Config-driven via quickActions; wired-only.

function FooterActionBar({
  actions,
  onFire,
  pending,
}: {
  actions: RecordDrawerConfig["quickActions"];
  onFire: (actionId: string) => void;
  pending: boolean;
}) {
  if (actions.length === 0) return null;
  const destructive = actions.filter((a) => a.tone === "danger");
  const regular = actions.filter((a) => a.tone !== "danger");
  return (
    <div
      className="flex flex-shrink-0 items-center gap-2 border-t border-[var(--color-border)] bg-[var(--color-surface)] px-6 py-3.5"
      data-testid="record-drawer-quick-actions"
    >
      {destructive.map((a) => (
        <Button
          key={a.id}
          size="sm"
          variant="destructive"
          disabled={pending}
          onClick={() => onFire(a.id)}
          data-testid={`record-drawer-quick-action-${a.id}`}
        >
          {a.label}
        </Button>
      ))}
      <div className="flex-1" />
      {regular.map((a, i) => (
        <Button
          key={a.id}
          size="sm"
          variant={i === regular.length - 1 ? "navy" : "outline"}
          disabled={pending}
          onClick={() => onFire(a.id)}
          data-testid={`record-drawer-quick-action-${a.id}`}
        >
          {a.label}
        </Button>
      ))}
    </div>
  );
}

// ─── Comments tab (PS.DATA sub-entity — spec Decision 5) ──────────────────────

type NoteRecord = { id: string; body: string; author?: string; createdAt?: string };

function CommentsTab({ entityType, recordId, config }: { entityType: string; recordId: string; config: RecordDrawerConfig }) {
  const noteType = `${entityType}-note`;
  const { rows: notes, isLoading, error } = useEntityList<NoteRecord>(noteType, {
    filters: { recordId },
  });
  const queryClient = useQueryClient();
  const [draft, setDraft] = React.useState("");
  const create = useMutation({
    mutationFn: (body: string) => createEntity<NoteRecord>(noteType, { recordId, body } as unknown as NoteRecord),
    onSuccess: () => {
      setDraft("");
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity-list", noteType] });
    },
    onError: () => toast({ title: "Failed to save note", tone: "danger" }),
  });

  if (isLoading) {
    return (
      <div className="flex flex-col gap-2" data-testid="comments-loading">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-10 w-full" />
      </div>
    );
  }
  if (error) {
    return (
      <Alert tone="danger" title="Failed to load comments" data-testid="comments-error">
        {error.message}
      </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-4" data-testid="comments-tab">
      <div className="flex flex-col gap-2">
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          rows={3}
          placeholder={label(config, "commentsPlaceholder", "Add a note")}
          className="w-full resize-y rounded-md border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2 text-sm text-[var(--color-text)]"
          data-testid="comment-input"
        />
        <div className="flex justify-end">
          <Button
            size="sm"
            disabled={!draft.trim() || create.isPending}
            loading={create.isPending}
            onClick={() => create.mutate(draft.trim())}
            data-testid="comment-submit"
          >
            {label(config, "commentsSubmit", "Save note")}
          </Button>
        </div>
      </div>
      {notes.length === 0 ? (
        <p className="text-sm text-[var(--color-text-muted)]" data-testid="comments-empty">
          {label(config, "commentsEmpty", "No notes yet.")}
        </p>
      ) : (
        <ul className="flex flex-col gap-3" data-testid="comments-list">
          {notes.map((n) => (
            <li key={n.id} className="rounded-md border border-[var(--color-border)] p-3">
              <p className="text-sm text-[var(--color-text)]">{n.data.body}</p>
              {n.data.author && (
                <p className="mt-1 text-xs text-[var(--color-text-muted)]">
                  {n.data.author} {n.data.createdAt ? `· ${n.data.createdAt}` : ""}
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// ─── Audit tab (PS.AUDIT — spec Decision 5, platform-audit stream) ────────────

function AuditTab({ recordId }: { recordId: string }) {
  const { events, isLoading, error } = useActivityFeed(recordId);
  if (isLoading) {
    return (
      <div className="flex flex-col gap-2" data-testid="audit-loading">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-8 w-full" />
      </div>
    );
  }
  if (error) {
    return (
      <Alert tone="danger" title="Failed to load audit trail" data-testid="audit-error">
        {error.message}
      </Alert>
    );
  }
  if (events.length === 0) {
    return (
      <p className="text-sm text-[var(--color-text-muted)]" data-testid="audit-empty">
        No audit events yet.
      </p>
    );
  }
  return (
    <ul className="flex flex-col gap-3" data-testid="audit-list">
      {events.map((e) => (
        <li key={e.id} className="border-l-2 border-[var(--color-border)] pl-3 text-sm">
          <span className="font-medium text-[var(--color-text)]">{e.action}</span>{" "}
          <span className="text-[var(--color-text-muted)]">{e.actor.displayName} · {e.ts}</span>
        </li>
      ))}
    </ul>
  );
}

// ─── Workflow tab (APP.F23 — reuse over reimplementation, spec §1) ────────────

function WorkflowTab({ recordId, config }: { recordId: string; config: RecordDrawerConfig }) {
  if (!config.workflow) {
    return (
      <p className="text-sm text-[var(--color-text-muted)]" data-testid="workflow-not-configured">
        No workflow bound to this record type.
      </p>
    );
  }
  const wfConfig = { definitionIds: [config.workflow.definitionId], entityType: config.entityType };
  return (
    <div className="flex flex-col gap-4" data-testid="workflow-tab">
      <WorkflowTabStatusSummary recordId={recordId} config={wfConfig} />
      <RecordWorkflowStepper recordId={recordId} config={wfConfig} />
      <RecordWorkflowActions recordId={recordId} config={wfConfig} />
      <RecordProgressHistory recordId={recordId} config={wfConfig} />
    </div>
  );
}

// Thin wrapper: WorkflowStatusSummary (built + storied, never mounted per the
// 2026-07-17 design audit) needs a bound WorkflowInstanceView — render nothing
// until an instance exists rather than fabricate placeholder state.
function WorkflowTabStatusSummary({
  recordId,
  config,
}: {
  recordId: string;
  config: { definitionIds: string[]; entityType: string };
}) {
  const wf = useRecordWorkflow(recordId, config);
  if (wf.loading || wf.error || !wf.instance) return null;
  return <WorkflowStatusSummary instance={wf.instance} variant="drawer" />;
}

// ─── Tab content dispatcher ────────────────────────────────────────────────────

function TabBody({
  tab,
  config,
  record,
  onFieldSave,
}: {
  tab: RecordDrawerTab;
  config: RecordDrawerConfig;
  record: Record<string, unknown> & { id: string };
  onFieldSave?: ((fieldId: string, next: string | number) => void) | undefined;
}) {
  switch (tab.kind) {
    case "workflow":
      return <WorkflowTab recordId={record.id} config={config} />;
    case "comments":
      return <CommentsTab entityType={config.comments?.entityType ?? config.entityType} recordId={record.id} config={config} />;
    case "audit":
      return <AuditTab recordId={record.id} />;
    case "metrics":
      // Cut for v1 (spec Decision 3) — honest notice, no invented trends.
      return (
        <p className="text-sm text-[var(--color-text-muted)]" data-testid="metrics-unavailable">
          Metrics are not available yet.
        </p>
      );
    case "fields":
    default: {
      const sections = tab.sections ?? resolveSections(config, record);
      // Description block (N37): the configured leading multiline summary field
      // renders as a paragraph above the definition list (reference's
      // contractor paragraph), never as a label/value row.
      const desc = config.descriptionField ? record[config.descriptionField] : undefined;
      const filtered = config.descriptionField
        ? sections
            .map((s) => ({ ...s, fields: s.fields.filter((f) => f.id !== config.descriptionField) }))
            .filter((s) => s.fields.length > 0)
        : sections;
      return (
        <div className="flex flex-col gap-4">
          {typeof desc === "string" && desc !== "" && (
            <p className="text-sm leading-relaxed text-[var(--color-text)]" data-testid="record-drawer-description">
              {desc}
            </p>
          )}
          <SectionList sections={filtered} record={record} onFieldSave={onFieldSave} />
        </div>
      );
    }
  }
}

function resolveSections(config: RecordDrawerConfig, record: Record<string, unknown>): RecordDrawerSection[] {
  if (config.typeField) {
    const typeValue = record[config.typeField];
    if (typeof typeValue === "string" && config.variants[typeValue]) {
      return config.variants[typeValue];
    }
  }
  return config.defaultSections;
}

// Tab count badge (N37 — "Systems 6" in the reference). Cheap derivation only:
// array field → length, number field → value; anything else omits the badge.
function tabCount(tab: RecordDrawerTab, record: Record<string, unknown>): number | null {
  if (!tab.countField) return null;
  const v = record[tab.countField];
  if (Array.isArray(v)) return v.length;
  if (typeof v === "number" && Number.isFinite(v)) return v;
  return null;
}

function tabVisible(tab: RecordDrawerTab, record: Record<string, unknown>): boolean {
  if (!tab.visibleWhen) return true;
  return String(record[tab.visibleWhen.field]) === tab.visibleWhen.equals;
}

// ─── Deep-link hook (spec §2 — Next useSearchParams/router.replace) ───────────

function useDeepLink(enabled: boolean, recordId: string | null, open: boolean) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  React.useEffect(() => {
    if (!enabled) return;
    const params = new URLSearchParams(searchParams.toString());
    if (open && recordId) {
      params.set("recordId", recordId);
      params.set("view", "drawer");
    } else {
      params.delete("recordId");
      params.delete("view");
    }
    const query = params.toString();
    router.replace(query ? `${pathname}?${query}` : pathname, { scroll: false });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, open, recordId, pathname, router]);
}

// ─── Root component ───────────────────────────────────────────────────────────

export default function RecordDrawer({ config, recordId, open, onOpenChange, nav }: RecordDrawerProps) {
  const parseResult = RecordDrawerConfigSchema.safeParse(config);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="RecordDrawer configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }
  return (
    <RecordDrawerInner
      config={parseResult.data}
      recordId={recordId}
      open={open}
      onOpenChange={onOpenChange}
      nav={nav}
    />
  );
}

function RecordDrawerInner({ config, recordId, open, onOpenChange, nav }: RecordDrawerProps & { config: RecordDrawerConfig }) {
  useDeepLink(config.deepLink, recordId, open);

  const visibleTabs = config.tabs;
  const [activeTab, setActiveTab] = React.useState(visibleTabs[0]?.id ?? "");
  const [expanded, setExpanded] = React.useState(false);
  const [width, setWidth] = React.useState(WIDTH_COMPACT);
  const dragging = React.useRef(false);
  const queryClient = useQueryClient();

  const { data: record, isLoading, error } = useEntity<Record<string, unknown> & { id: string; version?: number }>(
    config.entityType,
    recordId ?? "",
    { enabled: open && !!recordId },
  );

  const fieldSave = useMutation({
    mutationFn: ({ fieldId, next }: { fieldId: string; next: string | number }) =>
      updateEntity(config.entityType, recordId ?? "", { [fieldId]: next } as Record<string, unknown>, {
        ...(record?.version !== undefined && { expectedRevision: record.version }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity", config.entityType, recordId] });
    },
    onError: () => toast({ title: "Failed to save field", tone: "danger" }),
  });
  const onFieldSave = React.useCallback(
    (fieldId: string, next: string | number) => fieldSave.mutate({ fieldId, next }),
    [fieldSave],
  );

  const quickAction = useMutation({
    mutationFn: (patch: Record<string, unknown>) =>
      updateEntity(config.entityType, recordId ?? "", patch, {
        ...(record?.version !== undefined && { expectedRevision: record.version }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity", config.entityType, recordId] });
    },
    onError: () => toast({ title: "Failed to run action", tone: "danger" }),
  });
  // Fires footer actions AND header kebab items (both wired-only patches).
  const onQuickAction = React.useCallback(
    (actionId: string) => {
      const action =
        config.quickActions.find((a) => a.id === actionId) ?? config.headerMenu.find((a) => a.id === actionId);
      if (action) quickAction.mutate(action.patch);
    },
    [config.quickActions, config.headerMenu, quickAction],
  );

  const onCopyLink = React.useCallback(() => {
    if (typeof navigator !== "undefined" && navigator.clipboard && typeof window !== "undefined") {
      void navigator.clipboard.writeText(window.location.href);
    }
    toast({ title: label(config, "linkCopied", "Link copied") });
  }, [config]);

  React.useEffect(() => {
    if (!open) {
      setExpanded(false);
      setWidth(WIDTH_COMPACT);
    }
  }, [open]);

  // Shift+Enter = toggle expand (spec §2 — keep the reference's shortcuts).
  React.useEffect(() => {
    if (!open || !config.expandable) return;
    function onKeyDown(e: KeyboardEvent) {
      if (e.shiftKey && e.key === "Enter") {
        e.preventDefault();
        setExpanded((v) => !v);
      }
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open, config.expandable]);

  const onDragStart = React.useCallback((e: React.PointerEvent) => {
    dragging.current = true;
    e.currentTarget.setPointerCapture(e.pointerId);
  }, []);
  const onDragMove = React.useCallback((e: React.PointerEvent) => {
    if (!dragging.current) return;
    const next = Math.min(window.innerWidth * WIDTH_EXPANDED_RATIO, Math.max(WIDTH_MIN, window.innerWidth - e.clientX));
    setWidth(next);
    setExpanded(false);
  }, []);
  const onDragEnd = React.useCallback(() => {
    dragging.current = false;
  }, []);

  const effectiveWidth = expanded ? Math.round(window.innerWidth * WIDTH_EXPANDED_RATIO) : width;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        style={{ width: `${effectiveWidth}px`, maxWidth: "100vw" }}
        className="flex flex-col gap-0 overflow-hidden p-0"
        data-testid="record-drawer"
      >
        {config.expandable && (
          <div
            role="separator"
            aria-label="Resize drawer"
            className="absolute left-0 top-0 h-full w-1 cursor-col-resize hover:bg-[var(--color-primary)]"
            data-testid="record-drawer-resize-handle"
            onPointerDown={onDragStart}
            onPointerMove={onDragMove}
            onPointerUp={onDragEnd}
          />
        )}

        <SheetHeader className="border-b border-[var(--color-border)] px-6 py-4">
          {nav && (
            <div className="mb-2 flex items-center gap-2" data-testid="record-drawer-nav">
              <Button
                variant="ghost"
                size="sm"
                disabled={nav.index <= 0}
                onClick={nav.onPrev}
                data-testid="record-drawer-nav-prev"
              >
                {label(config, "navPrev", "Prev")}
              </Button>
              <span className="text-xs text-[var(--color-text-muted)]" data-testid="record-drawer-nav-position">
                {nav.index + 1} {label(config, "navOf", "of")} {nav.total}
              </span>
              <Button
                variant="ghost"
                size="sm"
                disabled={nav.index >= nav.total - 1}
                onClick={nav.onNext}
                data-testid="record-drawer-nav-next"
              >
                {label(config, "navNext", "Next")}
              </Button>
            </div>
          )}
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              {/* Eyebrow: entity label · record code (reference's `${category} · ${id}`) — N37 */}
              <div
                className="mb-0.5 text-xs font-semibold uppercase tracking-[.05em] text-[var(--color-text-muted)]"
                data-testid="record-drawer-eyebrow"
              >
                {config.entityLabel ?? humanize(config.entityType)}
                {record && config.codeField && record[config.codeField] != null
                  ? ` · ${String(record[config.codeField])}`
                  : ""}
              </div>
              {/* Title + status chip on the title line (reference) — N37 */}
              <div className="flex flex-wrap items-center gap-2.5">
                <SheetTitle className="truncate" data-testid="record-drawer-title">
                  {isLoading ? <Skeleton className="h-5 w-40" /> : record ? String(record[config.titleField] ?? recordId) : "—"}
                </SheetTitle>
                {record && config.statusField && (
                  <Badge tone={toneFor(config, String(record[config.statusField] ?? ""))} size="sm" data-testid="record-drawer-status-chip">
                    {String(record[config.statusField])}
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1">
              {record && config.deepLink && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onCopyLink}
                  data-testid="record-drawer-copy-link"
                >
                  {label(config, "copyLink", "Copy link")}
                </Button>
              )}
              {config.expandable && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setExpanded((v) => !v)}
                  data-testid="record-drawer-expand"
                >
                  {expanded ? label(config, "collapse", "Collapse") : label(config, "expand", "Expand")}
                </Button>
              )}
              {/* Kebab overflow menu — config-driven, wired-only (N34/N37) */}
              {record && config.headerMenu.length > 0 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" aria-label="More actions" data-testid="record-drawer-kebab">
                      ⋮
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {config.headerMenu.map((item) => (
                      <DropdownMenuItem
                        key={item.id}
                        onSelect={() => onQuickAction(item.id)}
                        className={item.tone === "danger" ? "text-[var(--color-danger)]" : undefined}
                        data-testid={`record-drawer-menu-item-${item.id}`}
                      >
                        {item.label}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>
        </SheetHeader>

        {record && <KpiStrip fields={config.kpiFields} record={record} />}
        {record && config.showStagePipeline && config.workflow && (
          <div className="border-b border-[var(--color-border)] px-6 py-3" data-testid="record-drawer-pipeline">
            <RecordWorkflowStepper
              recordId={record.id}
              config={{ definitionIds: [config.workflow.definitionId], entityType: config.entityType }}
            />
          </div>
        )}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {!recordId ? (
            <p className="text-sm text-[var(--color-text-muted)]" data-testid="record-drawer-no-selection">
              No record selected.
            </p>
          ) : isLoading ? (
            <div className="flex flex-col gap-3" data-testid="record-drawer-loading">
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-2/3" />
            </div>
          ) : error ? (
            <Alert tone="danger" title="Failed to load record" data-testid="record-drawer-error">
              {error.message}
            </Alert>
          ) : !record ? (
            <Alert tone="warning" title="Record not found" data-testid="record-drawer-not-found">
              This record may have been deleted.
            </Alert>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList>
                {visibleTabs.filter((t) => tabVisible(t, record)).map((tab) => {
                  const count = tabCount(tab, record);
                  return (
                    <TabsTrigger key={tab.id} value={tab.id} data-testid={`record-drawer-tab-${tab.id}`}>
                      {tab.label}
                      {count !== null && (
                        <Badge tone="default" size="sm" className="ml-1.5" data-testid={`record-drawer-tab-count-${tab.id}`}>
                          {count}
                        </Badge>
                      )}
                    </TabsTrigger>
                  );
                })}
              </TabsList>
              {visibleTabs.filter((t) => tabVisible(t, record)).map((tab) => (
                <TabsContent key={tab.id} value={tab.id} className="pt-4">
                  <TabBody tab={tab} config={config} record={record} onFieldSave={onFieldSave} />
                </TabsContent>
              ))}
            </Tabs>
          )}
        </div>

        {record && (
          <FooterActionBar actions={config.quickActions} onFire={onQuickAction} pending={quickAction.isPending} />
        )}
      </SheetContent>
    </Sheet>
  );
}
