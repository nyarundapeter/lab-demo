import { z } from "zod";

// Config schema for @dbp/organisms/record-drawer (APP.F25).
// Source: docs/03-features/specs/organism-record-drawer-spec-2026-07-10.md §3
// (Zod is the source of truth — z.infer, never hand-authored interfaces).

export const RecordDrawerEditOptionSchema = z.object({ value: z.string(), label: z.string() });
export type RecordDrawerEditOption = z.infer<typeof RecordDrawerEditOptionSchema>;

export const RecordDrawerFieldSchema = z.object({
  id: z.string(),
  label: z.string(),
  format: z
    .enum(["text", "date", "datetime", "badge", "tags", "link", "image", "richtext", "metric"])
    .default("text"),
  icon: z.string().optional(),
  badgeTones: z.record(z.string()).optional(),
  // Typed value renderer (N37 — overlay-system reference parity):
  // "person" = avatar initials + name; "status-dot" = colored dot + label
  // (tone-mapped via `badgeTones`); "date" = formatted date; "sla" = countdown
  // chip vs the field's own target-date value (local light calc — sla-math in
  // @dbp/organisms/sla-tracking is workflow-instance-shaped, not field-shaped).
  render: z.enum(["text", "person", "status-dot", "date", "sla"]).optional(),
  // Overview-tab inline editing (mirrors LVE's DetailField semantics — spec N35).
  editable: z.boolean().default(false),
  editType: z.enum(["text", "number", "date", "select"]).optional(),
  editOptions: z.array(RecordDrawerEditOptionSchema).optional(),
});
export type RecordDrawerField = z.infer<typeof RecordDrawerFieldSchema>;

// Quick-action row (config-driven, LVE quickActions pattern — N35). Only
// actions declared here are ever rendered; there are no disabled placeholders.
export const RecordDrawerQuickActionSchema = z.object({
  id: z.string(),
  label: z.string(),
  icon: z.string().optional(),
  tone: z.enum(["default", "primary", "success", "warning", "danger"]).optional(),
  patch: z.record(z.union([z.string(), z.number(), z.boolean()])),
});
export type RecordDrawerQuickAction = z.infer<typeof RecordDrawerQuickActionSchema>;

export const RecordDrawerSectionSchema = z.object({
  id: z.string(),
  title: z.string().optional(),
  fields: z.array(RecordDrawerFieldSchema).min(1),
});
export type RecordDrawerSection = z.infer<typeof RecordDrawerSectionSchema>;

export const RecordDrawerTabSchema = z.object({
  id: z.string(),
  label: z.string(),
  kind: z.enum(["fields", "workflow", "comments", "audit", "metrics"]).default("fields"),
  sections: z.array(RecordDrawerSectionSchema).optional(),
  visibleWhen: z.object({ field: z.string(), equals: z.string() }).optional(),
  // Optional count badge on the tab ("Systems 6" in the overlay-system
  // reference — N37). Derived cheaply from the record itself: an array field
  // counts its length, a number field shows the number. Anything else omits
  // the badge — a count is never fabricated.
  countField: z.string().optional(),
});
export type RecordDrawerTab = z.infer<typeof RecordDrawerTabSchema>;

export const RecordDrawerConfigSchema = z
  .object({
    entityType: z.string(),
    titleField: z.string(),
    subtitleFields: z.array(z.string()).default([]),
    statusField: z.string().optional(),
    statusTones: z.record(z.string()).default({}),
    typeField: z.string().optional(),
    variants: z.record(z.array(RecordDrawerSectionSchema)).default({}),
    defaultSections: z.array(RecordDrawerSectionSchema).min(1),
    tabs: z.array(RecordDrawerTabSchema).min(1),
    workflow: z.object({ definitionId: z.string() }).optional(),
    comments: z.object({ entityType: z.string() }).optional(),
    labels: z.record(z.string()).default({}),
    deepLink: z.boolean().default(true),
    expandable: z.boolean().default(true),
    // Record-ID chip in the header (e.g. a human-readable `code` field) — N35.
    codeField: z.string().optional(),
    // Optional KPI strip rendered under the header (amount/weighted/probability
    // pattern from the dashboard-system reference) — N35.
    kpiFields: z.array(RecordDrawerFieldSchema).default([]),
    // Stage-pipeline bar under the header, reusing the existing
    // RecordWorkflowStepper/StepIndicator (never a new tracker) — requires
    // `workflow` to also be configured. N35.
    showStagePipeline: z.boolean().default(false),
    // Footer action bar (N37 — overlay-system reference puts record actions in
    // a sticky footer, not an inline row): reuses quickActions semantics.
    // Actions with tone "danger" sit left (destructive slot); the rest sit
    // right, last one rendered primary. Wired-only — every action carries a
    // real patch; there are no disabled placeholders.
    quickActions: z.array(RecordDrawerQuickActionSchema).default([]),
    // Kebab overflow menu in the header (N37) — config-driven, wired-only
    // (same schema as quickActions: an item exists only if its patch does).
    headerMenu: z.array(RecordDrawerQuickActionSchema).default([]),
    // Eyebrow line "Entity label · CODE" above the title (N37, reference's
    // `${category} · ${id}`). Falls back to a humanised entityType.
    entityLabel: z.string().optional(),
    // A leading multiline summary field rendered as a description paragraph
    // under the tabs (reference's contractor paragraph), excluded from the
    // label/value rows (N37).
    descriptionField: z.string().optional(),
  })
  .strict();
export type RecordDrawerConfig = z.infer<typeof RecordDrawerConfigSchema>;

/**
 * Runtime props: the drawer is mounted with a record id + open state by its
 * host (EntityList's evolved `detailDrawer: boolean | RecordDrawerConfig`, or
 * any other collection surface). Config never carries the selected record.
 *
 * `nav` is context-driven (from the hosting list's current result set), not
 * config — it is supplied by whatever list/grid mounts the drawer, mirroring
 * the reference's prev/next + "N of M" position (N35).
 */
export type RecordDrawerNav = {
  index: number;
  total: number;
  onPrev: () => void;
  onNext: () => void;
};

export type RecordDrawerProps = {
  config: RecordDrawerConfig;
  recordId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  nav?: RecordDrawerNav | undefined;
};
