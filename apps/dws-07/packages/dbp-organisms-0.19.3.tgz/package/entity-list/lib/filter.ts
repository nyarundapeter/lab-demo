/**
 * Pure filter utilities for EntityList's listTabs `where` clauses.
 * No React imports — safe for unit tests.
 *
 * PS.DATA only supports equality ("is") filters as query params. All other ops
 * (isNot, contains, >, <, >=, <=, in) are applied client-side on the fetched
 * page via matchesAll/evaluateClause.
 *
 * Mirrors packages/stack/app-scaffolds/features/lve-workspace/lib/filter.ts
 * for semantic consistency — duplicated rather than imported since entity-list
 * and lve-workspace are independent sibling leaf packages with no shared
 * dependency between them.
 */
import type { FilterClause } from "../types.js";

/**
 * Evaluate a single FilterClause against a row's data.
 * Row values are treated as unknown; comparisons are best-effort.
 */
export function evaluateClause(
  row: Record<string, unknown>,
  clause: FilterClause,
): boolean {
  const raw = row[clause.field];

  switch (clause.op) {
    case "is":
      return String(raw ?? "") === String(clause.value ?? "");

    case "isNot":
      return String(raw ?? "") !== String(clause.value ?? "");

    case "contains": {
      if (clause.value === undefined || clause.value === null) return true;
      const haystack = String(raw ?? "").toLowerCase();
      const needle = String(clause.value).toLowerCase();
      return haystack.includes(needle);
    }

    case ">": {
      if (clause.value === undefined) return false;
      const n = Number(raw);
      const v = Number(clause.value);
      return Number.isFinite(n) && Number.isFinite(v) && n > v;
    }

    case "<": {
      if (clause.value === undefined) return false;
      const n = Number(raw);
      const v = Number(clause.value);
      return Number.isFinite(n) && Number.isFinite(v) && n < v;
    }

    case ">=": {
      if (clause.value === undefined) return false;
      const n = Number(raw);
      const v = Number(clause.value);
      return Number.isFinite(n) && Number.isFinite(v) && n >= v;
    }

    case "<=": {
      if (clause.value === undefined) return false;
      const n = Number(raw);
      const v = Number(clause.value);
      return Number.isFinite(n) && Number.isFinite(v) && n <= v;
    }

    case "in": {
      if (!Array.isArray(clause.value)) return false;
      const vals = (clause.value as string[]).map((v) => String(v));
      return vals.includes(String(raw ?? ""));
    }

    default:
      return true;
  }
}

/**
 * Returns true when the row satisfies ALL clauses (AND logic).
 * Empty array → true.
 */
export function matchesAll(
  row: Record<string, unknown>,
  clauses: FilterClause[],
): boolean {
  return clauses.every((c) => evaluateClause(row, c));
}

/**
 * Extracts only "is" equality clauses with scalar (non-array) values into the
 * flat key→value map that PS.DATA's `filters` option accepts.
 *
 * All other ops must be applied client-side via matchesAll.
 */
export function toServerFilters(
  clauses: FilterClause[],
): Record<string, string | number | boolean> {
  const out: Record<string, string | number | boolean> = {};
  for (const c of clauses) {
    if (
      c.op === "is" &&
      c.value !== undefined &&
      c.value !== null &&
      !Array.isArray(c.value)
    ) {
      out[c.field] = c.value as string | number | boolean;
    }
  }
  return out;
}

/** True when every clause in `where` is server-pushable ("is" with a scalar value). */
export function isFullyServerPushable(where: FilterClause[]): boolean {
  return where.every(
    (c) => c.op === "is" && c.value !== undefined && c.value !== null && !Array.isArray(c.value),
  );
}
