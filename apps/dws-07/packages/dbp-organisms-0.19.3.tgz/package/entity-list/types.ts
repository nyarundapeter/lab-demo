import { z } from "zod";
import { RecordDrawerConfigSchema } from "@dbp/organisms/record-drawer";

// Shared tone enum — the canonical @dbp/ui Badge tones, plus "neutral" kept as a
// back-compat alias (mapBadgeTone() maps neutral → gray). "gray"/"default" are the
// real Badge tones and are now accepted directly (previously rejected — see index.tsx).
// "active"/"paused"/"critical"/"testing" are the consolidated tone family added
// 2026-07-17 (see docs/03-features/specs/tone-family-consolidation-2026-07-17.md) —
// needed so a status column (e.g. admin ConfigList's 11-state StatusBadge) can map
// onto real Badge tones instead of falling back to gray for every collapsed state.
const Tone = z.enum([
  "default", "gray", "neutral", "info", "success", "warning", "danger", "orange", "navy",
  "active", "paused", "critical", "testing",
]);

export const ColumnDefSchema = z.object({
  /** The entity data field this column reads. */
  field: z.string().min(1),
  /** Human-readable column header label. */
  label: z.string().min(1),
  /** Allow the user to toggle sort order on this column (client-side, current page). */
  sortable: z.boolean().optional(),
  /** Tailwind width class applied to the <th>/<td>, e.g. "w-32" or "w-auto". */
  width: z.string().optional(),
  /**
   * Display format hint for cell values.
   * "number"   → formatNumber (compact for >=10 000)
   * "currency" → formatCurrency USD (compact for >=10 000)
   * "percent"  → formatPercent (ratio 0–1)
   * "date"     → formatDate "medium"
   * "datetime" → formatDate with time
   * "badge"    → @dbp/ui Badge component; use badgeTones to map values to tones
   * When omitted the cell renders the raw string value; ISO date strings are
   * auto-detected and formatted as "medium" date.
   */
  format: z.enum(["number", "currency", "percent", "date", "datetime", "badge"]).optional(),
  /**
   * Badge tone map for format:"badge" columns.
   * Key = cell value string, value = Tone.
   * Missing keys fall back to "neutral" (renders as gray badge).
   * Ignored when format is not "badge".
   */
  badgeTones: z.record(z.string(), Tone).optional(),
  /**
   * When true, this field is editable in the detail drawer's Overview section
   * (DEFECT 4 — the drawer used to be entirely read-only regardless of the
   * entity's field types). Ignored in the table itself; only affects the drawer.
   */
  editable: z.boolean().optional(),
  /** Input control used when `editable` is true. */
  editType: z.enum(["text", "number", "select"]).optional(),
  /** Options for editType:"select" — value/label pairs. */
  editOptions: z.array(z.object({ value: z.string(), label: z.string() })).optional(),
});
export type ColumnDef = z.infer<typeof ColumnDefSchema>;

/**
 * A single filter clause (mirrors LVE's FilterClause for semantic consistency).
 * Supported ops: "is" | "isNot" | "contains" | ">" | "<" | ">=" | "<=" | "in"
 */
const FilterClause = z.object({
  field: z.string().min(1),
  op: z.enum(["is", "isNot", "contains", ">", "<", ">=", "<=", "in"]),
  value: z.union([z.string(), z.number(), z.boolean(), z.array(z.string())]).optional(),
});
export type FilterClause = z.infer<typeof FilterClause>;

/**
 * A named tab for the SegmentedControl tab strip above the FilterBar.
 * Selecting a tab merges its `where` clauses into the PS.DATA filters,
 * replacing the previous tab's clauses. Static `config.filters` are always
 * applied in addition.
 *
 * Mirror of LVE's FilterPreset — `key:"all"` with empty `where:[]` = show all.
 */
const ListTabSchema = z.object({
  key: z.string().min(1),
  label: z.string().min(1),
  /**
   * Filter clauses applied when this tab is active.
   * Empty array = no additional filter (show all).
   */
  where: z.array(FilterClause).default([]),
});
export type ListTab = z.infer<typeof ListTabSchema>;

/**
 * A single KPI tile shown in the row above the tab strip.
 * The count is a real server-side total: PS.DATA is called with pageSize=1
 * and the result's `total` field is used (no fake numbers).
 */
const KpiDefSchema = z.object({
  /** Unique id (used as React key). */
  id: z.string().min(1),
  /** Label shown below the count value (e.g. "Open"). */
  label: z.string().min(1),
  /**
   * When set, clicking this KPI tile activates the matching listTab.
   * Value must match a ListTab `key`. Optional — clicking does nothing if unset.
   */
  tab: z.string().optional(),
  /**
   * Static field-equality filters sent to PS.DATA when counting this KPI.
   * Example: { status: "open" } — counts only open records.
   * Uses simple equality (merged with EntityListConfig.filters).
   */
  filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
  /**
   * Lucide icon name string (e.g. "Activity", "CheckCircle").
   * Currently accepted for API completeness but the StatTile `icon` prop is
   * deprecated — value is accepted, passed through, and silently ignored by StatTile.
   */
  icon: z.string().optional(),
  /** Tone for the KPI count value colour (default "primary"). */
  tone: z.enum(["primary", "success", "warning", "danger", "info"]).optional(),
});
export type KpiDef = z.infer<typeof KpiDefSchema>;

/**
 * EntityListConfig — the single typed contract for APP.F01.
 *
 * This is a DATA contract only (no function fields — Zod schemas are data-only).
 * Callbacks and event handling are via DOM CustomEvents (see FEATURE.md).
 *
 * All new fields are OPTIONAL with defaults that preserve the existing behavior:
 * existing config objects that omit the new fields render exactly as before.
 */
export const EntityListConfig = z.object({
  /** The PS.DATA entity type to list (e.g. "invoice", "order"). */
  entityType: z.string().min(1),
  /** Column definitions — at least one required. */
  columns: z.array(ColumnDefSchema).min(1),
  /** Number of rows per page. Defaults to 25. */
  pageSize: z.number().int().min(1).max(200).default(25),
  /** Prepend a checkbox column and enable bulk-export action. Defaults to false. */
  enableBulkActions: z.boolean().default(false),
  /**
   * Show a search box that routes through PS.SEARCH when a query is entered.
   * See FEATURE.md §Search / PS.SEARCH interplay for the two-step fetch contract.
   * Defaults to false.
   */
  enableSearch: z.boolean().default(false),
  /**
   * Static field-equality filters applied to every PS.DATA request.
   * Example: { paid: true } — always shows only paid invoices.
   */
  filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
  /**
   * Enable master-detail row selection. When true (default), clicking or
   * keyboard-activating a row dispatches a `dbp:entity-list:row-select`
   * CustomEvent ({ entityType, id }) on `document` and applies a selected-row
   * style (bg-navy-50). A paired EntityDetail listens for that event.
   * Set false for pure read-only lists where row clicks should do nothing.
   */
  selectable: z.boolean().default(true),

  // ── W2: section stack additions ─────────────────────────────────────────────

  /**
   * KPI stat tile row rendered above the tab strip and FilterBar.
   * Each KPI fetches a server-side count (PS.DATA pageSize=1, reads `total`).
   * When absent, no KPI row is rendered. (default: undefined = no KPI row)
   */
  kpis: z.array(KpiDefSchema).optional(),

  /**
   * Tab strip rendered above the FilterBar (SegmentedControl).
   * Selecting a tab merges its `where` clauses into the PS.DATA request.
   * When absent, no tab strip is rendered. (default: undefined = no tabs)
   */
  listTabs: z.array(ListTabSchema).optional(),

  // ── W6: drawer-for-detail ────────────────────────────────────────────────────

  /**
   * When true AND selectable is true (default), a row click opens a @dbp/ui Sheet
   * (right-side drawer, ~560px) showing the record fields as a read-only detail view
   * instead of dispatching the `dbp:entity-list:row-select` CustomEvent.
   *
   * The two paths are mutually exclusive: detailDrawer=true → Sheet; otherwise →
   * CustomEvent (master-detail). Dialog is NOT used for this (reserved for forms).
   *
   * `detailDrawer` also accepts a `RecordDrawerConfig` (entityType omitted —
   * it is always this list's own `entityType`) to upgrade the plain Sheet to
   * the APP.F25 record-drawer organism (tabs, workflow/comments/audit,
   * deep-linking, resize) per
   * docs/03-features/specs/organism-record-drawer-spec-2026-07-10.md §4.
   *
   * Default: false (preserves current CustomEvent behavior).
   */
  detailDrawer: z.union([z.boolean(), RecordDrawerConfigSchema.omit({ entityType: true })]).default(false),

  /**
   * When set, clicking a row navigates to `${detailHref}/${entityId}` via Next.js router.
   * Takes precedence over detailDrawer and the CustomEvent row-select path.
   * Use for list→detail page flows (e.g. "/admin/form-builder").
   */
  detailHref: z.string().startsWith("/").optional(),
});
export type EntityListConfig = z.infer<typeof EntityListConfig>;
