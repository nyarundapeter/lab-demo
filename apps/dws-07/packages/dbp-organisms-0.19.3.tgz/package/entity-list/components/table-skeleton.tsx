import * as React from "react";
import { Skeleton } from "@dbp/ui";
import type { ColumnDef } from "../types.js";

interface TableSkeletonProps {
  columns: ColumnDef[];
  rowCount: number;
  enableBulkActions: boolean;
}

/** Loading skeleton: renders ghost rows matching the configured column layout. */
export function TableSkeleton({ columns, rowCount, enableBulkActions }: TableSkeletonProps) {
  const colCount = enableBulkActions ? columns.length + 1 : columns.length;
  return (
    <div role="status" aria-label="Loading" className="w-full overflow-x-auto">
      <table className="w-full border-collapse text-[var(--text-sm)]">
        <thead>
          <tr className="border-b border-[var(--color-border)]">
            {enableBulkActions && (
              <th className="w-10 px-3 py-2">
                <Skeleton className="h-4 w-4" />
              </th>
            )}
            {columns.map((col) => (
              <th key={col.field} className={`px-3 py-2 text-left ${col.width ?? ""}`}>
                <Skeleton className="h-4 w-20" />
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: rowCount }).map((_, i) => (
            <tr key={i} className="border-b border-[var(--color-border)]">
              {Array.from({ length: colCount }).map((__, j) => (
                <td key={j} className="px-3 py-2">
                  <Skeleton className="h-4 w-full" />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
