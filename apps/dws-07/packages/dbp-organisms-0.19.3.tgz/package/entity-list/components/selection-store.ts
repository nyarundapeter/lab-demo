import { create } from "zustand";

interface SelectionState {
  selectedIds: Set<string>;
  toggleRow: (id: string) => void;
  toggleAll: (ids: string[]) => void;
  clearSelection: () => void;
}

/**
 * Per-feature Zustand store for bulk-action row selection.
 * Internal to APP.F01 — not exported from the package root.
 */
export const useSelectionStore = create<SelectionState>((set) => ({
  selectedIds: new Set<string>(),
  toggleRow: (id) =>
    set((state) => {
      const next = new Set(state.selectedIds);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return { selectedIds: next };
    }),
  toggleAll: (ids) =>
    set((state) => {
      const allSelected = ids.every((id) => state.selectedIds.has(id));
      if (allSelected) {
        const next = new Set(state.selectedIds);
        for (const id of ids) next.delete(id);
        return { selectedIds: next };
      }
      const next = new Set(state.selectedIds);
      for (const id of ids) next.add(id);
      return { selectedIds: next };
    }),
  clearSelection: () => set({ selectedIds: new Set<string>() }),
}));
