# @dbp/organisms/entity-list

**registryId:** `APP.F01`

Sortable/filterable entity table with columns, tabs, and KPI strip — the admin list archetype.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`EntityListConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `object-page-detail` and `collection-table` layouts.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/entity-list` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
