import * as React from "react";
import { useRouter } from "next/navigation";
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  flexRender,
  type SortingState,
  type ColumnDef as TanStackColumnDef,
} from "@tanstack/react-table";
import { ArrowUp, ArrowDown, ChevronsUpDown, Inbox, MoreHorizontal } from "lucide-react";
import {
  FilterBar,
  Alert,
  Badge,
  Checkbox,
  Button,
  ConflictBanner,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  EmptyState,
  Pagination,
  SegmentedControl,
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SectionCard,
  SectionLabel,
  StatTile,
  formatNumber,
  formatCurrency,
  formatPercent,
  formatDate,
  isIsoDateString,
  isYearMonthString,
  toast,
  useShortcuts,
} from "@dbp/ui";
import { useEntityList, useEntity, ConflictError } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import RecordDrawer from "@dbp/organisms/record-drawer";
import type { z } from "zod";
import { EntityListConfig, type ColumnDef, type KpiDef, type ListTab } from "./types.js";
import { useEntityListData } from "./hooks/use-entity-list-data.js";
import { useSelectionStore } from "./components/selection-store.js";
import { TableSkeleton } from "./components/table-skeleton.js";
import { matchesAll, toServerFilters, isFullyServerPushable } from "./lib/filter.js";

/**
 * Optional action button rendered in a trailing column on every data row.
 * Config-driven and @dbp/ui-only — no bespoke markup.
 *
 * Example:
 *   rowAction={{ label: "Open", onClick: (row) => setSelectedId(row.id) }}
 */
export interface RowAction {
  /** Button label (e.g. "Open", "Edit"). */
  label: string;
  /** Called with the full EntityRecord when the button is clicked. */
  onClick: (row: EntityRecord<EntityData>) => void;
}

/**
 * A single item in the trailing row-menu (rowActions). Config-driven and
 * @dbp/ui DropdownMenu-only — no bespoke markup. Mirrors the admin ConfigList
 * reference's per-row menu (Open/Edit/Duplicate/Test/View versions/Disable/Archive).
 */
export interface RowMenuAction {
  /** Menu item label (e.g. "Open", "Archive"). */
  label: string;
  /** Called with the full EntityRecord when the item is selected. */
  onClick: (row: EntityRecord<EntityData>) => void;
  /** Renders a separator above this item (groups related actions). */
  separatorBefore?: boolean;
  /** Renders the item in the destructive tone (e.g. "Archive", "Delete"). */
  danger?: boolean;
}

/**
 * Optional multi-item row menu (⋯ trigger) rendered in a trailing column on
 * every data row. Mutually exclusive with `rowAction` (single button) — when
 * both are supplied, `rowActions` wins. Returns the menu items for a given row
 * (so items can vary per-row, e.g. hide "Publish" for already-published rows).
 */
export type RowActions = (row: EntityRecord<EntityData>) => RowMenuAction[];

// ── Badge tone mapping (mirrors LVE's mapBadgeTone) ──────────────────────────

type BadgeTone =
  | "default" | "gray" | "info" | "success" | "warning" | "danger" | "orange" | "navy"
  | "active" | "paused" | "critical" | "testing";
const VALID_BADGE_TONES = new Set<string>([
  "default", "gray", "info", "success", "warning", "danger", "orange", "navy",
  "active", "paused", "critical", "testing",
]);

function mapBadgeTone(tone?: string): BadgeTone {
  if (!tone || tone === "neutral") return "gray";
  return VALID_BADGE_TONES.has(tone) ? (tone as BadgeTone) : "gray";
}

/** Format a single cell value given the column's format hint (or auto-detect). */
function formatCellValue(value: unknown, col: ColumnDef): string {
  if (value === null || value === undefined) return "";

  const raw = value;

  if (col.format && col.format !== "badge") {
    const n = Number(raw);
    switch (col.format) {
      case "number":
        return Number.isFinite(n)
          ? formatNumber(n, { compact: Math.abs(n) >= 10_000 })
          : String(raw);
      case "currency":
        return Number.isFinite(n)
          ? formatCurrency(n, "USD", { compact: Math.abs(n) >= 10_000 })
          : String(raw);
      case "percent":
        return Number.isFinite(n) ? formatPercent(n) : String(raw);
      case "date":
        return isIsoDateString(raw) || raw instanceof Date || typeof raw === "number"
          ? formatDate(raw as string | Date | number, "medium")
          : String(raw);
      case "datetime":
        return isIsoDateString(raw) || raw instanceof Date || typeof raw === "number"
          ? formatDate(raw as string | Date | number, "long")
          : String(raw);
    }
  }

  // Auto-detect: year-month strings (e.g. "2026-01") → "Jan 2026"
  if (isYearMonthString(raw)) {
    return formatDate(`${raw}-01`, "year-month");
  }

  // Auto-detect: full ISO date strings → "Jun 12, 2026"
  if (isIsoDateString(raw) && (raw as string).length > 7) {
    return formatDate(raw as string, "medium");
  }

  return String(raw);
}

// ── KPI count hook (real server-side total via pageSize=1) ────────────────────

/**
 * Fetches a server-side count for a KPI definition.
 * Uses PS.DATA with pageSize=1 and reads the `total` field — real count, no fakes.
 * The base entityType and static filters are merged with the KPI's own filters.
 */
function useKpiCount(
  entityType: string,
  baseFilters: EntityListConfig["filters"],
  kpi: KpiDef,
): { count: number; isLoading: boolean } {
  const mergedFilters = {
    ...(baseFilters ?? {}),
    ...(kpi.filters ?? {}),
  };
  const { total, isLoading } = useEntityList(entityType, {
    filters: mergedFilters,
    page: 1,
    pageSize: 1,
  });
  return { count: total, isLoading };
}

// ── Per-tab count probe ───────────────────────────────────────────────────────
// Renders nothing — issues a count query for one tab's where-clause and reports
// the total up so the count can be shown as a badge on the filter pill. Mounted
// once per tab (config.listTabs is stable, so hook order is stable).
function TabCountProbe({
  entityType,
  baseFilters,
  where,
  tabKey,
  onCount,
}: {
  entityType: string;
  baseFilters: EntityListConfig["filters"];
  where: ListTab["where"];
  tabKey: string;
  onCount: (key: string, count: number | undefined) => void;
}) {
  // A tab's where clauses are only fully expressible as PS.DATA query params when
  // every clause is "is" with a scalar value. Non-"is" ops (isNot/contains/>/</>=/<=/in)
  // are applied client-side on the fetched page (see effectiveFilters below) — a
  // server-side pageSize=1 total can't reflect that, so the count badge is hidden
  // (undefined) rather than showing a number that wouldn't match the visible rows.
  const clauses = React.useMemo(() => where ?? [], [where]);
  const fullyPushable = isFullyServerPushable(clauses);

  const filters = React.useMemo(() => {
    return { ...(baseFilters ?? {}), ...toServerFilters(clauses) };
  }, [baseFilters, clauses]);

  const { total } = useEntityList(entityType, { filters, page: 1, pageSize: 1 });

  React.useEffect(() => {
    onCount(tabKey, fullyPushable ? total : undefined);
  }, [tabKey, total, fullyPushable, onCount]);

  return null;
}

// ── Single KPI tile wrapper ───────────────────────────────────────────────────

// KPIs are display-only metrics — NOT clickable filters. Filtering is done via the
// pill tabs (which carry their own count badges), so a KPI tile never highlights
// or acts as a tab toggle (avoids the confusing "card is also a filter" pattern).
function KpiTile({
  entityType,
  baseFilters,
  kpi,
}: {
  entityType: string;
  baseFilters: EntityListConfig["filters"];
  kpi: KpiDef;
}) {
  const { count, isLoading } = useKpiCount(entityType, baseFilters, kpi);

  return (
    <div data-testid={`kpi-tile-${kpi.id}`}>
      <StatTile
        label={kpi.label}
        value={isLoading ? "—" : formatNumber(count)}
        tone={kpi.tone ?? "primary"}
      />
    </div>
  );
}

// ── Detail drawer content ─────────────────────────────────────────────────────

/**
 * Component-level (not Zod config) seam for solution/generator code to bind a
 * workflow-bound stepper into the EntityList drawer — Pattern B per
 * docs/01-Architecture/PS-WORKFLOW-UI-Patterns.md §4/§5b. Mirrors LVE's
 * `detailExtras` render-prop shape. Not part of EntityListConfig — passed
 * as a sibling prop to <EntityList> alongside the config (function fields
 * are data-only-Zod-incompatible).
 */
export interface EntityListDrawerExtras {
  /** Rendered above the field list (e.g. RecordWorkflowStepper, compact). */
  stepper?: (record: EntityRecord<EntityData>) => React.ReactNode;
  /** Rendered at the bottom of the drawer (e.g. workflow actions + Progress History link). */
  footer?: (record: EntityRecord<EntityData>) => React.ReactNode;
}

/**
 * DEFECT 4 (naive-UX-audit): a single body field row — read-only display, or (when
 * `col.editable`) an inline editable control that PATCHes via useEntity().update()
 * on blur/change. Previously the drawer was entirely read-only regardless of the
 * entity's field types.
 */
function DrawerField({
  col,
  value,
  onSave,
}: {
  col: ColumnDef;
  value: unknown;
  onSave: (field: string, next: string) => void;
}) {
  const [draft, setDraft] = React.useState(value === null || value === undefined ? "" : String(value));
  React.useEffect(() => {
    setDraft(value === null || value === undefined ? "" : String(value));
  }, [value]);

  if (!col.editable) {
    return (
      <div
        className="flex items-center justify-between gap-4 py-2.5"
        data-testid={`drawer-field-${col.field}`}
      >
        <span className="shrink-0 text-xs text-[var(--color-text-muted)]">{col.label}</span>
        <div className="min-w-0 text-right text-sm font-medium text-[var(--color-text-primary)]">
          {col.format === "badge" ? (
            <Badge tone={mapBadgeTone(col.badgeTones?.[String(value ?? "")])} size="sm">
              {String(value ?? "")}
            </Badge>
          ) : (
            <span>{value === null || value === undefined ? "—" : formatCellValue(value, col)}</span>
          )}
        </div>
      </div>
    );
  }

  if (col.editType === "select") {
    return (
      <div className="flex items-center justify-between gap-4 py-2.5" data-testid={`drawer-field-${col.field}`}>
        <label className="shrink-0 text-xs text-[var(--color-text-muted)]">{col.label}</label>
        <select
          className="min-w-0 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 py-1 text-sm text-right"
          value={draft}
          onChange={(e) => {
            setDraft(e.target.value);
            onSave(col.field, e.target.value);
          }}
        >
          {(col.editOptions ?? []).map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between gap-4 py-2.5" data-testid={`drawer-field-${col.field}`}>
      <label className="shrink-0 text-xs text-[var(--color-text-muted)]">{col.label}</label>
      <input
        type={col.editType === "number" ? "number" : "text"}
        className="min-w-0 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 py-1 text-sm text-right"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => {
          if (draft !== (value === null || value === undefined ? "" : String(value))) {
            onSave(col.field, draft);
          }
        }}
      />
    </div>
  );
}

function DetailDrawerContent({
  record,
  columns,
  entityType,
  drawerExtras,
}: {
  record: EntityRecord<EntityData>;
  columns: ColumnDef[];
  entityType?: string;
  drawerExtras?: EntityListDrawerExtras;
}) {
  const data = record.data as Record<string, unknown>;
  // First column is the title (shown in the sheet header) — don't repeat it below.
  const titleCol = columns[0];
  const title = titleCol ? String(data[titleCol.field] ?? record.id) : record.id;
  const bodyCols = columns.slice(1);
  const { update, conflict, resolveConflict } = useEntity(entityType ?? "", record.id, {
    enabled: false,
  });

  function handleSave(field: string, next: string) {
    void update({ [field]: next } as Partial<EntityData>).catch((err) => {
      // ConflictError populates `conflict` above (spec-ps-data-revisions-2026-07-17.md
      // §4) — the ConflictBanner renders instead of a toast in that case.
      if (err instanceof ConflictError) return;
      toast({ title: "Could not save change", description: "Try again." });
    });
  }

  return (
    <>
      <SheetHeader>
        <SheetTitle>{title}</SheetTitle>
      </SheetHeader>
      {drawerExtras?.stepper && (
        <div className="mt-4" data-testid="drawer-workflow-stepper">
          {drawerExtras.stepper(record)}
        </div>
      )}
      {conflict && (
        <div className="mt-4">
          <ConflictBanner
            updatedByLabel={conflict.theirs.updatedBy ?? "Someone else"}
            updatedAtLabel={conflict.theirs.updatedAt}
            fields={Object.keys(conflict.mine).map((field) => {
              const col = columns.find((c) => c.field === field);
              return {
                field,
                label: col?.label ?? field,
                mine: String((conflict.mine as Record<string, unknown>)[field]),
                theirs: String((conflict.theirs.data as Record<string, unknown>)[field]),
              };
            })}
            canOverwrite
            onResolve={(action) => void resolveConflict(action)}
          />
        </div>
      )}
      <div className="mt-5">
        <SectionCard title="Overview">
          <div className="divide-y divide-[var(--color-border-subtle)]">
            {bodyCols.map((col) => (
              <DrawerField key={col.field} col={col} value={data[col.field]} onSave={handleSave} />
            ))}
          </div>
        </SectionCard>
      </div>
      {drawerExtras?.footer && (
        <div className="mt-5" data-testid="drawer-workflow-footer">
          {drawerExtras.footer(record)}
        </div>
      )}
    </>
  );
}

// ── ConfigInput type (all defaulted fields optional at the call site) ─────────

type ConfigInput = Omit<
  EntityListConfig,
  "pageSize" | "enableBulkActions" | "enableSearch" | "selectable" | "detailDrawer"
> &
  Partial<
    Pick<EntityListConfig, "pageSize" | "enableBulkActions" | "enableSearch" | "selectable">
  > & {
    /**
     * Typed from the schema's INPUT shape, not its output. `RecordDrawerConfig`
     * defaults several members (`kpiFields`, `showStagePipeline`, …), so those are
     * required on the parsed output but optional at the call site. Deriving this
     * from `z.infer` (the output) made every caller supplying a partial drawer
     * config a type error, which is exactly what a `.default()` is supposed to
     * prevent.
     */
    detailDrawer?: z.input<typeof EntityListConfig>["detailDrawer"];
    /**
     * Optional action button rendered in a trailing column on every row.
     * Not part of the Zod schema (function field) — extracted before Zod parse.
     * See RowAction type for full docs.
     */
    rowAction?: RowAction;
    /**
     * Optional multi-item row menu (⋯), rendered instead of `rowAction` when
     * both are supplied. Not part of the Zod schema (function field) — see
     * RowActions/RowMenuAction types.
     */
    rowActions?: RowActions;
    /**
     * Optional workflow-bound stepper/footer seam for the detail drawer.
     * Not part of the Zod schema (function fields) — see EntityListDrawerExtras.
     */
    drawerExtras?: EntityListDrawerExtras;
  };

/**
 * APP.F01 — Entity List Table
 *
 * Receives CONFIG, never data. All rows are fetched via PS.DATA (useEntityList).
 * Search is handled by PS.SEARCH (useSearch) when enableSearch is true.
 *
 * The config is validated at render time via EntityListConfig.safeParse.
 * A config-error state is rendered (not thrown) on invalid config.
 *
 * W2 additions (all optional, backward-compatible):
 *   kpis      — stat tile row with real server-side counts
 *   listTabs  — SegmentedControl tab strip filtering the list
 *   columns[].format="badge" + badgeTones — badge cell rendering
 *
 * W6 addition (optional, backward-compatible):
 *   detailDrawer — row click opens a Sheet instead of dispatching CustomEvent
 */
export default function EntityList(rawConfig: ConfigInput) {
  // Extract function fields before Zod parse — Zod schemas are data-only.
  const { rowAction, rowActions, drawerExtras, ...rest } = rawConfig;
  const parseResult = EntityListConfig.safeParse(rest);
  if (!parseResult.success) {
    return (
      <Alert
        tone="danger"
        title="EntityList configuration error"
        data-testid="config-error"
      >
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>{e.path.join(".") || "root"}: {e.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }
  const config = parseResult.data;

  return (
    <EntityListInner
      config={config}
      {...(rowAction !== undefined && { rowAction })}
      {...(rowActions !== undefined && { rowActions })}
      {...(drawerExtras !== undefined && { drawerExtras })}
    />
  );
}

// ─── Inner component (config is guaranteed valid here) ───────────────────────

interface EntityListInnerProps {
  config: EntityListConfig;
  /** Optional action column — rendered as a trailing Button cell on each row. */
  rowAction?: RowAction;
  /** Optional multi-item row menu (⋯) — takes precedence over `rowAction`. */
  rowActions?: RowActions;
  /** Optional workflow-bound stepper/footer seam for the detail drawer. */
  drawerExtras?: EntityListDrawerExtras;
}

function EntityListInner({ config, rowAction, rowActions, drawerExtras }: EntityListInnerProps) {
  const router = useRouter();
  const [page, setPage] = React.useState(1);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [sorting, setSorting] = React.useState<SortingState>([]);
  // Master-detail: id of the row activated for the detail panel.
  const [selectedRowId, setSelectedRowId] = React.useState<string | null>(null);
  // W2: active tab key (undefined = "all" / no tab filter)
  const [activeTab, setActiveTab] = React.useState<string | undefined>(
    config.listTabs?.[0]?.key,
  );
  // W6: detail drawer open state + record to show
  const [drawerRecord, setDrawerRecord] = React.useState<EntityRecord<EntityData> | null>(null);
  const drawerOpen = drawerRecord !== null;

  // Resolve the active tab's where clauses → merge into data filters
  const activeTabWhere = React.useMemo<ListTab["where"] | undefined>(() => {
    if (!config.listTabs || !activeTab) return undefined;
    return config.listTabs.find((t) => t.key === activeTab)?.where;
  }, [config.listTabs, activeTab]);

  // Build the effective filters: static config.filters + active tab "is" clauses
  // (the only op PS.DATA's flat-filter query-param API can express server-side).
  // All other ops (isNot/contains/>/</>=/<=/in) are applied client-side below via
  // matchesAll, on the rows this fetch returns.
  const effectiveFilters = React.useMemo<EntityListConfig["filters"]>(() => {
    const base = config.filters ?? {};
    if (!activeTabWhere || activeTabWhere.length === 0) return base;
    return { ...base, ...toServerFilters(activeTabWhere) };
  }, [config.filters, activeTabWhere]);

  // Override config.filters with effectiveFilters for data fetching
  const dataConfig = React.useMemo(
    () => ({ ...config, filters: effectiveFilters }),
    [config, effectiveFilters],
  );

  // Dispatch the master-detail selection event a paired EntityDetail listens for.
  const selectRow = React.useCallback(
    (id: string) => {
      setSelectedRowId(id);
      document.dispatchEvent(
        new CustomEvent("dbp:entity-list:row-select", {
          detail: { entityType: config.entityType, id },
          bubbles: true,
        }),
      );
    },
    [config.entityType],
  );

  // Open the detail drawer for a row (W6)
  const openDrawer = React.useCallback(
    (record: EntityRecord<EntityData>) => {
      setDrawerRecord(record);
    },
    [],
  );

  const { rows: rawRows, total, pageSize, isLoading, error } = useEntityListData(
    dataConfig,
    page,
    searchQuery,
  );

  // Apply non-"is" tab clauses (isNot/contains/>/</>=/<=/in) client-side on the
  // fetched page — PS.DATA's query-param filter API can't express them server-side.
  // NOTE: like the "is" filters, this operates on the current page only.
  const rows = React.useMemo(() => {
    if (!activeTabWhere || activeTabWhere.length === 0) return rawRows;
    return rawRows.filter((r) =>
      matchesAll(r.data as Record<string, unknown>, activeTabWhere),
    );
  }, [rawRows, activeTabWhere]);

  const { selectedIds, toggleRow, toggleAll, clearSelection } = useSelectionStore();

  // Reset page when search or active tab changes
  React.useEffect(() => {
    setPage(1);
    clearSelection();
    setSelectedRowId(null);
  }, [searchQuery, activeTab, clearSelection]);

  // Build TanStack Table column defs from EntityListConfig.columns
  const tanstackColumns = React.useMemo<TanStackColumnDef<EntityRecord<EntityData>>[]>(() => {
    const cols: TanStackColumnDef<EntityRecord<EntityData>>[] = [];

    if (config.enableBulkActions) {
      cols.push({
        id: "__select__",
        header: ({ table }) => {
          const allIds = table.getRowModel().rows.map((r) => r.original.id);
          const allSelected = allIds.length > 0 && allIds.every((id) => selectedIds.has(id));
          const someSelected = allIds.some((id) => selectedIds.has(id));
          return (
            <Checkbox
              aria-label="Select all rows"
              checked={allSelected}
              indeterminate={!allSelected && someSelected}
              onCheckedChange={() => toggleAll(allIds)}
            />
          );
        },
        cell: ({ row }) => (
          <Checkbox
            aria-label={`Select row ${row.original.id}`}
            checked={selectedIds.has(row.original.id)}
            onCheckedChange={() => toggleRow(row.original.id)}
          />
        ),
        enableSorting: false,
        size: 40,
      });
    }

    for (const col of config.columns) {
      const colRef = col; // capture for closure
      cols.push({
        id: col.field,
        accessorFn: (row) => {
          const val = (row.data as Record<string, unknown>)[colRef.field];
          return val ?? "";
        },
        header: col.label,
        enableSorting: col.sortable ?? false,
        // size omitted — width applied via className in meta
        ...(col.width !== undefined && { meta: { width: col.width } }),
        cell: ({ getValue, row }) => {
          const raw = getValue();
          // W2: badge cell rendering
          if (colRef.format === "badge") {
            const key = String(raw ?? "");
            const tone = colRef.badgeTones?.[key];
            return (
              <Badge
                tone={mapBadgeTone(tone)}
                size="sm"
                data-testid={`badge-cell-${row.original.id}-${colRef.field}`}
              >
                {key}
              </Badge>
            );
          }
          return formatCellValue(raw, colRef);
        },
      });
    }

    // Trailing action column — a multi-item ⋯ menu (rowActions) takes precedence
    // over a single button (rowAction). Uses @dbp/ui DropdownMenu/Button so both
    // stay within the design system. Mirrors the admin ConfigList reference's
    // per-row RowMenu (Open/Edit/Duplicate/Test/View versions/Disable/Archive).
    if (rowActions) {
      const actionsRef = rowActions; // capture for closure
      cols.push({
        id: "__row_actions__",
        header: "",
        enableSorting: false,
        meta: { width: "w-[56px]" },
        cell: ({ row }) => {
          const items = actionsRef(row.original);
          if (items.length === 0) return null;
          return (
            <div className="flex justify-end pr-1">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={(e) => e.stopPropagation()}
                    aria-label="Row actions"
                    data-testid={`row-actions-${row.original.id}`}
                  >
                    <MoreHorizontal className="h-4 w-4" aria-hidden="true" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                  {items.map((item, i) => (
                    <React.Fragment key={item.label}>
                      {item.separatorBefore && i > 0 && <DropdownMenuSeparator />}
                      <DropdownMenuItem
                        onSelect={() => item.onClick(row.original)}
                        className={item.danger ? "text-[var(--color-danger-text)]" : undefined}
                      >
                        {item.label}
                      </DropdownMenuItem>
                    </React.Fragment>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          );
        },
      });
    } else if (rowAction) {
      const actionRef = rowAction; // capture for closure
      cols.push({
        id: "__row_action__",
        header: "",
        enableSorting: false,
        meta: { width: "w-[100px]" },
        cell: ({ row }) => (
          <div className="flex justify-end pr-1">
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={(e) => {
                // Stop row-level click from also firing (if selectable is on)
                e.stopPropagation();
                actionRef.onClick(row.original);
              }}
              data-testid={`row-action-${row.original.id}`}
            >
              {actionRef.label}
            </Button>
          </div>
        ),
      });
    }

    return cols;
  }, [config.columns, config.enableBulkActions, selectedIds, toggleRow, toggleAll, rowAction, rowActions]);

  const table = useReactTable({
    data: rows,
    columns: tanstackColumns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    manualPagination: true,
    pageCount: Math.ceil(total / pageSize),
  });

  // ── Bulk export action ────────────────────────────────────────────────────
  const handleExportSelection = React.useCallback(() => {
    const selected = rows.filter((r) => selectedIds.has(r.id)).map((r) => r.data);
    const json = JSON.stringify(selected, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${config.entityType}-selection.json`;

    // Dispatch before download for observability / future solution extension seam
    document.dispatchEvent(
      new CustomEvent("dbp:entity-list:export", {
        detail: { entityType: config.entityType, count: selected.length },
        bubbles: true,
      }),
    );

    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [rows, selectedIds, config.entityType]);

  // Keep the counter visible during background refetches (rows already present) —
  // only hide it on the initial load or on error.
  const showRecordCounter = !error && (rows.length > 0 || !isLoading);
  const isRefetching = isLoading && rows.length > 0;
  const visibleCount = rows.length;

  // ── W2: per-tab counts (shown as badges on the filter pills) ──────────────
  // undefined = badge hidden (tab's where has a non-"is" clause; a server total
  // wouldn't match the client-filtered rows the tab actually shows).
  const [tabCounts, setTabCounts] = React.useState<Record<string, number | undefined>>({});
  const reportTabCount = React.useCallback((key: string, count: number | undefined) => {
    setTabCounts((prev) => (prev[key] === count ? prev : { ...prev, [key]: count }));
  }, []);

  // ── W2: tab options for SegmentedControl ──────────────────────────────────
  const tabOptions = React.useMemo(
    () =>
      config.listTabs?.map((t) => {
        const count = tabCounts[t.key];
        return {
          value: t.key,
          label: t.label,
          ...(count !== undefined ? { count } : {}),
        };
      }) ?? [],
    [config.listTabs, tabCounts],
  );

  // ── Row click handler (detailHref → navigate, detailDrawer → Sheet, else CustomEvent) ──
  const handleRowClick = React.useCallback(
    (rowId: string, record: EntityRecord<EntityData>) => {
      if (config.detailHref) {
        router.push(`${config.detailHref}/${rowId}`);
      } else if (config.detailDrawer) {
        openDrawer(record);
      } else {
        selectRow(rowId);
      }
    },
    [config.detailHref, config.detailDrawer, router, openDrawer, selectRow],
  );

  const handleRowKeyDown = React.useCallback(
    (e: React.KeyboardEvent<HTMLTableRowElement>, rowId: string, record: EntityRecord<EntityData>) => {
      if (e.target !== e.currentTarget) return;
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        handleRowClick(rowId, record);
      }
    },
    [handleRowClick],
  );

  // ── j/k row-focus navigation (capability-keyboard-shortcuts-spec-2026-07-10.md
  // §2 default global map: "j/k → list focus, registered by list-bearing organisms,
  // surface scope"). Disabled when detailHref navigates the browser on selection
  // (moving focus a row at a time would fire a route change per keystroke) or when
  // the list isn't selectable at all.
  const activeRowId = config.detailDrawer ? drawerRecord?.id ?? null : selectedRowId;
  const activeRowIndex = rows.findIndex((r) => r.id === activeRowId);
  const focusRow = React.useCallback(
    (dir: 1 | -1) => {
      if (rows.length === 0) return;
      const base = activeRowIndex < 0 ? (dir === 1 ? -1 : 0) : activeRowIndex;
      const next = Math.max(0, Math.min(rows.length - 1, base + dir));
      const nextRow = rows[next];
      if (nextRow) handleRowClick(nextRow.id, nextRow);
    },
    [rows, activeRowIndex, handleRowClick],
  );
  useShortcuts(
    [
      { keys: "j", handler: () => focusRow(1), description: "Next row", group: "List navigation" },
      { keys: "k", handler: () => focusRow(-1), description: "Previous row", group: "List navigation" },
    ],
    { scope: "surface", enabled: config.selectable === true && !config.detailHref && rows.length > 0 },
  );

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col gap-3" data-testid="entity-list">

      {/* W2: KPI stat tile row */}
      {config.kpis && config.kpis.length > 0 && (
        <div
          className={[
            "grid gap-4",
            config.kpis.length <= 2
              ? "grid-cols-2"
              : config.kpis.length === 4
              ? "grid-cols-2 lg:grid-cols-4"
              : "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4",
          ].join(" ")}
          data-testid="kpi-row"
        >
          {config.kpis.map((kpi) => (
            <KpiTile
              key={kpi.id}
              entityType={config.entityType}
              baseFilters={config.filters}
              kpi={kpi}
            />
          ))}
        </div>
      )}

      {/* Per-tab count probes (render nothing) — populate the pill count badges. */}
      {config.listTabs?.map((t) => (
        <TabCountProbe
          key={`count-${t.key}`}
          entityType={config.entityType}
          baseFilters={config.filters}
          where={t.where}
          tabKey={t.key}
          onCount={reportTabCount}
        />
      ))}

      {/* W2: toolbar — tab pills + search + record counter all on one row */}
      {((config.listTabs && config.listTabs.length > 0) ||
        config.enableSearch ||
        showRecordCounter) && (
        <div className="flex flex-wrap items-center gap-3" data-testid="tab-strip">
          {config.listTabs && config.listTabs.length > 0 && (
            <SegmentedControl
              options={tabOptions}
              value={activeTab ?? config.listTabs[0]?.key ?? ""}
              onChange={(key) => {
                setActiveTab(key);
              }}
              name="entity-list-tabs"
            />
          )}
          {config.enableSearch && (
            <FilterBar
              searchValue={searchQuery}
              onSearchChange={(v) => setSearchQuery(v)}
              searchPlaceholder={`Search ${config.entityType}…`}
              data-testid="search-input"
            />
          )}
          {showRecordCounter && (
            <SectionLabel
              className="ml-auto font-mono tracking-[0.18em]"
              data-testid="record-counter"
            >
              {formatNumber(visibleCount)} OF {formatNumber(total)} RECORDS
            </SectionLabel>
          )}
        </div>
      )}

      {/* Bulk actions toolbar */}
      {config.enableBulkActions && selectedIds.size > 0 && (
        <div
          className="flex items-center gap-3 rounded-[var(--radius-button)] border border-[var(--color-border-default)] bg-[var(--color-surface)] px-3 py-2 text-sm"
          data-testid="bulk-toolbar"
        >
          <span className="text-[var(--color-text-muted)]">
            {selectedIds.size} selected
          </span>
          <Button
            type="button"
            size="sm"
            onClick={handleExportSelection}
            data-testid="export-button"
          >
            Export as JSON
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={clearSelection}
            aria-label="Clear selection"
            className="ml-auto"
          >
            Clear
          </Button>
        </div>
      )}

      {/* Table area — skeleton only on the INITIAL load (no rows yet). During a
          filter/search/page change the rows are kept (keepPreviousData) and the
          table stays mounted (dimmed) so it never blanks/reloads. */}
      {isLoading && rows.length === 0 ? (
        <TableSkeleton
          columns={config.columns}
          rowCount={config.pageSize}
          enableBulkActions={config.enableBulkActions}
        />
      ) : error ? (
        <EmptyState
          tone="danger"
          headline="Failed to load records"
          description={error.message}
          data-testid="error-state"
        />
      ) : rows.length === 0 ? (
        <EmptyState
          icon={<Inbox size={22} strokeWidth={1.5} />}
          title={`No ${config.entityType} records found`}
          data-testid="empty-state"
        />
      ) : (
        <div
          className={[
            "w-full overflow-x-auto rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-surface-content shadow-[var(--shadow-sm)]",
            "transition-opacity duration-150",
            isRefetching ? "opacity-60" : "",
          ].filter(Boolean).join(" ")}
          aria-busy={isRefetching}
        >
          <table
            className="w-full border-collapse text-sm text-[var(--color-text-primary)]"
            data-testid="data-table"
          >
            <thead>
              {table.getHeaderGroups().map((hg) => (
                <tr key={hg.id} className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]">
                  {hg.headers.map((header) => {
                    const canSort = header.column.getCanSort();
                    const sortDir = header.column.getIsSorted();
                    const metaWidth = (header.column.columnDef.meta as { width?: string } | undefined)?.width;
                    return (
                      <SectionLabel
                        as="th"
                        size="2xs"
                        key={header.id}
                        className={[
                          "px-4 py-3 text-left font-mono whitespace-nowrap",
                          metaWidth ?? "",
                          canSort ? "cursor-pointer select-none hover:text-[var(--color-text-secondary)]" : "",
                        ].join(" ")}
                        onClick={canSort ? header.column.getToggleSortingHandler() : undefined}
                        aria-sort={
                          sortDir === "asc"
                            ? "ascending"
                            : sortDir === "desc"
                            ? "descending"
                            : canSort
                            ? "none"
                            : undefined
                        }
                      >
                        <span className="flex items-center gap-1.5">
                          {flexRender(header.column.columnDef.header, header.getContext())}
                          {canSort && (
                            <span aria-hidden="true" className="text-[var(--color-text-disabled)]">
                              {sortDir === "asc" ? (
                                <ArrowUp size={13} strokeWidth={1.5} />
                              ) : sortDir === "desc" ? (
                                <ArrowDown size={13} strokeWidth={1.5} />
                              ) : (
                                <ChevronsUpDown size={13} strokeWidth={1.5} />
                              )}
                            </span>
                          )}
                        </span>
                      </SectionLabel>
                    );
                  })}
                </tr>
              ))}
            </thead>
            <tbody>
              {table.getRowModel().rows.map((row) => {
                const rowId = row.original.id;
                const isBulkSelected = selectedIds.has(rowId);
                // When detailDrawer is true, "selected" means drawer is open for this row.
                const isRowActive = config.selectable && (
                  config.detailDrawer
                    ? drawerRecord?.id === rowId
                    : selectedRowId === rowId
                );
                // Bulk (checkbox) selection wins visually — accent left-border + accent-tinted fill.
                // Otherwise master-detail active row gets the nav-tinted fill.
                // Row states use theme-aware role tokens (surface-accent/surface-nav) so
                // they read correctly in dark as well as light — never literal palette tints.
                const rowClass = isBulkSelected
                  ? "border-b border-l-2 border-l-[var(--color-secondary)] border-b-[var(--color-border-subtle)] bg-[var(--color-surface-accent)]"
                  : isRowActive
                  ? "border-b border-[var(--color-border-subtle)] bg-[var(--color-surface-nav)]"
                  : "border-b border-[var(--color-border-subtle)] transition-colors hover:bg-[var(--color-surface)]";
                return (
                <tr
                  key={row.id}
                  className={[rowClass, config.selectable ? "cursor-pointer" : ""].join(" ").trim()}
                  data-testid={`entity-row-${rowId}`}
                  data-selected={isRowActive ? "true" : undefined}
                  {...(config.selectable
                    ? {
                        role: "button" as const,
                        tabIndex: 0,
                        "aria-pressed": isRowActive,
                        onClick: () => handleRowClick(rowId, row.original),
                        onKeyDown: (e: React.KeyboardEvent<HTMLTableRowElement>) =>
                          handleRowKeyDown(e, rowId, row.original),
                      }
                    : {})}
                >
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id} className="px-4 py-2.5 whitespace-nowrap">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination — only shown when data is present */}
      {!isLoading && !error && rows.length > 0 && (
        <div className="flex justify-end pt-1" data-testid="pager">
          <Pagination
            page={page}
            pageSize={pageSize}
            total={total}
            showCaption
            onPageChange={(p) => {
              setPage(p);
              clearSelection();
            }}
          />
        </div>
      )}

      {/* W6 / APP.F25: Detail drawer — object config upgrades the plain Sheet to the
          record-drawer organism (tabs, workflow/comments/audit, deep-link, resize);
          detailDrawer=true keeps the original read-only Sheet. */}
      {config.detailDrawer && typeof config.detailDrawer === "object" ? (
        <RecordDrawer
          config={{ ...config.detailDrawer, entityType: config.entityType }}
          recordId={drawerRecord?.id ?? null}
          open={drawerOpen}
          onOpenChange={(open) => {
            if (!open) setDrawerRecord(null);
          }}
          // N35 — prev/next navigation is context-driven from this list's current
          // result set (not config): position within the on-screen page of rows.
          {...(drawerRecord &&
            rows.some((r) => r.id === drawerRecord.id) && {
              nav: {
                index: rows.findIndex((r) => r.id === drawerRecord.id),
                total: rows.length,
                onPrev: () => {
                  const i = rows.findIndex((r) => r.id === drawerRecord.id);
                  if (i > 0) setDrawerRecord(rows[i - 1] ?? null);
                },
                onNext: () => {
                  const i = rows.findIndex((r) => r.id === drawerRecord.id);
                  if (i >= 0 && i < rows.length - 1) setDrawerRecord(rows[i + 1] ?? null);
                },
              },
            })}
        />
      ) : (
        config.detailDrawer && (
          <Sheet
            open={drawerOpen}
            onOpenChange={(open) => {
              if (!open) setDrawerRecord(null);
            }}
          >
            <SheetContent
              side="right"
              className="w-[560px] max-w-[90vw] overflow-y-auto"
              data-testid="detail-drawer"
            >
              {drawerRecord && (
                <DetailDrawerContent
                  record={drawerRecord}
                  columns={config.columns}
                  entityType={config.entityType}
                  {...(drawerExtras !== undefined && { drawerExtras })}
                />
              )}
            </SheetContent>
          </Sheet>
        )
      )}
    </div>
  );
}
