import { useEntityList } from "@dbp/ps-data/client";
import { useSearch } from "@dbp/ps-search/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { EntityListConfig } from "../types.js";

interface EntityListDataResult {
  rows: EntityRecord<EntityData>[];
  total: number;
  page: number;
  pageSize: number;
  isLoading: boolean;
  error: Error | null;
}

/**
 * Wires PS.DATA (useEntityList) and, when a search query is active, PS.SEARCH (useSearch).
 *
 * PS.SEARCH interplay:
 * - Empty query → pure PS.DATA fetch with static filters and pagination.
 * - Non-empty query → useSearch fires; its result IDs are used as an `id` filter on
 *   PS.DATA so that full entity fields are available for all configured columns.
 *   Pagination is locked to page=1 and pageSize=100 while a search is active (one
 *   full-results page). A future minor can implement cursor-based search pagination.
 */
export function useEntityListData(
  config: EntityListConfig,
  page: number,
  searchQuery: string,
): EntityListDataResult {
  const isSearchActive = searchQuery.trim().length > 0;

  const { results: searchHits, loading: searchLoading } = useSearch(
    searchQuery,
    { entityType: config.entityType },
  );

  // Only constrain PS.DATA by the search-result IDs once the search has actually
  // resolved. While the search is still loading we keep the CURRENT filters/page
  // so the table stays populated (TanStack keepPreviousData) instead of blanking
  // to a skeleton on every keystroke. `id` is the standard filter key; PS.DATA
  // supports comma-separated ID lists.
  const searchReady = isSearchActive && !searchLoading;

  const dataFilters = searchReady
    ? { ...config.filters, id: searchHits.map((h) => h.id).join(",") }
    : config.filters;

  const dataOptions = searchReady
    ? { ...(dataFilters !== undefined && { filters: dataFilters }), page: 1, pageSize: 100 }
    : { ...(dataFilters !== undefined && { filters: dataFilters }), page, pageSize: config.pageSize };

  const { rows, total, page: resultPage, pageSize: resultPageSize, isLoading: dataLoading, error } =
    useEntityList(config.entityType, dataOptions);

  return {
    rows,
    total,
    page: resultPage,
    pageSize: resultPageSize,
    // isLoading is reserved for the INITIAL load only (the consumer keeps the
    // table mounted during background refetches); searchLoading is folded in so
    // the initial search still shows the skeleton when there are no rows yet.
    isLoading: dataLoading || (isSearchActive && searchLoading),
    error: error as Error | null,
  };
}
