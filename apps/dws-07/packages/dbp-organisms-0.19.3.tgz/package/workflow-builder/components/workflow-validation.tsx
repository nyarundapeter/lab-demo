import { ChevronRight, CircleX, TriangleAlert } from "lucide-react";
import { Button } from "@dbp/ui";
import type { WorkflowBuilderConfig } from "../types.js";

interface Props {
  items: WorkflowBuilderConfig["validation"];
  onJump: (nodeId: string) => void;
}

/** Validation list — port of admin-workflow-builder.jsx's `WfValidation`. */
export function WorkflowValidation({ items, onJump }: Props) {
  const errorCount = items.filter((x) => x.level === "error").length;
  const warningCount = items.filter((x) => x.level === "warning").length;

  return (
    <div>
      <div className="mb-2.5 flex gap-3 text-xs">
        <span className="font-semibold text-[var(--color-danger)]">{errorCount} errors</span>
        <span className="font-semibold text-[var(--color-warning)]">{warningCount} warnings</span>
      </div>
      <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
        {items.map((x, i) => (
          <Button
            type="button"
            variant="ghost"
            key={i}
            onClick={() => onJump(x.nodeId)}
            className="h-auto w-full justify-start rounded-none px-2.5 py-2.5 text-left font-normal hover:bg-[var(--color-surface)]"
            style={i < items.length - 1 ? { borderBottom: "1px solid var(--color-border-subtle)" } : undefined}
          >
            {x.level === "error" ? (
              <CircleX size={14} className="mt-0.5 shrink-0 text-[var(--color-danger)]" aria-hidden="true" />
            ) : (
              <TriangleAlert size={14} className="mt-0.5 shrink-0 text-[var(--color-warning)]" aria-hidden="true" />
            )}
            <div className="flex-1">
              <div className="text-xs font-medium">{x.node}</div>
              <div className="text-xs text-text-muted">{x.msg}</div>
            </div>
            <ChevronRight size={13} className="mt-0.5 shrink-0 text-text-muted" aria-hidden="true" />
          </Button>
        ))}
      </div>
    </div>
  );
}
