import React from "react";
import { Trash2 } from "lucide-react";
import { Input, Textarea, Select, SelectTrigger, SelectContent, SelectItem, SelectValue, Button, Alert, SectionLabel } from "@dbp/ui";
import type { WorkflowNode } from "../types.js";

interface Props {
  node: WorkflowNode;
  colorByKind: Record<string, string>;
  onChange: (patch: Partial<WorkflowNode>) => void;
}

/**
 * Kind-adaptive node inspector — port of admin-workflow-builder.jsx's
 * `NodeProperties`. Each `node.kind` branch shows different fields, matching
 * the reference exactly (approval/system/notify/decision + a generic
 * assignee fallback for every other kind).
 */
export function NodeProperties({ node, colorByKind, onChange }: Props) {
  return (
    <div className="flex flex-col">
      <div className="flex items-center gap-2 border-b border-border-default px-4 py-3.5">
        <span
          className="flex h-[26px] w-[26px] items-center justify-center rounded-[4px] text-xs font-bold text-white"
          style={{ background: colorByKind[node.kind] ?? "var(--color-text-muted)" }}
        >
          {node.kind.slice(0, 1).toUpperCase()}
        </span>
        <div>
          <div className="text-sm font-semibold">{node.type}</div>
          <div className="text-xs text-text-muted">Node · {node.id}</div>
        </div>
      </div>

      {node.error && (
        <div className="px-4 pt-2.5">
          <Alert tone="danger" title="Configuration incomplete">
            This node has no connection configured.
          </Alert>
        </div>
      )}

      <div className="flex flex-col gap-3 p-4">
        <FieldRow label="Name">
          <Input className="h-8 text-xs" value={node.title} onChange={(e) => onChange({ title: e.target.value })} />
        </FieldRow>
        <FieldRow label="Description">
          <Textarea className="min-h-[52px] text-xs" placeholder="Describe this step…" />
        </FieldRow>

        {node.kind === "approval" && (
          <>
            <SectionTitle>Approver</SectionTitle>
            <FieldRow label="Approval type">
              <StaticSelect options={["Role-based", "Specific user", "Manager hierarchy", "Threshold-based"]} />
            </FieldRow>
            <FieldRow label="Approver role">
              <StaticSelect options={["Line manager", "Department head", "Finance approver"]} />
            </FieldRow>
            <FieldRow label="Approval mode">
              <StaticSelect options={["Sequential", "Parallel (all must approve)", "Parallel (any one)"]} />
            </FieldRow>
            <SectionTitle>SLA & escalation</SectionTitle>
            <FieldRow label="Approve within" help="Escalates if no decision in time.">
              <div className="flex gap-2">
                <Input className="h-8 w-16 text-xs" defaultValue="48" />
                <StaticSelect options={["hours", "days"]} />
              </div>
            </FieldRow>
            <FieldRow label="On timeout">
              <StaticSelect options={["Escalate to department head", "Auto-approve", "Auto-reject"]} />
            </FieldRow>
          </>
        )}

        {node.kind === "system" && (
          <>
            <SectionTitle>Action</SectionTitle>
            <FieldRow label="System action">
              <StaticSelect options={["Update record field", "Recalculate balance", "Sync to calendar"]} />
            </FieldRow>
            <FieldRow label="Retry policy">
              <StaticSelect options={["3 attempts, exponential backoff", "No retry"]} />
            </FieldRow>
          </>
        )}

        {node.kind === "notify" && (
          <>
            <SectionTitle>Notification</SectionTitle>
            <FieldRow label="Template" required>
              <StaticSelect options={["Select a template…", "Request rejected"]} tone="danger" />
            </FieldRow>
            <FieldRow label="Channel">
              <StaticSelect options={["In-app + Email", "Email only"]} />
            </FieldRow>
            <FieldRow label="Recipient">
              <StaticSelect options={["Requester", "Manager"]} />
            </FieldRow>
          </>
        )}

        {node.kind === "decision" && (
          <>
            <SectionTitle>Branches</SectionTitle>
            <div className="flex flex-col gap-1.5 text-xs">
              <div className="flex items-center gap-1.5 text-[var(--color-success)]">✓ Yes — balance ≥ requested</div>
              <div className="flex items-center gap-1.5 text-[var(--color-danger)]">✕ No — insufficient balance</div>
            </div>
            <Button type="button" variant="outline" size="sm" className="mt-2 self-start">
              Add branch
            </Button>
          </>
        )}

        {!["approval", "system", "notify", "decision"].includes(node.kind) && (
          <FieldRow label="Assignee">
            <Input
              className="h-8 text-xs"
              defaultValue={node.assignee ?? ""}
              placeholder="Team, role, or user"
              onChange={(e) => onChange({ assignee: e.target.value })}
            />
          </FieldRow>
        )}

        <Button type="button" variant="ghost" size="sm" className="mt-2 self-start text-[var(--color-danger)]">
          <Trash2 size={13} />
          Delete node
        </Button>
      </div>
    </div>
  );
}

function StaticSelect({ options, tone }: { options: string[]; tone?: "danger" }) {
  return (
    <Select defaultValue={options[0] ?? ""}>
      <SelectTrigger className={`h-8 text-xs ${tone === "danger" ? "border-[var(--color-danger)]" : ""}`}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o} value={o}>
            {o}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <SectionLabel as="div" className="mt-1 text-text-muted">{children}</SectionLabel>;
}

function FieldRow({
  label,
  help,
  required,
  children,
}: {
  label: string;
  help?: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1 text-xs">
      <span className="font-medium text-text-secondary">
        {label}
        {required && <span className="text-[var(--color-danger)]"> *</span>}
      </span>
      {children}
      {help && <span className="text-xs text-text-muted">{help}</span>}
    </label>
  );
}
