import React from "react";
import type { WorkflowNode, WorkflowEdge } from "../types.js";

const NODE_W = 168;
const NODE_H = 62;
const EDGE_COLORS: Record<string, string> = {
  success: "var(--color-success)",
  failure: "var(--color-danger)",
  default: "var(--color-border-default)",
};
const ACTIVE_TEST_COLOR = "var(--color-active)";
const FALLBACK_NODE_COLOR = "var(--color-text-muted)";

function edgePath(a: { x: number; y: number }, b: { x: number; y: number }): string {
  const x1 = a.x + NODE_W;
  const y1 = a.y + NODE_H / 2;
  const x2 = b.x;
  const y2 = b.y + NODE_H / 2;
  const dx = Math.max(40, Math.abs(x2 - x1) / 2);
  return `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
}

interface Props {
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  nodeColors: Record<string, string>;
  paletteIconByKind: Record<string, string>;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onNodeMove: (id: string, x: number, y: number) => void;
  zoom: number;
  pan: { x: number; y: number };
  onPan: (pan: { x: number; y: number }) => void;
  testMode: boolean;
  activeTestNodeId: string | null;
  visitedTestNodeIds: Set<string>;
}

/**
 * Node canvas: SVG edges + draggable node cards + minimap, with mouse-driven
 * pan/zoom. Port of admin-workflow-builder.jsx's canvas — plain
 * window-mousemove/mouseup drag tracking (via refs), same approach as the
 * reference, no drag-and-drop library.
 */
export function WorkflowCanvas({
  nodes,
  edges,
  nodeColors,
  paletteIconByKind,
  selectedId,
  onSelect,
  onNodeMove,
  zoom,
  pan,
  onPan,
  testMode,
  activeTestNodeId,
  visitedTestNodeIds,
}: Props) {
  const dragRef = React.useRef<{ id: string; mx: number; my: number; x: number; y: number } | null>(null);
  const bounds = { w: 1360, h: 480 };

  const onNodeDown = (e: React.MouseEvent, node: WorkflowNode) => {
    e.stopPropagation();
    onSelect(node.id);
    dragRef.current = { id: node.id, mx: e.clientX, my: e.clientY, x: node.x, y: node.y };

    const move = (ev: MouseEvent) => {
      const d = dragRef.current;
      if (!d) return;
      const nx = d.x + (ev.clientX - d.mx) / zoom;
      const ny = d.y + (ev.clientY - d.my) / zoom;
      onNodeMove(d.id, Math.round(nx), Math.round(ny));
    };
    const up = () => {
      dragRef.current = null;
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  const onCanvasDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest("[data-wf-node]")) return;
    onSelect(null);
    const start = { mx: e.clientX, my: e.clientY, px: pan.x, py: pan.y };
    const move = (ev: MouseEvent) => onPan({ x: start.px + (ev.clientX - start.mx), y: start.py + (ev.clientY - start.my) });
    const up = () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  return (
    <div
      data-testid="wf-canvas-background"
      className="relative h-full flex-1 overflow-hidden bg-[var(--color-surface)]"
      style={{ cursor: "grab" }}
      onMouseDown={onCanvasDown}
    >
      <div style={{ position: "absolute", transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: "0 0" }}>
        <svg width={bounds.w} height={bounds.h} style={{ position: "absolute", top: 0, left: 0, overflow: "visible", pointerEvents: "none" }}>
          <defs>
            {Object.entries(EDGE_COLORS).map(([k, c]) => (
              <marker key={k} id={`wf-arrow-${k}`} markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
                <path d="M0,0 L8,4 L0,8 Z" fill={c} />
              </marker>
            ))}
          </defs>
          {edges.map((e, i) => {
            const a = nodes.find((n) => n.id === e.from);
            const b = nodes.find((n) => n.id === e.to);
            if (!a || !b) return null;
            const inTestPath = testMode && visitedTestNodeIds.has(e.from) && (visitedTestNodeIds.has(e.to) || e.to === activeTestNodeId);
            const color = inTestPath ? ACTIVE_TEST_COLOR : (EDGE_COLORS[e.kind] ?? EDGE_COLORS.default);
            const mid = { x: (a.x + NODE_W + b.x) / 2, y: (a.y + b.y) / 2 + NODE_H / 2 };
            return (
              <g key={i}>
                <path
                  d={edgePath(a, b)}
                  fill="none"
                  stroke={color}
                  strokeWidth={inTestPath ? 2.5 : 1.75}
                  markerEnd={`url(#wf-arrow-${e.kind})`}
                />
                {e.label && (
                  <g>
                    <rect
                      x={mid.x - e.label.length * 3.5 - 6}
                      y={mid.y - 9}
                      width={e.label.length * 7 + 12}
                      height={18}
                      rx={4}
                      fill="white"
                      stroke={color}
                      strokeWidth="1"
                    />
                    <text x={mid.x} y={mid.y + 3.5} textAnchor="middle" fontSize="10.5" fill={color} fontWeight="600">
                      {e.label}
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>

        {nodes.map((n) => {
          const isActive = activeTestNodeId === n.id;
          const wasVisited = testMode && visitedTestNodeIds.has(n.id) && !isActive;
          const color = nodeColors[n.kind] ?? FALLBACK_NODE_COLOR;
          return (
            <div
              key={n.id}
              data-wf-node
              className="absolute flex flex-col gap-1 rounded-[var(--radius-card)] border bg-[var(--color-surface-content)] px-3 py-2 shadow-[var(--shadow-sm)]"
              style={{
                left: n.x,
                top: n.y,
                width: NODE_W,
                minHeight: NODE_H,
                cursor: "grab",
                borderColor: selectedId === n.id ? "var(--color-primary)" : "var(--color-border-default)",
                borderWidth: selectedId === n.id ? 2 : 1,
                ...(isActive
                  ? {
                      borderColor: ACTIVE_TEST_COLOR,
                      boxShadow: `0 0 0 3px color-mix(in srgb, ${ACTIVE_TEST_COLOR} 30%, transparent)`,
                    }
                  : {}),
                opacity: wasVisited ? 0.75 : 1,
              }}
              onMouseDown={(e) => onNodeDown(e, n)}
            >
              <div className="flex items-center gap-1.5">
                <span
                  className="flex h-5 w-5 shrink-0 items-center justify-center rounded-[4px] text-xs font-bold text-white"
                  style={{ background: color }}
                >
                  {(paletteIconByKind[n.kind] ?? n.kind).slice(0, 1).toUpperCase()}
                </span>
                <span className="min-w-0 flex-1 truncate text-xs font-semibold">{n.title}</span>
                {n.error && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--color-danger)]" aria-label="Error" />}
                {n.warn && !n.error && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--color-warning)]" aria-label="Warning" />}
                {wasVisited && <span className="shrink-0 text-[var(--color-success)]">✓</span>}
              </div>
              <div className="text-xs text-text-muted">{n.type}</div>
              {n.assignee && <div className="text-xs">{n.assignee}</div>}
            </div>
          );
        })}
      </div>

      {/* Minimap */}
      <div className="absolute bottom-3 right-3 w-40 overflow-hidden rounded-[var(--radius-card)] border border-border-default bg-[var(--color-surface-content)]">
        <div className="border-b border-border-default px-1.5 py-1 text-xs text-text-muted">Overview</div>
        <svg width="160" height="90" viewBox={`0 0 ${bounds.w} ${bounds.h + 80}`}>
          {edges.map((e, i) => {
            const a = nodes.find((n) => n.id === e.from);
            const b = nodes.find((n) => n.id === e.to);
            if (!a || !b) return null;
            return (
              <line
                key={i}
                x1={a.x + NODE_W / 2}
                y1={a.y + NODE_H / 2}
                x2={b.x + NODE_W / 2}
                y2={b.y + NODE_H / 2}
                stroke="var(--color-border-default)"
                strokeWidth="3"
              />
            );
          })}
          {nodes.map((n) => (
            <rect key={n.id} x={n.x} y={n.y} width={NODE_W} height={NODE_H} rx="8" fill={nodeColors[n.kind] ?? FALLBACK_NODE_COLOR} opacity="0.7" />
          ))}
        </svg>
      </div>
    </div>
  );
}
