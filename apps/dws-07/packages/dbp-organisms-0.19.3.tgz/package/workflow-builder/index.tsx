import React from "react";
import {
  Play,
  Save,
  Rocket,
  Undo2,
  Redo2,
  ZoomOut,
  ZoomIn,
  Maximize,
  ChevronLeft,
  ChevronRight as ChevronRightIcon,
  RefreshCw,
  PlayCircle,
} from "lucide-react";
import { Alert, Badge, Button, SuggestedAction, SectionLabel } from "@dbp/ui";
import PublishReview from "../publish-review/index.js";
import { WorkflowCanvas } from "./components/workflow-canvas.js";
import { NodeProperties } from "./components/node-properties.js";
import { WorkflowValidation } from "./components/workflow-validation.js";
import { WorkflowBuilderConfig, type WorkflowBuilderConfigInput, type WorkflowNode } from "./types.js";

/**
 * Visual workflow definition editor — node-graph canvas with drag/pan/zoom,
 * a kind-adaptive node-properties panel, a validation list, and a
 * step-through test mode. Port of admin-workflow-builder.jsx's
 * `WorkflowBuilder`.
 *
 * UI-only, prop-driven — no backend call. `config` is the initial state,
 * this component owns all canvas/selection/test-mode interaction locally.
 * Publish composes the shared `@dbp/organism-publish-review` (APP.F39)
 * rather than reimplementing it (WfPublishReview was a near-duplicate of
 * ConfigDetail's PublishReview — collapsed to one pattern per
 * wave3-family2-tier-audit.md §F).
 *
 * Node-kind coverage is intentionally incomplete against the real engine:
 * only 6 of 14 node kinds (start/end/user/system/approval/notify) map onto
 * today's PS.WORKFLOW step types. The other 8 (split/merge/decision/review/
 * integration/delay/wait/escalation) render in the palette and on canvas —
 * this is a visual definition editor, not validation that the engine can
 * execute them — see FEATURE.md.
 */
export default function WorkflowBuilder(config: WorkflowBuilderConfigInput) {
  const parsed = WorkflowBuilderConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="WorkflowBuilder — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <WorkflowBuilderInner config={parsed.data} />;
}

function WorkflowBuilderInner({ config }: { config: WorkflowBuilderConfig }) {
  const [nodes, setNodes] = React.useState<WorkflowNode[]>(config.nodes);
  const [selectedId, setSelectedId] = React.useState<string | null>(config.nodes[0]?.id ?? null);
  const [zoom, setZoom] = React.useState(0.85);
  const [pan, setPan] = React.useState({ x: 20, y: 10 });
  const [testMode, setTestMode] = React.useState(false);
  const [testStep, setTestStep] = React.useState(0);
  const [publishOpen, setPublishOpen] = React.useState(false);
  const [dirty, setDirty] = React.useState(false);

  const selectedNode = nodes.find((n) => n.id === selectedId) ?? null;
  const paletteIconByKind = React.useMemo(() => {
    const map: Record<string, string> = {};
    for (const group of config.palette) {
      for (const item of group.nodes) map[item.kind] = item.icon ?? item.kind;
    }
    return map;
  }, [config.palette]);

  const testNodeOrder = config.testNodeOrder;
  const activeTestNodeId = testMode ? (testNodeOrder[testStep] ?? null) : null;
  const visitedTestNodeIds = React.useMemo(() => {
    if (!testMode) return new Set<string>();
    return new Set(testNodeOrder.slice(0, testStep));
  }, [testMode, testStep, testNodeOrder]);

  const onNodeMove = (id: string, x: number, y: number) => {
    setNodes((ns) => ns.map((n) => (n.id === id ? { ...n, x, y } : n)));
    setDirty(true);
  };

  const onNodePatch = (patch: Partial<WorkflowNode>) => {
    if (!selectedId) return;
    setNodes((ns) => ns.map((n) => (n.id === selectedId ? { ...n, ...patch } : n)));
    setDirty(true);
  };

  return (
    <div className="flex h-full flex-col">
      {/* Toolbar */}
      <div className="flex shrink-0 items-center gap-2 border-b border-border-default bg-[var(--color-surface-content)] px-3 py-2">
        <span className="text-sm font-semibold">{config.workflowName}</span>
        <Badge tone={testMode ? "testing" : "gray"}>{testMode ? "Test mode" : config.statusLabel}</Badge>
        <Badge tone="gray">{config.env}</Badge>
        <div className="flex-1" />
        <div className="flex items-center gap-0.5 rounded-[6px] border border-border-default p-0.5">
          <Button type="button" variant="ghost" size="sm" className="h-7 w-7 p-0" aria-label="Undo" disabled>
            <Undo2 size={13} />
          </Button>
          <Button type="button" variant="ghost" size="sm" className="h-7 w-7 p-0" aria-label="Redo" disabled>
            <Redo2 size={13} />
          </Button>
        </div>
        <div className="flex items-center gap-0.5 rounded-[6px] border border-border-default p-0.5">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0"
            aria-label="Zoom out"
            onClick={() => setZoom((z) => Math.max(0.4, +(z - 0.1).toFixed(2)))}
          >
            <ZoomOut size={13} />
          </Button>
          <span className="w-10 text-center text-xs">{Math.round(zoom * 100)}%</span>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0"
            aria-label="Zoom in"
            onClick={() => setZoom((z) => Math.min(1.4, +(z + 0.1).toFixed(2)))}
          >
            <ZoomIn size={13} />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0"
            aria-label="Fit to view"
            onClick={() => {
              setZoom(0.85);
              setPan({ x: 20, y: 10 });
            }}
          >
            <Maximize size={13} />
          </Button>
        </div>
        <Button
          type="button"
          variant={testMode ? undefined : "outline"}
          size="sm"
          onClick={() => {
            setTestMode(!testMode);
            setTestStep(0);
          }}
        >
          <Play size={13} />
          {testMode ? "Exit test" : "Test"}
        </Button>
        <Button type="button" variant="outline" size="sm" onClick={() => setDirty(false)}>
          <Save size={13} />
          Save draft
        </Button>
        <Button type="button" size="sm" onClick={() => setPublishOpen(true)}>
          <Rocket size={13} />
          Publish
        </Button>
      </div>

      <div className="flex min-h-0 flex-1">
        {/* Palette */}
        <div className="w-[180px] shrink-0 overflow-y-auto border-r border-border-default bg-[var(--color-surface-content)] p-2">
          <SectionLabel className="px-1 pb-2 block text-xs text-text-muted">Components</SectionLabel>
          {config.palette.map((group) => (
            <div key={group.group} className="mb-3">
              <div className="px-1 py-1 text-xs font-medium text-text-muted">{group.group}</div>
              {group.nodes.map((n) => (
                <div key={n.kind} className="flex items-center gap-2 rounded-[4px] px-1.5 py-1.5 text-xs hover:bg-[var(--color-surface)]" title={`${n.type}`}>
                  <span
                    className="flex h-5 w-5 shrink-0 items-center justify-center rounded-[4px] text-xs font-bold text-white"
                    style={{ background: n.color }}
                  >
                    {n.type.slice(0, 1).toUpperCase()}
                  </span>
                  <span>{n.type}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Canvas */}
        <div className="relative min-w-0 flex-1">
          {testMode && (
            <div className="absolute left-3 top-3 z-10 flex items-center gap-2 rounded-[8px] border border-border-default bg-[var(--color-surface-content)] px-2.5 py-1.5 shadow-[var(--shadow-sm)]">
              <PlayCircle size={15} className="text-[var(--color-primary)]" aria-hidden="true" />
              <span className="text-xs font-medium">
                Step {testStep + 1} of {testNodeOrder.length}
              </span>
              <span className="text-xs text-text-muted">{nodes.find((n) => n.id === activeTestNodeId)?.title}</span>
              <div className="h-4 w-px bg-border-default" />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0"
                aria-label="Previous step"
                disabled={testStep === 0}
                onClick={() => setTestStep((s) => Math.max(0, s - 1))}
              >
                <ChevronLeft size={13} />
              </Button>
              <Button
                type="button"
                size="sm"
                className="h-7 px-2"
                onClick={() => setTestStep((s) => Math.min(testNodeOrder.length - 1, s + 1))}
              >
                <ChevronRightIcon size={13} />
                Step
              </Button>
              <Button type="button" variant="ghost" size="sm" className="h-7 w-7 p-0" aria-label="Reset" onClick={() => setTestStep(0)}>
                <RefreshCw size={13} />
              </Button>
            </div>
          )}

          <WorkflowCanvas
            nodes={nodes}
            edges={config.edges}
            nodeColors={config.nodeColors}
            paletteIconByKind={paletteIconByKind}
            selectedId={selectedId}
            onSelect={setSelectedId}
            onNodeMove={onNodeMove}
            zoom={zoom}
            pan={pan}
            onPan={setPan}
            testMode={testMode}
            activeTestNodeId={activeTestNodeId}
            visitedTestNodeIds={visitedTestNodeIds}
          />
        </div>

        {/* Properties panel */}
        <div className="w-[300px] shrink-0 overflow-y-auto border-l border-border-default bg-[var(--color-surface-content)]">
          {selectedNode ? (
            <NodeProperties node={selectedNode} colorByKind={config.nodeColors} onChange={onNodePatch} />
          ) : (
            <div className="flex flex-col gap-4 p-4">
              <div>
                <SectionLabel className="mb-2.5 block text-text-muted">Validation</SectionLabel>
                <WorkflowValidation items={config.validation} onJump={setSelectedId} />
              </div>
              {config.suggestion && (
                <SuggestedAction
                  title={config.suggestion.title}
                  reason={config.suggestion.reason}
                  impact={config.suggestion.impact}
                  records={config.suggestion.records}
                  {...(config.suggestion.confidence !== undefined && { confidence: config.suggestion.confidence })}
                  permission={config.suggestion.permission}
                />
              )}
            </div>
          )}
        </div>
      </div>

      {dirty && (
        <div className="flex shrink-0 items-center gap-3 border-t border-border-default bg-[var(--color-surface-content)] px-4 py-2.5">
          <span className="text-sm">Unsaved changes</span>
          <div className="flex-1" />
          <Button type="button" variant="outline" size="sm" onClick={() => setDirty(false)}>
            Discard
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => setDirty(false)}>
            <Save size={13} />
            Save draft
          </Button>
        </div>
      )}

      {config.publishReview && (
        <PublishReview
          open={publishOpen}
          onOpenChange={setPublishOpen}
          itemName={config.workflowName}
          versions={config.publishReview.versions}
          diff={config.publishReview.diff}
          impactItems={config.publishReview.impactItems}
          {...(config.publishReview.disablePublishReason !== undefined && {
            disablePublishReason: config.publishReview.disablePublishReason,
          })}
          onPublish={() => setPublishOpen(false)}
        />
      )}
    </div>
  );
}
