# @dbp/organisms/workflow-builder

**registryId:** `APP.F40`

Visual node-graph workflow definition editor: draggable canvas (pan/zoom/drag), kind-adaptive
node properties, validation list, minimap, step-through test mode. Composes
[publish-review](../publish-review/README.md) (APP.F39) for the Publish action.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`WorkflowBuilderConfig` — Zod schema exported from `types.ts` (source of truth). See
`FEATURE.md` for why only 6 of the 14 `WorkflowNodeKind` values are backed by the real
`PS.WORKFLOW` engine today.

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/workflows/[id]` to this organism. Generator wiring is a follow-up (lift-and-shift scope).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/workflow-builder` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
