import { z } from "zod";

/** The 6 node kinds that map onto today's real PS.WORKFLOW engine (start/end/task/approval/subprocess step types). */
export const ENGINE_BACKED_KINDS = ["start", "end", "user", "system", "approval", "notify"] as const;

export const WorkflowNodeKind = z.enum([
  // Engine-backed today (6):
  "start",
  "end",
  "user",
  "system",
  "approval",
  "notify",
  // Palette-only -- no engine equivalent today (8), see FEATURE.md:
  "decision",
  "split",
  "merge",
  "review",
  "integration",
  "delay",
  "wait",
  "escalation",
]);
export type WorkflowNodeKind = z.infer<typeof WorkflowNodeKind>;

export const WorkflowNode = z.object({
  id: z.string().min(1),
  kind: WorkflowNodeKind,
  /** Human label for the node's type, e.g. "Approval". */
  type: z.string().min(1),
  title: z.string().min(1),
  x: z.number(),
  y: z.number(),
  assignee: z.string().optional(),
  error: z.boolean().optional(),
  warn: z.boolean().optional(),
});
export type WorkflowNode = z.infer<typeof WorkflowNode>;
export type WorkflowNodeInput = z.input<typeof WorkflowNode>;

export const WorkflowEdge = z.object({
  from: z.string().min(1),
  to: z.string().min(1),
  kind: z.enum(["success", "failure", "default"]).default("default"),
  label: z.string().optional(),
});
export type WorkflowEdge = z.infer<typeof WorkflowEdge>;

const PaletteNode = z.object({
  kind: WorkflowNodeKind,
  type: z.string().min(1),
  icon: z.string().optional(),
  color: z.string().min(1),
});

const PaletteGroup = z.object({
  group: z.string().min(1),
  nodes: z.array(PaletteNode).min(1),
});

const ValidationItem = z.object({
  level: z.enum(["error", "warning"]),
  node: z.string().min(1),
  nodeId: z.string().min(1),
  msg: z.string().min(1),
});

const AiSuggestion = z.object({
  title: z.string().min(1),
  reason: z.string().min(1),
  impact: z.string().min(1),
  records: z.string().min(1),
  confidence: z.enum(["high", "medium", "low", "insufficient"]).optional(),
  permission: z.string().min(1),
});

const PublishReviewData = z.object({
  versions: z.array(z.object({ value: z.string().min(1), author: z.string().min(1) })).min(1),
  diff: z.array(z.object({ type: z.enum(["context", "add", "remove"]), text: z.string().min(1) })),
  impactItems: z.array(
    z.object({
      type: z.string().min(1),
      count: z.number().int().nonnegative(),
      items: z.array(z.string()),
      to: z.string().optional(),
    })
  ),
  disablePublishReason: z.string().optional(),
});

export const WorkflowBuilderConfig = z.object({
  workflowName: z.string().min(1),
  statusLabel: z.string().default("Draft"),
  env: z.string().default("dev"),
  nodes: z.array(WorkflowNode).min(1),
  edges: z.array(WorkflowEdge),
  /** Fill color per node kind, e.g. { approval: "amber" }, as a caller-supplied CSS color value. Falls back to a neutral gray for unlisted kinds. */
  nodeColors: z.record(z.string()),
  palette: z.array(PaletteGroup).min(1),
  /** Node ids visited in order during test-mode stepping (matches the reference's fixed demo path -- only the 6 engine-backed kinds are ever exercised). */
  testNodeOrder: z.array(z.string()).default([]),
  validation: z.array(ValidationItem).default([]),
  suggestion: AiSuggestion.optional(),
  /** Data for the composed PublishReview drawer (APP.F39). Omit to hide the Publish action's review step (Publish becomes a no-op affordance). */
  publishReview: PublishReviewData.optional(),
});

export type WorkflowBuilderConfig = z.infer<typeof WorkflowBuilderConfig>;
export type WorkflowBuilderConfigInput = z.input<typeof WorkflowBuilderConfig>;
