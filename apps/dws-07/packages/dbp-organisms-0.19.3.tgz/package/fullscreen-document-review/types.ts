import { z } from "zod";

export const FullscreenDocumentReviewConfig = z.object({
  eyebrow: z.string().optional(),
  fileName: z.string().min(1),
  /** e.g. "MSA_v3.pdf · 284 KB" */
  fileMeta: z.string().optional(),
  /** e.g. "Ava Okafor · 2h ago" */
  uploadedBy: z.string().optional(),
  pageCount: z.number().int().positive().optional(),
  /** Small uppercase kicker inside the document card, e.g. "Master Services Agreement". */
  documentKicker: z.string().optional(),
  /** Document heading inside the card, e.g. "Meridian Foods — Amendment 3". */
  documentTitle: z.string().min(1),
  /** AI-generated summary shown in the side rail. */
  aiSummary: z.string().optional(),
  approveLabel: z.string().default("Approve document"),
});

export type FullscreenDocumentReviewConfig = z.infer<typeof FullscreenDocumentReviewConfig>;
export type FullscreenDocumentReviewConfigInput = z.input<typeof FullscreenDocumentReviewConfig>;
