import React from "react";
import { ChevronLeft, Download, Share2, Eye, Check } from "lucide-react";
import {
  Alert,
  Button,
  AiSurface,
  FullScreenModal,
  FullScreenModalContent,
  FullScreenModalBar,
  FullScreenModalTitle,
  FullScreenModalDescription,
  FullScreenModalBody,
  FullScreenModalMain,
  FullScreenModalRail,
  FullScreenModalFooter,
} from "@dbp/ui";
import { FullscreenDocumentReviewConfig, type FullscreenDocumentReviewConfigInput } from "./types.js";

export interface FullscreenDocumentReviewProps extends FullscreenDocumentReviewConfigInput {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApprove?: () => void;
}

const SKELETON_ROWS = [95, 88, 92, 70, 100, 96, 90, 98, 84, 92, 88];

/**
 * APP.F63 — Fullscreen Document Review
 *
 * Read-only document review surface — port of `overlay-fullscreen.jsx`'s
 * `FullScreenSurface` (`mode === 'doc'`). Composition on top of the existing
 * `FullScreenModal` primitive (`fullscreen-modal.tsx`, already built and
 * unconsumed) — no new fullscreen shell.
 */
export default function FullscreenDocumentReview(props: FullscreenDocumentReviewProps) {
  const { open, onOpenChange, onApprove, ...config } = props;
  const parsed = FullscreenDocumentReviewConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <FullScreenModal open={open} onOpenChange={onOpenChange}>
        <FullScreenModalContent hideClose>
          <Alert tone="danger" title="FullscreenDocumentReview — invalid config" data-testid="config-error">
            <ul className="mt-1 list-disc pl-5">
              {parsed.error.issues.map((issue, i) => (
                <li key={i}>
                  {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
                  {issue.message}
                </li>
              ))}
            </ul>
          </Alert>
        </FullScreenModalContent>
      </FullScreenModal>
    );
  }

  const c = parsed.data;

  return (
    <FullScreenModal open={open} onOpenChange={onOpenChange}>
      <FullScreenModalContent hideClose data-testid="fullscreen-document-review">
        <FullScreenModalBar>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => onOpenChange(false)}
            aria-label="Back"
            className="h-8 w-8 rounded-[var(--radius-button)] text-[var(--color-text-muted)] hover:text-primary"
          >
            <ChevronLeft size={18} aria-hidden="true" />
          </Button>
          <div className="min-w-0">
            {c.eyebrow && <FullScreenModalDescription>{c.eyebrow}</FullScreenModalDescription>}
            <FullScreenModalTitle>{c.fileName}</FullScreenModalTitle>
          </div>
          <div className="flex flex-1 justify-end gap-1">
            <Button type="button" variant="ghost" size="icon" title="Download" aria-label="Download">
              <Download size={15} aria-hidden="true" />
            </Button>
            <Button type="button" variant="ghost" size="icon" title="Share" aria-label="Share">
              <Share2 size={15} aria-hidden="true" />
            </Button>
          </div>
        </FullScreenModalBar>

        <FullScreenModalBody>
          <FullScreenModalMain>
            <div className="flex justify-center p-8">
              <div className="w-full max-w-[620px] rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] p-10 shadow-[var(--shadow-md)]">
                {c.documentKicker && (
                  <div className="mb-5 text-xs font-semibold uppercase tracking-[0.1em] text-[var(--color-text-muted)]">
                    {c.documentKicker}
                  </div>
                )}
                <div className="mb-4 text-lg font-semibold">{c.documentTitle}</div>
                <div className="flex flex-col gap-2.5" aria-hidden="true">
                  {SKELETON_ROWS.map((w, i) => (
                    <div
                      key={i}
                      className="h-2 rounded-full bg-[var(--color-surface)] opacity-60"
                      style={{ width: `${w}%` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </FullScreenModalMain>
          <FullScreenModalRail>
            <div className="mb-3 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
              Document info
            </div>
            <dl className="flex flex-col divide-y divide-[var(--color-border-subtle)] text-sm">
              {c.fileMeta && (
                <div className="flex gap-3 py-2">
                  <dt className="w-24 shrink-0 text-[var(--color-text-muted)]">File</dt>
                  <dd className="font-medium">{c.fileMeta}</dd>
                </div>
              )}
              {c.uploadedBy && (
                <div className="flex gap-3 py-2">
                  <dt className="w-24 shrink-0 text-[var(--color-text-muted)]">Uploaded</dt>
                  <dd className="font-medium">{c.uploadedBy}</dd>
                </div>
              )}
              {c.pageCount !== undefined && (
                <div className="flex gap-3 py-2">
                  <dt className="w-24 shrink-0 text-[var(--color-text-muted)]">Pages</dt>
                  <dd className="font-medium">{c.pageCount}</dd>
                </div>
              )}
            </dl>
            {c.aiSummary && (
              <div className="mt-4">
                <AiSurface label="generated" labelText="AI summary" low>
                  <p className="text-xs leading-relaxed">{c.aiSummary}</p>
                </AiSurface>
              </div>
            )}
          </FullScreenModalRail>
        </FullScreenModalBody>

        <FullScreenModalFooter>
          <span className="inline-flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
            <Eye size={13} aria-hidden="true" />
            Read-only preview
          </span>
          <div className="flex-1" />
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button type="button" onClick={onApprove}>
            <Check size={14} aria-hidden="true" />
            {c.approveLabel}
          </Button>
        </FullScreenModalFooter>
      </FullScreenModalContent>
    </FullScreenModal>
  );
}
