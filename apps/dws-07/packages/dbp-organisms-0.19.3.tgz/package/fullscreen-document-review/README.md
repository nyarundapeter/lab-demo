# @dbp/organisms/fullscreen-document-review

**registryId:** `APP.F63`

Read-only full-viewport document review — document card + AI-summary/metadata rail + a
read-only-preview footer note with an approve action. See `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`FullscreenDocumentReviewConfig` — Zod schema exported from `types.ts` (source of truth).
Component props also take `open`/`onOpenChange` (controlled) and an optional `onApprove`
callback (not part of the Zod config).

## Consumed by
Not yet wired — no caller mounts this organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/fullscreen-document-review` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
