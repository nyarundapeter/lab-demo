import { z } from "zod";
import { EntityDetailConfig } from "../entity-detail/types.js";

const ConfigKind = z.enum(["rule", "workflow", "config"]);

const KeyValueRow = z.object({
  label: z.string().min(1),
  value: z.string().min(1),
});

const DependencyNodeDef = z.object({
  label: z.string().min(1),
  sub: z.string().optional(),
  to: z.string().optional(),
});

const DependenciesConfig = z.object({
  upstream: z.array(DependencyNodeDef),
  current: DependencyNodeDef,
  downstream: z.array(DependencyNodeDef),
});

const VersionStatus = z.enum(["published", "deprecated", "archived", "draft"]);

const VersionRecordDef = z.object({
  version: z.string().min(1),
  status: VersionStatus,
  author: z.string().min(1),
  changedAt: z.string().min(1),
  summary: z.string().min(1),
  reviewer: z.string().min(1),
  current: z.boolean().optional(),
});

export const ConfigDetailConfig = EntityDetailConfig.omit({
  extraTabs: true,
  detailsLabel: true,
}).extend({
  /** What kind of config-governance object this is. Drives tab copy only, not behavior. */
  kind: ConfigKind.default("config"),
  /**
   * Configuration tab content (rule condition summary / workflow step
   * summary / etc.) as label/value rows. Tab omitted when not provided.
   */
  configuration: z.array(KeyValueRow).optional(),
  /** Dependencies tab — rendered via the shared DependencyView molecule. Tab omitted when not provided. */
  dependencies: DependenciesConfig.optional(),
  /** Usage tab content as label/value rows. Tab omitted when not provided. */
  usage: z.array(KeyValueRow).optional(),
  /** Versions tab — rendered via the shared VersionHistory molecule. Tab omitted when not provided. */
  versions: z.array(VersionRecordDef).optional(),
  /** Test history tab content as label/value rows. Tab omitted when not provided. */
  testHistory: z.array(KeyValueRow).optional(),
  /** Audit tab — reuses the existing self-fetching AdminAuditLog (APP.F-scoped, not record-scoped yet). @default true */
  showAudit: z.boolean().default(true),
});

export type ConfigDetailConfig = z.infer<typeof ConfigDetailConfig>;
export type ConfigDetailConfigInput = z.input<typeof ConfigDetailConfig>;
export type ConfigKind = z.infer<typeof ConfigKind>;
export type DependencyNodeInput = z.infer<typeof DependencyNodeDef>;
export type VersionRecordInput = z.infer<typeof VersionRecordDef>;
export type KeyValueRow = z.infer<typeof KeyValueRow>;
