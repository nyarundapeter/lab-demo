# @dbp/organisms/config-detail

**registryId:** `APP.F37`

Config-governance detail panel (rule/workflow/schema pages): Overview + Activity plus up to
five optional tabs (Configuration, Dependencies, Usage, Versions, Test history, Audit).
Extends [entity-detail](../entity-detail/README.md) (APP.F02) via its `extraTabs` extension
point rather than forking it.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ConfigDetailConfig` — Zod schema exported from `types.ts` (source of truth). Extends
`EntityDetailConfig` (from `../entity-detail/types.ts`) minus `extraTabs`/`detailsLabel`
(owned internally), plus `kind`/`configuration`/`dependencies`/`usage`/`versions`/
`testHistory`/`showAudit`.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the
`FEATURE_COMPONENT` map at JSX emission time and mounts it into the `object-page-detail`
layout, same as `entity-detail`.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/config-detail` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
