import React from "react";
import { Alert, InfoCard, DependencyView, VersionHistory, AdminAuditLog } from "@dbp/ui";
import EntityDetail from "../entity-detail/index.js";
import type { ExtraTab } from "../entity-detail/types.js";
import { ConfigDetailConfig, type ConfigDetailConfigInput } from "./types.js";

const KIND_LABEL: Record<string, string> = {
  rule: "Rule",
  workflow: "Workflow",
  config: "Configuration",
};

/**
 * Dependency-node navigation dispatches the same `dbp:entity-detail:action`
 * CustomEvent convention `entity-detail`'s rail actions use — solutions wire
 * behaviour off the event, this component owns no routing.
 */
function dispatchNavigate(entityType: string, entityId: string, to: string) {
  document.dispatchEvent(
    new CustomEvent("dbp:entity-detail:action", {
      bubbles: true,
      detail: { id: `dependency:${to}`, entityType, entityId, to },
    })
  );
}

/**
 * APP.F02's config-governance variant — rule/workflow/schema detail pages
 * needing Configuration/Dependencies/Usage/Versions/Test history/Audit tabs
 * beyond entity-detail's base Details/Activity pair. Composes `EntityDetail`
 * via its `extraTabs`/`extraTabsContent` extension point rather than
 * forking it, per `wave3-family2-tier-audit.md`'s reuse recommendation.
 *
 * Each optional data block (`configuration`/`dependencies`/`usage`/
 * `versions`/`testHistory`) independently controls whether its tab renders
 * at all — a rule detail page and a workflow detail page can show a
 * different tab subset from the same component.
 */
export default function ConfigDetail(config: ConfigDetailConfigInput) {
  const parsed = ConfigDetailConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="ConfigDetail — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const {
    entityType,
    entityId,
    sections,
    showActivity,
    header,
    actions,
    meta,
    kind,
    configuration,
    dependencies,
    usage,
    versions,
    testHistory,
    showAudit,
  } = parsed.data;

  const extraTabs: ExtraTab[] = [];
  const extraTabsContent: Record<string, React.ReactNode> = {};

  if (configuration) {
    extraTabs.push({ id: "configuration", label: "Configuration" });
    extraTabsContent.configuration = (
      <InfoCard title={`${KIND_LABEL[kind] ?? "Configuration"} summary`} rows={configuration} />
    );
  }

  if (dependencies) {
    extraTabs.push({ id: "dependencies", label: "Dependencies" });
    extraTabsContent.dependencies = (
      <DependencyView
        upstream={dependencies.upstream}
        current={dependencies.current}
        downstream={dependencies.downstream}
        onNavigate={(to) => dispatchNavigate(entityType, entityId, to)}
      />
    );
  }

  if (usage) {
    extraTabs.push({ id: "usage", label: "Usage" });
    extraTabsContent.usage = <InfoCard title="Usage" rows={usage} />;
  }

  if (versions) {
    extraTabs.push({ id: "versions", label: "Versions" });
    extraTabsContent.versions = <VersionHistory versions={versions} />;
  }

  if (testHistory) {
    extraTabs.push({ id: "test-history", label: "Test history" });
    extraTabsContent["test-history"] = <InfoCard title="Test history" rows={testHistory} />;
  }

  if (showAudit) {
    extraTabs.push({ id: "audit", label: "Audit" });
    extraTabsContent.audit = <AdminAuditLog />;
  }

  return (
    <EntityDetail
      entityType={entityType}
      entityId={entityId}
      sections={sections}
      showActivity={showActivity}
      header={header}
      actions={actions}
      meta={meta}
      detailsLabel="Overview"
      extraTabs={extraTabs}
      extraTabsContent={extraTabsContent}
    />
  );
}
