import * as React from "react";
import { useNotifications } from "@dbp/ps-notif/client";
import {
  Alert,
  Badge,
  SegmentedControl,
  cn,
  relativeTimeCompact,
  Button,
  TypeTag,
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  FullScreenModal,
  FullScreenModalContent,
  FullScreenModalBar,
  FullScreenModalTitle,
  FullScreenModalDescription,
  FullScreenModalBody,
  FullScreenModalMain,
  FullScreenModalRail,
  FullScreenModalFooter,
  CriticalCard,
  SectionLabel,
} from "@dbp/ui";
import { NotificationInboxConfig } from "./types.js";
import type { NotificationInboxConfig as NotificationInboxConfigType } from "./types.js";

// ─── Public re-exports ────────────────────────────────────────────────────
export type { NotificationInboxConfig } from "./types.js";

/**
 * APP.F29 (provisional — see PENDING note in
 * scripts/scaffold-solution.mjs FEATURE_COMPONENT) — Notification Inbox
 *
 * The "lighter pattern" thin list surface ruled in place of an LVE preset
 * (ruling N3, decision pack 2026-07-17). See
 * docs/09-plans/notification-inbox-pattern-2026-07-17.md for the research
 * and rationale.
 *
 * Reads from PS.NOTIF's existing `useNotifications` hook — no new endpoints.
 * Filter chips are a control (SegmentedControl), not a data operation. No
 * search, no bulk select, no archive, no drawer — those were explicitly
 * rejected as "too much" for this surface.
 */
export default function NotificationInbox({
  config,
}: {
  config: NotificationInboxConfigType;
}) {
  const parseResult = NotificationInboxConfig.safeParse(config);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="NotificationInbox configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <NotificationInboxInner config={parseResult.data} />;
}

// ─── Type → severity badge tone (§ notification-taxonomy.ts, @dbp/contracts) ──

type BadgeTone = "info" | "success" | "warning" | "danger" | "critical" | "gray";

const TYPE_TONE: Record<string, BadgeTone> = {
  info: "info",
  success: "success",
  warning: "warning",
  error: "danger",
  critical: "critical",
  action: "warning",
  reminder: "info",
  system: "gray",
};

function toneOf(type: string): BadgeTone {
  return TYPE_TONE[type] ?? "gray";
}

// Structurally identical to @dbp/contracts' NotificationType (8-type taxonomy) —
// PS.NOTIF's `type` field is still an unconstrained string, so unknown values
// fall back to "info" for the typed TypeTag chip.
type KnownNotifType = "info" | "success" | "warning" | "error" | "critical" | "action" | "reminder" | "system";
const KNOWN_TYPES = new Set<string>(["info", "success", "warning", "error", "critical", "action", "reminder", "system"]);
function asTaxonomyType(type: string): KnownNotifType {
  return (KNOWN_TYPES.has(type) ? type : "info") as KnownNotifType;
}

// ─── Filter chips — a small, fixed set, never a filter builder ─────────────

type FilterValue = "all" | "unread" | "action" | "system";

const FILTERS: { value: FilterValue; label: string }[] = [
  { value: "all", label: "All" },
  { value: "unread", label: "Unread" },
  { value: "action", label: "Action required" },
  { value: "system", label: "System" },
];

const SNOOZE_1H_MS = 60 * 60 * 1000;

function NotificationInboxInner({ config }: { config: NotificationInboxConfigType }) {
  const { items, unread, markRead, markAllRead, archive, snooze, acknowledge, markFalsePositive, isLoading } =
    useNotifications(config.sessionHeader);
  const [filter, setFilter] = React.useState<FilterValue>("all");
  // Full-screen review (OVL-11) — items with no external link open a
  // doc-review-style full-screen surface instead of doing nothing on click.
  const [reviewId, setReviewId] = React.useState<string | null>(null);
  // Bottom-sheet quick actions (OVL-14) — touch-friendly compact detent,
  // reachable from every row via the "More actions" affordance.
  const [quickActionsId, setQuickActionsId] = React.useState<string | null>(null);
  const reviewItem = items.find((n) => n.id === reviewId) ?? null;
  const quickActionsItem = items.find((n) => n.id === quickActionsId) ?? null;

  // Archived / still-snoozed items leave the active inbox (NOT-10).
  const now = Date.now();
  const active = items.filter((n) => {
    if (n.status === "archived") return false;
    if (n.snoozedUntil && new Date(n.snoozedUntil).getTime() > now) return false;
    return true;
  });

  const shown = active.filter((n) => {
    if (filter === "unread") return n.status === "unread";
    if (filter === "action") return n.type === "action";
    if (filter === "system") return n.type === "system";
    return true;
  });

  return (
    <div className="flex flex-col gap-4" data-testid="notification-inbox">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <SegmentedControl
          name="notification-filter"
          value={filter}
          onChange={(v) => setFilter(v as FilterValue)}
          options={FILTERS.map((f) => ({
            ...f,
            ...(f.value === "unread" ? { count: unread } : {}),
          }))}
        />
        {unread > 0 && (
          <Button
            variant="link"
            onClick={markAllRead}
            className="text-sm"
            data-testid="mark-all-read"
          >
            Mark all read
          </Button>
        )}
      </div>

      <div className="rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)]">
        {isLoading && (
          <div className="px-4 py-8 text-center text-sm text-[var(--color-text-muted)]">
            Loading…
          </div>
        )}

        {!isLoading && shown.length === 0 && (
          <div
            className="px-4 py-8 text-center text-sm text-[var(--color-text-muted)]"
            data-testid="empty-state"
          >
            {config.emptyMessage ?? "No notifications."}
          </div>
        )}

        {shown.map((n, i) => (
          <div
            key={n.id}
            className={cn(i > 0 && "border-t border-[var(--color-border)]", n.type === "critical" && "p-3")}
          >
            {n.type === "critical" ? (
              // CriticalCard (NOT-14) — the reference's highest-severity surface,
              // wired here for real product consumption for the first time.
              // onAck/onMarkFalsePositive persist via the W5b PS.NOTIF verbs;
              // the 4-step incident stepper is a separate, unpersisted axis.
              <CriticalCard
                record={n.type}
                title={n.message}
                message={n.message}
                fields={[
                  { label: "Received", value: relativeTimeCompact(n.ts) },
                  { label: "Status", value: n.status },
                ]}
                onAck={() => acknowledge(n.id)}
                onMarkFalsePositive={() => markFalsePositive(n.id)}
              />
            ) : (
              <div
                role={n.link ? "link" : "button"}
                tabIndex={0}
                onClick={() => {
                  markRead(n.id);
                  if (n.link) window.location.assign(n.link);
                  else setReviewId(n.id);
                }}
                className={cn(
                  "group flex cursor-pointer items-start gap-3 px-4 py-3",
                  n.status === "unread" &&
                    "bg-[color-mix(in_srgb,var(--color-primary)_5%,transparent)]",
                )}
                data-testid={`notification-row-${n.id}`}
                aria-label={`${n.status === "unread" ? "Unread: " : ""}${n.message}`}
              >
                <Badge tone={toneOf(n.type)} size="sm" className="mt-0.5 shrink-0">
                  {n.type}
                </Badge>
                <div className="min-w-0 flex-1">
                  <p
                    className={cn(
                      "text-sm leading-snug",
                      n.status === "unread"
                        ? "font-medium text-[var(--color-text)]"
                        : "text-[var(--color-text)] opacity-70",
                    )}
                  >
                    {n.message}
                  </p>
                  <p className="mt-0.5 text-xs text-[var(--color-text-muted)]">
                    {relativeTimeCompact(n.ts)}
                  </p>
                </div>
                {/* Hover actions (NOT-10) — archive/snooze, visible on hover/focus. */}
                <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100 group-focus-within:opacity-100">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      archive(n.id);
                    }}
                    className="h-auto rounded px-1.5 py-1 text-xs font-medium text-[var(--color-text-muted)] hover:bg-[var(--color-border)]/40 hover:text-[var(--color-text)]"
                    aria-label={`Archive: ${n.message}`}
                    data-testid={`notification-archive-${n.id}`}
                  >
                    Archive
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      snooze(n.id, new Date(Date.now() + SNOOZE_1H_MS).toISOString());
                    }}
                    className="h-auto rounded px-1.5 py-1 text-xs font-medium text-[var(--color-text-muted)] hover:bg-[var(--color-border)]/40 hover:text-[var(--color-text)]"
                    aria-label={`Snooze 1 hour: ${n.message}`}
                    data-testid={`notification-snooze-${n.id}`}
                  >
                    Snooze
                  </Button>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation();
                    setQuickActionsId(n.id);
                  }}
                  className="h-auto w-auto shrink-0 rounded p-1 text-[var(--color-text-muted)] hover:bg-[var(--color-border)]/40 hover:text-[var(--color-text)]"
                  aria-label={`More actions for: ${n.message}`}
                  data-testid={`notification-actions-${n.id}`}
                >
                  <span aria-hidden className="text-sm font-bold leading-none tracking-widest">{"⋮"}</span>
                </Button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Full-screen review (OVL-11) — link-less notifications open here instead of no-op. */}
      <FullScreenModal open={reviewItem != null} onOpenChange={(open) => !open && setReviewId(null)}>
        {reviewItem && (
          <FullScreenModalContent>
            <FullScreenModalBar>
              <div className="min-w-0 flex-1">
                <FullScreenModalDescription>Notification review</FullScreenModalDescription>
                <FullScreenModalTitle>{reviewItem.message}</FullScreenModalTitle>
              </div>
            </FullScreenModalBar>
            <FullScreenModalBody>
              <FullScreenModalMain className="p-6">
                <p className="text-sm leading-relaxed text-[var(--color-text)]">{reviewItem.message}</p>
              </FullScreenModalMain>
              <FullScreenModalRail>
                <div className="flex flex-col gap-3">
                  <TypeTag type={asTaxonomyType(reviewItem.type)} />
                  <div>
                    <SectionLabel as="div" className="text-xs mb-0.5">
                      Received
                    </SectionLabel>
                    <div className="text-xs font-medium">{relativeTimeCompact(reviewItem.ts)}</div>
                  </div>
                  <div>
                    <SectionLabel as="div" className="text-xs mb-0.5">
                      Status
                    </SectionLabel>
                    <div className="text-xs font-medium capitalize">{reviewItem.status}</div>
                  </div>
                </div>
              </FullScreenModalRail>
            </FullScreenModalBody>
            <FullScreenModalFooter>
              <div className="ml-auto flex gap-2">
                <Button variant="ghost" size="sm" onClick={() => setReviewId(null)}>
                  Close
                </Button>
              </div>
            </FullScreenModalFooter>
          </FullScreenModalContent>
        )}
      </FullScreenModal>

      {/* Bottom-sheet quick actions (OVL-14) — compact detent, touch-friendly. */}
      <Sheet open={quickActionsItem != null} onOpenChange={(open) => !open && setQuickActionsId(null)}>
        {quickActionsItem && (
          <SheetContent side="bottom" detent="compact" showGrip>
            <SheetHeader>
              <SheetTitle className="text-sm">Quick actions</SheetTitle>
            </SheetHeader>
            <div className="flex flex-col gap-1 pt-2">
              <Button
                variant="ghost"
                className="justify-start"
                onClick={() => {
                  markRead(quickActionsItem.id);
                  setQuickActionsId(null);
                }}
              >
                Mark as read
              </Button>
              {quickActionsItem.link && (
                <Button
                  variant="ghost"
                  className="justify-start"
                  onClick={() => {
                    markRead(quickActionsItem.id);
                    window.location.assign(quickActionsItem.link!);
                  }}
                >
                  Open link
                </Button>
              )}
              <Button
                variant="ghost"
                className="justify-start"
                onClick={() => {
                  snooze(quickActionsItem.id, new Date(Date.now() + SNOOZE_1H_MS).toISOString());
                  setQuickActionsId(null);
                }}
              >
                Snooze 1 hour
              </Button>
              <Button
                variant="ghost"
                className="justify-start"
                onClick={() => {
                  archive(quickActionsItem.id);
                  setQuickActionsId(null);
                }}
              >
                Archive
              </Button>
            </div>
          </SheetContent>
        )}
      </Sheet>
    </div>
  );
}
