# @dbp/organisms/notification-inbox

**registryId:** `APP.F29` (provisional — pending catalogue-owner confirmation,
see [FEATURE.md](./FEATURE.md))

Thin, dedicated list surface for a user's personal PS.NOTIF notifications —
filter chips (All / Unread / Action required / System), severity-badged rows,
"Mark all read". Built as the "lighter pattern" in place of an LVE preset
(ruling N3, decision pack 2026-07-17). See [FEATURE.md](./FEATURE.md) for the
full contract and [CHANGELOG.md](./CHANGELOG.md) for release history.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`NotificationInboxConfig` — Zod schema (and inferred type of the same name)
exported from `types.ts` (source of truth).

## Layer boundary
Layer 07 feature. Imports only `@dbp/ps-notif/client` (never `/server`) and
`@dbp/ui`; reads via the existing `useNotifications` hook — no new PS.NOTIF
endpoints.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/notification-inbox` via
plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it
as a committed tarball per `docs/08-contributing/package-distribution.md`.
