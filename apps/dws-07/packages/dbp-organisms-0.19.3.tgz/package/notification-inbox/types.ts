import { z } from "zod";

// ─── NotificationInboxConfig ───────────────────────────────────────────────
// Data-only contract — no function fields. Body-only (single-header rule):
// the page title is owned by the shell PageHeader, not this feature.

export const NotificationInboxConfig = z
  .object({
    /** Session header forwarded to PS.NOTIF (matches NotificationBell's prop). */
    sessionHeader: z.string().optional(),

    /** Text shown when there are no notifications. */
    emptyMessage: z.string().optional(),
  })
  .strict();

export type NotificationInboxConfig = z.infer<typeof NotificationInboxConfig>;
