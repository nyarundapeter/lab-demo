import * as React from "react";
import { z } from "zod";
import { Alert, DashSection, AiExecSummary, DashboardDensityProvider } from "@dbp/ui";
import { ExecutiveDashboardData } from "./types.js";
import { HeroBand } from "./components/hero-band.js";
import { KpiCard } from "./components/kpi-card.js";
import { TrendChart } from "./components/trend-chart.js";
import { SegmentDonut } from "./components/segment-donut.js";
import { DecisionsRequired } from "./components/decisions-required.js";
import { PortfolioTable } from "./components/portfolio-table.js";

type DataInput = z.input<typeof ExecutiveDashboardData>;

const money = (v: number) => `£${v}M`;

/**
 * ANL.F10 — Executive Dashboard
 *
 * Verbatim port of the design-run-pack reference's `ExecutiveDashboard`
 * composition (dash-views-1.jsx:19-112): hero band → performance summary →
 * trends & outlook → AI executive brief + decisions required → portfolio
 * health. See docs/09-plans/design-ingestion-resolution-2026-07-17/
 * dashboard-verbatim-port-contract.md for the anatomy/method this follows.
 *
 * Receives DATA (not PS.DATA config) — see types.ts doc comment for why this
 * differs from KpiScorecard/ChartPanel's per-tile config contract.
 */
export default function ExecutiveDashboard(rawData: DataInput) {
  const parsed = ExecutiveDashboardData.safeParse(rawData);
  if (!parsed.success) {
    return (
      <Alert tone="danger" title="ExecutiveDashboard data error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parsed.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }
  const d = parsed.data;

  return (
    <DashboardDensityProvider density="executive" className="dash">
      <div className="dash-canvas">
        <HeroBand
          status={d.headline.status}
          period={d.headline.period}
          outcome={d.headline.outcome}
          revenueToTargetPct={d.headline.revenueToTargetPct}
          revenueToTargetDelta={d.headline.revenueToTargetDelta}
          forecast={d.headline.forecast}
          forecastDelta={d.headline.forecastDelta}
        />

        <DashSection title="Performance summary">
          <div className="dgrid">
            {d.kpis.map((kpi) => (
              <div className="c3" key={kpi.id}>
                <KpiCard {...kpi} />
              </div>
            ))}
          </div>
        </DashSection>

        <DashSection title="Trends & outlook">
          <div className="dgrid">
            <div className="c8">
              <div className="widget">
                <div className="widget-head bordered">
                  <div className="min-w-0">
                    <h3 className="widget-title">Revenue vs target</h3>
                    <p className="widget-desc">Monthly, £M</p>
                  </div>
                </div>
                <div className="widget-body">
                  <TrendChart series={d.revenue.series} labels={d.months} target={d.revenue.target} yFormat={money} />
                </div>
              </div>
            </div>
            <div className="c4">
              <div className="widget">
                <div className="widget-head bordered">
                  <div className="min-w-0">
                    <h3 className="widget-title">Revenue by segment</h3>
                    <p className="widget-desc">Share of ARR</p>
                  </div>
                </div>
                <div className="widget-body flex items-center justify-center">
                  <SegmentDonut data={d.segments} centerValue={d.segmentsCenterValue} centerLabel={d.segmentsCenterLabel} />
                </div>
              </div>
            </div>
          </div>
        </DashSection>

        <DashSection title="AI executive brief" sub="Grounded in the widgets above">
          <div className="dgrid">
            <div className="c8">
              <AiExecSummary period={d.aiBrief.period} points={d.aiBrief.points} outlook={d.aiBrief.outlook} />
            </div>
            <div className="c4">
              <div className="widget">
                <div className="widget-head bordered">
                  <div className="min-w-0">
                    <h3 className="widget-title">Decisions required</h3>
                    <p className="widget-desc">Awaiting the leadership team</p>
                  </div>
                </div>
                <div className="widget-body flush">
                  <DecisionsRequired items={d.decisions} />
                </div>
              </div>
            </div>
          </div>
        </DashSection>

        <DashSection title="Portfolio health" sub="Strategic initiatives">
          <div className="widget">
            <div className="widget-head bordered">
              <div className="min-w-0">
                <h3 className="widget-title">Initiative status</h3>
              </div>
            </div>
            <div className="widget-body flush">
              <PortfolioTable rows={d.portfolio} />
            </div>
          </div>
        </DashSection>
      </div>
    </DashboardDensityProvider>
  );
}

export type { ExecutiveDashboardData } from "./types.js";
