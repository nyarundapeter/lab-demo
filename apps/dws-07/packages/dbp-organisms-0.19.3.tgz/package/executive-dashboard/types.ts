import { z } from "zod";

/**
 * ExecutiveDashboardData — the data contract for ANL.F10 (verbatim port of
 * the design-run-pack reference's `ExecutiveDashboard` composition, see
 * docs/09-plans/design-ingestion-resolution-2026-07-17/dashboard-verbatim-port-contract.md).
 *
 * The component receives DATA, not config — unlike KpiScorecard/ChartPanel
 * (which fetch from PS.DATA per-tile), the reference composition is a single
 * fixed anatomy of widgets fed by one coherent business narrative, so the
 * caller (a solution page) assembles the figures once (demo fixture today,
 * a PS.DATA/PS.WORKFLOW aggregate later) and passes them down.
 */

export const KpiCardData = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  value: z.string().min(1),
  unit: z.string().optional(),
  delta: z.number().optional(),
  deltaPolarity: z.enum(["up-good", "down-good"]).optional(),
  comparison: z.string().optional(),
  target: z.string().optional(),
  targetPct: z.number().min(0).max(999).optional(),
  benchmark: z.string().optional(),
  status: z.enum(["good", "warn", "bad", "neutral", "info"]).optional(),
  spark: z.array(z.number()).optional(),
});
export type KpiCardData = z.infer<typeof KpiCardData>;

export const SegmentSlice = z.object({
  name: z.string().min(1),
  value: z.number(),
  color: z.string().min(1),
});
export type SegmentSlice = z.infer<typeof SegmentSlice>;

export const DecisionItem = z.object({
  id: z.string().min(1),
  severity: z.enum(["crit", "high", "med", "low"]),
  title: z.string().min(1),
  impact: z.string().optional(),
  owner: z.string().optional(),
  age: z.string().optional(),
});
export type DecisionItem = z.infer<typeof DecisionItem>;

export const InitiativeRow = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  owner: z.string().min(1),
  status: z.enum(["good", "warn", "bad"]),
  pct: z.number().min(0).max(100),
  invest: z.string().min(1),
  benefit: z.string().min(1),
  confidence: z.enum(["High", "Medium", "Low"]),
});
export type InitiativeRow = z.infer<typeof InitiativeRow>;

export const AiBriefPoint = z.object({
  text: z.string().min(1),
  tone: z.enum(["good", "warn", "bad"]),
  cite: z.string().min(1),
});
export type AiBriefPoint = z.infer<typeof AiBriefPoint>;

export const ExecutiveDashboardData = z.object({
  months: z.array(z.string()).min(2),
  headline: z.object({
    status: z.enum(["good", "warn", "bad"]),
    period: z.string().min(1),
    outcome: z.string().min(1),
    revenueToTargetPct: z.number(),
    revenueToTargetDelta: z.number(),
    forecast: z.string().min(1),
    forecastDelta: z.string().min(1),
  }),
  kpis: z.array(KpiCardData).min(1),
  revenue: z.object({
    series: z.array(z.number()).min(2),
    target: z.number(),
  }),
  segments: z.array(SegmentSlice).min(1),
  segmentsCenterValue: z.string().min(1),
  segmentsCenterLabel: z.string().min(1),
  aiBrief: z.object({
    period: z.string().min(1),
    points: z.array(AiBriefPoint).min(1),
    outlook: z.string().min(1),
  }),
  decisions: z.array(DecisionItem).min(1),
  portfolio: z.array(InitiativeRow).min(1),
});
export type ExecutiveDashboardData = z.infer<typeof ExecutiveDashboardData>;
