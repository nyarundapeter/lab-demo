# @dbp/organisms/executive-dashboard

ANL.F10 — verbatim port of the design-run-pack reference's `ExecutiveDashboard`.
See `FEATURE.md` for the contract and composition table.

```tsx
import ExecutiveDashboard from "@dbp/organisms/executive-dashboard";

<ExecutiveDashboard {...executiveDashboardDemoData} />
```
