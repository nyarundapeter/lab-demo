import * as React from "react";
import { CircleX, TriangleAlert, CircleAlert, Circle, User, Clock, ChevronRight } from "lucide-react";
import { Button } from "@dbp/ui";
import type { DecisionItem } from "../types.js";

const SEV: Record<DecisionItem["severity"], { cls: string; icon: React.ComponentType<{ size?: number }>; label: string }> = {
  crit: { cls: "sev-crit", icon: CircleX, label: "Critical" },
  high: { cls: "sev-high", icon: TriangleAlert, label: "High" },
  med: { cls: "sev-med", icon: CircleAlert, label: "Medium" },
  low: { cls: "sev-low", icon: Circle, label: "Low" },
};

/**
 * Decisions-required queue — verbatim port of `AlertCard`
 * (dash-components.jsx:134-155) as used in the "Decisions required" widget
 * (dash-views-1.jsx:86-90).
 *
 * DEVIATION FROM THE CONTRACT (flagged, not silent): the contract asked to
 * "reuse the approval-queue organism" here. `ApprovalQueue`
 * (packages/stack/app-scaffolds/features/approval-surface/components/approval-queue.tsx)
 * is hard-wired to PS.WORKFLOW — it requires a real `definitionId` and lists
 * live running instances, it does not accept static rows. Standing up a real
 * workflow definition for this demo composition is out of scope for a
 * fidelity-first verbatim port, so this renders the reference's own
 * `AlertCard` list directly against the lifted demo data (honestly labelled
 * as demo, not claimed as a live queue). Wiring this widget to a real
 * PS.WORKFLOW-backed `ApprovalQueue` is a Wave 2/3 follow-up.
 */
export function DecisionsRequired({ items }: { items: DecisionItem[] }) {
  return (
    <div>
      {items.map((it) => {
        const s = SEV[it.severity];
        const Icon = s.icon;
        return (
          <div key={it.id} className="alertc">
            <span className={`alertc-icon ${s.cls}`}>
              <Icon size={15} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">{it.title}</span>
                <span className="chip-sm ml-auto shrink-0">{s.label}</span>
              </div>
              {it.impact && <div className="mt-0.5 text-xs text-[var(--color-text-muted)]">{it.impact}</div>}
              <div className="mt-1.5 flex items-center gap-2.5 text-xs text-[var(--color-text-muted)]">
                {it.owner && (
                  <span className="inline-flex items-center gap-1">
                    <User size={11} />
                    {it.owner}
                  </span>
                )}
                {it.age && (
                  <span className="inline-flex items-center gap-1">
                    <Clock size={11} />
                    {it.age}
                  </span>
                )}
                <div className="flex-1" />
                <Button variant="link" className="h-auto gap-0.5 p-0 text-xs text-[var(--color-secondary)]">
                  Review
                </Button>
              </div>
            </div>
          </div>
        );
      })}
      <div className="widget-foot">
        <Button variant="link" className="link-btn h-auto gap-1 p-0 text-xs text-[var(--color-secondary)]">
          View all decisions <ChevronRight size={12} />
        </Button>
      </div>
    </div>
  );
}
