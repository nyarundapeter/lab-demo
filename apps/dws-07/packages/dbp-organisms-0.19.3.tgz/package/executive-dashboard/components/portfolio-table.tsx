import * as React from "react";
import { Progress, StatusDot } from "@dbp/ui";
import type { InitiativeRow } from "../types.js";

/**
 * Initiative-status table — verbatim port of dash-views-1.jsx:97-107's
 * `DataTable` columns config, rendered against the `.dtable` classes ported
 * into dashboard.css (dash-components.jsx:217-230).
 */
export function PortfolioTable({ rows }: { rows: InitiativeRow[] }) {
  return (
    <div className="dtable-scroll">
      <table className="dtable">
        <thead>
          <tr>
            <th>Initiative</th>
            <th style={{ width: 140 }}>Progress</th>
            <th className="num">Invest</th>
            <th className="num">Benefit</th>
            <th>Confidence</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>
                <div className="font-medium">{r.name}</div>
                <div className="text-xs text-[var(--color-text-muted)]">
                  {r.id} · {r.owner}
                </div>
              </td>
              <td>
                <div style={{ width: 120 }}>
                  <Progress
                    value={r.pct}
                    showLabel
                    tone={r.status === "good" ? "success" : r.status === "warn" ? "warning" : "danger"}
                  />
                </div>
              </td>
              <td className="num">{r.invest}</td>
              <td className="num">{r.benefit}</td>
              <td>{r.confidence}</td>
              <td>
                <StatusDot status={r.status} pill />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
