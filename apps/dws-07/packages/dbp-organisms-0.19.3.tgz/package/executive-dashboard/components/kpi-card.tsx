import * as React from "react";
import { Sparkline, Delta, type DeltaPolarity } from "@dbp/ui";
import type { KpiCardData } from "../types.js";

const STATUS_ICON_COLOR: Record<string, string> = {
  good: "var(--color-success)",
  warn: "var(--color-warning)",
  bad: "var(--color-danger)",
};

/**
 * KPI card — verbatim port of dash-components.jsx:36-67 (`KpiCard`). Value +
 * inline sparkline + delta + target progress bar + benchmark line, styled
 * via the `.kpi`/`.kpi-*` classes ported into dashboard.css.
 *
 * Wave 1.F (`docs/plans/design-system-dedup-2026-07-25/strategy.md` §4 R5/R7)
 * ACCEPTED DIVERGENCE: NOT migrated onto the canonical `@dbp/ui` `StatTile`.
 * `StatTile` is a `Card`-shell/Tailwind-token component; this file is a
 * verbatim pixel-for-pixel port of the reference's own CSS classes
 * (`.kpi`/`.kpi-value`/`.kpi-bar`/`.kpi-foot`, `dashboard.css`), whose
 * acceptance criterion (`docs/09-plans/design-ingestion-resolution-2026-07-17/
 * dashboard-verbatim-port-contract.md`) is exact visual match to the design
 * reference screenshot at the ported density (`data-density="executive"` in
 * `dashboard.css`, driven by `DashboardDensityProvider` in
 * `executive-dashboard/index.tsx`). Rebuilding it on `Card`'s border/radius/
 * shadow/spacing would break that pixel match. Density here therefore comes
 * from the CSS-attribute mechanism (`.dash[data-density]`), not from
 * `StatTile`'s React-context density (which this component doesn't consume).
 */
export function KpiCard({
  label,
  value,
  unit,
  delta,
  deltaPolarity,
  comparison,
  target,
  targetPct,
  benchmark,
  status,
  spark,
}: KpiCardData) {
  const sparkColor =
    delta != null ? (delta >= 0 ? "var(--color-success)" : "var(--color-danger)") : "var(--color-secondary)";
  const barColor =
    targetPct != null
      ? targetPct >= 100
        ? "var(--color-success)"
        : targetPct >= 80
          ? "var(--color-secondary)"
          : "var(--color-warning)"
      : undefined;

  return (
    <div className="kpi">
      <div className="kpi-label">
        <span>{label}</span>
        {status && (
          <span
            className="ml-auto inline-block h-2 w-2 rounded-full"
            style={{ background: STATUS_ICON_COLOR[status] }}
            aria-hidden
          />
        )}
      </div>
      <div className="flex items-end justify-between gap-2">
        <div className="kpi-value">
          {value}
          {unit && <span className="ml-0.5 text-[0.5em] font-medium text-[var(--color-text-muted)]">{unit}</span>}
        </div>
        {spark && <Sparkline data={spark} color={sparkColor} showDot />}
      </div>
      {(delta != null || comparison) && (
        <div className="kpi-sub">
          {delta != null && <Delta value={delta} polarity={(deltaPolarity ?? "up-good") as DeltaPolarity} />}
          {comparison && <span className="kpi-foot">{comparison}</span>}
        </div>
      )}
      {/* DR-11 — bottom-anchored footer slot (target bar / benchmark line) so
          value/sparkline rows align across equal-height sibling cards even
          when only some cards carry a footer. */}
      {(targetPct != null || benchmark) && (
        <div className="mt-auto flex flex-col gap-1">
          {targetPct != null && (
            <>
              <div className="kpi-bar">
                <i style={{ width: `${Math.min(100, targetPct)}%`, background: barColor }} />
              </div>
              <div className="kpi-foot">
                {targetPct}% of target{target ? ` · ${target}` : ""}
              </div>
            </>
          )}
          {benchmark && <div className="kpi-foot">Benchmark: {benchmark}</div>}
        </div>
      )}
    </div>
  );
}
