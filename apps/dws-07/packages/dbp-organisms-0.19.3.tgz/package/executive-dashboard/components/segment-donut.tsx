import * as React from "react";
import type { SegmentSlice } from "../types.js";

export interface SegmentDonutProps {
  data: SegmentSlice[];
  centerValue: string;
  centerLabel: string;
  size?: number;
  thickness?: number;
}

/**
 * Revenue-by-segment donut — verbatim port of dash-charts.jsx:164-197
 * (`Donut`), plain inline `<svg>`/`<circle>` strokes, not a chart library.
 */
export function SegmentDonut({ data, centerValue, centerLabel, size = 130, thickness = 18 }: SegmentDonutProps) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const r = (size - thickness) / 2;
  const cx = size / 2;
  const cy = size / 2;
  const C = 2 * Math.PI * r;
  let acc = 0;

  return (
    <div className="flex items-center gap-4">
      <svg
        viewBox={`0 0 ${size} ${size}`}
        width={size}
        height={size}
        role="img"
        aria-label={`Donut: ${data.map((d) => `${d.name} ${d.value}`).join(", ")}`}
      >
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="var(--color-surface)" strokeWidth={thickness} />
        {data.map((d, i) => {
          const frac = d.value / total;
          const dash = frac * C;
          const off = acc * C;
          acc += frac;
          return (
            <circle
              key={i}
              cx={cx}
              cy={cy}
              r={r}
              fill="none"
              stroke={d.color}
              strokeWidth={thickness}
              strokeDasharray={`${dash} ${C - dash}`}
              strokeDashoffset={-off}
              transform={`rotate(-90 ${cx} ${cy})`}
            />
          );
        })}
        <text x={cx} y={cy - 2} textAnchor="middle" fontSize="20" fontWeight="600" fill="var(--color-text)" className="tnum">
          {centerValue}
        </text>
        <text x={cx} y={cy + 14} textAnchor="middle" fontSize="10" fill="var(--color-text-muted)">
          {centerLabel}
        </text>
      </svg>
      <div className="flex flex-col gap-1.5">
        {data.map((d, i) => (
          <div key={i} className="legend-item">
            <span className="sw" style={{ background: d.color }} />
            <span className="text-[var(--color-text)]">{d.name}</span>
            <span className="tnum text-[var(--color-text-muted)]">{Math.round((d.value / total) * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}
