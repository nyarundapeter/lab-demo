import * as React from "react";
import { StatusDot, Delta, type StatusDotStatus } from "@dbp/ui";
import { TrendingUp } from "lucide-react";

export interface HeroBandProps {
  status: StatusDotStatus;
  period: string;
  outcome: string;
  revenueToTargetPct: number;
  revenueToTargetDelta: number;
  forecast: string;
  forecastDelta: string;
}

/**
 * Inverted-pyramid apex — verbatim port of dash-views-1.jsx:26-46
 * (`.headline-band`, `.hb-outcome`, `.hb-metric` from dashboard.css).
 * The DR-9 audience/decisions/questions/mode meta strip (`IntentStrip`) is
 * deliberately OMITTED per the verbatim-port contract.
 */
export function HeroBand({
  status,
  period,
  outcome,
  revenueToTargetPct,
  revenueToTargetDelta,
  forecast,
  forecastDelta,
}: HeroBandProps) {
  return (
    <div className="headline-band">
      <div style={{ flex: "1 1 340px", minWidth: 0 }}>
        <div className="mb-1.5 flex items-center gap-2.5">
          <StatusDot status={status} pill>
            On track
          </StatusDot>
          <span className="text-xs text-[var(--color-text-muted)]">{period}</span>
        </div>
        <div className="hb-outcome">{outcome}</div>
      </div>
      <div className="flex flex-shrink-0 gap-7">
        <div>
          <div className="text-[11.5px] font-medium text-[var(--color-text-muted)]">Revenue to target</div>
          <div className="hb-metric tnum">
            {revenueToTargetPct}
            <span className="text-[0.5em] font-medium text-[var(--color-text-muted)]">%</span>
          </div>
          <span className="inline-flex items-center gap-1">
            <Delta value={revenueToTargetDelta} />
            <span className="text-[11.5px] text-[var(--color-text-muted)]">vs last qtr</span>
          </span>
        </div>
        <div>
          <div className="text-[11.5px] font-medium text-[var(--color-text-muted)]">Full-year forecast</div>
          <div className="hb-metric tnum">{forecast}</div>
          <span className="provenance">
            <TrendingUp size={9} aria-hidden />
            {forecastDelta}
          </span>
        </div>
      </div>
    </div>
  );
}
