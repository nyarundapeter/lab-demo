"use client";
import * as React from "react";
import { Button } from "@dbp/ui";

export interface TrendChartProps {
  series: number[];
  labels: string[];
  target?: number;
  height?: number;
  yFormat?: (v: number) => string;
}

/**
 * Revenue-vs-target trend chart — verbatim port of dash-charts.jsx:24-70
 * (`LineChart`, plain inline `<svg>`/`<polyline>`, NOT a chart library, per
 * the verbatim-port contract). Adds the reference's Trend/Cumulative
 * `viewSwitcher` (dash-views-1.jsx:60) as local state.
 */
export function TrendChart({ series, labels, target, height = 220, yFormat = (v) => String(v) }: TrendChartProps) {
  const [view, setView] = React.useState<"Trend" | "Cumulative">("Trend");
  const [tip, setTip] = React.useState<{ x: number; y: number; label: string; value: number } | null>(null);

  const data = React.useMemo(() => {
    if (view === "Trend") return series;
    let acc = 0;
    return series.map((v) => (acc += v));
  }, [series, view]);

  const w = 640;
  const h = height;
  const padL = 40;
  const padR = 12;
  const padT = 12;
  const padB = 24;
  const effTarget = view === "Trend" ? target : undefined;
  const max = Math.max(...data, effTarget || 0) * 1.1 || 1;
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const n = data.length;
  const x = (i: number) => padL + (i / (n - 1)) * (w - padL - padR);
  const y = (v: number) => padT + (1 - (v - min) / range) * (h - padT - padB);
  const ticks = 4;
  const color = "var(--color-secondary)";
  const points = data.map((v, i) => `${x(i)},${y(v)}`).join(" ");
  const area = `${padL},${h - padB} ${points} ${w - padR},${h - padB}`;

  return (
    <div className="relative">
      <div className="mb-2 flex justify-end">
        <div className="flex rounded-md bg-[var(--color-surface)] p-0.5">
          {(["Trend", "Cumulative"] as const).map((v) => (
            <Button
              key={v}
              variant="ghost"
              onClick={() => setView(v)}
              className="h-[22px] rounded px-2 text-[11.5px]"
              style={{
                background: view === v ? "var(--color-surface-2)" : "transparent",
                boxShadow: view === v ? "var(--shadow-sm)" : "none",
                fontWeight: view === v ? 500 : 400,
              }}
            >
              {v}
            </Button>
          ))}
        </div>
      </div>
      <svg
        viewBox={`0 0 ${w} ${h}`}
        width="100%"
        height={h}
        role="img"
        preserveAspectRatio="none"
        aria-label={`Line chart. Revenue latest ${yFormat(data[data.length - 1] ?? 0)}`}
      >
        {Array.from({ length: ticks + 1 }).map((_, i) => {
          const val = min + (range * i) / ticks;
          const yy = y(val);
          return (
            <g key={i}>
              <line x1={padL} y1={yy} x2={w - padR} y2={yy} className="chart-grid-line" opacity={i === 0 ? 0 : 0.6} />
              <text x={padL - 6} y={yy + 3} textAnchor="end" className="axis-label">
                {yFormat(Math.round(val))}
              </text>
            </g>
          );
        })}
        {effTarget != null && (
          <>
            <line
              x1={padL}
              y1={y(effTarget)}
              x2={w - padR}
              y2={y(effTarget)}
              stroke="var(--color-text-muted)"
              strokeDasharray="4 3"
              strokeWidth="1"
            />
            <text x={w - padR} y={y(effTarget) - 4} textAnchor="end" className="axis-label" fill="var(--color-text-muted)">
              Target
            </text>
          </>
        )}
        <polygon points={area} fill={color} opacity="0.08" />
        <polyline points={points} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        {data.map((v, i) => (
          <circle
            key={i}
            cx={x(i)}
            cy={y(v)}
            r="3.5"
            fill="var(--color-surface-2)"
            stroke={color}
            strokeWidth="2"
            style={{ cursor: "pointer" }}
            onMouseEnter={(e) => setTip({ x: e.clientX, y: e.clientY, label: labels[i] ?? "", value: v })}
            onMouseLeave={() => setTip(null)}
          />
        ))}
        {labels.map(
          (l, i) =>
            i % Math.ceil(labels.length / 7) === 0 && (
              <text key={i} x={x(i)} y={h - 6} textAnchor="middle" className="axis-label">
                {l}
              </text>
            ),
        )}
      </svg>
      {tip && (
        <div
          className="chart-tt fixed z-[200] pointer-events-none"
          style={{ left: tip.x + 12, top: tip.y + 12 }}
        >
          <div className="mb-0.5 font-semibold">{tip.label}</div>
          <div>Revenue: {yFormat(tip.value)}</div>
        </div>
      )}
    </div>
  );
}
