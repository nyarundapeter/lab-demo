// @dbp/organisms/field-ai-assist — the three AI field-assist variants
// (ai-example-dashboard/ai/field.jsx:50-116). One package per the
// wave3-build-plan's "one package with 3 exports, shared fetch logic"
// option — mirrors the @dbp/organisms/workflow-binding precedent (one
// subpath, several named organism exports).
export { FieldSuggestValue } from "./field-suggest-value.js";
export type { FieldSuggestValueProps, FieldSuggestValueConfig } from "./field-suggest-value.js";

export { FieldMultiSuggest } from "./field-multi-suggest.js";
export type { FieldMultiSuggestProps, FieldMultiSuggestConfig } from "./field-multi-suggest.js";

export { FieldRewrite } from "./field-rewrite.js";
export type { FieldRewriteProps, FieldRewriteConfig } from "./field-rewrite.js";

export { useFieldSuggest } from "./hooks/use-field-suggest.js";
