import { z } from "zod";

// Config schemas for the @dbp/organisms/field-ai-assist organism family
// (ai-example-dashboard/ai/field.jsx:50-116) — FieldSuggestValue,
// FieldMultiSuggest, FieldRewrite. Each owns its own trigger() PS.AI call
// via useFieldSuggest(); `prompt` is the caller-authored instruction sent
// to ask() (this factory has no field-specific suggestion model, so the
// caller supplies what to ask for, same honesty pattern as ForecastCard).

export const FieldSuggestValueConfig = z.object({
  label: z.string(),
  placeholder: z.string().optional(),
  required: z.boolean().optional(),
  prompt: z.string().min(1),
  context: z.record(z.unknown()).optional(),
});
export type FieldSuggestValueConfig = z.infer<typeof FieldSuggestValueConfig>;

export const FieldMultiSuggestConfig = z.object({
  label: z.string(),
  placeholder: z.string().optional(),
  required: z.boolean().optional(),
  prompt: z.string().min(1),
  context: z.record(z.unknown()).optional(),
});
export type FieldMultiSuggestConfig = z.infer<typeof FieldMultiSuggestConfig>;

export const FieldRewriteConfig = z.object({
  label: z.string(),
  defaultValue: z.string().optional(),
  prompt: z.string().min(1),
  /** Optional second assist action (e.g. "Summarise") with its own prompt. */
  secondaryAction: z.object({ label: z.string(), prompt: z.string().min(1) }).optional(),
  context: z.record(z.unknown()).optional(),
});
export type FieldRewriteConfig = z.infer<typeof FieldRewriteConfig>;
