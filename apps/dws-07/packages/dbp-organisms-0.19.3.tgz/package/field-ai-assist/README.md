# @dbp/organisms/field-ai-assist

**registryId:** `APP.F36`

Three AI field-assist variants — `FieldSuggestValue`, `FieldMultiSuggest`, `FieldRewrite` — each owning a live PS.AI suggest/rewrite call.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `FieldSuggestValue` | `.` |
| `FieldMultiSuggest` | `.` |
| `FieldRewrite` | `.` |

## Consumed by
Bespoke import — mounted next to a form field by the solution/organism that owns that field.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/field-ai-assist` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
