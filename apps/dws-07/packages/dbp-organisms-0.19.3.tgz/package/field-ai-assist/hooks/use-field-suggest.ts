import * as React from "react";
import { ask } from "@dbp/ps-ai/client";
import type { AssistTriggerState } from "@dbp/ui";

/**
 * Shared trigger/fetch logic for FieldSuggestValue/FieldMultiSuggest/
 * FieldRewrite (ai-example-dashboard/ai/field.jsx:50-116) — each owns its
 * own `trigger()` async suggest/rewrite call, but the request/state
 * machinery (loading → result | unavailable) is identical across all
 * three, so it lives here once rather than tripled.
 */
export function useFieldSuggest(prompt: string, context?: Record<string, unknown>) {
  const [state, setState] = React.useState<AssistTriggerState>("ready");

  const trigger = React.useCallback(async (): Promise<string | null> => {
    setState("loading");
    try {
      const result = await ask({ message: prompt, ...(context !== undefined ? { context } : {}) });
      setState("ready");
      return result.message;
    } catch {
      setState("unavailable");
      return null;
    }
  }, [prompt, context]);

  return { state, trigger };
}
