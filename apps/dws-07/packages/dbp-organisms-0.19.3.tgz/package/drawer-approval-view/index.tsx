import React from "react";
import { ShieldCheck } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, Alert, Pagination, ConfirmDialog, SectionLabel, Skeleton } from "@dbp/ui";
import { ActionPanel, useApprovalWorkflow, type ApprovalSurfaceConfig } from "@dbp/organisms/approval-surface";
import { WorkflowServiceError } from "@dbp/ps-workflow/client";
import { DrawerApprovalViewConfig, type DrawerApprovalViewConfigInput } from "./types.js";

export interface DrawerApprovalViewProps extends DrawerApprovalViewConfigInput {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/**
 * APP.F58 — Drawer Approval View
 *
 * Approval-queue review drawer with record navigation — port of
 * overlay-drawers.jsx's `ApprovalDrawer` ("Approval review with record
 * navigation"). Composes the existing `Pagination` molecule as the record
 * pager (J/K keyboard shortcuts step through the queue, matching the
 * reference), approval-surface's own `ActionPanel`+`useApprovalWorkflow`
 * bound to the currently-paged item, and a `ConfirmDialog` guarding the
 * close action since the reviewer may be mid-queue. Distinct from
 * `approval-drawer` (Family 3, APP.F58) which reviews a single instance with
 * no queue — this drawer is the multi-item review-with-navigation variant.
 */
export default function DrawerApprovalView(props: DrawerApprovalViewProps) {
  const { open, onOpenChange, ...config } = props;
  const parsed = DrawerApprovalViewConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="right" size="wide">
          <SheetHeader>
            <SheetTitle>DrawerApprovalView — invalid config</SheetTitle>
          </SheetHeader>
          <Alert tone="danger" title="DrawerApprovalView — invalid config" data-testid="config-error">
            <ul className="mt-1 list-disc pl-5">
              {parsed.error.issues.map((issue, i) => (
                <li key={i}>
                  {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
                  {issue.message}
                </li>
              ))}
            </ul>
          </Alert>
        </SheetContent>
      </Sheet>
    );
  }

  return <DrawerApprovalViewInner config={parsed.data} open={open} onOpenChange={onOpenChange} />;
}

const DEMO_SESSION = btoa(
  JSON.stringify({
    userId: "demo-approver",
    roles: ["finance-approver", "platform-admin", "user"],
    tenantId: "demo",
  }),
);

function DrawerApprovalViewInner({
  config,
  open,
  onOpenChange,
}: {
  config: DrawerApprovalViewConfig;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [index, setIndex] = React.useState(() => Math.min(config.initialIndex, config.items.length - 1));
  const [confirmClose, setConfirmClose] = React.useState(false);
  const current = config.items[index]!;

  React.useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (e.key === "j" || e.key === "ArrowDown") setIndex((i) => Math.min(config.items.length - 1, i + 1));
      if (e.key === "k" || e.key === "ArrowUp") setIndex((i) => Math.max(0, i - 1));
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, config.items.length]);

  const requestClose = React.useCallback(() => {
    if (config.confirmOnClose) {
      setConfirmClose(true);
      return;
    }
    onOpenChange(false);
  }, [config.confirmOnClose, onOpenChange]);

  return (
    <>
      <Sheet open={open} onOpenChange={(next) => (next ? onOpenChange(true) : requestClose())}>
        <SheetContent side="right" size="wide" data-testid="drawer-approval-view">
          <SheetHeader>
            <Pagination
              page={index + 1}
              pageSize={1}
              total={config.items.length}
              onPageChange={(p) => setIndex(p - 1)}
              showCaption
            />
            {current.eyebrow && (
              <SectionLabel as="p">{current.eyebrow}</SectionLabel>
            )}
            <SheetTitle>{current.title}</SheetTitle>
          </SheetHeader>

          <div className="flex flex-col gap-4 overflow-y-auto">
            {(current.amount || current.budgetRemaining) && (
              <div className="flex gap-6 flex-wrap">
                {current.amount && (
                  <div>
                    <div className="text-xs text-[var(--color-text-muted)]">Amount</div>
                    <div className="text-xl font-semibold tracking-tight">{current.amount}</div>
                  </div>
                )}
                {current.budgetRemaining && (
                  <div className="border-l border-[var(--color-border-default)] pl-6">
                    <div className="text-xs text-[var(--color-text-muted)]">Budget remaining</div>
                    <div className="text-xl font-semibold tracking-tight">{current.budgetRemaining}</div>
                  </div>
                )}
              </div>
            )}

            {current.policyNote && (
              <Alert tone="success" title="Within policy">
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck size={14} aria-hidden="true" />
                  {current.policyNote}
                </span>
              </Alert>
            )}

            {current.lineItems.length > 0 && (
              <div>
                <SectionLabel as="h4" className="mb-2">
                  Line items
                </SectionLabel>
                <div className="flex flex-col divide-y divide-[var(--color-border-default)] rounded-[var(--radius-card)] border border-[var(--color-border-default)]">
                  {current.lineItems.map((l) => (
                    <div key={l.item} className="flex items-center justify-between px-3.5 py-2.5 text-sm">
                      <span>
                        {l.item} <span className="text-xs text-[var(--color-text-muted)]">×{l.qty}</span>
                      </span>
                      <span className="font-medium">{l.total}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {current.meta.length > 0 && (
              <div className="flex flex-col divide-y divide-[var(--color-border-default)]">
                {current.meta.map((m) => (
                  <div key={m.label} className="flex gap-3 py-2 text-sm">
                    <span className="w-28 shrink-0 text-[var(--color-text-muted)]">{m.label}</span>
                    <span className="flex-1 font-medium">{m.value}</span>
                  </div>
                ))}
              </div>
            )}

            <DrawerApprovalDecision
              key={current.workflowId}
              workflowId={current.workflowId}
              approveAction={config.approveAction}
              {...(config.resource !== undefined && { resource: config.resource })}
              {...(config.approveLabel !== undefined && { approveLabel: config.approveLabel })}
              {...(config.rejectLabel !== undefined && { rejectLabel: config.rejectLabel })}
              requireComment={config.requireComment}
              onAdvance={() => setIndex((i) => Math.min(config.items.length - 1, i + 1))}
            />
          </div>
        </SheetContent>
      </Sheet>

      <ConfirmDialog
        open={confirmClose}
        onOpenChange={setConfirmClose}
        title="Close approval review?"
        description="Your progress on this queue is preserved — reopen it from the queue at any time."
        confirmLabel="Close review"
        cancelLabel="Keep reviewing"
        onConfirm={() => {
          setConfirmClose(false);
          onOpenChange(false);
        }}
      />
    </>
  );
}

interface DrawerApprovalDecisionProps {
  workflowId: string;
  approveAction: string;
  resource?: string;
  approveLabel?: string;
  rejectLabel?: string;
  requireComment: ApprovalSurfaceConfig["requireComment"];
  onAdvance: () => void;
}

/** Binds the currently-paged item to a live PS.WORKFLOW instance via `useApprovalWorkflow`, then hands decision UI to `ActionPanel`. */
function DrawerApprovalDecision({
  workflowId,
  approveAction,
  resource,
  approveLabel,
  rejectLabel,
  requireComment,
  onAdvance,
}: DrawerApprovalDecisionProps) {
  const { instance, isLoading, error, isAdvancing, isRejecting, advance, reject } = useApprovalWorkflow(workflowId);
  const [serviceError, setServiceError] = React.useState<string | null>(null);

  async function handleApprove(comment: string) {
    setServiceError(null);
    try {
      await advance({ comment: comment || undefined }, DEMO_SESSION);
      onAdvance();
    } catch (err) {
      setServiceError(
        err instanceof WorkflowServiceError && err.status === 403
          ? "The workflow engine denied the transition. You may not have permission to approve this step."
          : err instanceof WorkflowServiceError
            ? err.message
            : "Failed to approve. Please try again.",
      );
    }
  }

  async function handleReject(comment: string) {
    setServiceError(null);
    try {
      await reject({ comment: comment || undefined }, DEMO_SESSION);
      onAdvance();
    } catch (err) {
      setServiceError(
        err instanceof WorkflowServiceError && err.status === 403
          ? "The workflow engine denied the transition. You may not have permission to reject this step."
          : err instanceof WorkflowServiceError
            ? err.message
            : "Failed to reject. Please try again.",
      );
    }
  }

  if (isLoading) {
    return (
      <div className="flex flex-col gap-3" data-testid="drawer-approval-view-loading" aria-busy="true">
        <Skeleton className="h-4 w-32" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }

  if (error && instance === null) {
    return (
      <Alert tone="danger" title="Failed to load workflow instance" data-testid="drawer-approval-view-error">
        {error instanceof WorkflowServiceError ? error.message : "Unexpected error loading this approval."}
      </Alert>
    );
  }

  if (instance === null) return null;

  const isTerminal = instance.status === "completed" || instance.status === "rejected";
  if (isTerminal) {
    return (
      <div
        className="rounded border border-[var(--color-border)] bg-[var(--color-bg)] px-4 py-3 text-sm text-[var(--color-text)] opacity-70"
        data-testid="terminal-outcome"
      >
        This instance is <strong>{instance.status}</strong>. No further actions are available.
      </div>
    );
  }

  const actionPanelConfig: ApprovalSurfaceConfig = {
    workflowId,
    approveAction,
    ...(resource !== undefined && { resource }),
    ...(approveLabel !== undefined && { approveLabel }),
    ...(rejectLabel !== undefined && { rejectLabel }),
    requireComment,
    showHistory: false,
    allowDelegate: false,
    allowRequestInfo: true,
  };

  return (
    <ActionPanel
      config={actionPanelConfig}
      isAdvancing={isAdvancing}
      isRejecting={isRejecting}
      serviceError={serviceError}
      onApprove={handleApprove}
      onReject={handleReject}
    />
  );
}
