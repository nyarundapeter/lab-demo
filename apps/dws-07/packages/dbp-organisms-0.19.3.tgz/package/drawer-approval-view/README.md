# @dbp/organisms/drawer-approval-view

**registryId:** `APP.F58`

Approval-queue review drawer with record navigation — a pager steps through a queue of
PS.WORKFLOW instances without closing the drawer; the decision surface (`ActionPanel`) rebinds
to whichever item is currently paged to. See `FEATURE.md` for how this differs from the
single-instance `approval-drawer` organism.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`DrawerApprovalViewConfig` — Zod schema exported from `types.ts` (source of truth). Component
props also take `open`/`onOpenChange` (controlled), not part of the Zod config.

## Consumed by
Not yet wired — no caller mounts this drawer yet (same "not yet wired" state as
`approval-drawer`/`data-mapping` at build time).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/drawer-approval-view` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
