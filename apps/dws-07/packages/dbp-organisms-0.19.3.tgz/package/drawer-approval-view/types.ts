import { z } from "zod";

/**
 * DrawerApprovalViewConfig — the single typed contract for APP.F58.
 *
 * Data contract only (no function fields — Zod schemas are data-only, same
 * rule as approval-surface/approval-drawer's types.ts).
 */
const LineItemSchema = z.object({
  item: z.string().min(1),
  qty: z.number().int().positive(),
  total: z.string().min(1),
});
export type DrawerApprovalLineItem = z.infer<typeof LineItemSchema>;

const MetaRowSchema = z.object({ label: z.string().min(1), value: z.string().min(1) });
export type DrawerApprovalMetaRow = z.infer<typeof MetaRowSchema>;

const DrawerApprovalItemSchema = z.object({
  /** The PS.WORKFLOW instance ID this queue row loads and acts on. */
  workflowId: z.string().min(1),
  eyebrow: z.string().optional(),
  title: z.string().min(1),
  amount: z.string().optional(),
  budgetRemaining: z.string().optional(),
  /** Short "within policy" note — rendered as a success callout when present. */
  policyNote: z.string().optional(),
  lineItems: z.array(LineItemSchema).default([]),
  meta: z.array(MetaRowSchema).default([]),
});
export type DrawerApprovalItem = z.infer<typeof DrawerApprovalItemSchema>;

export const DrawerApprovalViewConfig = z
  .object({
    items: z.array(DrawerApprovalItemSchema).min(1),
    approveAction: z.string().min(1),
    resource: z.string().optional(),
    approveLabel: z.string().optional(),
    rejectLabel: z.string().optional(),
    requireComment: z.enum(["never", "on-reject", "always"]).default("on-reject"),
    /** Index into `items` to open on. @default 0 */
    initialIndex: z.number().int().nonnegative().default(0),
    /** Confirm before closing the drawer — the reviewer may be mid-queue. @default true */
    confirmOnClose: z.boolean().default(true),
  })
  .strict();

export type DrawerApprovalViewConfig = z.infer<typeof DrawerApprovalViewConfig>;
export type DrawerApprovalViewConfigInput = z.input<typeof DrawerApprovalViewConfig>;
