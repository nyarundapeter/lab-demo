import * as React from "react";
import { useForm, type Resolver } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { FieldSet } from "@dbp/organisms/form-builder/renderer";
import { compileDynamicSchema } from "@dbp/organisms/form-builder/logic";
import type { FormDefinition } from "@dbp/organisms/form-builder/types";
import { Alert, Badge, Button, UnsavedChangesConfirmDialog, useUnsavedGuard } from "@dbp/ui";

export interface FormBodyProps {
  definition: FormDefinition;
  showRequesterMeta: boolean;
  requesterLabel: string | undefined;
  onSuccessSecondaryLabel: string | undefined;
  /** Demo-only forced-failure toggle, per spec §5/§9 ("demo a forced failure once"). */
  forceSubmitError?: boolean | undefined;
  onCancel?: (() => void) | undefined;
  /** Persistence hook — awaited before the success panel renders. See index.tsx RecordFormProps. */
  onSubmit?: ((values: Record<string, unknown>) => Promise<void> | void) | undefined;
  /**
   * "page" forms have no bounded scroll container — a sticky footer would pin
   * to the shell viewport and float over content, which shell-v3/N27 forbids
   * (FormBasicLayout: "NO sticky/fixed bottom action bar — actions live in
   * the PageHeader"). For "page", actions render in the title row instead
   * (N28/N36 pattern). "drawer"/"modal" are bounded overlays — the sticky
   * bottom bar is correct there and unchanged.
   */
  placement: "page" | "drawer" | "modal";
}

type SubmitState = { kind: "idle" } | { kind: "success" } | { kind: "error"; message: string };

/**
 * FormBody — the organism-owned chrome (header, validation summary, action
 * bar, submit lifecycle) wrapping `@dbp/organisms/form-builder`'s `FieldSet`
 * (form-builder responsibility per spec §2/§3). Shared across the
 * page/drawer/modal placements — see index.tsx. Actions render in the title
 * row for "page" and in a sticky bottom bar for "drawer"/"modal" — see the
 * `placement` prop doc.
 */
export function FormBody({
  definition,
  showRequesterMeta,
  requesterLabel,
  onSuccessSecondaryLabel,
  forceSubmitError,
  onCancel,
  onSubmit: onSubmitProp,
  placement,
}: FormBodyProps) {
  const summaryRef = React.useRef<HTMLDivElement>(null);
  const [submitState, setSubmitState] = React.useState<SubmitState>({ kind: "idle" });

  const resolver: Resolver<Record<string, unknown>> = React.useCallback(
    async (values, context, options) => {
      const schema = compileDynamicSchema(definition, values);
      return zodResolver(schema)(values, context, options);
    },
    [definition],
  );

  const {
    register,
    control,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting, isDirty },
  } = useForm<Record<string, unknown>>({
    resolver,
    mode: "onBlur",
    reValidateMode: "onChange",
    defaultValues: buildDefaultValues(definition),
  });

  const values = watch();
  const errorEntries = Object.entries(errors);

  const unsavedGuard = useUnsavedGuard({
    isDirty,
    onDiscard: () => onCancel?.(),
  });

  const onSubmit = handleSubmit(
    async (formValues) => {
      try {
        if (forceSubmitError) {
          throw new Error("Something went wrong while saving. Your entries were kept — try again.");
        }
        await onSubmitProp?.(formValues);
        setSubmitState({ kind: "success" });
      } catch (err) {
        setSubmitState({ kind: "error", message: err instanceof Error ? err.message : "Submission failed." });
      }
    },
    () => {
      requestAnimationFrame(() => summaryRef.current?.focus());
    },
  );

  if (submitState.kind === "success") {
    return (
      <div className="flex flex-col gap-4" data-testid="record-form-success">
        <Alert tone="success" title="Saved">
          {definition.successMessage}
        </Alert>
        {onSuccessSecondaryLabel && (
          <Button
            variant="outline"
            type="button"
            onClick={() => setSubmitState({ kind: "idle" })}
            data-testid="record-form-success-secondary"
          >
            {onSuccessSecondaryLabel}
          </Button>
        )}
      </div>
    );
  }

  const actions = (
    <>
      {onCancel && (
        <Button type="button" variant="ghost" onClick={unsavedGuard.requestClose} data-testid="record-form-cancel">
          Cancel
        </Button>
      )}
      <Button type="submit" loading={isSubmitting} disabled={isSubmitting} variant="orange" data-testid="record-form-submit">
        {isSubmitting ? "Saving…" : definition.submitLabel}
      </Button>
    </>
  );

  return (
    <form onSubmit={onSubmit} noValidate className="flex flex-col gap-6" data-testid="record-form">
      <div className="flex flex-col gap-1">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-semibold text-[var(--color-text-primary)]">
              {definition.labels["title"] ?? definition.id}
            </h2>
            {isDirty && <Badge tone="warning">Unsaved changes</Badge>}
          </div>
          {placement === "page" && <div className="flex shrink-0 items-center gap-3">{actions}</div>}
        </div>
        {definition.labels["description"] && (
          <p className="text-sm text-[var(--color-text-secondary)]">{definition.labels["description"]}</p>
        )}
        {showRequesterMeta && requesterLabel && (
          <p className="text-xs text-[var(--color-text-muted)]">{requesterLabel}</p>
        )}
      </div>

      {submitState.kind === "error" && (
        <Alert
          tone="danger"
          title="Couldn't save"
          dismissible
          data-testid="record-form-submit-error"
        >
          {submitState.message}
        </Alert>
      )}

      {errorEntries.length > 0 && (
        <div
          ref={summaryRef}
          role="alert"
          tabIndex={-1}
          data-testid="record-form-validation-summary"
          className="rounded-[var(--radius-md)] border border-[var(--color-danger)] bg-[var(--color-danger-surface)] p-4"
        >
          <p className="text-sm font-medium text-[var(--color-danger-text)]">
            {errorEntries.length} field{errorEntries.length > 1 ? "s" : ""} need attention
          </p>
          <ul className="mt-1 list-disc pl-5 text-sm text-[var(--color-danger-text)]">
            {errorEntries.map(([field, error]) => (
              <li key={field}>
                <a href={`#${field}`}>{(error?.message as string) ?? field}</a>
              </li>
            ))}
          </ul>
        </div>
      )}

      {definition.sections.length === 0 && (
        <p className="text-sm text-[var(--color-text-muted)]" data-testid="record-form-empty">
          This form has no fields yet. Add sections to the form definition to start collecting entries.
        </p>
      )}

      <FieldSet
        sections={definition.sections}
        register={register}
        control={control}
        errors={errors}
        values={values}
        disabled={isSubmitting}
      />

      {placement !== "page" && (
        <div className="sticky bottom-0 flex items-center justify-end gap-3 border-t border-[var(--color-border)] bg-[var(--color-background)] py-4">
          {actions}
        </div>
      )}

      {onCancel && (
        <UnsavedChangesConfirmDialog
          open={unsavedGuard.confirmOpen}
          onOpenChange={unsavedGuard.setConfirmOpen}
          title="Discard unsaved changes?"
          description="You have unsaved changes. Leaving now will discard them."
          discardLabel="Discard changes"
          onDiscard={unsavedGuard.confirmDiscard}
        />
      )}
    </form>
  );
}

function buildDefaultValues(definition: FormDefinition): Record<string, unknown> {
  const defaults: Record<string, unknown> = {};
  for (const section of definition.sections) {
    for (const field of section.fields) {
      if (field.type === "checkbox" || field.type === "switch") defaults[field.id] = false;
      else if (field.type === "number") defaults[field.id] = undefined;
      else if (field.type === "checkbox-group" || field.type === "tags") defaults[field.id] = [];
      else if (field.type === "date-range") defaults[field.id] = {};
      // Seeded with one empty row, matching forms-blocks.jsx's RepeatableGroup
      // ("at least one row visible" convention) — useFieldArray otherwise
      // starts empty and renders no row at all.
      else if (field.type === "repeatable-group") {
        defaults[field.id] = [
          Object.fromEntries(
            (field.subFields ?? []).map((sf) => [sf.id, sf.type === "checkbox" || sf.type === "switch" ? false : ""]),
          ),
        ];
      } else defaults[field.id] = "";
    }
  }
  return defaults;
}
