import * as React from "react";
import { Alert, Dialog, DialogContent, EmptyState, Sheet, SheetContent, Skeleton, formatDate } from "@dbp/ui";
import { useFormDefinition } from "@dbp/organisms/form-builder/hooks";
import { useSessionIdentity } from "@dbp/ps-auth/client";
import { RecordFormOrganismConfigSchema, type RecordFormOrganismConfig } from "./types.js";
import { FormBody } from "./components/form-body.js";

type ConfigInput = Omit<RecordFormOrganismConfig, "placement" | "showRequesterMeta"> &
  Partial<Pick<RecordFormOrganismConfig, "placement" | "showRequesterMeta">>;

export type RecordFormProps = ConfigInput & {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onCancel?: () => void;
  /**
   * Persistence hook — called with the validated form values on submit.
   * Rejecting/throwing surfaces the existing submit-error Alert path; the
   * organism does not persist anything itself when this is omitted (matches
   * the pre-existing demo-only success behavior).
   */
  onSubmit?: (values: Record<string, unknown>) => Promise<void> | void;
  /** Demo-only: forces the submit error path once, per spec §5/§9. */
  forceSubmitError?: boolean;
};

/**
 * APP.F24 — Record Form
 *
 * Config-driven, single-page sectioned record-creation/edit form. Renders a
 * `FormDefinition` (form-builder contract) as a titled field stack with
 * validation choreography, dirty-state tracking, and a submit lifecycle.
 * Composes @dbp/organisms/form-builder's FieldSet for the field stack and
 * @dbp/ui Sheet/Dialog for the drawer/modal placements — no hand-rolled
 * field components or overlay shells (spec §1/§3,
 * docs/03-features/specs/record-form-spec-2026-07-12.md).
 *
 * Config is validated at render time via safeParse; a config-error Alert is
 * rendered (never thrown) on invalid config.
 */
export default function RecordForm(rawConfig: RecordFormProps) {
  const { open, onOpenChange, onCancel, onSubmit, forceSubmitError, ...configInput } = rawConfig;
  const parseResult = RecordFormOrganismConfigSchema.safeParse(configInput);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="RecordForm — invalid config" data-testid="config-error">
        <ul className="mt-1 list-disc pl-5">
          {parseResult.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <RecordFormInner
      config={parseResult.data}
      open={open}
      onOpenChange={onOpenChange}
      onCancel={onCancel}
      onSubmit={onSubmit}
      forceSubmitError={forceSubmitError}
    />
  );
}

function RecordFormInner({
  config,
  open,
  onOpenChange,
  onCancel,
  onSubmit,
  forceSubmitError,
}: {
  config: RecordFormOrganismConfig;
  open?: boolean | undefined;
  onOpenChange?: ((open: boolean) => void) | undefined;
  onCancel?: (() => void) | undefined;
  onSubmit?: ((values: Record<string, unknown>) => Promise<void> | void) | undefined;
  forceSubmitError?: boolean | undefined;
}) {
  const { identity } = useSessionIdentity();
  const fetched = useFormDefinition(config.formDefinitionId ?? "", {
    enabled: Boolean(config.formDefinitionId) && !config.formDefinition,
  });

  const definition = config.formDefinition ?? fetched.definition;

  const requesterLabel = identity
    ? `Requested by ${identity.displayName}${definition ? ` · Draft created ${formatDate(definition.createdAt, "short")}` : ""}`
    : undefined;

  let body: React.ReactNode;
  if (!config.formDefinition && fetched.isLoading) {
    body = (
      <div className="flex flex-col gap-4" data-testid="record-form-loading">
        <Skeleton className="h-8 w-1/2" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  } else if (!config.formDefinition && fetched.error) {
    body = (
      <EmptyState
        tone="danger"
        headline="Couldn't load this form"
        description={fetched.error.message}
        data-testid="record-form-fetch-error"
      />
    );
  } else if (!definition) {
    body = (
      <EmptyState tone="danger" headline="Form definition not found" data-testid="record-form-not-found" />
    );
  } else {
    body = (
      <FormBody
        definition={definition}
        showRequesterMeta={config.showRequesterMeta}
        requesterLabel={config.showRequesterMeta ? requesterLabel : undefined}
        onSuccessSecondaryLabel={config.onSuccessSecondaryLabel}
        forceSubmitError={forceSubmitError}
        onCancel={onCancel}
        onSubmit={onSubmit}
        placement={config.placement}
      />
    );
  }

  if (config.placement === "drawer") {
    return (
      <Sheet {...(open !== undefined && { open })} {...(onOpenChange !== undefined && { onOpenChange })}>
        <SheetContent side="right" size="wide" data-testid="record-form-drawer">
          <div style={{ containerType: "inline-size" }}>{body}</div>
        </SheetContent>
      </Sheet>
    );
  }

  if (config.placement === "modal") {
    return (
      <Dialog {...(open !== undefined && { open })} {...(onOpenChange !== undefined && { onOpenChange })}>
        <DialogContent size="lg" data-testid="record-form-modal">
          <div style={{ containerType: "inline-size" }}>{body}</div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <div style={{ containerType: "inline-size" }} data-testid="record-form-page">
      {body}
    </div>
  );
}


export type { RecordFormOrganismConfig } from "./types.js";
