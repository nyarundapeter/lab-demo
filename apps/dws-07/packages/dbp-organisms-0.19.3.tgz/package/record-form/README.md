# @dbp/organisms/record-form

APP.F24 — config-driven record-creation/edit form. See `FEATURE.md` for the
full behaviour contract and `docs/03-features/specs/record-form-spec-2026-07-12.md`
for the build spec.

```tsx
import RecordForm from "@dbp/organisms/record-form";

<RecordForm formDefinitionId="technology-standard-proposal" placement="page" />
```
