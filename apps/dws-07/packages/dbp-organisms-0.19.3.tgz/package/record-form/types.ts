import { z } from "zod";
import { FormDefinitionSchema } from "@dbp/organisms/form-builder/types";

/**
 * APP.F24 — Record Form organism config.
 *
 * Thin wrapper around `FormDefinition` (source of truth for field/section
 * content — @dbp/organisms/form-builder/types.ts). The organism owns no
 * separate field-content schema; see spec §4
 * (docs/03-features/specs/record-form-spec-2026-07-12.md).
 *
 * `formDefinitionId` XOR `formDefinition` mirrors FormBuilderConfig's
 * existing runtime-fetch-vs-literal posture.
 */
export const RecordFormOrganismConfigSchema = z
  .object({
    /** The FormDefinition id to fetch (PS.DATA entity type "form-definition"). */
    formDefinitionId: z.string().min(1).optional(),
    /** Literal FormDefinition — for solutions not yet on runtime-fetched definitions. */
    formDefinition: FormDefinitionSchema.optional(),
    /** Placement — drives layout only, not field content. */
    placement: z.enum(["page", "drawer", "modal"]).default("page"),
    /** Meta row above the form header, e.g. "Requested by {user}". */
    showRequesterMeta: z.boolean().default(true),
    /** "propose another" / "raise another request" secondary action after success. */
    onSuccessSecondaryLabel: z.string().optional(),
  })
  .refine((v) => v.formDefinitionId ?? v.formDefinition, {
    message: "one of formDefinitionId or formDefinition is required",
  });

export type RecordFormOrganismConfig = z.infer<typeof RecordFormOrganismConfigSchema>;

export type { FormDefinition } from "@dbp/organisms/form-builder/types";
