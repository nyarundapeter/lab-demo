"use client";
import { useMutation } from "@tanstack/react-query";
import { CreateInviteInput, CreateInviteResult } from "../types.js";
import type { CreateInviteInput as CreateInviteInputT, CreateInviteResult as CreateInviteResultT } from "../types.js";

/**
 * useCreateInvite — mock client for the PS.AUTH create-invite mutation that
 * does not exist yet (`platform-services/auth/client/admin.ts` only exports
 * `useAdminUsers()`, read-only). Per the blocked-row build policy (Wave 3
 * build plan, Amendment A): called exactly like a real PS.* client mutation
 * hook so the eventual real implementation is a drop-in swap. NOT WIRED to
 * any backend — resolves locally after a simulated delay. See the
 * "Not wired" note on this organism's Storybook docs page.
 */
export function useCreateInvite() {
  return useMutation({
    mutationFn: async (input: CreateInviteInputT): Promise<CreateInviteResultT> => {
      const parsed = CreateInviteInput.parse(input);
      await new Promise((resolve) => setTimeout(resolve, 400));
      return CreateInviteResult.parse({ invited: parsed.emails });
    },
  });
}
