import { z } from "zod";

export const InviteRoleOption = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  desc: z.string().optional(),
});
export type InviteRoleOption = z.infer<typeof InviteRoleOption>;

export const InviteWorkspaceOption = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
});
export type InviteWorkspaceOption = z.infer<typeof InviteWorkspaceOption>;

export const InviteModalConfig = z.object({
  orgName: z.string().min(1),
  roles: z.array(InviteRoleOption).min(1),
  workspaces: z.array(InviteWorkspaceOption).default([]),
  defaultExpiryDays: z.enum(["3", "7", "14", "30"]).default("7"),
  triggerLabel: z.string().default("Invite people"),
});
export type InviteModalConfig = z.infer<typeof InviteModalConfig>;
export type InviteModalConfigInput = z.input<typeof InviteModalConfig>;

// ─── Mock PS.AUTH create-invite contract (blocked-row build policy) ────────
//
// `packages/stack/platform-services/auth/client/admin.ts` only exports
// `useAdminUsers()` (read) — there is no create-user/invite mutation in
// PS.AUTH yet (Wave 3 Family 4g gap). Per Amendment A, this is the Zod
// contract the missing mutation *would* expose, so `client/create-invite.ts`
// can call it exactly like any other real PS.* client mutation and the
// eventual real implementation is a drop-in swap, not a rewrite.

export const CreateInviteInput = z.object({
  emails: z.array(z.string().email()).min(1),
  roleId: z.string().min(1),
  workspaceId: z.string().optional(),
  expiryDays: z.number().int().positive(),
  note: z.string().optional(),
});
export type CreateInviteInput = z.infer<typeof CreateInviteInput>;

export const CreateInviteResult = z.object({
  invited: z.array(z.string()),
});
export type CreateInviteResult = z.infer<typeof CreateInviteResult>;
