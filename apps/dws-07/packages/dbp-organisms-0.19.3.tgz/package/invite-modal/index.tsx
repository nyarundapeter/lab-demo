import * as React from "react";
import { Send } from "lucide-react";
import {
  Alert,
  Button,
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
  FormField,
  TagsField,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
  Textarea,
} from "@dbp/ui";
import { InviteModalConfig, type InviteModalConfigInput } from "./types.js";
import { useCreateInvite } from "./client/create-invite.js";

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const EXPIRY_OPTIONS = [
  { value: "3", label: "After 3 days" },
  { value: "7", label: "After 7 days" },
  { value: "14", label: "After 14 days" },
  { value: "30", label: "After 30 days" },
];

/**
 * InviteModal (R6: `add-user-modal`) — admin invite dialog: multi-email
 * entry with validation, role and workspace pickers, expiry, and an optional
 * note. Port of `identity-invite.jsx`'s `InviteModal`.
 *
 * **Not wired** — `platform-services/auth/client/admin.ts` only exports
 * `useAdminUsers()` (read). No create-user/invite mutation exists in
 * PS.AUTH yet. This organism calls `useCreateInvite()`
 * (`client/create-invite.ts`), a typed mock built against the Zod contract
 * the real mutation would expose — see `FEATURE.md` for the gap this
 * surfaces.
 */
export default function InviteModal(config: InviteModalConfigInput) {
  const parsed = InviteModalConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="InviteModal — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <InviteModalInner config={parsed.data} />;
}

function InviteModalInner({ config }: { config: InviteModalConfig }) {
  const [open, setOpen] = React.useState(false);
  const [emails, setEmails] = React.useState<string[]>([]);
  const [emailError, setEmailError] = React.useState<string | undefined>(undefined);
  const [roleId, setRoleId] = React.useState(config.roles[0]!.id);
  const [workspaceId, setWorkspaceId] = React.useState(config.workspaces[0]?.id);
  const [expiryDays, setExpiryDays] = React.useState(config.defaultExpiryDays);
  const [note, setNote] = React.useState("");
  const createInvite = useCreateInvite();

  function handleEmailsChange(next: string[]) {
    if (next.length > emails.length) {
      const added = next[next.length - 1]!;
      if (!EMAIL_RE.test(added)) {
        setEmailError(`"${added}" isn't a valid email address`);
        return;
      }
    }
    setEmailError(undefined);
    setEmails(next);
  }

  function reset() {
    setEmails([]);
    setEmailError(undefined);
    setNote("");
    createInvite.reset();
  }

  const roleName = config.roles.find((r) => r.id === roleId)?.name ?? roleId;
  const roleDesc = config.roles.find((r) => r.id === roleId)?.desc;
  const sent = createInvite.isSuccess;

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      <Button onClick={() => setOpen(true)} data-testid="invite-modal-trigger">
        {config.triggerLabel}
      </Button>
      <DialogContent data-testid="invite-modal">
        {sent ? (
          <DialogBody className="flex flex-col items-center gap-3 py-10 text-center">
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[var(--color-success-surface)]">
              <Send size={18} className="text-[var(--color-success)]" aria-hidden="true" />
            </span>
            <h3 className="text-base font-semibold text-primary">
              {createInvite.data!.invited.length}{" "}
              {createInvite.data!.invited.length === 1 ? "invitation" : "invitations"} sent
            </h3>
            <p className="max-w-sm text-sm text-[var(--color-text-muted)]">
              They&rsquo;ll receive an email to join <strong className="text-primary">{config.orgName}</strong> as{" "}
              {roleName}. Invitations expire in {expiryDays} days.
            </p>
            <div className="mt-2 flex gap-2">
              <Button variant="outline" onClick={reset} data-testid="invite-more">
                Invite more
              </Button>
              <Button onClick={() => setOpen(false)} data-testid="invite-done">
                Done
              </Button>
            </div>
          </DialogBody>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Invite people</DialogTitle>
              <DialogDescription>Add teammates to {config.orgName}</DialogDescription>
            </DialogHeader>
            <DialogBody className="flex flex-col gap-4">
              <Alert tone="warning" variant="compact">
                Not wired — PS.AUTH has no create-invite mutation yet. This sends against a mock client.
              </Alert>
              <FormField
                label="Email addresses"
                required
                {...(emailError !== undefined && { error: emailError })}
                {...(emailError === undefined && { helperText: "Type an address and press Enter. Add several at once." })}
              >
                <TagsField
                  tags={emails}
                  onChange={handleEmailsChange}
                  placeholder="name@company.com"
                  state={emailError ? "error" : "default"}
                />
              </FormField>
              <div className="grid grid-cols-2 gap-3">
                <FormField label="Role" {...(roleDesc !== undefined && { helperText: roleDesc })}>
                  <Select value={roleId} onValueChange={setRoleId}>
                    <SelectTrigger data-testid="invite-role"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {config.roles.map((r) => (
                        <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormField>
                {config.workspaces.length > 0 && (
                  <FormField label="Workspace">
                    <Select {...(workspaceId !== undefined && { value: workspaceId })} onValueChange={setWorkspaceId}>
                      <SelectTrigger data-testid="invite-workspace"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {config.workspaces.map((w) => (
                          <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormField>
                )}
              </div>
              <FormField label="Invitation expires">
                <Select value={expiryDays} onValueChange={(v) => setExpiryDays(v as typeof expiryDays)}>
                  <SelectTrigger data-testid="invite-expiry"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {EXPIRY_OPTIONS.map((o) => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FormField>
              <FormField label="Personal note" optional helperText="Included in the invitation email.">
                <Textarea
                  rows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Welcome to the team — reach out if you need anything."
                />
              </FormField>
              {createInvite.isError && (
                <Alert tone="danger" title="Couldn't send invitations">
                  {createInvite.error instanceof Error ? createInvite.error.message : "Something went wrong."}
                </Alert>
              )}
            </DialogBody>
            <DialogFooter className="flex-row items-center justify-between sm:justify-between">
              <span className="text-xs text-[var(--color-text-muted)]">
                {emails.length} recipient{emails.length !== 1 ? "s" : ""}
              </span>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button
                  disabled={!emails.length || createInvite.isPending}
                  loading={createInvite.isPending}
                  onClick={() =>
                    createInvite.mutate({
                      emails,
                      roleId,
                      ...(workspaceId !== undefined && { workspaceId }),
                      expiryDays: Number(expiryDays),
                      ...(note && { note }),
                    })
                  }
                  data-testid="invite-submit"
                >
                  <Send size={14} aria-hidden="true" />
                  Send {emails.length || ""} invite{emails.length !== 1 ? "s" : ""}
                </Button>
              </div>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

export type { InviteModalConfig, InviteModalConfigInput } from "./types.js";
