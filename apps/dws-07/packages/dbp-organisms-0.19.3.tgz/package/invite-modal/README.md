# @dbp/organisms/invite-modal

**registryId:** `APP.F64` (placeholder — assigned during central registration)

Admin invite dialog: multi-email entry, role/workspace pickers, expiry, personal note, and a
send confirmation panel. See `FEATURE.md` for why this ships against a mock create-invite client
— no `PS.AUTH` create-user mutation exists today.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`InviteModalConfig` — Zod schema exported from `types.ts` (source of truth). The mock
create-invite call's contract (`CreateInviteInput`/`CreateInviteResult`) is also exported from
`types.ts`.

## Consumed by
Not yet wired — no `FEATURE_COMPONENT` route in `scripts/scaffold-solution.mjs` targets this
organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/invite-modal` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
