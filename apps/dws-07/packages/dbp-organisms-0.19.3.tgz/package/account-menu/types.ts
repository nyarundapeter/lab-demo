import { z } from "zod";

export const AccountMenuConfig = z.object({
  memberName: z.string().min(1),
  memberEmail: z.string().email(),
});

export type AccountMenuConfig = z.infer<typeof AccountMenuConfig>;
export type AccountMenuConfigInput = z.input<typeof AccountMenuConfig>;
