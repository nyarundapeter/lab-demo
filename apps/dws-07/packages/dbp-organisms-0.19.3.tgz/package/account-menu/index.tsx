import React from "react";
import { User, Shield, Lock, Settings, LogOut } from "lucide-react";
import {
  Alert,
  Avatar,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@dbp/ui";
import { AccountMenuConfig, type AccountMenuConfigInput } from "./types.js";

export type AccountMenuProps = AccountMenuConfigInput & {
  onProfile?: () => void;
  onSecurity?: () => void;
  onTokens?: () => void;
  onPreferences?: () => void;
  onSignOut?: () => void;
};

/**
 * AccountMenu — the top-bar avatar dropdown: identity header + Profile /
 * Security / API tokens / Preferences links + Sign out. Port of
 * `identity-shell.jsx`'s `AccountMenu`.
 *
 * **Confirmed genuinely missing, not reused.** Per this build's coordination
 * note, `packages/shared/ui/src/components/app-top-bar.tsx` and
 * `app-chrome.tsx` were read directly before building this: `AppChrome`'s
 * `userSlot` already renders a working dropdown, but it's a **role
 * switcher** (`AdminGovernance / Finance Approver / …`), not an account
 * menu — no Profile/Security/API-tokens/Sign-out items exist anywhere.
 * `AppTopBar`'s own default `userSlot` (used when no slot is passed) is
 * just a static two-line avatar block with no dropdown at all. This
 * organism fills that gap; wiring it into `AppChrome`'s `userSlot` — which
 * currently doubles as the role switcher — is a composition decision left
 * to whoever integrates the two, not resolved unilaterally here.
 */
export default function AccountMenu(rawConfig: AccountMenuProps) {
  const { onProfile, onSecurity, onTokens, onPreferences, onSignOut, ...configInput } = rawConfig;
  const parsed = AccountMenuConfig.safeParse(configInput);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="AccountMenu — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <AccountMenuInner
      config={parsed.data}
      onProfile={onProfile}
      onSecurity={onSecurity}
      onTokens={onTokens}
      onPreferences={onPreferences}
      onSignOut={onSignOut}
    />
  );
}

function AccountMenuInner({
  config,
  onProfile,
  onSecurity,
  onTokens,
  onPreferences,
  onSignOut,
}: {
  config: AccountMenuConfig;
  onProfile?: (() => void) | undefined;
  onSecurity?: (() => void) | undefined;
  onTokens?: (() => void) | undefined;
  onPreferences?: (() => void) | undefined;
  onSignOut?: (() => void) | undefined;
}) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {/* deliberate keep: rounded-full icon-only avatar trigger — Button has no rounded-full shape */}
        <button
          type="button"
          aria-label="Account menu"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-colors focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
        >
          <Avatar name={config.memberName} size="sm" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <DropdownMenuLabel className="flex items-center gap-2.5 py-2 font-normal">
          <Avatar name={config.memberName} size="md" />
          <span className="min-w-0">
            <span className="block truncate text-sm font-semibold">{config.memberName}</span>
            <span className="block truncate text-xs text-[var(--color-text-muted)]">{config.memberEmail}</span>
          </span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem {...(onProfile !== undefined && { onSelect: onProfile })}>
          <User size={14} className="text-[var(--color-text-muted)]" />
          Profile
        </DropdownMenuItem>
        <DropdownMenuItem {...(onSecurity !== undefined && { onSelect: onSecurity })}>
          <Shield size={14} className="text-[var(--color-text-muted)]" />
          Security
        </DropdownMenuItem>
        <DropdownMenuItem {...(onTokens !== undefined && { onSelect: onTokens })}>
          <Lock size={14} className="text-[var(--color-text-muted)]" />
          API tokens
        </DropdownMenuItem>
        <DropdownMenuItem {...(onPreferences !== undefined && { onSelect: onPreferences })}>
          <Settings size={14} className="text-[var(--color-text-muted)]" />
          Preferences
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem {...(onSignOut !== undefined && { onSelect: onSignOut })} className="text-danger">
          <LogOut size={14} />
          Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
