# @dbp/organisms/account-menu

**registryId:** `APP.F53` (placeholder — assigned during central registration)

Top-bar avatar dropdown (Profile/Security/API tokens/Preferences/Sign out). See `FEATURE.md` —
confirmed genuinely missing, not a duplicate of `AppChrome`'s role switcher.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`AccountMenuConfig` — Zod schema exported from `types.ts` (source of truth). The default
export's prop type (`AccountMenuProps`) adds `onProfile`/`onSecurity`/`onTokens`/
`onPreferences`/`onSignOut` callbacks.

## Consumed by
Not yet wired — integrating with `AppChrome`'s existing role-switcher `userSlot` needs a
composition decision (see `FEATURE.md`).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/account-menu` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
