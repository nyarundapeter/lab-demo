import { z } from "zod";

// Data-only contract — no function fields. Callbacks (onOpenResult,
// onSaveSearch) are typed separately as component props, same pattern as
// the sibling search-bar organism's onSelect.

export const SearchResultsConfig = z
  .object({
    /** Query the page loads with — usually the term the user just ran globally. */
    initialQuery: z.string().default(""),
    /** Field-equality filters PS.SEARCH understands, seeded before the facet rail is touched. */
    initialFilters: z.record(z.string(), z.string()).default({}),
    /** Rows shown before "Load more"; also PS.SEARCH's requested pageSize. */
    pageSize: z.number().int().positive().default(8),
  })
  .strict();

export type SearchResultsConfig = z.infer<typeof SearchResultsConfig>;
export type SearchResultsConfigInput = z.input<typeof SearchResultsConfig>;
