import * as React from "react";
import { Search, Star, Lock } from "lucide-react";
import { useSearch } from "@dbp/ps-search/client";
import type { SearchHit } from "@dbp/ps-search/client";
import { Alert, Button, SaveSearchModal, type SaveSearchInput } from "@dbp/ui";
import { FacetRail } from "./components/facet-rail.js";
import { ResultRow } from "./components/result-row.js";
import { SearchResultsConfig } from "./types.js";
import type { SearchResultsConfig as SearchResultsConfigType, SearchResultsConfigInput } from "./types.js";

export type { SearchResultsConfig, SearchResultsConfigInput } from "./types.js";

/**
 * APP.F72 (placeholder — real id assigned during central registration) —
 * Search results page. Port of search-system/search-results.jsx's
 * `ResultsPage`. Binds live to `PS.SEARCH`'s `useSearch(query, filters,
 * options)` hook (`@dbp/ps-search/client`, same hook the `search-bar`
 * organism already uses) — real UI-composition work against a working
 * platform service, not a mock.
 *
 * Scope adaptations vs. the reference mockup (see FEATURE.md): single
 * relevance-ranked list only (no grouped-by-type view — the real facet set
 * is just `entityType` today, making a separate grouped view redundant);
 * single-value-per-field faceting (PS.SEARCH filters are equality-only, no
 * multi-select `$in`); no spell-correction (PS.SEARCH doesn't offer one).
 *
 * Also ports `search-states.jsx`'s "Permission-filtered results" state —
 * `hiddenByAccessCount`/`onRequestAccess` props render the "N results hidden
 * by your access" notice between the count row and the result list. Prop-driven,
 * data injected; no PS.RBAC wiring yet.
 */
export default function SearchResultsPage({
  config,
  onOpenResult,
  onSaveSearch,
  hiddenByAccessCount,
  onRequestAccess,
}: {
  config: SearchResultsConfigInput;
  /** Called when a result row is opened (Enter or click). */
  onOpenResult?: ((hit: SearchHit) => void) | undefined;
  /** Called when the save-search dialog is confirmed. No PS.SAVED-SEARCH persistence exists — see saved-search organism's FEATURE.md. */
  onSaveSearch?: ((input: SaveSearchInput & { query: string; filters: Record<string, string> }) => void) | undefined;
  /**
   * Count of matching results the caller has withheld because the current
   * user lacks permission to view them (RBAC-filtered upstream of this
   * component — PS.SEARCH itself doesn't return a permission-filtered
   * count, so this is prop-driven, data injected by the caller, not wired
   * to PS.RBAC). Port of `search-states.jsx`'s "Permission-filtered
   * results" state.
   */
  hiddenByAccessCount?: number | undefined;
  /** Called when the "Request access" action is used. */
  onRequestAccess?: (() => void) | undefined;
}) {
  const parsed = SearchResultsConfig.safeParse(config);
  if (!parsed.success) {
    return (
      <Alert tone="danger" title="SearchResultsPage — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <SearchResultsPageInner
      config={parsed.data}
      onOpenResult={onOpenResult}
      onSaveSearch={onSaveSearch}
      hiddenByAccessCount={hiddenByAccessCount}
      onRequestAccess={onRequestAccess}
    />
  );
}

function SearchResultsPageInner({
  config,
  onOpenResult,
  onSaveSearch,
  hiddenByAccessCount,
  onRequestAccess,
}: {
  config: SearchResultsConfigType;
  onOpenResult?: ((hit: SearchHit) => void) | undefined;
  onSaveSearch?: ((input: SaveSearchInput & { query: string; filters: Record<string, string> }) => void) | undefined;
  hiddenByAccessCount?: number | undefined;
  onRequestAccess?: (() => void) | undefined;
}) {
  const [query] = React.useState(config.initialQuery);
  const [filters, setFilters] = React.useState<Record<string, string>>(config.initialFilters);
  const [visibleCount, setVisibleCount] = React.useState(config.pageSize);
  const [focusedIndex, setFocusedIndex] = React.useState(-1);
  const [saveModalOpen, setSaveModalOpen] = React.useState(false);
  const rowRefs = React.useRef<Array<HTMLDivElement | null>>([]);

  const { results, facets, total, loading } = useSearch(query, filters, { page: 1, pageSize: visibleCount });

  React.useEffect(() => {
    setFocusedIndex(-1);
  }, [filters, query]);

  const queryTerms = query.trim() ? query.trim().split(/\s+/) : [];
  const anyFilterActive = Object.keys(filters).length > 0;

  const toggleFacet = (field: string, value: string) => {
    setFilters((prev) => {
      if (prev[field] === value) {
        const next = { ...prev };
        delete next[field];
        return next;
      }
      return { ...prev, [field]: value };
    });
    setVisibleCount(config.pageSize);
  };

  const clearFacets = () => {
    setFilters({});
    setVisibleCount(config.pageSize);
  };

  const onListKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (results.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setFocusedIndex((i) => {
        const next = Math.min(i + 1, results.length - 1);
        rowRefs.current[next]?.focus();
        return next;
      });
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setFocusedIndex((i) => {
        const next = Math.max(i - 1, 0);
        rowRefs.current[next]?.focus();
        return next;
      });
    } else if (e.key === "Enter" && focusedIndex >= 0) {
      e.preventDefault();
      const hit = results[focusedIndex];
      if (hit) onOpenResult?.(hit);
    }
  };

  const queryChips = [
    ...(query.trim() ? [{ label: query.trim() }] : []),
    ...Object.entries(filters).map(([field, value]) => ({ label: `${field}:${value}`, kind: "filter" as const })),
  ];

  return (
    <div className="flex gap-6" data-testid="search-results-page">
      <FacetRail facets={facets} selected={filters} onToggle={toggleFacet} onClear={clearFacets} />

      <div className="min-w-0 flex-1" role="listbox" aria-label="Search results" tabIndex={-1} onKeyDown={onListKeyDown}>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-[var(--color-text-muted)]">
            <span className="font-semibold text-[var(--color-text-primary)]">{total}</span>{" "}
            {total === 1 ? "result" : "results"}
            {query.trim() && (
              <>
                {" "}for <span className="font-semibold text-[var(--color-text-primary)]">&ldquo;{query}&rdquo;</span>
              </>
            )}
          </p>
          {results.length > 0 && (
            <Button type="button" variant="outline" size="sm" onClick={() => setSaveModalOpen(true)}>
              <Star size={13} aria-hidden="true" />
              Save search
            </Button>
          )}
        </div>

        {Boolean(hiddenByAccessCount) && hiddenByAccessCount! > 0 && (
          <Alert tone="info" icon={<Lock size={15} aria-hidden="true" />} className="mb-3" data-testid="search-results-hidden-by-access">
            <b>
              {hiddenByAccessCount} {hiddenByAccessCount === 1 ? "result is" : "results are"} hidden by your access.
            </b>{" "}
            They exist but you don&rsquo;t have permission to view them.{" "}
            <Button type="button" variant="link" size="sm" onClick={onRequestAccess}>
              Request access
            </Button>
          </Alert>
        )}

        {loading && results.length === 0 && (
          <p className="py-10 text-center text-sm text-[var(--color-text-muted)]">Searching&hellip;</p>
        )}

        {!loading && results.length === 0 && (
          <div className="flex flex-col items-center gap-2 rounded-card border border-dashed border-[var(--color-border-default)] py-12 text-center" data-testid="search-results-empty">
            <Search size={22} className="text-[var(--color-text-muted)]" aria-hidden="true" />
            <h3 className="text-sm font-semibold">
              {query.trim() ? `No results for “${query}”` : "Start typing to search"}
            </h3>
            <p className="max-w-sm text-xs text-[var(--color-text-muted)]">
              {query.trim()
                ? "Try fewer or more general terms, or broaden your filters."
                : "Results from every record type you can see will appear here."}
            </p>
            {anyFilterActive && (
              <Button type="button" variant="outline" size="sm" onClick={clearFacets}>
                Clear filters
              </Button>
            )}
          </div>
        )}

        {results.length > 0 && (
          <div className="flex flex-col gap-0.5">
            {results.map((hit, i) => (
              <ResultRow
                key={hit.id}
                ref={(el) => {
                  rowRefs.current[i] = el;
                }}
                hit={hit}
                queryTerms={queryTerms}
                focused={focusedIndex === i}
                onFocus={() => setFocusedIndex(i)}
                onOpen={() => onOpenResult?.(hit)}
              />
            ))}
            <div className="mt-2 flex items-center justify-between">
              {visibleCount < total ? (
                <Button type="button" variant="outline" size="sm" onClick={() => setVisibleCount((c) => c + config.pageSize)}>
                  Load {Math.min(config.pageSize, total - visibleCount)} more
                </Button>
              ) : (
                <span className="text-xs text-[var(--color-text-muted)]">End of results &middot; {total} shown</span>
              )}
            </div>
          </div>
        )}
      </div>

      <SaveSearchModal
        open={saveModalOpen}
        onOpenChange={setSaveModalOpen}
        defaultName={query}
        queryChips={queryChips}
        onSave={(input) => {
          setSaveModalOpen(false);
          onSaveSearch?.({ ...input, query, filters });
        }}
      />
    </div>
  );
}
