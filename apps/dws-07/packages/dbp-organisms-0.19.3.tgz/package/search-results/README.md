# @dbp/organisms/search-results

**registryId:** `APP.F72` (placeholder — assigned during central registration)

Global search results page: facet rail + relevance-ranked, keyboard-navigable result list.
Binds live to `PS.SEARCH`'s `useSearch` hook. See `FEATURE.md` for composition and the
adaptations made against the real `SearchHit`/`Facet` contract vs. the reference mockup.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`SearchResultsConfig` — Zod schema exported from `types.ts` (source of truth). Callbacks
(`onOpenResult`, `onSaveSearch`) are separate component props, not part of the config.

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route a
search-results page yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/search-results` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
