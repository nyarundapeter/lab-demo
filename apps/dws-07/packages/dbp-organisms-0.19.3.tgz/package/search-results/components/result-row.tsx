import * as React from "react";
import { FileQuestion, Percent, Hash } from "lucide-react";
import { Highlight, TypePill, MetaLine, cn } from "@dbp/ui";
import type { SearchHit } from "@dbp/ps-search/client";

/**
 * ResultRow — port of search-system/search-results.jsx's `ResultRow`.
 * Composes the search-result-row molecules (Highlight/TypePill/MetaLine)
 * from `@dbp/ui`. `SearchHit` carries no per-record icon/owner/status/
 * amount metadata (PS.SEARCH is a generic index, not CRM-specific), so the
 * meta line surfaces what the service actually returns: relevance score,
 * record id, and which fields matched — not fabricated CRM fields.
 */

export interface ResultRowProps {
  hit: SearchHit;
  queryTerms: string[];
  focused: boolean;
  onFocus: () => void;
  onOpen: () => void;
}

export const ResultRow = React.forwardRef<HTMLDivElement, ResultRowProps>(function ResultRow(
  { hit, queryTerms, focused, onFocus, onOpen },
  ref,
) {
  const matchedFields = hit.highlights ? Object.keys(hit.highlights) : [];

  return (
    <div
      ref={ref}
      role="option"
      aria-selected={focused}
      tabIndex={focused ? 0 : -1}
      onMouseEnter={onFocus}
      onClick={onOpen}
      onKeyDown={(e) => {
        if (e.key === "Enter") onOpen();
      }}
      data-testid={`search-result-${hit.id}`}
      className={cn(
        "flex cursor-pointer items-start gap-3 rounded-input px-3 py-2.5 outline-none",
        focused ? "bg-[var(--color-navy-50)]" : "hover:bg-[var(--color-surface)]",
      )}
    >
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="truncate text-sm font-medium text-[var(--color-text-primary)]">
            <Highlight text={hit.title} terms={queryTerms} />
          </span>
          <TypePill icon={FileQuestion} label={hit.entityType} />
        </div>
        <MetaLine
          items={[
            { icon: Percent, label: `${Math.round(hit.score * 100)}% match` },
            { icon: Hash, label: hit.id, mono: true },
            ...(matchedFields.length > 0 ? [{ label: `Matched in ${matchedFields.join(", ")}` }] : []),
          ]}
        />
      </div>
    </div>
  );
});
