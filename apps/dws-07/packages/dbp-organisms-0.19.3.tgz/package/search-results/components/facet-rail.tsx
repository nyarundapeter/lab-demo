import * as React from "react";
import { Check } from "lucide-react";
import { cn, SectionLabel, Button } from "@dbp/ui";
import type { Facet } from "@dbp/ps-search/client";

/**
 * FacetRail — port of search-system/search-results.jsx's `FacetRail`,
 * generalised to render one group per PS.SEARCH `Facet` rather than the
 * reference mockup's fixed type/date/owner/status categories. The real
 * `MiniSearchAdapter` only ever facets `entityType` today, but this stays
 * correct if more `facetFields` are added server-side later.
 *
 * PS.SEARCH's `filters` are field-equality only (`Record<string,
 * string|number|boolean>`, no `$in`) — so selection is single-value-per-
 * field (click to select, click again to clear), not the reference's
 * checkbox multi-select, which the real service can't express in one query.
 */

export interface FacetRailProps {
  facets: Facet[];
  /** Currently-selected value per facet field. */
  selected: Record<string, string>;
  onToggle: (field: string, value: string) => void;
  onClear: () => void;
  className?: string;
}

export function FacetRail({ facets, selected, onToggle, onClear, className }: FacetRailProps) {
  const anyActive = Object.keys(selected).length > 0;
  const visibleFacets = facets.filter((f) => f.values.length > 0);

  return (
    <div className={cn("w-56 shrink-0", className)} aria-label="Search filters">
      <div className="mb-3 flex items-center justify-between">
        <SectionLabel>Filters</SectionLabel>
        {anyActive && (
          <Button type="button" variant="link" onClick={onClear} className="h-auto text-xs font-medium">
            Clear all
          </Button>
        )}
      </div>

      {visibleFacets.length === 0 && <p className="text-xs text-[var(--color-text-muted)]">No filters available.</p>}

      {visibleFacets.map((facet) => (
        <div key={facet.field} className="mb-4">
          <div className="mb-1.5 text-xs font-semibold capitalize text-[var(--color-text-primary)]">{facet.field}</div>
          <div className="flex flex-col gap-0.5">
            {facet.values.map((value) => {
              const active = selected[facet.field] === value.value;
              return (
                <Button
                  key={value.value}
                  type="button"
                  variant="ghost"
                  role="checkbox"
                  aria-checked={active}
                  onClick={() => onToggle(facet.field, value.value)}
                  className={cn(
                    "h-auto w-full justify-start gap-2 rounded px-1.5 py-1 text-left text-xs font-normal",
                    active && "bg-[var(--color-navy-50)]",
                  )}
                >
                  <span
                    aria-hidden="true"
                    className={cn(
                      "flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-[3px] border",
                      active ? "border-primary bg-primary" : "border-[var(--color-border-default)]",
                    )}
                  >
                    {active && <Check size={9} className="text-white" />}
                  </span>
                  <span className="flex-1 truncate">{value.value}</span>
                  <span className="text-[var(--color-text-muted)]">{value.count}</span>
                </Button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
