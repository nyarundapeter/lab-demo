"use client"

import * as React from "react"
import { useQuery } from "@tanstack/react-query"
import { fetchMatrix } from "@dbp/ps-rbac/client"
import { Check, Minus } from "lucide-react"
import { EmptyState } from "@dbp/ui"

/* ─── AdminAccessMatrix ──────────────────────────────────────────────────
 * Access Control (admin/access-control) — real PS.RBAC role/permission
 * matrix (GET /admin/rbac/matrix), rendered read-only: one row per
 * resource.action permission, one column per role, a check where the
 * matrix grants that role the permission. Mutating the matrix isn't
 * exposed by PS.RBAC's admin API yet, so this is a viewer, not an editor.
 * ─────────────────────────────────────────────────────────────────────── */

export function AdminAccessMatrix() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["ps-rbac", "admin", "access-control-page"],
    queryFn: fetchMatrix,
  })

  if (isLoading) {
    return <p className="text-sm text-[var(--color-text-secondary)] py-6">Loading permission matrix…</p>
  }
  if (error) {
    return <EmptyState tone="danger" headline="Failed to load access matrix" description={error instanceof Error ? error.message : String(error)} />
  }
  if (!data || data.permissions.length === 0 || data.roles.length === 0) {
    return <EmptyState title="No permissions configured" description="No role/permission matrix is configured for this tenant yet." />
  }

  const grantedRoleIds = (resource: string, action: string) =>
    new Set(
      data.matrix
        .filter((entry) => entry.resource === resource && entry.action === action)
        .map((entry) => entry.role),
    )

  return (
    <div className="overflow-x-auto rounded-lg border border-[var(--color-border-subtle)]">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]">
            <th className="text-left font-medium px-4 py-2.5 text-[var(--color-text-secondary)]">Permission</th>
            {data.roles.map((role) => (
              <th key={role.id} className="text-center font-medium px-3 py-2.5 text-[var(--color-text-secondary)]">
                {role.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.permissions.map((permission) => {
            const granted = grantedRoleIds(permission.resource, permission.action)
            return (
              <tr key={`${permission.resource}.${permission.action}`} className="border-b border-[var(--color-border-subtle)] last:border-0">
                <td className="px-4 py-2.5 font-medium text-[var(--color-text-primary)]">
                  {/* action is already fully qualified (e.g. "invoice.approve") — don't prefix resource again */}
                  {permission.action}
                  {permission.description ? (
                    <span className="block text-xs font-normal text-[var(--color-text-secondary)]">{permission.description}</span>
                  ) : null}
                </td>
                {data.roles.map((role) => (
                  <td key={role.id} className="text-center px-3 py-2.5">
                    {granted.has(role.id) ? (
                      <Check size={16} className="inline text-[var(--color-success-text)]" aria-label="Allowed" />
                    ) : (
                      <Minus size={14} className="inline text-[var(--color-text-muted)]" aria-label="Not allowed" />
                    )}
                  </td>
                ))}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export type { AdminAccessMatrixConfig } from "./types.js";
