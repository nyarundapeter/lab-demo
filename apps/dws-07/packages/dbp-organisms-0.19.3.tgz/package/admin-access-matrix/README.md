# @dbp/organisms/admin-access-matrix

**registryId:** `APP.F18`

Read-only PS.RBAC role/permission matrix viewer for the admin/access-control page.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`AdminAccessMatrixConfig` — empty Zod schema (no props; self-fetches).

## Consumed by
Bespoke import — `apps/dbp/app/(authenticated)/admin/access-control/page.tsx`.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/admin-access-matrix` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
