import { z } from "zod";

// AdminAccessMatrix takes no props — it self-fetches the whole matrix from
// PS.RBAC. The empty schema is kept for catalogue/DoD consistency with the
// other promoted organisms (2026-07-21 Bindings/Admin resolution).
export const AdminAccessMatrixConfig = z.object({});

export type AdminAccessMatrixConfig = z.infer<typeof AdminAccessMatrixConfig>;
