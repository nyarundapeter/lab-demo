# @dbp/organisms/integration-detail

**registryId:** `APP.F46`

Connected-integration detail: Overview/Data mapping/Logs/Monitoring tabs. Reuses
`MappingRowList` for the mapping tab; uses `Badge` not `EnvPill` — see `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`IntegrationDetailConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/integrations/[id]` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/integration-detail` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
