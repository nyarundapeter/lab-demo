import { z } from "zod";

const MappingRow = z.object({
  source: z.string().min(1),
  target: z.string().min(1),
  transform: z.string().min(1),
});

const LogEntry = z.object({
  time: z.string().min(1),
  level: z.enum(["error", "warn", "info"]),
  message: z.string().min(1),
});

export const IntegrationDetailConfig = z.object({
  name: z.string().min(1),
  status: z.enum(["active", "inactive", "error"]),
  env: z.string().min(1),
  category: z.string().min(1),
  syncDirection: z.string().min(1),
  frequency: z.string().min(1),
  auth: z.string().min(1),
  endpoint: z.string().min(1),
  owner: z.string().min(1),
  error: z.string().optional(),
  health: z.enum(["ok", "error"]),
  lastSync: z.string().min(1),
  recordsSynced: z.string().min(1),
  successRate: z.string().min(1),
  avgLatency: z.string().default("84ms"),
  mapping: z.array(MappingRow).default([]),
  logs: z.array(LogEntry).default([]),
});

export type IntegrationDetailConfig = z.infer<typeof IntegrationDetailConfig>;
export type IntegrationDetailConfigInput = z.input<typeof IntegrationDetailConfig>;
