import React from "react";
import { Key, Play, Power } from "lucide-react";
import {
  Alert,
  Badge,
  Button,
  InfoCard,
  MappingRowList,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@dbp/ui";
import { IntegrationDetailConfig, type IntegrationDetailConfigInput } from "./types.js";

const STATUS_TONE: Record<string, "active" | "gray" | "danger"> = {
  active: "active",
  inactive: "gray",
  error: "danger",
};
const LEVEL_TONE: Record<string, "danger" | "warning" | "gray"> = {
  error: "danger",
  warn: "warning",
  info: "gray",
};

/**
 * Connected-integration detail: Overview/Data mapping/Logs/Monitoring tabs.
 * Port of admin-specimens2.jsx's `IntegrationDetail`. Uses `Badge` for
 * environment identity (not `EnvPill` — see `environments-admin`'s FEATURE.md
 * for the out-of-scope ruling this respects) and the shared `MappingRowList`
 * molecule for the Data mapping tab.
 */
export default function IntegrationDetail(config: IntegrationDetailConfigInput) {
  const parsed = IntegrationDetailConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="IntegrationDetail — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const c = parsed.data;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold">{c.name}</h2>
            <Badge tone={STATUS_TONE[c.status]}>{c.status}</Badge>
            <Badge tone="gray">{c.env}</Badge>
          </div>
          <p className="mt-1 text-xs text-text-muted">
            {c.category} · {c.syncDirection} sync · {c.frequency}
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button type="button" variant="outline" size="sm">
            <Play size={13} />
            Test connection
          </Button>
          <Button type="button" variant="outline" size="sm">
            <Power size={13} />
            {c.status === "active" ? "Disable" : "Enable"}
          </Button>
        </div>
      </div>

      {c.error && (
        <Alert tone="danger" title="Sync failed">
          <div className="flex items-center justify-between gap-3">
            <span>{c.error}</span>
            <Button type="button" variant="outline" size="sm" className="shrink-0">
              <Key size={12} />
              Replace key
            </Button>
          </div>
        </Alert>
      )}

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="mapping">Data mapping</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-2">
            <InfoCard
              title="Connection"
              rows={[
                { label: "Authentication", value: c.auth },
                { label: "Endpoint", value: <span className="font-mono text-xs">{c.endpoint}</span> },
                { label: "Credentials", value: <span className="font-mono text-xs">••••••••</span> },
                { label: "Sync direction", value: c.syncDirection },
                { label: "Frequency", value: c.frequency },
                { label: "Owner", value: c.owner },
              ]}
            />
            <InfoCard
              title="Health"
              rows={[
                {
                  label: "Status",
                  value: (
                    <span className={c.health === "ok" ? "text-[var(--color-success)]" : "text-[var(--color-danger)]"}>
                      {c.health === "ok" ? "Healthy" : "Error"}
                    </span>
                  ),
                },
                { label: "Last sync", value: c.lastSync },
                { label: "Records synced", value: c.recordsSynced },
                { label: "Avg latency", value: c.avgLatency },
                { label: "Success rate (7d)", value: c.successRate },
              ]}
            />
          </div>
        </TabsContent>

        <TabsContent value="mapping" className="mt-4">
          <MappingRowList rows={c.mapping.map((m) => ({ source: m.source, target: m.target, meta: m.transform }))} />
        </TabsContent>

        {(["logs", "monitoring"] as const).map((tabValue) => (
          <TabsContent key={tabValue} value={tabValue} className="mt-4">
            <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
              {c.logs.map((l, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 px-3.5 py-2.5 text-xs"
                  style={i < c.logs.length - 1 ? { borderBottom: "1px solid var(--color-border-subtle)" } : undefined}
                >
                  <span className="font-mono text-xs text-text-muted">{l.time}</span>
                  <Badge tone={LEVEL_TONE[l.level]} className="uppercase">
                    {l.level}
                  </Badge>
                  <span>{l.message}</span>
                </div>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
