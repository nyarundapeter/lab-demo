// Builds the `x-dbp-session` header PS.WORKFLOW expects for advance/reject
// (see packages/stack/platform-services/workflow/SERVICE.md "Session-header
// convention") from the logged-in PS.AUTH user. Base64-encoded JSON, same
// shape as the Actor schema: { userId, roles, tenantId }.
import type { User } from "@dbp/ps-auth/client";

export function buildWorkflowSession(user: User): string {
  return btoa(JSON.stringify({ userId: user.id, roles: user.roles, tenantId: user.tenantId }));
}
