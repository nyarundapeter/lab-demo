import type * as React from "react";

// StepIndicator styles itself with the LVE design-scope variables; outside the
// LveDsScope (Pattern B panel) we map them back to the app tokens here.
export const STEP_VARS: React.CSSProperties = {
  ["--charcoal-950" as string]: "var(--color-primary)",
  ["--rose-500" as string]: "var(--color-secondary, var(--color-primary))",
  ["--gray-100" as string]: "var(--color-surface)",
  ["--gray-200" as string]: "var(--color-border-subtle)",
  ["--gray-400" as string]: "var(--color-text-muted)",
  ["--gray-500" as string]: "var(--color-text-muted)",
};
