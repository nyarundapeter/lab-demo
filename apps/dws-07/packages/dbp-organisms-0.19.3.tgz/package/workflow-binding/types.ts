import { z } from "zod";

// Config schema for the @dbp/organisms/workflow-binding hook + components.
// Generalized from apps/wfd-01 solution/components/record-workflow.tsx —
// no hardcoded definition ids or entity type; both come from the caller
// (manifest-declared binding, wired by the generator per §5b of
// docs/01-Architecture/PS-WORKFLOW-UI-Patterns.md).
// Zod is the source of truth — use z.infer, never hand-authored interfaces.

export const WorkflowBindingConfig = z.object({
  /** Ordered list of workflow definition ids this entity can be bound to. */
  definitionIds: z.array(z.string()),
  /** Entity type used for audit/context routing (e.g. "purchase-request"). */
  entityType: z.string(),
});

export type WorkflowBindingConfig = z.infer<typeof WorkflowBindingConfig>;
