# @dbp/organisms/workflow-binding

**registryId:** `APP.F23`

RecordProgressHistory/RecordWorkflowActions/RecordWorkflowStepper hook + components binding a record to a PS.WORKFLOW definition, generalized from `apps/wfd-01`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`WorkflowBindingConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Bespoke import — `scripts/scaffold-solution.mjs` imports this organism directly by name at specific generated call sites rather than via the `FEATURE_COMPONENT` map, mounted into the `object-page-detail` layout. Depends on `@dbp/organisms/lve-workspace` (APP.F19) as a workspace dependency.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/workflow-binding` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
