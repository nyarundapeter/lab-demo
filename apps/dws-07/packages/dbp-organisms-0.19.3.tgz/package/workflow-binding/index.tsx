// @dbp/organisms/workflow-binding — workflow-bound stepper + Progress History,
// generalized from apps/wfd-01 (docs/01-Architecture/PS-WORKFLOW-UI-Patterns.md).
export { useRecordWorkflow, walkStages, slaDescription, escalated } from "./hooks/use-record-workflow.js";
export type { StageNode } from "./hooks/use-record-workflow.js";
export { RecordWorkflowStepper } from "./components/record-workflow-stepper.js";
export { RecordWorkflowActions } from "./components/record-workflow-actions.js";
export { RecordProgressHistory } from "./components/record-progress-history.js";
export { WorkflowSidePanel } from "./components/workflow-side-panel.js";
export { RecordWorkflowPanel } from "./components/record-workflow-panel.js";
export { buildWorkflowSession } from "./lib/workflow-session.js";
export { WorkflowBindingConfig } from "./types.js";
