"use client";
// Record detail with embedded workflow section (WFL-33, design-audit
// 2026-07-17 top gap #1 — "the single most important composition of the
// reference"). Composes the three storied-but-unmounted @dbp/ui workflow
// primitives around the existing useRecordWorkflow binding hook:
//   VerticalStageTracker  — full stage rail (deriveStagesFromWorkflowInstance)
//   WorkflowStatusSummary — current step / SLA / owner / next-action panel
//   RecordProgressHistory — the workflow-binding activity-timeline equivalent
// This is the "record-detail" seam alongside RecordWorkflowStepper (Pattern A,
// horizontal) and WorkflowSidePanel (Pattern B, subprocess) — a third,
// full-page pattern for a record whose whole page IS the workflow.
import * as React from "react";
import { Alert, Skeleton, VerticalStageTracker, WorkflowStatusSummary, deriveStagesFromWorkflowInstance } from "@dbp/ui";
import { useRecordWorkflow } from "../hooks/use-record-workflow.js";
import { RecordProgressHistory } from "./record-progress-history.js";
import { RecordWorkflowActions } from "./record-workflow-actions.js";
import type { WorkflowBindingConfig } from "../types.js";

export function RecordWorkflowPanel({
  recordId,
  config,
}: {
  recordId: string;
  config: WorkflowBindingConfig;
}) {
  const wf = useRecordWorkflow(recordId, config);

  if (wf.error) {
    return (
      <Alert tone="danger" title="Failed to load workflow" data-testid="record-workflow-panel-error">
        {wf.error.message}
      </Alert>
    );
  }

  if (wf.loading) {
    return (
      <div className="flex flex-col gap-3" data-testid="record-workflow-panel-skeleton" aria-busy="true">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!wf.instance || !wf.definition) {
    return (
      <div className="flex flex-col gap-3" data-testid="record-workflow-panel-empty">
        <p className="text-sm text-[var(--color-text-muted)]">
          No workflow started for this record yet.
        </p>
        <div className="flex gap-2">
          <RecordWorkflowActions recordId={recordId} config={config} />
        </div>
      </div>
    );
  }

  const stages = deriveStagesFromWorkflowInstance(wf.instance, wf.definition);

  return (
    <div className="flex flex-col gap-5" data-testid="record-workflow-panel">
      <WorkflowStatusSummary
        instance={wf.instance}
        variant="header"
        workflowName={wf.definition.name}
      />

      <div className="flex flex-wrap gap-2" data-testid="record-workflow-panel-actions">
        <RecordWorkflowActions recordId={recordId} config={config} />
      </div>

      <div>
        <h3 className="dq-overline mb-2">Stages</h3>
        <VerticalStageTracker stages={stages} />
      </div>

      <div>
        <h3 className="dq-overline mb-2">History</h3>
        <RecordProgressHistory recordId={recordId} config={config} />
      </div>
    </div>
  );
}
