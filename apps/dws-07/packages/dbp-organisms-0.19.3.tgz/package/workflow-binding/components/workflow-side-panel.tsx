"use client";
// Pattern B — right side panel with compact stepper (EntityList detail popups
// and subprocess-child entry points).
import * as React from "react";
import { Button } from "@dbp/ui";
import { StepIndicator } from "@dbp/organisms/lve-workspace";
import { useRecordWorkflow, walkStages } from "../hooks/use-record-workflow.js";
import { STEP_VARS } from "../lib/step-vars.js";
import type { WorkflowBindingConfig } from "../types.js";

export function WorkflowSidePanel({
  recordId,
  config,
  onClose,
}: {
  recordId: string;
  config: WorkflowBindingConfig;
  onClose: () => void;
}) {
  const wf = useRecordWorkflow(recordId, config);
  const child = wf.childInstance;
  const childDef = wf.childDefinition;

  return (
    <div
      className="fixed inset-y-0 right-0 z-50 flex w-[480px] max-w-full flex-col gap-4 border-l border-[var(--color-border-default)] bg-[var(--color-surface-content)] p-6 shadow-xl"
      style={STEP_VARS}
      data-testid="workflow-side-panel"
    >
      <div className="flex items-start justify-between">
        <span className="text-xs font-semibold uppercase tracking-[0.12em] text-[var(--color-text-muted)]">
          Workflow · {childDef?.name ?? "Sub-process"}
        </span>
        <Button aria-label="Close" variant="ghost" onClick={onClose}
          className="h-auto w-auto p-1 text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)]" data-testid="side-panel-close">
          ✕
        </Button>
      </div>

      {child && childDef ? (
        <>
          <div style={{ transform: "scale(0.9)", transformOrigin: "top left" }}>
            <StepIndicator
              steps={walkStages(childDef, child).steps.map((s) => ({ label: s.label }))}
              currentStep={walkStages(childDef, child).currentIndex}
            />
          </div>
          <div>
            <div className="text-base font-semibold text-[var(--color-text-primary)]">
              {String(childDef.name)}
            </div>
            <div className="mt-1 text-sm text-[var(--color-text-muted)]" data-testid="side-panel-step">
              {child.terminal
                ? `Completed — ${child.status}`
                : `Current step: ${childDef.steps.find((s) => s.id === child.currentStepId)?.name ?? child.currentStepId} · ${child.assigneeRoles.join(", ")}`}
            </div>
          </div>
          {wf.notice ? <div className="text-xs text-[var(--color-text-muted)]">{wf.notice}</div> : null}
          {!child.terminal &&
          child.assigneeRoles.some((role) => wf.user?.roles.includes(role)) ? (
            <div className="mt-auto flex flex-col gap-2">
              {child.allowedActions.includes("advance") ? (
                <Button variant="navy" loading={wf.busy} onClick={() => wf.advance(child)} data-testid="child-approve-button">
                  Approve
                </Button>
              ) : null}
              {child.allowedActions.includes("reject") ? (
                <Button variant="outline" className="text-[var(--color-danger)]" loading={wf.busy}
                  onClick={() => wf.reject(child)} data-testid="child-reject-button">
                  Reject
                </Button>
              ) : null}
            </div>
          ) : null}
        </>
      ) : (
        <div className="text-sm text-[var(--color-text-muted)]" data-testid="side-panel-empty">
          The sub-process instance has not been created yet — refresh in a moment.
        </div>
      )}
    </div>
  );
}
