"use client";
// Progress History tab (detailExtras.extraTab / Pattern B panel body).
// Subtle vertical timeline: hairline rail, small dots — escalations in accent
// tone, grouped ×N; prose entries "<actor> <action> <step>". Never big
// numbered circles, never inline under the stepper (§5b.2).
//
// Engine transition history (instance.steps) — the chunk-consistent source of
// "who did what when" in demo mode (the PS.AUDIT bridge writes land in the
// workflow route chunk's in-memory store and are invisible to the audit API
// chunk until PS.AUDIT persistence lands — known platform gap).
import * as React from "react";
import { Alert, Skeleton } from "@dbp/ui";
import { useRecordWorkflow } from "../hooks/use-record-workflow.js";
import type { WorkflowBindingConfig } from "../types.js";
import type { WorkflowInstanceView } from "@dbp/ps-workflow/client";

type HistoryRow = {
  kind: "transition" | "escalation";
  label: string;
  detail: string;
  count: number;
  firstTs: string;
  lastTs: string;
};

function groupHistory(steps: WorkflowInstanceView["steps"]): HistoryRow[] {
  const rows: HistoryRow[] = [];
  for (const entry of steps) {
    const isTimer = String(entry.action) === "timer-fired";
    const escalate = (entry as { escalateToRoles?: string[] }).escalateToRoles;
    const kind = isTimer ? "escalation" : "transition";
    const label = isTimer ? "escalated" : String(entry.action);
    const detail = isTimer
      ? `${entry.stepId} · SLA breach → ${escalate?.join(", ") ?? "applied"}`
      : `${entry.stepId} · ${entry.actor?.userId ?? "system"}`;
    const prev = rows[rows.length - 1];
    if (prev && prev.kind === "escalation" && kind === "escalation" && prev.detail === detail) {
      prev.count += 1;
      prev.lastTs = entry.ts;
    } else {
      rows.push({ kind, label, detail, count: 1, firstTs: entry.ts, lastTs: entry.ts });
    }
  }
  return rows.reverse();
}

export function RecordProgressHistory({
  recordId,
  config,
}: {
  recordId: string;
  config: WorkflowBindingConfig;
}) {
  const wf = useRecordWorkflow(recordId, config);

  if (wf.error) {
    return (
      <div className="p-5">
        <Alert tone="danger" title="Failed to load workflow history" data-testid="workflow-history-error">
          {wf.error.message}
        </Alert>
      </div>
    );
  }

  if (wf.loading) {
    return (
      <div className="p-5 flex flex-col gap-3" data-testid="workflow-history-skeleton" aria-busy="true">
        <Skeleton className="h-6 w-full" />
        <Skeleton className="h-6 w-full" />
        <Skeleton className="h-6 w-2/3" />
      </div>
    );
  }

  if (!wf.instance || wf.instance.steps.length === 0) {
    return (
      <div className="p-5 text-sm text-[var(--color-text-muted)]" data-testid="workflow-history-empty">
        No workflow activity yet — start a workflow from the header actions.
      </div>
    );
  }
  const rows = groupHistory(wf.instance.steps);
  return (
    <div className="p-5" data-testid="workflow-history">
      <div className="flex flex-col">
        {rows.map((row, i) => {
          const isEscalation = row.kind === "escalation";
          const last = i === rows.length - 1;
          const [stepName, actorPart] = row.detail.split(" · ");
          return (
            <div key={i} className="flex gap-3">
              {/* Timeline rail: subtle dot + hairline connector */}
              <div className="flex w-4 flex-col items-center pt-1.5">
                <div
                  className="h-2 w-2 shrink-0 rounded-full"
                  style={{ background: isEscalation ? "var(--color-secondary)" : "var(--color-border-strong, var(--color-text-muted))" }}
                  aria-hidden
                />
                {!last ? (
                  <div className="w-px flex-1 min-h-[14px] mt-1" style={{ background: "var(--color-border-subtle)" }} aria-hidden />
                ) : null}
              </div>
              {/* Entry content */}
              <div className={last ? "pb-0" : "pb-4"}>
                <div className="text-sm text-[var(--color-text-primary)]">
                  {isEscalation ? (
                    <>
                      <span className="text-[var(--color-secondary)]">SLA escalated</span>
                      {row.count > 1 ? <span className="text-[var(--color-text-muted)]"> ×{row.count}</span> : null}
                      <span className="text-[var(--color-text-muted)]"> — {actorPart ?? row.detail} on </span>
                      <span className="font-medium">{stepName}</span>
                    </>
                  ) : (
                    <>
                      <span className="font-medium">{actorPart ?? "system"}</span>
                      <span className="text-[var(--color-text-muted)]"> {row.label}d </span>
                      <span className="font-medium">{stepName}</span>
                    </>
                  )}
                </div>
                <div className="mt-0.5 text-xs text-[var(--color-text-muted)]">
                  {row.count > 1
                    ? `${new Date(row.firstTs).toLocaleString()} – ${new Date(row.lastTs).toLocaleTimeString()}`
                    : new Date(row.lastTs).toLocaleString()}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
