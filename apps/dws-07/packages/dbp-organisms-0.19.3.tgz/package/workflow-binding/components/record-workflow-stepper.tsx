"use client";
// Pattern A — full-width stepper for the LVE detailExtras `stepper` seam.
import * as React from "react";
import { Alert, Badge, Skeleton } from "@dbp/ui";
import { StepIndicator } from "@dbp/organisms/lve-workspace";
import { useRecordWorkflow, walkStages, slaDescription, escalated } from "../hooks/use-record-workflow.js";
import type { WorkflowBindingConfig } from "../types.js";

export function RecordWorkflowStepper({
  recordId,
  config,
}: {
  recordId: string;
  config: WorkflowBindingConfig;
}) {
  const wf = useRecordWorkflow(recordId, config);

  if (wf.error) {
    return (
      <Alert tone="danger" title="Failed to load workflow" data-testid="workflow-stepper-error">
        {wf.error.message}
      </Alert>
    );
  }

  if (wf.loading) {
    return (
      <div data-testid="workflow-stepper-skeleton" aria-busy="true" className="flex items-center gap-2">
        <Skeleton className="h-8 w-24" />
        <Skeleton className="h-8 w-24" />
        <Skeleton className="h-8 w-24" />
      </div>
    );
  }

  // Draw the bound instance's pinned definition; with no instance yet, preview
  // the default (first-declared) chain with every node upcoming.
  const drawDef = wf.definition ?? wf.definitions?.find((d) => d.id === config.definitionIds[0]);
  if (!drawDef) return null;
  const { steps, currentIndex } = walkStages(drawDef, wf.instance);

  return (
    <div data-testid="workflow-stepper">
      <StepIndicator
        steps={steps.map((s) => {
          const desc = slaDescription(wf.instance, s.id);
          return desc ? { label: s.label, description: desc } : { label: s.label };
        })}
        currentStep={currentIndex < 0 ? -1 : currentIndex}
      />
      {wf.instance ? (
        <div className="mt-2 flex items-center gap-2">
          <Badge
            tone={wf.instance.terminal ? (wf.instance.status === "completed" ? "success" : "danger") : "info"}
            data-testid="workflow-status-badge"
          >
            {wf.instance.terminal
              ? wf.instance.status === "completed"
                ? "Approved"
                : "Rejected"
              : `Workflow: ${drawDef.name}`}
          </Badge>
          {escalated(wf.instance) ? <Badge tone="orange" data-testid="workflow-escalated-badge">Escalated</Badge> : null}
          {wf.notice ? <span className="text-xs text-[var(--color-text-muted)]" data-testid="workflow-notice">{wf.notice}</span> : null}
        </div>
      ) : null}
    </div>
  );
}
