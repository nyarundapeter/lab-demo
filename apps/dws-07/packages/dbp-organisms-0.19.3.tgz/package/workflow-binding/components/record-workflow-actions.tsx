"use client";
// Header actions: Start workflow (per definitionId) / Approve / Reject, and
// the "View sub-process" entry point into Pattern B (WorkflowSidePanel).
// P1 §3.1 — plus an admin action group (Reassign / Force-advance / Cancel),
// gated on workflow:admin:<definitionId> (Sharavi's 2026-07-11 per-definition
// scoped ruling), rendered alongside the existing approve/reject buttons.
import * as React from "react";
import {
  Button,
  Dialog,
  DialogBody,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  Input,
  Textarea,
} from "@dbp/ui";
import { useCan } from "@dbp/ps-rbac/client";
import type { WorkflowInstanceView } from "@dbp/ps-workflow/client";
import { useRecordWorkflow } from "../hooks/use-record-workflow.js";
import { WorkflowSidePanel } from "./workflow-side-panel.js";
import type { WorkflowBindingConfig } from "../types.js";

type AdminActionKind = "reassign" | "force-advance" | "cancel";

function AdminActionGroup({
  instance,
  onReassign,
  onForceAdvance,
  onCancel,
  busy,
}: {
  instance: WorkflowInstanceView;
  onReassign: (targetUserId: string, comment?: string) => Promise<unknown>;
  onForceAdvance: (comment: string) => Promise<unknown>;
  onCancel: (comment: string) => Promise<unknown>;
  busy: boolean;
}) {
  const [open, setOpen] = React.useState<AdminActionKind | null>(null);
  const [targetUserId, setTargetUserId] = React.useState("");
  const [comment, setComment] = React.useState("");

  const close = () => {
    setOpen(null);
    setTargetUserId("");
    setComment("");
  };

  const confirm = async () => {
    if (open === "reassign") await onReassign(targetUserId, comment || undefined);
    else if (open === "force-advance") await onForceAdvance(comment);
    else if (open === "cancel") await onCancel(comment);
    close();
  };

  const commentRequired = open === "force-advance" || open === "cancel";
  const canConfirm =
    open === "reassign" ? targetUserId.trim().length > 0 : comment.trim().length > 0;

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        className="h-7 px-3 text-xs"
        onClick={() => setOpen("reassign")}
        data-testid="admin-reassign-button"
      >
        Reassign
      </Button>
      <Button
        size="sm"
        variant="outline"
        className="h-7 px-3 text-xs"
        onClick={() => setOpen("force-advance")}
        data-testid="admin-force-advance-button"
      >
        Force-advance
      </Button>
      <Button
        size="sm"
        variant="outline"
        className="h-7 px-3 text-xs text-[var(--color-danger)]"
        onClick={() => setOpen("cancel")}
        data-testid="admin-cancel-button"
      >
        Cancel workflow
      </Button>

      <Dialog open={open !== null} onOpenChange={(next) => (!next ? close() : undefined)}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>
              {open === "reassign"
                ? "Reassign step"
                : open === "force-advance"
                  ? "Force-advance step"
                  : "Cancel workflow"}
            </DialogTitle>
            <DialogDescription>
              {open === "reassign"
                ? `Reassign the current step (${instance.currentStepId ?? ""}) to a specific user.`
                : "Admin action — recorded in the instance history with your comment."}
            </DialogDescription>
          </DialogHeader>
          <DialogBody className="space-y-3">
            {open === "reassign" ? (
              <Input
                placeholder="Target user id"
                value={targetUserId}
                onChange={(e) => setTargetUserId(e.target.value)}
                data-testid="admin-reassign-target-input"
              />
            ) : null}
            <Textarea
              placeholder={commentRequired ? "Comment (required)" : "Comment (optional)"}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              data-testid="admin-action-comment-input"
            />
          </DialogBody>
          <DialogFooter>
            <Button size="sm" variant="outline" onClick={close}>
              Cancel
            </Button>
            <Button
              size="sm"
              variant="navy"
              loading={busy}
              disabled={!canConfirm}
              onClick={confirm}
              data-testid="admin-action-confirm-button"
            >
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

export function RecordWorkflowActions({
  recordId,
  config,
}: {
  recordId: string;
  config: WorkflowBindingConfig;
}) {
  const wf = useRecordWorkflow(recordId, config);
  const [panelOpen, setPanelOpen] = React.useState(false);
  // Hooks run unconditionally, ahead of any early return below (rules of
  // hooks) — definitionId is undefined until an instance exists, in which
  // case useCan resolves to false (no ability data to match against).
  const isAdmin = useCan(`workflow:admin:${wf.instance?.definitionId ?? ""}`);

  if (wf.loading || !wf.user) return null;

  if (!wf.instance) {
    return (
      <>
        {config.definitionIds.map((definitionId, i) => (
          <Button
            key={definitionId}
            size="sm"
            variant={i === 0 ? "navy" : "outline"}
            className="h-7 px-3 text-xs"
            loading={wf.busy}
            onClick={() => wf.start(definitionId)}
            data-testid={`start-${definitionId}-button`}
          >
            Start {definitionId}
          </Button>
        ))}
      </>
    );
  }

  if (wf.instance.terminal) return null;

  const instance = wf.instance;
  const adminGroup = isAdmin ? (
    <AdminActionGroup
      instance={instance}
      busy={wf.busy}
      onReassign={(targetUserId, comment) => wf.reassign(instance, targetUserId, comment)}
      onForceAdvance={(comment) => wf.forceAdvance(instance, comment)}
      onCancel={(comment) => wf.cancelInstance(instance, comment)}
    />
  ) : null;

  const currentStep = wf.definition?.steps.find((s) => s.id === instance.currentStepId);
  const waitingOnSubprocess = currentStep?.type === "subprocess";

  if (waitingOnSubprocess) {
    return (
      <>
        <Button size="sm" variant="outline" className="h-7 px-3 text-xs"
          onClick={() => setPanelOpen(true)} data-testid="view-subprocess-button">
          View sub-process
        </Button>
        {panelOpen ? (
          <WorkflowSidePanel recordId={recordId} config={config} onClose={() => setPanelOpen(false)} />
        ) : null}
        {adminGroup}
      </>
    );
  }

  const canAct = instance.assigneeRoles.some((role) => wf.user!.roles.includes(role));
  if (!canAct) return adminGroup;

  const canAdvance = instance.allowedActions.includes("advance");
  const canReject = instance.allowedActions.includes("reject");
  return (
    <>
      {canAdvance ? (
        <Button size="sm" variant="navy" className="h-7 px-3 text-xs" loading={wf.busy}
          onClick={() => wf.advance(instance)} data-testid="approve-button">
          Approve
        </Button>
      ) : null}
      {canReject ? (
        <Button size="sm" variant="outline" className="h-7 px-3 text-xs text-[var(--color-danger)]" loading={wf.busy}
          onClick={() => wf.reject(instance)} data-testid="reject-button">
          Reject
        </Button>
      ) : null}
      {adminGroup}
    </>
  );
}
