"use client";
// useRecordWorkflow — binding hook composing the @dbp/ps-workflow client SDK
// per docs/01-Architecture/PS-WORKFLOW-UI-Patterns.md §5. Generalized from
// apps/wfd-01 solution/components/record-workflow.tsx: definitionIds and
// entityType are supplied by the caller (manifest-declared binding) instead
// of a hardcoded RECORD_DEFINITIONS list / "purchase-request" literal.
import * as React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@dbp/ps-auth/client";
import {
  advanceInstance,
  cancelInstance,
  forceAdvance,
  getDefinition,
  getInstance,
  listInstances,
  reassignStep,
  rejectInstance,
  startWorkflow,
  WorkflowServiceError,
  type WorkflowDefinition,
  type WorkflowInstanceView,
} from "@dbp/ps-workflow/client";
import { buildWorkflowSession } from "../lib/workflow-session.js";
import type { WorkflowBindingConfig } from "../types.js";

function useWorkflowData(
  recordId: string,
  entityType: string,
  definitionIds: string[],
  childDefinitionIds: string[],
) {
  const allIds = React.useMemo(
    () => Array.from(new Set([...definitionIds, ...childDefinitionIds])),
    [definitionIds, childDefinitionIds],
  );
  const definitions = useQuery({
    queryKey: ["ps-workflow", "record-definitions", allIds],
    queryFn: () => Promise.all(allIds.map((id) => getDefinition(id))),
    staleTime: 60_000,
    enabled: allIds.length > 0,
  });
  const instances = useQuery({
    // ADR-0038 follow-up #4 / DB design addendum 2026-07-03: server-side
    // entityRecordId filter (indexed lookup) replaces the client-side
    // context.recordId match for the primary (non-child) definitions. Child
    // (subprocess) definition ids still list unfiltered — a subprocess
    // instance's own context does not carry the parent record's binding —
    // and are matched to their parent via parentInstanceId as before.
    queryKey: ["ps-workflow", "record-instances", allIds, recordId, entityType],
    queryFn: async () => {
      const primaryPages = await Promise.all(
        definitionIds.map((id) => listInstances({ definitionId: id, entityType, entityRecordId: recordId })),
      );
      const childPages = await Promise.all(
        childDefinitionIds.map((id) => listInstances({ definitionId: id })),
      );
      const rows = [...primaryPages, ...childPages].flatMap((p) => p.rows);
      // Fallback (pre-migration data): instances created before entity_type/
      // entity_record_id existed have neither column populated. Re-fetch
      // unfiltered and fall back to the legacy client-side context.recordId
      // match for rows the server-side filter didn't return.
      const matchedIds = new Set(rows.map((r) => r.workflowId));
      const needsFallback = definitionIds.some(
        (id) => !rows.some((r) => r.definitionId === id),
      );
      if (!needsFallback) return rows;
      const fallbackPages = await Promise.all(
        definitionIds.map((id) => listInstances({ definitionId: id })),
      );
      const fallbackRows = fallbackPages
        .flatMap((p) => p.rows)
        .filter((r) => !matchedIds.has(r.workflowId) && r.context["recordId"] === recordId);
      return [...rows, ...fallbackRows];
    },
    // Refetch keeps the stepper live and lets demo-mode lazy SLA breach
    // evaluation fire on read.
    refetchInterval: 5_000,
    enabled: allIds.length > 0,
  });
  return { definitions, instances };
}

export function useRecordWorkflow(recordId: string, config: WorkflowBindingConfig) {
  const { definitionIds, entityType } = config;
  const { user } = useAuth();
  const queryClient = useQueryClient();
  // Child (subprocess) definition ids are discovered lazily from loaded
  // definitions' subprocess steps; seed with none, then widen once known.
  const [childDefinitionIds, setChildDefinitionIds] = React.useState<string[]>([]);
  const { definitions, instances } = useWorkflowData(
    recordId,
    entityType,
    definitionIds,
    childDefinitionIds,
  );

  React.useEffect(() => {
    const found = new Set<string>();
    for (const def of definitions.data ?? []) {
      for (const step of def.steps) {
        const childId = (step as { definitionId?: string }).definitionId;
        if (step.type === "subprocess" && childId) found.add(childId);
      }
    }
    const next = Array.from(found);
    setChildDefinitionIds((prev) =>
      prev.length === next.length && prev.every((id, i) => id === next[i]) ? prev : next,
    );
  }, [definitions.data]);

  const [notice, setNotice] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);

  const listed = instances.data?.find(
    (row) =>
      definitionIds.includes(row.definitionId) &&
      (row.entityRecordId === recordId || row.context["recordId"] === recordId),
  );
  // Single-instance read: the list endpoint deliberately skips demo-mode lazy
  // SLA evaluation, so re-read the bound instance directly — this triggers any
  // due breach server-side and returns the freshest revision.
  const bound = useQuery({
    queryKey: ["ps-workflow", "instance", listed?.workflowId],
    queryFn: () => getInstance(listed!.workflowId),
    enabled: Boolean(listed),
    refetchInterval: 5_000,
  });
  const instance = (bound.data as WorkflowInstanceView | undefined) ?? listed;
  const definition = definitions.data?.find((d) => d.id === instance?.definitionId);
  const childInstance = instance
    ? instances.data?.find(
        (row) => childDefinitionIds.includes(row.definitionId) && row.parentInstanceId === instance.workflowId,
      )
    : undefined;
  const childDefinition = definitions.data?.find((d) => d.id === childInstance?.definitionId);

  const refresh = React.useCallback(
    () => queryClient.invalidateQueries({ queryKey: ["ps-workflow"] }),
    [queryClient],
  );

  const run = React.useCallback(
    async (fn: () => Promise<unknown>) => {
      setNotice(null);
      setBusy(true);
      try {
        await fn();
      } catch (err) {
        if (err instanceof WorkflowServiceError && err.status === 409) {
          setNotice("This record was updated — showing latest state.");
        } else {
          setNotice(err instanceof WorkflowServiceError ? err.message : "Workflow action failed.");
        }
      } finally {
        setBusy(false);
        await refresh();
      }
    },
    [refresh],
  );

  return {
    user,
    loading: definitions.isLoading || instances.isLoading,
    // DoD §6.1 — a fetch failure must surface, not render a silent blank.
    error: (definitions.error ?? instances.error) as Error | null,
    definitionIds,
    definitions: definitions.data,
    instance,
    definition,
    childInstance,
    childDefinition,
    notice,
    busy,
    // entityId/entityType in the context route the bridge's PS.AUDIT records to
    // the record itself, so the entity's Activity tab shows workflow actions.
    start: (definitionId: string) =>
      run(() =>
        startWorkflow(definitionId, {
          recordId,
          entityId: recordId,
          entityType,
        }),
      ),
    advance: (target: WorkflowInstanceView) => {
      if (!user) return Promise.resolve();
      const session = buildWorkflowSession(user);
      return run(() => advanceInstance(target.workflowId, {}, session));
    },
    reject: (target: WorkflowInstanceView) => {
      if (!user) return Promise.resolve();
      const session = buildWorkflowSession(user);
      return run(() => rejectInstance(target.workflowId, {}, session));
    },
    // P1 §3.1 — admin-gated operations, same run()/session shape as advance/reject.
    // Gating (workflow:admin:<definitionId>) is enforced server-side; the UI
    // only decides whether to render the affordance (RecordWorkflowActions).
    reassign: (target: WorkflowInstanceView, targetUserId: string, comment?: string) => {
      if (!user) return Promise.resolve();
      const session = buildWorkflowSession(user);
      return run(() =>
        reassignStep(target.workflowId, { targetUserId, ...(comment ? { comment } : {}) }, session),
      );
    },
    forceAdvance: (target: WorkflowInstanceView, comment: string) => {
      if (!user) return Promise.resolve();
      const session = buildWorkflowSession(user);
      return run(() => forceAdvance(target.workflowId, { comment }, session));
    },
    cancelInstance: (target: WorkflowInstanceView, comment: string) => {
      if (!user) return Promise.resolve();
      const session = buildWorkflowSession(user);
      return run(() => cancelInstance(target.workflowId, { comment }, session));
    },
  };
}

// ── Stage computation — walk the PINNED definition's primary chain ────────────

export type StageNode = { id: string; label: string; description?: string };

export function walkStages(
  definition: WorkflowDefinition,
  instance?: WorkflowInstanceView,
): { steps: StageNode[]; currentIndex: number } {
  const byId = new Map(definition.steps.map((s) => [s.id, s]));
  const steps: StageNode[] = [];
  let cursor: string | undefined = definition.initialStep;
  const seen = new Set<string>();
  while (cursor && !seen.has(cursor)) {
    seen.add(cursor);
    const step = byId.get(cursor);
    if (!step) break;
    steps.push({ id: step.id, label: step.name });
    cursor = step.type === "end" ? undefined : (step as { next?: string }).next;
  }
  // Rejected/cancelled terminal steps live off the primary chain — surface them
  // as the final node so the stepper shows where the instance actually ended.
  const currentStepId = instance?.currentStepId;
  if (currentStepId && !seen.has(currentStepId)) {
    const step = byId.get(currentStepId);
    if (step) steps.push({ id: step.id, label: step.name });
  }
  const currentIndex = instance ? steps.findIndex((s) => s.id === instance.currentStepId) : -1;
  // Terminal instances: mark every node completed by pointing past the end.
  return {
    steps,
    currentIndex: instance?.terminal ? steps.length : currentIndex,
  };
}

export function slaDescription(instance: WorkflowInstanceView | undefined, stepId: string): string | undefined {
  if (!instance || instance.currentStepId !== stepId || !instance.slaDueAt || instance.terminal) {
    return undefined;
  }
  const due = new Date(instance.slaDueAt).getTime();
  const diff = due - Date.now();
  if (diff <= 0) return "SLA overdue";
  const mins = Math.ceil(diff / 60_000);
  return `Due in ${mins} min`;
}

export function escalated(instance: WorkflowInstanceView | undefined): boolean {
  return Boolean(instance?.steps.some((s) => String(s.action) === "timer-fired"));
}
