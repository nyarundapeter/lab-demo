import { useQuery } from "@tanstack/react-query";
import { listAllEntities } from "@dbp/ps-data/client";
import type { KpiTargetMetric } from "../types.js";

export interface ReportMetricResult {
  value: number | null;
  /** True when the fetch succeeded but returned zero rows for this metric's period. */
  isEmpty: boolean;
  isLoading: boolean;
  error: Error | null;
}

/**
 * Fetches PS.DATA rows for one metric's entityType and aggregates client-side
 * (count/sum/avg) — the same pattern as chart-panel/kpi-scorecard's
 * `useChartData`/`useKpiData`. No server-side aggregate endpoint exists yet;
 * see FEATURE.md for the client-side aggregation limitation notice.
 */
export function useReportMetric(metric: KpiTargetMetric): ReportMetricResult {
  const query = useQuery({
    queryKey: ["ps-data", "all-entities", metric.entityType, metric.filters ?? {}],
    queryFn: () =>
      listAllEntities(metric.entityType, {
        ...(metric.filters !== undefined && { filters: metric.filters }),
      }),
  });

  const rows = query.data?.rows ?? [];
  const value = query.isLoading || query.isError ? null : aggregate(rows, metric);

  return {
    value,
    isEmpty: !query.isLoading && !query.isError && rows.length === 0,
    isLoading: query.isLoading,
    error: query.error as Error | null,
  };
}

function aggregate(
  rows: Array<{ data: unknown }>,
  metric: KpiTargetMetric,
): number {
  if (metric.aggregate === "count") return rows.length;

  const field = metric.field ?? "";
  const nums = rows.map((r) => {
    const v = (r.data as Record<string, unknown>)[field];
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  });

  if (nums.length === 0) return 0;
  const total = nums.reduce((acc, n) => acc + n, 0);
  return metric.aggregate === "sum" ? total : total / nums.length;
}
