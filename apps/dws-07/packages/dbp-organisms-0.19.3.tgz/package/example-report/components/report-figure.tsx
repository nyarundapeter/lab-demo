import * as React from "react";
import ChartPanel from "@dbp/organisms/chart-panel";
import type { ReportFigure } from "../types.js";

interface ReportFigureBlockProps {
  figure: ReportFigure;
}

/**
 * Wraps ANL.F02 (`ChartPanel`) with a figure number + caption, per
 * `dash-report.jsx`'s `RFigure`. Composes the existing chart organism
 * verbatim — no chart rendering logic is reimplemented here.
 */
export function ReportFigureBlock({ figure }: ReportFigureBlockProps) {
  return (
    <figure className="mb-5" data-testid={`report-figure-${figure.figure}`}>
      <div className="rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] p-4">
        <ChartPanel {...figure.config} />
      </div>
      <figcaption className="mt-1.5 text-xs italic text-[var(--color-text-muted)]">
        <strong className="font-semibold not-italic text-[var(--color-text-primary)]">
          Figure {figure.figure}.
        </strong>{" "}
        {figure.caption}
      </figcaption>
    </figure>
  );
}
