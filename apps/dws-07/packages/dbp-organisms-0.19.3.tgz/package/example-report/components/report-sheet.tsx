import * as React from "react";

interface ReportSheetProps {
  reportTitle: string;
  periodLabel: string;
  page: number;
  total: number;
  generatedAt: string;
  dataFrozenAt: string;
  children: React.ReactNode;
}

/**
 * Fixed-width "sheet" with a running header and footer (page number,
 * generated/frozen timestamps) — the document-shell chrome that makes a
 * report visually distinct from a live dashboard, per `dash-report.jsx`'s
 * `RSheet`. See FEATURE.md — this is presentational only, not a print
 * pagination implementation (deferred).
 */
export function ReportSheet({
  reportTitle,
  periodLabel,
  page,
  total,
  generatedAt,
  dataFrozenAt,
  children,
}: ReportSheetProps) {
  return (
    <div
      data-testid="report-sheet"
      className="mx-auto mb-6 w-full max-w-3xl rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface)] px-10 py-8 shadow-sm"
    >
      <div className="mb-6 flex items-center justify-between border-b border-[var(--color-border-subtle)] pb-2 text-xs text-[var(--color-text-muted)]">
        <span>{reportTitle}</span>
        <span>{periodLabel}</span>
      </div>

      {children}

      <div className="mt-7 flex items-center justify-between border-t border-[var(--color-border-subtle)] pt-2 text-xs text-[var(--color-text-muted)]">
        <span>
          Generated {formatStamp(generatedAt)} · Data frozen as of {formatStamp(dataFrozenAt)}
        </span>
        <span data-testid="report-sheet-page">
          Page {page} of {total}
        </span>
      </div>
    </div>
  );
}

function formatStamp(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
