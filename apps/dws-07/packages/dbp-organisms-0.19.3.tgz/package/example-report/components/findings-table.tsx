import * as React from "react";
import { Badge, SectionLabel } from "@dbp/ui";
import type { ReportFinding } from "../types.js";

interface FindingsTableProps {
  findings: ReportFinding[];
}

const PRIORITY_TONE = {
  high: "danger",
  medium: "warning",
  low: "neutral",
} as const;

const PRIORITY_LABEL = {
  high: "High",
  medium: "Medium",
  low: "Low",
} as const;

/** Static, authored exceptions/recommendations table — per FEATURE.md, not PS.DATA-derived. */
export function FindingsTable({ findings }: FindingsTableProps) {
  if (findings.length === 0) return null;

  return (
    <table className="w-full border-collapse text-left text-xs" data-testid="findings-table">
      <thead>
        <tr className="border-b border-[var(--color-border-subtle)]">
          <SectionLabel as="th" size="2xs" className="pb-2 pr-4 font-mono text-left">Issue</SectionLabel>
          <SectionLabel as="th" size="2xs" className="pb-2 pr-4 font-mono text-left">Recommendation</SectionLabel>
          <SectionLabel as="th" size="2xs" className="pb-2 pr-4 font-mono text-left">Owner</SectionLabel>
          <SectionLabel as="th" size="2xs" className="pb-2 font-mono text-left">Priority</SectionLabel>
        </tr>
      </thead>
      <tbody>
        {findings.map((f, i) => (
          <tr key={i} className="border-b border-[var(--color-border-subtle)] last:border-0">
            <td className="py-2 pr-4 font-medium">{f.issue}</td>
            <td className="py-2 pr-4 text-[var(--color-text-muted)]">{f.recommendation}</td>
            <td className="py-2 pr-4">{f.owner}</td>
            <td className="py-2">
              <Badge tone={PRIORITY_TONE[f.priority]}>{PRIORITY_LABEL[f.priority]}</Badge>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
