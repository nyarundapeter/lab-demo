import * as React from "react";
import { Badge, formatNumber } from "@dbp/ui";
import type { KpiTargetMetric } from "../types.js";
import { useReportMetric } from "../hooks/use-report-metric.js";

interface KpiTargetRowProps {
  metric: KpiTargetMetric;
}

/**
 * One row of the KPI-vs-target table: fetches + aggregates its own PS.DATA
 * value (error/loading isolated per row, same isolation contract as
 * kpi-scorecard's tiles), then derives variance + good/warn/bad status
 * client-side from `metric.target`/`metric.direction`.
 */
export function KpiTargetRow({ metric }: KpiTargetRowProps) {
  const { value, isEmpty, isLoading, error } = useReportMetric(metric);

  if (isEmpty) {
    return (
      <tr data-testid={`kpi-target-row-${metric.id}`} data-state="empty">
        <td className="py-2 pr-4 font-medium">{metric.label}</td>
        <td colSpan={4} className="py-2 text-[var(--color-text-muted)]">
          No data recorded for this period — check the reporting period or data source.
        </td>
      </tr>
    );
  }

  if (isLoading) {
    return (
      <tr data-testid={`kpi-target-row-${metric.id}`} data-state="loading">
        <td className="py-2 pr-4 font-medium">{metric.label}</td>
        <td colSpan={4} className="py-2 text-[var(--color-text-muted)]">Loading…</td>
      </tr>
    );
  }

  if (error || value === null) {
    return (
      <tr data-testid={`kpi-target-row-${metric.id}`} data-state="error">
        <td className="py-2 pr-4 font-medium">{metric.label}</td>
        <td colSpan={4} className="py-2 text-[var(--color-danger-text)]">Failed to load</td>
      </tr>
    );
  }

  const formatted = `${formatNumber(value, { compact: Math.abs(value) >= 10_000 })}${metric.unit}`;
  const hasTarget = metric.target !== undefined;
  const status = !hasTarget
    ? "neutral"
    : metric.direction === "higher-is-better"
      ? value >= (metric.target as number) ? "good" : "bad"
      : value <= (metric.target as number) ? "good" : "bad";

  const variance = hasTarget ? value - (metric.target as number) : null;
  const varianceLabel =
    variance === null ? "—" : `${variance >= 0 ? "+" : ""}${formatNumber(variance, { compact: Math.abs(variance) >= 10_000 })}${metric.unit}`;

  const tone = status === "good" ? "success" : status === "bad" ? "danger" : "neutral";
  const statusLabel = status === "good" ? "On target" : status === "bad" ? "Off target" : "—";

  return (
    <tr data-testid={`kpi-target-row-${metric.id}`} data-state="loaded">
      <td className="py-2 pr-4 font-medium">{metric.label}</td>
      <td className="py-2 pr-4 text-right tabular-nums">{formatted}</td>
      <td className="py-2 pr-4 text-right tabular-nums text-[var(--color-text-muted)]">
        {hasTarget ? `${formatNumber(metric.target as number)}${metric.unit}` : "—"}
      </td>
      <td className="py-2 pr-4 text-right tabular-nums">{varianceLabel}</td>
      <td className="py-2">
        <Badge tone={tone}>{statusLabel}</Badge>
      </td>
    </tr>
  );
}
