import { z } from "zod";
import { ChartPanelConfig } from "@dbp/organisms/chart-panel";

// ─── Cover / period ─────────────────────────────────────────────────────────────

const ReportPeriodSchema = z.object({
  label: z.string().min(1),
  start: z.string().min(1),
  end: z.string().min(1),
});
export type ReportPeriod = z.infer<typeof ReportPeriodSchema>;

// ─── KPI-vs-target metric ───────────────────────────────────────────────────────

const KpiTargetMetricSchema = z
  .object({
    /** Stable identifier — used as React key and for error isolation. */
    id: z.string().min(1),
    label: z.string().min(1),
    /** PS.DATA entity type this metric queries. */
    entityType: z.string().min(1),
    /** Entity data field to aggregate. Required for sum/avg; omitted only for count. */
    field: z.string().optional(),
    aggregate: z.enum(["count", "sum", "avg"]),
    /** Target value shown in the "Target" column and used to compute variance/status. */
    target: z.number().optional(),
    /** Unit suffix appended to displayed values, e.g. "%", "h". Default "". */
    unit: z.string().default(""),
    /**
     * Semantic direction used to colour the status column.
     * "higher-is-better" (default) → actual >= target is "good".
     * "lower-is-better" → actual <= target is "good".
     */
    direction: z.enum(["higher-is-better", "lower-is-better"]).default("higher-is-better"),
    filters: z
      .record(z.string(), z.union([z.string(), z.number(), z.boolean()]))
      .optional(),
  })
  .superRefine((val, ctx) => {
    if (val.aggregate !== "count" && !val.field) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `field is required when aggregate is "${val.aggregate}"`,
        path: ["field"],
      });
    }
  });
export type KpiTargetMetric = z.infer<typeof KpiTargetMetricSchema>;

// ─── Figures (charts) ───────────────────────────────────────────────────────────

const ReportFigureSchema = z.object({
  figure: z.number().int().min(1),
  caption: z.string().min(1),
  /** Verbatim ANL.F02 config — the report does not define its own chart shape. */
  config: ChartPanelConfig,
});
export type ReportFigure = z.infer<typeof ReportFigureSchema>;

// ─── Findings / exceptions ──────────────────────────────────────────────────────

const ReportFindingSchema = z.object({
  issue: z.string().min(1),
  recommendation: z.string().min(1),
  owner: z.string().min(1),
  priority: z.enum(["high", "medium", "low"]),
});
export type ReportFinding = z.infer<typeof ReportFindingSchema>;

// ─── Summary narrative ───────────────────────────────────────────────────────────

const ReportSummarySchema = z.object({
  paragraphs: z.array(z.string().min(1)).min(1),
  keyFindings: z.array(z.string().min(1)).default([]),
});
export type ReportSummary = z.infer<typeof ReportSummarySchema>;

// ─── Top-level config ───────────────────────────────────────────────────────────

/**
 * ExampleReportConfig — the single typed contract for ANL.F06.
 *
 * DATA contract only (no function fields — Zod schemas are data-only).
 * `metrics` and `charts[].config` are PS.DATA-bound; `summary`, `findings`, and
 * `methodologyNotes` are authored narrative content (analyst judgement), not
 * derived aggregation. See FEATURE.md.
 */
export const ExampleReportConfig = z.object({
  title: z.string().min(1),
  subtitle: z.string().optional(),
  period: ReportPeriodSchema,
  preparedFor: z.string().optional(),
  preparedBy: z.string().optional(),
  summary: ReportSummarySchema,
  metrics: z.array(KpiTargetMetricSchema).min(1).max(8),
  charts: z.array(ReportFigureSchema).max(6).default([]),
  findings: z.array(ReportFindingSchema).default([]),
  methodologyNotes: z.array(z.string().min(1)).default([]),
  /** ISO 8601 timestamp — "data frozen as of" in the sheet footer. */
  dataFrozenAt: z.string().min(1),
  /** ISO 8601 timestamp — "generated" in the sheet footer. Defaults to render time. */
  generatedAt: z.string().optional(),
});
export type ExampleReportConfig = z.infer<typeof ExampleReportConfig>;
