import * as React from "react";
import { z } from "zod";
import { Alert, Badge, Button, SectionLabel } from "@dbp/ui";
import { ExampleReportConfig } from "./types.js";
import { ReportSheet } from "./components/report-sheet.js";
import { KpiTargetRow } from "./components/kpi-target-row.js";
import { ReportFigureBlock } from "./components/report-figure.js";
import { FindingsTable } from "./components/findings-table.js";

type ConfigInput = z.input<typeof ExampleReportConfig>;

/**
 * ANL.F06 — Example Report
 *
 * A frozen, paginated document surface (cover + exec summary, KPI-vs-target
 * table, chart figures, findings, methodology notes) — the "new surface
 * class" ruled 2026-07-16 to belong in the showcase app / generated apps,
 * distinct from the live `analytics-dashboard` compositions (`ANL.F01`).
 *
 * Receives CONFIG, never data. `metrics` and `charts[].config` are PS.DATA-
 * bound (client-side aggregation, same limitation as ANL.F02/F03); `summary`,
 * `findings`, and `methodologyNotes` are authored narrative content. See
 * FEATURE.md and the spec at
 * docs/03-features/specs/organism-example-report-spec-2026-07-17.md.
 *
 * Config is validated at render time via ExampleReportConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 */
export default function ExampleReport(rawConfig: ConfigInput) {
  const parseResult = ExampleReportConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="ExampleReport configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <ExampleReportInner config={parseResult.data} />;
}

export type {
  ExampleReportConfig,
  ReportPeriod,
  KpiTargetMetric,
  ReportFigure,
  ReportFinding,
  ReportSummary,
} from "./types.js";

// ─── Inner component (config guaranteed valid) ────────────────────────────────

interface ExampleReportInnerProps {
  config: ExampleReportConfig;
}

function ExampleReportInner({ config }: ExampleReportInnerProps) {
  const {
    title,
    subtitle,
    period,
    preparedFor,
    preparedBy,
    summary,
    metrics,
    charts,
    findings,
    methodologyNotes,
    dataFrozenAt,
  } = config;

  const generatedAt = config.generatedAt ?? new Date().toISOString();
  const totalPages = 1 + (charts.length > 0 ? 1 : 0) + (findings.length > 0 || methodologyNotes.length > 0 ? 1 : 0);

  return (
    <div data-testid="example-report" className="w-full">
      {/* toolbar — a report is generated/exported, not interacted with */}
      <div className="mx-auto mb-4 flex max-w-3xl flex-wrap items-center gap-2">
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold">{title}</div>
          {subtitle && <div className="text-xs text-[var(--color-text-muted)]">{subtitle}</div>}
        </div>
        <Badge tone="neutral">Static · periodic</Badge>
        <Button
          variant="outline"
          size="sm"
          disabled
          title="Export deferred — see FEATURE.md"
          className="h-auto px-2.5 py-1 text-xs"
          data-testid="download-pdf"
        >
          Download PDF
        </Button>
        <Button
          variant="outline"
          size="sm"
          disabled
          title="Scheduling deferred — see FEATURE.md"
          className="h-auto px-2.5 py-1 text-xs"
          data-testid="schedule-report"
        >
          Schedule
        </Button>
      </div>

      {/* Sheet 1 — cover + executive summary */}
      <ReportSheet
        reportTitle={title}
        periodLabel={period.label}
        page={1}
        total={totalPages}
        generatedAt={generatedAt}
        dataFrozenAt={dataFrozenAt}
      >
        <div className="mb-6 border-b-2 border-[var(--color-primary)] pb-5">
          <h1 className="text-2xl font-bold leading-tight tracking-tight">{title}</h1>
          <div className="mt-2 flex flex-wrap gap-x-7 gap-y-1 text-xs">
            <Meta label="Reporting period" value={`${period.start} – ${period.end}`} />
            {preparedFor && <Meta label="Prepared for" value={preparedFor} />}
            {preparedBy && <Meta label="Prepared by" value={preparedBy} />}
          </div>
        </div>

        <h2 className="mb-2 text-base font-semibold">Executive summary</h2>
        <div className="flex flex-col gap-2.5 text-sm leading-relaxed">
          {summary.paragraphs.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>

        {summary.keyFindings.length > 0 && (
          <div className="mt-5 rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-subtle)] p-3.5">
            <div className="mb-2 text-xs font-semibold">Key findings</div>
            <ul className="flex list-disc flex-col gap-1.5 pl-4 text-xs leading-relaxed">
              {summary.keyFindings.map((f, i) => (
                <li key={i}>{f}</li>
              ))}
            </ul>
          </div>
        )}
      </ReportSheet>

      {/* Sheet 2 — KPI-vs-target table + figures */}
      {(metrics.length > 0 || charts.length > 0) && (
        <ReportSheet
          reportTitle={title}
          periodLabel={period.label}
          page={2}
          total={totalPages}
          generatedAt={generatedAt}
          dataFrozenAt={dataFrozenAt}
        >
          <h2 className="mb-3 text-base font-semibold">1 · Performance summary</h2>
          <table className="mb-6 w-full border-collapse text-left text-xs" data-testid="kpi-target-table">
            <thead>
              <tr className="border-b border-[var(--color-border-subtle)]">
                <SectionLabel as="th" size="2xs" className="pb-2 pr-4 font-mono text-left">Metric</SectionLabel>
                <SectionLabel as="th" size="2xs" className="pb-2 pr-4 font-mono text-right">Actual</SectionLabel>
                <SectionLabel as="th" size="2xs" className="pb-2 pr-4 font-mono text-right">Target</SectionLabel>
                <SectionLabel as="th" size="2xs" className="pb-2 pr-4 font-mono text-right">Variance</SectionLabel>
                <SectionLabel as="th" size="2xs" className="pb-2 font-mono text-left">Status</SectionLabel>
              </tr>
            </thead>
            <tbody>
              {metrics.map((m) => (
                <KpiTargetRow key={m.id} metric={m} />
              ))}
            </tbody>
          </table>

          {charts.length > 0 && <h2 className="mb-3 text-base font-semibold">2 · Trends</h2>}
          {charts.map((fig) => (
            <ReportFigureBlock key={fig.figure} figure={fig} />
          ))}
        </ReportSheet>
      )}

      {/* Sheet 3 — findings + methodology */}
      {(findings.length > 0 || methodologyNotes.length > 0) && (
        <ReportSheet
          reportTitle={title}
          periodLabel={period.label}
          page={totalPages}
          total={totalPages}
          generatedAt={generatedAt}
          dataFrozenAt={dataFrozenAt}
        >
          {findings.length > 0 && (
            <>
              <h2 className="mb-3 text-base font-semibold">3 · Exceptions &amp; recommendations</h2>
              <div className="mb-6">
                <FindingsTable findings={findings} />
              </div>
            </>
          )}

          {methodologyNotes.length > 0 && (
            <div className="border-t border-[var(--color-border-subtle)] pt-4">
              <div className="mb-2 text-xs font-semibold">Methodology &amp; notes</div>
              <ul className="flex list-disc flex-col gap-1.5 pl-4 text-xs leading-relaxed text-[var(--color-text-muted)]">
                {methodologyNotes.map((n, i) => (
                  <li key={i}>{n}</li>
                ))}
              </ul>
            </div>
          )}
        </ReportSheet>
      )}
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-xs text-[var(--color-text-muted)]">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
