# @dbp/organisms/example-report

**registryId:** `ANL.F06`

Frozen, paginated document surface — cover + exec summary, KPI-vs-target table,
chart figures (via `@dbp/organisms/chart-panel`), findings, and methodology notes.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ExampleReportConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `analytics-dashboard` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/example-report` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
