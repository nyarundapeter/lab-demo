import { z } from "zod";

export const MfaChallengeConfig = z.object({
  /** The signed-in-but-not-yet-verified user's email, shown in the prompt copy. */
  email: z.string().email(),
});

export type MfaChallengeConfig = z.infer<typeof MfaChallengeConfig>;
export type MfaChallengeConfigInput = z.input<typeof MfaChallengeConfig>;
