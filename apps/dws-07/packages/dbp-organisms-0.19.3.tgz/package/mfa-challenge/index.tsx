import React from "react";
import { Shield, AlertTriangle } from "lucide-react";
import { Alert, Button, CodeInput, FormField, Input } from "@dbp/ui";
import { MfaChallengeConfig, type MfaChallengeConfigInput } from "./types.js";
import { verifyTotpCode, verifyBackupCode } from "./mock-mfa-client.js";

export type MfaChallengeProps = MfaChallengeConfigInput & {
  /** Called once the code (authenticator or backup) verifies successfully. */
  onVerified?: () => void;
};

/**
 * MFA challenge — segmented TOTP code entry at sign-in, with an optional
 * "trust this device" checkbox and a path to fall back to a backup code.
 * Port of `identity-mfa.jsx`'s `MfaChallenge`.
 *
 * **Not wired to a real service.** `packages/stack/platform-services/auth`
 * has zero TOTP/MFA/backup-code code (confirmed by grep) — both verify paths
 * call a typed mock client (`mock-mfa-client.ts`). Storybook-only until that
 * Layer-06 capability lands. See `wave3-build-plan.md`'s "Blocked-row build
 * policy" (Amendment A).
 */
export default function MfaChallenge(rawConfig: MfaChallengeProps) {
  const { onVerified, ...configInput } = rawConfig;
  const parsed = MfaChallengeConfig.safeParse(configInput);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="MfaChallenge — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <MfaChallengeInner config={parsed.data} onVerified={onVerified} />;
}

function MfaChallengeInner({ config, onVerified }: { config: MfaChallengeConfig; onVerified?: (() => void) | undefined }) {
  const [backup, setBackup] = React.useState(false);
  const [backupCode, setBackupCode] = React.useState("");
  const [trustDevice, setTrustDevice] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState(false);

  async function verifyTotp(code: string) {
    setBusy(true);
    const result = await verifyTotpCode(code);
    setBusy(false);
    setErr(!result.ok);
    if (result.ok) onVerified?.();
  }

  async function submitBackup() {
    setBusy(true);
    const result = await verifyBackupCode(backupCode);
    setBusy(false);
    setErr(!result.ok);
    if (result.ok) onVerified?.();
  }

  return (
    <div>
      <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-[var(--radius-button)] bg-[var(--color-primary-surface)]">
        <Shield size={20} className="text-primary" />
      </div>
      <h1 className="mb-2 text-xl font-semibold">Two-factor authentication</h1>

      {!backup ? (
        <>
          <p className="mb-4 text-sm text-[var(--color-text-muted)]">
            Enter the 6-digit code from your authenticator app for <strong>{config.email}</strong>.
          </p>
          <CodeInput autoFocus error={err} disabled={busy} onComplete={verifyTotp} />
          {err && (
            <div className="mt-2 flex items-center gap-1.5 text-xs font-medium text-danger">
              <AlertTriangle size={12} />
              That code didn&apos;t match. Try again.
            </div>
          )}
          <label className="my-4 flex cursor-pointer items-center gap-2 text-xs text-[var(--color-text-muted)]">
            <input
              type="checkbox"
              checked={trustDevice}
              onChange={() => setTrustDevice((t) => !t)}
            />
            Trust this device for 30 days
          </label>
          <Button type="button" className="w-full" disabled={busy}>
            {busy ? "Verifying…" : "Verify"}
          </Button>
          <Button type="button" variant="ghost" className="mt-2 w-full" onClick={() => setBackup(true)}>
            Use a backup code instead
          </Button>
        </>
      ) : (
        <>
          <p className="mb-4 text-sm text-[var(--color-text-muted)]">
            Enter one of the backup codes you saved when you set up two-factor authentication.
          </p>
          <FormField label="Backup code">
            <Input
              className="font-mono"
              placeholder="xxxx-xxxx"
              value={backupCode}
              onChange={(e) => setBackupCode(e.target.value)}
              autoFocus
            />
          </FormField>
          {err && (
            <div className="mt-2 flex items-center gap-1.5 text-xs font-medium text-danger">
              <AlertTriangle size={12} />
              That code didn&apos;t match. Try again.
            </div>
          )}
          <Button type="button" className="mt-4 w-full" disabled={busy || !backupCode} onClick={submitBackup}>
            {busy ? "Verifying…" : "Verify"}
          </Button>
          <Button type="button" variant="ghost" className="mt-2 w-full" onClick={() => setBackup(false)}>
            Use authenticator app instead
          </Button>
        </>
      )}
      <div className="mt-6 text-center text-xs text-[var(--color-text-muted)]">
        Lost access? Contact your admin
      </div>
    </div>
  );
}
