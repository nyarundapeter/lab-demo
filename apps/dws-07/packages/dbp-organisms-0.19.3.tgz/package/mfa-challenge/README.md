# @dbp/organisms/mfa-challenge

**registryId:** `APP.F65` (placeholder — assigned during central registration)

TOTP verification-code entry at sign-in, with a backup-code fallback. See `FEATURE.md` — **not
wired to a real service**, PS.AUTH has no MFA support yet.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`MfaChallengeConfig` — Zod schema exported from `types.ts` (source of truth). The default
export's prop type (`MfaChallengeProps`) adds an `onVerified` callback alongside the config.

## Consumed by
Not yet wired — Storybook-only until PS.AUTH MFA support exists.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/mfa-challenge` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
