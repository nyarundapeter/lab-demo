# @dbp/organisms/integration-catalogue

**registryId:** `APP.F45`

Connector catalogue grid + guided 7-step connection wizard. Reuses `StepNav` (@dbp/ui) for the
step rail and the shared `MappingRowList` molecule for the mapping-preview step — see
`FEATURE.md` for why `multi-step-form` isn't the right reuse target here.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`IntegrationCatalogueConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/integrations` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/integration-catalogue` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
