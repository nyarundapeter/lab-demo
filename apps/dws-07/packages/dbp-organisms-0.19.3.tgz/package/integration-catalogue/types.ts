import { z } from "zod";

const CatalogueConnector = z.object({
  name: z.string().min(1),
  category: z.string().min(1),
  /** CSS color for the connector's letter-mark tile. */
  color: z.string().min(1),
  /** Set when this connector already has a connected instance — drives "Available" vs status badge. */
  connectedStatus: z.string().optional(),
});

const MappingRow = z.object({
  source: z.string().min(1),
  target: z.string().min(1),
  transform: z.string().min(1),
});

export const AUTH_METHODS = [
  { value: "oauth", label: "OAuth 2.0 (recommended)" },
  { value: "apikey", label: "API key" },
  { value: "service", label: "Service account" },
  { value: "basic", label: "Basic authentication" },
  { value: "cert", label: "Certificate" },
  { value: "managed", label: "Managed identity" },
] as const;

export const IntegrationCatalogueConfig = z.object({
  connectors: z.array(CatalogueConnector).min(1),
  /** Mapping preview shown at the wizard's "Map data" step. */
  mappingPreview: z.array(MappingRow).default([]),
});

export type IntegrationCatalogueConfig = z.infer<typeof IntegrationCatalogueConfig>;
export type IntegrationCatalogueConfigInput = z.input<typeof IntegrationCatalogueConfig>;
