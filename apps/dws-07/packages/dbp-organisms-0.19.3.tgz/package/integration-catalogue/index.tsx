import React from "react";
import { Alert } from "@dbp/ui";
import { CatalogueGrid } from "./components/catalogue-grid.js";
import { IntegrationWizard } from "./components/integration-wizard.js";
import { IntegrationCatalogueConfig, type IntegrationCatalogueConfigInput } from "./types.js";

/**
 * Connector catalogue grid + guided 7-step connection wizard. Port of
 * admin-specimens2.jsx's `IntegrationsHub`/`IntegrationWizard`, combined
 * into one organism with local catalogue↔wizard view state (matches the
 * reference's own `view` state shape).
 */
export default function IntegrationCatalogue(config: IntegrationCatalogueConfigInput) {
  const parsed = IntegrationCatalogueConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="IntegrationCatalogue — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <IntegrationCatalogueInner config={parsed.data} />;
}

function IntegrationCatalogueInner({ config }: { config: IntegrationCatalogueConfig }) {
  const [view, setView] = React.useState<"catalogue" | "wizard">("catalogue");
  const [selectedConnector, setSelectedConnector] = React.useState<string>(config.connectors[0]?.name ?? "");

  if (view === "wizard") {
    return (
      <IntegrationWizard
        connectorName={selectedConnector}
        mappingPreview={config.mappingPreview}
        onDone={() => setView("catalogue")}
        onCancel={() => setView("catalogue")}
      />
    );
  }

  return (
    <CatalogueGrid
      connectors={config.connectors}
      onNewConnection={() => setView("wizard")}
      onSelectConnector={(name) => {
        setSelectedConnector(name);
        setView("wizard");
      }}
    />
  );
}
