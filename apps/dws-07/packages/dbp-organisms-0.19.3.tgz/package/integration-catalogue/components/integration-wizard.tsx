import React from "react";
import { CheckCircle2, ChevronLeft, ChevronRight, Power } from "lucide-react";
import {
  Alert,
  Button,
  Card,
  EmptyState,
  Input,
  MappingRowList,
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue,
  StepNav,
  type StepNavItem,
} from "@dbp/ui";
import { AUTH_METHODS, type IntegrationCatalogueConfig } from "../types.js";

const STEP_LABELS = ["Select", "Connect", "Authenticate", "Map data", "Test", "Review", "Activate"];

interface Props {
  connectorName: string;
  mappingPreview: IntegrationCatalogueConfig["mappingPreview"];
  onDone: () => void;
  onCancel: () => void;
}

/**
 * 7-step guided connector setup — port of admin-specimens2.jsx's
 * `IntegrationWizard`. Uses `StepNav` (@dbp/ui) for the step rail rather
 * than hand-rolling one, and the shared `MappingRowList` molecule for the
 * "Map data" step's field-mapping preview — both existing reuse, per the
 * tier audit's note to check `StepNav`/`multi-step-form` before building a
 * bespoke stepper. `multi-step-form` itself is form-field-schema-driven
 * (owns `form-builder`'s `FormDefinition` contract) and isn't a fit for
 * this wizard's free-form step content (auth method picker, mapping
 * preview, test-connection result) — `StepNav` alone is the right-sized
 * reuse.
 */
export function IntegrationWizard({ connectorName, mappingPreview, onDone, onCancel }: Props) {
  const [step, setStep] = React.useState(2);
  const [auth, setAuth] = React.useState("oauth");

  const steps: StepNavItem[] = STEP_LABELS.map((label, i) => ({
    id: String(i),
    label,
    state: i < step ? "done" : i === step ? "active" : "upcoming",
  }));

  return (
    <div className="mx-auto flex max-w-[860px] flex-col gap-4">
      <h2 className="text-lg font-semibold">New connection — {connectorName}</h2>

      <StepNav
        steps={steps}
        onStepClick={(id) => {
          const target = Number(id);
          if (target <= step) setStep(target);
        }}
      />

      <Card className="min-h-[260px] shadow-none">
        {step === 2 && (
          <div className="flex max-w-[480px] flex-col gap-3">
            <h3 className="text-sm font-semibold">Authentication</h3>
            <label className="flex flex-col gap-1 text-xs">
              <span className="font-medium text-text-secondary">Method</span>
              <Select value={auth} onValueChange={setAuth}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {AUTH_METHODS.map((m) => (
                    <SelectItem key={m.value} value={m.value}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
            {auth === "oauth" && (
              <Alert tone="info" title={`You'll be redirected to ${connectorName}`}>
                Sign in and authorise access. We never store your password — only a revocable token.
              </Alert>
            )}
            {auth === "apikey" && (
              <>
                <label className="flex flex-col gap-1 text-xs">
                  <span className="font-medium text-text-secondary">API key *</span>
                  <Input className="h-8 text-xs" type="password" placeholder="••••••••••••••••" />
                </label>
                <label className="flex flex-col gap-1 text-xs">
                  <span className="font-medium text-text-secondary">Endpoint *</span>
                  <Input className="h-8 text-xs" placeholder="https://api.example.com/v2" />
                </label>
              </>
            )}
            <Alert tone="warning" title="Secrets are write-once">
              Once saved, credentials are masked and can only be replaced, never viewed.
            </Alert>
          </div>
        )}

        {step === 3 && (
          <div className="flex flex-col gap-2">
            <h3 className="text-sm font-semibold">Map data</h3>
            <p className="text-xs text-text-muted">
              Preview of field mapping — full mapping interface available after activation.
            </p>
            <MappingRowList
              rows={mappingPreview.map((m) => ({ source: m.source, target: m.target, meta: m.transform }))}
            />
          </div>
        )}

        {step === 4 && (
          <div className="flex flex-col items-center gap-2 py-5 text-center">
            <div className="inline-flex items-center gap-2 text-sm font-medium text-[var(--color-success)]">
              <CheckCircle2 size={18} aria-hidden="true" />
              Connection test passed
            </div>
            <p className="text-xs text-text-muted">Authenticated · 7 objects readable · latency 84ms</p>
          </div>
        )}

        {![2, 3, 4].includes(step) && (
          <EmptyState
            headline={`Step: ${STEP_LABELS[step]}`}
            description={`Guided configuration for ${STEP_LABELS[step]?.toLowerCase()}.`}
          />
        )}
      </Card>

      <div className="flex gap-2">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <div className="flex-1" />
        {step > 0 && (
          <Button type="button" variant="outline" onClick={() => setStep(step - 1)}>
            <ChevronLeft size={14} />
            Back
          </Button>
        )}
        {step < STEP_LABELS.length - 1 ? (
          <Button type="button" onClick={() => setStep(step + 1)}>
            Continue
            <ChevronRight size={14} />
          </Button>
        ) : (
          <Button type="button" onClick={onDone}>
            <Power size={14} />
            Activate
          </Button>
        )}
      </div>
    </div>
  );
}
