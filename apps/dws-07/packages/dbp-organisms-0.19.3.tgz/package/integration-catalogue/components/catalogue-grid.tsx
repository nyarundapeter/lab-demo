import React from "react";
import { Plus, Search } from "lucide-react";
import { Badge, Button, Card, Input } from "@dbp/ui";
import type { IntegrationCatalogueConfig } from "../types.js";

interface Props {
  connectors: IntegrationCatalogueConfig["connectors"];
  onNewConnection: () => void;
  /** Called with the clicked connector's name — a connected connector opens its detail elsewhere, an unconnected one starts the wizard. */
  onSelectConnector: (name: string) => void;
}

/** Connector grid — port of admin-specimens2.jsx's `IntegrationsHub` catalogue view. */
export function CatalogueGrid({ connectors, onNewConnection, onSelectConnector }: Props) {
  const categories = Array.from(new Set(connectors.map((c) => c.category))).slice(0, 5);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Integration catalogue</h2>
          <p className="mt-1 text-xs text-text-muted">
            Browse available connectors and configure new connections through a guided setup.
          </p>
        </div>
        <Button type="button" size="sm" className="shrink-0" onClick={onNewConnection}>
          <Plus size={13} />
          New connection
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative w-[280px]">
          <Search size={13} className="absolute left-2 top-1/2 -translate-y-1/2 text-text-muted" aria-hidden="true" />
          <Input className="h-8 pl-7 text-xs" placeholder="Search connectors…" />
        </div>
        {categories.map((c) => (
          <Button
            type="button"
            key={c}
            variant="outline"
            className="h-auto rounded-pill border-border-default px-2.5 py-1 text-xs font-normal text-text-secondary hover:bg-[var(--color-neutral-surface)]"
          >
            {c}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {connectors.map((c) => (
          <Card
            key={c.name}
            className="flex cursor-pointer items-start gap-3 p-3.5 shadow-none"
            onClick={() => onSelectConnector(c.name)}
          >
            <span
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[8px] text-base font-bold text-white"
              style={{ background: c.color }}
            >
              {c.name.slice(0, 1)}
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-semibold">{c.name}</div>
              <div className="text-xs text-text-muted">{c.category}</div>
              <div className="mt-2">
                {c.connectedStatus ? (
                  <Badge tone="active">{c.connectedStatus}</Badge>
                ) : (
                  <Badge tone="gray">Available</Badge>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
