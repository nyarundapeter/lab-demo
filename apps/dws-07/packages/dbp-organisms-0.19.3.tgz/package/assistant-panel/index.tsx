import * as React from "react";
import { Send } from "lucide-react";
import { useAssistant } from "@dbp/ps-ai/client";
import { ScrollArea, Button, cn } from "@dbp/ui";
import type { AssistantPanelConfig } from "./types.js";

export type AssistantPanelProps = AssistantPanelConfig;

export function AssistantPanel({ context, title }: AssistantPanelProps) {
  const { ask, messages, streaming } = useAssistant(context);
  const [draft, setDraft] = React.useState("");
  const bottomRef = React.useRef<HTMLDivElement>(null);
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);

  React.useEffect(() => {
    if (bottomRef.current !== null) {
      const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      bottomRef.current.scrollIntoView({ behavior: prefersReduced ? "instant" : "smooth" });
    }
  }, [messages, streaming]);

  const handleSend = async () => {
    const text = draft.trim();
    if (text === "" || streaming) return;
    setDraft("");
    await ask(text);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full w-full" aria-label={title ?? "Assistant panel"}>
      {title && (
        <h2 className="text-sm font-semibold text-[var(--color-text)] px-3 pt-3 pb-1 shrink-0">
          {title}
        </h2>
      )}

      <ScrollArea className="flex-1 px-3">
        <div className="flex flex-col gap-2 py-2">
          {messages.length === 0 && (
            <p className="text-sm text-[var(--color-text)] opacity-50 text-center mt-4">
              Ask me anything…
            </p>
          )}

          {messages.map((msg, i) => (
            <div
              key={i}
              className={cn(
                "max-w-[85%] rounded-lg px-3 py-2 text-sm",
                msg.role === "user"
                  ? "self-end bg-[var(--color-primary)] text-white ml-auto"
                  : "self-start bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text)]",
              )}
              aria-label={`${msg.role === "user" ? "You" : "Assistant"}: ${msg.content}`}
            >
              <p className="whitespace-pre-wrap break-words">{msg.content}</p>
            </div>
          ))}

          {streaming && (
            <div
              className="self-start bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg px-3 py-2"
              aria-live="polite"
              aria-label="Assistant is typing"
            >
              <span className="flex gap-1 items-center" aria-hidden="true">
                <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-primary)] animate-bounce [animation-delay:0ms]" />
                <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-primary)] animate-bounce [animation-delay:150ms]" />
                <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-primary)] animate-bounce [animation-delay:300ms]" />
              </span>
            </div>
          )}

          <div ref={bottomRef} />
        </div>
      </ScrollArea>

      <div className="flex gap-2 items-end px-3 py-3 border-t border-[var(--color-border)] shrink-0">
        <textarea
          ref={textareaRef}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type a message… (Enter to send, Shift+Enter for newline)"
          rows={1}
          aria-label="Message input"
          aria-multiline="true"
          disabled={streaming}
          className={cn(
            "flex-1 resize-none rounded border border-[var(--color-border)]",
            "bg-[var(--color-surface)] text-sm text-[var(--color-text)]",
            "placeholder:text-[var(--color-text)] placeholder:opacity-50",
            "px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]",
            "disabled:opacity-50 min-h-[2.25rem] max-h-32 overflow-y-auto",
          )}
        />
        <Button
          size="icon"
          variant="orange"
          onClick={() => void handleSend()}
          disabled={draft.trim() === "" || streaming}
          aria-label="Send message"
          className="shrink-0"
        >
          <Send className="h-4 w-4" aria-hidden="true" />
        </Button>
      </div>
    </div>
  );
}

export type { AssistantPanelConfig } from "./types.js";

export { AssistantHeader } from "./assistant-header.js";
export type { AssistantHeaderProps } from "./assistant-header.js";

export { AssistantDrawer } from "./assistant-drawer.js";
export type { AssistantDrawerProps } from "./assistant-drawer.js";

export { AssistantInline } from "./assistant-inline.js";
export type { AssistantInlineProps } from "./assistant-inline.js";

export { AssistantFull } from "./assistant-full.js";
export type { AssistantFullProps } from "./assistant-full.js";
