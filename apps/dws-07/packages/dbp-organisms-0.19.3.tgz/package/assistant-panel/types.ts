import { z } from "zod";

// Config schema for the @dbp/organisms/assistant-panel organism. Promoted
// from packages/shared/ui/src/bindings (2026-07-21 Bindings/Admin
// resolution — it owns useAssistant()'s messages/streaming/ask state, so it
// is an organism, not a presentation-layer binding).
export const AssistantPanelConfig = z.object({
  context: z.record(z.unknown()).optional(),
  title: z.string().optional(),
});

export type AssistantPanelConfig = z.infer<typeof AssistantPanelConfig>;
