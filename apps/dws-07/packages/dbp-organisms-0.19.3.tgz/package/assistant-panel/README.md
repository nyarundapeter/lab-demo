# @dbp/organisms/assistant-panel

**registryId:** `APP.F16`

Embeddable AI conversation panel: message thread + composer, streaming indicator.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`AssistantPanelConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Bespoke import — mounted directly by callers embedding an AI conversation surface
(e.g. `@dbp/organisms/workbench-surface`'s assistant zone).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/assistant-panel` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
