# @dbp/organisms/notification-preference-matrix

**registryId:** `APP.F32`

Self-fetching type×channel PS.NOTIF preference matrix (mandatory/recommended/optional tiers, per-channel toggle).

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`NotificationPreferenceMatrixConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Bespoke import — `apps/dbp/solution/pages/NotificationSettings.tsx`.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/notification-preference-matrix` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
