"use client"

import * as React from "react"
import { NotificationTypeSchema } from "@dbp/contracts"
import {
  CHANNEL_STATUS,
  NOTIFICATION_TYPE_TIER,
  usePreferences,
  type NotificationChannel,
  type NotificationPreference,
  type NotificationPreferenceTier,
} from "@dbp/ps-notif/client"
import { cn, Badge, Switch } from "@dbp/ui"
import type { NotificationPreferenceMatrixConfig } from "./types.js"

/**
 * Type×channel preference matrix (NOT-22, reference `notif-prefs.jsx:11-76`).
 * Self-fetching organism — mirrors `AdminAccessMatrix`'s pattern (owns its own
 * `usePreferences` query/mutation, no prop plumbing required from callers).
 *
 * One row per notification type, one column per *implemented* channel
 * (`CHANNEL_STATUS` — sms is excluded, a toggle for a channel that can't
 * deliver would be a lie). Mandatory-tier rows render a locked, always-on
 * switch — this is a UI mirror of the server-side enforcement in
 * `resolveShouldSend`/`MandatoryTierOptOutError`, not the enforcement
 * itself; the server still rejects a mandatory opt-out even if this
 * component is bypassed.
 */

const TIER_LABEL: Record<NotificationPreferenceTier, string> = {
  mandatory: "Mandatory",
  recommended: "Recommended",
  optional: "Optional",
}

const TIER_TONE: Record<NotificationPreferenceTier, "critical" | "warning" | "gray"> = {
  mandatory: "critical",
  recommended: "warning",
  optional: "gray",
}

const CHANNEL_LABEL: Record<NotificationChannel, string> = {
  "in-app": "In-app",
  email: "Email",
  sms: "SMS",
}

const IMPLEMENTED_CHANNELS = (Object.keys(CHANNEL_STATUS) as NotificationChannel[]).filter(
  (channel) => CHANNEL_STATUS[channel] === "implemented",
)

export type NotificationPreferenceMatrixProps = NotificationPreferenceMatrixConfig;

export function NotificationPreferenceMatrix({ sessionHeader, className }: NotificationPreferenceMatrixProps) {
  const { items, setPreference, isLoading, isSaving } = usePreferences(sessionHeader)

  const byKey = React.useMemo(() => {
    const map = new Map<string, NotificationPreference>()
    for (const p of items) map.set(`${p.type}::${p.channel}`, p)
    return map
  }, [items])

  if (isLoading) {
    return <p className="text-sm text-[var(--color-text-muted)] py-6">Loading notification preferences…</p>
  }

  return (
    <div
      className={cn(
        "overflow-x-auto rounded-[var(--radius-card)] border border-[var(--color-border)]",
        className,
      )}
      data-testid="notification-preference-matrix"
    >
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-[var(--color-border)] bg-[var(--color-surface)]">
            <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
              Type
            </th>
            {IMPLEMENTED_CHANNELS.map((channel) => (
              <th
                key={channel}
                className="px-4 py-2.5 text-center text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]"
              >
                {CHANNEL_LABEL[channel]}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {NotificationTypeSchema.options.map((type, i) => {
            const tier = NOTIFICATION_TYPE_TIER[type]
            const isMandatory = tier === "mandatory"
            return (
              <tr
                key={type}
                className={cn(i > 0 && "border-t border-[var(--color-border)]")}
                data-testid={`notification-preference-row-${type}`}
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="font-medium capitalize text-[var(--color-text)]">{type}</span>
                    <Badge tone={TIER_TONE[tier]} size="sm">
                      {TIER_LABEL[tier]}
                    </Badge>
                  </div>
                </td>
                {IMPLEMENTED_CHANNELS.map((channel) => {
                  const stored = byKey.get(`${type}::${channel}`)
                  const optedIn = isMandatory ? true : (stored?.optedIn ?? true)
                  return (
                    <td key={channel} className="px-4 py-3 text-center">
                      <Switch
                        checked={optedIn}
                        disabled={isSaving || isMandatory}
                        onCheckedChange={(checked) => setPreference(type, checked, channel)}
                        aria-label={`${type} via ${CHANNEL_LABEL[channel]}${isMandatory ? " (mandatory, cannot be disabled)" : ""}`}
                        data-testid={`notification-preference-toggle-${type}-${channel}`}
                      />
                    </td>
                  )
                })}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export type { NotificationPreferenceMatrixConfig } from "./types.js";
