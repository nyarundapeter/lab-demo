import { z } from "zod";

// Config schema for the @dbp/organisms/notification-preference-matrix
// organism. Promoted from packages/shared/ui/src/components (2026-07-21
// Bindings/Admin resolution — it owns usePreferences()'s own query/mutation
// state, so it is an organism, not a design-system primitive).
export const NotificationPreferenceMatrixConfig = z.object({
  sessionHeader: z.string().optional(),
  className: z.string().optional(),
});

export type NotificationPreferenceMatrixConfig = z.infer<typeof NotificationPreferenceMatrixConfig>;
