# @dbp/organisms/session-expired

**registryId:** `APP.F74` (placeholder — assigned during central registration)

Re-authenticate-in-place interstitial. See `FEATURE.md` — built against the real
`@dbp/ps-auth/client` `login()` call, not mocked.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`SessionExpiredConfig` — Zod schema exported from `types.ts` (source of truth). The default
export's prop type (`SessionExpiredProps`) adds `onUnlocked`/`onSwitchUser` callbacks.

## Consumed by
Not yet wired — no page currently detects session expiry and mounts this overlay.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/session-expired` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
