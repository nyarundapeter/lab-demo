import { z } from "zod";

export const SessionExpiredConfig = z.object({
  /** The signed-out user's email, prefilled/shown in the re-auth prompt. */
  email: z.string().email(),
  /** The record/page the user was on, named so they know nothing was lost. */
  destinationLabel: z.string().min(1),
  /** Optional SSO fallback shown below the password field. Omit to hide it. */
  ssoLabel: z.string().min(1).optional(),
});

export type SessionExpiredConfig = z.infer<typeof SessionExpiredConfig>;
export type SessionExpiredConfigInput = z.input<typeof SessionExpiredConfig>;
