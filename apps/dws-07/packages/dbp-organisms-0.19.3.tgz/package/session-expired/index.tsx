import React from "react";
import { Clock } from "lucide-react";
import { Alert, Button, Card, FormField, PwField } from "@dbp/ui";
import { login, AuthRequestError } from "@dbp/ps-auth/client";
import { SessionExpiredConfig, type SessionExpiredConfigInput } from "./types.js";

export type SessionExpiredProps = SessionExpiredConfigInput & {
  /** Called once re-authentication succeeds. */
  onUnlocked?: () => void;
  /** Called if the user picks "Sign in as a different user" instead. */
  onSwitchUser?: () => void;
};

/**
 * Session-expired interstitial — dims the app in place, names the record
 * the user was on, and re-authenticates inline instead of dumping them at a
 * blank login page. Port of `identity-mfa.jsx`'s `SessionExpired`.
 *
 * **Built against the real PS.AUTH primitive** (not mocked) —
 * `packages/stack/platform-services/auth/client`'s `login()` mutation is a
 * fully real, working call (unlike MfaEnrol/MfaChallenge/TokensSection,
 * which are genuinely blocked on missing Layer-06 capabilities).
 */
export default function SessionExpired(rawConfig: SessionExpiredProps) {
  const { onUnlocked, onSwitchUser, ...configInput } = rawConfig;
  const parsed = SessionExpiredConfig.safeParse(configInput);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="SessionExpired — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <SessionExpiredInner config={parsed.data} onUnlocked={onUnlocked} onSwitchUser={onSwitchUser} />;
}

function SessionExpiredInner({
  config,
  onUnlocked,
  onSwitchUser,
}: {
  config: SessionExpiredConfig;
  onUnlocked?: (() => void) | undefined;
  onSwitchUser?: (() => void) | undefined;
}) {
  const [password, setPassword] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function unlock(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login({ email: config.email, password });
      onUnlocked?.();
    } catch (err) {
      setError(err instanceof AuthRequestError ? err.message : "Couldn't sign you back in. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex h-full items-center justify-center overflow-hidden bg-[color-mix(in_srgb,var(--color-primary)_40%,transparent)] p-5">
      <Card className="w-full max-w-[400px] shadow-[0_20px_50px_rgba(0,0,0,0.25)]">
        <div className="p-6">
          <div className="mb-3.5 flex items-center gap-2.5">
            <span className="flex h-[38px] w-[38px] items-center justify-center rounded-[var(--radius-button)] bg-[var(--color-warning-surface)]">
              <Clock size={19} className="text-[var(--color-warning-text)]" />
            </span>
            <div>
              <div className="text-base font-semibold">Your session expired</div>
              <div className="text-xs text-[var(--color-text-muted)]">Signed in as {config.email}</div>
            </div>
          </div>
          <Alert tone="info">
            We saved your place. Sign back in to return to <strong>{config.destinationLabel}</strong>.
          </Alert>
          <form onSubmit={unlock} className="mt-4 flex flex-col gap-3">
            <FormField label="Password">
              <PwField
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
                required
              />
            </FormField>
            {error && (
              <p role="alert" className="text-xs text-danger">
                {error}
              </p>
            )}
            <Button type="submit" className="w-full" disabled={busy || !password}>
              {busy ? "Unlocking…" : "Unlock & continue"}
            </Button>
            {config.ssoLabel && (
              <>
                <div className="flex items-center gap-2 text-xs text-[var(--color-text-muted)]">
                  <span className="h-px flex-1 bg-[var(--color-border-subtle)]" />
                  or
                  <span className="h-px flex-1 bg-[var(--color-border-subtle)]" />
                </div>
                <Button type="button" variant="outline" className="w-full">
                  Continue with {config.ssoLabel}
                </Button>
              </>
            )}
          </form>
          <div className="mt-3.5 text-center">
            <Button
              type="button"
              variant="link"
              onClick={onSwitchUser}
              className="h-auto text-xs text-[var(--color-text-muted)] underline-offset-2"
            >
              Sign in as a different user
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
