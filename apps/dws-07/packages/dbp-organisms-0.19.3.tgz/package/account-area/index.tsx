import React from "react";
import { Alert, AvatarLockup, Tabs, TabsContent, TabsList, TabsTrigger } from "@dbp/ui";
import { AccountAreaConfig, type AccountAreaConfigInput } from "./types.js";
import SecuritySection from "../security-section/index.js";
import TokensSection from "../tokens-section/index.js";

/**
 * Account area — tabbed settings surface behind the top-bar avatar.
 * Template-tier composition of `SecuritySection` + `TokensSection` (Profile
 * and Connected-identities tabs are out of this build's scope — see
 * `FEATURE.md`). Port of `identity-account.jsx`'s `AccountArea`.
 *
 * Lighter than the organisms it composes: no config-error alert of its own
 * beyond validating the shape that feeds those two organisms, no owned
 * business state besides which tab is active.
 */
export default function AccountArea(config: AccountAreaConfigInput) {
  const parsed = AccountAreaConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="AccountArea — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <AccountAreaInner config={parsed.data} />;
}

function AccountAreaInner({ config }: { config: AccountAreaConfig }) {
  const [tab, setTab] = React.useState(config.initialTab);

  return (
    <div className="py-1">
      <div className="mb-5">
        <AvatarLockup
          name={config.memberName}
          role={config.memberTitle ? `${config.memberEmail} · ${config.memberTitle}` : config.memberEmail}
          size="lg"
        />
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="tokens">API tokens</TabsTrigger>
        </TabsList>
        <TabsContent value="security" className="mt-6">
          <SecuritySection {...config.security} />
        </TabsContent>
        <TabsContent value="tokens" className="mt-6">
          <TokensSection {...config.tokens} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
