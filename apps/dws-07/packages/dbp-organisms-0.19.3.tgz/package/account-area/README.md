# @dbp/organisms/account-area

**registryId:** `APP.F52` (placeholder — assigned during central registration)

Tabbed account settings surface. See `FEATURE.md` — Template tier, composes `SecuritySection` +
`TokensSection` only (Profile/Connected identities out of scope for this build).

**Tier:** Template

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`AccountAreaConfig` — Zod schema exported from `types.ts` (source of truth). Nests
`SecuritySectionConfig` and `TokensSectionConfig` from the sibling organisms.

## Consumed by
Not yet wired — depends on both composed organisms' PS.AUTH gaps closing before a live route.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/account-area` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
