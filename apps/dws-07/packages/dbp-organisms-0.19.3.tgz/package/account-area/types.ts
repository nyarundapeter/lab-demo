import { z } from "zod";
import { SecuritySectionConfig } from "../security-section/types.js";
import { TokensSectionConfig } from "../tokens-section/types.js";

export const AccountAreaConfig = z.object({
  memberName: z.string().min(1),
  memberEmail: z.string().email(),
  memberTitle: z.string().optional(),
  initialTab: z.enum(["security", "tokens"]).default("security"),
  security: SecuritySectionConfig,
  tokens: TokensSectionConfig,
});

export type AccountAreaConfig = z.infer<typeof AccountAreaConfig>;
export type AccountAreaConfigInput = z.input<typeof AccountAreaConfig>;
