import { useEntityList } from "@dbp/ps-data/client";
import { useSearch } from "@dbp/ps-search/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { CatalogGridConfig } from "../types.js";

export interface CatalogGridDataResult {
  rows: EntityRecord<EntityData>[];
  total: number;
  page: number;
  pageSize: number;
  isLoading: boolean;
  error: Error | null;
}

/**
 * Wires PS.DATA (useEntityList) and, when a search query is active, PS.SEARCH (useSearch).
 *
 * PS.SEARCH interplay:
 * - Empty query → pure PS.DATA fetch with static filters and pagination.
 * - Non-empty query → useSearch fires; its result IDs are used as an `id` filter on
 *   PS.DATA so that full entity fields are available for all configured card slots.
 *   Pagination is locked to page=1 and pageSize=100 while a search is active.
 */
export function useCatalogGridData(
  config: CatalogGridConfig,
  page: number,
  searchQuery: string,
): CatalogGridDataResult {
  const isSearchActive = searchQuery.trim().length > 0;

  const { results: searchHits, loading: searchLoading } = useSearch(
    searchQuery,
    { entityType: config.entityType },
  );

  const dataFilters = isSearchActive
    ? { ...config.filters, id: searchHits.map((h) => h.id).join(",") }
    : config.filters;

  const dataOptions = isSearchActive
    ? { ...(dataFilters !== undefined && { filters: dataFilters }), page: 1, pageSize: 100 }
    : { ...(dataFilters !== undefined && { filters: dataFilters }), page, pageSize: config.pageSize };

  // Skip the PS.DATA fetch while the search is still loading
  const skipDataFetch = isSearchActive && searchLoading;

  const {
    rows,
    total,
    page: resultPage,
    pageSize: resultPageSize,
    isLoading: dataLoading,
    error,
  } = useEntityList(config.entityType, skipDataFetch ? { page: 1, pageSize: 1 } : dataOptions);

  return {
    rows: skipDataFetch ? [] : rows,
    total: skipDataFetch ? 0 : total,
    page: resultPage,
    pageSize: resultPageSize,
    isLoading: dataLoading || searchLoading,
    error: error as Error | null,
  };
}
