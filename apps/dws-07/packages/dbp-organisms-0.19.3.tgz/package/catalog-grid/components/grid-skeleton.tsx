import * as React from "react";
import { Skeleton, Grid, Col } from "@dbp/ui";

interface GridSkeletonProps {
  count?: number;
}

/** Loading skeleton: ghost card grid while data is fetching. */
export function GridSkeleton({ count = 6 }: GridSkeletonProps) {
  return (
    <Grid role="status" aria-label="Loading">
      {Array.from({ length: count }).map((_, i) => (
        <Col
          key={i}
          span={6}
          xl={4}
          className="flex flex-col gap-3 rounded-card border border-[var(--color-border-default)] bg-[var(--color-surface-content)] p-6 shadow-sm"
        >
          {/* Header row: type chip + status chip */}
          <div className="flex items-center gap-2">
            <Skeleton className="h-5 w-20 rounded" />
            <Skeleton className="h-5 w-14 rounded" />
          </div>
          {/* Meta line */}
          <Skeleton className="h-3 w-24 rounded" />
          {/* Title */}
          <Skeleton className="h-5 w-3/4 rounded" />
          {/* Description lines */}
          <Skeleton className="h-3 w-full rounded" />
          <Skeleton className="h-3 w-5/6 rounded" />
          {/* Footer */}
          <Skeleton className="mt-2 h-3 w-28 rounded" />
        </Col>
      ))}
    </Grid>
  );
}
