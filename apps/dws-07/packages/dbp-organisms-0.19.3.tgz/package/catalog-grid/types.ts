import { z } from "zod";

/**
 * Category tab — drives the tab strip above the grid.
 * id "all" is reserved and auto-inserted as the first tab.
 */
export const CategorySchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
});
export type Category = z.infer<typeof CategorySchema>;

/**
 * CardFields — maps entity data fields to CatalogCard slots.
 * All fields are string keys into the entity's data object.
 */
export const CardFieldsSchema = z.object({
  /** Entity field that becomes card title (required). */
  title: z.string().min(1),
  /** Entity field for the card description body. */
  description: z.string().optional(),
  /** Entity field for the mono type chip (e.g. "G · KNOWLEDGE"). */
  typeLabel: z.string().optional(),
  /** Entity field for the status chip label (e.g. "EFFECTIVE"). */
  status: z.string().optional(),
  /**
   * Literal tone for the status chip — not read from entity data.
   * Defaults to "gray".
   */
  statusTone: z
    .enum(["success", "warning", "danger", "info", "orange", "navy", "gray"])
    .optional(),
  /** Entity field for the footer asset-ID mono line (e.g. "KNO-001"). */
  footerId: z.string().optional(),
  /**
   * Entity field for the mono meta line above the title (e.g. "5 MIN · EFFECTIVE").
   * Distinct from footerId — leave unset to avoid duplicating the footer asset-ID
   * above the title. Only set when there is genuinely separate meta content.
   */
  metaLine: z.string().optional(),
  /**
   * Entity field whose value is a comma-separated tag string or string[].
   * Rendered as Badge chips inside the card (media variant tags slot).
   * Not used by the catalog variant — kept for possible future extension.
   */
  tags: z.string().optional(),
});
export type CardFields = z.infer<typeof CardFieldsSchema>;

/**
 * FilterField — one checkbox group in the sticky filter panel.
 */
export const FilterFieldSchema = z.object({
  /** The entity data field this facet filters on. */
  field: z.string().min(1),
  /** Human-readable label for the checkbox group heading. */
  label: z.string().min(1),
});
export type FilterField = z.infer<typeof FilterFieldSchema>;

/**
 * CatalogGridConfig — the single typed contract for APP.F10.
 *
 * DATA contract only — no function fields. Callbacks and event handling are
 * via DOM CustomEvents (dbp:catalog:item-select) and optional onCardClick prop.
 */
export const CatalogGridConfig = z.object({
  /** The PS.DATA entity type to list (e.g. "knowledge-asset", "service"). */
  entityType: z.string().min(1),

  /**
   * @deprecated — CatalogGrid is body-only. Pass title via shell PageHeader or
   * MeshSection above the component (single-header rule, ARCHETYPE-REFERENCE-SPEC §4.4).
   * Field is accepted (not stripped) for backwards-compat but is never rendered.
   */
  headline: z.string().min(1).optional(),

  /** @deprecated — see `headline`. Accepted but not rendered. */
  lede: z.string().optional(),

  /**
   * Plural noun used in the counter, e.g. "items" → "12 OF 24 ITEMS".
   * Defaults to "items".
   */
  itemLabel: z.string().default("items"),

  /**
   * Category tabs rendered above the card grid.
   * An "All" tab is prepended automatically.
   * Each category filters by matching the entity's categoryField value.
   */
  categories: z.array(CategorySchema).default([]),

  /**
   * The entity data field used to match category tab ids.
   * Required when categories.length > 0; ignored when empty.
   */
  categoryField: z.string().optional(),

  /** Maps entity data fields to CatalogCard presentation slots. */
  cardFields: CardFieldsSchema,

  /**
   * Facet checkboxes shown in the filter panel.
   * Each entry produces a checkbox group; unique values are read from the
   * current page of fetched data (client-side faceting on current page).
   */
  filterFields: z.array(FilterFieldSchema).default([]),

  /**
   * Optional "Recommended" toggle filter.
   * When provided, a special toggle appears at the top of the filter panel.
   * Filters items where entity.data[field] === true.
   */
  recommendedFilter: FilterFieldSchema.optional(),

  /** Number of items per page. Defaults to 12 (3-col × 4-row). */
  pageSize: z.number().int().min(1).max(200).default(12),

  /**
   * Static field-equality filters applied to every PS.DATA request.
   * Example: { published: true } — always shows only published items.
   */
  filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
});

export type CatalogGridConfig = z.infer<typeof CatalogGridConfig>;
