# @dbp/organisms/catalog-grid

**registryId:** `APP.F10`

Faceted card-grid catalogue with categories, search, and configurable filters.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`CatalogGridConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `collection-grid` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/catalog-grid` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
