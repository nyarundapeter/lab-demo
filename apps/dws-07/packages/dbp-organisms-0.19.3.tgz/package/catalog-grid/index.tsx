import * as React from "react";
import { useSearchParams } from "next/navigation";
import { LayoutGrid } from "lucide-react";
import {
  Alert,
  Badge,
  Button,
  CatalogCard,
  Checkbox,
  Col,
  EmptyState,
  FilterBar,
  formatNumber,
  Grid,
  Pagination,
  SectionLabel,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@dbp/ui";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import { CatalogGridConfig } from "./types.js";
import type { CatalogGridConfig as CatalogGridConfigType, FilterField } from "./types.js";
import { useCatalogGridData } from "./hooks/use-catalog-grid-data.js";
import { GridSkeleton } from "./components/grid-skeleton.js";

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Safely read a string-or-unknown field from entity data, returning "". */
function readField(data: Record<string, unknown>, field: string | undefined): string {
  if (!field) return "";
  const v = data[field];
  if (v === null || v === undefined) return "";
  return String(v);
}

/** Collect unique non-empty string values for a field across rows. */
function collectValues(rows: EntityRecord<EntityData>[], field: string): string[] {
  const seen = new Set<string>();
  for (const row of rows) {
    const v = readField(row.data as Record<string, unknown>, field);
    if (v) seen.add(v);
  }
  return Array.from(seen).sort();
}

// ─── Outer shell: config validation ──────────────────────────────────────────

type ConfigInput = Omit<CatalogGridConfigType, "pageSize" | "itemLabel" | "categories" | "filterFields"> &
  Partial<Pick<CatalogGridConfigType, "pageSize" | "itemLabel" | "categories" | "filterFields">>;

export interface CatalogGridProps extends ConfigInput {
  /**
   * Optional callback fired in addition to the dbp:catalog:item-select CustomEvent
   * when a card is clicked/activated.
   */
  onCardClick?: (entityType: string, id: string) => void;
}

/**
 * APP.F10 — Catalog Grid
 *
 * Marketplace listing surface: a configurable, paginated, filterable grid of
 * CatalogCard backed by PS.DATA (with optional PS.SEARCH for the search box).
 *
 * The config is validated at render time via CatalogGridConfig.safeParse.
 * An Alert is rendered (not thrown) on invalid config.
 */
export default function CatalogGrid({ onCardClick, ...rawConfig }: CatalogGridProps) {
  const parseResult = CatalogGridConfig.safeParse(rawConfig);
  if (!parseResult.success) {
    return (
      <Alert
        tone="danger"
        title="CatalogGrid configuration error"
        data-testid="config-error"
      >
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <React.Suspense fallback={null}>
      <CatalogGridInner config={parseResult.data} {...(onCardClick !== undefined && { onCardClick })} />
    </React.Suspense>
  );
}

// ─── Inner component (config is guaranteed valid here) ────────────────────────

interface CatalogGridInnerProps {
  config: CatalogGridConfigType;
  onCardClick?: (entityType: string, id: string) => void;
}

function CatalogGridInner({ config, onCardClick }: CatalogGridInnerProps) {
  const searchParams = useSearchParams();
  const [page, setPage] = React.useState(1);
  const [searchQuery, setSearchQuery] = React.useState(() => searchParams?.get("q") ?? "");
  // No "All" sub-marketplace tab — default to the first declared category (ruling:
  // "all is never a sub marketplace"). "" means no category tabs are configured.
  const [activeCategory, setActiveCategory] = React.useState(
    () => config.categories.find((c) => c.id.toLowerCase() !== "all")?.id ?? "",
  );
  const [showMobileFilters, setShowMobileFilters] = React.useState(false);
  // activeFilters: field → Set of selected values
  const [activeFilters, setActiveFilters] = React.useState<Record<string, Set<string>>>({});
  const [recommendedOnly, setRecommendedOnly] = React.useState(false);

  const { rows, total, pageSize, isLoading, error } = useCatalogGridData(
    config,
    page,
    searchQuery,
  );

  // Reset page when search or category changes
  React.useEffect(() => {
    setPage(1);
  }, [searchQuery, activeCategory]);

  // ── Dispatch helper ───────────────────────────────────────────────────────
  const handleCardActivate = React.useCallback(
    (id: string) => {
      document.dispatchEvent(
        new CustomEvent("dbp:catalog:item-select", {
          detail: { entityType: config.entityType, id },
          bubbles: true,
        }),
      );
      onCardClick?.(config.entityType, id);
    },
    [config.entityType, onCardClick],
  );

  // ── Client-side filtering (category + facet checkboxes + recommended) ─────
  const displayRows = React.useMemo(() => {
    let filtered = rows;

    // Category tab filter
    if (activeCategory && config.categoryField) {
      filtered = filtered.filter(
        (row) =>
          readField(row.data as Record<string, unknown>, config.categoryField) === activeCategory,
      );
    }

    // Facet checkbox filters — each active field must match one of the selected values
    for (const [field, values] of Object.entries(activeFilters)) {
      if (values.size === 0) continue;
      filtered = filtered.filter((row) =>
        values.has(readField(row.data as Record<string, unknown>, field)),
      );
    }

    // Recommended toggle
    if (recommendedOnly && config.recommendedFilter) {
      const field = config.recommendedFilter.field;
      filtered = filtered.filter((row) => {
        const v = (row.data as Record<string, unknown>)[field];
        return v === true || v === "true" || v === 1;
      });
    }

    return filtered;
  }, [rows, activeCategory, config.categoryField, activeFilters, recommendedOnly, config.recommendedFilter]);

  // ── Filter toggle helper ──────────────────────────────────────────────────
  const toggleFilter = React.useCallback((field: string, value: string) => {
    setActiveFilters((prev) => {
      const current = new Set(prev[field] ?? []);
      if (current.has(value)) {
        current.delete(value);
      } else {
        current.add(value);
      }
      return { ...prev, [field]: current };
    });
  }, []);

  const clearAllFilters = React.useCallback(() => {
    setActiveFilters({});
    setRecommendedOnly(false);
  }, []);

  const activeFilterCount = React.useMemo(() => {
    let count = Object.values(activeFilters).reduce((sum, s) => sum + s.size, 0);
    if (recommendedOnly) count += 1;
    return count;
  }, [activeFilters, recommendedOnly]);

  // ── Filtered counter ──────────────────────────────────────────────────────
  const filteredCount = displayRows.length;
  // total is the full server-side count; for the counter we show filtered / total
  const counterTotal = searchQuery.trim() || activeFilterCount > 0 ? filteredCount : total;

  // itemLabel is already plural (e.g. "templates", "services") — just uppercase it.
  const itemLabelUpper = (config.itemLabel ?? "items").toUpperCase();

  // ── Tabs: declared categories only — no "All" sub-marketplace tab ──────────
  // Ruling: "all is never a sub marketplace". Any "all"-id category in config is
  // dropped rather than promoted to a tab.
  const tabs = React.useMemo(
    () => config.categories.filter((c) => c.id.toLowerCase() !== "all"),
    [config.categories],
  );

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col gap-5" data-testid="catalog-grid">

      {/* ── Search + counter row ──────────────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-3">
        <FilterBar
          searchValue={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder={`Search ${config.entityType}…`}
          data-testid="search-input"
        />

        {/* Mono N OF M ITEMS counter */}
        {!isLoading && !error && (
          <SectionLabel
            className="ml-auto font-mono tracking-[0.18em]"
            aria-live="polite"
            data-testid="item-counter"
          >
            {formatNumber(filteredCount)} OF {formatNumber(counterTotal)} {itemLabelUpper}
          </SectionLabel>
        )}
      </div>

      {/* ── Active filter chips ───────────────────────────────────────────── */}
      {activeFilterCount > 0 && (
        <div className="flex flex-wrap items-center gap-2" data-testid="active-filter-chips">
          <SectionLabel>
            Active filters:
          </SectionLabel>
          {config.recommendedFilter && recommendedOnly && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setRecommendedOnly(false)}
              className="h-auto gap-1.5 rounded-full bg-[var(--color-surface)] px-3 py-1 text-xs font-medium text-[var(--color-text-secondary)] hover:bg-[var(--color-navy-50)]"
              data-testid="active-filter-chip-recommended"
            >
              {config.recommendedFilter.label}
              <span aria-hidden="true">×</span>
            </Button>
          )}
          {Object.entries(activeFilters).flatMap(([field, values]) =>
            Array.from(values).map((value) => (
              <Button
                key={`${field}:${value}`}
                variant="ghost"
                size="sm"
                onClick={() => toggleFilter(field, value)}
                className="h-auto gap-1.5 rounded-full bg-[var(--color-surface)] px-3 py-1 text-xs font-medium text-[var(--color-text-secondary)] hover:bg-[var(--color-navy-50)]"
                data-testid={`active-filter-chip-${field}-${value}`}
              >
                {value}
                <span aria-hidden="true">×</span>
              </Button>
            )),
          )}
          <Button
            variant="link"
            onClick={clearAllFilters}
            className="h-auto font-mono text-xs uppercase tracking-wider text-secondary"
            data-testid="clear-filters-chips"
          >
            Clear all
          </Button>
        </div>
      )}

      {/* ── Category tabs ─────────────────────────────────────────────────── */}
      {tabs.length > 1 && (
        <Tabs
          value={activeCategory}
          onValueChange={(v) => setActiveCategory(v)}
        >
          <TabsList
            className="w-full justify-start gap-0 rounded-none border-b border-[var(--color-border-subtle)] bg-transparent p-0"
            data-testid="category-tabs"
          >
            {tabs.map((tab) => (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className={[
                  // Active underline is the @dbp/ui TabsTrigger built-in (::after);
                  // do NOT add a second border-b underline here (double-underline bug).
                  "relative rounded-none px-4 py-2.5 text-sm font-medium",
                  "text-[var(--color-text-muted)] transition-colors",
                  "data-[state=active]:text-secondary",
                  "hover:text-[var(--color-text-secondary)]",
                  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
                ].join(" ")}
              >
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {/* TabsContent: one per tab — all render the same body, driven by activeCategory state */}
          {tabs.map((tab) => (
            <TabsContent key={tab.id} value={tab.id} className="mt-0 pt-0">
              <CatalogGridBody
                config={config}
                rows={displayRows}
                total={total}
                page={page}
                pageSize={pageSize}
                isLoading={isLoading}
                error={error}
                activeFilters={activeFilters}
                activeFilterCount={activeFilterCount}
                recommendedOnly={recommendedOnly}
                showMobileFilters={showMobileFilters}
                onToggleFilter={toggleFilter}
                onToggleRecommended={() => setRecommendedOnly((v) => !v)}
                onClearAll={clearAllFilters}
                onToggleMobileFilters={() => setShowMobileFilters((v) => !v)}
                onPageChange={setPage}
                onCardActivate={handleCardActivate}
              />
            </TabsContent>
          ))}
        </Tabs>
      )}

      {/* ── No tabs: render body directly ────────────────────────────────── */}
      {tabs.length <= 1 && (
        <CatalogGridBody
          config={config}
          rows={displayRows}
          total={total}
          page={page}
          pageSize={pageSize}
          isLoading={isLoading}
          error={error}
          activeFilters={activeFilters}
          activeFilterCount={activeFilterCount}
          recommendedOnly={recommendedOnly}
          showMobileFilters={showMobileFilters}
          onToggleFilter={toggleFilter}
          onToggleRecommended={() => setRecommendedOnly((v) => !v)}
          onClearAll={clearAllFilters}
          onToggleMobileFilters={() => setShowMobileFilters((v) => !v)}
          onPageChange={setPage}
          onCardActivate={handleCardActivate}
        />
      )}
    </div>
  );
}

// ─── Body: filter panel + card grid + pagination ──────────────────────────────

interface CatalogGridBodyProps {
  config: CatalogGridConfigType;
  rows: EntityRecord<EntityData>[];
  total: number;
  page: number;
  pageSize: number;
  isLoading: boolean;
  error: Error | null;
  activeFilters: Record<string, Set<string>>;
  activeFilterCount: number;
  recommendedOnly: boolean;
  showMobileFilters: boolean;
  onToggleFilter: (field: string, value: string) => void;
  onToggleRecommended: () => void;
  onClearAll: () => void;
  onToggleMobileFilters: () => void;
  onPageChange: (page: number) => void;
  onCardActivate: (id: string) => void;
}

function CatalogGridBody({
  config,
  rows,
  total,
  page,
  pageSize,
  isLoading,
  error,
  activeFilters,
  activeFilterCount,
  recommendedOnly,
  showMobileFilters,
  onToggleFilter,
  onToggleRecommended,
  onClearAll,
  onToggleMobileFilters,
  onPageChange,
  onCardActivate,
}: CatalogGridBodyProps) {
  // Collect facet values from the current page of data (client-side faceting)
  const facetValues = React.useMemo(() => {
    const map: Record<string, string[]> = {};
    for (const ff of config.filterFields) {
      map[ff.field] = collectValues(rows, ff.field);
    }
    return map;
  }, [rows, config.filterFields]);

  const hasFilterPanel =
    config.filterFields.length > 0 || config.recommendedFilter !== undefined;

  // Shared filter panel content — used in both desktop aside and mobile collapsible.
  const filterPanelContent = hasFilterPanel ? (
    <>
      {/* Recommended toggle */}
      {config.recommendedFilter && (
        <div className="mb-4 border-b border-[var(--color-border-subtle)] pb-4">
          <SectionLabel as="p" size="2xs" className="mb-2">
            {config.recommendedFilter.label}
          </SectionLabel>
          <label className="flex cursor-pointer items-center gap-2">
            <Checkbox
              checked={recommendedOnly}
              onCheckedChange={onToggleRecommended}
              aria-label={`Show recommended ${config.entityType} only`}
              data-testid="recommended-toggle"
            />
            <span className="text-sm text-[var(--color-text-primary)]">Recommended</span>
          </label>
        </div>
      )}

      {/* Facet groups */}
      {config.filterFields.map((ff: FilterField) => (
        <FilterGroup
          key={ff.field}
          field={ff}
          values={facetValues[ff.field] ?? []}
          active={activeFilters[ff.field] ?? new Set()}
          onToggle={onToggleFilter}
        />
      ))}
    </>
  ) : null;

  return (
    <div className="mt-5" data-testid="catalog-body">
      {/* ── Mobile filter toggle row (hidden on md+) ─────────────────────── */}
      {hasFilterPanel && (
        <div className="mb-3 flex items-center gap-3 md:hidden">
          <Button
            variant="outline"
            size="sm"
            onClick={onToggleMobileFilters}
            className="h-auto gap-2 rounded-button px-3 py-1.5"
            data-testid="mobile-filter-toggle"
            aria-expanded={showMobileFilters}
          >
            Filters
            {activeFilterCount > 0 && (
              <Badge tone="orange" size="sm" data-testid="filter-count-badge-mobile">
                {activeFilterCount}
              </Badge>
            )}
          </Button>
          {activeFilterCount > 0 && (
            <Button
              variant="link"
              onClick={onClearAll}
              className="h-auto font-mono text-xs uppercase tracking-wider text-secondary"
              data-testid="clear-filters-mobile"
            >
              Clear all
            </Button>
          )}
        </div>
      )}

      {/* ── Mobile collapsible filter panel ──────────────────────────────── */}
      {hasFilterPanel && showMobileFilters && (
        <div
          className="mb-4 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-4 md:hidden"
          data-testid="mobile-filter-panel"
        >
          {filterPanelContent}
        </div>
      )}

      <div className="flex gap-6">
      {/* ── Desktop filter panel (hidden on mobile) ──────────────────────── */}
      {hasFilterPanel && (
        <aside
          className="hidden md:block sticky top-4 h-fit w-[220px] shrink-0 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface-2)] p-4"
          aria-label="Filters"
          data-testid="filter-panel"
        >
          {/* Panel heading + active count pill + clear button */}
          <div className="mb-4 flex items-center justify-between">
            <SectionLabel as="span" className="flex items-center gap-2 text-[var(--color-text-secondary)]">
              Filters
              {activeFilterCount > 0 && (
                <Badge tone="orange" size="sm" data-testid="filter-count-badge">
                  {activeFilterCount}
                </Badge>
              )}
            </SectionLabel>
            {activeFilterCount > 0 && (
              <Button
                variant="link"
                onClick={onClearAll}
                className="h-auto font-mono text-xs uppercase tracking-wider text-secondary"
                data-testid="clear-filters"
              >
                Clear All
              </Button>
            )}
          </div>
          {filterPanelContent}
        </aside>
      )}

      {/* ── Card grid ─────────────────────────────────────────────────────── */}
      <div className="min-w-0 flex-1" data-testid="card-grid-area">
        {isLoading ? (
          <GridSkeleton count={config.pageSize} />
        ) : error ? (
          <EmptyState
            tone="danger"
            headline="Failed to load catalog items"
            description={error.message}
            data-testid="error-state"
          />
        ) : rows.length === 0 ? (
          <EmptyState
            icon={<LayoutGrid size={22} strokeWidth={1.5} />}
            title={`No ${config.entityType} items found`}
            description="Try adjusting your search or filters."
            data-testid="empty-state"
          />
        ) : (
          <>
            <Grid data-testid="catalog-card-grid">
              {rows.map((row) => {
                const data = row.data as Record<string, unknown>;
                const cf = config.cardFields;
                const statusTone = cf.statusTone ?? "gray";

                const desc = cf.description ? readField(data, cf.description) : undefined;
                const typeL = cf.typeLabel ? readField(data, cf.typeLabel) : undefined;
                const statusL = cf.status ? readField(data, cf.status) : undefined;
                const metaL = cf.metaLine ? readField(data, cf.metaLine) : undefined;
                const footerIdV = cf.footerId ? readField(data, cf.footerId) : undefined;
                return (
                  <Col key={row.id} span={12} sm={6} lg={4}>
                  <CatalogCard
                    variant="catalog"
                    title={readField(data, cf.title) || row.id}
                    {...(desc !== undefined && { description: desc })}
                    {...(typeL !== undefined && { typeLabel: typeL })}
                    {...(statusL !== undefined && { statusLabel: statusL })}
                    statusTone={statusTone}
                    {...(metaL !== undefined && { metaLine: metaL })}
                    {...(footerIdV !== undefined && { footerId: footerIdV })}
                    onClick={() => onCardActivate(row.id)}
                    onOpen={() => onCardActivate(row.id)}
                    data-testid={`catalog-card-${row.id}`}
                  />
                  </Col>
                );
              })}
            </Grid>

            {/* Pagination */}
            <div className="mt-6 flex justify-end" data-testid="pager">
              <Pagination
                page={page}
                pageSize={pageSize}
                total={total}
                showCaption
                onPageChange={onPageChange}
              />
            </div>
          </>
        )}
      </div>
      </div>
    </div>
  );
}

// ─── FilterGroup sub-component ────────────────────────────────────────────────

interface FilterGroupProps {
  field: FilterField;
  values: string[];
  active: Set<string>;
  onToggle: (field: string, value: string) => void;
}

function FilterGroup({ field, values, active, onToggle }: FilterGroupProps) {
  if (values.length === 0) return null;

  return (
    <div className="mb-4 border-b border-[var(--color-border-subtle)] pb-4 last:mb-0 last:border-0 last:pb-0">
      <SectionLabel as="p" size="2xs" className="mb-2">
        {field.label}
      </SectionLabel>
      <ul role="group" aria-label={field.label} className="flex flex-col gap-1.5">
        {values.map((val) => (
          <li key={val}>
            <label className="flex cursor-pointer items-center gap-2">
              <Checkbox
                checked={active.has(val)}
                onCheckedChange={() => onToggle(field.field, val)}
                aria-label={`Filter by ${field.label}: ${val}`}
                data-testid={`filter-checkbox-${field.field}-${val}`}
              />
              <span className="text-sm text-[var(--color-text-primary)]">{val}</span>
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
}
