// components/ui/ds/templates/LveWorkspaceTemplate.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import { Button, Input, Pagination, useShortcuts } from "@dbp/ui";
import { Filter, ChevronDown, X, Columns2, Plus } from "lucide-react";
import { ListTable } from "./ListTable";
import { DetailPane } from "./DetailPane";
import { useMediaQuery } from "../../hooks/use-media-query";
import type {
  LveRow, LveColumnDef, LveFilter, LveSortState, LveStageStep,
} from "./types";

/** Minimal English pluralization (consonant+y → ies, s/x/z/ch/sh → es, else + s). */
function pluralize(label: string): string {
  if (/[^aeiou]y$/i.test(label)) return label.slice(0, -1) + "ies";
  if (/(s|x|z|ch|sh)$/i.test(label)) return label + "es";
  return label + "s";
}

interface CardListItemsProps {
  rows: LveRow[];
  activeId: string | null;
  onSelect: (id: string) => void;
  cardLabelKey: string;
  cardSublabelKey?: string;
  cardDotColorKey?: string;
  cardDotColors?: Record<string, string>;
  cardStatusKey?: string;
  cardStatusColors?: Record<string, string>;
  cardStatusLabels?: Record<string, string>;
  cardBadgeRender?: (row: LveRow) => React.ReactNode;
  cardTimeKey?: string;
  cardTimeRender?: (val: unknown) => string;
}

/** Shared card-list row renderer — used by the detail-mode sidebar and the mobile list-mode card list. */
function CardListItems({
  rows, activeId, onSelect,
  cardLabelKey, cardSublabelKey, cardDotColorKey, cardDotColors,
  cardStatusKey, cardStatusColors, cardStatusLabels, cardBadgeRender, cardTimeKey, cardTimeRender,
}: CardListItemsProps) {
  return (
    <>
      {rows.map(row => {
        const isActive = row.id === activeId;
        const label = cardLabelKey && row[cardLabelKey] ? String(row[cardLabelKey]) : row.id;
        const sublabel = cardSublabelKey && row[cardSublabelKey] ? String(row[cardSublabelKey]) : undefined;
        const dotVal = cardDotColorKey && row[cardDotColorKey] ? String(row[cardDotColorKey]) : undefined;
        const _dotColor = dotVal && cardDotColors ? (cardDotColors[dotVal] ?? "var(--muted)") : "var(--muted)";
        const statusVal = cardStatusKey && row[cardStatusKey] ? String(row[cardStatusKey]) : undefined;
        const statusLabel = statusVal && cardStatusLabels ? (cardStatusLabels[statusVal] ?? statusVal) : statusVal;
        const _statusColor = statusVal && cardStatusColors ? (cardStatusColors[statusVal] ?? "var(--muted)") : "var(--muted)";
        const timeVal = cardTimeKey && row[cardTimeKey];

        return (
          <div
            key={row.id}
            role="button"
            tabIndex={0}
            aria-pressed={isActive}
            onClick={() => onSelect(row.id)}
            onKeyDown={(e: React.KeyboardEvent<HTMLDivElement>) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onSelect(row.id);
              }
            }}
            onFocus={(e: React.FocusEvent<HTMLDivElement>) => {
              e.currentTarget.style.outline = "2px solid var(--color-focus-ring, var(--color-primary))";
              e.currentTarget.style.outlineOffset = "-2px";
            }}
            onBlur={(e: React.FocusEvent<HTMLDivElement>) => {
              e.currentTarget.style.outline = "";
              e.currentTarget.style.outlineOffset = "";
            }}
            style={{
              padding: "8px 10px 8px 13px",
              cursor: "pointer",
              display: "flex", flexDirection: "column", gap: 3,
              background: isActive ? "var(--bone)" : "transparent",
              borderLeft: `3px solid ${isActive ? "var(--accent)" : "transparent"}`,
              outline: "none",
            }}
          >
            {/* Line 1: name + time */}
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <span style={{ fontSize: 13.5, fontWeight: 500, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: "var(--ink)" }}>
                {label}
              </span>
              {timeVal != null && (
                <span style={{ fontSize: 10.5, color: "var(--muted)", fontFamily: "var(--mono)", flexShrink: 0 }}>
                  {cardTimeRender ? cardTimeRender(timeVal) : (timeVal as unknown) instanceof Date ? (timeVal as Date).toLocaleDateString() : String(timeVal)}
                </span>
              )}
            </div>
            {/* Line 2: type · status + badge */}
            <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
              {sublabel && <span style={{ fontSize: 11.5, color: "var(--muted)" }}>{sublabel}</span>}
              {sublabel && statusLabel && <span style={{ fontSize: 11, color: "var(--hair)" }}>·</span>}
              {statusLabel && <span style={{ fontSize: 11.5, color: "var(--muted)" }}>{statusLabel}</span>}
              {cardBadgeRender?.(row)}
            </div>
          </div>
        );
      })}
    </>
  );
}

export interface LveWorkspaceTemplateProps {
  // ── Header ───────────────────────────────────────────────────────────────
  eyebrow?: string;
  title?: string;
  meta?: React.ReactNode;
  actions?: React.ReactNode;

  // ── Table ─────────────────────────────────────────────────────────────────
  columns: LveColumnDef[];
  rows: LveRow[];
  entityLabel: string;
  onNew: () => void;
  /** When true, renders a "+ New" button in the list toolbar wired to onNew. */
  showNewButton?: boolean;
  onRowUpdate: (id: string, patch: Partial<LveRow>) => void;

  // ── Host callbacks (ADR-0040) ─────────────────────────────────────────────
  /** Typed list ↔ split notification; fires alongside the (deprecated) dbp:lve:view-change CustomEvent. */
  onViewChange?: (mode: "list" | "split") => void;

  // ── Card list (shown when detail is open) ─────────────────────────────────
  cardLabelKey: string;
  cardSublabelKey?: string;
  cardDotColorKey?: string;
  cardDotColors?: Record<string, string>;
  cardStatusKey?: string;
  cardStatusColors?: Record<string, string>;
  /** Map from status key → human label, e.g. { IN_PROGRESS: "In Progress" } */
  cardStatusLabels?: Record<string, string>;
  cardBadgeRender?: (row: LveRow) => React.ReactNode;
  cardTimeKey?: string;
  /** Render function for the time slot; receives the raw field value */
  cardTimeRender?: (val: unknown) => string;

  // ── FocusedRail (focus mode) ─────────────────────────────────────────────
  railLabelKey: string;
  railSubLabelKey?: string;
  railDotColorKey?: string;
  railDotColors?: Record<string, string>;

  // ── Detail pane ───────────────────────────────────────────────────────────
  detailTitleKey?: string;
  detailSubtitleContent?: (record: LveRow) => React.ReactNode;
  detailMetrics?: (record: LveRow) => { label: string; value: React.ReactNode; accent?: boolean }[];
  detailStages?: LveStageStep[];
  detailActiveStageKey?: string;
  detailQuickActions?: { label: string; action: string }[] | ((record: LveRow) => { label: string; action: string }[]);
  /** Detail-pane overflow ("⋯") menu items. Empty/absent → DetailPane renders no overflow menu. */
  detailOverflowActions?: { label: string; action: string; tone?: string }[] | ((record: LveRow) => { label: string; action: string; tone?: string }[]);
  detailTitleBadge?: (record: LveRow) => React.ReactNode;
  detailOverviewContent?: (record: LveRow, onUpdate: (patch: Partial<LveRow>) => void) => React.ReactNode;
  detailActivityContent?: (record: LveRow) => React.ReactNode;
  /** Tabs beyond Overview/Activity, e.g. config.detailTabs[1..] — rendered in order, no cap. */
  detailExtraTabs?: { label: string; content: (record: LveRow) => React.ReactNode }[];
  detailContactsContent?: (record: LveRow) => React.ReactNode;
  detailFilesContent?: (record: LveRow) => React.ReactNode;
  onDetailQuickAction?: (action: string, record: LveRow) => void;
  onStageClick?: (stageId: string, record: LveRow) => void;
  /** Workflow-bound stepper — replaces the config-driven stages StepIndicator */
  detailStepperOverride?: (record: LveRow) => React.ReactNode;
  /** Workflow-bound actions rendered in the detail title row */
  detailHeaderActions?: (record: LveRow) => React.ReactNode;

  // ── Sort ──────────────────────────────────────────────────────────────────
  sortFields?: string[];

  /** Forwarded to DetailPane — shows auto-save status indicator */
  detailSaveStatus?: "saved" | "saving" | "unsaved";
  /** Slot rendered in the detail pane control bar (e.g. + New button) */
  detailControlBarSlot?: React.ReactNode;
  /** Extra content rendered below the title/actions row in the header area */
  headerExtra?: React.ReactNode;

  listTabs?: { key: string; label: string; filter?: (row: LveRow) => boolean }[];
  quickFilters?: { key: string; label: string; filter: (row: LveRow) => boolean }[];
  bulkActions?: { label: string; action: string }[];
  onBulkAction?: (action: string, ids: string[]) => void;
  showFooter?: boolean;
  pageSizeOptions?: number[];
  /** When true, the host renders the page header externally — suppress the list-mode header here. */
  hideListHeader?: boolean;
  /** When true, list mode switches to a card list + pill tabs + load-more below the 768px breakpoint (phones). */
  mobileCardList?: boolean;
}


const PAGE_SIZE = 10;

export function LveWorkspaceTemplate({
  eyebrow, title, meta, actions,
  columns, rows, entityLabel, onNew, showNewButton = false, onRowUpdate,
  onViewChange,
  cardLabelKey, cardSublabelKey, cardDotColorKey, cardDotColors,
  cardStatusKey, cardStatusColors, cardStatusLabels, cardBadgeRender, cardTimeKey, cardTimeRender,
  railLabelKey: _railLabelKey, railSubLabelKey: _railSubLabelKey, railDotColorKey: _railDotColorKey, railDotColors: _railDotColors,
  detailTitleKey, detailSubtitleContent, detailMetrics,
  detailTitleBadge,
  detailStages, detailActiveStageKey, detailQuickActions, detailOverflowActions,
  detailOverviewContent, detailActivityContent, detailExtraTabs,
  detailContactsContent, detailFilesContent,
  onDetailQuickAction, onStageClick,
  detailStepperOverride, detailHeaderActions,
  sortFields,
  detailSaveStatus,
  detailControlBarSlot,
  listTabs, quickFilters,
  bulkActions, onBulkAction,
  showFooter = true,
  pageSizeOptions,
  headerExtra,
  hideListHeader,
  mobileCardList = false,
}: LveWorkspaceTemplateProps) {
  const isMobile = useMediaQuery("(max-width: 767px)");
  const useMobileLayout = mobileCardList && isMobile;
  const [activeId, setActiveId] = useState<string | null>(rows[0]?.id ?? null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOpen, setSortOpen] = useState(false);
  const [savedViewsOpen, setSavedViewsOpen] = useState(false);
  const [filters, setFilters] = useState<LveFilter[]>([]);
  const [sortBy, setSortBy] = useState<LveSortState>({ field: sortFields?.[0] ?? columns[0]?.key ?? "id", dir: "desc" });
  const [selection, setSelection] = useState<Set<string>>(new Set());
  // Multi-select mode: when true the checkbox column is visible in ListTable
  const [multiSelectMode, setMultiSelectMode] = useState(false);
  const [savedViews, setSavedViews] = useState<{ id: string; label: string; filters: LveFilter[]; sortBy: LveSortState }[]>([]);
  const [page, setPage] = useState(1);
  const [activeTabKey, setActiveTabKey] = useState<string | null>(null);
  const [activeQuickFilters, _setActiveQuickFilters] = useState<Set<string>>(new Set());
  const [pageSize, setPageSize] = useState<number>(() => pageSizeOptions?.[0] ?? PAGE_SIZE);
  const [mobileLoadedCount, setMobileLoadedCount] = useState<number>(() => pageSizeOptions?.[0] ?? PAGE_SIZE);

  // Filter builder popover state
  const [filterBuilderOpen, setFilterBuilderOpen] = useState(false);
  const [fbField, setFbField] = useState<string>("");
  const [fbOp, setFbOp] = useState<"is" | "contains" | ">" | "<">("is");
  const [fbValue, setFbValue] = useState("");

  // Save-view inline popover state (replaces window.prompt)
  const [saveViewOpen, setSaveViewOpen] = useState(false);
  const [saveViewLabel, setSaveViewLabel] = useState("");

  // Card-list search
  const [cardListSearch, setCardListSearch] = useState("");

  const visibleRows = useMemo(() => {
    let out = [...rows];

    // Tab filter (applied first)
    if (activeTabKey && listTabs) {
      const tab = listTabs.find(t => t.key === activeTabKey);
      if (tab?.filter) out = out.filter(tab.filter);
    }

    // Quick filters (AND — each active chip must match)
    if (quickFilters) {
      for (const qf of quickFilters) {
        if (activeQuickFilters.has(qf.key)) {
          out = out.filter(qf.filter);
        }
      }
    }

    // Text search
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      out = out.filter(r => Object.values(r).some(v => v != null && String(v).toLowerCase().includes(q)));
    }

    // Custom filters from filter builder
    filters.forEach(f => {
      out = out.filter(r => {
        const v = r[f.field];
        if (f.op === "is") return String(v).toLowerCase() === f.value.toLowerCase();
        if (f.op === "contains") return String(v).toLowerCase().includes(f.value.toLowerCase());
        if (f.op === ">") return Number(v) > Number(f.value);
        if (f.op === "<") return Number(v) < Number(f.value);
        return true;
      });
    });

    // Sort
    out.sort((a, b) => {
      const av = a[sortBy.field], bv = b[sortBy.field];
      if (av instanceof Date && bv instanceof Date)
        return sortBy.dir === "desc" ? bv.getTime() - av.getTime() : av.getTime() - bv.getTime();
      const cmp = typeof av === "number" && typeof bv === "number"
        ? av - bv
        : String(av ?? "").localeCompare(String(bv ?? ""));
      return sortBy.dir === "desc" ? -cmp : cmp;
    });

    return out;
  }, [rows, activeTabKey, listTabs, activeQuickFilters, quickFilters, searchQuery, filters, sortBy]);

  // Reset page when filters or sort change
  useEffect(() => {
    setPage(1);
    setMobileLoadedCount(pageSizeOptions?.[0] ?? PAGE_SIZE);
  }, [filters, sortBy, activeTabKey, activeQuickFilters, pageSizeOptions]);

  // Notify the host of list↔focus view changes so it can show/hide an external page header.
  // ADR-0040: the typed onViewChange callback is the sanctioned channel; the
  // dbp:lve:view-change CustomEvent still fires (deprecated, one release).
  useEffect(() => {
    const mode = detailOpen ? ("split" as const) : ("list" as const);
    onViewChange?.(mode);
    if (typeof document === "undefined") return;
    document.dispatchEvent(
      new CustomEvent("dbp:lve:view-change", { detail: { mode }, bubbles: true }),
    );
  }, [detailOpen, onViewChange]);

  // Close filter builder popover on outside click
  useEffect(() => {
    if (!filterBuilderOpen) return;
    const close = (e: MouseEvent) => {
      if (!(e.target as HTMLElement).closest(".lve-filter-builder")) {
        setFilterBuilderOpen(false);
      }
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [filterBuilderOpen]);

  const tabCounts = useMemo(() => {
    if (!listTabs) return {} as Record<string, number>;
    return Object.fromEntries(
      listTabs.map(t => [t.key, t.filter ? rows.filter(t.filter).length : rows.length])
    );
  }, [rows, listTabs]);

  const pagedRows = useMemo(() => {
    const start = (page - 1) * pageSize;
    return visibleRows.slice(start, start + pageSize);
  }, [visibleRows, page, pageSize]);

  const mobileRows = useMemo(() => visibleRows.slice(0, mobileLoadedCount), [visibleRows, mobileLoadedCount]);

  const cardListRows = useMemo(() => {
    if (!cardListSearch.trim()) return pagedRows;
    const q = cardListSearch.trim().toLowerCase();
    return pagedRows.filter(r => Object.values(r).some(v => v != null && String(v).toLowerCase().includes(q)));
  }, [pagedRows, cardListSearch]);

  const activeRecord = visibleRows.find(r => r.id === activeId) ?? null;
  const activeIndex = visibleRows.findIndex(r => r.id === activeId);

  const navigate = (dir: 1 | -1) => {
    const next = Math.max(0, Math.min(visibleRows.length - 1, activeIndex + dir));
    if (visibleRows[next]) setActiveId(visibleRows[next].id);
  };

  // capability-keyboard-shortcuts-spec-2026-07-10.md §2 default global map:
  // "j/k → list focus" (organism-registered, surface scope) and "[ ] → detail
  // panel close/open" (LVE/record-drawer surfaces). Reuses the same `navigate`
  // that already backs the detail pane's prev/next chevrons.
  useShortcuts(
    [
      { keys: "j", handler: () => navigate(1), description: "Next record", group: "List navigation" },
      { keys: "k", handler: () => navigate(-1), description: "Previous record", group: "List navigation" },
      { keys: "[", handler: () => setDetailOpen(false), description: "Close detail panel", group: "Detail panel" },
      {
        keys: "]",
        handler: () => { if (activeRecord) setDetailOpen(true); },
        description: "Open detail panel",
        group: "Detail panel",
      },
    ],
    { scope: "surface", enabled: visibleRows.length > 0 },
  );

  const handleRowUpdate = (id: string, patch: Partial<LveRow>) => onRowUpdate(id, patch);


  const commitSaveView = () => {
    if (!saveViewLabel.trim()) return;
    setSavedViews(prev => [...prev, {
      id: `v-${Date.now()}`,
      label: saveViewLabel.trim(),
      filters: [...filters],
      sortBy: { ...sortBy },
    }]);
    setSaveViewOpen(false);
    setSaveViewLabel("");
  };

  const saveCurrentView = () => {
    setSaveViewLabel("");
    setSaveViewOpen(v => !v);
  };

  const loadView = (v: typeof savedViews[number]) => {
    setFilters([...v.filters]);
    setSortBy({ ...v.sortBy });
  };

  const deleteView = (id: string) => setSavedViews(prev => prev.filter(v => v.id !== id));

  // Header node — shared between list (full-width) and detail (card-column-width)
  const headerNode = (title || meta || actions || eyebrow) ? (
    <div style={{
      padding: "14px 16px 12px",
      borderBottom: "1px solid var(--hair)",
      display: "flex", alignItems: "center", gap: 10,
      flexShrink: 0, background: "var(--paper)",
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        {eyebrow && (
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--muted)", fontFamily: "var(--mono)", marginBottom: 4 }}>
            {eyebrow}
          </div>
        )}
        {title && (
          <div style={{ fontSize: 22, fontWeight: 700, color: "var(--ink)", letterSpacing: "-0.01em", lineHeight: 1.2, fontFamily: "var(--serif)" }}>
            {title}
          </div>
        )}
        {meta && <div style={{ fontSize: 13, color: "var(--muted)", marginTop: 2 }}>{meta}</div>}
      </div>
      {actions}
    </div>
  ) : null;

  // Compact header for FOCUS/detail mode — TITLE ONLY, confined to the left list column
  // (so the detail pane runs full-height). Breadcrumb + subtitle are dropped here.
  const compactHeaderNode = title ? (
    <div style={{
      padding: "12px 16px",
      borderBottom: "1px solid var(--hair)",
      flexShrink: 0, background: "var(--paper)",
    }}>
      <div style={{
        fontSize: 16, fontWeight: 700, color: "var(--ink)",
        letterSpacing: "-0.01em", lineHeight: 1.2, fontFamily: "var(--serif)",
        overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
      }}>
        {title}
      </div>
    </div>
  ) : null;

  return (
    <div className="lve-viewport" style={{
      flex: 1,
      minHeight: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      background: "var(--paper)",
    }}>
      {/* ── Page header — full width in list mode ── */}
      {!detailOpen && !hideListHeader && headerNode}
      {!detailOpen && !hideListHeader && headerExtra}

      {/* ── Tab row / filter bar / bulk actions — list mode only ── */}
      {!detailOpen && listTabs && listTabs.length > 0 && !useMobileLayout && (
        <div
          role="tablist"
          style={{
            height: 36, flexShrink: 0,
            borderBottom: "1px solid var(--hair)",
            display: "flex", alignItems: "flex-end",
            padding: "0 16px", gap: 0,
            background: "var(--paper)",
          }}
        >
          {listTabs.map(t => {
            const isActive = activeTabKey === t.key;
            return (
              <button
                key={t.key}
                role="tab"
                aria-selected={isActive}
                onClick={() => { setActiveTabKey(isActive ? null : t.key); }}
                style={{
                  height: 34, padding: "0 12px", fontSize: 13,
                  background: "none", border: "none",
                  borderBottom: isActive ? "2px solid var(--accent)" : "2px solid transparent",
                  color: isActive ? "var(--ink)" : "var(--muted)",
                  fontWeight: isActive ? 500 : 400,
                  cursor: "pointer",
                  transition: "color 0.1s, border-color 0.1s",
                  display: "flex", alignItems: "center", gap: 5,
                }}
              >
                {t.label}
                {tabCounts[t.key] !== undefined && (
                  <span style={{ fontSize: 11, color: "var(--muted)", fontFamily: "var(--mono)" }}>
                    {tabCounts[t.key]}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* ── Pill tabs — mobile list mode only ── */}
      {!detailOpen && listTabs && listTabs.length > 0 && useMobileLayout && (
        <div
          role="tablist"
          style={{
            flexShrink: 0,
            borderBottom: "1px solid var(--hair)",
            display: "flex", alignItems: "center",
            padding: "8px 16px", gap: 6,
            overflowX: "auto", flexWrap: "nowrap",
            background: "var(--paper)",
          }}
        >
          {listTabs.map(t => {
            const isActive = activeTabKey === t.key;
            return (
              <button
                key={t.key}
                role="tab"
                aria-selected={isActive}
                onClick={() => { setActiveTabKey(isActive ? null : t.key); }}
                style={{
                  flexShrink: 0,
                  borderRadius: 999,
                  padding: "5px 12px",
                  fontSize: 13,
                  border: "none",
                  background: isActive ? "var(--accent)" : "var(--bone)",
                  color: isActive ? "white" : "var(--muted)",
                  fontWeight: isActive ? 500 : 400,
                  cursor: "pointer",
                  display: "flex", alignItems: "center", gap: 5,
                  whiteSpace: "nowrap",
                }}
              >
                {t.label}
                {tabCounts[t.key] !== undefined && (
                  <span style={{ fontSize: 11, fontFamily: "var(--mono)" }}>
                    {tabCounts[t.key]}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* ── Bulk-actions bar (shown when rows selected, list mode only) ── */}
      {!detailOpen && bulkActions && selection.size > 0 && (
        <div style={{
          height: 40, flexShrink: 0,
          borderBottom: "1px solid var(--hair)",
          display: "flex", alignItems: "center",
          padding: "0 16px", gap: 8,
          background: "var(--bone)",
        }}>
          <span style={{ fontSize: 12.5, fontWeight: 500, color: "var(--ink)", flexShrink: 0 }}>
            {selection.size} selected
          </span>
          {bulkActions.map(ba => (
            <Button
              key={ba.action}
              variant="outline"
              size="sm"
              className="h-7 px-2 text-xs"
              onClick={() => onBulkAction?.(ba.action, Array.from(selection))}
            >
              {ba.label}
            </Button>
          ))}
          <div style={{ flex: 1 }} />
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2 text-xs"
            onClick={() => setSelection(new Set())}
          >
            <X size={13} /> Clear
          </Button>
        </div>
      )}

      {/* ── Toolbar row (list mode only): search + focus + select + filter/sort controls ── */}
      {!detailOpen && (
        <div style={{
          height: 44, flexShrink: 0,
          borderBottom: "1px solid var(--hair)",
          display: "flex", alignItems: "center",
          padding: "0 16px", gap: 6,
          background: "var(--paper)",
          overflowX: "auto",
        }}>
          {/* Search — always visible, leftmost */}
          <Input
            value={searchQuery}
            onChange={e => { setSearchQuery(e.target.value); setPage(1); }}
            placeholder={`Search ${pluralize(entityLabel).toLowerCase()}…`}
            className="h-8 text-sm w-[200px]"
          />

          {/* Active custom filter chips */}
          {filters.map((f, i) => (
            <span key={i} style={{
              display: "inline-flex", alignItems: "center", gap: 4,
              padding: "2px 8px", borderRadius: "var(--radius-input)", fontSize: 11,
              background: "var(--bone)", border: "1px solid var(--hair)",
              fontFamily: "var(--mono)", color: "var(--ink)", flexShrink: 0,
            }}>
              {f.field} {f.op} {f.value}
              <button
                aria-label={`Remove filter: ${f.field} ${f.op} ${f.value}`}
                onClick={() => setFilters(prev => prev.filter((_, j) => j !== i))}
                style={{ cursor: "pointer", color: "var(--muted)", display: "inline-flex", alignItems: "center", background: "none", border: "none", padding: 0, marginLeft: 2 }}
              ><X size={12} /></button>
            </span>
          ))}

          {/* Filter button */}
          <div className="lve-filter-builder" style={{ position: "relative" }}>
            <Button
              variant="outline"
              size="sm"
              className="h-7 px-2 text-xs gap-1 border-[var(--color-border-subtle)] font-normal text-[var(--color-text-secondary)]"
              onClick={() => { setFbField(columns[0]?.key ?? ""); setFbOp("is"); setFbValue(""); setFilterBuilderOpen(v => !v); }}
            >
              <Filter size={13} /> Filter
            </Button>
            {filterBuilderOpen && (
              <div style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, zIndex: 50, background: "var(--paper)", border: "1px solid var(--hair)", borderRadius: "var(--radius-card)", boxShadow: "var(--shadow-lg)", padding: 12, minWidth: 280, display: "flex", flexDirection: "column", gap: 8 }}>
                <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--muted)", fontFamily: "var(--mono)" }}>Add filter</div>
                <select className="input" style={{ height: 28, fontSize: 12 }} value={fbField} onChange={e => setFbField(e.target.value)}>
                  {columns.map(c => <option key={c.key} value={c.key}>{c.label}</option>)}
                </select>
                <select className="input" style={{ height: 28, fontSize: 12 }} value={fbOp} onChange={e => setFbOp(e.target.value as "is" | "contains" | ">" | "<")}>
                  <option value="is">is</option><option value="contains">contains</option>
                  <option value=">">greater than</option><option value="<">less than</option>
                </select>
                <input className="input" style={{ height: 28, fontSize: 12 }} placeholder="Value…" value={fbValue} onChange={e => setFbValue(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && fbValue.trim()) { setFilters(prev => [...prev, { field: fbField, op: fbOp, value: fbValue.trim() }]); setFilterBuilderOpen(false); } if (e.key === "Escape") setFilterBuilderOpen(false); }} autoFocus />
                <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                  <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setFilterBuilderOpen(false)}>Cancel</Button>
                  <Button size="sm" className="h-7 px-2 text-xs" onClick={() => { if (fbValue.trim()) setFilters(prev => [...prev, { field: fbField, op: fbOp, value: fbValue.trim() }]); setFilterBuilderOpen(false); }} disabled={!fbValue.trim()}>Apply</Button>
                </div>
              </div>
            )}
          </div>

          {/* Sort dropdown */}
          <div style={{ position: "relative" }}>
            <Button
              variant="outline"
              size="sm"
              className="h-7 px-2 text-xs gap-1 border-[var(--color-border-subtle)] font-normal text-[var(--color-text-secondary)]"
              onClick={() => { setSortOpen(v => !v); setSavedViewsOpen(false); }}
            >
              Sort: {sortBy.dir === "desc" ? "Newest" : "Oldest"} <ChevronDown size={12} />
            </Button>
            {sortOpen && (
              <div style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, zIndex: 50, background: "var(--paper)", border: "1px solid var(--hair)", borderRadius: "var(--radius-card)", boxShadow: "var(--shadow-lg)", minWidth: 160, overflow: "hidden" }}>
                {[
                  { label: "Newest first", field: sortFields?.[0] ?? "id", dir: "desc" as const },
                  { label: "Oldest first", field: sortFields?.[0] ?? "id", dir: "asc" as const },
                  ...(sortFields?.slice(1).map(f => ({ label: f.charAt(0).toUpperCase() + f.slice(1), field: f, dir: "desc" as const })) ?? []),
                ].map(opt => (
                  <button key={opt.label} onClick={() => { setSortBy({ field: opt.field, dir: opt.dir }); setSortOpen(false); }}
                    style={{ display: "block", width: "100%", textAlign: "left", padding: "8px 14px", fontSize: 13, background: "none", border: "none", cursor: "pointer", color: "var(--ink)" }}>
                    {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Saved views dropdown — hidden on mobile card-list layout */}
          {!useMobileLayout && (
          <div style={{ position: "relative" }}>
            <Button
              variant="outline"
              size="sm"
              className="h-7 px-2 text-xs gap-1 border-[var(--color-border-subtle)] font-normal text-[var(--color-text-secondary)]"
              onClick={() => { setSavedViewsOpen(v => !v); setSortOpen(false); }}
              aria-haspopup="true"
              aria-expanded={savedViewsOpen}
            >
              Views <ChevronDown size={12} />
            </Button>
            {savedViewsOpen && (
              <div role="menu" style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, zIndex: 50, background: "var(--paper)", border: "1px solid var(--hair)", borderRadius: "var(--radius-card)", boxShadow: "var(--shadow-lg)", minWidth: 200, overflow: "hidden", padding: 4 }}>
                {savedViews.length === 0 && (
                  <div style={{ padding: "8px 12px", fontSize: 12, color: "var(--muted)" }}>No saved views</div>
                )}
                {savedViews.map(v => (
                  <div key={v.id} style={{ display: "flex", alignItems: "center" }}>
                    <button onClick={() => { loadView(v); setSavedViewsOpen(false); }} style={{ flex: 1, textAlign: "left", padding: "8px 12px", fontSize: 13, background: "none", border: "none", cursor: "pointer", color: "var(--ink)" }}>
                      {v.label}
                    </button>
                    <button onClick={() => deleteView(v.id)} aria-label={`Delete view ${v.label}`} style={{ padding: "4px 10px", background: "none", border: "none", cursor: "pointer", color: "var(--muted)", display: "inline-flex" }}>
                      <X size={12} />
                    </button>
                  </div>
                ))}
                <div style={{ borderTop: "1px solid var(--hair)", marginTop: 4, paddingTop: 4 }}>
                  {saveViewOpen ? (
                    <div style={{ display: "flex", gap: 4, padding: 4 }}>
                      <Input
                        autoFocus
                        value={saveViewLabel}
                        onChange={e => setSaveViewLabel(e.target.value)}
                        onKeyDown={e => { if (e.key === "Enter") commitSaveView(); if (e.key === "Escape") setSaveViewOpen(false); }}
                        placeholder="View name…"
                        className="h-7 text-xs flex-1"
                      />
                      <Button size="sm" className="h-7 px-2 text-xs" onClick={commitSaveView}>Save</Button>
                    </div>
                  ) : (
                    <button onClick={saveCurrentView} style={{ display: "block", width: "100%", textAlign: "left", padding: "8px 12px", fontSize: 13, background: "none", border: "none", cursor: "pointer", color: "var(--color-primary)" }}>
                      + Save current view
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
          )}

          <div style={{ flex: 1 }} />

          {/* Create — "+ New" affordance (GAP 1). Only rendered when the host config declares createConfig. */}
          {showNewButton && (
            <Button
              variant="orange"
              size="sm"
              className="h-7 px-2 text-xs gap-1 shrink-0"
              onClick={onNew}
              data-testid="lve-new-button"
            >
              <Plus size={13} /> New
            </Button>
          )}

          {/* Select mode toggle — enables checkbox column */}
          {bulkActions && bulkActions.length > 0 && (
            <Button
              variant={multiSelectMode ? "navy" : "outline"}
              size="sm"
              className="h-7 px-2 text-xs gap-1 shrink-0 font-normal"
              onClick={() => {
                setMultiSelectMode(v => !v);
                if (multiSelectMode) setSelection(new Set()); // clear on exit
              }}
            >
              Select
            </Button>
          )}

          {/* Focus view — hidden on mobile card-list layout (mobile is already a focus-style single-pane view) */}
          {!useMobileLayout && (
          <Button
            variant="outline"
            size="sm"
            className="h-7 px-2 text-xs gap-1 shrink-0 border-[var(--color-border-subtle)] font-normal text-[var(--color-text-secondary)]"
            onClick={() => {
              if (!activeId && rows[0]) setActiveId(rows[0].id);
              setDetailOpen(true);
            }}
            title="Focus view"
          >
            <Columns2 size={14} /> Focus
          </Button>
          )}
        </div>
      )}

      {/* ── Main body ── */}
      <div style={{ flex: 1, display: "flex", minHeight: 0, overflow: "hidden", position: "relative" }}>
        {/* Table mode — detail closed, full width */}
        {!detailOpen && (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0, overflow: "hidden" }}>
            {useMobileLayout ? (
              <div className="lve-card-list" style={{ flex: 1, overflowY: "auto", padding: "4px 0" }}>
                <CardListItems
                  rows={mobileRows}
                  activeId={activeId}
                  onSelect={id => { setActiveId(id); setDetailOpen(true); }}
                  cardLabelKey={cardLabelKey}
                  {...(cardSublabelKey !== undefined ? { cardSublabelKey } : {})}
                  {...(cardDotColorKey !== undefined ? { cardDotColorKey } : {})}
                  {...(cardDotColors !== undefined ? { cardDotColors } : {})}
                  {...(cardStatusKey !== undefined ? { cardStatusKey } : {})}
                  {...(cardStatusColors !== undefined ? { cardStatusColors } : {})}
                  {...(cardStatusLabels !== undefined ? { cardStatusLabels } : {})}
                  {...(cardBadgeRender !== undefined ? { cardBadgeRender } : {})}
                  {...(cardTimeKey !== undefined ? { cardTimeKey } : {})}
                  {...(cardTimeRender !== undefined ? { cardTimeRender } : {})}
                />
              </div>
            ) : (
              <ListTable
                columns={columns}
                rows={pagedRows}
                selection={selection}
                setSelection={setSelection}
                activeId={activeId}
                onRowClick={id => { setActiveId(id); setDetailOpen(true); }}
                onUpdate={handleRowUpdate}
                sortBy={sortBy}
                onSort={field => setSortBy(prev => ({ field, dir: prev.field === field && prev.dir === "desc" ? "asc" : "desc" }))}
                multiSelectMode={multiSelectMode}
              />
            )}
            {/* Footer */}
            {showFooter && (
              <div style={{
                height: 36, flexShrink: 0,
                borderTop: "1px solid var(--hair)",
                display: "flex", alignItems: "center",
                padding: "0 16px", gap: 8,
                background: "var(--paper)",
              }}>
                {useMobileLayout ? (
                  visibleRows.length > mobileLoadedCount ? (
                    <button
                      onClick={() => setMobileLoadedCount(c => c + (pageSizeOptions?.[0] ?? PAGE_SIZE))}
                      style={{
                        flex: 1, textAlign: "center", fontSize: 11.5, color: "var(--muted)",
                        fontFamily: "var(--mono)", background: "none", border: "none", cursor: "pointer",
                      }}
                    >
                      Load more ({visibleRows.length - mobileLoadedCount} remaining)
                    </button>
                  ) : (
                    <span style={{ flex: 1, textAlign: "center", fontSize: 11.5, color: "var(--muted)", fontFamily: "var(--mono)" }}>
                      {visibleRows.length} {entityLabel}{visibleRows.length !== 1 ? "s" : ""}
                    </span>
                  )
                ) : (
                  <>
                    <span style={{ fontSize: 11.5, color: "var(--muted)", fontFamily: "var(--mono)" }}>
                      {visibleRows.length} {entityLabel}{visibleRows.length !== 1 ? "s" : ""}
                    </span>
                    <div style={{ flex: 1 }} />
                    {visibleRows.length > pageSize && (
                      <Pagination
                        page={page}
                        pageSize={pageSize}
                        total={visibleRows.length}
                        onPageChange={setPage}
                        {...(pageSizeOptions && pageSizeOptions.length > 1
                          ? { onPageSizeChange: (n: number) => { setPageSize(n); setPage(1); }, pageSizeOptions }
                          : {})}
                        className="[&_.text-xs]:text-xs"
                      />
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        )}

        {/* Detail mode — card list (narrows in focus) + detail pane */}
        {detailOpen && (
          <>
            {/* Card list — hidden on mobile (detail pane takes full width), fixed sidebar on md+ */}
            <div
              className="hidden md:flex md:w-[300px] lg:w-[340px] shrink-0 flex-col"
              style={{
                borderRight: "1px solid var(--hair)",
                background: "var(--paper)",
                overflow: "hidden",
                minHeight: 0,
              }}>
              {/* Page header — TITLE ONLY in detail mode (compact, 1 column).
                  Suppressed when the host layout already owns the page header
                  (externalHeader → hideListHeader), so the title isn't repeated. */}
              {!hideListHeader && compactHeaderNode}

              {/* List header */}
              <div style={{
                padding: "8px 12px",
                borderBottom: "1px solid var(--hair)",
                display: "flex", alignItems: "center", justifyContent: "space-between",
                flexShrink: 0,
              }}>
                <span style={{ fontSize: 12, fontWeight: 500, color: "var(--ink)" }}>
                  {visibleRows.length} {entityLabel}{visibleRows.length !== 1 ? "s" : ""}
                </span>
                <Input
                  value={cardListSearch}
                  onChange={e => setCardListSearch(e.target.value)}
                  placeholder="Search list…"
                  className="h-7 text-xs w-[130px]"
                />
              </div>
              <div className="lve-card-list" style={{ flex: 1, overflowY: "auto", padding: "4px 0" }}>
                <CardListItems
                  rows={cardListRows}
                  activeId={activeId}
                  onSelect={id => setActiveId(id)}
                  cardLabelKey={cardLabelKey}
                  {...(cardSublabelKey !== undefined ? { cardSublabelKey } : {})}
                  {...(cardDotColorKey !== undefined ? { cardDotColorKey } : {})}
                  {...(cardDotColors !== undefined ? { cardDotColors } : {})}
                  {...(cardStatusKey !== undefined ? { cardStatusKey } : {})}
                  {...(cardStatusColors !== undefined ? { cardStatusColors } : {})}
                  {...(cardStatusLabels !== undefined ? { cardStatusLabels } : {})}
                  {...(cardBadgeRender !== undefined ? { cardBadgeRender } : {})}
                  {...(cardTimeKey !== undefined ? { cardTimeKey } : {})}
                  {...(cardTimeRender !== undefined ? { cardTimeRender } : {})}
                />
              </div>
              {/* Pagination footer */}
              {visibleRows.length > pageSize && (
                <div style={{
                  padding: "7px 12px", borderTop: "1px solid var(--hair)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0, background: "var(--paper)",
                }}>
                  <Pagination
                    page={page}
                    pageSize={pageSize}
                    total={visibleRows.length}
                    onPageChange={setPage}
                    showCaption
                    className="[&_.text-xs]:text-xs"
                  />
                </div>
              )}
            </div>

            {/* Detail pane — fills remaining space */}
            <DetailPane
              record={activeRecord}
              recordIndex={Math.max(0, activeIndex)}
              totalRecords={visibleRows.length}
              mode="focused"
              onClose={() => setDetailOpen(false)}
              onUpdate={patch => { if (activeId) handleRowUpdate(activeId, patch); }}
              onNavigate={navigate}
              {...(onDetailQuickAction ? { onQuickAction: onDetailQuickAction } : {})}
              onModeToggle={() => setDetailOpen(false)}
              {...(detailTitleKey !== undefined ? { titleKey: detailTitleKey } : {})}
              {...(activeRecord && detailTitleBadge ? { titleBadge: detailTitleBadge(activeRecord) } : {})}
              {...(activeRecord && detailSubtitleContent ? { subtitleContent: detailSubtitleContent(activeRecord) } : {})}
              {...(activeRecord && detailMetrics ? { metrics: detailMetrics(activeRecord) } : {})}
              {...(detailStages !== undefined ? { stages: detailStages } : {})}
              {...(activeRecord && detailActiveStageKey ? { activeStageId: String(activeRecord[detailActiveStageKey] ?? "") } : {})}
              {...(onStageClick ? { onStageClick: (stageId: string) => { if (activeRecord) onStageClick(stageId, activeRecord); } } : {})}
              quickActions={(() => {
                if (!detailQuickActions) return [];
                if (typeof detailQuickActions === "function") return activeRecord ? detailQuickActions(activeRecord) : [];
                return detailQuickActions;
              })()}
              overflowActions={(() => {
                if (!detailOverflowActions) return [];
                if (typeof detailOverflowActions === "function") return activeRecord ? detailOverflowActions(activeRecord) : [];
                return detailOverflowActions;
              })()}
              {...(activeRecord && detailOverviewContent ? { overviewContent: detailOverviewContent(activeRecord, patch => { if (activeId) handleRowUpdate(activeId, patch); }) } : {})}
              {...(activeRecord && detailActivityContent ? { activityContent: detailActivityContent(activeRecord) } : {})}
              {...(activeRecord && detailExtraTabs && detailExtraTabs.length > 0
                ? { extraTabs: detailExtraTabs.map(t => ({ label: t.label, content: t.content(activeRecord!) })) }
                : {})}
              {...(activeRecord && detailContactsContent ? { contactsContent: detailContactsContent(activeRecord) } : {})}
              {...(activeRecord && detailFilesContent ? { filesContent: detailFilesContent(activeRecord) } : {})}
              {...(detailSaveStatus !== undefined ? { saveStatus: detailSaveStatus } : {})}
              {...(detailControlBarSlot !== undefined ? { controlBarSlot: detailControlBarSlot } : {})}
              {...(activeRecord && detailStepperOverride ? { stepperOverride: detailStepperOverride(activeRecord) } : {})}
              {...(activeRecord && detailHeaderActions ? { headerActions: detailHeaderActions(activeRecord) } : {})}
            />
          </>
        )}

      </div>

      <style>{`
        @keyframes lve-slide-in { from { transform: translateX(100%); } to { transform: translateX(0); } }
        .lve-card-list::-webkit-scrollbar { width: 4px; }
        .lve-card-list::-webkit-scrollbar-track { background: transparent; }
        .lve-card-list::-webkit-scrollbar-thumb { background: var(--hair); border-radius: 2px; }
        .lve-card-list::-webkit-scrollbar-thumb:hover { background: var(--muted); }
      `}</style>
    </div>
  );
}
