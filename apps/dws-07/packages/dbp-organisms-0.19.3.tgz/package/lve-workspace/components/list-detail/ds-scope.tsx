"use client";
import React, { useEffect } from "react";

const SCOPE_CSS = `
.lve-ds .input{height:30px;width:100%;border:1px solid var(--hair);border-radius:var(--radius-input);background:var(--paper);color:var(--ink);font-size:13px;padding:0 8px;outline:none;font-family:var(--sans);}
.lve-ds .input:focus{border-color:var(--accent);}
.lve-ds .input.mono,.lve-ds .mono{font-family:var(--mono);}
.lve-ds .eyebrow{font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);}
.lve-ds .btn{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;}
.lve-ds .label-m{font-size:12px;font-weight:600;}
.lve-ds .caption{font-size:11px;}
.lve-ds select.input{cursor:pointer;padding-right:6px;}
`;

let injected = false;

function injectScopeCss() {
  if (injected) return;
  if (typeof document === "undefined") return;
  const id = "lve-ds-scope-css";
  if (document.getElementById(id)) { injected = true; return; }
  const s = document.createElement("style");
  s.id = id;
  s.textContent = SCOPE_CSS;
  document.head.appendChild(s);
  injected = true;
}

interface LveDsScopeProps {
  children: React.ReactNode;
  className?: string;
  "data-testid"?: string;
}

/**
 * LveDsScope — wraps BROWZ LVE components and sets the token aliases that map
 * BROWZ CSS custom properties to DBP design tokens. Also injects the shared
 * utility class CSS (.input, .eyebrow, etc.) scoped under .lve-ds.
 *
 * The wrapper is a full-height flex column so it fills available space.
 */
export function LveDsScope({ children, className, "data-testid": testId }: LveDsScopeProps) {
  useEffect(() => {
    injectScopeCss();
  }, []);

  // Also inject on server render side (SSR) — runs once per module load
  if (typeof document !== "undefined") {
    injectScopeCss();
  }

  const tokenAliases = ({
    // Layout
    height: "100%",
    display: "flex",
    flexDirection: "column",
    minHeight: "0",
    // BROWZ semantic tokens → DBP color tokens
    "--paper": "var(--color-background)",
    "--bone": "var(--color-surface)",
    "--hair": "var(--color-border-subtle)",
    "--ink": "var(--color-text)",
    "--muted": "var(--color-text-muted)",
    "--accent": "var(--color-primary)",
    "--warn": "var(--color-warning)",
    "--ok": "var(--color-success)",
    "--danger": "var(--color-danger)",
    // Font stacks
    "--serif": "var(--font-display)",
    "--sans": "var(--font-sans)",
    "--mono": "var(--font-mono)",
    // Named color aliases
    "--charcoal-950": "var(--color-primary)",
    "--rose-500": "var(--color-secondary)",
    "--gray-100": "var(--color-surface)",
    "--gray-200": "var(--color-border-subtle)",
    "--gray-400": "var(--color-text-muted)",
    "--gray-500": "var(--color-text-muted)",
    // Shadow & utility
    "--shadow-lg": "0 8px 24px color-mix(in srgb, var(--color-text) 12%, transparent)",
    // Row tint aliases
    "--lve-row-active": "color-mix(in srgb, var(--color-primary) 7%, transparent)",
    "--lve-row-selected": "color-mix(in srgb, var(--color-primary) 4%, transparent)",
  } as unknown) as React.CSSProperties;

  return (
    <div
      className={`lve-ds${className ? ` ${className}` : ""}`}
      style={tokenAliases}
      data-testid={testId}
    >
      {children}
    </div>
  );
}
