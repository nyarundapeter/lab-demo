import * as React from "react";

export interface StepIndicatorProps {
  steps: Array<{ label: string; description?: string }>;
  /** Zero-based index of the active step */
  currentStep: number;
  /** Called with the zero-based index when a step is clicked */
  onStepClick?: (index: number) => void;
}

export function StepIndicator({
  steps,
  currentStep,
  onStepClick,
}: StepIndicatorProps) {
  return (
    <div style={{ width: "100%" }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 0 }}>
        {steps.map((step, i) => {
          const completed = i < currentStep;
          const active = i === currentStep;
          const pending = i > currentStep;

          const circleBg = completed
            ? "var(--charcoal-950)"
            : active
              ? "var(--rose-500)"
              : "var(--gray-100)";
          const circleBorder = pending
            ? "1px solid var(--gray-200)"
            : "1px solid transparent";
          const numColor = completed || active ? "var(--color-primary-foreground)" : "var(--gray-400)";

          return (
            <React.Fragment key={i}>
              {i > 0 ? (
                <div
                  style={{
                    flex: 1,
                    height: 2,
                    marginTop: 15,
                    minWidth: 8,
                    background:
                      i <= currentStep
                        ? "var(--charcoal-950)"
                        : "var(--gray-200)",
                  }}
                  aria-hidden
                />
              ) : null}
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 8,
                  flexShrink: 0,
                }}
              >
                <div
                  onClick={() => onStepClick?.(i)}
                  role={onStepClick ? "button" : undefined}
                  tabIndex={onStepClick ? 0 : undefined}
                  onKeyDown={onStepClick ? (e: React.KeyboardEvent<HTMLDivElement>) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      onStepClick(i);
                    }
                  } : undefined}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: "var(--radius-pill)",
                    background: circleBg,
                    border: circleBorder,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 14,
                    fontWeight: 700,
                    color: numColor,
                    fontFamily: "var(--font-sans), sans-serif",
                    cursor: onStepClick ? "pointer" : "default",
                    outline: "none",
                  }}
                  aria-current={active ? "step" : undefined}
                  onFocus={(e: React.FocusEvent<HTMLDivElement>) => {
                    if (onStepClick) (e.currentTarget as HTMLDivElement).style.boxShadow = "0 0 0 2px var(--color-focus-ring, var(--color-primary))";
                  }}
                  onBlur={(e: React.FocusEvent<HTMLDivElement>) => {
                    (e.currentTarget as HTMLDivElement).style.boxShadow = "";
                  }}
                >
                  <span>{i + 1}</span>
                </div>
                <div style={{ textAlign: "center", maxWidth: 120 }}>
                  <div
                    className="label-m"
                    style={{ color: "var(--charcoal-950)" }}
                  >
                    {step.label}
                  </div>
                  {step.description ? (
                    <div
                      className="caption"
                      style={{ color: "var(--gray-500)", marginTop: 2 }}
                    >
                      {step.description}
                    </div>
                  ) : null}
                </div>
              </div>
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
