// components/ui/ds/lve/ContextMenu.tsx
"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronRight } from "lucide-react";
import type { LveRow, LveStageStep } from "./types";

export interface ContextMenuProps {
  x: number;
  y: number;
  record: LveRow;
  stages?: LveStageStep[];
  assignees?: { value: string; label: string }[];
  onOpen: (record: LveRow) => void;
  onSetStage: (stageId: string, record: LveRow) => void;
  onAssign: (assignee: string, record: LveRow) => void;
  onCopyId: (record: LveRow) => void;
  onDelete: (record: LveRow) => void;
  onClose: () => void;
}

export function ContextMenu({
  x, y, record, stages = [], assignees = [],
  onOpen, onSetStage, onAssign: _onAssign, onCopyId: _onCopyId, onDelete, onClose,
}: ContextMenuProps) {
  const menuRef = useRef<HTMLDivElement>(null);
  const [stageSubOpen, setStageSubOpen] = useState(false);

  // Close on outside click or Escape
  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) onClose();
    };
    const onEsc = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onEsc);
    };
  }, [onClose]);

  // Focus first focusable item when menu opens
  useEffect(() => {
    const firstBtn = menuRef.current?.querySelector<HTMLButtonElement>("button:not([disabled])");
    firstBtn?.focus();
  }, []);

  // Arrow-key navigation between top-level buttons in the menu
  const handleMenuKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    e.preventDefault();
    const btns = Array.from(
      menuRef.current?.querySelectorAll<HTMLButtonElement>(":scope > button:not([disabled]), :scope > div > button:not([disabled])") ?? []
    );
    const focused = document.activeElement as HTMLElement;
    const idx = btns.indexOf(focused as HTMLButtonElement);
    if (btns.length === 0) return;
    if (e.key === "ArrowDown") {
      btns[(idx + 1) % btns.length]?.focus();
    } else {
      btns[(idx - 1 + btns.length) % btns.length]?.focus();
    }
  };

  const clampedX = Math.min(x, window.innerWidth - 220);
  const clampedY = Math.min(y, window.innerHeight - 240);

  const itemStyle: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    gap: 8,
    width: "100%",
    padding: "6px 10px",
    borderRadius: "var(--radius-input)",
    cursor: "pointer",
    fontSize: 12.5,
    background: "none",
    border: "none",
    textAlign: "left",
    outline: "none",
  };

  const sep = (key: string) => <div key={key} style={{ height: 1, background: "var(--hair)", margin: "3px 0" }} />;

  return createPortal(
    <div
      ref={menuRef}
      onKeyDown={handleMenuKeyDown}
      style={{
        position: "fixed",
        top: clampedY,
        left: clampedX,
        zIndex: 500,
        width: 200,
        background: "var(--paper)",
        border: "1px solid var(--hair)",
        borderRadius: "var(--radius-card)",
        boxShadow: "var(--shadow-lg)",
        padding: 4,
      }}
    >
      {/* Open */}
      <button
        style={{ ...itemStyle, color: "var(--ink)" }}
        onClick={() => { onOpen(record); onClose(); }}
        onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
        onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
        onFocus={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
        onBlur={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
      >
        Open
      </button>

      {sep("s1")}

      {/* Set stage — keyboard: Enter/ArrowRight opens submenu */}
      {stages.length > 0 && (
        <div style={{ position: "relative" }}>
          <button
            style={{ ...itemStyle, color: "var(--ink)", justifyContent: "space-between" }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)";
              setStageSubOpen(true);
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLButtonElement).style.background = "";
              // Don't close here — submenu hover keeps it open; close on root mouse-leave
            }}
            onFocus={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
            onBlur={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
            onClick={() => setStageSubOpen(v => !v)}
            onKeyDown={e => {
              if (e.key === "ArrowRight" || e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                setStageSubOpen(true);
                // Focus first stage item
                setTimeout(() => {
                  const firstStageBtn = menuRef.current?.querySelector<HTMLButtonElement>(".ctx-sub-inner button");
                  firstStageBtn?.focus();
                }, 0);
              }
            }}
            aria-haspopup="true"
            aria-expanded={stageSubOpen}
          >
            Set stage <ChevronRight size={12} style={{ color: "var(--muted)" }} />
          </button>
          {stageSubOpen && (
            <div
              className="ctx-sub-inner"
              style={{
                position: "absolute",
                left: "100%", top: 0,
                width: 180,
                background: "var(--paper)",
                border: "1px solid var(--hair)",
                borderRadius: "var(--radius-card)",
                boxShadow: "var(--shadow-lg)",
                padding: 4,
              }}
              onMouseLeave={() => setStageSubOpen(false)}
            >
              {stages.map(s => (
                <button
                  key={s.id}
                  style={{ ...itemStyle, color: s.color, gap: 6 }}
                  onClick={() => { onSetStage(s.id, record); onClose(); }}
                  onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
                  onFocus={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
                  onBlur={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
                  onKeyDown={e => {
                    if (e.key === "Escape" || e.key === "ArrowLeft") {
                      e.preventDefault();
                      setStageSubOpen(false);
                      // Return focus to the "Set stage" trigger
                      const trigger = menuRef.current?.querySelector<HTMLButtonElement>("[aria-haspopup]");
                      trigger?.focus();
                    }
                  }}
                >
                  <span style={{ width: 5, height: 5, borderRadius: "50%", background: s.color, flexShrink: 0 }} />
                  {s.label}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Assign to… — disabled: no real picker available */}
      {assignees.length > 0 && (
        <button
          disabled
          title="Assignee picker not yet available"
          style={{ ...itemStyle, color: "var(--muted)", cursor: "not-allowed", opacity: 0.5 }}
        >
          Assign to…
        </button>
      )}

      {sep("s2")}

      {/* Copy ID */}
      <button
        style={{ ...itemStyle, color: "var(--ink)" }}
        onClick={() => { navigator.clipboard?.writeText(record.id); onClose(); }}
        onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
        onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
        onFocus={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
        onBlur={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
      >
        Copy ID
      </button>

      {sep("s3")}

      {/* Delete */}
      <button
        style={{ ...itemStyle, color: "var(--color-danger)" }}
        onClick={() => { onDelete(record); onClose(); }}
        onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
        onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
        onFocus={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--bone)"; }}
        onBlur={e => { (e.currentTarget as HTMLButtonElement).style.background = ""; }}
      >
        Delete
      </button>
    </div>,
    document.body
  );
}
