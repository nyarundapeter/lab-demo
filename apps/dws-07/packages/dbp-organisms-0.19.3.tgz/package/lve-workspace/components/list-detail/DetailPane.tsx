// components/ui/ds/lve/DetailPane.tsx
"use client";

import React, { createContext, useState } from "react";
import {
  Button,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@dbp/ui";
import {
  ArrowLeft, ChevronLeft, ChevronRight, X, Columns2, List, MoreHorizontal, Check,
} from "lucide-react";
import type { LveRow, LveStageStep } from "./types";
import { StepIndicator } from "./StepIndicator";

/**
 * DOM node for the detail header's title row, action-button area. Overview
 * content rendered inside DetailPane (e.g. the edit-mode save/cancel controls)
 * can portal into this node via `useLveEditHeaderSlot()` so those controls
 * render in the title row instead of a separate bar, without DetailPane
 * needing to know anything about edit-mode state.
 */
export const LveEditHeaderSlotContext = createContext<HTMLDivElement | null>(null);
export function useLveEditHeaderSlot() {
  return React.useContext(LveEditHeaderSlotContext);
}

interface DetailPaneProps {
  record: LveRow | null;
  recordIndex: number;
  totalRecords: number;
  mode?: "split" | "slide" | "focused";
  onClose: () => void;
  onUpdate: (patch: Partial<LveRow>) => void;
  onNavigate: (dir: 1 | -1) => void;
  onQuickAction?: (action: string, record: LveRow) => void;
  /** Toggle between split and slide-over mode */
  onModeToggle?: () => void;
  /** Rendered inside the Overview tab */
  overviewContent?: React.ReactNode;
  /** Rendered inside the Activity tab */
  activityContent?: React.ReactNode;
  /** Optional additional tabs beyond Overview/Activity (e.g. config.detailTabs[1..]) */
  extraTabs?: { label: string; content: React.ReactNode }[];
  /** Rendered inside the Contacts tab */
  contactsContent?: React.ReactNode;
  /** Rendered inside the Files tab */
  filesContent?: React.ReactNode;
  stages?: LveStageStep[];
  activeStageId?: string;
  onStageClick?: (stageId: string) => void;
  /** Hero title — defaults to record.id */
  titleKey?: string;
  /** Hero subtitle line */
  subtitleContent?: React.ReactNode;
  /** Badge rendered inline with the title (replaces stage pill) */
  titleBadge?: React.ReactNode;
  /** Metrics strip: up to 3 cells */
  metrics?: { label: string; value: React.ReactNode; accent?: boolean }[];
  /** Quick action buttons */
  quickActions?: { label: string; action: string }[];
  /** Overflow ("⋯") menu items. When empty/absent, no overflow menu is rendered — see no-disabled-placeholder-actions. */
  overflowActions?: { label: string; action: string; tone?: string }[];
  saveStatus?: "saved" | "saving" | "unsaved";
  /** Slot rendered in the control bar, between nav and save status */
  controlBarSlot?: React.ReactNode;
  /** When provided, replaces the config-driven StepIndicator block (workflow-bound stepper) */
  stepperOverride?: React.ReactNode;
  /** Rendered in the title row action area, before quick actions (workflow-bound actions) */
  headerActions?: React.ReactNode;
}


export function DetailPane({
  record, recordIndex, totalRecords,
  mode = "split",
  onClose, onUpdate: _onUpdate, onNavigate, onQuickAction,
  onModeToggle,
  overviewContent, activityContent, extraTabs = [],
  contactsContent, filesContent,
  stages, activeStageId, onStageClick,
  titleKey = "id",
  subtitleContent,
  titleBadge,
  metrics: _metrics = [],
  quickActions = [],
  overflowActions = [],
  saveStatus,
  controlBarSlot,
  stepperOverride,
  headerActions,
}: DetailPaneProps) {
  const [tab, setTab] = useState<string>("overview");
  const [editHeaderSlot, setEditHeaderSlot] = useState<HTMLDivElement | null>(null);

  const paneStyle: React.CSSProperties =
    mode === "slide"
      ? {
          position: "absolute", top: 0, right: 0, bottom: 0,
          width: 480,
          zIndex: 10,
          animation: "lve-slide-in 0.22s cubic-bezier(0.16,1,0.3,1)",
          boxShadow: "var(--shadow-lg)",
        }
      : mode === "focused"
      ? { flex: 1, minHeight: 0 }
      : { flex: 1, minHeight: 0 }; // split: fill remaining space beside card list

  if (!record) {
    return (
      <div style={{
        ...paneStyle,
        background: "var(--paper)",
        borderLeft: mode !== "focused" ? "1px solid var(--hair)" : undefined,
        display: "flex", alignItems: "center", justifyContent: "center",
        color: "var(--muted)", fontSize: 13, padding: 24, textAlign: "center",
      }}>
        <div>
          <div style={{ marginBottom: 8, display: "flex", justifyContent: "center" }}>
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <circle cx="14" cy="14" r="12" stroke="currentColor" strokeWidth="1.5"/>
            </svg>
          </div>
          Select a record to view details
        </div>
      </div>
    );
  }

  const title = record[titleKey] ? String(record[titleKey]) : record.id;
  const tabs: { key: string; label: string }[] = [
    { key: "overview", label: "Overview" },
    { key: "activity", label: "Activity" },
    ...extraTabs.map((t, i) => ({ key: `extra-${i}`, label: t.label })),
    ...(contactsContent !== undefined ? [{ key: "contacts", label: "Contacts" }] : []),
    ...(filesContent !== undefined ? [{ key: "files", label: "Files" }] : []),
  ];

  return (
    <LveEditHeaderSlotContext.Provider value={editHeaderSlot}>
      {/* Slide-over backdrop */}
      {mode === "slide" && (
        <div
          onClick={onClose}
          style={{ position: "absolute", inset: 0, background: "color-mix(in srgb, var(--color-text) 30%, transparent)", zIndex: 9 }}
        />
      )}
      <div style={{
        ...paneStyle,
        background: "var(--paper)",
        borderLeft: mode !== "focused" ? "1px solid var(--hair)" : undefined,
        display: "flex", flexDirection: "column", minWidth: 0,
        overflow: "hidden",
      }}>
        {/* Hero */}
        <div style={{ flexShrink: 0, borderBottom: "1px solid var(--hair)" }}>

          {/* Control bar */}
          <div style={{
            display: "flex", alignItems: "center", gap: 6,
            padding: "0 12px", height: 36,
            borderBottom: "1px solid var(--hair)",
          }}>
            {/* Back / close */}
            <button
              onClick={onClose}
              aria-label="Back"
              style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, color: "var(--muted)", background: "none", border: "none", cursor: "pointer", padding: "0 2px", borderRadius: "var(--radius-input)", height: 26, flexShrink: 0 }}
            >
              <ArrowLeft size={15} />
            </button>

            <span style={{ width: 1, height: 12, background: "var(--hair)", flexShrink: 0 }} />

            {/* Nav */}
            <button onClick={() => onNavigate(-1)} aria-label="Previous record" style={{ width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--muted)", background: "none", border: "none", cursor: "pointer", flexShrink: 0 }} title="Previous"><ChevronLeft size={15} /></button>
            <span style={{ fontSize: 10, fontFamily: "var(--mono)", color: "var(--muted)", padding: "0 4px", userSelect: "none", whiteSpace: "nowrap", flexShrink: 0 }}>
              {recordIndex + 1} / {totalRecords}
            </span>
            <button onClick={() => onNavigate(1)} aria-label="Next record" style={{ width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--muted)", background: "none", border: "none", cursor: "pointer", flexShrink: 0 }} title="Next"><ChevronRight size={15} /></button>

            <div style={{ flex: 1 }} />

            {controlBarSlot}

            {/* Save status indicator */}
            {saveStatus && (
              <span style={{
                fontSize: 11, flexShrink: 0,
                color: saveStatus === "unsaved" ? "var(--warn)" : saveStatus === "saving" ? "var(--muted)" : "var(--ok)",
              }}>
                {saveStatus === "unsaved" && "● Unsaved changes"}
                {saveStatus === "saving"  && "Saving…"}
                {saveStatus === "saved"   && <><Check size={14} style={{ display: "inline", verticalAlign: "middle", marginRight: 2 }} />Saved</>}
              </span>
            )}

            {onModeToggle && (
              <button
                style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: "var(--muted)", background: "none", border: "none", cursor: "pointer", padding: "0 4px", flexShrink: 0 }}
                onClick={onModeToggle}
                title="Toggle mode"
              >
                {mode === "focused" ? <><List size={14} /> List</> : <><Columns2 size={14} /> Focus</>}
              </button>
            )}
            <button
              aria-label="Close"
              className="dq-icon-btn"
              style={{
                display: "flex", alignItems: "center", justifyContent: "center",
                width: 26, height: 26, borderRadius: "var(--radius-input)",
                color: "var(--muted)", background: "transparent", border: "none",
                cursor: "pointer", flexShrink: 0,
                transition: "background 0.12s, color 0.12s",
              }}
              onClick={onClose}
              title="Close"
            >
              <X size={15} />
            </button>
          </div>

          {/* Identity block */}
          <div style={{ padding: "12px 16px 10px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, rowGap: 12, marginBottom: 5, flexWrap: "wrap" }}>
              <div style={{ flex: 1, minWidth: 0, display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                <div style={{
                  fontSize: mode === "focused" ? 24 : 22,
                  fontWeight: 600,
                  color: "var(--ink)",
                  lineHeight: 1.2,
                  padding: "2px 0",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}>
                  {title ?? ""}
                </div>
                {titleBadge}
              </div>
              {/* Action buttons — right side of identity block */}
              {(headerActions || quickActions.length > 0 || overflowActions.length > 0) && (
                <div style={{ display: "flex", gap: 6, flexShrink: 0, flexWrap: "wrap", alignItems: "center" }}>
                  {/* Portal target for edit-mode save/cancel controls (see LveEditHeaderSlotContext) */}
                  <div ref={setEditHeaderSlot} style={{ display: "contents" }} />
                  {headerActions}
                  {quickActions.map(qa => (
                    <Button
                      key={qa.action}
                      variant="outline"
                      size="sm"
                      className="h-7 px-2 text-xs"
                      onClick={() => {
                        if (qa.action === "note") setTab("activity");
                        onQuickAction?.(qa.action, record);
                      }}
                    >
                      {qa.label}
                    </Button>
                  ))}
                  {/* Overflow ("⋯") menu — only rendered when the host config supplies
                      configured items; there is no dead/no-op menu (no-disabled-placeholder-actions). */}
                  {overflowActions.length > 0 && (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button aria-label="More actions" style={{ height: 28, width: 28, border: "1px solid var(--hair)", background: "var(--paper)", borderRadius: "var(--radius-card)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--muted)" }}><MoreHorizontal size={15} /></button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {overflowActions.map(oa => (
                          <DropdownMenuItem
                            key={oa.action}
                            onClick={() => onQuickAction?.(oa.action, record)}
                            className={oa.tone === "danger" ? "text-[var(--color-danger,red)]" : undefined}
                          >
                            {oa.label}
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                </div>
              )}
            </div>
            {subtitleContent && (
              <div style={{ fontSize: 12, color: "var(--muted)", display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
                {subtitleContent}
              </div>
            )}
          </div>

          {/* Stage pipeline — step indicator */}
          {stepperOverride ? (
            <div style={{ padding: "4px 20px 16px", flexShrink: 0 }}>{stepperOverride}</div>
          ) : stages && stages.length > 0 && (
            <div style={{ padding: "4px 20px 16px", flexShrink: 0 }}>
              <StepIndicator
                steps={stages.map(s => ({ label: s.label }))}
                currentStep={Math.max(0, stages.findIndex(s => s.id === activeStageId))}
                {...(onStageClick ? { onStepClick: (i: number) => onStageClick(stages[i]!.id) } : {})}
              />
            </div>
          )}
        </div>

        {/* Tabs */}
        <div role="tablist" style={{ borderBottom: "1px solid var(--hair)", padding: "0 10px", display: "flex", gap: 2, flexShrink: 0 }}>
          {tabs.map(t => (
            <button
              key={t.key}
              role="tab"
              aria-selected={tab === t.key}
              onClick={() => setTab(t.key)}
              style={{
                height: 30, padding: "0 10px", fontSize: 13,
                background: "none", border: "none",
                borderBottom: tab === t.key ? "2px solid var(--accent)" : "2px solid transparent",
                color: tab === t.key ? "var(--ink)" : "var(--muted)",
                fontWeight: tab === t.key ? 500 : 400,
                cursor: "pointer",
                transition: "color 0.1s, border-color 0.1s",
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Tab body */}
        <div style={{ flex: 1, overflow: "auto", minHeight: 0 }}>
          {tab === "overview" && (overviewContent ?? <div style={{ padding: 24, color: "var(--muted)", fontSize: 13 }}>No overview content.</div>)}
          {tab === "activity" && (activityContent ?? <div style={{ padding: 24, color: "var(--muted)", fontSize: 13 }}>No activity.</div>)}
          {tab.startsWith("extra-") && extraTabs[Number(tab.slice(6))]?.content}
          {tab === "contacts" && (contactsContent ?? <div style={{ padding: 24, color: "var(--muted)", fontSize: 13 }}>No contacts.</div>)}
          {tab === "files" && (filesContent ?? <div style={{ padding: 24, color: "var(--muted)", fontSize: 13 }}>No files attached.</div>)}
        </div>
      </div>

      {/* Keyframe for slide animation */}
      <style>{`@keyframes lve-slide-in { from { transform: translateX(100%); } to { transform: translateX(0); } }`}</style>
    </LveEditHeaderSlotContext.Provider>
  );
}

// ── FieldRow helper — exported for use in overview tab content ────────────────

interface FieldRowProps {
  label: string;
  children: React.ReactNode;
}

export function FieldRow({ label, children }: FieldRowProps) {
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "120px 1fr",
      gap: 8, alignItems: "center",
      minHeight: 30,
      padding: "2px 0",
    }}>
      <span style={{ fontSize: 12, color: "var(--muted)" }}>{label}</span>
      <div style={{ fontSize: 13, fontWeight: 500, minWidth: 0 }}>{children}</div>
    </div>
  );
}

// ── SectionLabel helper ───────────────────────────────────────────────────────

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="eyebrow" style={{ marginBottom: 8 }}>{children}</div>
  );
}
