// components/ui/ds/lve/ListTable.tsx
"use client";

import { useState } from "react";
import { Checkbox, EmptyState } from "@dbp/ui";
import { ArrowUp, ArrowDown } from "lucide-react";
import type { LveRow, LveColumnDef, LveSortState, LveStageStep } from "./types";
import { EditableText, EditableSelect, EditableDate } from "./EditableField";
import { ContextMenu } from "./ContextMenu";

interface ListTableProps {
  columns: LveColumnDef[];
  rows: LveRow[];
  selection: Set<string>;
  setSelection: (s: Set<string>) => void;
  activeId: string | null;
  onRowClick: (id: string) => void;
  onUpdate: (id: string, patch: Partial<LveRow>) => void;
  sortBy: LveSortState;
  onSort: (field: string) => void;
  stages?: LveStageStep[];
  assigneeOptions?: { value: string; label: string }[];
  onContextSetStage?: (stageId: string, record: LveRow) => void;
  onContextAssign?: (assignee: string, record: LveRow) => void;
  onContextDelete?: (record: LveRow) => void;
  /** When true, the checkbox column is visible for multi-select. Default: false. */
  multiSelectMode?: boolean;
}

export function ListTable({
  columns, rows, selection, setSelection,
  activeId, onRowClick, onUpdate, sortBy, onSort,
  stages, assigneeOptions, onContextSetStage, onContextAssign, onContextDelete,
  multiSelectMode = false,
}: ListTableProps) {
  const [dragFrom, setDragFrom] = useState<number | null>(null);
  const [dragOver, setDragOver] = useState<number | null>(null);
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number; record: LveRow } | null>(null);

  // Show checkbox column when multi-select mode is active OR rows are already selected
  const showCheckboxes = multiSelectMode || selection.size > 0;

  const allSelected = rows.length > 0 && rows.every(r => selection.has(r.id));
  const someSelected = rows.some(r => selection.has(r.id)) && !allSelected;

  const toggleAll = () => {
    const next = new Set(selection);
    if (allSelected) rows.forEach(r => next.delete(r.id));
    else rows.forEach(r => next.add(r.id));
    setSelection(next);
  };

  const toggleOne = (id: string, checked: boolean) => {
    const next = new Set(selection);
    if (checked) next.add(id); else next.delete(id);
    setSelection(next);
  };

  const handleCellUpdate = (row: LveRow, col: LveColumnDef, value: unknown) => {
    onUpdate(row.id, { [col.key]: value });
  };

  return (
    <div style={{ flex: 1, overflow: "auto", minHeight: 0 }}>
      <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: 0 }}>
        <thead>
          <tr>
            {/* Checkbox col — only rendered when multi-select is active */}
            {showCheckboxes && (
              <th style={{ width: 36, padding: "0 4px 0 10px", position: "sticky", top: 0, background: "var(--bone)", borderBottom: "1px solid var(--hair)", zIndex: 1 }}>
                <Checkbox
                  checked={allSelected}
                  indeterminate={someSelected}
                  onCheckedChange={toggleAll}
                  aria-label="Select all rows"
                />
              </th>
            )}
            {/* Data cols */}
            {columns.map(col => (
              <th
                key={col.key}
                onClick={() => onSort(col.key)}
                style={{
                  position: "sticky", top: 0,
                  background: "var(--bone)",
                  borderBottom: "1px solid var(--hair)",
                  textAlign: (col.align ?? "left") as React.CSSProperties["textAlign"],
                  padding: "0 10px",
                  height: 36,
                  fontFamily: "var(--mono)",
                  fontSize: 11,
                  letterSpacing: "0.12em",
                  color: "var(--muted)",
                  userSelect: "none",
                  cursor: "pointer",
                  whiteSpace: "nowrap",
                  width: col.width,
                  zIndex: 1,
                }}
              >
                {col.label}
                {sortBy.field === col.key && (
                  <span style={{ marginLeft: 4, display: "inline-flex", verticalAlign: "middle" }}>
                    {sortBy.dir === "desc" ? <ArrowDown size={13} /> : <ArrowUp size={13} />}
                  </span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody
          onContextMenu={e => {
            const tr = (e.target as HTMLElement).closest("tr");
            if (!tr) return;
            const rowIdx = Array.from(tr.parentElement?.children ?? []).indexOf(tr);
            const row = rows[rowIdx];
            if (!row) return;
            e.preventDefault();
            setCtxMenu({ x: e.clientX, y: e.clientY, record: row });
          }}
        >
          {rows.map((row, i) => {
            const isActive = row.id === activeId;
            const isSelected = selection.has(row.id);
            return (
              <tr
                key={row.id}
                tabIndex={0}
                draggable
                onDragStart={() => setDragFrom(i)}
                onDragOver={e => { e.preventDefault(); setDragOver(i); }}
                onDragEnd={() => { setDragFrom(null); setDragOver(null); }}
                onDrop={() => { setDragFrom(null); setDragOver(null); }}
                onClick={() => onRowClick(row.id)}
                onKeyDown={(e: React.KeyboardEvent<HTMLTableRowElement>) => {
                  if (e.key === "Enter") { e.preventDefault(); onRowClick(row.id); }
                }}
                aria-selected={isActive}
                style={{
                  background: isActive ? "var(--lve-row-active)" : isSelected ? "var(--lve-row-selected)" : "transparent",
                  cursor: "pointer",
                  transition: "background 0.08s",
                  opacity: dragFrom === i ? 0.4 : 1,
                  outline: dragOver === i && dragFrom !== i ? "2px solid var(--color-primary)" : "none",
                  outlineOffset: -2,
                }}
                onFocus={(e: React.FocusEvent<HTMLTableRowElement>) => {
                  if (!isActive) e.currentTarget.style.outline = "2px solid var(--color-focus-ring, var(--color-primary))";
                }}
                onBlur={(e: React.FocusEvent<HTMLTableRowElement>) => {
                  if (dragOver !== i || dragFrom === i) e.currentTarget.style.outline = "";
                }}
                onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "var(--bone-2, var(--bone))"; }}
                onMouseLeave={e => { e.currentTarget.style.background = isActive ? "var(--lve-row-active)" : isSelected ? "var(--lve-row-selected)" : "transparent"; }}
              >
                {/* Checkbox — only rendered when multi-select is active */}
                {showCheckboxes && (
                  <td
                    style={{ width: 36, padding: "0 4px 0 10px", borderBottom: "1px solid var(--hair)", height: 36 }}
                    onClick={e => e.stopPropagation()}
                  >
                    <Checkbox
                      checked={isSelected}
                      onCheckedChange={checked => toggleOne(row.id, !!checked)}
                      aria-label={`Select row ${row.id}`}
                    />
                  </td>
                )}
                {/* Data cells */}
                {columns.map(col => {
                  const rawVal = row[col.key];
                  const val = rawVal === null || rawVal === undefined ? "" : String(rawVal);

                  let cellContent: React.ReactNode;
                  if (col.render) {
                    cellContent = col.render(rawVal, row);
                  } else if (col.editable && col.editType === "select" && col.editOptions) {
                    cellContent = (
                      <EditableSelect
                        value={val}
                        options={col.editOptions}
                        onSave={v => handleCellUpdate(row, col, v)}
                      />
                    );
                  } else if (col.editable && col.editType === "date") {
                    cellContent = (
                      <EditableDate
                        value={val}
                        onSave={v => handleCellUpdate(row, col, v)}
                      />
                    );
                  } else if (col.editable) {
                    cellContent = (
                      <EditableText
                        value={val}
                        onSave={v => handleCellUpdate(row, col, v)}
                      />
                    );
                  } else {
                    cellContent = val;
                  }

                  return (
                    <td
                      key={col.key}
                      style={{
                        padding: "0 10px",
                        height: 36,
                        borderBottom: "1px solid var(--hair)",
                        fontSize: 13,
                        fontFamily: col.mono ? "var(--mono)" : col.serif ? "var(--serif)" : "var(--sans)",
                        textAlign: (col.align ?? "left") as React.CSSProperties["textAlign"],
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        maxWidth: col.width ?? 200,
                        boxShadow: isActive && col.key === columns[0]?.key ? "inset 2px 0 0 var(--accent)" : undefined,
                      }}
                    >
                      {cellContent}
                    </td>
                  );
                })}
              </tr>
            );
          })}
          {rows.length === 0 && (
            <tr>
              <td colSpan={columns.length + (showCheckboxes ? 1 : 0)}>
                <EmptyState title="No records match your filters" />
              </td>
            </tr>
          )}
        </tbody>
      </table>
      {ctxMenu && (
        <ContextMenu
          x={ctxMenu.x}
          y={ctxMenu.y}
          record={ctxMenu.record}
          stages={stages ?? []}
          assignees={assigneeOptions ?? []}
          onOpen={record => onRowClick(record.id)}
          onSetStage={(stageId, record) => { onContextSetStage?.(stageId, record); }}
          onAssign={(assignee, record) => { onContextAssign?.(assignee, record); }}
          onCopyId={record => { navigator.clipboard?.writeText(record.id); }}
          onDelete={record => { onContextDelete?.(record); }}
          onClose={() => setCtxMenu(null)}
        />
      )}
    </div>
  );
}
