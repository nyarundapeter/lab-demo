"use client";

import React from "react";

// ── FormCard ──────────────────────────────────────────────────────────────────
// Bordered card with an inside title, used for grouped fields in detail panes.

interface FormCardProps {
  title: string;
  children: React.ReactNode;
}

export function FormCard({ title, children }: FormCardProps) {
  return (
    <div style={{
      border: "1px solid var(--hair)",
      borderRadius: "var(--radius-card)",
      background: "var(--paper)",
      overflow: "hidden",
    }}>
      <div style={{
        padding: "8px 14px",
        fontSize: 11, fontWeight: 700,
        letterSpacing: "0.12em", textTransform: "uppercase",
        color: "var(--muted)",
        borderBottom: "1px solid var(--hair)",
      }}>
        {title}
      </div>
      <div style={{ padding: "8px 14px", display: "flex", flexDirection: "column", gap: 2 }}>
        {children}
      </div>
    </div>
  );
}

// ── FormField ─────────────────────────────────────────────────────────────────
// Horizontal label + control row. Slot for any input, select, textarea, or ReadValue.

interface FormFieldProps {
  label: string;
  required?: boolean;
  layout?: "inline" | "stacked";
  /** Validation error (GAP 2). Rendered below the control in FG2 danger styling. */
  error?: string;
  children: React.ReactNode;
}

export function FormField({ label, required, layout = "inline", error, children }: FormFieldProps) {
  const errorNode = error ? (
    <span role="alert" style={{ fontSize: 11, color: "var(--color-danger)", marginTop: 2, display: "block" }}>
      {error}
    </span>
  ) : null;

  if (layout === "stacked") {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <span style={{ fontSize: 13, fontWeight: 500, color: "var(--ink)" }}>
          {label}
          {required && <span style={{ color: "var(--warn)", marginLeft: 2 }}>*</span>}
        </span>
        <div>{children}</div>
        {errorNode}
      </div>
    );
  }

  return (
    <div>
      <div style={{
        display: "grid",
        gridTemplateColumns: "110px 1fr",
        alignItems: "center",
        gap: 8,
        minHeight: 32,
      }}>
        <span style={{ fontSize: 12, color: "var(--muted)", userSelect: "none" }}>
          {label}
          {required && <span style={{ color: "var(--warn)", marginLeft: 2 }}>*</span>}
        </span>
        <div>{children}</div>
      </div>
      {errorNode && <div style={{ gridColumn: "2", marginLeft: 118 }}>{errorNode}</div>}
    </div>
  );
}

// ── ReadValue ─────────────────────────────────────────────────────────────────
// Plain text display for read-only fields — no border, no background.

interface ReadValueProps {
  children: React.ReactNode;
  mono?: boolean;
}

export function ReadValue({ children, mono }: ReadValueProps) {
  return (
    <span style={{
      fontSize: 13,
      color: "var(--ink)",
      fontFamily: mono ? "var(--mono)" : "inherit",
    }}>
      {children}
    </span>
  );
}

// ── Shared editable field style ───────────────────────────────────────────────
// Use this on <input>, <select>, <textarea> inside FormField.

export const fieldStyle: React.CSSProperties = {
  height: 30,
  width: "100%",
  padding: "0 8px",
  border: "none",
  borderRadius: "var(--radius-input)",
  background: "var(--color-surface)",
  fontSize: 13,
  color: "var(--ink)",
  outline: "none",
  fontFamily: "inherit",
};

// ── LveFormSection ────────────────────────────────────────────────────────────
// Flush section for the detail-pane edit panel. Uses the same eyebrow hierarchy
// as APP.F22: 10px uppercase muted title + bottom border separator.
// Fields stack vertically below — use with LveFormField for the stacked label pattern.

interface LveFormSectionProps {
  title: string;
  children: React.ReactNode;
}

export function LveFormSection({ title, children }: LveFormSectionProps) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{
        fontSize: 10,
        fontWeight: 600,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        color: "var(--muted)",
        paddingBottom: 6,
        marginBottom: 12,
        borderBottom: "1px solid var(--hair)",
      }}>
        {title}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {children}
      </div>
    </div>
  );
}

// ── LveFormField ──────────────────────────────────────────────────────────────
// Stacked label-above-control field for the detail-pane edit panel.
// Label is 13px medium sentence-case (not eyebrow). Matches APP.F22 QuestionField.

interface LveFormFieldProps {
  label: string;
  optional?: boolean;
  helper?: string;
  error?: string;
  children: React.ReactNode;
}

export function LveFormField({ label, optional, helper, error, children }: LveFormFieldProps) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 4 }}>
        <span style={{ fontSize: 13, fontWeight: 500, color: "var(--ink)" }}>{label}</span>
        {optional && (
          <span style={{ fontSize: 11, color: "var(--muted)", fontStyle: "italic" }}>(optional)</span>
        )}
      </div>
      {children}
      {helper && !error && (
        <span style={{ fontSize: 11, color: "var(--muted)" }}>{helper}</span>
      )}
      {error && (
        <span style={{ fontSize: 11, color: "var(--color-danger, red)" }}>{error}</span>
      )}
    </div>
  );
}
