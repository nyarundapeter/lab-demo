// components/ui/ds/lve/EditableField.tsx
"use client";

import { useEffect, useRef, useState } from "react";
import { Input, Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@dbp/ui";

// ── Hover affordance (injected once) ─────────────────────────────────────────
if (typeof document !== "undefined") {
  const id = "lve-editable-css";
  if (!document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = `
      .lve-editable { position: relative; transition: background 0.1s, box-shadow 0.1s; }
      .lve-editable:hover { background: var(--bone); box-shadow: 0 0 0 1px var(--hair); border-radius: 4px; }
    `;
    document.head.appendChild(s);
  }
}

// ── EditableText ──────────────────────────────────────────────────────────────

interface EditableTextProps {
  value: string;
  onSave: (v: string) => void;
  placeholder?: string;
  multiline?: boolean;
  allowEmpty?: boolean;
  style?: React.CSSProperties;
  className?: string;
}

export function EditableText({
  value, onSave,
  placeholder = "—",
  multiline = false,
  allowEmpty = false,
  style = {},
  className = "",
}: EditableTextProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const inputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => setDraft(value), [value]);
  useEffect(() => {
    if (editing) {
      const el = multiline ? textareaRef.current : inputRef.current;
      if (el) { el.focus(); el.select?.(); }
    }
  }, [editing, multiline]);

  const commit = () => {
    if (!allowEmpty && draft.trim() === "") { setDraft(value); setEditing(false); return; }
    if (draft !== value) onSave(draft);
    setEditing(false);
  };
  const cancel = () => { setDraft(value); setEditing(false); };

  if (editing) {
    const sharedKeyDown = (e: React.KeyboardEvent) => {
      e.stopPropagation();
      if (e.key === "Enter" && !multiline) { e.preventDefault(); commit(); }
      if (e.key === "Enter" && multiline && (e.metaKey || e.ctrlKey)) { e.preventDefault(); commit(); }
      if (e.key === "Escape") cancel();
    };
    if (multiline) {
      return (
        <textarea
          ref={textareaRef}
          value={draft}
          onChange={e => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={sharedKeyDown}
          style={{ width: "100%", minHeight: 60, padding: 8, fontSize: 13, fontFamily: "var(--sans)", resize: "vertical", ...style }}
        />
      );
    }
    return (
      <Input
        ref={inputRef}
        type="text"
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={sharedKeyDown}
        className="h-8 text-sm"
        style={style}
      />
    );
  }

  const hasValue = value !== undefined && value !== null && String(value).trim() !== "";
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => setEditing(true)}
      onKeyDown={(e: React.KeyboardEvent<HTMLDivElement>) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          setEditing(true);
        }
      }}
      className={`lve-editable ${className}`}
      style={{
        cursor: "text",
        padding: "3px 6px",
        margin: "-3px -6px",
        borderRadius: "var(--radius-input)",
        minHeight: 22,
        display: "inline-flex",
        alignItems: multiline ? "flex-start" : "center",
        color: hasValue ? "var(--ink)" : "var(--muted)",
        fontStyle: hasValue ? "normal" : "italic",
        maxWidth: "100%",
        whiteSpace: multiline ? "pre-wrap" : "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
        fontSize: 13,
        outline: "none",
        ...style,
      }}
      title="Click to edit"
      onFocus={(e: React.FocusEvent<HTMLDivElement>) => { e.currentTarget.style.boxShadow = "0 0 0 2px var(--color-focus-ring, var(--color-primary))"; }}
      onBlur={(e: React.FocusEvent<HTMLDivElement>) => { e.currentTarget.style.boxShadow = ""; }}
    >
      <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>
        {hasValue ? value : placeholder}
      </span>
    </div>
  );
}

// ── EditableSelect ────────────────────────────────────────────────────────────

interface EditableSelectProps {
  value: string;
  options: { value: string; label: string }[];
  onSave: (v: string) => void;
  render?: (opt: { value: string; label: string } | undefined) => React.ReactNode;
  placeholder?: string;
}

export function EditableSelect({ value, options, onSave, render, placeholder = "Select…" }: EditableSelectProps) {
  const selected = options.find(o => o.value === value);

  // When a render prop is provided, show the custom display in a wrapping click-trigger
  // and fall back to the @dbp/ui Select for the actual edit interaction.
  // For the common case (no render), use @dbp/ui Select directly with display text.
  if (render) {
    return (
      <Select value={value} onValueChange={onSave}>
        <SelectTrigger className="h-8 text-sm lve-editable" style={{ cursor: "pointer" }}>
          <span>{render(selected)}</span>
        </SelectTrigger>
        <SelectContent>
          {options.map(o => (
            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }

  return (
    <Select value={value} onValueChange={onSave}>
      <SelectTrigger className="h-8 text-sm lve-editable">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {options.map(o => (
          <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

// ── EditableDate ──────────────────────────────────────────────────────────────

interface EditableDateProps {
  value: string;
  onSave: (v: string) => void;
}

export function EditableDate({ value, onSave }: EditableDateProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => setDraft(value), [value]);
  useEffect(() => { if (editing && ref.current) ref.current.focus(); }, [editing]);

  if (editing) {
    return (
      <Input
        ref={ref}
        type="date"
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onBlur={() => { if (draft !== value) onSave(draft); setEditing(false); }}
        onKeyDown={e => { e.stopPropagation(); if (e.key === "Enter") e.currentTarget.blur(); if (e.key === "Escape") { setDraft(value); setEditing(false); } }}
        className="h-8 text-xs font-mono"
      />
    );
  }
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => setEditing(true)}
      onKeyDown={(e: React.KeyboardEvent<HTMLDivElement>) => {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setEditing(true); }
      }}
      className="lve-editable mono"
      style={{ cursor: "pointer", padding: "3px 6px", margin: "-3px -6px", borderRadius: "var(--radius-input)", fontSize: 12, color: "var(--ink)", outline: "none" }}
      onFocus={(e: React.FocusEvent<HTMLDivElement>) => { e.currentTarget.style.boxShadow = "0 0 0 2px var(--color-focus-ring, var(--color-primary))"; }}
      onBlur={(e: React.FocusEvent<HTMLDivElement>) => { e.currentTarget.style.boxShadow = ""; }}
    >
      {value || <span style={{ color: "var(--muted)", fontStyle: "italic" }}>—</span>}
    </div>
  );
}

// ── EditableNumber ────────────────────────────────────────────────────────────

interface EditableNumberProps {
  value: number;
  onSave: (v: number) => void;
  format?: (v: number) => string;
  prefix?: string;
}

export function EditableNumber({ value, onSave, format = String, prefix = "" }: EditableNumberProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(String(value));
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => setDraft(String(value)), [value]);
  useEffect(() => { if (editing && ref.current) { ref.current.focus(); ref.current.select(); } }, [editing]);

  const commit = () => {
    const n = Number(draft);
    if (!isNaN(n) && n !== value) onSave(n);
    setEditing(false);
  };

  if (editing) {
    return (
      <Input
        ref={ref}
        type="number"
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={e => { e.stopPropagation(); if (e.key === "Enter") commit(); if (e.key === "Escape") setEditing(false); }}
        className="h-8 text-sm font-mono"
      />
    );
  }
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => setEditing(true)}
      onKeyDown={(e: React.KeyboardEvent<HTMLDivElement>) => {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setEditing(true); }
      }}
      className="lve-editable mono"
      style={{ cursor: "pointer", padding: "3px 6px", margin: "-3px -6px", borderRadius: "var(--radius-input)", fontSize: 12, outline: "none" }}
      onFocus={(e: React.FocusEvent<HTMLDivElement>) => { e.currentTarget.style.boxShadow = "0 0 0 2px var(--color-focus-ring, var(--color-primary))"; }}
      onBlur={(e: React.FocusEvent<HTMLDivElement>) => { e.currentTarget.style.boxShadow = ""; }}
    >
      {prefix}{format(value)}
    </div>
  );
}
