import type { ReactNode } from "react";

export type LveRow = Record<string, unknown> & { id: string };

export type LveColumnDef = {
  key: string;
  label: string;
  width?: number | string;
  align?: "left" | "right" | "center";
  mono?: boolean;
  serif?: boolean;
  /** Double-click cell to edit inline */
  editable?: boolean;
  editType?: "text" | "select" | "date" | "number";
  editOptions?: { value: string; label: string }[];
  render?: (value: unknown, row: LveRow) => ReactNode;
};

export type LveFilter = {
  field: string;
  op: "is" | "contains" | ">" | "<";
  value: string;
};

export type LveSortState = {
  field: string;
  dir: "asc" | "desc";
};

export type LveStageStep = {
  id: string;
  label: string;
  color: string;
};

export type LveBulkAction = "status" | "assign" | "archive" | "delete";
