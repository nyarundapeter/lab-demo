# @dbp/organisms/lve-workspace

**registryId:** `APP.F19`

List-view-edit unified workspace: list + inline detail/edit panel, externalHeader-driven.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`LveWorkspaceConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `lve-split` layout. Also imported directly by `@dbp/organisms/workflow-binding` (APP.F23) as a workspace dependency.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/lve-workspace` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
