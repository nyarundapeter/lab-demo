"use client";
import * as React from "react";
import { createPortal } from "react-dom";
import {
  Alert, Badge, Button,
  Input,
  Select, SelectTrigger, SelectContent, SelectItem, SelectValue,
  LoadingSkeleton, ErrorCard,
  ActivityTimeline, ActivityComposer,
  ConflictBanner,
  type ActivityEntry, type ActivityDataState, type ActivityDraft, type ActivityTimelineConfig,
} from "@dbp/ui";
import {
  LveWorkspaceConfig,
  type LveWorkspaceConfigInput,
  type ActivityTabConfig,
  type RelationConfig,
  type DetailField as DetailFieldType,
} from "./types.js";
import { matchesAll } from "./lib/filter.js";
import { useEntityList, createEntity, updateEntity, useCreateEntity, ConflictError } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import { useQueryClient } from "@tanstack/react-query";
import { useActivityFeed } from "@dbp/ps-audit/client";
import RecordForm from "@dbp/organisms/record-form";
import type { FormDefinition, FormFieldType } from "@dbp/organisms/form-builder/types";
import { useSend } from "@dbp/ps-notif/client";
import { LveDsScope } from "./components/list-detail/ds-scope.js";
import { LveWorkspaceTemplate } from "./components/list-detail/LveWorkspaceTemplate.js";
import { useLveEditHeaderSlot } from "./components/list-detail/DetailPane.js";
import { FormCard, FormField, ReadValue, LveFormSection, LveFormField } from "./components/list-detail/FormCard.js";
import { EditableText } from "./components/list-detail/EditableField.js";
import type { LveRow, LveColumnDef, LveStageStep } from "./components/list-detail/types.js";
import type { AuditEvent } from "@dbp/ps-audit/client";

// Re-export types so consumers can import them from the package root.
export type {
  LveWorkspaceConfig,
  LveWorkspaceConfigInput,
  LveColumn,
  FilterClause,
  FilterPreset,
  StageStep,
  DetailTab,
  DetailSection,
  DetailField,
  QuickAction,
  OverflowAction,
  BulkAction,
  LveSection,
  ActivityTabConfig,
  RelationConfig,
} from "./types.js";

// ── toneToColor ───────────────────────────────────────────────────────────────

function toneToColor(tone: string | undefined): string {
  switch (tone) {
    case "info":    return "var(--color-primary)";
    case "success": return "var(--color-success)";
    case "warning": return "var(--color-warning)";
    case "danger":  return "var(--color-danger)";
    case "orange":  return "var(--color-secondary)";
    case "navy":    return "var(--color-primary)";
    case "neutral":
    default:        return "var(--color-text-muted)";
  }
}

// ── validateEditField ─────────────────────────────────────────────────────────
// GAP 2 fix. The LVE edit path has no access to the entity's full Zod schema
// client-side (solution/entities/*.ts is not threaded through to this
// package — see the generator note in the gap-fix commit message), so this
// validates from what IS available on a DetailField: its editType and, for
// selects, its editOptions. Empty strings are treated as "leave optional
// field blank" (DetailField carries no `required` flag today — a plumbing
// gap flagged for the generator, not something this validator can invent).
export function validateEditField(f: import("./types.js").DetailField, raw: string): string | null {
  if (raw.trim() === "") return null;
  if (f.editType === "number" && Number.isNaN(Number(raw))) {
    return `${f.label} must be a number`;
  }
  if (f.editType === "date" && Number.isNaN(Date.parse(raw))) {
    return `${f.label} must be a valid date`;
  }
  if (f.editType === "select" && f.editOptions && !f.editOptions.some(o => o.value === raw)) {
    return `${f.label} must be one of the listed options`;
  }
  return null;
}

// ── mapCreateEditType ─────────────────────────────────────────────────────────
// CreateField.editType ("text"|"number"|"date"|"select") → form-builder's
// FormFieldType — a strict subset, so this is a direct 1:1 map.
function mapCreateEditType(editType: "text" | "number" | "date" | "select"): FormFieldType {
  return editType;
}

// ── mapBadgeTone ──────────────────────────────────────────────────────────────

type BadgeTone = "default" | "gray" | "info" | "success" | "warning" | "danger" | "orange" | "navy";
const VALID_BADGE_TONES = new Set<string>(["default", "gray", "info", "success", "warning", "danger", "orange", "navy"]);

function mapBadgeTone(tone?: string): BadgeTone {
  if (!tone || tone === "neutral") return "gray";
  return VALID_BADGE_TONES.has(tone) ? (tone as BadgeTone) : "gray";
}

// ── toTitleCase — converts kebab-case / snake_case to Title Case ──────────────

function toTitleCase(val: string): string {
  return val
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, c => c.toUpperCase());
}

// ── formatCellValue ────────────────────────────────────────────────────────────

function formatCellValue(val: unknown, format: string | undefined): string {
  if (val === null || val === undefined) return "—";
  switch (format) {
    case "date": {
      const d = val instanceof Date ? val : new Date(String(val));
      return isNaN(d.getTime()) ? String(val) : d.toLocaleDateString();
    }
    case "datetime": {
      const d = val instanceof Date ? val : new Date(String(val));
      return isNaN(d.getTime()) ? String(val) : d.toLocaleString();
    }
    case "number":   return Number(val).toLocaleString();
    case "currency": return Number(val).toLocaleString(undefined, { style: "currency", currency: "AED" });
    case "percent":  return `${Number(val).toFixed(1)}%`;
    default:         return String(val);
  }
}

// ── Demo activity entries — shown when no real events are available ────────────

const DEMO_ACTIVITY_ENTRIES = [
  { id: "demo-1", initials: "AK", name: "Ahmad K.", action: "Status changed to In Progress", time: "2 hours ago" },
  { id: "demo-2", initials: "SA", name: "Sara A.", action: "Assigned to Sara A.", time: "Yesterday" },
  { id: "demo-3", initials: "SY", name: "System", action: "Record created", time: "3 days ago" },
] as const;

// ── LocalNote — optimistic note entries added by the user ─────────────────

interface LocalNote {
  id: string;
  initials: string;
  name: string;
  action: string;
  time: string;
  type: "note";
}

// ── NoteInput — sticky textarea + submit button ────────────────────

function NoteInput({ onSubmit }: { onSubmit: (text: string) => void }) {
  const [value, setValue] = React.useState("");
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);

  const handleSubmit = () => {
    const trimmed = value.trim();
    if (!trimmed) return;
    onSubmit(trimmed);
    setValue("");
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      handleSubmit();
    }
  };

  const isEmpty = value.trim().length === 0;

  return (
    <div className="shrink-0 border-t border-[var(--color-border)] bg-[var(--color-surface)] px-4 py-3">
      <textarea
        ref={textareaRef}
        rows={2}
        value={value}
        onChange={e => {
          setValue(e.target.value);
          e.target.style.height = "auto";
          e.target.style.height = `${Math.min(e.target.scrollHeight, 96)}px`;
        }}
        onKeyDown={handleKeyDown}
        placeholder="Add a note…"
        className="w-full resize-none rounded-md border border-[var(--color-border)] bg-[var(--color-surface-content)] px-3 py-2 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-muted)] focus:outline-none focus:ring-1 focus:ring-[var(--color-primary)] min-h-[36px] max-h-[96px]"
        style={{ overflow: "hidden" }}
      />
      <div className="mt-2 flex justify-end">
        <Button
          variant="outline"
          size="sm"
          disabled={isEmpty}
          onClick={handleSubmit}
        >
          Add Note
        </Button>
      </div>
    </div>
  );
}

// ── ActivityPanel ─────────────────────────────────────────────────────────────

function ActivityPanel({ entityId }: { entityId: string }) {
  const { events, loadMore, hasMore, isLoading, isFetchingNextPage } = useActivityFeed(entityId);

  const [localNotes, setLocalNotes] = React.useState<LocalNote[]>([]);

  const handleAddNote = React.useCallback((text: string) => {
    const note: LocalNote = {
      id: `note-${Date.now()}`,
      initials: "Y",
      name: "You",
      action: text,
      time: "Just now",
      type: "note",
    };
    setLocalNotes(prev => [note, ...prev]);
  }, []);

  if (isLoading) {
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <div className="flex-1 px-6 py-4">
          <LoadingSkeleton variant="list" rows={3} />
        </div>
        <NoteInput onSubmit={handleAddNote} />
      </div>
    );
  }

  const hasRealEvents = events.length > 0;

  if (!hasRealEvents && localNotes.length === 0) {
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <div className="flex-1 overflow-y-auto">
          {/* Demo entries */}
          <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: 10 }}>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--muted)", fontFamily: "var(--mono)", marginBottom: 4 }}>
              Demo entries
            </div>
            {DEMO_ACTIVITY_ENTRIES.map(entry => (
              <div key={entry.id} style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                <div style={{ width: 28, height: 28, flexShrink: 0, borderRadius: "50%", background: "var(--color-primary)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 600, color: "white", fontFamily: "var(--mono)", letterSpacing: "0.05em" }}>
                  {entry.initials}
                </div>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <span style={{ fontSize: 12, fontWeight: 500, color: "var(--ink)" }}>{entry.name}</span>
                  <span style={{ fontSize: 12, color: "var(--muted)" }}> · {entry.action}</span>
                  <div style={{ marginTop: 2, fontSize: 11, color: "var(--muted)", fontFamily: "var(--mono)" }}>
                    {entry.time}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <NoteInput onSubmit={handleAddNote} />
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex-1 overflow-y-auto">
        <div className="flex flex-col gap-2.5 px-4 py-3">
          {/* Local notes (optimistic) — always shown first */}
          {localNotes.map(note => (
            <div key={note.id} className="flex items-start gap-2.5 border-b border-[var(--hair)] pb-2.5">
              {/* Avatar circle — neutral for user notes */}
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[var(--color-text-muted)] font-mono text-xs font-semibold tracking-wide text-white">
                {note.initials}
              </div>
              <div className="min-w-0 flex-1">
                <span className="text-xs font-medium text-[var(--ink)]">{note.name}</span>
                <span className="text-xs text-[var(--muted)]"> · {note.action}</span>
                <div className="mt-0.5 font-mono text-xs text-[var(--muted)]">{note.time}</div>
              </div>
            </div>
          ))}
          {/* Real audit events */}
          {events.map((ev: AuditEvent) => (
        <div key={ev.id} className="flex flex-col gap-0.5 border-b border-[var(--hair)] pb-2.5">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[var(--ink)]">
              {ev.actor.displayName}
            </span>
            <span className="font-mono text-xs text-[var(--muted)]">
              {new Date(ev.ts).toLocaleString()}
            </span>
          </div>
          <div className="text-xs text-[var(--muted)]">
            {ev.action}
          </div>
          {ev.delta && Object.keys(ev.delta).length > 0 && (
            <div className="rounded font-mono text-xs text-[var(--muted)] bg-[var(--bone)] px-2 py-1">
              {Object.entries(ev.delta).map(([k, v]) => (
                <div key={k}>{k}: {String(v)}</div>
              ))}
            </div>
          )}
        </div>
      ))}
          {hasMore && (
            <button
              onClick={loadMore}
              disabled={isFetchingNextPage}
              className="self-center cursor-pointer bg-transparent border-0 px-2 py-1 text-xs text-[var(--accent)] disabled:opacity-50"
            >
              {isFetchingNextPage ? "Loading…" : "Load more"}
            </button>
          )}
        </div>
      </div>
      <NoteInput onSubmit={handleAddNote} />
    </div>
  );
}

// ── ActivityTabPanel — activity-timeline-spec-2026-07-10.md §7 config-gated upgrade ────────
// Renders the typed @dbp/ui ActivityTimeline + ActivityComposer molecules when the host
// supplies `config.activityTab`. Seeded from the same useActivityFeed audit trail as the
// legacy ActivityPanel above, plus notes persisted to a PS.DATA `<entityType>-note` sub-entity
// (spec §2/§7 item 4: "notes=PS.DATA", `<entity>-note` per the record-drawer decision). Note
// shape mirrors the spec's `body`/`plainText`/`tags`/`attachmentRefs` fields — `body` is the
// Tiptap JSON doc (ADR-0048), `plainText` is `editor.getText()`, `mentionedUserIds` are the
// `@mention` node ids extracted from `body`, notified via PS.NOTIF (spec §6.2, see handleSave
// below). `attachmentRefs` always empty (attachments deferred to `@dbp/ps-storage`, not built
// in this lane — see docs/03-features/specs/spec-ps-storage-requirements-2026-07-17.md). Actor
// identity is not yet resolved against ps-auth/ps-org — notes are attributed to "You"
// client-side; wiring real identity is a follow-up.

interface NoteEntityData extends EntityData {
  parentId: string;
  body: string;
  plainText: string;
  tags: string[];
  attachmentRefs: string[];
  actorName: string;
  mentionedUserIds: string[];
}

function auditEventToEntry(ev: AuditEvent): ActivityEntry {
  const deltaSummary =
    ev.delta && Object.keys(ev.delta).length > 0
      ? Object.entries(ev.delta).map(([k, v]) => `${k}: ${String(v)}`).join(", ")
      : undefined;
  return {
    id: ev.id,
    type: ev.action,
    actorName: ev.actor.displayName,
    timestamp: ev.ts,
    bodyText: deltaSummary ? `${ev.action} — ${deltaSummary}` : ev.action,
  };
}

function noteRecordToEntry(record: EntityRecord<NoteEntityData>): ActivityEntry {
  return {
    id: record.id,
    type: "note",
    actorName: record.data.actorName || "You",
    timestamp: record.createdAt,
    bodyText: record.data.plainText,
    ...(record.data.tags && record.data.tags.length > 0 ? { tags: record.data.tags } : {}),
  };
}

function ActivityTabPanel({
  entityId,
  parentEntityType,
  config,
}: {
  entityId: string;
  parentEntityType: string;
  config: ActivityTabConfig;
}) {
  const { events, isLoading, error } = useActivityFeed(entityId);
  const noteType = `${config.entityType ?? parentEntityType}-note`;
  const { rows: noteRows, isLoading: notesLoading, error: notesError } = useEntityList<NoteEntityData>(noteType, {
    filters: { parentId: entityId },
    pageSize: 200,
  });
  const { create: createNote } = useCreateEntity<NoteEntityData>(noteType);
  const { send: sendNotification } = useSend();

  const timelineConfig: ActivityTimelineConfig = {
    activityTypes: config.activityTypes,
    mentions: config.mentions,
    tags: config.tags,
    attachments: config.attachments,
    ...(config.entityType !== undefined ? { entityType: config.entityType } : {}),
    ...(config.labels !== undefined ? { labels: config.labels } : {}),
  };

  const entries = React.useMemo(() => {
    const notes = noteRows.map(noteRecordToEntry).sort((a, b) => b.timestamp.localeCompare(a.timestamp));
    return [...notes, ...events.map(auditEventToEntry)];
  }, [noteRows, events]);

  const combinedLoading = isLoading || notesLoading;
  const combinedError = error ?? notesError;
  const state: ActivityDataState = combinedLoading
    ? "loading"
    : combinedError
      ? "error"
      : entries.length === 0
        ? "empty"
        : "populated";

  const handleSave = React.useCallback(
    (draft: ActivityDraft) => {
      void createNote({
        parentId: entityId,
        body: draft.body,
        plainText: draft.plainText,
        tags: draft.tags,
        attachmentRefs: [],
        actorName: "You",
        mentionedUserIds: draft.mentionedUserIds,
      });
      // ADR-0048 §6.2 — mention → PS.NOTIF wiring. type "info" (tier "optional", see
      // packages/stack/platform-services/notif/client/types.ts NOTIFICATION_TYPE_TIER):
      // per the taxonomy (@dbp/contracts notification-taxonomy.ts) "action" means "work the
      // user must complete" — being @mentioned in a note is "user should know", not a task,
      // so "info" is the accurate type. It stays opt-in (non-mandatory tier) via preferences.
      for (const userId of draft.mentionedUserIds) {
        const mentionedBy = config.labels?.mentionActorName ?? "You";
        sendNotification({
          to: userId,
          type: "info",
          message: (config.labels?.mentionNotificationMessage ?? "{actor} mentioned you in a note").replace(
            "{actor}",
            mentionedBy,
          ),
          channel: "in-app",
        });
      }
    },
    [config.labels, createNote, entityId, sendNotification],
  );

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex-1 overflow-y-auto p-4">
        <ActivityTimeline config={timelineConfig} state={state} entries={entries} />
      </div>
      <div className="shrink-0 border-t border-[var(--color-border)] bg-[var(--color-surface)] p-3">
        <ActivityComposer config={timelineConfig} mentionCandidates={config.mentionCandidates} onSave={handleSave} />
      </div>
    </div>
  );
}

// ── relationValuesEqual — array-aware equality for EditModeOverview dirty-check ─
// Relation fields store string[] internally (even scalar ones, see buildInitial
// below); a fresh array is built on every buildInitial() call, so a naive `!==`
// would treat an unchanged relation field as dirty on every render. Compares by
// content for arrays, falls back to `===` for plain strings.

function relationValuesEqual(a: string | string[] | undefined, b: string | string[] | undefined): boolean {
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((v, i) => v === b[i]);
  }
  return a === b;
}

// ── RelationPicker — searchable chip picker backed by another entity type ─────
// Used by EditModeOverview for DetailFields with editType:"relation". Internal
// state is always string[] (chips); `multiple: false` (scalar FK fields, e.g.
// remediation.findingId/controlId/testId/owner) replaces the selection on add
// instead of appending — the string[]<->string boundary conversion lives in
// EditModeOverview's buildInitial()/handleSave(), not here.

const RELATION_DROPDOWN_CAP = 100;

interface RelationPickerProps {
  value: string[];
  onChange: (next: string[]) => void;
  relation: RelationConfig;
}

function RelationPicker({ value, onChange, relation }: RelationPickerProps) {
  const [search, setSearch] = React.useState("");
  const [open, setOpen] = React.useState(false);
  // Defaults to true (back-compat, existing array-backed relation fields).
  const multi = relation.multiple !== false;

  const { rows: rawRows } = useEntityList<EntityData>(relation.entityType, {
    filters: {},
    page: 1,
    pageSize: 200,
  });
  const records = React.useMemo(
    () => rawRows.map((r: EntityRecord<EntityData>) => ({ id: r.id, ...(r.data as object) }) as Record<string, unknown>),
    [rawRows],
  );

  const searchFields = relation.searchFields ?? [relation.labelField];
  const filtered = React.useMemo(() => {
    const q = search.trim().toLowerCase();
    return records
      .filter(r => !value.includes(String(r["id"])))
      .filter(r => !q || searchFields.some(f => String(r[f] ?? "").toLowerCase().includes(q)))
      .slice(0, RELATION_DROPDOWN_CAP);
  }, [records, value, search, searchFields]);

  const labelFor = React.useCallback(
    (id: string) => {
      const r = records.find(rr => String(rr["id"]) === id);
      return r ? String(r[relation.labelField] ?? id) : id;
    },
    [records, relation.labelField],
  );

  // multi: false (single-value picker) replaces the current selection instead
  // of appending — picking a new owner/finding/control/test swaps it, it
  // doesn't add a second one.
  const addId = (id: string) => {
    onChange(multi ? [...value, id] : [id]);
    setSearch("");
    setOpen(false);
  };

  const removeId = (id: string) => {
    onChange(value.filter(v => v !== id));
  };

  const showSearch = multi || value.length === 0;

  return (
    <div className="flex flex-col gap-1.5">
      {value.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          {value.map(id => (
            <Badge key={id} tone="gray" size="sm">
              {labelFor(id)}
              <button
                type="button"
                aria-label={`Remove ${labelFor(id)}`}
                className="ml-1 cursor-pointer bg-transparent border-0 p-0 text-[var(--muted)]"
                onClick={() => removeId(id)}
              >
                ×
              </button>
            </Badge>
          ))}
        </div>
      )}
      {showSearch && (
        <div className="relative">
          <Input
            type="text"
            className="h-8 text-sm"
            placeholder="Search…"
            value={search}
            onFocus={() => setOpen(true)}
            onChange={e => { setSearch(e.target.value); setOpen(true); }}
          />
          {open && filtered.length > 0 && (
            <div className="absolute z-10 mt-1 max-h-48 w-full overflow-y-auto rounded-md border border-[var(--color-border)] bg-white shadow-md">
              {filtered.map(r => (
                <button
                  key={String(r["id"])}
                  type="button"
                  className="block w-full cursor-pointer bg-transparent border-0 px-3 py-1.5 text-left text-sm hover:bg-[var(--color-surface)]"
                  onClick={() => addId(String(r["id"]))}
                >
                  {String(r[relation.labelField] ?? r["id"])}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── EditModeOverview ──────────────────────────────────────────────────────────
// Extracted component so it can hold the controlled-edit state (hooks not
// allowed inside useCallback). Rendered when defaultEditMode === "edit".

interface EditModeOverviewProps {
  record: LveRow;
  config: LveWorkspaceConfig;
  onUpdate: (patch: Partial<LveRow>) => void;
  onSave?: (id: string, changes: Record<string, unknown>) => void;
}

function EditModeOverview({ record, config, onUpdate, onSave }: EditModeOverviewProps) {
  const firstTab = config.detailTabs[0];

  // Collect all DetailField objects from detailTabs[0] into a flat lookup by field name.
  // Used by the sections-based rendering path.
  const allDetailFields = React.useMemo(() => {
    const map = new Map<string, import("./types.js").DetailField>();
    if (firstTab) {
      for (const section of firstTab.sections) {
        for (const f of section.fields) {
          map.set(f.field, f);
        }
      }
    }
    return map;
  }, [firstTab]);

  // Initialise from record; re-init when record.id changes (new record selected)
  const buildInitial = React.useCallback(() => {
    const vals: Record<string, string | string[]> = {};
    if (!firstTab) return vals;
    for (const section of firstTab.sections) {
      for (const f of section.fields) {
        const val = record[f.field];
        if (f.editType === "relation") {
          // multiple: false (scalar relation, e.g. remediation's findingId/
          // controlId/testId/owner) — the record field is a plain string, not
          // string[]. RelationPicker's internal state is always an array; wrap
          // a non-empty scalar into a single-element array here, unwrapped
          // again in handleSave() below.
          if (f.relation?.multiple === false) {
            vals[f.field] = typeof val === "string" && val ? [val] : [];
          } else {
            vals[f.field] = Array.isArray(val) ? val.map(String) : [];
          }
        } else {
          vals[f.field] = val === null || val === undefined ? "" : String(val);
        }
      }
    }
    return vals;
    // Intentionally re-derive only on record.id change, not on every field-set-shape
    // change — buildInitial reads `record` via closure and is expected to change
    // identity each render; keying on record.id avoids an infinite re-init loop.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [record.id]);

  const [editValues, setEditValues] = React.useState<Record<string, string | string[]>>(buildInitial);
  // GAP 2 — per-field validation errors, keyed by field name. Cleared on cancel
  // and whenever a field the error was on changes.
  const [fieldErrors, setFieldErrors] = React.useState<Record<string, string>>({});

  // Reset when selected record changes
  React.useEffect(() => {
    setEditValues(buildInitial());
    setFieldErrors({});
    // See note above: keyed on record.id, not buildInitial, to avoid re-triggering
    // on every render (buildInitial's identity changes each render).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [record.id]);

  // See note above: keyed on record.id, not buildInitial.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const originalValues = React.useMemo(() => buildInitial(), [record.id]);

  const isDirty = React.useMemo(
    () => Object.keys(editValues).some(k => !relationValuesEqual(editValues[k], originalValues[k])),
    [editValues, originalValues],
  );

  const handleSave = () => {
    const changes: Record<string, unknown> = {};
    const errors: Record<string, string> = {};
    for (const [k, v] of Object.entries(editValues)) {
      if (relationValuesEqual(v, originalValues[k])) continue;
      const fieldDef = allDetailFields.get(k);
      if (typeof v === "string") {
        const err = fieldDef ? validateEditField(fieldDef, v) : null;
        if (err) {
          errors[k] = err;
          continue;
        }
      }
      if (fieldDef?.editType === "relation" && fieldDef.relation?.multiple === false) {
        // Unwrap RelationPicker's array-backed internal state back to the
        // scalar string the entity schema expects (see buildInitial() above).
        changes[k] = Array.isArray(v) ? (v[0] ?? "") : v;
      } else {
        changes[k] = v;
      }
    }
    // GAP 2 — block save and surface field-level errors when any changed value
    // fails its editType/editOptions constraint. No PATCH is issued.
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      return;
    }
    setFieldErrors({});
    onUpdate(changes as Partial<LveRow>);
    onSave?.(record.id, changes);
  };

  const setFieldValue = (field: string, v: string) => {
    setEditValues(prev => ({ ...prev, [field]: v }));
    if (fieldErrors[field]) setFieldErrors(prev => { const next = { ...prev }; delete next[field]; return next; });
  };

  const handleCancel = () => {
    setEditValues(buildInitial());
    setFieldErrors({});
  };

  if (!firstTab) return null;

  // ── Helper: render a single field's input ──────────────────────────────────
  const renderFieldInput = (f: DetailFieldType) => {
    const err = fieldErrors[f.field];
    const errorClass = err ? "border-[var(--color-danger)] focus-visible:ring-[var(--color-danger)]" : "";

    if (f.editType === "relation" && f.relation) {
      const relVal = editValues[f.field];
      const arrVal = Array.isArray(relVal) ? relVal : (typeof relVal === "string" && relVal ? [relVal] : []);
      return (
        <FormField key={f.field} label={f.label} layout={config.detailFormLayout} {...(err ? { error: err } : {})}>
          <RelationPicker
            value={arrVal}
            onChange={next => setEditValues(prev => ({ ...prev, [f.field]: next }))}
            relation={f.relation}
          />
        </FormField>
      );
    }

    const val = typeof editValues[f.field] === "string" ? (editValues[f.field] as string) : "";

    if (f.editType === "select" && f.editOptions) {
      return (
        <FormField key={f.field} label={f.label} layout={config.detailFormLayout} {...(err ? { error: err } : {})}>
          <Select
            value={val}
            onValueChange={v => setFieldValue(f.field, v)}
          >
            <SelectTrigger className={`h-8 text-sm ${errorClass}`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {f.editOptions.map(o => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FormField>
      );
    }

    if (f.editType === "date") {
      return (
        <FormField key={f.field} label={f.label} layout={config.detailFormLayout} {...(err ? { error: err } : {})}>
          <Input
            type="date"
            className={`h-8 text-sm ${errorClass}`}
            value={val}
            onChange={e => setFieldValue(f.field, e.target.value)}
          />
        </FormField>
      );
    }

    if (f.editType === "number") {
      return (
        <FormField key={f.field} label={f.label} layout={config.detailFormLayout} {...(err ? { error: err } : {})}>
          <Input
            type="number"
            className={`h-8 text-sm ${errorClass}`}
            value={val}
            onChange={e => setFieldValue(f.field, e.target.value)}
          />
        </FormField>
      );
    }

    // Default: text input (edit-first — no click-to-edit)
    return (
      <FormField key={f.field} label={f.label} layout={config.detailFormLayout} {...(err ? { error: err } : {})}>
        <Input
          type="text"
          className={`h-8 text-sm ${errorClass}`}
          value={val}
          onChange={e => setFieldValue(f.field, e.target.value)}
        />
      </FormField>
    );
  };

  // ── Build left-column content ──────────────────────────────────────────────
  // If config.sections is provided, render fields grouped by those flat sections
  // (field names → DetailField lookup). Fields not assigned to any section are
  // collected into an implicit "Details" section appended at the end.
  // Otherwise fall back to the existing detailTabs[0].sections (DetailSection[]) layout.
  let leftColumnContent: React.ReactNode;

  if (config.sections && config.sections.length > 0) {
    const assignedFieldNames = new Set(config.sections.flatMap(s => s.fields));
    const ungrouped = Array.from(allDetailFields.values()).filter(f => !assignedFieldNames.has(f.field));

    leftColumnContent = (
      <div className="space-y-6">
        {config.sections.map(section => {
          const sectionFields = section.fields
            .map(name => allDetailFields.get(name))
            .filter((f): f is import("./types.js").DetailField => f !== undefined);

          if (sectionFields.length === 0) return null;

          return (
            <div key={section.title}>
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
                {section.title}
              </h3>
              <div className="space-y-3">
                {sectionFields.map(renderFieldInput)}
              </div>
            </div>
          );
        })}
        {ungrouped.length > 0 && (
          <div key="__implicit_details__">
            <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
              Details
            </h3>
            <div className="space-y-3">
              {ungrouped.map(renderFieldInput)}
            </div>
          </div>
        )}
      </div>
    );
  } else {
    leftColumnContent = firstTab.sections.map(section => (
      <FormCard key={section.title} title={section.title}>
        {section.fields.map(renderFieldInput)}
      </FormCard>
    ));
  }

  const hasRail = config.detailRail.length > 0;

  // N28 — save/cancel controls render in the detail header's title row
  // (portaled via LveEditHeaderSlotContext), not as a standalone bar. They
  // only appear while the record is dirty.
  const editHeaderSlot = useLveEditHeaderSlot();
  const headerControls = isDirty && editHeaderSlot
    ? createPortal(
        <div className="flex items-center gap-2" data-testid="lve-edit-affordance-controls">
          <span className="text-xs text-[var(--muted)]">Unsaved changes</span>
          <Button variant="outline" size="sm" className="h-7 px-3 text-xs" onClick={handleCancel}>
            Cancel
          </Button>
          <Button size="sm" className="h-7 px-3 text-xs" onClick={handleSave}>
            Save changes
          </Button>
        </div>,
        editHeaderSlot,
      )
    : null;

  return (
    <div key={record.id} className="flex flex-col">
      {headerControls}
      {/* grid: 1 or 2 columns depending on whether detailRail is present */}
      <div
        className="grid items-start p-5"
        style={{ gridTemplateColumns: hasRail ? config.detailGridColumns : "1fr", gap: config.detailGridGap }}
      >
        {/* Left column: grouped sections or detailTab sections */}
        <div className="flex flex-col gap-4">
          {leftColumnContent}
        </div>

        {/* Right column: detailRail cards (read-only metadata) */}
        {hasRail && (
          <div className="flex flex-col gap-4">
            {config.detailRail.map(card => (
              <FormCard key={card.title} title={card.title}>
                {card.kind === "badges" && (
                  <div className="flex flex-wrap items-center gap-1.5">
                    {card.fields.map(f => {
                      const v = record[f.field];
                      if (!v) return null;
                      const vals = Array.isArray(v) ? v : [v];
                      return vals.map((vv, i) => (
                        <Badge key={`${f.field}-${i}`} tone="gray" size="sm">
                          {String(vv)}
                        </Badge>
                      ));
                    })}
                  </div>
                )}
                {card.kind === "linked" && (
                  <div className="flex flex-col gap-1.5">
                    {card.fields.map(f => {
                      const v = record[f.field];
                      if (!v) return null;
                      return (
                        <div key={f.field} className="flex items-center gap-2">
                          <span className="w-20 shrink-0 text-xs text-[var(--muted)]">{f.label}</span>
                          <span className="rounded-full border border-[var(--hair)] bg-[var(--bone)] px-2 py-0.5 font-mono text-xs text-[var(--ink)]">
                            {String(v)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
                {(card.kind === "fields" || !card.kind) && card.fields.map(f => (
                  <FormField key={f.field} label={f.label} layout={config.detailFormLayout}>
                    <ReadValue mono={f.format === "number" || f.format === "currency"}>
                      {formatCellValue(record[f.field], f.format)}
                    </ReadValue>
                  </FormField>
                ))}
              </FormCard>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Type accepted ─────────────────────────────────────────────────────────────
type ConfigInput = LveWorkspaceConfigInput;

/**
 * APP.F19 — LVE Workspace (List–View–Edit) — list-detail template edition
 *
 * Receives CONFIG only — no data props. All data flows through PS.DATA hooks.
 * Config is validated at render time via LveWorkspaceConfig.safeParse.
 * A config-error state is rendered (not thrown) on invalid config.
 *
 * Emitted CustomEvents:
 *   dbp:lve:inline-edit      { entityType, id, field, value }
 *   dbp:lve:stage-change     { entityType, id, from, to }
 *   dbp:lve:quick-action     { entityType, id, action }
 *   dbp:lve:bulk-action      { entityType, action, ids }
 */
export interface LveDetailExtras {
  /** Workflow-bound stepper — replaces the config-driven stages StepIndicator in the detail pane */
  stepper?: (record: LveRow) => React.ReactNode;
  /** Workflow-bound actions rendered in the detail title row, before quick actions */
  headerActions?: (record: LveRow) => React.ReactNode;
  /** Additional detail tab (e.g. workflow progress history / audit trail). Takes precedence over a second config detailTab. */
  extraTab?: { label: string; content: (record: LveRow) => React.ReactNode };
  /**
   * GG-12 (option b) — executes a quickAction/overflowAction that declared
   * `engineAction` (types.ts's QuickAction) instead of `patch`. The host
   * supplies this using its own workflow binding (e.g.
   * `@dbp/organism-workflow-binding`'s useRecordWorkflow) to call
   * advanceInstance/rejectInstance for the record's bound instance. When
   * absent, an `engineAction` quickAction is a no-op (dispatches its
   * `dbp:lve:quick-action` event only) — same "unwired affordance" behavior
   * as any other host-optional extra.
   */
  onQuickAction?: (action: "advance" | "reject", record: LveRow) => void | Promise<void>;
}

/**
 * Typed change callbacks (ADR-0040) — the sanctioned alternative to listening
 * for the stringly-typed `dbp:lve:*` DOM CustomEvents. The events still fire
 * (deprecated, kept one release for existing consumers); callbacks fire in
 * addition, after the PS.DATA mutation succeeds. LveWorkspace already maintains
 * its own react-query cache (invalidate on mutate), so consumers need no
 * hand-patching — these hooks are for host-level reactions (header toggling,
 * side-panel sync, analytics), not cache management.
 */
export interface LveWorkspaceCallbacks {
  /** List ↔ split view transitions (replaces the `dbp:lve:view-change` listener). */
  onViewChange?: (mode: "list" | "split") => void;
  /** Any successful record patch (inline edit, stage change, quick action). */
  onFieldChange?: (recordId: string, patch: Record<string, unknown>) => void;
  /** Convenience: fired when a successful patch includes the `assignee` field. */
  onAssigneeChange?: (recordId: string, assignee: string | null) => void;
}

export default function LveWorkspace({
  detailExtras,
  callbacks,
  ...rawConfig
}: ConfigInput & { detailExtras?: LveDetailExtras; callbacks?: LveWorkspaceCallbacks }) {
  const parseResult = LveWorkspaceConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert
        tone="danger"
        title="LveWorkspace configuration error"
        data-testid="lve-config-error"
      >
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const config = parseResult.data;
  return (
    <LveDsScope data-testid="lve-workspace">
      <LveWorkspaceInner
        config={config}
        {...(detailExtras ? { detailExtras } : {})}
        {...(callbacks ? { callbacks } : {})}
      />
    </LveDsScope>
  );
}

// ── Inner component — config guaranteed valid ─────────────────────────────────

interface LveWorkspaceInnerProps {
  config: LveWorkspaceConfig;
  detailExtras?: LveDetailExtras;
  callbacks?: LveWorkspaceCallbacks;
}

function LveWorkspaceInner({ config, detailExtras, callbacks }: LveWorkspaceInnerProps) {
  const queryClient = useQueryClient();

  // ── PS.DATA — load all rows (demo-scale, pageSize 200) ───────────────────
  // PS.DATA caps pageSize at 200; the list-detail template paginates client-side.
  const { rows: rawRows, isLoading, error } = useEntityList<EntityData>(config.entityType, {
    filters: {},
    page: 1,
    pageSize: 200,
  });

  // Map EntityRecord → LveRow
  const rows: LveRow[] = React.useMemo(() => {
    return rawRows.map((r: EntityRecord<EntityData>) => ({
      id: r.id,
      ...(r.data as object),
      _record: r,
    }));
  }, [rawRows]);

  // ── Save status ───────────────────────────────────────────────────────────
  const [saveStatus, setSaveStatus] = React.useState<"idle" | "saving" | "saved">("idle");
  const saveTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const flashSaved = React.useCallback(() => {
    setSaveStatus("saving");
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      setSaveStatus("saved");
      saveTimerRef.current = setTimeout(() => setSaveStatus("idle"), 1500);
    }, 300);
  }, []);

  // Unmounting mid-flash (or a test tearing down the environment) must not let
  // a queued setTimeout fire setSaveStatus against a gone component/window.
  React.useEffect(() => {
    return () => {
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    };
  }, []);

  // ── Conflict state (spec-ps-data-revisions-2026-07-17.md §4) — a 412 from
  // either the inline list edit or the detail-pane save (both route through
  // onRowUpdate below) populates this; ConflictBanner renders instead of a
  // silent failure until the user resolves it.
  const [conflict, setConflict] = React.useState<{
    id: string;
    mine: Partial<EntityData>;
    theirs: EntityRecord<EntityData>;
  } | null>(null);

  // ── Row update — PS.DATA mutation ─────────────────────────────────────────
  const onRowUpdate = React.useCallback(async (
    id: string,
    patch: Partial<LveRow>,
    opts?: { silent?: boolean },
  ) => {
    flashSaved();
    try {
      await updateEntity<EntityData>(config.entityType, id, patch as Partial<EntityData>);
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity-list", config.entityType] });
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity", config.entityType, id] });
      // Dispatch inline-edit events per field — only on success, and only when not suppressed
      if (!opts?.silent) {
        for (const [field, value] of Object.entries(patch)) {
          document.dispatchEvent(new CustomEvent("dbp:lve:inline-edit", {
            detail: { entityType: config.entityType, id, field, value },
            bubbles: true,
          }));
        }
      }
      // ADR-0040 typed callbacks — fire after the mutation succeeds (never on error).
      callbacks?.onFieldChange?.(id, patch as Record<string, unknown>);
      if ("assignee" in patch) {
        callbacks?.onAssigneeChange?.(id, (patch as Record<string, unknown>)["assignee"] as string | null);
      }
    } catch (err) {
      setSaveStatus("idle");
      if (err instanceof ConflictError) {
        setConflict({ id, mine: patch as Partial<EntityData>, theirs: err.current as EntityRecord<EntityData> });
      }
    }
  }, [config.entityType, queryClient, flashSaved, callbacks]);

  // ── Conflict resolution — mirrors useEntity()'s resolveConflict (spec §5). ──
  const resolveConflict = React.useCallback(async (action: "refresh" | "overwrite" | "saveAsNew") => {
    if (!conflict) return;
    if (action === "refresh") {
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity-list", config.entityType] });
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity", config.entityType, conflict.id] });
      setConflict(null);
      return;
    }
    if (action === "overwrite") {
      await updateEntity<EntityData>(config.entityType, conflict.id, conflict.mine, {
        ...(conflict.theirs.version !== undefined && { expectedRevision: conflict.theirs.version }),
      });
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity-list", config.entityType] });
      void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity", config.entityType, conflict.id] });
      setConflict(null);
      return;
    }
    // saveAsNew — creates a new record from `mine`; the original record is left untouched.
    await createEntity<EntityData>(config.entityType, { ...conflict.theirs.data, ...conflict.mine } as EntityData);
    void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity-list", config.entityType] });
    setConflict(null);
  }, [conflict, config.entityType, queryClient]);

  // ── Create (GAP 1) ────────────────────────────────────────────────────────
  // "+ New" opens @dbp/organisms/record-form (APP.F24) in drawer placement,
  // built from config.createConfig. Absent createConfig → no button, no drawer.
  const [createOpen, setCreateOpen] = React.useState(false);

  const createFormDefinition: FormDefinition | null = React.useMemo(() => {
    const cc = config.createConfig;
    if (!cc) return null;
    const now = new Date().toISOString();
    return {
      id: `${config.entityType}-create`,
      entityType: config.entityType,
      version: 1,
      status: "published",
      sections: [
        {
          id: "main",
          title: cc.title ?? `New ${config.entityLabel}`,
          fields: cc.fields.map(f => ({
            id: f.field,
            label: f.label,
            type: mapCreateEditType(f.editType),
            required: f.required,
            span: "full" as const,
            ...(f.editOptions ? { options: f.editOptions } : {}),
          })),
        },
      ],
      crossFieldRules: [],
      submitLabel: "Create",
      labels: { title: cc.title ?? `New ${config.entityLabel}` },
      successMessage: `${config.entityLabel} created.`,
      createdAt: now,
      updatedAt: now,
    };
  }, [config.createConfig, config.entityType, config.entityLabel]);

  const onNew = React.useCallback(() => setCreateOpen(true), []);

  const onCreateSubmit = React.useCallback(async (values: Record<string, unknown>) => {
    const payload = { ...config.createConfig?.defaults, ...values };
    await createEntity<EntityData>(config.entityType, payload as EntityData);
    void queryClient.invalidateQueries({ queryKey: ["ps-data", "entity-list", config.entityType] });
    document.dispatchEvent(new CustomEvent("dbp:lve:record-created", {
      detail: { entityType: config.entityType },
      bubbles: true,
    }));
    setCreateOpen(false);
  }, [config.createConfig, config.entityType, queryClient]);

  // ── Map config.columns → LveColumnDef[] ──────────────────────────────────
  const columns: LveColumnDef[] = React.useMemo(() => {
    return config.columns.map(col => {
      const def: LveColumnDef = {
        key: col.field,
        label: col.label,
        ...(col.width !== undefined ? { width: parseInt(col.width, 10) || col.width } : {}),
        ...(col.align !== undefined ? { align: col.align } : {}),
        ...(col.mono !== undefined ? { mono: col.mono } : {}),
        editable: col.editable,
        ...(col.editType !== undefined ? { editType: col.editType } : {}),
        ...(col.editOptions !== undefined ? { editOptions: col.editOptions } : {}),
      };

      if (col.format === "badge" && col.badgeTones) {
        const tones = col.badgeTones;
        def.render = (val: unknown) => {
          const key = String(val ?? "");
          const tone = tones[key];
          return (
            <Badge tone={mapBadgeTone(tone)} size="sm">
              {toTitleCase(key)}
            </Badge>
          );
        };
      } else if (col.format && col.format !== "text") {
        const fmt = col.format;
        def.render = (val: unknown) => (
          <span className={`text-sm text-[var(--muted)] ${col.mono ? "font-mono" : ""}`}>
            {formatCellValue(val, fmt)}
          </span>
        );
      }

      return def;
    });
  }, [config.columns]);

  // ── Map config.listTabs → LveWorkspaceTemplate listTabs ──────────────────
  const listTabs = React.useMemo(() => {
    return config.listTabs.map(tab => {
      type Tab = { key: string; label: string; filter?: (row: LveRow) => boolean };
      const t: Tab = { key: tab.key, label: tab.label };
      if (tab.where.length > 0) {
        t.filter = (row: LveRow) => matchesAll(row, tab.where);
      }
      return t;
    });
  }, [config.listTabs]);

  // ── Map config.quickFilters → quick filter chips ──────────────────────────
  const quickFilters = React.useMemo(() => {
    return config.quickFilters.map(qf => ({
      key: qf.key,
      label: qf.label,
      filter: (row: LveRow) => matchesAll(row, qf.where),
    }));
  }, [config.quickFilters]);

  // ── Stages ────────────────────────────────────────────────────────────────
  const detailStages: LveStageStep[] = React.useMemo(() => {
    return config.stages.map(s => ({
      id: s.id,
      label: s.label,
      color: toneToColor(s.tone),
    }));
  }, [config.stages]);

  // ── Stage click → update stageField ──────────────────────────────────────
  const onStageClick = React.useCallback(async (stageId: string, record: LveRow) => {
    const prev = config.stageField ? String(record[config.stageField] ?? "") : "";
    await onRowUpdate(record.id, { [config.stageField ?? "status"]: stageId }, { silent: true });
    document.dispatchEvent(new CustomEvent("dbp:lve:stage-change", {
      detail: { entityType: config.entityType, id: record.id, from: prev, to: stageId },
      bubbles: true,
    }));
  }, [config.stageField, config.entityType, onRowUpdate]);

  // ── Quick actions ─────────────────────────────────────────────────────────
  const detailQuickActions = React.useCallback((record: LveRow) => {
    return config.quickActions
      .filter(qa => matchesAll(record, qa.when))
      .map(qa => ({ label: qa.label, action: qa.action }));
  }, [config.quickActions]);

  // ── Detail overflow ("⋯") menu items — same `when`/`patch` shape as quickActions ─────
  const detailOverflowActions = React.useCallback((record: LveRow) => {
    return config.overflowActions
      .filter(oa => matchesAll(record, oa.when))
      .map(oa => ({ label: oa.label, action: oa.action, ...(oa.tone !== undefined ? { tone: oa.tone } : {}) }));
  }, [config.overflowActions]);

  const onDetailQuickAction = React.useCallback(async (action: string, record: LveRow) => {
    const qa = config.quickActions.find(q => q.action === action) ?? config.overflowActions.find(q => q.action === action);
    // GG-12 (option b) — engineAction quickActions route through the host's
    // workflow binding instead of a raw PS.DATA patch; see LveDetailExtras.onQuickAction.
    const qaEngineAction = (qa as { engineAction?: "advance" | "reject" } | undefined)?.engineAction;
    if (qaEngineAction) {
      await detailExtras?.onQuickAction?.(qaEngineAction, record);
    } else if (qa?.patch) {
      await onRowUpdate(record.id, qa.patch as Partial<LveRow>, { silent: true });
    }
    document.dispatchEvent(new CustomEvent("dbp:lve:quick-action", {
      detail: { entityType: config.entityType, id: record.id, action },
      bubbles: true,
    }));
  }, [config.quickActions, config.overflowActions, config.entityType, onRowUpdate, detailExtras]);

  // ── Bulk actions ──────────────────────────────────────────────────────────
  const bulkActions = React.useMemo(
    () => config.bulkActions.map(ba => ({ label: ba.label, action: ba.action })),
    [config.bulkActions],
  );

  const onBulkAction = React.useCallback((action: string, ids: string[]) => {
    const ba = config.bulkActions.find(b => b.action === action);
    if (ba?.patch) {
      ids.forEach(id => void onRowUpdate(id, ba.patch as Partial<LveRow>));
    }
    document.dispatchEvent(new CustomEvent("dbp:lve:bulk-action", {
      detail: { entityType: config.entityType, action, ids },
      bubbles: true,
    }));
  }, [config.bulkActions, config.entityType, onRowUpdate]);

  // ── Card keys ─────────────────────────────────────────────────────────────
  const cardLabelKey = config.header?.titleField ?? config.columns[0]?.field ?? "id";
  const cardSublabelKey = config.header?.subtitleField;
  const cardStatusKey = config.header?.statusField;

  // ── Card dot colors — derived from stages (tone → CSS variable) ──────────
  const cardDotColors: Record<string, string> | undefined = React.useMemo(() => {
    if (!config.stageField || config.stages.length === 0) return undefined;
    const map: Record<string, string> = {};
    for (const s of config.stages) {
      map[s.id] = toneToColor(s.tone);
    }
    return map;
  }, [config.stageField, config.stages]);

  // ── Detail overview content ────────────────────────────────────────────────
  const detailOverviewContent = React.useCallback((record: LveRow, onUpdate: (patch: Partial<LveRow>) => void) => {
    // Edit-first mode: render EditModeOverview which holds controlled state + Save/Cancel.
    if (config.defaultEditMode === "edit") {
      return (
        <EditModeOverview
          record={record}
          config={config}
          onUpdate={onUpdate}
        />
      );
    }

    // Readonly mode: original click-to-edit behaviour preserved.
    const firstTab = config.detailTabs[0];
    if (!firstTab) return null;

    return (
      // key={record.id} remounts the overview when the SELECTED record changes (id is stable
      // across edits to the same record), so uncontrolled text inputs re-bind to the new record.
      <div
        key={record.id}
        className="grid items-start p-5"
        style={{ gridTemplateColumns: config.detailRail.length > 0 ? config.detailGridColumns : "1fr", gap: config.detailGridGap }}
      >
        {/* Left column: sections from first detailTab */}
        <div className="flex flex-col gap-2">
          {firstTab.sections.map(section => (
            <LveFormSection key={section.title} title={section.title}>
              {section.fields.map(f => {
                const val = record[f.field];
                const strVal = val === null || val === undefined ? "" : String(val);

                if (f.editable && f.editType === "select" && f.editOptions) {
                  return (
                    <LveFormField key={f.field} label={f.label}>
                      <Select
                        value={strVal}
                        onValueChange={v => {
                          onUpdate({ [f.field]: v });
                          document.dispatchEvent(new CustomEvent("dbp:lve:inline-edit", {
                            detail: { entityType: config.entityType, id: record.id, field: f.field, value: v },
                            bubbles: true,
                          }));
                        }}
                      >
                        <SelectTrigger className="h-8 text-sm">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {f.editOptions.map(o => (
                            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </LveFormField>
                  );
                }

                if (f.editable && f.editType === "date") {
                  return (
                    <LveFormField key={f.field} label={f.label}>
                      <Input
                        type="date"
                        className="h-8 text-sm"
                        value={strVal}
                        onChange={e => onUpdate({ [f.field]: e.target.value })}
                        onBlur={e => {
                          document.dispatchEvent(new CustomEvent("dbp:lve:inline-edit", {
                            detail: { entityType: config.entityType, id: record.id, field: f.field, value: e.target.value },
                            bubbles: true,
                          }));
                        }}
                      />
                    </LveFormField>
                  );
                }

                if (f.editable && f.editType === "number") {
                  return (
                    <LveFormField key={f.field} label={f.label}>
                      <Input
                        type="number"
                        className="h-8 text-sm"
                        value={strVal}
                        onChange={e => onUpdate({ [f.field]: e.target.value })}
                        onBlur={e => {
                          const n = Number(e.target.value);
                          if (!isNaN(n)) {
                            onUpdate({ [f.field]: n });
                            document.dispatchEvent(new CustomEvent("dbp:lve:inline-edit", {
                              detail: { entityType: config.entityType, id: record.id, field: f.field, value: n },
                              bubbles: true,
                            }));
                          }
                        }}
                      />
                    </LveFormField>
                  );
                }

                if (f.editable) {
                  // Inline-edit text: reads as a clean value, becomes an input only
                  // on click (no always-on boxy form field). Edit is the "E" in LVE.
                  return (
                    <LveFormField key={f.field} label={f.label}>
                      <EditableText
                        value={strVal}
                        onSave={v => {
                          onUpdate({ [f.field]: v });
                          document.dispatchEvent(new CustomEvent("dbp:lve:inline-edit", {
                            detail: { entityType: config.entityType, id: record.id, field: f.field, value: v },
                            bubbles: true,
                          }));
                        }}
                      />
                    </LveFormField>
                  );
                }

                // Read-only
                return (
                  <LveFormField key={f.field} label={f.label}>
                    <ReadValue mono={f.format === "number" || f.format === "currency" || f.format === "percent"}>
                      {formatCellValue(val, f.format)}
                    </ReadValue>
                  </LveFormField>
                );
              })}
            </LveFormSection>
          ))}
        </div>

        {/* Right column: detailRail cards */}
        {config.detailRail.length > 0 && (
          <div className="flex flex-col gap-4">
            {config.detailRail.map(card => (
              <FormCard key={card.title} title={card.title}>
                {card.kind === "badges" && (
                  <div className="flex flex-wrap items-center gap-1.5">
                    {card.fields.map(f => {
                      const val = record[f.field];
                      if (!val) return null;
                      const vals = Array.isArray(val) ? val : [val];
                      return vals.map((v, i) => (
                        <Badge key={`${f.field}-${i}`} tone="gray" size="sm">
                          {String(v)}
                        </Badge>
                      ));
                    })}
                  </div>
                )}
                {card.kind === "linked" && (
                  <div className="flex flex-col gap-1.5">
                    {card.fields.map(f => {
                      const val = record[f.field];
                      if (!val) return null;
                      return (
                        <div key={f.field} className="flex items-center gap-2">
                          <span className="w-20 shrink-0 text-xs text-[var(--muted)]">{f.label}</span>
                          <span className="rounded-full border border-[var(--hair)] bg-[var(--bone)] px-2 py-0.5 font-mono text-xs text-[var(--ink)]">
                            {String(val)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
                {(card.kind === "fields" || !card.kind) && card.fields.map(f => (
                  <FormField key={f.field} label={f.label}>
                    <ReadValue mono={f.format === "number" || f.format === "currency"}>
                      {formatCellValue(record[f.field], f.format)}
                    </ReadValue>
                  </FormField>
                ))}
              </FormCard>
            ))}
          </div>
        )}
      </div>
    );
  }, [config]);

  // ── Detail extra tabs (all detailTabs beyond the first — that one is the Overview tab) ──
  const detailExtraTabs = config.detailTabs.slice(1).map(tab => ({
    label: tab.label,
    content: (record: LveRow) => (
      <div className="flex flex-col gap-4 p-5">
        {tab.sections.map(section => (
          <FormCard key={section.title} title={section.title}>
            {section.fields.map(f => (
              <FormField key={f.field} label={f.label}>
                <ReadValue>{formatCellValue(record[f.field], f.format)}</ReadValue>
              </FormField>
            ))}
          </FormCard>
        ))}
      </div>
    ),
  }));

  // ── Activity tab ───────────────────────────────────────────────────────────
  const detailActivityContent = React.useCallback((record: LveRow) => (
    config.activityTab
      ? <ActivityTabPanel entityId={record.id} parentEntityType={config.entityType} config={config.activityTab} />
      : <ActivityPanel entityId={record.id} />
  ), [config.activityTab, config.entityType]);

  // ── Title badge ───────────────────────────────────────────────────────────
  const detailTitleBadge = React.useCallback((record: LveRow) => {
    if (!config.header?.statusField) return undefined;
    const val = record[config.header.statusField];
    if (!val) return undefined;
    // Look up the tone from the status badge-column's badgeTones map if available
    const statusCol = config.columns.find(c => c.field === config.header?.statusField && c.format === "badge");
    const tone = statusCol?.badgeTones?.[String(val)];
    return (
      <Badge tone={mapBadgeTone(tone)} size="sm">
        {toTitleCase(String(val))}
      </Badge>
    );
  }, [config.header?.statusField, config.columns]);

  // ── Save status mapping (idle→undefined, saving/saved → template prop) ────
  const detailSaveStatus: "saving" | "saved" | undefined =
    saveStatus === "idle" ? undefined : saveStatus;

  // ── Loading state ─────────────────────────────────────────────────────────
  if (isLoading && rows.length === 0) {
    return (
      <div className="px-6 py-4">
        <LoadingSkeleton variant="list" rows={6} />
      </div>
    );
  }

  // ── Error state ───────────────────────────────────────────────────────────
  if (error && rows.length === 0) {
    return (
      <div className="px-6 py-4">
        <ErrorCard message="Failed to load records." />
      </div>
    );
  }

  return (
    <>
    {conflict && (
      <div className="px-6 pt-4" data-testid="lve-conflict-banner-wrap">
        <ConflictBanner
          updatedByLabel={conflict.theirs.updatedBy ?? "Someone else"}
          updatedAtLabel={conflict.theirs.updatedAt}
          fields={Object.keys(conflict.mine).map((field) => {
            const col = config.columns.find((c) => c.field === field);
            return {
              field,
              label: col?.label ?? field,
              mine: String((conflict.mine as Record<string, unknown>)[field]),
              theirs: String((conflict.theirs.data as Record<string, unknown>)[field]),
            };
          })}
          canOverwrite
          onResolve={(action) => void resolveConflict(action)}
        />
      </div>
    )}
    <LveWorkspaceTemplate
      {...(config.title !== undefined ? { title: config.title } : {})}
      {...(config.subtitle !== undefined ? { meta: config.subtitle } : {})}
      {...(config.breadcrumb.length > 0 ? { eyebrow: config.breadcrumb.map((b) => b.label).join("  /  ") } : {})}
      hideListHeader={config.externalHeader}
      mobileCardList={config.mobileCardList}
      entityLabel={config.entityLabel}
      columns={columns}
      rows={rows}
      onNew={onNew}
      showNewButton={Boolean(config.createConfig)}
      onRowUpdate={onRowUpdate}
      {...(callbacks?.onViewChange ? { onViewChange: callbacks.onViewChange } : {})}
      // Card list keys
      cardLabelKey={cardLabelKey}
      {...(cardSublabelKey !== undefined ? { cardSublabelKey } : {})}
      {...(cardStatusKey !== undefined ? { cardStatusKey } : {})}
      {...(config.stageField !== undefined ? { cardDotColorKey: config.stageField } : {})}
      {...(cardDotColors !== undefined ? { cardDotColors } : {})}
      // Rail keys (mirror card keys)
      railLabelKey={cardLabelKey}
      {...(cardSublabelKey !== undefined ? { railSubLabelKey: cardSublabelKey } : {})}
      // List tabs + quick filters
      {...(listTabs.length > 0 ? { listTabs } : {})}
      {...(quickFilters.length > 0 ? { quickFilters } : {})}
      // Sort
      {...(config.sortFields.length > 0 ? { sortFields: config.sortFields } : {})}
      pageSizeOptions={config.pageSizeOptions}
      // Detail props
      {...(config.header?.titleField !== undefined ? { detailTitleKey: config.header.titleField } : {})}
      detailTitleBadge={detailTitleBadge}
      {...(config.header?.subtitleField !== undefined
        ? {
            detailSubtitleContent: (record: LveRow) => (
              <span>{String(record[config.header!.subtitleField!] ?? "")}</span>
            ),
          }
        : {})}
      {...(detailStages.length > 0 ? { detailStages } : {})}
      {...(config.stageField !== undefined ? { detailActiveStageKey: config.stageField } : {})}
      detailQuickActions={detailQuickActions}
      detailOverflowActions={detailOverflowActions}
      onDetailQuickAction={onDetailQuickAction}
      onStageClick={onStageClick}
      detailOverviewContent={detailOverviewContent}
      detailActivityContent={detailActivityContent}
      {...((detailExtras?.extraTab ? [detailExtras.extraTab, ...detailExtraTabs.slice(1)] : detailExtraTabs).length > 0
        ? { detailExtraTabs: detailExtras?.extraTab ? [detailExtras.extraTab, ...detailExtraTabs.slice(1)] : detailExtraTabs }
        : {})}
      {...(detailSaveStatus !== undefined ? { detailSaveStatus } : {})}
      {...(detailExtras?.stepper ? { detailStepperOverride: detailExtras.stepper } : {})}
      {...(detailExtras?.headerActions ? { detailHeaderActions: detailExtras.headerActions } : {})}
      // Bulk
      {...(bulkActions.length > 0 ? { bulkActions } : {})}
      onBulkAction={onBulkAction}
      showFooter
    />
    {createFormDefinition && (
      <RecordForm
        formDefinition={createFormDefinition}
        placement="drawer"
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCancel={() => setCreateOpen(false)}
        onSubmit={onCreateSubmit}
        showRequesterMeta={false}
      />
    )}
    </>
  );
}

// ── Primitive re-exports ──────────────────────────────────────────────────────
export { StepIndicator } from "./components/list-detail/StepIndicator.js";
export type { LveRow } from "./components/list-detail/types.js";
// LveFormSection + LveFormField: stacked edit-panel primitives (eyebrow title +
// top-aligned 13px label above control). Use in detailOverviewContent render fns
// to compose the detail pane as an organised form.
export { LveFormSection, LveFormField };
// Compact grid-layout primitives (label-left / value-right) for read-only display.
export { FormCard, FormField, ReadValue };
export { EditableText } from "./components/list-detail/EditableField.js";
export { EditableSelect, EditableDate, EditableNumber } from "./components/list-detail/EditableField.js";
// LveDsScope: design-token mapping scope (--paper/--bone/--ink/…). Non-LVE consumers of the
// primitive re-exports above need this wrapper or they fall back to browser initial values.
export { LveDsScope } from "./components/list-detail/ds-scope.js";
// ActivityPanel + NoteInput: the standard activity/notes surface used when the host does not
// supply `config.activityTab` (see ActivityTabPanel below for the config-gated upgrade, which
// is invoked internally via config and does not need a direct export). Exported so non-LVE
// consumers can rebuild this surface without reimplementing it against @dbp/ps-audit/client.
export { ActivityPanel, NoteInput };
