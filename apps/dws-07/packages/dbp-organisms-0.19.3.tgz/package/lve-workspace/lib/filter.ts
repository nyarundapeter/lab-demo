/**
 * Pure filter utilities for LVE Workspace.
 * No React imports — safe for unit tests and server contexts.
 *
 * PS.DATA only supports equality filters. All other ops (contains, >, in, etc.)
 * are applied client-side on the returned page via matchesAll / evaluateClause.
 */
import type { FilterClause } from "../types.js";

/**
 * Evaluate a single FilterClause against a row.
 * Row values are treated as unknown; comparisons are best-effort.
 */
export function evaluateClause(
  row: Record<string, unknown>,
  clause: FilterClause,
): boolean {
  const raw = row[clause.field];

  switch (clause.op) {
    case "is":
      return String(raw ?? "") === String(clause.value ?? "");

    case "isNot":
      return String(raw ?? "") !== String(clause.value ?? "");

    case "contains": {
      if (clause.value === undefined || clause.value === null) return true;
      const haystack = String(raw ?? "").toLowerCase();
      const needle = String(clause.value).toLowerCase();
      return haystack.includes(needle);
    }

    case ">": {
      if (clause.value === undefined) return false;
      const n = Number(raw);
      const v = Number(clause.value);
      return Number.isFinite(n) && Number.isFinite(v) && n > v;
    }

    case "<": {
      if (clause.value === undefined) return false;
      const n = Number(raw);
      const v = Number(clause.value);
      return Number.isFinite(n) && Number.isFinite(v) && n < v;
    }

    case ">=": {
      if (clause.value === undefined) return false;
      const n = Number(raw);
      const v = Number(clause.value);
      return Number.isFinite(n) && Number.isFinite(v) && n >= v;
    }

    case "<=": {
      if (clause.value === undefined) return false;
      const n = Number(raw);
      const v = Number(clause.value);
      return Number.isFinite(n) && Number.isFinite(v) && n <= v;
    }

    case "in": {
      if (!Array.isArray(clause.value)) return false;
      const vals = (clause.value as string[]).map((v) => String(v));
      return vals.includes(String(raw ?? ""));
    }

    case "isEmpty":
      return raw === null || raw === undefined || String(raw) === "";

    case "isNotEmpty":
      return raw !== null && raw !== undefined && String(raw) !== "";

    default:
      return true;
  }
}

/**
 * Returns true when the row satisfies ALL clauses (AND logic).
 * Empty array → true.
 */
export function matchesAll(
  row: Record<string, unknown>,
  clauses: FilterClause[],
): boolean {
  return clauses.every((c) => evaluateClause(row, c));
}

/**
 * Extracts only "is" equality clauses with scalar (non-array) values into the
 * flat key→value map that PS.DATA's `filters` option accepts.
 *
 * All other ops must be applied client-side via matchesAll.
 */
export function toServerFilters(
  clauses: FilterClause[],
): Record<string, string | number | boolean> {
  const out: Record<string, string | number | boolean> = {};
  for (const c of clauses) {
    if (
      c.op === "is" &&
      c.value !== undefined &&
      c.value !== null &&
      !Array.isArray(c.value)
    ) {
      out[c.field] = c.value as string | number | boolean;
    }
  }
  return out;
}
