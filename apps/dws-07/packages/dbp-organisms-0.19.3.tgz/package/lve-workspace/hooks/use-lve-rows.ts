"use client";
import { useEntityList } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import { matchesAll } from "../lib/filter.js";
import type { FilterClause } from "../types.js";

interface UseLveRowsOptions {
  /** All non-equality clauses from the active tab + quick filters. Used client-side. */
  clientClauses: FilterClause[];
  /** Equality clauses already extracted for server-side filtering. */
  serverFilters: Record<string, string | number | boolean>;
  /** Free-text search string. Applied client-side across all string columns. */
  search: string;
  /** Fields to search across when a search query is active. */
  searchableFields: string[];
  page: number;
  pageSize: number;
  /**
   * Optional client-side sort applied to the filtered rows before returning.
   * NOTE: sort applies to the loaded page only — consistent with the existing
   * client-side filter limitation. For cross-page ordering push sort to the server.
   */
  sort?: { field: string; dir: "asc" | "desc" };
}

interface UseLveRowsResult {
  rows: EntityRecord<EntityData>[];
  total: number;
  pageSize: number;
  page: number;
  isLoading: boolean;
  error: Error | null;
}

/**
 * Wraps useEntityList and applies:
 * 1. Server-side equality filters (toServerFilters output).
 * 2. Client-side non-equality clause matching (matchesAll).
 * 3. Free-text search across searchableFields.
 *
 * NOTE: Client-side filtering operates on the current page only.
 * For best results, equality filters should be pushed to the server
 * so the returned page contains as many relevant rows as possible.
 */
export function useLveRows(
  entityType: string,
  options: UseLveRowsOptions,
): UseLveRowsResult {
  const { clientClauses, serverFilters, search, searchableFields, page, pageSize, sort } = options;

  const { rows: rawRows, total, page: resultPage, pageSize: resultPageSize, isLoading, error } =
    useEntityList<EntityData>(entityType, {
      filters: serverFilters,
      page,
      pageSize,
    });

  // Apply client-side non-equality clauses
  const afterClauses =
    clientClauses.length > 0
      ? rawRows.filter((r) =>
          matchesAll(r.data as Record<string, unknown>, clientClauses),
        )
      : rawRows;

  // Apply free-text search
  const trimmedSearch = search.trim().toLowerCase();
  const filteredRows =
    trimmedSearch.length > 0
      ? afterClauses.filter((r) => {
          const data = r.data as Record<string, unknown>;
          return searchableFields.some((field) => {
            const val = data[field];
            if (val === null || val === undefined) return false;
            return String(val).toLowerCase().includes(trimmedSearch);
          });
        })
      : afterClauses;

  // Apply optional client-side sort (applies to loaded page only — same limitation as client filtering).
  const sortedRows = sort
    ? [...filteredRows].sort((a, b) => {
        const av = (a.data as Record<string, unknown>)[sort.field];
        const bv = (b.data as Record<string, unknown>)[sort.field];
        const an = Number(av);
        const bn = Number(bv);
        let cmp: number;
        if (Number.isFinite(an) && Number.isFinite(bn)) {
          cmp = an - bn;
        } else {
          cmp = String(av ?? "")
            .toLowerCase()
            .localeCompare(String(bv ?? "").toLowerCase());
        }
        return sort.dir === "desc" ? -cmp : cmp;
      })
    : filteredRows;

  return {
    rows: sortedRows,
    total,
    pageSize: resultPageSize,
    page: resultPage,
    isLoading,
    error: error as Error | null,
  };
}
