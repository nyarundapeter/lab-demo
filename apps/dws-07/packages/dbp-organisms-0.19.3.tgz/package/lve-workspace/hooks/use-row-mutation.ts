"use client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { updateEntity } from "@dbp/ps-data/client";
import type { EntityData } from "@dbp/ps-data/client";
import { useSaveStatus } from "./use-save-status.js";

/**
 * Wraps PS.DATA updateEntity in a mutation.
 * On success, invalidates both the entity-list and the specific entity queries
 * so the UI reflects the new state immediately.
 * Save-status transitions: onMutate→saving, onSuccess→saved, onError→error.
 */
export function useRowMutation(entityType: string, id: string) {
  const queryClient = useQueryClient();
  const { markSaving, markSaved, markError } = useSaveStatus();

  return useMutation({
    mutationFn: (patch: Partial<EntityData>) =>
      updateEntity<EntityData>(entityType, id, patch),
    onMutate: () => {
      markSaving();
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({
        queryKey: ["ps-data", "entity-list", entityType],
      });
      void queryClient.invalidateQueries({
        queryKey: ["ps-data", "entity", entityType, id],
      });
      markSaved();
    },
    onError: () => {
      markError();
    },
  });
}
