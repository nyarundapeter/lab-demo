"use client";
import { create } from "zustand";

type SaveState = "idle" | "saving" | "saved" | "error";

interface SaveStatusStore {
  status: SaveState;
  _timer: ReturnType<typeof setTimeout> | null;
  markSaving: () => void;
  markSaved: () => void;
  markError: () => void;
}

/**
 * Module-level Zustand store for inline-edit save status.
 * Used by useRowMutation to surface Saving / Saved / Error states
 * in the DetailPane control bar (showSaveStatus config).
 */
const useSaveStatusStore = create<SaveStatusStore>((set, get) => ({
  status: "idle",
  _timer: null,

  markSaving: () => {
    const prior = get()._timer;
    if (prior !== null) clearTimeout(prior);
    set({ status: "saving", _timer: null });
  },

  markSaved: () => {
    const prior = get()._timer;
    if (prior !== null) clearTimeout(prior);
    const timer = setTimeout(() => {
      set({ status: "idle", _timer: null });
    }, 1500);
    set({ status: "saved", _timer: timer });
  },

  markError: () => {
    const prior = get()._timer;
    if (prior !== null) clearTimeout(prior);
    const timer = setTimeout(() => {
      set({ status: "idle", _timer: null });
    }, 2500);
    set({ status: "error", _timer: timer });
  },
}));

export function useSaveStatus() {
  const status = useSaveStatusStore((s) => s.status);
  const markSaving = useSaveStatusStore((s) => s.markSaving);
  const markSaved = useSaveStatusStore((s) => s.markSaved);
  const markError = useSaveStatusStore((s) => s.markError);
  return { status, markSaving, markSaved, markError };
}
