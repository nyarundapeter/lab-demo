"use client";
import { useQueries } from "@tanstack/react-query";
import { listEntities } from "@dbp/ps-data/client";
import { toServerFilters } from "../lib/filter.js";
import type { FilterPreset } from "../types.js";

/**
 * Returns per-tab counts by issuing a lightweight page:1 pageSize:1 query per tab
 * and reading the `total` from the response.
 *
 * Tabs whose `where` array contains any non-`is` clause are returned as `undefined`
 * (badge hidden) because those clauses cannot be pushed to the server — showing a
 * server-total would be misleading when client-side filtering would further reduce
 * the visible rows.
 *
 * The data client is configured globally (configureDataClient); no tenant arg needed.
 */
export function useTabCounts(
  entityType: string,
  tabs: FilterPreset[],
): Record<string, number | undefined> {
  const results = useQueries({
    queries: tabs.map((tab) => {
      // Determine whether all clauses are server-pushable (op === "is" with scalar value).
      const allPushable = tab.where.every(
        (c) =>
          c.op === "is" &&
          c.value !== undefined &&
          c.value !== null &&
          !Array.isArray(c.value),
      );
      const serverFilters = toServerFilters(tab.where);

      return {
        queryKey: [
          // Key under the ps-data entity-list namespace so the row-mutation's
          // invalidateQueries({ queryKey: ["ps-data","entity-list",entityType] })
          // refreshes these counts by prefix match after any inline/quick/bulk edit.
          "ps-data",
          "entity-list",
          entityType,
          "tab-count",
          tab.key,
          serverFilters,
        ] as const,
        queryFn: async () => {
          const result = await listEntities(entityType, {
            filters: serverFilters,
            page: 1,
            pageSize: 1,
          });
          return result.total;
        },
        // Disable the query entirely when clauses are not fully server-pushable
        // so we never surface a wrong count.
        enabled: allPushable,
        // Counts are relatively stable; cache for 30 s before going stale.
        staleTime: 30_000,
      };
    }),
  });

  if (tabs.length === 0) return {};

  const counts: Record<string, number | undefined> = {};
  for (let i = 0; i < tabs.length; i++) {
    const tab = tabs[i]!;
    const result = results[i]!;
    const allPushable = tab.where.every(
      (c) =>
        c.op === "is" &&
        c.value !== undefined &&
        c.value !== null &&
        !Array.isArray(c.value),
    );
    // Return undefined when not server-pushable or query not yet resolved.
    counts[tab.key] =
      allPushable && result.status === "success"
        ? (result.data as number)
        : undefined;
  }
  return counts;
}
