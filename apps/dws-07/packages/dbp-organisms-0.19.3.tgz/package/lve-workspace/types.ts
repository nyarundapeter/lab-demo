import { z } from "zod";
import { ActivityMentionUserSchema, ActivityTypeConfigSchema } from "@dbp/ui";

const CellFormat   = z.enum(["text","number","currency","percent","date","datetime","badge"]);
const EditType     = z.enum(["text","number","date","select"]);
// DetailField-only: relation editing (RelationPicker) is not supported in the
// inline-editable list-table columns, only in the EditModeOverview detail form.
const DetailEditType = z.enum(["text","number","date","select","relation"]);
// "neutral" kept for back-compat (mapBadgeTone in the runtime maps it → "gray").
// Canonical tones match badge.tsx CVA keys; "gray" and "default" are the real ones.
const Tone         = z.enum(["default","gray","neutral","info","success","warning","danger","orange","navy"]);
const SelectOption = z.object({ value: z.string(), label: z.string() });

const LveColumn = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
  width: z.string().optional(),
  align: z.enum(["left","right","center"]).optional(),
  mono: z.boolean().optional(),
  sortable: z.boolean().default(false),
  format: CellFormat.optional(),
  editable: z.boolean().default(false),
  editType: EditType.optional(),
  editOptions: z.array(SelectOption).optional(),
  badgeTones: z.record(z.string(), Tone).optional(),
});

const FilterOp = z.enum(["is","isNot","contains",">","<",">=","<=","in","isEmpty","isNotEmpty"]);
const FilterClause = z.object({
  field: z.string().min(1),
  op: FilterOp,
  value: z.union([z.string(), z.number(), z.boolean(), z.array(z.string())]).optional(),
});
const FilterPreset = z.object({
  key: z.string().min(1),
  label: z.string().min(1),
  where: z.array(FilterClause).default([]),
});

const StageStep = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  tone: Tone.optional(),
});

/**
 * Config for a DetailField with `editType: "relation"` — renders a searchable
 * chip picker backed by another entity type instead of a plain input.
 *
 * `multiple` defaults to true (existing behavior, back-compat): the underlying
 * entity field is string[] (e.g. compliance-assessment.obligationIds). false
 * means the field is a plain scalar string ("" = cleared) — e.g. a
 * remediation's findingId/controlId/testId/owner — picking a new value
 * replaces rather than appends. See index.tsx EditModeOverview's
 * buildInitial()/handleSave() for the string<->string[] boundary conversion
 * this drives, and RelationPicker.addId() for the replace-vs-append behavior.
 */
const RelationConfig = z.object({
  entityType: z.string().min(1),
  labelField: z.string().min(1),
  searchFields: z.array(z.string().min(1)).optional(),
  multiple: z.boolean().optional(),
});
export type RelationConfig = z.infer<typeof RelationConfig>;

const DetailField = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
  format: CellFormat.optional(),
  editable: z.boolean().default(false),
  editType: DetailEditType.optional(),
  editOptions: z.array(SelectOption).optional(),
  /** Required when editType is "relation". */
  relation: RelationConfig.optional(),
});
const DetailSection = z.object({
  title: z.string().min(1),
  fields: z.array(DetailField).min(1),
});
const DetailTab = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  sections: z.array(DetailSection).min(1),
});

/**
 * A flat section used by the focus-mode form to group fields into labeled blocks.
 * `fields` is an array of field *names* (matching DetailField.field values from detailTabs).
 * When config.sections is provided, EditModeOverview renders grouped blocks instead of
 * the flat detailTab section layout. Fields not listed in any section fall into an
 * implicit "Details" group at the end.
 */
const LveSectionSchema = z.object({
  title: z.string().min(1),
  fields: z.array(z.string().min(1)).min(1),
});
export type LveSection = z.infer<typeof LveSectionSchema>;

const RailCard = z.object({
  title: z.string().min(1),
  kind: z.enum(["fields","badges","linked"]).default("fields"),
  fields: z.array(DetailField).default([]),
});

const PatchMap = z.record(z.string(), z.union([z.string(), z.number(), z.boolean()]));
const BulkAction  = z.object({ action: z.string().min(1), label: z.string().min(1), patch: PatchMap.optional() });
/**
 * GG-12 (option b, docs/09-plans/entity-identity-contract-design-2026-07-26.md)
 * — a quickAction that changes a workflow-bound entity's lifecycle status
 * declares `engineAction` instead of `patch`, so the host routes it through
 * the workflow engine (advanceInstance/rejectInstance) rather than a raw
 * PS.DATA field patch. Mutually exclusive with `patch` (see refine below) —
 * `patch` stays the path for non-lifecycle fields on entities with no bound
 * workflow. Execution is host-supplied via `LveDetailExtras.onQuickAction`
 * (index.tsx); a config declaring `engineAction` with no host handler wired
 * is a silent no-op, same as any other unimplemented affordance.
 */
const QuickAction = z.object({
  action: z.string().min(1),
  label: z.string().min(1),
  when: z.array(FilterClause).default([]),
  patch: PatchMap.optional(),
  engineAction: z.enum(["advance", "reject"]).optional(),
  icon: z.string().optional(),
  tone: Tone.optional(),
}).refine((qa) => !(qa.patch && qa.engineAction), {
  message: "quickAction cannot declare both \"patch\" and \"engineAction\" — pick one.",
});

const HeaderConfig = z.object({
  titleField: z.string().min(1),
  subtitleField: z.string().optional(),
  statusField: z.string().optional(),
});

/**
 * Detail-pane overflow-menu ("⋯") entries — same shape as QuickAction so a
 * host can share `when`/`patch` logic between visible quick-action buttons
 * and menu items. When empty (the default), DetailPane renders no overflow
 * menu at all — see no-disabled-placeholder-actions.
 */
const OverflowAction = z.object({
  action: z.string().min(1),
  label: z.string().min(1),
  when: z.array(FilterClause).default([]),
  patch: PatchMap.optional(),
  tone: Tone.optional(),
});

/**
 * activity-timeline-spec-2026-07-10.md §7 deliverable 4 — config extension for the
 * `@dbp/ui` `ActivityTimeline`/`ActivityComposer` molecules. Optional: when absent, the
 * Activity tab keeps its pre-existing PS.AUDIT-only rendering (backward compatible).
 * When present, the Activity tab renders the typed timeline + composer, seeded from the
 * `useActivityFeed` audit trail plus notes persisted to a PS.DATA `<entityType>-note`
 * sub-entity (spec §2/§7 item 4). `entityType` here overrides the parent LVE record's own
 * entityType for the note sub-entity name; when absent, `<parent entityType>-note` is used.
 *
 * `mentionCandidates` (ADR-0048 §6.2): host-supplied `@mention` picker candidates. No
 * name-bearing identity directory is exposed client-side yet (`ps-org`/`ps-rbac` admin
 * endpoints return userId only, no display name) — verified at build time per the spec's
 * "verify the lookup surface" note. Until such a directory exists, the host page supplies
 * the candidate list explicitly, same shape the composer already expected.
 */
const ActivityTabConfig = z.object({
  entityType: z.string().optional(),
  activityTypes: z.record(z.string(), ActivityTypeConfigSchema).default({}),
  mentions: z.boolean().default(false),
  tags: z.boolean().default(false),
  attachments: z.boolean().default(false),
  mentionCandidates: z.array(ActivityMentionUserSchema).default([]),
  labels: z.record(z.string(), z.string()).optional(),
});
export type ActivityTabConfig = z.infer<typeof ActivityTabConfig>;

/**
 * A field the "+ New" create form collects. Reuses the same edit-type
 * vocabulary as DetailField/LveColumn (text/number/date/select) so the
 * generator can synthesize this from the same entity-Zod-type switch that
 * already produces editable detailTabs fields.
 */
const CreateField = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
  editType: EditType.default("text"),
  editOptions: z.array(SelectOption).optional(),
  required: z.boolean().default(false),
});
export type CreateField = z.infer<typeof CreateField>;

/**
 * Optional creation config. When present, LveWorkspaceTemplate renders a
 * "+ New" button that opens `@dbp/organisms/record-form` (APP.F24) in drawer
 * placement, built from `fields`. Absent = no create affordance (e.g. a
 * manifest entity marked `readOnly: true` — see scaffold-solution.mjs).
 */
const CreateConfig = z.object({
  fields: z.array(CreateField).min(1),
  title: z.string().optional(),
  /** Field values merged in under the submitted form values (e.g. status: "draft"). */
  defaults: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).default({}),
});
export type CreateConfig = z.infer<typeof CreateConfig>;

export const LveWorkspaceConfig = z.object({
  entityType: z.string().min(1),
  entityLabel: z.string().min(1),
  title: z.string().optional(),
  subtitle: z.string().optional(),
  breadcrumb: z.array(z.object({ label: z.string().min(1), href: z.string().optional() })).default([]),
  // When true, the workspace does NOT render its own list-mode header (the host page
  // renders a standard PageHeader above the card instead). The workspace still shows a
  // compact title-only header in the left column when a record is focused, and emits a
  // `dbp:lve:view-change` { mode } event so the host can show/hide the external header.
  externalHeader: z.boolean().default(false),
  columns: z.array(LveColumn).min(1),
  pageSize: z.number().int().min(1).max(200).default(25),
  enableSearch: z.boolean().default(true),
  enableBulkActions: z.boolean().default(false),
  selectable: z.boolean().default(true),
  listTabs: z.array(FilterPreset).default([]),
  quickFilters: z.array(FilterPreset).default([]),
  sortFields: z.array(z.string()).default([]),
  bulkActions: z.array(BulkAction).default([]),
  header: HeaderConfig.optional(),
  detailTabs: z.array(DetailTab).min(1),
  /** See CreateConfig doc comment above. Optional; absent = no "+ New" affordance. */
  createConfig: CreateConfig.optional(),
  showActivity: z.boolean().default(true),
  /** Optional — see ActivityTabConfig doc comment above. */
  activityTab: ActivityTabConfig.optional(),
  stageField: z.string().optional(),
  stages: z.array(StageStep).default([]),
  allowStageClick: z.boolean().default(true),
  quickActions: z.array(QuickAction).default([]),
  /** Detail-pane overflow ("⋯") menu items. Empty (default) → no overflow menu is rendered. */
  overflowActions: z.array(OverflowAction).default([]),
  defaultEditMode: z.enum(["edit","readonly"]).default("edit"),
  detailMode: z.enum(["list","split","stacked"]).default("list"),
  enableViewToggle: z.boolean().default(true),
  enableRecordPager: z.boolean().default(true),
  splitListWidth: z.string().default("320px"),
  showTabCounts: z.boolean().default(true),
  enableSort: z.boolean().default(true),
  pageSizeOptions: z.array(z.number().int().positive()).min(1).default([10,25,50]),
  stageVariant: z.enum(["numbered","pills"]).default("numbered"),
  showSaveStatus: z.boolean().default(true),
  detailRail: z.array(RailCard).default([]),
  emptyHeadline: z.string().optional(),
  /**
   * Optional flat grouping for the focus-mode form.
   * When present, EditModeOverview renders fields into labeled section blocks
   * rather than using the nested detailTabs[0].sections structure.
   * Fields not assigned to any section are collected into an implicit "Details" section.
   */
  sections: z.array(LveSectionSchema).optional(),
  // CSS grid-template-columns for the detail-pane overview+rail layout (both edit and readonly modes).
  detailGridColumns: z.string().default("1fr 260px"),
  // Gap in px between the overview and rail columns in the detail-pane grid.
  detailGridGap: z.number().int().min(0).max(48).default(20),
  // Layout of the edit-mode detail form's fields: label-left inline row, or label-above-control stacked.
  detailFormLayout: z.enum(["inline", "stacked"]).default("inline"),
  // When true, list mode switches to a card list + pill tabs + load-more below the 768px breakpoint (phones). Default false = no behavior change.
  mobileCardList: z.boolean().default(false),
});
export type LveWorkspaceConfig = z.infer<typeof LveWorkspaceConfig>;

/**
 * The accepted config shape for the LveWorkspace component — the Zod INPUT type,
 * where every `.default()` field (including nested column/field `editable` and
 * `sortable`) is optional. Use this for the component's public prop type so
 * callers need not spell out defaulted booleans on every column.
 */
export type LveWorkspaceConfigInput = z.input<typeof LveWorkspaceConfig>;

// Also export the inner element types for component props:
export type LveColumn = z.infer<typeof LveColumn>;
export type FilterClause = z.infer<typeof FilterClause>;
export type FilterPreset = z.infer<typeof FilterPreset>;
export type StageStep = z.infer<typeof StageStep>;
export type DetailTab = z.infer<typeof DetailTab>;
export type DetailSection = z.infer<typeof DetailSection>;
export type DetailField = z.infer<typeof DetailField>;
export type QuickAction = z.infer<typeof QuickAction>;
export type OverflowAction = z.infer<typeof OverflowAction>;
export type BulkAction = z.infer<typeof BulkAction>;
export type RailCard = z.infer<typeof RailCard>;
