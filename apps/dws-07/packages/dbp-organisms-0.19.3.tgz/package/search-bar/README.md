# @dbp/organisms/search-bar

**registryId:** `APP.F33`

Global search input with a debounced live-results dropdown.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Consumed by
Bespoke import — mounted into `AppChrome`'s `search` slot by the solution's chrome composition (e.g. `apps/dbp/app/solution-chrome.tsx`).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/search-bar` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
