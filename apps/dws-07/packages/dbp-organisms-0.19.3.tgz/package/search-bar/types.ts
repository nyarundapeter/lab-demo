import { z } from "zod";

// Config schema for the @dbp/organisms/search-bar organism. Promoted from
// packages/shared/ui/src/bindings (2026-07-21 Bindings/Admin resolution — it
// owns useSearch() debounced-query/selection fetch state, so it is an
// organism, not a presentation-layer binding). `onSelect` is a callback and
// is not representable in a Zod schema, so SearchBarProps extends the parsed
// config with it directly.
export const SearchBarConfig = z.object({
  placeholder: z.string().optional(),
  scope: z.string().optional(),
});

export type SearchBarConfig = z.infer<typeof SearchBarConfig>;
