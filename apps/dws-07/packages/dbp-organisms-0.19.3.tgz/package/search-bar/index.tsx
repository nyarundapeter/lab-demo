import * as React from "react";
import { Search } from "lucide-react";
import { useSearch } from "@dbp/ps-search/client";
import type { SearchHit } from "@dbp/ps-search/client";
import { Badge, cn, useDebounce } from "@dbp/ui";
import type { SearchBarConfig } from "./types.js";

export interface SearchBarProps extends SearchBarConfig {
  onSelect?: (hit: SearchHit) => void;
}

export function SearchBar({ placeholder = "Search…", scope, onSelect }: SearchBarProps) {
  const [query, setQuery] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [activeIndex, setActiveIndex] = React.useState(-1);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const listRef = React.useRef<HTMLUListElement>(null);

  const debouncedQuery = useDebounce(query, 250);
  const filters = scope !== undefined ? { scope } : {};
  const { results, loading } = useSearch(debouncedQuery, filters);

  React.useEffect(() => {
    if (debouncedQuery.trim() !== "" && !loading) {
      setOpen(true);
      setActiveIndex(-1);
    } else if (debouncedQuery.trim() === "") {
      setOpen(false);
    }
  }, [results, debouncedQuery, loading]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!open) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const idx = activeIndex >= 0 ? activeIndex : 0;
      const hit = results[idx];
      if (hit !== undefined) {
        selectHit(hit);
      }
    } else if (e.key === "Escape") {
      setOpen(false);
      setActiveIndex(-1);
    }
  };

  const selectHit = (hit: SearchHit) => {
    setQuery("");
    setOpen(false);
    setActiveIndex(-1);
    onSelect?.(hit);
  };

  const listboxId = React.useId();

  return (
    <div className="relative w-full" role="combobox" aria-expanded={open} aria-haspopup="listbox">
      <div className="relative flex items-center">
        <Search
          className="absolute left-3 h-4 w-4 text-[var(--color-text)] opacity-50 pointer-events-none"
          aria-hidden="true"
        />
        <input
          ref={inputRef}
          type="search"
          role="searchbox"
          aria-label={placeholder}
          aria-autocomplete="list"
          aria-controls={open ? listboxId : undefined}
          aria-activedescendant={
            open && activeIndex >= 0 ? `search-hit-${activeIndex}` : undefined
          }
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          placeholder={placeholder}
          style={{ height: "var(--shell-control-h)" }}
          className={cn(
            "w-full pl-9 pr-3 rounded border border-[var(--color-border)]",
            "bg-[var(--color-surface)] text-sm text-[var(--color-text)]",
            "placeholder:text-[var(--color-text)] placeholder:opacity-50",
            "focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]",
          )}
        />
        {loading && (
          <span
            className="absolute right-3 text-xs text-[var(--color-text)] opacity-50"
            aria-live="polite"
            aria-label="Searching"
          >
            …
          </span>
        )}
      </div>

      {open && results.length === 0 && (
        <div
          data-testid="search-bar-empty-state"
          className={cn(
            "absolute z-50 top-full mt-1 w-full rounded border border-[var(--color-border)]",
            "bg-[var(--color-surface)] shadow-md px-3 py-2.5 text-sm text-[var(--color-text)] opacity-70",
          )}
        >
          No results for "{debouncedQuery}" — try a different term or check another scope.
        </div>
      )}

      {open && results.length > 0 && (
        <ul
          id={listboxId}
          ref={listRef}
          role="listbox"
          aria-label="Search results"
          className={cn(
            "absolute z-50 top-full mt-1 w-full rounded border border-[var(--color-border)]",
            "bg-[var(--color-surface)] shadow-md max-h-64 overflow-y-auto",
          )}
        >
          {results.map((hit, i) => (
            <li
              key={hit.id}
              id={`search-hit-${i}`}
              role="option"
              aria-selected={i === activeIndex}
              onMouseDown={(e) => {
                e.preventDefault();
                selectHit(hit);
              }}
              onMouseEnter={() => setActiveIndex(i)}
              className={cn(
                "flex items-center justify-between px-3 py-2 text-sm cursor-pointer gap-2",
                i === activeIndex
                  ? "bg-[color-mix(in_srgb,var(--color-primary)_12%,transparent)] text-[var(--color-text)]"
                  : "text-[var(--color-text)] hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)]",
              )}
            >
              <span className="truncate">{hit.title}</span>
              <Badge tone="gray" className="shrink-0 text-xs leading-none">
                {hit.entityType}
              </Badge>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export type { SearchBarConfig } from "./types.js";
