import { z } from "zod";

// Config schema for the @dbp/organisms/activity-feed organism. Zod is the
// source of truth — the component's props type is z.infer, never a
// hand-authored interface. Promoted from packages/shared/ui/src/bindings
// (2026-07-21 Bindings/Admin resolution — this owns useActivityFeed()
// fetch/pagination state, so it is an organism, not a presentation-layer
// binding).
export const ActivityFeedConfig = z.object({
  entityId: z.string(),
  tenantId: z.string().optional(),
  limit: z.number().int().positive().optional(),
  title: z.string().optional(),
});

export type ActivityFeedConfig = z.infer<typeof ActivityFeedConfig>;
