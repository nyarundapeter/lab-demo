import * as React from "react";
import { useActivityFeed } from "@dbp/ps-audit/client";
import type { AuditEvent } from "@dbp/ps-audit/client";
import { ActivityTimeline, Button } from "@dbp/ui";
import type { ActivityDataState, ActivityEntry, ActivityTimelineConfig } from "@dbp/ui";
import type { ActivityFeedConfig } from "./types.js";

export type ActivityFeedProps = ActivityFeedConfig;

/** Every distinct PS.AUDIT `action` string renders as a generic "note" entry — audit actions are
 * open-ended (create/update/delete/...), so there's no fixed activityTypes vocabulary to declare. */
const TIMELINE_CONFIG: ActivityTimelineConfig = {
  activityTypes: {},
  mentions: false,
  tags: false,
  attachments: false,
};

function toEntry(event: AuditEvent): ActivityEntry {
  const bodyText = event.delta
    ? `${event.target.entityType}/${event.target.entityId}\n\nChanges:\n${JSON.stringify(event.delta, null, 2)}`
    : `${event.target.entityType}/${event.target.entityId}`;
  return {
    id: event.id,
    type: event.action,
    actorName: event.actor.displayName,
    timestamp: event.ts,
    bodyText,
  };
}

export function ActivityFeed({ entityId, limit, title }: ActivityFeedProps) {
  const { events, loadMore, hasMore, isLoading, isFetchingNextPage, error } =
    useActivityFeed(entityId, limit !== undefined ? { limit } : undefined);

  const state: ActivityDataState = isLoading
    ? "loading"
    : error
      ? "error"
      : events.length === 0
        ? "empty"
        : "populated";

  return (
    <div className="flex flex-col gap-2 w-full" role="region" aria-label={title ?? "Activity feed"}>
      {title && (
        <h2 className="text-sm font-semibold text-[var(--color-text)] px-1">{title}</h2>
      )}

      <ActivityTimeline
        config={TIMELINE_CONFIG}
        state={state}
        entries={events.map(toEntry)}
      />

      {isFetchingNextPage && <ActivityTimeline config={TIMELINE_CONFIG} state="loading" />}

      {hasMore && !isFetchingNextPage && (
        <Button
          variant="ghost"
          size="sm"
          onClick={loadMore}
          className="self-start mt-1"
          aria-label="Load more activity"
        >
          Load more
        </Button>
      )}
    </div>
  );
}

export type { ActivityFeedConfig } from "./types.js";
