# @dbp/organisms/activity-feed

**registryId:** `APP.F14`

Paginated PS.AUDIT event feed for a single entity: relative-time rows, expandable
delta diffs, "Load more" pagination.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ActivityFeedConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Bespoke import — mounted directly by callers needing an entity's audit trail
(e.g. `@dbp/organisms/marketplace-item-detail`), not via the `FEATURE_COMPONENT` map.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/activity-feed` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
