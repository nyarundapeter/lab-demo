# @dbp/organisms

Config-driven organism library — one package per registry id (`APP.F*`/`ANL.F*`). Each
subdirectory under `packages/stack/app-scaffolds/features/*` is an organism: a prop-driven React
component (Zod config in, no direct data-fetching of its own beyond the platform-service hooks it
composes) plus its Storybook stories and tests.

Consumed via subpath exports, e.g.:

```ts
import CollabCalendar from "@dbp/organisms/collab-calendar";
```

See `packages/shared/contracts/src/organism-catalogue.ts` for the source-of-truth registry
(package name, purpose, config schema, layouts, wiring, Storybook title, DoD status per
organism), and `docs/02-guides/02-operations/package-versioning-and-updates.md` for the
version-bump policy that applies to this package.
