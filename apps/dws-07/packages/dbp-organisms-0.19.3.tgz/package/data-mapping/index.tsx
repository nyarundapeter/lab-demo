import React from "react";
import { ArrowRight, Play, Save, Zap, MoreHorizontal } from "lucide-react";
import {
  Alert,
  Badge,
  Button,
  StatTile,
  MappingRowList,
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  FormField,
  Textarea,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  SectionLabel,
} from "@dbp/ui";
import { DataMappingConfig, type DataMappingConfigInput, type MappingField } from "./types.js";

const STATUS_BADGE: Record<MappingField["status"], { tone: "success" | "warning" | "gray" | "danger"; label: string }> = {
  ok: { tone: "success", label: "Mapped" },
  transform: { tone: "warning", label: "Transform" },
  unmapped: { tone: "gray", label: "Unmapped" },
  error: { tone: "danger", label: "Error" },
};

/**
 * Field-mapping interface: source → target with transformations, defaults,
 * and validation. Port of admin-specimens3.jsx's `MappingPage`. Owns the
 * `transformFor` drawer-open state. UI-only, prop-driven — no `PS.INTEGRATIONS`
 * platform service exists (same gap as `integration-catalogue`/`integration-detail`).
 * The transform drawer's "Preview with sample" list reuses the shared
 * `MappingRowList` molecule (table variant) rather than a bespoke render.
 */
export default function DataMapping(config: DataMappingConfigInput) {
  const parsed = DataMappingConfig.safeParse(config);
  const [transformFor, setTransformFor] = React.useState<MappingField | null>(null);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="DataMapping — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const c = parsed.data;
  const mappedCount = c.fields.filter((f) => f.status !== "unmapped").length;
  const unmappedCount = c.fields.length - mappedCount;
  const errorCount = c.fields.filter((f) => f.status === "error").length;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">
            Data mapping — {c.sourceSystem} → {c.targetSystem}
          </h2>
          <p className="mt-1 text-xs text-text-muted">
            Map source fields to target fields with transformations, defaults, and validation.
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <Badge tone="gray">{c.env}</Badge>
          <Button type="button" variant="outline" size="sm">
            <Play size={13} />
            Test with sample
          </Button>
          <Button type="button" size="sm">
            <Save size={13} />
            Save mapping
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatTile label="Mapped" value={`${mappedCount}/${c.fields.length}`} tone="success" />
        <StatTile label="Transformations" value={c.transformationsCount} tone="info" />
        <StatTile label="Unmapped" value={unmappedCount} tone="warning" />
        <StatTile label="Errors" value={errorCount} tone="danger" />
      </div>

      <div className="overflow-x-auto rounded-card border border-border-default bg-[var(--color-surface-content)]">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border-default text-left text-xs text-text-muted">
              <th className="px-3.5 py-2.5 font-medium">Source field</th>
              <th className="px-3.5 py-2.5 font-medium">Type</th>
              <th className="w-10" />
              <th className="px-3.5 py-2.5 font-medium">Target field</th>
              <th className="px-3.5 py-2.5 font-medium">Type</th>
              <th className="px-3.5 py-2.5 font-medium">Transformation</th>
              <th className="px-3.5 py-2.5 font-medium">Status</th>
              <th className="w-10" />
            </tr>
          </thead>
          <tbody>
            {c.fields.map((f, i) => (
              <tr key={i} className={i < c.fields.length - 1 ? "border-b border-border-default" : undefined}>
                <td className="px-3.5 py-2.5">
                  <span className="font-mono text-xs">{f.source}</span>
                  {f.required && <span className="ml-1 text-[var(--color-danger)]">*</span>}
                </td>
                <td className="px-3.5 py-2.5">
                  <Badge tone="gray" size="sm">
                    {f.sourceType}
                  </Badge>
                </td>
                <td className="px-1">
                  <ArrowRight size={13} className={f.status === "unmapped" ? "text-border-default" : "text-text-muted"} />
                </td>
                <td className="px-3.5 py-2.5">
                  {f.target ? (
                    <span className="font-mono text-xs">{f.target}</span>
                  ) : (
                    <span className="text-xs italic text-text-muted">Unmapped</span>
                  )}
                </td>
                <td className="px-3.5 py-2.5">
                  {f.targetType && (
                    <Badge tone="gray" size="sm">
                      {f.targetType}
                    </Badge>
                  )}
                </td>
                <td className="px-3.5 py-2.5 text-xs text-text-muted">
                  {f.status === "transform" ? (
                    <Button variant="link" className="h-auto p-0 underline-offset-2" onClick={() => setTransformFor(f)}>
                      {f.transform}
                    </Button>
                  ) : (
                    f.transform
                  )}
                </td>
                <td className="px-3.5 py-2.5">
                  <Badge tone={STATUS_BADGE[f.status].tone} size="sm">
                    {f.status === "transform" && <Zap size={10} />}
                    {STATUS_BADGE[f.status].label}
                  </Badge>
                </td>
                <td className="px-1">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button type="button" variant="ghost" size="sm" aria-label={`Row actions for ${f.source}`}>
                        <MoreHorizontal size={14} />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onSelect={() => setTransformFor(f)}>Edit transform</DropdownMenuItem>
                      <DropdownMenuItem>Set default value</DropdownMenuItem>
                      <DropdownMenuItem className="text-[var(--color-danger-text)]">Clear mapping</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="text-xs text-text-muted">
        Also available as a visual connector layout (drag source → target). Unmapped required fields and type
        mismatches surface inline before you can save.
      </p>

      <Sheet open={!!transformFor} onOpenChange={(open) => !open && setTransformFor(null)}>
        <SheetContent side="right" size="wide">
          <SheetHeader>
            <SheetTitle>Transformation</SheetTitle>
            {transformFor && (
              <SheetDescription>
                {transformFor.source} → {transformFor.target}
              </SheetDescription>
            )}
          </SheetHeader>

          {transformFor && (
            <div className="flex flex-col gap-4">
              <FormField label="Transformation type">
                <select className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm">
                  <option>Lookup table</option>
                  <option>Formula</option>
                  <option>Concatenation</option>
                  <option>Split</option>
                  <option>Date format</option>
                  <option>Default value</option>
                </select>
              </FormField>

              <FormField label="Lookup table" helperText="Maps source values to target values.">
                <Textarea className="min-h-[100px] font-mono text-xs" defaultValue={c.lookupTableDefault} />
              </FormField>

              <FormField label="On no match">
                <select className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm">
                  <option>Use default: &quot;Other&quot;</option>
                  <option>Leave empty</option>
                  <option>Flag as error</option>
                </select>
              </FormField>

              <div>
                <SectionLabel as="h4" className="mb-2 text-text-muted">
                  Preview with sample
                </SectionLabel>
                <MappingRowList
                  rows={c.transformPreview.map((r) => ({ source: r.source, target: r.target }))}
                  sourceHeader="Sample value"
                  targetHeader="Result"
                  metaHeader=""
                />
              </div>
            </div>
          )}

          <div className="mt-auto flex justify-end gap-2 border-t border-border-default pt-4">
            <Button type="button" variant="outline" onClick={() => setTransformFor(null)}>
              Cancel
            </Button>
            <Button type="button" onClick={() => setTransformFor(null)}>
              Apply
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
