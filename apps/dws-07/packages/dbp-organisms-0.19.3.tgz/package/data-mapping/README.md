# @dbp/organisms/data-mapping

**registryId:** `APP.F47`

Field-mapping interface: source → target with transformations, defaults, and validation.
Reuses `MappingRowList` for the transform drawer's sample preview — see `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`DataMappingConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/integrations/[id]/mapping` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/data-mapping` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
