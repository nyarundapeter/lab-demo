import { z } from "zod";

const MappingFieldStatus = z.enum(["ok", "transform", "unmapped", "error"]);

const MappingField = z.object({
  source: z.string().min(1),
  sourceType: z.string().min(1),
  /** Absent when the field is unmapped. */
  target: z.string().optional(),
  targetType: z.string().optional(),
  transform: z.string().optional(),
  status: MappingFieldStatus,
  required: z.boolean().default(false),
});

const TransformPreviewRow = z.object({
  source: z.string().min(1),
  target: z.string().min(1),
});

export const DataMappingConfig = z.object({
  sourceSystem: z.string().min(1),
  targetSystem: z.string().default("Platform"),
  env: z.string().default("stage"),
  fields: z.array(MappingField).default([]),
  transformationsCount: z.number().default(0),
  lookupTableDefault: z.string().default(""),
  transformPreview: z.array(TransformPreviewRow).default([]),
});

export type DataMappingConfig = z.infer<typeof DataMappingConfig>;
export type DataMappingConfigInput = z.input<typeof DataMappingConfig>;
export type MappingField = z.infer<typeof MappingField>;
