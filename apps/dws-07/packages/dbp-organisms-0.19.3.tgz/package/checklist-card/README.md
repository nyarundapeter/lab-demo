# @dbp/organisms/checklist-card

**registryId:** `APP.F55` (placeholder — assigned during central registration)

Dismissible onboarding checklist with progress and per-task deep-links. See `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ChecklistCardConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — no `FEATURE_COMPONENT` route in `scripts/scaffold-solution.mjs` targets this
organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/checklist-card` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
