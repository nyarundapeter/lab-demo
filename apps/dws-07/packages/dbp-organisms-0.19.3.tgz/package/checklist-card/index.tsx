import * as React from "react";
import { ChevronUp, ChevronDown, X, Check, ArrowRight } from "lucide-react";
import { Alert, Button, Progress } from "@dbp/ui";
import { ChecklistCardConfig, type ChecklistCardConfigInput, type ChecklistTask } from "./types.js";

export interface ChecklistCardProps {
  config: ChecklistCardConfigInput;
  /** Fired when a task's CTA is clicked (deep-link to the relevant flow). */
  onTaskAction?: (task: ChecklistTask) => void;
  /** Fired when the whole card is dismissed. */
  onDismiss?: () => void;
}

/**
 * ChecklistCard — dismissible onboarding checklist with per-task deep-links
 * and a live progress bar. Owns its own task-completion, collapse and
 * dismiss state (genuinely new, per the Wave 3 build plan — not extracted
 * from an existing component). Port of `identity-firstrun.jsx`'s
 * `ChecklistCard`.
 */
export default function ChecklistCard({ config, onTaskAction, onDismiss }: ChecklistCardProps) {
  const parsed = ChecklistCardConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="ChecklistCard — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <ChecklistCardInner config={parsed.data} onTaskAction={onTaskAction} onDismiss={onDismiss} />;
}

function ChecklistCardInner({
  config,
  onTaskAction,
  onDismiss,
}: {
  config: ChecklistCardConfig;
  onTaskAction?: ((task: ChecklistTask) => void) | undefined;
  onDismiss?: (() => void) | undefined;
}) {
  const [tasks, setTasks] = React.useState(config.tasks);
  const [open, setOpen] = React.useState(true);
  const [dismissed, setDismissed] = React.useState(false);
  const done = tasks.filter((t) => t.done).length;
  const pct = Math.round((done / tasks.length) * 100);

  function toggleTask(id: string) {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  }

  function dismiss() {
    setDismissed(true);
    onDismiss?.();
  }

  if (dismissed) {
    if (config.floating) return null;
    return (
      <Alert tone="success" title="Checklist dismissed" data-testid="checklist-card-dismissed">
        You can bring it back from Help → Getting started.
      </Alert>
    );
  }

  return (
    <div
      className={
        "rounded-[var(--radius-modal)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] " +
        (config.floating ? "w-[340px] shadow-[var(--shadow-lg)]" : "w-full")
      }
      data-testid="checklist-card"
    >
      <div className="px-4 pt-4 pb-3">
        <div className="flex items-start justify-between gap-2.5">
          <div>
            <p className="text-sm font-semibold text-primary">{config.title}</p>
            <p className="mt-0.5 text-xs text-[var(--color-text-muted)]">
              {done} of {tasks.length} complete
            </p>
          </div>
          <div className="flex gap-0.5">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setOpen((o) => !o)}
              aria-label={open ? "Collapse" : "Expand"}
              data-testid="checklist-card-toggle"
              className="h-7 w-7 rounded-[var(--radius-button)] text-[var(--color-text-muted)]"
            >
              {open ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={dismiss}
              aria-label="Dismiss checklist"
              data-testid="checklist-card-dismiss"
              className="h-7 w-7 rounded-[var(--radius-button)] text-[var(--color-text-muted)]"
            >
              <X size={15} />
            </Button>
          </div>
        </div>
        <Progress value={pct} className="mt-3" />
      </div>
      {open && (
        <div className="flex flex-col">
          {tasks.map((task) => (
            <div
              key={task.id}
              onClick={() => toggleTask(task.id)}
              data-testid={`checklist-card-task-${task.id}`}
              className="flex cursor-pointer items-start gap-3 border-t border-[var(--color-border-subtle)] px-4 py-3 hover:bg-[var(--color-surface)]"
            >
              <span
                className={
                  "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border " +
                  (task.done ? "border-primary bg-primary" : "border-[var(--color-border-default)]")
                }
                aria-hidden="true"
              >
                {task.done && <Check size={10} className="text-white" strokeWidth={3} />}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-primary">{task.title}</p>
                {task.desc && <p className="text-xs text-[var(--color-text-muted)]">{task.desc}</p>}
              </div>
              {!task.done && (
                <Button
                  variant="link"
                  onClick={(e) => {
                    e.stopPropagation();
                    onTaskAction?.(task);
                  }}
                  data-testid={`checklist-card-cta-${task.id}`}
                  className="h-auto shrink-0 gap-1 text-xs font-medium"
                >
                  {task.cta}
                  <ArrowRight size={12} aria-hidden="true" />
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export type { ChecklistCardConfig, ChecklistCardConfigInput, ChecklistTask } from "./types.js";
