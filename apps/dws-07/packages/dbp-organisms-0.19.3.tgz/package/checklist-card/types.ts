import { z } from "zod";

export const ChecklistTask = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  desc: z.string().optional(),
  done: z.boolean().default(false),
  cta: z.string().default("Start"),
});
export type ChecklistTask = z.infer<typeof ChecklistTask>;

export const ChecklistCardConfig = z.object({
  title: z.string().default("Get started"),
  tasks: z.array(ChecklistTask).min(1),
  /** Floating placement (bottom-right pinned card) vs inline full-width. */
  floating: z.boolean().default(false),
});
export type ChecklistCardConfig = z.infer<typeof ChecklistCardConfig>;
export type ChecklistCardConfigInput = z.input<typeof ChecklistCardConfig>;
