import { z } from "zod";

const Health = z.enum(["ok", "warn", "down"]);

const Environment = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  region: z.string().min(1),
  version: z.string().min(1),
  health: Health,
  deploy: z.string().min(1),
  /** Marks this environment as production-class: gets the striped banner, red deploy button, and type-to-confirm gate. */
  isProduction: z.boolean().default(false),
});
export type Environment = z.infer<typeof Environment>;

export const EnvironmentsAdminConfig = z.object({
  environments: z.array(Environment).min(1),
  /** Version being deployed in the production confirmation dialog. */
  deployVersion: z.string().default(""),
});

export type EnvironmentsAdminConfig = z.infer<typeof EnvironmentsAdminConfig>;
export type EnvironmentsAdminConfigInput = z.input<typeof EnvironmentsAdminConfig>;
