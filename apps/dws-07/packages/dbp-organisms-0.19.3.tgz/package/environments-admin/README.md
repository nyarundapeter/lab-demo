# @dbp/organisms/environments-admin

**registryId:** `APP.F44`

Environment cards (dev/test/staging/prod) with health/version/deploy metadata; production gets
a striped accent + type-to-confirm deploy dialog. See `FEATURE.md` for why this uses `Badge`
instead of `EnvPill` (a dated out-of-scope ruling, not an open question).

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`EnvironmentsAdminConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/environments` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/environments-admin` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
