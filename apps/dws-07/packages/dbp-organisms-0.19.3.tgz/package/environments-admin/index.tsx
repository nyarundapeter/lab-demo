import React from "react";
import { Plus, RefreshCw, Rocket, Sliders } from "lucide-react";
import {
  Alert,
  Badge,
  Button,
  Card,
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  Input,
} from "@dbp/ui";
import { EnvironmentsAdminConfig, type EnvironmentsAdminConfigInput, type Environment } from "./types.js";

const HEALTH_LABEL: Record<string, string> = { ok: "Healthy", warn: "Degraded", down: "Down" };
const HEALTH_DOT: Record<string, string> = {
  ok: "bg-[var(--color-success)]",
  warn: "bg-[var(--color-warning)]",
  down: "bg-[var(--color-danger)]",
};

/**
 * Environment cards (dev/test/stage/prod) with health/version/deploy
 * metadata; the production row gets a striped accent and a type-to-confirm
 * deploy dialog. Port of admin-specimens2.jsx's `EnvironmentsPage`.
 *
 * Uses a plain `Badge` for environment identity rather than an `EnvPill`
 * component — `--env-*`/`EnvPill` was explicitly ruled OUT OF SCOPE for the
 * 2026-07-17 tone-family-consolidation PR
 * (`tone-family-consolidation-2026-07-17.md`), a dated decision, not an
 * open question — building it here would contradict that ruling.
 */
export default function EnvironmentsAdmin(config: EnvironmentsAdminConfigInput) {
  const parsed = EnvironmentsAdminConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="EnvironmentsAdmin — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <EnvironmentsAdminInner config={parsed.data} />;
}

function EnvironmentsAdminInner({ config }: { config: EnvironmentsAdminConfig }) {
  const [confirmEnv, setConfirmEnv] = React.useState<Environment | null>(null);
  const [confirmText, setConfirmText] = React.useState("");

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Environments</h2>
          <p className="mt-1 text-xs text-text-muted">
            Development, test, staging, and production. Production changes require stronger
            confirmation.
          </p>
        </div>
        <Button type="button" variant="outline" size="sm" className="shrink-0">
          <Plus size={13} />
          Add environment
        </Button>
      </div>

      <div className="flex flex-col gap-3">
        {config.environments.map((e) => (
          <Card key={e.id} className="relative overflow-hidden shadow-none">
            {e.isProduction && (
              <div
                className="absolute inset-x-0 top-0 h-1"
                style={{
                  background:
                    "repeating-linear-gradient(45deg, var(--color-danger), var(--color-danger) 8px, transparent 8px, transparent 16px)",
                }}
                aria-hidden="true"
              />
            )}
            <div className="grid grid-cols-1 items-center gap-4 p-4 sm:grid-cols-[160px_1fr_auto]">
              <div>
                <Badge tone={e.isProduction ? "danger" : "gray"}>{e.name}</Badge>
                <div className="mt-2 text-base font-semibold">{e.name}</div>
                <div className="text-xs text-text-muted">{e.region}</div>
              </div>

              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                <Tile label="Version" value={e.version} />
                <Tile
                  label="Connection"
                  value={
                    <span className="inline-flex items-center gap-1.5">
                      <span className={`h-1.5 w-1.5 rounded-full ${HEALTH_DOT[e.health]}`} aria-hidden="true" />
                      {HEALTH_LABEL[e.health]}
                    </span>
                  }
                />
                <Tile label="Last deploy" value={e.deploy} />
                <Tile label="Config status" value={e.isProduction ? "Locked" : "Open"} />
              </div>

              <div className="flex gap-2">
                <Button type="button" variant="outline" size="sm">
                  <Sliders size={13} />
                  Configure
                </Button>
                {e.isProduction ? (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="border-[var(--color-danger)] text-[var(--color-danger)]"
                    onClick={() => {
                      setConfirmEnv(e);
                      setConfirmText("");
                    }}
                  >
                    <Rocket size={13} />
                    Deploy
                  </Button>
                ) : (
                  <Button type="button" variant="outline" size="sm">
                    <RefreshCw size={13} />
                    Refresh data
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      <p className="text-xs text-text-muted">
        Environments are differentiated by label + mark + accent, never colour alone. Production
        carries a persistent striped banner and requires typed confirmation for changes.
      </p>

      <Dialog open={confirmEnv !== null} onOpenChange={(open) => !open && setConfirmEnv(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Deploy to Production?</DialogTitle>
          </DialogHeader>
          {confirmEnv && (
            <div className="flex flex-col gap-3 text-sm">
              <p>
                This deploys {config.deployVersion || "the current build"} to{" "}
                <strong>{confirmEnv.name}</strong>, affecting all live users. Active sessions are not
                interrupted.
              </p>
              <div>
                <div className="mb-1.5 text-xs font-medium">
                  Type <span className="font-mono">PRODUCTION</span> to confirm
                </div>
                <Input
                  className="h-8 text-xs"
                  placeholder="PRODUCTION"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setConfirmEnv(null)}>
              Cancel
            </Button>
            <Button
              type="button"
              disabled={confirmText !== "PRODUCTION"}
              className="bg-[var(--color-danger)] hover:bg-[color-mix(in_srgb,var(--color-danger)_85%,black)]"
            >
              <Rocket size={13} />
              Deploy to Production
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Tile({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs text-text-muted">{label}</div>
      <div className="mt-0.5 text-sm font-medium">{value}</div>
    </div>
  );
}
