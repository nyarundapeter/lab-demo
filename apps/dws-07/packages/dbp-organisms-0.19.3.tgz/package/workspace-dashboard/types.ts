import { z } from "zod";

// ---------------------------------------------------------------------------
// Action pills in the greeting header
// ---------------------------------------------------------------------------
export const WorkspaceDashboardActionSchema = z.object({
  /** Display label for the pill */
  label: z.string(),
  /** Lucide icon name (unused at runtime — icon slot is wired in component) */
  icon: z.string().optional(),
  /** When true this pill renders filled (primary style) */
  primary: z.boolean().optional(),
  /** Navigation target; resolved via onNavigate prop */
  href: z.string().optional(),
  /** When true the pill renders as an honest disabled "coming soon" affordance */
  disabled: z.boolean().optional(),
  /** Tooltip text shown for a disabled pill explaining why */
  disabledReason: z.string().optional(),
});
export type WorkspaceDashboardAction = z.infer<
  typeof WorkspaceDashboardActionSchema
>;

// ---------------------------------------------------------------------------
// Task grouping
// ---------------------------------------------------------------------------
export const TaskGroupSchema = z.object({
  /** Stable key used to identify this group */
  key: z.string(),
  /** Human-readable group label shown in the collapsible header */
  label: z.string(),
  /** Entity field values that map to this group */
  statuses: z.array(z.string()),
});
export type TaskGroup = z.infer<typeof TaskGroupSchema>;

export const TaskFieldsSchema = z.object({
  /** Entity field that holds the task name/title */
  name: z.string().default("title"),
  /** Entity field that holds the priority value */
  priority: z.string().default("priority"),
  /** Entity field that holds the due date string */
  dueDate: z.string().default("dueDate"),
  /** Entity field that holds the status value (used for grouping) */
  status: z.string().default("status"),
});
export type TaskFields = z.infer<typeof TaskFieldsSchema>;

// ---------------------------------------------------------------------------
// Goals
// ---------------------------------------------------------------------------
export const GoalSchema = z.object({
  /** Goal display label */
  label: z.string(),
  /** Optional secondary context line */
  context: z.string().optional(),
  /** Completion percentage 0-100 */
  value: z.number().min(0).max(100),
});
export type Goal = z.infer<typeof GoalSchema>;

// ---------------------------------------------------------------------------
// Projects
// ---------------------------------------------------------------------------
export const ProjectSchema = z.object({
  /** Project display name */
  name: z.string(),
  /** Number of tasks in this project */
  tasks: z.number().int().nonnegative(),
  /** Number of teammates on this project */
  teammates: z.number().int().nonnegative(),
  /** Optional icon letter/emoji for the project chip */
  icon: z.string().optional(),
  /**
   * Color tone key for the project chip.
   * Maps to CSS token: var(--color-<tone>)
   */
  tone: z
    .enum(["primary", "secondary", "success", "warning", "danger", "info"])
    .optional(),
});
export type Project = z.infer<typeof ProjectSchema>;

// ---------------------------------------------------------------------------
// Calendar
// ---------------------------------------------------------------------------
export const CalendarDaySchema = z.object({
  /** Day-of-week abbreviation, e.g. "Mon" */
  dow: z.string(),
  /** Day number, e.g. 7 */
  day: z.number().int().positive(),
  /** When true this day is highlighted as the current/selected day */
  active: z.boolean().optional(),
});
export type CalendarDay = z.infer<typeof CalendarDaySchema>;

export const CalendarEventSchema = z.object({
  /** Event title */
  title: z.string(),
  /** Display time string, e.g. "10:00 – 11:00 AM" */
  time: z.string(),
  /** Provider name shown as a small button, e.g. "Google Meet" */
  provider: z.string().optional(),
  /** Number of attendees; drives avatar stack */
  attendees: z.number().int().nonnegative().optional(),
});
export type CalendarEvent = z.infer<typeof CalendarEventSchema>;

export const CalendarConfigSchema = z.object({
  /** Month label shown in the card header, e.g. "July 2025" */
  month: z.string().default(""),
  /** Strip of days rendered horizontally */
  days: z.array(CalendarDaySchema).default([]),
  /** Events rendered below the day strip */
  events: z.array(CalendarEventSchema).default([]),
});
export type CalendarConfig = z.infer<typeof CalendarConfigSchema>;

// ---------------------------------------------------------------------------
// Top-level feature config
// ---------------------------------------------------------------------------
export const WorkspaceDashboardConfig = z.object({
  /** Name shown in the greeting, e.g. "Alex". Defaults to "there". */
  userName: z.string().optional(),

  /** Short date string shown above the greeting, e.g. "Mon, July 7" */
  dateLabel: z.string().optional(),

  /**
   * Greeting header action pills.
   * First item should have primary:true for the filled style.
   */
  actions: z.array(WorkspaceDashboardActionSchema).default([]),

  /** Entity type used to fetch task rows from PS.DATA */
  tasksEntityType: z.string().default("task"),

  /**
   * How task rows are grouped by status.
   * Default groups: In Progress, To Do, Upcoming.
   */
  taskGroups: z
    .array(TaskGroupSchema)
    .default([
      { key: "in-progress", label: "IN PROGRESS", statuses: ["in-progress"] },
      { key: "to-do", label: "TO DO", statuses: ["open"] },
      { key: "upcoming", label: "UPCOMING", statuses: ["blocked"] },
    ]),

  /** Maps entity data field names to task presentation slots */
  taskFields: TaskFieldsSchema.default({}),

  /** Optional server-side filters passed to useEntityList for tasks */
  taskFilters: z.record(z.string(), z.unknown()).optional(),

  /** Goal items rendered in the My Goals card */
  goals: z.array(GoalSchema).default([]),

  /** Project tiles rendered in the Projects card */
  projects: z.array(ProjectSchema).default([]),

  /** Calendar config for the Calendar card */
  calendar: CalendarConfigSchema.default({}),

  /**
   * Entity type used to fetch reminder rows from PS.DATA (platform-shipped
   * "reminder" entity — id/title/dueAt/done/userId). Rows are filtered to the
   * signed-in user via useAuth().
   */
  remindersEntityType: z.string().default("reminder"),
});

export type WorkspaceDashboardConfigInput = z.input<
  typeof WorkspaceDashboardConfig
>;
export type WorkspaceDashboardConfigOutput = z.output<
  typeof WorkspaceDashboardConfig
>;
