"use client";

import { useState } from "react";
import {
  ClipboardList,
  ChevronRight,
  ChevronDown,
  Plus,
  Maximize2,
} from "lucide-react";
import {
  Badge,
  Skeleton,
  EmptyState,
  Button,
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogBody,
  Input,
  toast,
  SectionLabel,
} from "@dbp/ui";
import { useEntityList, useCreateEntity } from "@dbp/ps-data/client";
import { DashboardCard } from "./dashboard-card.js";
import type {
  TaskGroup,
  TaskFields,
  WorkspaceDashboardConfigOutput,
} from "../types.js";

interface TasksCardProps {
  tasksEntityType: string;
  taskGroups: WorkspaceDashboardConfigOutput["taskGroups"];
  taskFields: TaskFields;
  taskFilters?: WorkspaceDashboardConfigOutput["taskFilters"];
}

type PriorityTone = "danger" | "warning" | "info" | "gray";

const PRIORITY_TONE: Record<string, PriorityTone> = {
  high: "danger",
  critical: "danger",
  medium: "warning",
  low: "info",
};

function priorityTone(value: string | undefined): PriorityTone {
  if (!value) return "gray";
  return PRIORITY_TONE[String(value).toLowerCase()] ?? "gray";
}

function isDueToday(value: unknown): boolean {
  if (!value || typeof value !== "string") return false;
  const today = new Date().toISOString().slice(0, 10);
  return value.startsWith(today);
}

interface TaskGroupBlockProps {
  group: TaskGroup;
  rows: Record<string, unknown>[];
  fields: TaskFields;
}

function TaskGroupBlock({ group, rows, fields }: TaskGroupBlockProps) {
  const [open, setOpen] = useState(true);

  return (
    <div className="border-b border-[var(--color-border-subtle)] last:border-0">
      <Button
        type="button"
        variant="ghost"
        onClick={() => setOpen((v) => !v)}
        className="h-auto w-full justify-start rounded-none px-4 py-2 text-left font-normal"
      >
        {open ? (
          <ChevronDown size={14} className="shrink-0 text-[var(--color-text-muted)]" />
        ) : (
          <ChevronRight size={14} className="shrink-0 text-[var(--color-text-muted)]" />
        )}
        <SectionLabel className="text-xs">
          {group.label}
        </SectionLabel>
        <span className="ml-auto text-xs text-[var(--color-text-muted)]">
          {rows.length} task{rows.length !== 1 ? "s" : ""}
        </span>
      </Button>

      {open ? (
        <div>
          {rows.map((row, i) => {
            const data = (row.data ?? row) as Record<string, unknown>;
            const name = String(data[fields.name] ?? "Untitled");
            const priority = data[fields.priority];
            const dueDate = data[fields.dueDate];
            const tone = priorityTone(
              priority != null ? String(priority) : undefined
            );
            const dueDateStr = dueDate != null ? String(dueDate) : undefined;
            const dueDateUrgent = isDueToday(dueDate);

            return (
              <div
                key={String(row.id ?? i)}
                className="flex items-center gap-3 px-8 py-2 text-sm hover:bg-[var(--color-surface-raised)]"
              >
                <ChevronRight size={12} className="shrink-0 text-[var(--color-text-muted)]" />
                <span className="min-w-0 flex-1 truncate text-[var(--color-text)]">
                  {name}
                </span>
                {priority != null ? (
                  <Badge tone={tone} size="sm">
                    {String(priority)}
                  </Badge>
                ) : null}
                {dueDateStr ? (
                  <span
                    className="shrink-0 text-xs"
                    style={{
                      color: dueDateUrgent
                        ? "var(--color-secondary)"
                        : "var(--color-text-muted)",
                    }}
                  >
                    {dueDateStr}
                  </span>
                ) : null}
              </div>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}

interface AddTaskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tasksEntityType: string;
  taskFields: TaskFields;
}

/** Minimal create-task dialog — persists via PS.DATA (POST /entities/{tasksEntityType}). */
function AddTaskDialog({
  open,
  onOpenChange,
  tasksEntityType,
  taskFields,
}: AddTaskDialogProps) {
  const [name, setName] = useState("");
  const { create, isPending } = useCreateEntity(tasksEntityType);

  async function handleSubmit() {
    if (!name.trim()) return;
    try {
      await create({
        [taskFields.name]: name.trim(),
        [taskFields.status]: "open",
      });
      toast({ title: "Task added" });
      setName("");
      onOpenChange(false);
    } catch {
      toast({ title: "Could not add task", description: "Try again." });
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="sm">
        <DialogHeader>
          <DialogTitle>Add task</DialogTitle>
        </DialogHeader>
        <DialogBody>
          <Input
            autoFocus
            placeholder="Task name…"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void handleSubmit();
            }}
          />
        </DialogBody>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            variant="orange"
            disabled={!name.trim() || isPending}
            onClick={() => void handleSubmit()}
          >
            {isPending ? "Adding…" : "Add task"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function TasksCard({
  tasksEntityType,
  taskGroups,
  taskFields,
  taskFilters,
}: TasksCardProps) {
  const [addOpen, setAddOpen] = useState(false);
  // useEntityList filters must be Record<string, string | number | boolean>
  // taskFilters is Record<string, unknown> so we must narrow
  const safeFilters: Record<string, string | number | boolean> = {};
  if (taskFilters) {
    for (const [k, v] of Object.entries(taskFilters)) {
      if (
        typeof v === "string" ||
        typeof v === "number" ||
        typeof v === "boolean"
      ) {
        safeFilters[k] = v;
      }
    }
  }

  const { rows, isLoading, error } = useEntityList(tasksEntityType, {
    page: 1,
    pageSize: 100,
    filters: safeFilters,
  });

  const grouped = taskGroups.map((group) => ({
    group,
    rows: rows.filter((row) => {
      const data = (row.data ?? row) as Record<string, unknown>;
      const status = data[taskFields.status];
      return group.statuses.includes(String(status ?? ""));
    }),
  }));

  return (
    <>
      <DashboardCard
        title="My Tasks"
        icon={<ClipboardList size={16} />}
        headerAction={
          <div className="flex items-center gap-1">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setAddOpen(true)}
              className="h-auto w-auto rounded p-1 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              aria-label="Add task"
            >
              <Plus size={14} />
            </Button>
            <Button
              type="button"
              variant="ghost"
              className="h-auto w-auto rounded p-1 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              aria-label="Expand"
            >
              <Maximize2 size={14} />
            </Button>
          </div>
        }
      >
        {isLoading ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-6 w-full" />
            ))}
          </div>
        ) : error ? (
          <div className="p-4 text-sm text-[var(--color-text-muted)]">
            Could not load tasks.
          </div>
        ) : rows.length === 0 ? (
          <EmptyState
            title="No tasks"
            description="You have no tasks assigned."
          />
        ) : (
          <div>
            {grouped.map(({ group, rows: groupRows }) =>
              groupRows.length > 0 ? (
                <TaskGroupBlock
                  key={group.key}
                  group={group}
                  rows={groupRows}
                  fields={taskFields}
                />
              ) : null
            )}
            <Button
              type="button"
              variant="ghost"
              onClick={() => setAddOpen(true)}
              className="h-auto w-full justify-start rounded-none px-4 py-2 text-xs font-normal text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
            >
              <Plus size={12} />
              Add task
            </Button>
          </div>
        )}
      </DashboardCard>
      <AddTaskDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        tasksEntityType={tasksEntityType}
        taskFields={taskFields}
      />
    </>
  );
}
