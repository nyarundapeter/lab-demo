"use client";

import { Bot } from "lucide-react";
import { Button } from "@dbp/ui";
import type {
  WorkspaceDashboardAction,
  WorkspaceDashboardConfigOutput,
} from "../types.js";

interface GreetingHeaderProps {
  userName: string;
  dateLabel?: string | undefined;
  actions: WorkspaceDashboardConfigOutput["actions"];
  onNavigate?: ((href: string) => void) | undefined;
}

function ActionPill({
  action,
  onNavigate,
}: {
  action: WorkspaceDashboardAction;
  onNavigate?: ((href: string) => void) | undefined;
}) {
  const handleClick = () => {
    if (action.disabled) return;
    if (action.href && onNavigate) {
      onNavigate(action.href);
    }
  };

  if (action.primary) {
    return (
      <Button
        type="button"
        onClick={handleClick}
        disabled={action.disabled}
        title={action.disabled ? action.disabledReason : undefined}
        aria-disabled={action.disabled}
        className="h-auto rounded-[var(--radius-pill)] px-4 py-1.5 text-sm font-medium"
        style={{
          background:
            "linear-gradient(135deg, var(--color-secondary), var(--color-primary))",
        }}
      >
        <Bot size={14} />
        {action.label}
      </Button>
    );
  }

  return (
    <Button
      type="button"
      variant="outline"
      onClick={handleClick}
      disabled={action.disabled}
      title={action.disabled ? action.disabledReason : undefined}
      aria-disabled={action.disabled}
      className="h-auto rounded-[var(--radius-pill)] bg-transparent px-4 py-1.5 text-sm font-medium"
    >
      {action.label}
    </Button>
  );
}

/** Action pills row — usable standalone in a layout's aside slot. */
export function ActionPillGroup({
  actions,
  onNavigate,
}: {
  actions: WorkspaceDashboardConfigOutput["actions"];
  onNavigate?: ((href: string) => void) | undefined;
}) {
  if (actions.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-2">
      {actions.map((action, i) => (
        <ActionPill
          key={i}
          action={action}
          {...(onNavigate ? { onNavigate } : {})}
        />
      ))}
    </div>
  );
}

export function GreetingHeader({
  userName,
  actions,
  onNavigate,
}: GreetingHeaderProps) {
  return (
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <div className="space-y-0.5">
        <p className="text-lg font-semibold text-[var(--color-text)]">
          Hello, {userName}
        </p>
        <p
          className="text-sm font-medium"
          style={{
            background:
              "linear-gradient(135deg, var(--color-primary), var(--color-secondary))",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
          }}
        >
          How can I help you today?
        </p>
      </div>
      <ActionPillGroup actions={actions} {...(onNavigate ? { onNavigate } : {})} />
    </div>
  );
}
