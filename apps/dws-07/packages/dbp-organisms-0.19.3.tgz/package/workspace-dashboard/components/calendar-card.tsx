"use client";

import { Calendar } from "lucide-react";
import { EmptyState, Button } from "@dbp/ui";
import { DashboardCard } from "./dashboard-card.js";
import type { CalendarConfig, CalendarDay, CalendarEvent } from "../types.js";

interface CalendarCardProps {
  calendar: CalendarConfig;
}

function DayPill({ day }: { day: CalendarDay }) {
  if (day.active) {
    return (
      <div className="flex flex-col items-center gap-0.5">
        <span className="text-xs text-white/70">{day.dow}</span>
        <div
          className="flex h-8 w-8 items-center justify-center rounded-[var(--radius-pill)] text-sm font-bold text-white"
          style={{ backgroundColor: "var(--color-primary)" }}
        >
          {day.day}
        </div>
      </div>
    );
  }
  return (
    <div className="flex flex-col items-center gap-0.5">
      <span className="text-xs text-[var(--color-text-muted)]">{day.dow}</span>
      <div className="flex h-8 w-8 items-center justify-center rounded-[var(--radius-pill)] text-sm text-[var(--color-text)]">
        {day.day}
      </div>
    </div>
  );
}

function AttendeeStack({ count }: { count: number }) {
  const MAX_SHOWN = 3;
  const shown = Math.min(count, MAX_SHOWN);
  const extra = count - shown;

  return (
    <div className="flex items-center">
      {Array.from({ length: shown }).map((_, i) => (
        <div
          key={i}
          className="-ml-2 first:ml-0 h-6 w-6 rounded-[var(--radius-pill)] border-2 border-[var(--color-surface-raised)] bg-[var(--color-border-subtle)] flex items-center justify-center text-xs font-semibold text-[var(--color-text-muted)]"
        >
          {String.fromCharCode(65 + i)}
        </div>
      ))}
      {extra > 0 ? (
        <div className="-ml-2 h-6 w-6 rounded-[var(--radius-pill)] border-2 border-[var(--color-surface-raised)] bg-[var(--color-border-subtle)] flex items-center justify-center text-xs font-semibold text-[var(--color-text-muted)]">
          +{extra}
        </div>
      ) : null}
    </div>
  );
}

function EventCard({ event }: { event: CalendarEvent }) {
  return (
    <div className="rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-raised)] p-3">
      <div className="flex items-start gap-2">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-[var(--color-text)]">
            {event.title}
          </p>
          <p className="mt-0.5 text-xs text-[var(--color-text-muted)]">
            {event.time}
          </p>
          {event.provider ? (
            <Button
              type="button"
              variant="outline"
              className="mt-1.5 h-auto rounded-[var(--radius-button)] px-2 py-0.5 text-xs font-medium text-[var(--color-text-secondary)]"
            >
              {event.provider}
            </Button>
          ) : null}
        </div>
        {event.attendees != null && event.attendees > 0 ? (
          <AttendeeStack count={event.attendees} />
        ) : null}
      </div>
    </div>
  );
}

export function CalendarCard({ calendar }: CalendarCardProps) {
  const headerAction = calendar.month ? (
    <span className="text-xs text-[var(--color-text-muted)]">{calendar.month}</span>
  ) : undefined;

  return (
    <DashboardCard
      title="Calendar"
      icon={<Calendar size={16} />}
      {...(headerAction ? { headerAction } : {})}
    >
      <div className="space-y-4 p-4">
        {calendar.days.length > 0 ? (
          <div
            className="flex items-center gap-1 overflow-x-auto rounded-[var(--radius-card)] pb-1"
            style={{ backgroundColor: "var(--color-primary)" }}
          >
            <div className="flex min-w-0 gap-1 px-3 py-2">
              {calendar.days.map((day, i) => (
                <DayPill key={i} day={day} />
              ))}
            </div>
          </div>
        ) : null}

        {calendar.events.length === 0 ? (
          <EmptyState title="No events" description="Nothing scheduled." />
        ) : (
          <div className="space-y-2">
            {calendar.events.map((event, i) => (
              <EventCard key={i} event={event} />
            ))}
          </div>
        )}
      </div>
    </DashboardCard>
  );
}
