"use client";

import type { ReactNode } from "react";
import { cn } from "@dbp/ui";

interface DashboardCardProps {
  title: string;
  icon?: ReactNode;
  headerAction?: ReactNode;
  children: ReactNode;
  className?: string;
}

/**
 * Internal card primitive for workspace-dashboard widgets.
 * Provides a titled card with optional left icon and right header action slot.
 * Uses design-system tokens only — no hardcoded colors.
 */
export function DashboardCard({
  title,
  icon,
  headerAction,
  children,
  className,
}: DashboardCardProps) {
  return (
    <div
      className={cn(
        "rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-2)] shadow-[var(--shadow-sm)] overflow-hidden",
        className
      )}
    >
      <div className="flex items-center justify-between border-b border-[var(--color-border-subtle)] px-4 py-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-[var(--color-text)]">
          {icon ? (
            <span className="text-[var(--color-text-muted)]">{icon}</span>
          ) : null}
          {title}
        </div>
        {headerAction ? <div>{headerAction}</div> : null}
      </div>
      {children}
    </div>
  );
}
