"use client";

import { useState } from "react";
import { BellRing, Bell, Trash2 } from "lucide-react";
import { EmptyState, Skeleton, ConfirmDialog, Button, SectionLabel } from "@dbp/ui";
import { useEntityList, useDeleteEntity } from "@dbp/ps-data/client";
import { useAuth } from "@dbp/ps-auth/client";
import { DashboardCard } from "./dashboard-card.js";

interface RemindersCardProps {
  /** Entity type used to fetch reminder rows from PS.DATA (id/title/dueAt/done/userId). */
  remindersEntityType: string;
}

export function RemindersCard({ remindersEntityType }: RemindersCardProps) {
  const { user } = useAuth();
  const userId = user?.id;
  const { rows, isLoading, error } = useEntityList(remindersEntityType, {
    page: 1,
    pageSize: 100,
    filters: userId ? { userId } : {},
  });
  const { remove, isPending } = useDeleteEntity(remindersEntityType);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const reminders = rows.map((row) => {
    const data = (row.data ?? row) as Record<string, unknown>;
    return {
      id: row.id,
      title: String(data.title ?? "Untitled"),
      dueAt: data.dueAt != null ? String(data.dueAt) : undefined,
      done: Boolean(data.done),
    };
  });
  const pending = reminders.filter((r) => !r.done);
  const pendingDelete = reminders.find((r) => r.id === pendingDeleteId);

  return (
    <DashboardCard title="Reminders" icon={<BellRing size={16} />}>
      {isLoading ? (
        <div className="space-y-2 p-4">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-6 w-full" />
          ))}
        </div>
      ) : error ? (
        <div className="p-4 text-sm text-[var(--color-text-muted)]">
          Could not load reminders.
        </div>
      ) : reminders.length === 0 ? (
        <EmptyState title="No reminders" description="All clear for now." />
      ) : (
        <div className="p-4 space-y-1">
          {pending.length > 0 ? (
            <div className="mb-2 flex items-center gap-2">
              <SectionLabel className="text-xs">
                Today
              </SectionLabel>
              <span className="rounded-[var(--radius-pill)] bg-[var(--color-secondary)] px-1.5 py-0.5 text-xs font-bold text-white">
                {pending.length}
              </span>
            </div>
          ) : null}

          {reminders.map((reminder) => (
            <div
              key={reminder.id}
              className="group flex items-center gap-3 rounded-[var(--radius-button)] px-2 py-2 hover:bg-[var(--color-surface-raised)]"
            >
              <div
                className="h-4 w-4 shrink-0 rounded border border-[var(--color-border-default)] flex items-center justify-center"
                style={
                  reminder.done
                    ? {
                        backgroundColor: "var(--color-success)",
                        borderColor: "var(--color-success)",
                      }
                    : {}
                }
              >
                {reminder.done ? (
                  <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                    <path
                      d="M1 4l3 3 5-6"
                      stroke="white"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                ) : null}
              </div>

              <div className="min-w-0 flex-1">
                <p
                  className="text-sm text-[var(--color-text)]"
                  style={
                    reminder.done
                      ? {
                          textDecoration: "line-through",
                          color: "var(--color-text-muted)",
                        }
                      : {}
                  }
                >
                  {reminder.title}
                </p>
                {reminder.dueAt ? (
                  <p className="text-xs text-[var(--color-text-muted)]">
                    {reminder.dueAt}
                  </p>
                ) : null}
              </div>

              <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                <Button
                  type="button"
                  variant="ghost"
                  className="h-auto w-auto rounded p-1 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                  aria-label="Bell"
                >
                  <Bell size={12} />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setPendingDeleteId(reminder.id)}
                  disabled={isPending}
                  className="h-auto w-auto rounded p-1 text-[var(--color-text-muted)] hover:text-[var(--color-secondary)]"
                  aria-label="Delete"
                >
                  <Trash2 size={12} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
      <ConfirmDialog
        open={pendingDeleteId !== null}
        onOpenChange={(open) => {
          if (!open) setPendingDeleteId(null);
        }}
        title="Delete reminder?"
        {...(pendingDelete ? { description: pendingDelete.title } : {})}
        confirmLabel="Delete"
        destructive
        onConfirm={() => {
          if (pendingDeleteId === null) return;
          void remove(pendingDeleteId).finally(() => setPendingDeleteId(null));
        }}
      />
    </DashboardCard>
  );
}
