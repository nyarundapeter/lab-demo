"use client";

import { CircleDashed } from "lucide-react";
import { Progress, EmptyState } from "@dbp/ui";
import { DashboardCard } from "./dashboard-card.js";
import type { WorkspaceDashboardConfigOutput } from "../types.js";

interface GoalsCardProps {
  goals: WorkspaceDashboardConfigOutput["goals"];
}

export function GoalsCard({ goals }: GoalsCardProps) {
  return (
    <DashboardCard title="My Goals" icon={<CircleDashed size={16} />}>
      {goals.length === 0 ? (
        <EmptyState
          title="No goals set"
          description="Add goals to track your progress."
        />
      ) : (
        <div className="space-y-4 p-4">
          {goals.map((goal, i) => (
            <div key={i} className="space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium text-[var(--color-text)]">
                  {goal.label}
                </span>
                <span className="shrink-0 text-xs font-semibold text-[var(--color-text-secondary)]">
                  {goal.value}%
                </span>
              </div>
              {goal.context ? (
                <p className="text-xs text-[var(--color-text-muted)]">
                  {goal.context}
                </p>
              ) : null}
              <Progress value={goal.value} />
            </div>
          ))}
        </div>
      )}
    </DashboardCard>
  );
}
