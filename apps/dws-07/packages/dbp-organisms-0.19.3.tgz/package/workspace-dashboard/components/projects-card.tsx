"use client";

import { Briefcase, Plus } from "lucide-react";
import { DashboardCard } from "./dashboard-card.js";
import type { Project, WorkspaceDashboardConfigOutput } from "../types.js";

interface ProjectsCardProps {
  projects: WorkspaceDashboardConfigOutput["projects"];
}

const TONE_VARS: Record<string, string> = {
  primary: "var(--color-primary)",
  secondary: "var(--color-secondary)",
  success: "var(--color-success)",
  warning: "var(--color-warning)",
  danger: "var(--color-secondary)",
  info: "var(--color-info-text)",
};

function toneColor(tone: Project["tone"]): string {
  return tone ? (TONE_VARS[tone] ?? "var(--color-primary)") : "var(--color-primary)";
}

function ProjectTile({ project }: { project: Project }) {
  const color = toneColor(project.tone);
  return (
    <div className="flex flex-col gap-2 rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-raised)] p-3">
      <div
        className="flex h-8 w-8 items-center justify-center rounded-[var(--radius-button)] text-sm font-bold text-white"
        style={{ backgroundColor: color }}
      >
        {project.icon ?? project.name.charAt(0).toUpperCase()}
      </div>
      <p className="text-sm font-semibold text-[var(--color-text)] leading-tight">
        {project.name}
      </p>
      <p className="text-xs text-[var(--color-text-muted)]">
        {project.tasks} task{project.tasks !== 1 ? "s" : ""} ·{" "}
        {project.teammates} teammate{project.teammates !== 1 ? "s" : ""}
      </p>
    </div>
  );
}

function CreateProjectTile() {
  return (
    <div className="flex flex-col items-center justify-center gap-1 rounded-[var(--radius-card)] border border-dashed border-[var(--color-border-default)] p-3 text-[var(--color-text-muted)] transition-colors hover:border-[var(--color-primary)] hover:text-[var(--color-primary)]">
      <Plus size={20} />
      <span className="text-xs font-medium">Create new project</span>
    </div>
  );
}

export function ProjectsCard({ projects }: ProjectsCardProps) {
  return (
    <DashboardCard title="Projects" icon={<Briefcase size={16} />}>
      <div className="p-4">
        {projects.length === 0 ? (
          <div className="grid grid-cols-2 gap-3">
            <CreateProjectTile />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <CreateProjectTile />
            {projects.map((project, i) => (
              <ProjectTile key={i} project={project} />
            ))}
          </div>
        )}
      </div>
    </DashboardCard>
  );
}
