"use client";

import { EmptyState, Grid, Col } from "@dbp/ui";
import {
  WorkspaceDashboardConfig,
  type WorkspaceDashboardConfigInput,
  type WorkspaceDashboardConfigOutput,
} from "./types.js";
import { TasksCard } from "./components/tasks-card.js";
import { GoalsCard } from "./components/goals-card.js";
import { ProjectsCard } from "./components/projects-card.js";
import { CalendarCard } from "./components/calendar-card.js";
import { RemindersCard } from "./components/reminders-card.js";

export type WorkspaceDashboardProps = WorkspaceDashboardConfigInput & {
  onNavigate?: ((href: string) => void) | undefined;
};

// ---------------------------------------------------------------------------
// Inner component — receives validated config
// ---------------------------------------------------------------------------
interface WorkspaceDashboardInnerProps {
  config: WorkspaceDashboardConfigOutput;
  onNavigate?: ((href: string) => void) | undefined;
}

function WorkspaceDashboardInner({
  config,
  onNavigate: _onNavigate,
}: WorkspaceDashboardInnerProps) {
  return (
    <div className="w-full">
      {/* Two-column layout: left lg=7, right lg=5 */}
      <Grid>
        {/* Left column */}
        <Col span={12} lg={7}>
          <div className="space-y-4">
            <TasksCard
              tasksEntityType={config.tasksEntityType}
              taskGroups={config.taskGroups}
              taskFields={config.taskFields}
              {...(config.taskFilters !== undefined ? { taskFilters: config.taskFilters } : {})}
            />
            <GoalsCard goals={config.goals} />
          </div>
        </Col>

        {/* Right column */}
        <Col span={12} lg={5}>
          <div className="space-y-4">
            <ProjectsCard projects={config.projects} />
            <CalendarCard calendar={config.calendar} />
            <RemindersCard remindersEntityType={config.remindersEntityType} />
          </div>
        </Col>
      </Grid>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Public component — validates config with Zod, renders EmptyState (danger tone) on failure
// ---------------------------------------------------------------------------
export default function WorkspaceDashboard(props: WorkspaceDashboardProps) {
  const { onNavigate, ...configInput } = props;

  const result = WorkspaceDashboardConfig.safeParse(configInput);
  if (!result.success) {
    return (
      <EmptyState
        tone="danger"
        headline="WorkspaceDashboard: invalid config"
        description={result.error.issues
          .map((i) => `${i.path.join(".")}: ${i.message}`)
          .join(" | ")}
      />
    );
  }

  return (
    <WorkspaceDashboardInner
      config={result.data}
      {...(onNavigate !== undefined ? { onNavigate } : {})}
    />
  );
}

/** Action pill buttons for the dashboard — for use in a layout's aside slot. */
export { ActionPillGroup as WorkspaceDashboardActions } from "./components/greeting-header.js";

export { WorkspaceDashboardConfig } from "./types.js";
export type {
  WorkspaceDashboardConfigInput,
  WorkspaceDashboardConfigOutput,
} from "./types.js";
