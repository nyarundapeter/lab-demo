# @dbp/organisms/workspace-dashboard

**registryId:** `APP.F21`

Composed personal "My Dashboard": task groups, calendar, reminders, and quick actions.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`WorkspaceDashboardConfigOutput` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `overview-grid` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/workspace-dashboard` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
