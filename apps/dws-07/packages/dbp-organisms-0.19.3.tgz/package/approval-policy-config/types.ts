import { z } from "zod";

const ApprovalStep = z.object({
  step: z.string().min(1),
  who: z.string().min(1),
  rule: z.string().min(1),
  sla: z.string().min(1),
  /** Fallback text, e.g. "Delegate: Team lead" or "—" when none. */
  alt: z.string().min(1),
});

export const ApprovalPolicyConfigConfig = z.object({
  policyName: z.string().min(1),
  approvalType: z.string().min(1),
  approvalTypeOptions: z.array(z.string()).min(1),
  triggerCondition: z.string().min(1),
  onTimeoutOptions: z.array(z.string()).min(1),
  allowDelegation: z.boolean().default(true),
  steps: z.array(ApprovalStep).min(1),
  completionNote: z.string().default("Completion: all applicable steps approved"),
});

export type ApprovalPolicyConfigConfig = z.infer<typeof ApprovalPolicyConfigConfig>;
export type ApprovalPolicyConfigConfigInput = z.input<typeof ApprovalPolicyConfigConfig>;
