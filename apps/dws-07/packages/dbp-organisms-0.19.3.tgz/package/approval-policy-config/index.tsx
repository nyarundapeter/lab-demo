import React from "react";
import { CheckCircle2, Plus } from "lucide-react";
import {
  Alert,
  Button,
  InfoCard,
  Input,
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue,
  Switch,
} from "@dbp/ui";
import { ApprovalPolicyConfigConfig, type ApprovalPolicyConfigConfigInput } from "./types.js";

/**
 * Approval policy editor: policy form (type/trigger/timeout/delegation) +
 * a read-only approval-path preview stepper. Port of admin-specimens.jsx's
 * `ApprovalsPage`. Distinct from the runtime `approval-surface` organism
 * (APP.F06), which renders/actions an in-flight approval — this configures
 * the policy that generates one.
 *
 * UI-only, prop-driven. The reference itself has zero save-flow state
 * (form fields have no onChange/submit) — a real policy editor needs to own
 * form state and submit to a platform service; this component doesn't
 * pretend otherwise. The path-preview stepper overlaps
 * `workflow-system-intake-2026-07-12.md` §3.1's `ApprovalRoute`
 * named-future-approver problem — cross-referenced, not re-litigated here.
 */
export default function ApprovalPolicyConfig(config: ApprovalPolicyConfigConfigInput) {
  const parsed = ApprovalPolicyConfigConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="ApprovalPolicyConfig — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const c = parsed.data;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Approval configuration</h2>
          <p className="mt-1 text-xs text-text-muted">
            Define approval chains: who approves, in what order, with escalation and delegation.
          </p>
        </div>
        <Button type="button" size="sm" className="shrink-0">
          <Plus size={13} />
          New approval policy
        </Button>
      </div>

      <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-2">
        <InfoCard title={`Policy — ${c.policyName}`}>
          <div className="flex flex-col gap-3.5">
            <label className="flex flex-col gap-1 text-xs">
              <span className="font-medium text-text-secondary">Approval type</span>
              <Select defaultValue={c.approvalType}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {c.approvalTypeOptions.map((o) => (
                    <SelectItem key={o} value={o}>
                      {o}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
            <label className="flex flex-col gap-1 text-xs">
              <span className="font-medium text-text-secondary">Trigger condition</span>
              <Input className="h-8 text-xs" defaultValue={c.triggerCondition} />
              <span className="text-xs text-text-muted">When approval is required.</span>
            </label>
            <label className="flex flex-col gap-1 text-xs">
              <span className="font-medium text-text-secondary">On timeout (per step)</span>
              <Select defaultValue={c.onTimeoutOptions[0] ?? ""}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {c.onTimeoutOptions.map((o) => (
                    <SelectItem key={o} value={o}>
                      {o}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
            <label className="mt-1 flex items-center gap-2 text-xs">
              <Switch defaultChecked={c.allowDelegation} />
              Allow delegation when approver is away
            </label>
          </div>
        </InfoCard>

        <InfoCard title="Approval path preview">
          <div className="flex flex-col">
            {c.steps.map((s, i) => (
              <div key={i} className="flex gap-3" style={{ paddingBottom: i < c.steps.length - 1 ? 16 : 0 }}>
                <div className="flex flex-col items-center">
                  <span className="flex h-[26px] w-[26px] shrink-0 items-center justify-center rounded-full bg-[color-mix(in_srgb,var(--color-primary)_10%,white)] text-xs font-semibold text-primary">
                    {s.step}
                  </span>
                  {i < c.steps.length - 1 && <div className="mt-1 w-0.5 flex-1 bg-border-default" />}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">{s.who}</div>
                  <div className="mt-0.5 text-xs text-text-muted">
                    Applies: {s.rule} · SLA {s.sla}
                  </div>
                  <div className="text-xs text-text-muted">{s.alt}</div>
                </div>
              </div>
            ))}
            <div className="mt-2 flex items-center gap-1 border-t border-border-default pt-3 text-xs text-text-muted">
              <CheckCircle2 size={13} className="text-[var(--color-success)]" aria-hidden="true" />
              {c.completionNote}
            </div>
          </div>
        </InfoCard>
      </div>
    </div>
  );
}
