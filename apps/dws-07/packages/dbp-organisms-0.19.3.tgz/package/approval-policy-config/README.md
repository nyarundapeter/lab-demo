# @dbp/organisms/approval-policy-config

**registryId:** `APP.F43`

Approval policy editor: policy form + approval-path preview stepper. Distinct from the runtime
`approval-surface` (APP.F06) — see `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ApprovalPolicyConfigConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/approvals` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/approval-policy-config` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
