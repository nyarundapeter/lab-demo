import { z } from "zod";

const SchemaField = z.object({
  key: z.string().min(1),
  name: z.string().min(1),
  type: z.string().min(1),
  required: z.boolean().default(false),
  unique: z.boolean().default(false),
  indexed: z.boolean().default(false),
  sensitive: z.boolean().default(false),
});

const SchemaRelationship = z.object({
  from: z.string().min(1),
  type: z.string().min(1),
  to: z.string().min(1),
  label: z.string().min(1),
});

const ValidationRule = z.object({
  field: z.string().min(1),
  rule: z.string().min(1),
});

const SchemaEntity = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  records: z.string().min(1),
  status: z.enum(["active", "draft", "deprecated"]),
  fields: z.array(SchemaField).default([]),
  relationships: z.array(SchemaRelationship).default([]),
  validationRules: z.array(ValidationRule).default([]),
});

export const SchemaEntityDetailConfig = z.object({
  entities: z.array(SchemaEntity).default([]),
});

export type SchemaEntityDetailConfig = z.infer<typeof SchemaEntityDetailConfig>;
export type SchemaEntityDetailConfigInput = z.input<typeof SchemaEntityDetailConfig>;
export type SchemaEntity = z.infer<typeof SchemaEntity>;
export type SchemaField = z.infer<typeof SchemaField>;
export type SchemaRelationship = z.infer<typeof SchemaRelationship>;
export type ValidationRule = z.infer<typeof ValidationRule>;
