# @dbp/organisms/schema-entity-detail

**registryId:** `APP.F48`

Data entity list + per-entity detail: Fields/Relationships/Validation tabs and an "Add field"
drawer. Reuses `MappingRowList` (connector variant) for the Relationships tab. Named
`schema-entity-detail` (not `schema-builder`) to avoid colliding with `entity-detail`
(APP.F02) — see `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`SchemaEntityDetailConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/data/schemas` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/schema-entity-detail` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
