import React from "react";
import { ArrowLeft, Check, Database, GitBranch, Lock, MoreHorizontal, Plus } from "lucide-react";
import {
  Alert,
  Badge,
  Button,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  FormField,
  Switch,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@dbp/ui";
import { RelationshipEditor } from "./components/relationship-editor.js";
import { SchemaEntityDetailConfig, type SchemaEntityDetailConfigInput, type SchemaEntity } from "./types.js";

const STATUS_TONE: Record<SchemaEntity["status"], "active" | "warning" | "gray"> = {
  active: "active",
  draft: "warning",
  deprecated: "gray",
};

const FIELD_TYPES = [
  "Text",
  "Long text",
  "Number",
  "Currency",
  "Percentage",
  "Boolean",
  "Date",
  "Date & time",
  "Choice",
  "Multi-choice",
  "Lookup",
  "User",
  "File",
  "Image",
  "Formula",
  "Auto-number",
];

/**
 * Schemas & fields admin surface: entity list + a per-entity detail page
 * with Fields/Relationships/Validation tabs and an "Add field" drawer. Port
 * of admin-specimens3.jsx's `SchemaPage`/`EntityDetail`/`RelationshipEditor`.
 * UI-only, prop-driven — no `PS.SCHEMA`/`PS.RELATIONSHIPS` platform service
 * exists (same gap as `rule-builder`/`workflow-builder`/`feature-flags-admin`/
 * `data-mapping`).
 */
export default function SchemaEntityDetail(
  config: SchemaEntityDetailConfigInput & { initialEntityId?: string | undefined },
) {
  const { initialEntityId, ...rest } = config;
  const parsed = SchemaEntityDetailConfig.safeParse(rest);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="SchemaEntityDetail — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <SchemaEntityDetailInner config={parsed.data} initialEntityId={initialEntityId} />;
}

function SchemaEntityDetailInner({
  config,
  initialEntityId,
}: {
  config: SchemaEntityDetailConfig;
  initialEntityId?: string | undefined;
}) {
  const [selectedId, setSelectedId] = React.useState<string | null>(initialEntityId ?? null);
  const entity = config.entities.find((e) => e.id === selectedId) ?? null;

  if (entity) {
    return <EntityDetailView entity={entity} onBack={() => setSelectedId(null)} />;
  }

  return <SchemaEntityList entities={config.entities} onOpen={setSelectedId} />;
}

function SchemaEntityList({
  entities,
  onOpen,
}: {
  entities: SchemaEntity[];
  onOpen: (id: string) => void;
}) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Schemas &amp; fields</h2>
          <p className="mt-1 text-xs text-text-muted">
            Define data entities, fields, relationships, and validation. Schema changes trigger
            impact analysis and migration.
          </p>
        </div>
        <Button type="button" size="sm">
          <Plus size={13} />
          New entity
        </Button>
      </div>

      <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-border-default text-xs text-text-muted">
              <th className="px-3.5 py-2.5 font-medium">Entity</th>
              <th className="px-3.5 py-2.5 font-medium">Fields</th>
              <th className="px-3.5 py-2.5 font-medium">Relationships</th>
              <th className="px-3.5 py-2.5 font-medium">Records</th>
              <th className="px-3.5 py-2.5 font-medium">Status</th>
              <th className="w-10" />
            </tr>
          </thead>
          <tbody>
            {entities.map((e) => (
              <tr
                key={e.id}
                className="cursor-pointer border-b border-border-subtle last:border-b-0 hover:bg-[var(--color-surface)]"
                onClick={() => onOpen(e.id)}
              >
                <td className="px-3.5 py-2.5">
                  <div className="flex items-center gap-2 font-medium">
                    <Database size={14} className="text-text-muted" aria-hidden="true" />
                    {e.name}
                  </div>
                </td>
                <td className="px-3.5 py-2.5 font-mono text-xs">{e.fields.length}</td>
                <td className="px-3.5 py-2.5 font-mono text-xs">{e.relationships.length}</td>
                <td className="px-3.5 py-2.5 text-xs text-text-muted">{e.records}</td>
                <td className="px-3.5 py-2.5">
                  <Badge tone={STATUS_TONE[e.status]}>{e.status}</Badge>
                </td>
                <td className="px-1" onClick={(ev) => ev.stopPropagation()}>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button type="button" variant="ghost" size="sm" aria-label={`Row actions for ${e.name}`}>
                        <MoreHorizontal size={14} />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onSelect={() => onOpen(e.id)}>Open</DropdownMenuItem>
                      <DropdownMenuItem>View diagram</DropdownMenuItem>
                      <DropdownMenuItem>Export schema</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function EntityDetailView({ entity, onBack }: { entity: SchemaEntity; onBack: () => void }) {
  const [tab, setTab] = React.useState("fields");
  const [addOpen, setAddOpen] = React.useState(false);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <Button type="button" variant="ghost" size="sm" className="mb-1" onClick={onBack}>
            <ArrowLeft size={13} />
            Schemas
          </Button>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold">{entity.name}</h2>
            <Badge tone={STATUS_TONE[entity.status]}>{entity.status}</Badge>
          </div>
          <p className="mt-1 text-xs text-text-muted">
            {entity.fields.length} fields · {entity.relationships.length} relationships · {entity.records} records
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button type="button" variant="outline" size="sm">
            <GitBranch size={13} />
            Diagram
          </Button>
          <Button type="button" size="sm" onClick={() => setAddOpen(true)}>
            <Plus size={13} />
            Add field
          </Button>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="fields">Fields</TabsTrigger>
          <TabsTrigger value="relationships">Relationships</TabsTrigger>
          <TabsTrigger value="validation">Validation</TabsTrigger>
        </TabsList>

        <TabsContent value="fields" className="mt-4">
          <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-border-default text-xs text-text-muted">
                  <th className="px-3.5 py-2.5 font-medium">Field</th>
                  <th className="px-3.5 py-2.5 font-medium">Key</th>
                  <th className="px-3.5 py-2.5 font-medium">Type</th>
                  <th className="px-3.5 py-2.5 font-medium">Req</th>
                  <th className="px-3.5 py-2.5 font-medium">Unique</th>
                  <th className="px-3.5 py-2.5 font-medium">Indexed</th>
                  <th className="px-3.5 py-2.5 font-medium">Sensitive</th>
                  <th className="w-10" />
                </tr>
              </thead>
              <tbody>
                {entity.fields.map((f) => (
                  <tr key={f.key} className="border-b border-border-subtle last:border-b-0">
                    <td className="px-3.5 py-2.5 font-medium">{f.name}</td>
                    <td className="px-3.5 py-2.5 font-mono text-xs text-text-muted">{f.key}</td>
                    <td className="px-3.5 py-2.5">
                      <Badge tone="gray" size="sm">
                        {f.type}
                      </Badge>
                    </td>
                    <td className="px-3.5 py-2.5">
                      {f.required && <Check size={14} className="text-[var(--color-success)]" aria-hidden="true" />}
                    </td>
                    <td className="px-3.5 py-2.5">
                      {f.unique && <Check size={14} className="text-[var(--color-success)]" aria-hidden="true" />}
                    </td>
                    <td className="px-3.5 py-2.5">
                      {f.indexed && <Check size={14} className="text-[var(--color-success)]" aria-hidden="true" />}
                    </td>
                    <td className="px-3.5 py-2.5">
                      {f.sensitive && (
                        <span className="inline-flex items-center gap-1 text-xs text-[var(--color-warning-text)]">
                          <Lock size={12} aria-hidden="true" />
                          Yes
                        </span>
                      )}
                    </td>
                    <td className="px-1">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button type="button" variant="ghost" size="sm" aria-label={`Row actions for ${f.name}`}>
                            <MoreHorizontal size={14} />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>Duplicate</DropdownMenuItem>
                          <DropdownMenuItem className="text-[var(--color-danger-text)]">Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="relationships" className="mt-4">
          <RelationshipEditor relationships={entity.relationships} />
        </TabsContent>

        <TabsContent value="validation" className="mt-4">
          <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
            {entity.validationRules.map((r, i) => (
              <div
                key={i}
                className="flex items-center gap-3 px-3.5 py-2.5 text-xs"
                style={i < entity.validationRules.length - 1 ? { borderBottom: "1px solid var(--color-border-subtle)" } : undefined}
              >
                <span className="w-40 shrink-0 font-medium">{r.field}</span>
                <span className="flex-1 text-text-muted">{r.rule}</span>
                <Button type="button" variant="ghost" size="sm" aria-label={`Edit validation for ${r.field}`}>
                  <MoreHorizontal size={14} />
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <Sheet open={addOpen} onOpenChange={setAddOpen}>
        <SheetContent side="right" size="standard">
          <SheetHeader>
            <SheetTitle>Add field</SheetTitle>
            <SheetDescription>New field on {entity.name}</SheetDescription>
          </SheetHeader>

          <div className="flex flex-col gap-4">
            <FormField label="Display name" required>
              <input
                placeholder="e.g. Resolution notes"
                className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm"
              />
            </FormField>

            <FormField label="Field type" required>
              <select className="h-9 rounded-input border border-border-default bg-[var(--color-surface-content)] px-2 text-sm">
                {FIELD_TYPES.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </FormField>

            <label className="flex items-center gap-2 text-sm">
              <Switch defaultChecked={false} />
              Required
            </label>
            <label className="flex items-center gap-2 text-sm">
              <Switch defaultChecked={false} />
              Unique
            </label>
            <label className="flex items-center gap-2 text-sm">
              <Switch defaultChecked={false} />
              Indexed
            </label>
            <label className="flex items-center gap-2 text-sm">
              <Switch defaultChecked={false} />
              Sensitive data
            </label>

            <Alert tone="warning" title={`Adds a column to ${entity.records} records`}>
              New fields are nullable. Publishing this schema change runs a migration.
            </Alert>
          </div>

          <div className="mt-auto flex justify-end gap-2 border-t border-border-default pt-4">
            <Button type="button" variant="outline" onClick={() => setAddOpen(false)}>
              Cancel
            </Button>
            <Button type="button" onClick={() => setAddOpen(false)}>
              <Plus size={13} />
              Add field
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
