import React from "react";
import { MappingRowList } from "@dbp/ui";
import type { SchemaRelationship } from "../types.js";

interface Props {
  relationships: SchemaRelationship[];
}

/**
 * Relationship tab — port of admin-specimens3.jsx's `RelationshipEditor`.
 * Thin wrapper around the shared `MappingRowList` molecule (`connector`
 * variant), which supplies the pill-and-line row treatment and the
 * trailing "Add relationship" action.
 */
export function RelationshipEditor({ relationships }: Props) {
  return (
    <div className="flex flex-col gap-3">
      <p className="text-xs text-text-muted">
        Relationships define how entities connect. Changing a relationship type triggers migration
        impact analysis.
      </p>
      <MappingRowList
        variant="connector"
        rows={relationships.map((r) => ({ source: r.from, target: r.to, meta: r.type, label: r.label }))}
        onAddRow={() => {}}
        addRowLabel="Add relationship"
      />
    </div>
  );
}
