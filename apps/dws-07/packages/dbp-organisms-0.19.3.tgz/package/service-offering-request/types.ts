import { z } from "zod";

// Config schema for @dbp/organisms/service-offering-request (APP.F22).
// Zod is the source of truth — use z.infer, never hand-authored interfaces.

/**
 * SubmitRequestSchema — the validated shape of a service-request submission.
 *
 * Required: description (min 10 chars), urgency (low/medium/high).
 * Optional: justification.
 */
export const SubmitRequestSchema = z.object({
  description: z
    .string()
    .min(10, "Describe what you need — at least 10 characters."),
  urgency: z.enum(["low", "medium", "high"], {
    required_error: "Select an urgency level.",
  }),
  justification: z.string().optional(),
});

export type SubmitRequestValues = z.infer<typeof SubmitRequestSchema>;
