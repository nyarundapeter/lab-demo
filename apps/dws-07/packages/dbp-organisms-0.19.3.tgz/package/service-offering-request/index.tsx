"use client";

import * as React from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Alert, Button, Textarea, cn, toast } from "@dbp/ui";
import { SubmitRequestSchema, type SubmitRequestValues } from "./types.js";
import { buildServiceOfferingRequestCreateBody } from "./create-body.js";

/* ─────────────────────────────────────────────────────────────────────────────
 * Schema & types — see ./types.ts (source of truth)
 * ─────────────────────────────────────────────────────────────────────────── */

type FormValues = SubmitRequestValues;

/* ─────────────────────────────────────────────────────────────────────────────
 * Urgency options
 * ─────────────────────────────────────────────────────────────────────────── */

const URGENCY_OPTIONS = [
  {
    value: "low" as const,
    label: "Low",
    description: "Response within 5 business days",
  },
  {
    value: "medium" as const,
    label: "Medium",
    description: "Response within 2 business days",
  },
  {
    value: "high" as const,
    label: "High",
    description: "Response within 24 hours",
  },
];

/* ─────────────────────────────────────────────────────────────────────────────
 * Local primitives — eyebrow section header + question field wrapper.
 * These are intentionally local: they establish the B-hierarchy (eyebrow
 * section title, prominent question label) for this transactional form pattern.
 * ─────────────────────────────────────────────────────────────────────────── */

function SectionEyebrow({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="pb-2 border-b border-[var(--color-border)] text-xs font-semibold uppercase tracking-[0.08em] text-[var(--color-text-muted)]">
      {children}
    </h3>
  );
}

interface QuestionFieldProps {
  label: string;
  optional?: boolean;
  helperText?: string;
  error?: string;
  children: React.ReactElement<Record<string, unknown>>;
}

function QuestionField({
  label,
  optional,
  helperText,
  error,
  children,
}: QuestionFieldProps) {
  const id = React.useId();
  const descId = `${id}-desc`;
  const hasDesc = Boolean(error ?? helperText);

  const control = React.cloneElement(children, {
    id,
    ...(hasDesc && { "aria-describedby": descId }),
    ...(error && { "aria-invalid": "true" }),
  });

  return (
    <div className="flex flex-col gap-1.5">
      <label
        htmlFor={id}
        className="text-sm font-medium text-[var(--color-text)]"
      >
        {label}
        {optional && (
          <span className="ml-1.5 text-xs font-normal text-[var(--color-text-muted)]">
            (optional)
          </span>
        )}
      </label>
      {control}
      {(error || helperText) && (
        <p
          id={descId}
          role={error ? "alert" : undefined}
          className={cn(
            "text-xs leading-snug",
            error
              ? "text-[var(--color-danger-text)]"
              : "text-[var(--color-text-muted)]",
          )}
        >
          {error ?? helperText}
        </p>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
 * UrgencyCards — radio card group (≤5 options → cards, not a dropdown)
 * ─────────────────────────────────────────────────────────────────────────── */

interface UrgencyCardsProps {
  value: "low" | "medium" | "high" | undefined;
  onChange: (value: "low" | "medium" | "high") => void;
  error?: boolean;
}

function UrgencyCards({ value, onChange, error }: UrgencyCardsProps) {
  return (
    <div className="flex flex-col gap-2" role="radiogroup">
      {URGENCY_OPTIONS.map((opt) => {
        const selected = value === opt.value;
        return (
          <label
            key={opt.value}
            className={cn(
              "flex items-center gap-3 cursor-pointer rounded-md border px-3 py-3 transition-colors",
              selected
                ? "border-[var(--color-secondary)] bg-[var(--color-secondary)]/5"
                : error
                  ? "border-danger hover:border-[var(--color-border-strong)]"
                  : "border-[var(--color-border)] hover:border-[var(--color-border-strong)]",
            )}
          >
            <input
              type="radio"
              className="sr-only"
              name="urgency"
              value={opt.value}
              checked={selected}
              onChange={() => onChange(opt.value)}
            />
            {/* Custom radio indicator */}
            <span
              className={cn(
                "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border-[1.5px] transition-colors",
                selected
                  ? "border-[var(--color-secondary)]"
                  : "border-[var(--color-border)]",
              )}
              aria-hidden="true"
            >
              {selected && (
                <span className="h-2 w-2 rounded-full bg-[var(--color-secondary)]" />
              )}
            </span>
            <span className="min-w-0">
              <span className="block text-sm font-medium text-[var(--color-text)]">
                {opt.label}
              </span>
              <span className="block text-xs text-[var(--color-text-muted)]">
                {opt.description}
              </span>
            </span>
          </label>
        );
      })}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
 * Public props
 * ─────────────────────────────────────────────────────────────────────────── */

export interface SubmitRequestFormProps {
  /** The service-offering entity id — sent as `serviceId` on the request record. */
  serviceId: string;
  /** Human-readable service name — shown in the form header. */
  serviceName?: string;
  /** Called with the new request entity id on successful submission. */
  onSuccess?: (requestId: string) => void;
  /** Called when the user cancels without submitting. */
  onCancel?: () => void;
  /**
   * Storybook/demo only — forces the submit button into its "Submitting…"
   * loading state without an actual submission. `isSubmitting` is otherwise
   * only reachable by driving a real form submission, and this package has
   * no play-function tooling to script that interaction (DoD §6.1).
   */
  previewSubmitting?: boolean;
}

/* ─────────────────────────────────────────────────────────────────────────────
 * SubmitRequestForm (APP.F22)
 *
 * Single-page service request form. Stacked FormSection hierarchy:
 *   - Section eyebrow (10px uppercase muted) groups related fields visually.
 *   - QuestionLabel (13px sentence-case) is the prominent field prompt.
 *   - UrgencyCards replaces a dropdown (3 options, all visible, no extra click).
 *   - Validates on blur (mode: "onBlur"), surfacing inline errors per field.
 *   - Submits to PS.DATA POST /entities/service-offering-request with `{ data }` envelope.
 * ─────────────────────────────────────────────────────────────────────────── */

export default function SubmitRequestForm({
  serviceId,
  serviceName,
  onSuccess,
  onCancel,
  previewSubmitting = false,
}: SubmitRequestFormProps) {
  const {
    register,
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(SubmitRequestSchema),
    mode: "onBlur",
  });
  const submitting = isSubmitting || previewSubmitting;

  const [serverError, setServerError] = React.useState<string | null>(null);

  async function onSubmit(values: FormValues) {
    setServerError(null);
    try {
      const res = await fetch(
        "/api/platform/data/entities/service-offering-request",
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-tenant-id": "tenant-alpha",
          },
          body: JSON.stringify(
            buildServiceOfferingRequestCreateBody(values, serviceId),
          ),
        },
      );

      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as {
          error?: string;
        };
        throw new Error(body.error ?? `Request failed (${res.status})`);
      }

      const created = (await res.json()) as { id?: string };
      toast({ title: "Request submitted", description: "We'll be in touch soon." });
      onSuccess?.(created.id ?? "");
    } catch (err) {
      setServerError(
        err instanceof Error ? err.message : "Something went wrong. Try again.",
      );
    }
  }

  return (
    <div className="flex flex-col gap-8">
      {/* Form title */}
      <div>
        <h2 className="text-xl font-semibold text-[var(--color-text)]">
          Submit request
        </h2>
        {serviceName && (
          <p className="mt-1 text-sm text-[var(--color-text-muted)]">
            {serviceName}
          </p>
        )}
      </div>

      {serverError && (
        <Alert tone="danger" title="Submission failed">
          {serverError}
        </Alert>
      )}

      <form
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        className="flex flex-col gap-8"
      >
        {/* ── Section 1: What do you need? ─────────────────────────────── */}
        <section aria-label="What do you need?" className="flex flex-col gap-4">
          <SectionEyebrow>What do you need?</SectionEyebrow>

          <QuestionField
            label="Description"
            helperText="Be specific — helps the team respond faster."
            {...(errors.description?.message ? { error: errors.description.message } : {})}
          >
            <Textarea
              rows={4}
              className="resize-none"
              placeholder="Describe what you need from this service…"
              error={Boolean(errors.description)}
              {...register("description")}
            />
          </QuestionField>
        </section>

        {/* ── Section 2: Urgency ───────────────────────────────────────── */}
        <section aria-label="Urgency" className="flex flex-col gap-4">
          <SectionEyebrow>Urgency</SectionEyebrow>

          <Controller
            name="urgency"
            control={control}
            render={({ field }) => (
              <QuestionField
                label="How quickly do you need a response?"
                {...(errors.urgency?.message ? { error: errors.urgency.message } : {})}
              >
                <UrgencyCards
                  value={field.value}
                  onChange={field.onChange}
                  error={Boolean(errors.urgency)}
                />
              </QuestionField>
            )}
          />
        </section>

        {/* ── Section 3: Business context (optional) ───────────────────── */}
        <section aria-label="Business context" className="flex flex-col gap-4">
          <SectionEyebrow>Business context</SectionEyebrow>

          <QuestionField
            label="Justification"
            optional
            helperText="Helps approvers make faster decisions."
            {...(errors.justification?.message ? { error: errors.justification.message } : {})}
          >
            <input
              type="text"
              placeholder="Why is this needed?"
              className={cn(
                "flex h-10 w-full rounded-input px-3 text-sm bg-[var(--color-surface-content)] text-[var(--color-text-primary)]",
                "placeholder:text-[var(--color-text-disabled)]",
                "transition-colors motion-safe:transition-all",
                "disabled:cursor-not-allowed disabled:opacity-50",
                "focus-visible:outline-none",
                "border-[1.5px] border-border-default focus-visible:border-primary focus-visible:[box-shadow:var(--focus-ring-primary)]",
              )}
              {...register("justification")}
            />
          </QuestionField>
        </section>

        {/* ── Footer ───────────────────────────────────────────────────── */}
        <div className="flex items-center justify-end gap-3 border-t border-[var(--color-border)] pt-6">
          {onCancel && (
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          )}
          <Button
            type="submit"
            variant="orange"
            disabled={submitting}
            data-testid="submit-request-btn"
          >
            {submitting ? "Submitting…" : "Submit request"}
          </Button>
        </div>
      </form>
    </div>
  );
}
