// Local patch — restores a file missing from the published @dbp/organisms
// 0.19.3 tarball (upstream packaging gap). See ../marketplace-item-detail/
// editorial-types.ts for the full explanation. Baked into
// packages/dbp-organisms-0.19.3.tgz itself so it survives every
// `pnpm install`.

import type { SubmitRequestValues } from "./types.js";

export function buildServiceOfferingRequestCreateBody(
  values: SubmitRequestValues,
  serviceId: string,
): { data: SubmitRequestValues & { serviceId: string } } {
  return {
    data: {
      ...values,
      serviceId,
    },
  };
}
