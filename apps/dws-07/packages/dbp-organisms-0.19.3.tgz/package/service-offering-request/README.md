# @dbp/organisms/service-offering-request

**registryId:** `APP.F22`

SubmitRequestForm: request-a-service form (description/urgency/justification) generated onto every marketplace/catalogue listing's `/request` sub-route.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`SubmitRequestSchema` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Bespoke import — `scripts/scaffold-solution.mjs` imports this organism directly by name at the marketplace/catalogue `/request` sub-route generation site, rather than via the `FEATURE_COMPONENT` map. Mounted into the `collection-marketplace-detail` layout's request sub-route.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/service-offering-request` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
