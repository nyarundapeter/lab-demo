import { z } from "zod";

const CompareRecordSchema = z.object({
  id: z.string().min(1),
  /** field key → display value, e.g. { summary: "Renew VPN access", priority: "High" }. */
  fields: z.record(z.string(), z.string()),
});
export type CompareRecord = z.infer<typeof CompareRecordSchema>;

const CompareFieldDefSchema = z.object({
  /** Key into each record's `fields` map. */
  key: z.string().min(1),
  label: z.string().min(1),
});
export type CompareFieldDef = z.infer<typeof CompareFieldDefSchema>;

export const FullscreenCompareRecordsConfig = z.object({
  eyebrow: z.string().default("Comparison"),
  title: z.string().min(1),
  records: z.array(CompareRecordSchema).length(2),
  fields: z.array(CompareFieldDefSchema).min(1),
  mergeLabel: z.string().default("Merge selected"),
});

export type FullscreenCompareRecordsConfig = z.infer<typeof FullscreenCompareRecordsConfig>;
export type FullscreenCompareRecordsConfigInput = z.input<typeof FullscreenCompareRecordsConfig>;
