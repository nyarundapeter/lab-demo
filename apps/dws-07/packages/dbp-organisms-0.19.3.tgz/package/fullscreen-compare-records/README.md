# @dbp/organisms/fullscreen-compare-records

**registryId:** `APP.F62`

Wide side-by-side comparison of exactly 2 records, with differing field values highlighted.
See `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`FullscreenCompareRecordsConfig` — Zod schema exported from `types.ts` (source of truth).
Component props also take `open`/`onOpenChange` (controlled) and an optional `onMerge`
callback (not part of the Zod config).

## Consumed by
Not yet wired — no caller mounts this organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/fullscreen-compare-records` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
