import React from "react";
import { ChevronLeft } from "lucide-react";
import {
  Alert,
  Button,
  FullScreenModal,
  FullScreenModalContent,
  FullScreenModalBar,
  FullScreenModalTitle,
  FullScreenModalDescription,
  FullScreenModalBody,
  FullScreenModalMain,
  FullScreenModalFooter,
} from "@dbp/ui";
import { FullscreenCompareRecordsConfig, type FullscreenCompareRecordsConfigInput } from "./types.js";

export interface FullscreenCompareRecordsProps extends FullscreenCompareRecordsConfigInput {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onMerge?: () => void;
}

/**
 * APP.F62 — Fullscreen Compare Records
 *
 * Wide side-by-side field comparison — port of `overlay-fullscreen.jsx`'s
 * `FullScreenSurface` (`mode === 'compare'`) / `CompareView`. Composition on
 * top of the existing `FullScreenModal` primitive — no side rail (the
 * reference omits one for this mode; the comparison table needs the full
 * width). Differing field values are highlighted, matching the reference's
 * "wide side-by-side comparison is exactly what a narrow drawer can't do".
 */
export default function FullscreenCompareRecords(props: FullscreenCompareRecordsProps) {
  const { open, onOpenChange, onMerge, ...config } = props;
  const parsed = FullscreenCompareRecordsConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <FullScreenModal open={open} onOpenChange={onOpenChange}>
        <FullScreenModalContent hideClose>
          <Alert tone="danger" title="FullscreenCompareRecords — invalid config" data-testid="config-error">
            <ul className="mt-1 list-disc pl-5">
              {parsed.error.issues.map((issue, i) => (
                <li key={i}>
                  {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
                  {issue.message}
                </li>
              ))}
            </ul>
          </Alert>
        </FullScreenModalContent>
      </FullScreenModal>
    );
  }

  const c = parsed.data;
  const [left, right] = c.records;

  return (
    <FullScreenModal open={open} onOpenChange={onOpenChange}>
      <FullScreenModalContent hideClose data-testid="fullscreen-compare-records">
        <FullScreenModalBar>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => onOpenChange(false)}
            aria-label="Back"
            className="h-8 w-8 rounded-[var(--radius-button)] text-[var(--color-text-muted)] hover:text-primary"
          >
            <ChevronLeft size={18} aria-hidden="true" />
          </Button>
          <div className="min-w-0">
            <FullScreenModalDescription>{c.eyebrow}</FullScreenModalDescription>
            <FullScreenModalTitle>{c.title}</FullScreenModalTitle>
          </div>
        </FullScreenModalBar>

        <FullScreenModalBody>
          <FullScreenModalMain>
            <div className="p-6">
              <div className="grid grid-cols-[160px_1fr_1fr] overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border-default)]">
                <div className="border-b border-[var(--color-border-default)] bg-[var(--color-surface)] px-3.5 py-2.5 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
                  Field
                </div>
                {c.records.map((r) => (
                  <div
                    key={r.id}
                    className="border-b border-[var(--color-border-default)] bg-[var(--color-surface)] px-3.5 py-2.5 text-sm font-semibold"
                  >
                    <span className="font-mono text-xs font-normal text-[var(--color-text-muted)]">{r.id}</span>
                  </div>
                ))}

                {c.fields.map((f) => {
                  const diff = left!.fields[f.key] !== right!.fields[f.key];
                  return (
                    <React.Fragment key={f.key}>
                      <div className="border-t border-[var(--color-border-default)] px-3.5 py-2.5 text-xs font-medium text-[var(--color-text-muted)]">
                        {f.label}
                      </div>
                      {c.records.map((r) => (
                        <div
                          key={r.id}
                          className="flex items-center gap-1.5 border-t border-[var(--color-border-default)] px-3.5 py-2.5 text-sm"
                          style={diff ? { background: "color-mix(in srgb, var(--color-primary) 5%, transparent)" } : undefined}
                        >
                          {r.fields[f.key] ?? "—"}
                          {diff && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--color-primary)]" aria-hidden="true" />}
                        </div>
                      ))}
                    </React.Fragment>
                  );
                })}
              </div>
              <p className="mt-3 flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
                <span className="h-2 w-2 rounded-full bg-[var(--color-primary)]" aria-hidden="true" />
                Highlighted rows differ between records.
              </p>
            </div>
          </FullScreenModalMain>
        </FullScreenModalBody>

        <FullScreenModalFooter>
          <div className="flex-1" />
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button type="button" onClick={onMerge}>
            {c.mergeLabel}
          </Button>
        </FullScreenModalFooter>
      </FullScreenModalContent>
    </FullScreenModal>
  );
}
