import * as React from "react";
import { Alert } from "@dbp/ui";
import { ChartPanelConfig } from "./types.js";
import { useChartData } from "./hooks/use-chart-data.js";
import { buildChartData, buildHeatmapData, sumSeries } from "./components/aggregation.js";
import { PanelChrome } from "./components/panel-chrome.js";
import { BarChartPanel } from "./components/bar-chart-panel.js";
import { LineChartPanel } from "./components/line-chart-panel.js";
import { AreaChartPanel } from "./components/area-chart-panel.js";
import { PieChartPanel } from "./components/pie-chart-panel.js";
import { HeatmapChartPanel } from "./components/heatmap-chart-panel.js";
import { FunnelChartPanel } from "./components/funnel-chart-panel.js";
import { RankingChartPanel } from "./components/ranking-chart-panel.js";
import { SummaryChartPanel } from "./components/summary-chart-panel.js";

type ConfigInput = Omit<ChartPanelConfig, "showLegend" | "height"> &
  Partial<Pick<ChartPanelConfig, "showLegend" | "height">>;

/**
 * ANL.F02 — Analytics Chart Panel
 *
 * Receives CONFIG, never data. Fetches entity rows via PS.DATA (useEntityList),
 * groups by categoryField, and aggregates each series client-side.
 *
 * Supported chart types: bar (multi-series, stackable), line (multi-series),
 * area (multi-series, stackable), pie (single series only).
 *
 * Config is validated at render time via ChartPanelConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 */
export default function ChartPanel(rawConfig: ConfigInput) {
  const parseResult = ChartPanelConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="ChartPanel configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const config = parseResult.data;
  return <ChartPanelInner config={config} />;
}

// Value export (the Zod schema itself) alongside the inferred type — ANL.F06
// (example-report) validates `charts[].config` against this schema verbatim.
export { ChartPanelConfig } from "./types.js";
export type { Series } from "./types.js";

// ─── Inner component (config is guaranteed valid here) ────────────────────────

interface ChartPanelInnerProps {
  config: ChartPanelConfig;
}

function ChartPanelInner({ config }: ChartPanelInnerProps) {
  const { rows, isLoading, error, capped, total } = useChartData(config);

  const isHeatmap = config.chartType === "heatmap";

  const data = React.useMemo(
    () =>
      isHeatmap
        ? []
        : buildChartData(rows, config.categoryField, config.series, config.limit ?? 20),
    [isHeatmap, rows, config.categoryField, config.series, config.limit],
  );

  const heatmapGrid = React.useMemo(
    () =>
      isHeatmap
        ? buildHeatmapData(rows, config.rowField ?? "", config.categoryField, config.series[0]!)
        : null,
    [isHeatmap, rows, config.rowField, config.categoryField, config.series],
  );

  const firstValueField = config.series[0]?.valueField ?? "";
  const totalValue = React.useMemo(
    () => sumSeries(data, firstValueField),
    [data, firstValueField],
  );

  const totalBadge = isLoading || error || isHeatmap
    ? undefined
    : new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(totalValue);

  const empty = isHeatmap
    ? !isLoading && !error && (heatmapGrid?.rows.length ?? 0) === 0
    : !isLoading && !error && data.length === 0;

  // HealthStatusCard carries its own dq-card surface + title header, so it
  // bypasses PanelChrome entirely (avoids a nested-card look) and owns its
  // own loading/error/empty states.
  if (config.chartType === "summary") {
    return <SummaryChartPanel config={config} data={data} isLoading={isLoading} error={error} />;
  }

  return (
    <PanelChrome
      title={config.title}
      {...(totalBadge !== undefined && { totalBadge })}
      isLoading={isLoading}
      error={error}
      empty={empty}
      height={config.height}
      capped={capped}
      rowCount={rows.length}
      total={total}
    >
      {config.chartType === "bar" && (
        <BarChartPanel config={config} data={data} />
      )}
      {config.chartType === "line" && (
        <LineChartPanel config={config} data={data} />
      )}
      {config.chartType === "area" && (
        <AreaChartPanel config={config} data={data} />
      )}
      {config.chartType === "pie" && (
        <PieChartPanel config={config} data={data} />
      )}
      {config.chartType === "heatmap" && heatmapGrid && (
        <HeatmapChartPanel config={config} grid={heatmapGrid} />
      )}
      {config.chartType === "funnel" && (
        <FunnelChartPanel config={config} data={data} />
      )}
      {config.chartType === "ranking" && (
        <RankingChartPanel config={config} data={data} />
      )}
    </PanelChrome>
  );
}
