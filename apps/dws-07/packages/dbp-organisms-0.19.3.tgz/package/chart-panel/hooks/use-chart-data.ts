import { useQuery } from "@tanstack/react-query";
import { listAllEntities } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { ChartPanelConfig } from "../types.js";

export interface ChartDataResult {
  rows: EntityRecord<EntityData>[];
  isLoading: boolean;
  error: Error | null;
  /**
   * True when `listAllEntities` hit the 2000-row safety cap (server reports
   * more matching rows than were fetched). The chart is aggregated over a
   * partial dataset when this is true.
   */
  capped: boolean;
  /** Server-reported total row count (undefined while loading). */
  total: number | undefined;
}

/**
 * Fetches entity rows for the chart panel from PS.DATA.
 *
 * NOTE — client-side aggregation:
 * PS.DATA has no server-side aggregate endpoint. The panel pages through all
 * available rows (up to 2000) using MAX_PAGE_SIZE (200) per request and
 * groups/aggregates entirely in the browser.
 * For very large datasets the values will be approximate. A future PS.DATA
 * aggregate endpoint can replace this without changing ChartPanelConfig.
 */
export function useChartData(config: ChartPanelConfig): ChartDataResult {
  const query = useQuery({
    queryKey: ["ps-data", "all-entities", config.entityType, config.filters ?? {}],
    queryFn: () => listAllEntities(config.entityType, { ...(config.filters !== undefined && { filters: config.filters }) }),
  });

  const rows = query.data?.rows ?? [];
  const total = query.data?.total;

  return {
    rows,
    isLoading: query.isLoading,
    error: query.error as Error | null,
    capped: total !== undefined && total > rows.length,
    total,
  };
}
