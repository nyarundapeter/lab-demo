import * as React from "react";
import { Skeleton, EmptyState, Alert, formatNumber } from "@dbp/ui";
import { BarChart3 } from "lucide-react";

interface PanelChromeProps {
  title: string;
  totalBadge?: string;
  isLoading: boolean;
  error: Error | null;
  empty: boolean;
  height: number;
  children: React.ReactNode;
  /** True when the underlying query hit the 2000-row safety cap. */
  capped?: boolean;
  /** Rows fetched vs. server-reported total — shown in the cap banner. */
  rowCount?: number;
  total?: number | undefined;
}

/**
 * Outer chrome for the Chart Panel — title header, total badge, and state
 * management (loading skeleton, error, empty). Children are the chart.
 */
export function PanelChrome({
  title,
  totalBadge,
  isLoading,
  error,
  empty,
  height,
  children,
  capped = false,
  rowCount,
  total,
}: PanelChromeProps) {
  return (
    <div className="dq-card flex flex-col gap-4" data-testid="chart-panel">
      <div className="flex items-center justify-between gap-2">
        <h2 className="dq-card-title">{title}</h2>
        {totalBadge !== undefined && (
          <span
            className="rounded-pill border border-[color-mix(in_srgb,var(--color-primary)_20%,transparent)] bg-[var(--color-navy-50)] px-2.5 py-0.5 font-mono text-xs font-medium tabular-nums text-[var(--color-primary)]"
            data-testid="panel-total-badge"
          >
            {totalBadge}
          </span>
        )}
      </div>

      {capped && !isLoading && !error && (
        <Alert tone="warning" variant="compact" data-testid="chart-panel-cap-banner">
          Showing first {formatNumber(rowCount ?? 0)} of {formatNumber(total ?? rowCount ?? 0)} — totals are partial
        </Alert>
      )}

      {isLoading ? (
        <div
          role="status"
          aria-label="Loading"
          className="flex flex-col gap-2"
          data-testid="chart-panel-loading"
          style={{ height }}
        >
          <Skeleton className="h-4 w-1/3" />
          <Skeleton style={{ height: height - 32, width: "100%" }} />
        </div>
      ) : error ? (
        <EmptyState
          tone="danger"
          headline="Failed to load"
          description={error.message}
          data-testid="chart-panel-error"
          style={{ minHeight: height }}
        />
      ) : empty ? (
        <EmptyState
          icon={<BarChart3 size={22} strokeWidth={1.5} />}
          title="No data"
          data-testid="chart-panel-empty"
          style={{ minHeight: height }}
        />
      ) : (
        children
      )}
    </div>
  );
}
