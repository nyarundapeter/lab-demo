import * as React from "react";
import {
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { formatNumber } from "@dbp/ui";
import { getChartPalette } from "./chart-colors.js";

export interface PieChartDatum {
  name: string;
  value: number;
}

export interface PieChartProps {
  data: PieChartDatum[];
  donut?: boolean;
  showLegend?: boolean;
  height?: number | string;
  palette?: string[];
  legendFontSize?: number;
  outerRadius?: number | string;
  /** "percent" shows "Label 24% (75)"; "plain" shows just the series name. Defaults to "percent". */
  legendFormat?: "percent" | "plain";
  testId?: string;
}

/**
 * Canonical recharts pie-chart atom shared by `chart-panel` (ANL.F02) and
 * `widget-grid` (ANL.F01). See `bar-chart.tsx` for why this lives here
 * rather than in `@dbp/ui`.
 */
export function PieChart({
  data,
  donut = false,
  showLegend = false,
  height = "100%",
  palette,
  legendFontSize = 11,
  outerRadius = "65%",
  legendFormat = "percent",
  testId = "chart-container",
}: PieChartProps) {
  const resolvedPalette = React.useMemo(() => palette ?? getChartPalette(), [palette]);

  const total = data.reduce((sum, entry) => sum + entry.value, 0);
  const legendFormatter = (value: string, entry: { payload?: { value?: number } }) => {
    const entryValue = entry.payload?.value ?? 0;
    const pct = total > 0 ? Math.round((entryValue / total) * 100) : 0;
    return `${value} ${pct}% (${formatNumber(entryValue)})`;
  };

  return (
    <div
      data-testid={testId}
      data-legend={showLegend ? "true" : "false"}
      data-donut={donut ? "true" : "false"}
      style={{ height, position: "relative" }}
      className="w-full"
    >
      {donut && (
        <div
          data-testid="pie-center-label"
          className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center"
        >
          <span className="font-mono text-2xl font-bold tabular-nums text-[var(--color-text)]">
            {formatNumber(total, { compact: total >= 10_000 })}
          </span>
          <span className="text-xs text-[var(--color-text-muted)]">Total</span>
        </div>
      )}
      <ResponsiveContainer width="100%" height="100%">
        <RechartsPieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            innerRadius={donut ? "45%" : 0}
            outerRadius={outerRadius}
            strokeWidth={1}
            stroke="var(--color-surface)"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${entry.name}`} fill={resolvedPalette[index % resolvedPalette.length]} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              background: "var(--color-surface)",
              border: "1px solid var(--color-border)",
              borderRadius: "var(--radius)",
              fontSize: 12,
            }}
          />
          {showLegend && (
            <Legend
              iconSize={10}
              wrapperStyle={{ fontSize: legendFontSize, color: "var(--color-text)" }}
              {...(legendFormat === "percent" && { formatter: legendFormatter })}
            />
          )}
        </RechartsPieChart>
      </ResponsiveContainer>
    </div>
  );
}
