import * as React from "react";
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { formatNumber } from "@dbp/ui";
import { getChartPalette } from "./chart-colors.js";

export interface BarChartSeries {
  dataKey: string;
  name?: string;
  stackId?: string;
}

export interface BarChartProps {
  data: Record<string, string | number>[];
  series: BarChartSeries[];
  /** Category dataKey read off each data point. Defaults to "category". */
  categoryKey?: string;
  horizontal?: boolean;
  showLegend?: boolean;
  /** Chart height. Accepts any CSS height value or number of px. */
  height?: number | string;
  /** Series colours, in order. Defaults to the brand chart palette. */
  palette?: string[];
  tickFontSize?: number;
  yAxisWidth?: number;
  maxBarSize?: number;
  testId?: string;
}

const compactTickFormatter = (value: unknown) => {
  const n = Number(value);
  return Number.isFinite(n) ? formatNumber(n, { compact: true }) : String(value);
};

const compactTooltipFormatter = (value: unknown) => {
  const n = Number(value);
  return Number.isFinite(n) ? formatNumber(n, { compact: Math.abs(n) >= 10_000 }) : String(value);
};

/** Turns a raw category value (often a slug like "in-progress") into readable text. */
function readableCategory(value: unknown): string {
  const s = String(value);
  return s.replace(/[-_]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Truncates a readable category label so long values don't overlap under narrow bars. */
function categoryTickFormatter(value: unknown): string {
  const label = readableCategory(value);
  return label.length > 14 ? `${label.slice(0, 13)}…` : label;
}

/**
 * Canonical recharts bar-chart atom shared by `chart-panel` (ANL.F02) and
 * `widget-grid` (ANL.F01) — both previously carried independent
 * implementations of the same chart. Kept inside `chart-panel` rather than
 * `@dbp/ui` because `@dbp/ui` deliberately excludes recharts (bundle-weight
 * ruling, 2026-07-16) — this atom is a within-package (`@dbp/organisms`)
 * shared primitive, not a `@dbp/ui` primitive.
 */
export function BarChart({
  data,
  series,
  categoryKey = "category",
  horizontal = false,
  showLegend = false,
  height = "100%",
  palette,
  tickFontSize = 11,
  yAxisWidth = 56,
  maxBarSize = 56,
  testId = "chart-container",
}: BarChartProps) {
  const resolvedPalette = React.useMemo(() => palette ?? getChartPalette(), [palette]);

  return (
    <div
      data-testid={testId}
      data-legend={showLegend ? "true" : "false"}
      data-orientation={horizontal ? "horizontal" : "vertical"}
      style={{ height }}
      className="w-full"
    >
      <ResponsiveContainer width="100%" height="100%">
        <RechartsBarChart
          data={data}
          layout={horizontal ? "vertical" : "horizontal"}
          margin={{ top: 4, right: 16, bottom: horizontal ? 4 : 12, left: 0 }}
        >
          {/* XAxis/YAxis are rendered as direct BarChart children (not through an
              intermediate variable + Fragment) — recharts locates its axis
              components by walking `props.children` for elements whose displayName
              matches "XAxis"/"YAxis"; nesting them inside a ternary-selected
              Fragment caused that lookup to come back empty (no visible axis,
              bars stuck at their zero-state). */}
          {horizontal ? (
            <XAxis
              type="number"
              tick={{ fontSize: tickFontSize, fill: "var(--color-text)" }}
              axisLine={false}
              tickLine={false}
              tickFormatter={compactTickFormatter}
            />
          ) : (
            <XAxis
              type="category"
              dataKey={categoryKey}
              tick={{ fontSize: tickFontSize, fill: "var(--color-text)" }}
              axisLine={false}
              tickLine={false}
              interval={0}
              angle={-20}
              textAnchor="end"
              height={48}
              tickFormatter={categoryTickFormatter}
            />
          )}
          {horizontal ? (
            <YAxis
              type="category"
              dataKey={categoryKey}
              tick={{ fontSize: tickFontSize, fill: "var(--color-text)" }}
              axisLine={false}
              tickLine={false}
              width={96}
              tickFormatter={categoryTickFormatter}
            />
          ) : (
            <YAxis
              type="number"
              tick={{ fontSize: tickFontSize, fill: "var(--color-text)" }}
              axisLine={false}
              tickLine={false}
              width={yAxisWidth}
              tickFormatter={compactTickFormatter}
            />
          )}
          <Tooltip
            contentStyle={{
              background: "var(--color-surface)",
              border: "1px solid var(--color-border)",
              borderRadius: "var(--radius)",
              fontSize: 12,
            }}
            formatter={compactTooltipFormatter}
            labelFormatter={readableCategory}
          />
          {showLegend && (
            <Legend
              iconSize={10}
              wrapperStyle={{ fontSize: 11, color: "var(--color-text)" }}
            />
          )}
          {series.map((s, i) => {
            const color = resolvedPalette[i % resolvedPalette.length] ?? "var(--color-text-muted)";
            return (
              <Bar
                key={s.dataKey}
                dataKey={s.dataKey}
                name={s.name ?? s.dataKey}
                fill={color}
                radius={[4, 4, 0, 0]}
                maxBarSize={maxBarSize}
                {...(s.stackId && { stackId: s.stackId })}
              />
            );
          })}
        </RechartsBarChart>
      </ResponsiveContainer>
    </div>
  );
}
