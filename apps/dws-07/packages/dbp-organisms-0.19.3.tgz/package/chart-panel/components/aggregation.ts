import type { EntityData, EntityRecord } from "@dbp/ps-data/client";

type AggregateOp = "count" | "sum" | "avg";

function aggregateRows(
  rows: EntityRecord<EntityData>[],
  field: string,
  op: AggregateOp,
): number {
  if (op === "count") return rows.length;

  const nums = rows.map((r) => {
    const v = (r.data as Record<string, unknown>)[field];
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  });

  if (nums.length === 0) return 0;
  const total = nums.reduce((acc, n) => acc + n, 0);
  return op === "sum" ? total : total / nums.length;
}

export interface SeriesEntry {
  valueField: string;
  label?: string | undefined;
  aggregate: AggregateOp;
}

export interface ChartDataPoint {
  category: string;
  [seriesKey: string]: string | number;
}

/**
 * Groups rows by categoryField, aggregates each series per group, and
 * returns data points sorted descending by the first series value,
 * capped to `limit`.
 */
export function buildChartData(
  rows: EntityRecord<EntityData>[],
  categoryField: string,
  series: SeriesEntry[],
  limit = 20,
): ChartDataPoint[] {
  const groups = new Map<string, EntityRecord<EntityData>[]>();

  for (const row of rows) {
    const cat = String((row.data as Record<string, unknown>)[categoryField] ?? "");
    const existing = groups.get(cat);
    if (existing) {
      existing.push(row);
    } else {
      groups.set(cat, [row]);
    }
  }

  const points: ChartDataPoint[] = [];
  for (const [category, groupRows] of groups) {
    const point: ChartDataPoint = { category };
    for (const s of series) {
      point[s.valueField] = aggregateRows(groupRows, s.valueField, s.aggregate);
    }
    points.push(point);
  }

  const firstField = series[0]?.valueField ?? "";
  points.sort((a, b) => {
    const bVal = typeof b[firstField] === "number" ? (b[firstField] as number) : 0;
    const aVal = typeof a[firstField] === "number" ? (a[firstField] as number) : 0;
    return bVal - aVal;
  });

  return points.slice(0, limit);
}

/**
 * Computes the total (sum) of a numeric series key across all data points.
 * Used for the panel total badge.
 */
export function sumSeries(points: ChartDataPoint[], valueField: string): number {
  return points.reduce((acc, p) => {
    const v = p[valueField];
    return acc + (typeof v === "number" ? v : 0);
  }, 0);
}

export interface HeatmapGridData {
  rows: string[];
  cols: string[];
  data: number[][];
}

const HEATMAP_KEY_SEPARATOR = "|||";

/**
 * Groups rows by (rowField, categoryField) pairs and aggregates the single
 * series value per cell. Row and column labels are sorted alphabetically;
 * missing combinations aggregate to 0.
 */
export function buildHeatmapData(
  rows: EntityRecord<EntityData>[],
  rowField: string,
  colField: string,
  series: SeriesEntry,
): HeatmapGridData {
  const cellGroups = new Map<string, EntityRecord<EntityData>[]>();
  const rowLabels = new Set<string>();
  const colLabels = new Set<string>();

  for (const row of rows) {
    const r = String((row.data as Record<string, unknown>)[rowField] ?? "");
    const c = String((row.data as Record<string, unknown>)[colField] ?? "");
    rowLabels.add(r);
    colLabels.add(c);
    const key = [r, c].join(HEATMAP_KEY_SEPARATOR);
    const existing = cellGroups.get(key);
    if (existing) {
      existing.push(row);
    } else {
      cellGroups.set(key, [row]);
    }
  }

  const sortedRows = [...rowLabels].sort();
  const sortedCols = [...colLabels].sort();

  const data = sortedRows.map((r) =>
    sortedCols.map((c) => {
      const groupRows = cellGroups.get([r, c].join(HEATMAP_KEY_SEPARATOR)) ?? [];
      return aggregateRows(groupRows, series.valueField, series.aggregate);
    }),
  );

  return { rows: sortedRows, cols: sortedCols, data };
}
