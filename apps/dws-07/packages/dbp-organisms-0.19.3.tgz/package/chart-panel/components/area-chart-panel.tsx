import * as React from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { formatNumber } from "@dbp/ui";
import type { ChartPanelConfig } from "../types.js";
import type { ChartDataPoint } from "./aggregation.js";
import { getChartPalette } from "./chart-colors.js";

interface AreaChartPanelProps {
  config: ChartPanelConfig;
  data: ChartDataPoint[];
}

const compactTickFormatter = (value: unknown) => {
  const n = Number(value);
  return Number.isFinite(n) ? formatNumber(n, { compact: true }) : String(value);
};

const compactTooltipFormatter = (value: unknown) => {
  const n = Number(value);
  return Number.isFinite(n) ? formatNumber(n, { compact: Math.abs(n) >= 10_000 }) : String(value);
};

export function AreaChartPanel({ config, data }: AreaChartPanelProps) {
  const palette = React.useMemo(() => getChartPalette(), []);

  return (
    <div
      data-testid="chart-container"
      data-legend={config.showLegend ? "true" : "false"}
      style={{ height: config.height }}
      className="w-full"
    >
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 4, right: 16, bottom: 4, left: 0 }}>
          <XAxis
            dataKey="category"
            tick={{ fontSize: 11, fill: "var(--color-text)" }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: "var(--color-text)" }}
            axisLine={false}
            tickLine={false}
            width={56}
            tickFormatter={compactTickFormatter}
          />
          <Tooltip
            contentStyle={{
              background: "var(--color-surface)",
              border: "1px solid var(--color-border)",
              borderRadius: "var(--radius)",
              fontSize: 12,
            }}
            formatter={compactTooltipFormatter}
          />
          {config.showLegend && (
            <Legend
              iconSize={10}
              wrapperStyle={{ fontSize: 11, color: "var(--color-text)" }}
            />
          )}
          {config.series.map((s, i) => {
            const color = palette[i % palette.length] ?? "var(--color-text-muted)";
            return (
              <Area
                key={s.valueField}
                type="monotone"
                dataKey={s.valueField}
                name={s.label ?? s.valueField}
                stroke={color}
                fill={color}
                fillOpacity={0.25}
                strokeWidth={2}
                {...(config.stacked && { stackId: "stack" })}
              />
            );
          })}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
