import * as React from "react";
import { HealthStatusCard, Skeleton, EmptyState, formatNumber } from "@dbp/ui";
import { LayoutDashboard } from "lucide-react";
import type { ChartPanelConfig } from "../types.js";
import type { ChartDataPoint } from "./aggregation.js";
import { sumSeries } from "./aggregation.js";

interface SummaryChartPanelProps {
  config: ChartPanelConfig;
  data: ChartDataPoint[];
  isLoading: boolean;
  error: Error | null;
}

/**
 * Renders the aggregated total as a headline with the top categories as
 * sub-metrics (dash-components.jsx:110-131). HealthStatusCard already carries its
 * own `dq-card` surface + title, so this bypasses PanelChrome's outer card
 * (avoids a nested-card look) and owns its own loading/error/empty states.
 *
 * Status is left "info" — there is no health-scoring model behind this data,
 * so no on-track/at-risk judgement is invented.
 */
export function SummaryChartPanel({ config, data, isLoading, error }: SummaryChartPanelProps) {
  const firstSeries = config.series[0]!;

  if (isLoading) {
    return (
      <div className="dq-card flex flex-col gap-3" role="status" aria-label="Loading" style={{ minHeight: config.height }}>
        <Skeleton className="h-4 w-1/3" />
        <Skeleton className="h-7 w-1/2" />
        <Skeleton className="h-3 w-full" />
      </div>
    );
  }

  if (error) {
    return (
      <EmptyState
        tone="danger"
        headline="Failed to load"
        description={error.message}
        data-testid="summary-chart-panel-error"
        style={{ minHeight: config.height }}
      />
    );
  }

  if (data.length === 0) {
    return (
      <div className="dq-card" style={{ minHeight: config.height }}>
        <EmptyState
          icon={<LayoutDashboard size={22} strokeWidth={1.5} />}
          title="No data"
          data-testid="summary-chart-panel-empty"
        />
      </div>
    );
  }

  const total = sumSeries(data, firstSeries.valueField);
  const subMetrics = data.slice(0, 4).map((p) => ({
    label: p.category,
    value: formatNumber(
      typeof p[firstSeries.valueField] === "number" ? (p[firstSeries.valueField] as number) : 0,
      { compact: true },
    ),
  }));

  return (
    <HealthStatusCard
      title={config.title}
      status="info"
      headline={formatNumber(total, { compact: total >= 10_000 })}
      subMetrics={subMetrics}
      style={{ minHeight: config.height }}
    />
  );
}
