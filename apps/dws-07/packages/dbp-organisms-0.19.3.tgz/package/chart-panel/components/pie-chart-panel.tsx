import type { ChartPanelConfig } from "../types.js";
import type { ChartDataPoint } from "./aggregation.js";
import { PieChart } from "./pie-chart.js";

interface PieChartPanelProps {
  config: ChartPanelConfig;
  /** For pie charts, series[0] is the only series used. */
  data: ChartDataPoint[];
}

export function PieChartPanel({ config, data }: PieChartPanelProps) {
  const firstSeries = config.series[0]!;

  // Recharts Pie expects [{ name, value }] shape for its built-in tooltip/legend.
  const pieData = data.map((p) => ({
    name: p.category,
    value: typeof p[firstSeries.valueField] === "number" ? (p[firstSeries.valueField] as number) : 0,
  }));

  return (
    <PieChart
      data={pieData}
      donut={config.donut === true}
      showLegend={config.showLegend}
      height={config.height}
    />
  );
}
