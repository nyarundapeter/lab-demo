/**
 * Chart color palette derived from CSS design tokens so that theme swaps
 * propagate to charts without any hardcoded hex values.
 *
 * Canonical source — consumed by both `chart-panel` and `widget-grid`
 * (`../../widget-grid/components/chart-colors.js` re-exports this file;
 * see Wave 1.F chart-primitive consolidation, CHANGELOG "Unreleased —
 * Wave 1.F/G"). Previously these two features carried independent,
 * near-identical copies that had drifted: widget-grid used
 * `--color-navy-400` for the 3rd palette entry (a deliberate readability
 * fix — navy-200 was too light against white chart backgrounds) and wider
 * opacity steps (.8/.6 vs .7/.45). This file adopts the navy-400 fix as
 * canonical for both consumers.
 *
 * Built at call time (not module load) so CSS variables resolve against
 * the document root present when the chart first renders.
 * In a test/SSR environment getComputedStyle may not be available —
 * the fallback palette uses the default token values from base.css.
 */

const FALLBACK_PALETTE = [
  "#030F35", // navy (primary)
  "#FB5535", // orange (secondary)
  "#4B63C8", // navy-400 ramp — readable contrast for the 3rd series
  "#F24C2A", // orange-600 ramp
  "#030F35B3", // navy 70%
  "#FB5535B3", // orange 70%
  "#030F3573", // navy 45%
  "#FB553573", // orange 45%
];

function resolveCssVar(name: string, fallback: string): string {
  if (typeof document === "undefined") return fallback;
  const value = getComputedStyle(document.documentElement)
    .getPropertyValue(name)
    .trim();
  return value || fallback;
}

function withOpacity(hex: string, opacity: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) return hex;
  return `rgba(${r},${g},${b},${opacity})`;
}

/** Deepen a #rrggbb toward black by `amt` (0–1). Used for the accent ramp shade. */
function darken(hex: string, amt: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) return hex;
  const f = (c: number) => Math.max(0, Math.round(c * (1 - amt)));
  const h = (c: number) => f(c).toString(16).padStart(2, "0");
  return `#${h(r)}${h(g)}${h(b)}`;
}

export function getChartPalette(): string[] {
  const primary = resolveCssVar("--color-primary", "#030F35");
  const secondary = resolveCssVar("--color-secondary", "#FB5535");
  // navy-400 provides readable contrast for the 3rd series — navy-200 was
  // too light against a white chart background.
  const navyRamp = resolveCssVar("--color-navy-400", "#4B63C8");

  const p100 = primary.startsWith("#") ? primary : FALLBACK_PALETTE[0]!;
  const s100 = secondary.startsWith("#") ? secondary : FALLBACK_PALETTE[1]!;
  const navy = navyRamp.startsWith("#") ? navyRamp : FALLBACK_PALETTE[2]!;
  // Accent ramp derived from the BRAND accent (--color-secondary), not a fixed
  // orange — so charts follow the solution brand. --color-orange-600 is now a
  // color-mix() expression (non-hex) and can't be read back as a hex, so we
  // deepen the secondary directly.
  const accentRamp = s100.startsWith("#") ? darken(s100, 0.12) : FALLBACK_PALETTE[3]!;

  // Brand primary/secondary first, then navy/accent ramp tints, then opacity steps.
  return [
    p100,
    s100,
    navy,
    accentRamp,
    withOpacity(p100, 0.7),
    withOpacity(s100, 0.7),
    withOpacity(p100, 0.45),
    withOpacity(s100, 0.45),
  ];
}
