import * as React from "react";
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
} from "recharts";
import { formatNumber } from "@dbp/ui";
import { getChartPalette } from "./chart-colors.js";

export interface LineChartSeries {
  dataKey: string;
  name?: string;
}

export interface LineChartProps {
  data: Record<string, string | number>[];
  series: LineChartSeries[];
  /** Category dataKey read off each data point. Defaults to "category". */
  categoryKey?: string;
  showLegend?: boolean;
  height?: number | string;
  palette?: string[];
  tickFontSize?: number;
  yAxisWidth?: number;
  /** Reference value drawn as a horizontal target line. */
  targetValue?: number;
  testId?: string;
}

const compactTickFormatter = (value: unknown) => {
  const n = Number(value);
  return Number.isFinite(n) ? formatNumber(n, { compact: true }) : String(value);
};

const compactTooltipFormatter = (value: unknown) => {
  const n = Number(value);
  return Number.isFinite(n) ? formatNumber(n, { compact: Math.abs(n) >= 10_000 }) : String(value);
};

/**
 * Canonical recharts line-chart atom shared by `chart-panel` (ANL.F02) and
 * `widget-grid` (ANL.F01). See `bar-chart.tsx` for why this lives here
 * rather than in `@dbp/ui`.
 */
export function LineChart({
  data,
  series,
  categoryKey = "category",
  showLegend = false,
  height = "100%",
  palette,
  tickFontSize = 11,
  yAxisWidth = 56,
  targetValue,
  testId = "chart-container",
}: LineChartProps) {
  const resolvedPalette = React.useMemo(() => palette ?? getChartPalette(), [palette]);

  return (
    <div
      data-testid={testId}
      data-legend={showLegend ? "true" : "false"}
      style={{ height }}
      className="w-full"
    >
      <ResponsiveContainer width="100%" height="100%">
        <RechartsLineChart data={data} margin={{ top: 4, right: 16, bottom: 4, left: 0 }}>
          <XAxis
            dataKey={categoryKey}
            tick={{ fontSize: tickFontSize, fill: "var(--color-text)" }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: tickFontSize, fill: "var(--color-text)" }}
            axisLine={false}
            tickLine={false}
            width={yAxisWidth}
            tickFormatter={compactTickFormatter}
          />
          <Tooltip
            contentStyle={{
              background: "var(--color-surface)",
              border: "1px solid var(--color-border)",
              borderRadius: "var(--radius)",
              fontSize: 12,
            }}
            formatter={compactTooltipFormatter}
          />
          {showLegend && (
            <Legend
              iconSize={10}
              wrapperStyle={{ fontSize: 11, color: "var(--color-text)" }}
            />
          )}
          {targetValue !== undefined && (
            <ReferenceLine
              y={targetValue}
              stroke="var(--color-text-muted)"
              strokeDasharray="4 4"
              label={{
                value: "Target",
                position: "insideTopRight",
                fontSize: 11,
                fill: "var(--color-text-muted)",
              }}
            />
          )}
          {series.map((s, i) => (
            <Line
              key={s.dataKey}
              type="monotone"
              dataKey={s.dataKey}
              name={s.name ?? s.dataKey}
              stroke={resolvedPalette[i % resolvedPalette.length]}
              strokeWidth={2}
              dot={{ fill: resolvedPalette[i % resolvedPalette.length], r: 3 }}
              activeDot={{ r: 5 }}
            />
          ))}
        </RechartsLineChart>
      </ResponsiveContainer>
    </div>
  );
}
