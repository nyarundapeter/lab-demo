import * as React from "react";
import { Heatmap, formatNumber } from "@dbp/ui";
import type { ChartPanelConfig } from "../types.js";
import type { HeatmapGridData } from "./aggregation.js";

interface HeatmapChartPanelProps {
  config: ChartPanelConfig;
  grid: HeatmapGridData;
}

/** Sequential low-to-high colour scale driven off the data's own min/max. */
function makeColorFor(data: number[][]) {
  const flat = data.flat();
  const min = flat.length ? Math.min(...flat) : 0;
  const max = flat.length ? Math.max(...flat) : 1;
  const range = max - min || 1;

  return (value: number) => {
    const pct = Math.round(((value - min) / range) * 100);
    return {
      bg: `color-mix(in srgb, var(--color-primary) ${Math.max(8, pct)}%, white)`,
      fg: pct > 55 ? "white" : "var(--color-text)",
    };
  };
}

export function HeatmapChartPanel({ config, grid }: HeatmapChartPanelProps) {
  const colorFor = React.useMemo(() => makeColorFor(grid.data), [grid.data]);

  return (
    <div data-testid="chart-container" style={{ minHeight: config.height }} className="w-full">
      <Heatmap
        rows={grid.rows}
        cols={grid.cols}
        data={grid.data}
        colorFor={colorFor}
        cellText={(v) => formatNumber(v, { compact: v >= 10_000 })}
        ariaLabel={config.title}
      />
    </div>
  );
}
