import * as React from "react";
import { Funnel } from "@dbp/ui";
import type { ChartPanelConfig } from "../types.js";
import type { ChartDataPoint } from "./aggregation.js";
import { getChartPalette } from "./chart-colors.js";

interface FunnelChartPanelProps {
  config: ChartPanelConfig;
  data: ChartDataPoint[];
}

export function FunnelChartPanel({ config, data }: FunnelChartPanelProps) {
  const palette = React.useMemo(() => getChartPalette(), []);
  const firstSeries = config.series[0]!;

  const stages = data.map((p, i) => ({
    label: p.category,
    value: typeof p[firstSeries.valueField] === "number" ? (p[firstSeries.valueField] as number) : 0,
    color: palette[i % palette.length],
  }));

  return (
    <div data-testid="chart-container" style={{ minHeight: config.height }} className="w-full">
      <Funnel stages={stages} />
    </div>
  );
}
