import type { ChartPanelConfig } from "../types.js";
import type { ChartDataPoint } from "./aggregation.js";
import { LineChart } from "./line-chart.js";

interface LineChartPanelProps {
  config: ChartPanelConfig;
  data: ChartDataPoint[];
}

export function LineChartPanel({ config, data }: LineChartPanelProps) {
  return (
    <LineChart
      data={data}
      series={config.series.map((s) => ({ dataKey: s.valueField, name: s.label ?? s.valueField }))}
      showLegend={config.showLegend}
      height={config.height}
      {...(config.targetValue !== undefined && { targetValue: config.targetValue })}
    />
  );
}
