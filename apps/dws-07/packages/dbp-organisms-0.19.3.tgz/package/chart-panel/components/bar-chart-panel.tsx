import type { ChartPanelConfig } from "../types.js";
import type { ChartDataPoint } from "./aggregation.js";
import { BarChart } from "./bar-chart.js";

interface BarChartPanelProps {
  config: ChartPanelConfig;
  data: ChartDataPoint[];
}

export function BarChartPanel({ config, data }: BarChartPanelProps) {
  return (
    <BarChart
      data={data}
      series={config.series.map((s) => ({
        dataKey: s.valueField,
        name: s.label ?? s.valueField,
        ...(config.stacked && { stackId: "stack" }),
      }))}
      horizontal={config.horizontal === true}
      showLegend={config.showLegend}
      height={config.height}
    />
  );
}
