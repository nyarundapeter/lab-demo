import * as React from "react";
import { Ranking, formatNumber } from "@dbp/ui";
import type { ChartPanelConfig } from "../types.js";
import type { ChartDataPoint } from "./aggregation.js";

interface RankingChartPanelProps {
  config: ChartPanelConfig;
  data: ChartDataPoint[];
}

/** Renders aggregated category rows as a ranked leaderboard (dash-components.jsx:202-214). */
export function RankingChartPanel({ config, data }: RankingChartPanelProps) {
  const firstSeries = config.series[0]!;

  const items = data.map((p) => ({
    name: p.category,
    value: typeof p[firstSeries.valueField] === "number" ? (p[firstSeries.valueField] as number) : 0,
  }));

  return (
    <div data-testid="chart-container" style={{ minHeight: config.height }} className="w-full overflow-auto">
      <Ranking items={items} format={(v) => formatNumber(v, { compact: v >= 10_000 })} />
    </div>
  );
}
