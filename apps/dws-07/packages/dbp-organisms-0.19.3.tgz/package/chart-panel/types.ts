import { z } from "zod";

const SeriesSchema = z.object({
  valueField: z.string().min(1),
  label: z.string().optional(),
  aggregate: z.enum(["count", "sum", "avg"]),
});
export type Series = z.infer<typeof SeriesSchema>;

/**
 * ChartPanelConfig — the single typed contract for ANL.F02.
 *
 * DATA contract only (no function fields — Zod schemas are data-only).
 *
 * Pie charts use only the first series; the pie refine below enforces this
 * when series.length > 1 with chartType "pie" (treated as config-error,
 * not a throw).
 */
export const ChartPanelConfig = z
  .object({
    title: z.string().min(1),
    entityType: z.string().min(1),
    chartType: z.enum(["bar", "line", "area", "pie", "heatmap", "funnel", "ranking", "summary"]),
    /**
     * Category field. For "heatmap" this is the COLUMN dimension; pair it
     * with `rowField` for the row dimension. For "funnel" each distinct
     * value becomes a stage, ordered by descending series value. For
     * "ranking" each distinct value becomes a ranked row. For "summary"
     * each distinct value becomes a sub-metric under the portfolio headline.
     */
    categoryField: z.string().min(1),
    /** Row dimension — required only when `chartType` is "heatmap". */
    rowField: z.string().min(1).optional(),
    series: z.array(SeriesSchema).min(1).max(3),
    filters: z
      .record(z.string(), z.union([z.string(), z.number(), z.boolean()]))
      .optional(),
    /** Top-N categories by first-series value. */
    limit: z.number().int().min(1).max(100).optional(),
    /** Stack series — applies to bar and area chart types. */
    stacked: z.boolean().optional(),
    /** Render the bar chart horizontally (categories on the Y axis). */
    horizontal: z.boolean().optional(),
    /** Render the pie chart as a donut with a center total label. */
    donut: z.boolean().optional(),
    /** Reference value drawn as a horizontal target line on line charts. */
    targetValue: z.number().optional(),
    showLegend: z.boolean().default(true),
    /** Height of the chart in pixels. */
    height: z.number().int().min(100).max(2000).default(320),
  })
  .superRefine((val, ctx) => {
    if (
      (val.chartType === "pie" || val.chartType === "funnel" || val.chartType === "ranking" || val.chartType === "summary") &&
      val.series.length > 1
    ) {
      const chartName =
        val.chartType === "pie" ? "Pie" : val.chartType === "funnel" ? "Funnel" : val.chartType === "ranking" ? "Ranking" : "Summary";
      ctx.addIssue({
        code: z.ZodIssueCode.too_big,
        maximum: 1,
        type: "array",
        inclusive: true,
        path: ["series"],
        message: `${chartName} charts support only one series`,
      });
    }
    if (val.chartType === "heatmap") {
      if (val.series.length > 1) {
        ctx.addIssue({
          code: z.ZodIssueCode.too_big,
          maximum: 1,
          type: "array",
          inclusive: true,
          path: ["series"],
          message: "Heatmap charts support only one series",
        });
      }
      if (!val.rowField) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["rowField"],
          message: "rowField is required when chartType is \"heatmap\"",
        });
      }
    }
  });

export type ChartPanelConfig = z.infer<typeof ChartPanelConfig>;
