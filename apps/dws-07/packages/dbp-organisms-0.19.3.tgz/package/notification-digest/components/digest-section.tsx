import React from "react";
import { ChevronDown, ChevronUp, Flag, RefreshCw, Clock, AtSign, CheckCircle2, type LucideIcon } from "lucide-react";
import { Badge, Button } from "@dbp/ui";
import type { DigestSectionKind } from "../types.js";

export interface DigestSectionMeta {
  icon: LucideIcon;
  label: string;
  toneClass: string;
}

/** Section-kind vocabulary — icon, default title, tone (notif-digest.jsx:59-77). */
export const DIGEST_SECTION_META: Record<DigestSectionKind, DigestSectionMeta> = {
  action: { icon: Flag, label: "Needs action", toneClass: "text-[var(--color-warning)]" },
  changes: { icon: RefreshCw, label: "Important changes", toneClass: "text-[var(--color-info)]" },
  deadlines: { icon: Clock, label: "Upcoming deadlines", toneClass: "text-[var(--color-warning)]" },
  mentions: { icon: AtSign, label: "Mentions", toneClass: "text-[var(--color-info)]" },
  completed: { icon: CheckCircle2, label: "Completed", toneClass: "text-[var(--color-success)]" },
};

interface Props {
  kind: DigestSectionKind;
  title?: string;
  count: number;
  defaultOpen?: boolean;
  children: React.ReactNode;
}

/** A collapsible digest group — port of notif-digest.jsx's `DigestSection`. */
export function DigestSection({ kind, title, count, defaultOpen = true, children }: Props) {
  const [open, setOpen] = React.useState(defaultOpen);
  const meta = DIGEST_SECTION_META[kind];
  const Icon = meta.icon;

  return (
    <div className="border-b border-[var(--color-border-subtle)] last:border-b-0">
      <Button
        type="button"
        variant="ghost"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="h-auto w-full justify-start gap-2.5 rounded-none px-4 py-3 text-left font-normal focus-visible:[box-shadow:var(--focus-ring-navy)]"
      >
        <Icon size={14} className={meta.toneClass} aria-hidden="true" />
        <span className="text-sm font-semibold text-[var(--color-text)]">{title ?? meta.label}</span>
        <Badge size="sm">{count}</Badge>
        <div className="ml-auto" />
        {open ? (
          <ChevronUp size={15} className="text-[var(--color-text-muted)]" aria-hidden="true" />
        ) : (
          <ChevronDown size={15} className="text-[var(--color-text-muted)]" aria-hidden="true" />
        )}
      </Button>
      {open && <div className="pl-10 pr-4 pb-3.5">{children}</div>}
    </div>
  );
}
