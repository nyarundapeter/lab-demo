import React from "react";
import { Button } from "@dbp/ui";
import type { DigestRow as DigestRowData } from "../types.js";

interface Props {
  row: DigestRowData;
  onAction?: () => void;
}

/** A single line item within a `DigestSection` — port of notif-digest.jsx's `DigestRow`. */
export function DigestRow({ row, onAction }: Props) {
  return (
    <div className="flex items-center gap-2.5 border-t border-[var(--color-border-subtle)]/60 py-1.5 first:border-t-0">
      <div className="min-w-0 flex-1">
        <div className="text-xs font-medium text-[var(--color-text)]">{row.title}</div>
        <div className="mt-0.5 text-xs text-[var(--color-text-muted)]">{row.meta}</div>
      </div>
      {row.action && (
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-auto shrink-0 px-1.5 py-0.5 text-xs text-[var(--color-primary)]"
          onClick={onAction}
        >
          {row.action}
        </Button>
      )}
    </div>
  );
}
