import React from "react";
import { Mail } from "lucide-react";
import { useDigestSettings } from "@dbp/ps-notif/client";
import type { DigestFrequency } from "@dbp/ps-notif/client";
import { Alert, AiMark, Button } from "@dbp/ui";
import { DigestSection } from "./components/digest-section.js";
import { DigestRow } from "./components/digest-row.js";
import { NotificationDigestConfig, type NotificationDigestConfigInput } from "./types.js";

export { DigestSection } from "./components/digest-section.js";
export { DigestRow } from "./components/digest-row.js";
export { DIGEST_SECTION_META } from "./components/digest-section.js";

const FREQUENCY_OPTIONS: { value: DigestFrequency; label: string }[] = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "realtime", label: "Off" },
];

const FREQUENCY_NOUN: Record<DigestFrequency, string> = {
  daily: "daily",
  weekly: "weekly",
  realtime: "real-time",
};

export interface NotificationDigestProps extends NotificationDigestConfigInput {
  onRowAction?: (sectionKind: string, rowTitle: string) => void;
  onMarkAllRead?: () => void;
  onViewAll?: () => void;
}

/**
 * APP.F67 (placeholder — central registration assigns the real id) —
 * Notification Digest
 *
 * Batches low/medium-priority updates into one calm, scannable summary
 * (notif-digest.jsx `DigestView`/`DigestSection`/`DigestRow`) — urgent and
 * critical items always bypass the digest and deliver immediately (enforced
 * server-side, not this component's concern). The frequency control is a
 * real PS.NOTIF binding (`useDigestSettings` — genuinely persisted, no
 * scheduler behind it yet per that hook's own doc-comment); section content
 * is prop-driven, same as the rest of the AI card family. The reference's
 * fourth "Team" frequency has no PS.NOTIF equivalent (3-value
 * `DigestFrequencySchema`: realtime/daily/weekly) and is intentionally
 * dropped rather than faked.
 */
export default function NotificationDigest(props: NotificationDigestProps) {
  const { onRowAction, onMarkAllRead, onViewAll, ...config } = props;
  const parsed = NotificationDigestConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="NotificationDigest — invalid config" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") || "root"}: {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <NotificationDigestInner
      config={parsed.data}
      {...(onRowAction !== undefined && { onRowAction })}
      {...(onMarkAllRead !== undefined && { onMarkAllRead })}
      {...(onViewAll !== undefined && { onViewAll })}
    />
  );
}

function NotificationDigestInner({
  config,
  onRowAction,
  onMarkAllRead,
  onViewAll,
}: {
  config: NotificationDigestConfig;
  onRowAction?: (sectionKind: string, rowTitle: string) => void;
  onMarkAllRead?: () => void;
  onViewAll?: () => void;
}) {
  const { frequency, setFrequency, isSaving } = useDigestSettings(config.sessionHeader);

  return (
    <div
      className="max-w-[640px] overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface-content)]"
      data-testid="notification-digest"
    >
      <div className="flex flex-wrap items-center gap-2 border-b border-[var(--color-border-subtle)] px-4 pb-2.5 pt-3">
        <span className="text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
          Frequency
        </span>
        <div className="flex gap-1 rounded-[var(--radius-button)] bg-[var(--color-surface)] p-1" role="group" aria-label="Digest frequency">
          {FREQUENCY_OPTIONS.map((opt) => (
            <Button
              key={opt.value}
              type="button"
              variant="ghost"
              size="sm"
              disabled={isSaving}
              aria-pressed={frequency === opt.value}
              className={
                frequency === opt.value
                  ? "h-7 bg-[var(--color-surface-content)] px-2.5 text-xs font-semibold shadow-[var(--shadow-sm)]"
                  : "h-7 px-2.5 text-xs font-normal"
              }
              onClick={() => setFrequency(opt.value)}
            >
              {opt.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]/40 px-4 py-3.5">
        <div className="flex items-center gap-2">
          <Mail size={16} className="text-[var(--color-primary)]" aria-hidden="true" />
          <span className="text-sm font-semibold text-[var(--color-text)]">
            Your {FREQUENCY_NOUN[frequency]} digest
          </span>
          <span className="ml-auto font-mono text-xs text-[var(--color-text-muted)]">{config.periodLabel}</span>
        </div>
        {config.aiSummary && (
          <p className="mb-0 mt-2 flex items-start gap-1.5 text-xs leading-relaxed text-[var(--color-text-muted)]">
            <AiMark size={13} className="mt-0.5" />
            <span>
              <strong className="font-semibold text-[hsl(var(--ai-strong))]">AI summary:</strong> {config.aiSummary}
            </span>
          </p>
        )}
      </div>

      {config.sections.map((section) => (
        <DigestSection
          key={section.kind}
          kind={section.kind}
          count={section.rows.length}
          {...(section.title !== undefined && { title: section.title })}
          {...(section.defaultOpen !== undefined && { defaultOpen: section.defaultOpen })}
        >
          {section.rows.map((row, i) => (
            <DigestRow key={i} row={row} onAction={() => onRowAction?.(section.kind, row.title)} />
          ))}
        </DigestSection>
      ))}

      <div className="flex gap-2 p-3.5">
        <Button type="button" variant="outline" size="sm" onClick={onMarkAllRead}>
          Mark all read
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={onViewAll}>
          View all notifications
        </Button>
      </div>
    </div>
  );
}
