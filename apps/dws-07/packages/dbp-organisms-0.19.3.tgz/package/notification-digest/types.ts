import { z } from "zod";

// ─── NotificationDigestConfig ──────────────────────────────────────────────
// Data-only contract — no function fields. Section *content* (rows) arrives
// injected via config, same as every other AI-card-family molecule; the
// frequency control is the one piece of real state this organism owns (see
// index.tsx's `useDigestSettings` binding).

export const DigestSectionKind = z.enum(["action", "changes", "deadlines", "mentions", "completed"]);
export type DigestSectionKind = z.infer<typeof DigestSectionKind>;

const DigestRowDef = z
  .object({
    title: z.string().min(1),
    meta: z.string().min(1),
    /** Row-level action label, e.g. "Review"/"Open". Omitted rows have no action. */
    action: z.string().optional(),
  })
  .strict();

const DigestSectionDef = z
  .object({
    kind: DigestSectionKind,
    /** Override the section's default title for its `kind`. */
    title: z.string().optional(),
    rows: z.array(DigestRowDef).min(1),
    defaultOpen: z.boolean().optional(),
  })
  .strict();

export const NotificationDigestConfig = z
  .object({
    sessionHeader: z.string().optional(),
    /** e.g. "Fri 12 Jul · 8:00 AM" — shown in the digest header. */
    periodLabel: z.string().min(1),
    /** Optional AI-generated recap line (notif-digest.jsx's "AI summary"). */
    aiSummary: z.string().optional(),
    sections: z.array(DigestSectionDef).min(1),
  })
  .strict();

export type NotificationDigestConfig = z.infer<typeof NotificationDigestConfig>;
export type NotificationDigestConfigInput = z.input<typeof NotificationDigestConfig>;
export type DigestSection = z.infer<typeof DigestSectionDef>;
export type DigestRow = z.infer<typeof DigestRowDef>;
