# @dbp/organisms/notification-digest

**registryId:** `APP.F67` (placeholder — pending central registration, see
[FEATURE.md](./FEATURE.md))

Grouped, calm-by-default summary of low/medium-priority notifications —
"Needs action / Important changes / Upcoming deadlines / Mentions /
Completed" sections, a real PS.NOTIF-backed frequency control, and an
optional AI-summary recap line. See [FEATURE.md](./FEATURE.md) for the full
contract.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` (default: `NotificationDigest`; named: `DigestSection`, `DigestRow`, `DIGEST_SECTION_META`) |

## Config schema
`NotificationDigestConfig` — Zod schema (and inferred type of the same name)
exported from `types.ts` (source of truth).

## Layer boundary
Layer 07 feature. Imports `@dbp/ps-notif/client` (`useDigestSettings` only)
and `@dbp/ui`.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/notification-digest` via
plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it
as a committed tarball per `docs/08-contributing/package-distribution.md`.
