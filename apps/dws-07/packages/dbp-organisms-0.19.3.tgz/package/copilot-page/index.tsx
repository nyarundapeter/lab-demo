import React from "react";
import { z } from "zod";
import { Alert, Badge, Grid, Col } from "@dbp/ui";
import { CopilotPageConfig } from "./types.js";
import { InsightCard } from "./components/insight-card.js";
import { ComposerCanvas } from "./components/composer-canvas.js";
import { CognitiveModeStrip } from "./components/cognitive-mode-strip.js";
import type { CognitiveMode } from "./types.js";

type ConfigInput = z.input<typeof CopilotPageConfig>;

/**
 * APP.F15 — Copilot Page (AI Cockpit)
 *
 * Full-page AI assistant surface mounted in SH.04's main slot.
 * Receives CONFIG, never data — each zone independently fetches via PS.*.
 *
 * Layout anatomy (§6 ARCHETYPE-REFERENCE-SPEC.md):
 *   1. Insight cards row: 3-column grid, each card derives its value via PS.DATA aggregation
 *   2. Canvas: composer (left 1fr) + suggested-prompt chips (right 360px)
 *
 * Single-header rule: CopilotPage is body-only. The host layout (shell/page) is
 * responsible for rendering the page title via PageHeader or its own heading.
 * The self-rendered header block has been removed — pass title via the shell.
 *
 * Thread composition: useAssistant is called directly (not via AssistantPanel).
 * See components/composer-canvas.tsx for rationale.
 *
 * Config is validated at render time via CopilotPageConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 */
export default function CopilotPage(rawConfig: ConfigInput) {
  const parseResult = CopilotPageConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="CopilotPage configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-5">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <CopilotPageInner config={parseResult.data} />;
}

// Re-export types so consumers can import from the root.
export type {
  CopilotPageConfig,
  InsightCard,
  ValueMetric,
  CognitiveMode,
} from "./types.js";

// ─── Inner component (config is guaranteed valid here) ────────────────────────

interface InnerProps {
  config: CopilotPageConfig;
}

function CopilotPageInner({ config }: InnerProps) {
  const {
    insightCards,
    cognitiveModes,
    composerPlaceholder,
    submitLabel,
    suggestedPrompts,
    entityType,
    ragScope,
    assistantContext,
  } = config;

  // Selecting a cognitive-mode chip seeds the composer draft and tags the
  // assistant context with the chosen mode — see ComposerCanvas's
  // `activeMode` prop for how the seed reaches the textarea.
  const [activeMode, setActiveMode] = React.useState<CognitiveMode | null>(null);

  // Build the assistant context: { entityType, ragScope? } merged with any
  // extra assistantContext from config, plus the active cognitive mode.
  const fullAssistantContext: Record<string, unknown> = {
    entityType,
    ...(ragScope !== undefined ? { ragScope } : {}),
    ...assistantContext,
    ...(activeMode !== null ? { mode: activeMode.id } : {}),
  };

  return (
    <div
      data-testid="copilot-page"
      className="bg-surface"
    >
      {/* Scope badge — contextual info rendered in the body, not as a page heading.
          A Badge (not bare muted text) so it reads as an intentional UI element,
          not an orphaned debug string, now that the header block above it
          (eyebrow/title/description) is rendered by the host layout's PageHeader
          rather than self-rendered here (see the single-header-rule note above). */}
      <div className="mb-4">
        <Badge tone="default" size="sm" data-testid="copilot-scope">
          Scope: {entityType}
        </Badge>
      </div>

      {/* REGION 1: Cognitive-modes capability strip (optional) */}
      {cognitiveModes !== undefined && (
        <CognitiveModeStrip
          modes={cognitiveModes}
          activeId={activeMode?.id ?? null}
          onSelect={setActiveMode}
        />
      )}

      {/* REGION 2: Insight Cards Row (the "AI-workers" stat-tile grid) */}
      <Grid
        as="section"
        data-testid="insight-cards-grid"
        aria-label="Insight metrics"
      >
        {insightCards.map((card) => (
          <Col key={card.id} lg={4}>
            <InsightCard card={card} />
          </Col>
        ))}
      </Grid>

      {/* REGION 3: Canvas (composer + prompts) */}
      <ComposerCanvas
        composerPlaceholder={composerPlaceholder}
        submitLabel={submitLabel}
        suggestedPrompts={suggestedPrompts}
        assistantContext={fullAssistantContext}
        activeMode={activeMode}
      />
    </div>
  );
}
