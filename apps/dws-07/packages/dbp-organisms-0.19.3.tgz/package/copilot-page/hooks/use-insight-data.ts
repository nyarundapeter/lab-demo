import { useQuery } from "@tanstack/react-query";
import { listAllEntities } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { InsightCard } from "../types.js";
import { aggregate } from "../components/aggregation.js";

export interface InsightDataResult {
  value: number;
  rows: EntityRecord<EntityData>[];
  isLoading: boolean;
  error: Error | null;
}

/**
 * Fetches entity rows for a single insight card and computes its aggregated value.
 *
 * NOTE: PS.DATA has no server-side aggregate endpoint. All aggregation is
 * performed client-side (same approach as KpiScorecard). listAllEntities
 * pages up to 2000 rows at 200/page.
 */
export function useInsightData(card: InsightCard): InsightDataResult {
  const { entityType, aggregate: op, field } = card.valueMetric;

  const query = useQuery({
    queryKey: ["ps-data", "all-entities", entityType, {}],
    queryFn: () => listAllEntities(entityType, {}),
  });

  const rows = query.data?.rows ?? [];

  return {
    value: aggregate(rows, field, op),
    rows,
    isLoading: query.isLoading,
    error: query.error as Error | null,
  };
}
