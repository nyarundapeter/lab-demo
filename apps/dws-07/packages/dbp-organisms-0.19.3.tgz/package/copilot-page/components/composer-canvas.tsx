import React, { useRef, useState, useCallback, useEffect } from "react";
import { MessageSquareText, Send } from "lucide-react";
import {
  AiMark,
  AiLabel,
  AiConfidence,
  CtrlBadge,
  Advisory,
  SourceList,
  FeedbackControl,
  GovState,
  ConfirmationPreview,
  Button,
  type AiSource,
} from "@dbp/ui";
import { useAssistant } from "@dbp/ps-ai/client";
import type { CopilotPageConfig, CognitiveMode } from "../types.js";

interface ComposerCanvasProps {
  composerPlaceholder: string;
  submitLabel: string;
  suggestedPrompts: string[];
  assistantContext: Record<string, unknown>;
  /** The currently-selected cognitive-mode chip (CognitiveModeStrip), if any.
   *  Selecting a mode seeds the composer draft with its promptSeed. */
  activeMode?: CognitiveMode | null;
}

// ---------------------------------------------------------------------------
// Demo AI-trust enrichment
//
// useAssistant()'s ChatMessage contract (@dbp/ps-ai/client) is { role,
// content } only — the PS.AI stub gateway does not emit confidence, control
// level, or citations today. Rather than inventing live-model values, each
// assistant message is deterministically enriched with clearly-labelled DEMO
// governance data so the trust-layer components below have something real to
// render. Replace `demoEnrichmentFor` with the live fields once PS.AI's
// contract grows them (see ADR-0011).
// ---------------------------------------------------------------------------

type ConfidenceLevel = NonNullable<React.ComponentProps<typeof AiConfidence>["level"]>;
type ControlLevel = NonNullable<React.ComponentProps<typeof CtrlBadge>["level"]>;

const DEMO_SOURCE_POOL: AiSource[] = [
  {
    n: 1,
    type: "Knowledge",
    title: "DBP Blueprint — Platform Services overview",
    meta: "Updated this release",
    fresh: "Fresh",
    rel: "high",
  },
  {
    n: 2,
    type: "Document",
    title: "Feature template catalogue",
    meta: "Regenerated on last scaffold run",
    fresh: "Fresh",
    rel: "medium",
  },
];

interface DemoEnrichment {
  confidence: ConfidenceLevel;
  control: ControlLevel;
  sources: AiSource[];
}

function demoEnrichmentFor(assistantIndex: number): DemoEnrichment {
  const confidences: ConfidenceLevel[] = ["high", "medium", "low"];
  const controls: ControlLevel[] = [1, 2];
  return {
    confidence: confidences[assistantIndex % confidences.length]!,
    control: controls[assistantIndex % controls.length]!,
    sources: DEMO_SOURCE_POOL,
  };
}

/**
 * The two-column canvas: LEFT = full-page AI composer + conversation thread,
 * RIGHT = suggested-prompt chip strip.
 *
 * Thread composition decision:
 *   useAssistant is called directly from @dbp/ps-ai/client. The conversation
 *   thread is rendered inline below the textarea inside the composer card.
 *   AssistantPanel (@dbp/ui) is NOT reused here — it is opaque (owns its own
 *   textarea + send button) and would conflict with the page-level composer
 *   layout and chip-fill interaction. The inline approach gives cleaner
 *   composability for this full-page archetype.
 *
 * AI trust layer (design-audit-2026-07-17 P3):
 *   Each assistant message renders AiLabel (mark + "AI-assisted"), a demo
 *   AiConfidence + CtrlBadge, an Advisory note for low-autonomy control
 *   levels, a demo SourceList (citations), and FeedbackControl. A failed
 *   `ask()` renders GovState instead of leaving the user with no explanation.
 *   The most recent assistant message also demonstrates the confirm-before-
 *   apply flow via a demo "Apply suggestion" action — see the ConfirmationPreview
 *   wiring below; there is no live AI-mutation path yet, so it is explicitly
 *   labelled as a demo sample.
 */
export function ComposerCanvas({
  composerPlaceholder,
  submitLabel,
  suggestedPrompts,
  assistantContext,
  activeMode,
}: ComposerCanvasProps) {
  const { ask, messages, streaming } = useAssistant(assistantContext);
  const [draft, setDraft] = useState("");
  const [lastError, setLastError] = useState<string | null>(null);
  const [lastFailedMessage, setLastFailedMessage] = useState<string | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const responseRegionRef = useRef<HTMLDivElement>(null);

  // Selecting a cognitive-mode chip seeds the draft and focuses the composer,
  // same interaction as a suggested-prompt chip (handleChipClick below).
  useEffect(() => {
    if (activeMode) {
      setDraft(activeMode.promptSeed);
      textareaRef.current?.focus();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeMode?.id, activeMode?.promptSeed]);

  const runAsk = useCallback(
    async (text: string) => {
      try {
        setLastError(null);
        await ask(text);
      } catch {
        setLastError("The assistant could not complete this request.");
        setLastFailedMessage(text);
      }
    },
    [ask],
  );

  // Submit handler — calls useAssistant.ask with the current draft.
  const handleSubmit = useCallback(async () => {
    const text = draft.trim();
    if (text === "" || streaming) return;
    setDraft("");
    await runAsk(text);
  }, [draft, runAsk, streaming]);

  const handleRetry = useCallback(async () => {
    if (!lastFailedMessage) return;
    await runAsk(lastFailedMessage);
  }, [lastFailedMessage, runAsk]);

  // Keyboard: Enter submits, Shift+Enter inserts newline, Esc blurs.
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void handleSubmit();
    }
    if (e.key === "Escape") {
      textareaRef.current?.blur();
    }
  };

  // Chip click: fill composer and focus.
  const handleChipClick = (prompt: string) => {
    setDraft(prompt);
    textareaRef.current?.focus();
  };

  const lastAssistantIndex = (() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i]!.role === "assistant") return i;
    }
    return -1;
  })();

  const contextLabel =
    typeof assistantContext["ragScope"] === "string"
      ? `Using ${assistantContext["ragScope"]}`
      : typeof assistantContext["entityType"] === "string"
        ? `Using ${assistantContext["entityType"]} context`
        : "Using platform context";

  let assistantSeen = -1;

  return (
    <section
      className="mt-5 grid grid-cols-1 gap-5 xl:grid-cols-[1fr_360px]"
      data-testid="composer-canvas"
    >
      {/* LEFT: Ask AI composer + thread */}
      <div
        className="rounded-card border border-border-subtle bg-[var(--color-surface-content)] p-6 shadow-sm"
        data-testid="composer-card"
      >
        {/* Card header */}
        <div className="flex items-center gap-3">
          <AiMark size={22} />
          <h2 className="text-xl font-bold text-primary">Ask AI</h2>
        </div>
        <p className="mt-2 text-sm text-text-secondary">
          Ask for a work brief, status summary, risk review, or recommended next action.
        </p>
        <div className="mt-3">
          <AiLabel text={contextLabel} />
        </div>

        {/* Composer textarea */}
        <textarea
          ref={textareaRef}
          data-testid="composer-textarea"
          rows={5}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={composerPlaceholder}
          disabled={streaming}
          aria-label="AI prompt composer"
          aria-multiline="true"
          className="mt-5 w-full resize-none rounded-input border border-border-default bg-surface p-4 text-sm outline-none focus:border-border-strong disabled:opacity-50"
        />

        {/* Submit — standard primary Button variant (CTA-color unify, DQ-Shell):
            never hardcode bg-primary/text-white here, always go through the
            "orange" (primary) variant so it stays in sync with the one
            established primary token. */}
        <Button
          data-testid="composer-submit"
          variant="orange"
          onClick={() => void handleSubmit()}
          disabled={draft.trim() === "" || streaming}
          loading={streaming}
          className="mt-3"
          aria-label={submitLabel}
        >
          <Send size={15} strokeWidth={1.5} aria-hidden="true" />
          {submitLabel}
        </Button>

        {/* Conversation thread — aria-live for screen readers */}
        {messages.length > 0 && (
          <div
            ref={responseRegionRef}
            data-testid="conversation-thread"
            aria-live="polite"
            aria-label="Conversation thread"
            className="mt-6 flex flex-col gap-3"
          >
            {messages.map((msg, i) => {
              const isAssistant = msg.role === "assistant";
              if (isAssistant) assistantSeen += 1;
              const enrichment = isAssistant ? demoEnrichmentFor(assistantSeen) : null;
              const isMostRecentAssistant = isAssistant && i === lastAssistantIndex;

              return (
                <div
                  key={i}
                  data-testid={`message-${i}`}
                  className={
                    msg.role === "user"
                      ? "self-end max-w-[85%] rounded-lg bg-primary px-3 py-2 text-sm text-white ml-auto"
                      : "self-start max-w-[90%] rounded-lg border border-border-subtle bg-surface px-3 py-2 text-sm text-primary"
                  }
                  aria-label={`${msg.role === "user" ? "You" : "AI"}: ${msg.content}`}
                >
                  {isAssistant && <AiLabel kind="assisted" className="mb-1.5" />}
                  <p className="whitespace-pre-wrap break-words">{msg.content}</p>

                  {isAssistant && enrichment && (
                    <>
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        <AiConfidence
                          level={enrichment.confidence}
                          note="Demo confidence — PS.AI is a stub gateway; this value is illustrative, not model-derived."
                        />
                        <CtrlBadge level={enrichment.control} />
                      </div>
                      {enrichment.control <= 2 && <Advisory className="mt-1.5" />}
                      <div className="mt-2">
                        <SourceList sources={enrichment.sources} label="Sources (demo)" />
                      </div>
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <FeedbackControl compact />
                        {isMostRecentAssistant && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setConfirmOpen(true)}
                          >
                            Apply suggestion (demo)
                          </Button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              );
            })}

            {streaming && (
              <div
                className="self-start rounded-lg border border-border-subtle bg-surface px-3 py-2"
                aria-live="polite"
                aria-label="AI is thinking"
                data-testid="streaming-indicator"
              >
                <span className="flex gap-1 items-center" aria-hidden="true">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary animate-bounce [animation-delay:0ms]" />
                  <span className="h-1.5 w-1.5 rounded-full bg-primary animate-bounce [animation-delay:150ms]" />
                  <span className="h-1.5 w-1.5 rounded-full bg-primary animate-bounce [animation-delay:300ms]" />
                </span>
              </div>
            )}

            {lastError && (
              <GovState
                state="error"
                why={lastError}
                actions={
                  <Button variant="outline" size="sm" onClick={() => void handleRetry()}>
                    Retry
                  </Button>
                }
              />
            )}
          </div>
        )}

        {/* Empty state — shown before first prompt */}
        {messages.length === 0 && !streaming && (
          <p
            className="mt-6 text-center text-sm text-text-muted"
            data-testid="composer-empty-state"
          >
            Your conversation will appear here once you send a message.
          </p>
        )}

        {/*
          Confirm-before-apply demo — no Copilot action mutates data today, so
          this demonstrates the required flow with a sample field diff rather
          than a real "apply" call. Wire `onConfirm` to a real mutation once
          Copilot gains one; never let an AI action skip this dialog.
        */}
        <ConfirmationPreview
          open={confirmOpen}
          onOpenChange={setConfirmOpen}
          description="Demo — Copilot has no live data-mutation action yet. This shows the required confirm-before-apply pattern using a sample suggestion."
          fields={[
            { label: "Next action", before: "Unassigned", after: "Follow up with platform owner" },
            { label: "Priority", before: "Normal", after: "High" },
          ]}
          onConfirm={() => setConfirmOpen(false)}
        />
      </div>

      {/* RIGHT: Suggested prompts */}
      <div
        className="rounded-card border border-border-subtle bg-[var(--color-surface-content)] p-5 shadow-sm"
        data-testid="prompts-card"
      >
        <h2
          className="flex items-center gap-2 text-lg font-bold text-primary"
          data-testid="prompts-heading"
        >
          <MessageSquareText size={18} strokeWidth={1.5} aria-hidden="true" />
          Suggested prompts
        </h2>
        <div className="mt-4 space-y-2" data-testid="prompts-list">
          {suggestedPrompts.map((prompt, i) => (
            <Button
              key={i}
              variant="outline"
              data-testid={`prompt-chip-${i}`}
              onClick={() => handleChipClick(prompt)}
              className="h-auto w-full justify-start rounded-lg bg-surface px-3 py-3 text-left text-sm font-semibold hover:bg-navy-50"
            >
              {prompt}
            </Button>
          ))}
        </div>
      </div>
    </section>
  );
}

// Re-export for consumers that import from the component path.
export type { CopilotPageConfig };
