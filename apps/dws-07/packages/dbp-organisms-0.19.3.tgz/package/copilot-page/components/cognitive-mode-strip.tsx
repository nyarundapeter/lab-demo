import * as React from "react";
import {
  Bot,
  FileText,
  Search,
  ClipboardCheck,
  Lightbulb,
  PenLine,
  type LucideProps,
} from "lucide-react";
import { Button, cn } from "@dbp/ui";
import type { CognitiveMode } from "../types.js";

// ─── Icon registry (stroke 1.5, same pattern as insight-card.tsx) ─────────────

const ICON_MAP: Record<string, React.FC<LucideProps>> = {
  Bot,
  FileText,
  Search,
  ClipboardCheck,
  Lightbulb,
  PenLine,
};

interface CognitiveModeStripProps {
  modes: CognitiveMode[];
  activeId: string | null;
  onSelect: (mode: CognitiveMode) => void;
}

/**
 * The cockpit's capability strip — a row of selectable "cognitive mode"
 * chips (e.g. Summarize / Draft / Review / Recommend) adapted from the
 * Claude Design reference's mode selector. Selecting a chip seeds the
 * composer draft (see ComposerCanvas's `activeMode` prop) rather than
 * mutating anything — purely a prompt-authoring aid.
 */
export function CognitiveModeStrip({ modes, activeId, onSelect }: CognitiveModeStripProps) {
  if (modes.length === 0) return null;

  return (
    <div
      role="group"
      aria-label="AI capability modes"
      data-testid="cognitive-mode-strip"
      className="mb-5 flex flex-wrap gap-2"
    >
      {modes.map((mode) => {
        const IconComponent = ICON_MAP[mode.icon] ?? Bot;
        const isActive = mode.id === activeId;
        return (
          <Button
            key={mode.id}
            variant="outline"
            data-testid={`cognitive-mode-${mode.id}`}
            aria-pressed={isActive}
            onClick={() => onSelect(mode)}
            className={cn(
              "h-auto gap-2 rounded-full px-3.5 py-2 text-sm font-semibold",
              isActive
                ? "border-[hsl(var(--ai-border))] bg-[hsl(var(--ai-soft))] text-[hsl(var(--ai-strong))]"
                : "border-border-subtle bg-[var(--color-surface-content)] text-text-secondary hover:border-[hsl(var(--ai-border))] hover:text-[hsl(var(--ai-strong))]",
            )}
          >
            <IconComponent size={15} strokeWidth={1.5} aria-hidden="true" />
            {mode.label}
          </Button>
        );
      })}
    </div>
  );
}
