import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import { formatNumber } from "@dbp/ui";

type AggregateOp = "count" | "sum" | "avg";

/**
 * Computes count / sum / avg of a numeric field across entity rows.
 * Mirrors the KpiScorecard aggregation helper — client-side only.
 * Non-numeric values coerce to 0.
 */
export function aggregate(
  rows: EntityRecord<EntityData>[],
  field: string | undefined,
  op: AggregateOp,
): number {
  if (op === "count") return rows.length;

  if (!field) return 0;

  const nums = rows.map((r) => {
    const v = (r.data as Record<string, unknown>)[field];
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  });

  if (nums.length === 0) return 0;

  const total = nums.reduce((acc, n) => acc + n, 0);
  return op === "sum" ? total : total / nums.length;
}

/** Threshold above which numbers display in compact notation. */
const COMPACT_THRESHOLD = 10_000;

/** Format a raw number for insight card display. */
export function formatInsightValue(value: number): string {
  return formatNumber(value, { compact: Math.abs(value) >= COMPACT_THRESHOLD });
}
