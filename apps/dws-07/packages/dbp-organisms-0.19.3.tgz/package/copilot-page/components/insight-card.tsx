import React from "react";
import {
  Bot,
  Search,
  Compass,
  BarChart3,
  Activity,
  TrendingUp,
  Users,
  Package,
  Hash,
  Target,
  CalendarDays,
  CalendarCheck,
  Clock,
  ArrowLeftRight,
  Inbox,
  FileText,
  DollarSign,
  Percent,
  ShoppingCart,
  CheckCircle,
  AlertCircle,
  type LucideProps,
} from "lucide-react";
import { Skeleton } from "@dbp/ui";
import type { InsightCard as InsightCardConfig } from "../types.js";
import { useInsightData } from "../hooks/use-insight-data.js";
import { formatInsightValue } from "./aggregation.js";

// ─── Icon registry (stroke 1.5) ───────────────────────────────────────────────

const ICON_MAP: Record<string, React.FC<LucideProps>> = {
  Bot,
  Search,
  Compass,
  BarChart3,
  Activity,
  TrendingUp,
  Users,
  Package,
  Hash,
  Target,
  CalendarDays,
  CalendarCheck,
  Clock,
  ArrowLeftRight,
  Inbox,
  FileText,
  DollarSign,
  Percent,
  ShoppingCart,
  CheckCircle,
  AlertCircle,
};

interface InsightCardProps {
  card: InsightCardConfig;
}

export function InsightCard({ card }: InsightCardProps) {
  const { value, isLoading, error } = useInsightData(card);

  const IconComponent = React.useMemo(() => {
    const resolved = ICON_MAP[card.icon];
    if (!resolved) {
      console.warn(`[InsightCard] Unknown icon "${card.icon}" for card "${card.id}" — using Hash fallback.`);
      return Hash;
    }
    return resolved;
  }, [card.icon, card.id]);

  return (
    <div
      data-testid={`insight-card-${card.id}`}
      className="rounded-card border border-border-subtle bg-[var(--color-surface-content)] p-5 text-left shadow-sm hover:bg-navy-50 transition-colors duration-150"
    >
      <div className="flex items-start justify-between gap-3">
        <IconComponent
          size={20}
          strokeWidth={1.5}
          className="text-primary shrink-0 mt-0.5"
          aria-hidden="true"
        />
        {isLoading ? (
          <Skeleton className="h-9 w-20" data-testid={`insight-value-skeleton-${card.id}`} />
        ) : error !== null ? (
          <span
            className="text-3xl font-bold text-danger-text"
            data-testid={`insight-value-error-${card.id}`}
          >
            —
          </span>
        ) : (
          <span
            className="text-3xl font-bold text-primary"
            data-testid={`insight-value-${card.id}`}
          >
            {formatInsightValue(value)}
          </span>
        )}
      </div>
      <h2 className="mt-4 font-bold text-primary" data-testid={`insight-title-${card.id}`}>
        {card.title}
      </h2>
    </div>
  );
}
