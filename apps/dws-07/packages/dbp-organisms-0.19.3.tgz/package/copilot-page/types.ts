import { z } from "zod";

// ─── Value metric ─────────────────────────────────────────────────────────────

/**
 * Describes how a single insight card's numeric value is derived from PS.DATA.
 *
 * - entityType  — the PS.DATA entity type to query
 * - aggregate   — "count" | "sum" | "avg" (client-side, same as KpiScorecard)
 * - field       — data field to sum/avg; omitted for "count"
 */
const ValueMetricSchema = z
  .object({
    entityType: z.string().min(1),
    aggregate: z.enum(["count", "sum", "avg"]),
    field: z.string().min(1).optional(),
  })
  .superRefine((val, ctx) => {
    if (val.aggregate !== "count" && !val.field) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `field is required when aggregate is "${val.aggregate}"`,
        path: ["field"],
      });
    }
  });

export type ValueMetric = z.infer<typeof ValueMetricSchema>;

// ─── Insight card ─────────────────────────────────────────────────────────────

/**
 * A single insight stat card shown in the 3-column row above the canvas.
 *
 * - id          — stable React key
 * - title       — card label
 * - valueMetric — PS.DATA query descriptor for the numeric value
 * - icon        — lucide icon name (subset supported in the render layer)
 */
const InsightCardSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  valueMetric: ValueMetricSchema,
  /**
   * Lucide icon name rendered at stroke 1.5 in the insight card header.
   * Any string is accepted — unknown names fall back to Hash.
   * Well-known names: "Bot" | "Search" | "Compass" | "BarChart3" | "Activity" |
   *   "TrendingUp" | "Users" | "Package" | "Hash" | "Target" | "CalendarDays" |
   *   "CalendarCheck" | "Clock" | "ArrowLeftRight" | "Inbox" | "FileText" |
   *   "DollarSign" | "Percent" | "ShoppingCart" | "CheckCircle" | "AlertCircle".
   */
  icon: z.string().default("Hash"),
});

export type InsightCard = z.infer<typeof InsightCardSchema>;

// ─── Cognitive mode ───────────────────────────────────────────────────────────

/**
 * A selectable capability-strip chip (the cockpit's "cognitive modes" row —
 * adapted from the Claude Design reference's mode selector). Selecting a mode
 * seeds the composer draft with `promptSeed` and merges `{ mode: id }` into
 * the assistant context so the stub gateway (and any future live model) can
 * see which capability the user picked.
 */
const CognitiveModeSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  /** Lucide icon name; unknown names fall back to Bot. */
  icon: z.string().default("Bot"),
  /** Text used to seed the composer draft when this mode is selected. */
  promptSeed: z.string().min(1),
});

export type CognitiveMode = z.infer<typeof CognitiveModeSchema>;

// ─── Top-level config ─────────────────────────────────────────────────────────

/**
 * CopilotPageConfig — the single typed contract for APP.F15.
 *
 * Data-only; no function fields (Zod schemas are data-only).
 */
export const CopilotPageConfig = z.object({
  /**
   * @deprecated — CopilotPage is body-only (single-header rule §4.4).
   * The self-rendered header block has been removed. This field is accepted
   * but has no effect. Pass the page title via the host shell/layout PageHeader.
   */
  externalHeader: z.boolean().optional(),
  /**
   * @deprecated — CopilotPage is body-only (single-header rule §4.4).
   * Accepted but not rendered. Pass eyebrow context via the shell PageHeader.
   */
  eyebrow: z.string().min(1).optional(),

  /**
   * @deprecated — CopilotPage is body-only (single-header rule §4.4).
   * Accepted but not rendered. Pass the page title via the shell PageHeader.
   */
  title: z.string().min(1).optional(),

  /**
   * @deprecated — CopilotPage is body-only (single-header rule §4.4).
   * Accepted but not rendered. Pass description via the shell PageHeader subtitle.
   */
  description: z.string().min(1).optional(),

  /**
   * 1–3 insight stat cards shown in the grid row above the canvas.
   * Values are derived at render time via PS.DATA (client-side aggregation).
   */
  insightCards: z.array(InsightCardSchema).min(1).max(3),

  /**
   * 0–6 cognitive-mode chips shown as a capability strip above the insight
   * grid (e.g. Summarize / Draft / Review / Recommend). Optional — omit for
   * a plain cockpit with no mode strip. Selecting a chip seeds the composer.
   */
  cognitiveModes: z.array(CognitiveModeSchema).max(6).optional(),

  /**
   * Placeholder text for the composer textarea, e.g.
   * "Ask about your work, requests, workflows, or governance actions…".
   */
  composerPlaceholder: z.string().min(1),

  /**
   * Label on the submit button, e.g. "Generate work brief".
   * The button uses Bot icon (global rule: no Sparkles).
   */
  submitLabel: z.string().min(1),

  /**
   * 1–8 suggested prompt strings rendered as chip buttons.
   * Clicking a chip fills and focuses the composer.
   */
  suggestedPrompts: z.array(z.string().min(1)).min(1).max(8),

  /**
   * PS.DATA entity type used as the scope label ("Active scope: {entityType}").
   * Also forwarded to the assistant context.
   */
  entityType: z.string().min(1),

  /**
   * When present, scoped to a PS.AI RAG search scope (passed to assistantContext
   * for downstream use; not used in the Copilot Page UI directly).
   */
  ragScope: z.string().min(1).optional(),

  /**
   * Extra context object merged into useAssistant's context argument
   * alongside the auto-built { entityType } entry.
   */
  assistantContext: z.record(z.string(), z.unknown()).optional(),
});

export type CopilotPageConfig = z.infer<typeof CopilotPageConfig>;
