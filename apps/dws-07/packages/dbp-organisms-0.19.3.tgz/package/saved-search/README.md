# @dbp/organisms/saved-search

**registryId:** `APP.F71` (placeholder — assigned during central registration)

Saved-searches list (pin/alert/open) plus a "Recent alerts" panel that composes the existing
`notification-inbox` organism. No `PS.SAVED-SEARCH` platform service exists — see `FEATURE.md`
for how the list is modeled without one.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`SavedSearchConfig` — Zod schema exported from `types.ts` (source of truth). `onOpenSearch` is
a separate component prop, not part of the config.

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route a
saved-searches page yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/saved-search` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
