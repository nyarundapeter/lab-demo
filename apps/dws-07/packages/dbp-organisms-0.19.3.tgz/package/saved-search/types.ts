import { z } from "zod";

const AlertFrequencySchema = z.enum(["realtime", "daily", "weekly"]);

const SavedSearchItemSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  /** Human-readable summary of the captured query + filters, e.g. "Deals · Open · At risk". */
  filtersSummary: z.string().default(""),
  matchCount: z.number().int().min(0).default(0),
  pinned: z.boolean().default(false),
  shared: z.boolean().default(false),
  alertOn: z.boolean().default(false),
  alertFrequency: AlertFrequencySchema.default("realtime"),
});
export type SavedSearchItem = z.infer<typeof SavedSearchItemSchema>;

// Data-only contract. No PS.SAVED-SEARCH platform service exists — this
// models the saved-search list as ordinary Zod config data, same as every
// other config-driven organism this wave (see FEATURE.md). Pin/alert toggles
// are local UI state seeded from this list, not persisted anywhere.
export const SavedSearchConfig = z
  .object({
    savedSearches: z.array(SavedSearchItemSchema).default([]),
    /** Forwarded to the composed `notification-inbox` organism for its own PS.NOTIF fetch. */
    sessionHeader: z.string().optional(),
  })
  .strict();

export type SavedSearchConfig = z.infer<typeof SavedSearchConfig>;
export type SavedSearchConfigInput = z.input<typeof SavedSearchConfig>;
