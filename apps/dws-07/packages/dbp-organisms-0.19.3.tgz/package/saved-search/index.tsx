import * as React from "react";
import { Star, Pin, Users, ArrowRight } from "lucide-react";
import NotificationInbox from "@dbp/organisms/notification-inbox";
import { Alert, Badge, Switch, Button } from "@dbp/ui";
import { SavedSearchConfig } from "./types.js";
import type { SavedSearchConfig as SavedSearchConfigType, SavedSearchConfigInput, SavedSearchItem } from "./types.js";

export type { SavedSearchConfig, SavedSearchConfigInput, SavedSearchItem } from "./types.js";

const FREQUENCY_LABEL: Record<SavedSearchItem["alertFrequency"], string> = {
  realtime: "Real-time",
  daily: "Daily digest",
  weekly: "Weekly digest",
};

/**
 * APP.F71 (placeholder — real id assigned during central registration) —
 * Saved searches. Port of search-system/search-saved.jsx's `SR_Saved`.
 *
 * No `PS.SAVED-SEARCH` platform service exists — this models the list as
 * ordinary Zod config data (`types.ts`), like every other config-driven
 * organism this wave; pin/alert toggles are local UI state, not persisted.
 *
 * Correctly reuses `notification-inbox` (APP.F29) for the "Recent alerts"
 * panel — search-saved.jsx's own `SR_Alerts` view re-implements a bespoke
 * notification row (icon/title/body/actions/timestamp); that anatomy
 * already exists as a real organism, so it's composed here instead of
 * duplicated.
 */
export default function SavedSearchPage({
  config,
  onOpenSearch,
}: {
  config: SavedSearchConfigInput;
  /** Called when a saved search's "Open" action is used. */
  onOpenSearch?: ((search: SavedSearchItem) => void) | undefined;
}) {
  const parsed = SavedSearchConfig.safeParse(config);
  if (!parsed.success) {
    return (
      <Alert tone="danger" title="SavedSearchPage — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <SavedSearchPageInner config={parsed.data} onOpenSearch={onOpenSearch} />;
}

function SavedSearchPageInner({
  config,
  onOpenSearch,
}: {
  config: SavedSearchConfigType;
  onOpenSearch?: ((search: SavedSearchItem) => void) | undefined;
}) {
  const [items, setItems] = React.useState<SavedSearchItem[]>(config.savedSearches);

  const setField = (id: string, patch: Partial<SavedSearchItem>) =>
    setItems((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));

  return (
    <div className="flex flex-col gap-6" data-testid="saved-search-page">
      <div>
        <h2 className="mb-1 text-sm font-semibold text-[var(--color-text-primary)]">Your saved searches</h2>
        <p className="mb-3 text-xs text-[var(--color-text-muted)]">
          Managed in one place — pin, alert, or open. Pinned searches also appear under Views in the sidebar.
        </p>

        {items.length === 0 ? (
          <div
            data-testid="saved-search-empty-state"
            className="rounded-card border border-dashed border-[var(--color-border-default)] py-8 text-center text-sm text-[var(--color-text-muted)]"
          >
            No saved searches yet — run a search, then save it to get alerted when new matches come in.
          </div>
        ) : (
          <div className="divide-y divide-[var(--color-border-default)] rounded-card border border-[var(--color-border-default)] bg-[var(--color-surface-content)]">
            {items.map((s) => (
              <div key={s.id} className="flex items-center gap-3 px-4 py-3" data-testid={`saved-search-${s.id}`}>
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[var(--color-navy-50)] text-primary">
                  {s.pinned ? <Pin size={15} aria-hidden="true" /> : <Star size={15} aria-hidden="true" />}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-medium text-[var(--color-text-primary)]">{s.name}</span>
                    {s.pinned && (
                      <Badge tone="gray" size="sm">
                        <Pin size={10} aria-hidden="true" />
                        Pinned
                      </Badge>
                    )}
                    {s.shared && (
                      <Badge tone="gray" size="sm">
                        <Users size={10} aria-hidden="true" />
                        Shared
                      </Badge>
                    )}
                  </div>
                  <div className="text-xs text-[var(--color-text-muted)]">
                    {s.filtersSummary}
                    {s.filtersSummary && " · "}
                    <span className="font-medium text-[var(--color-text-primary)]">{s.matchCount}</span> matches
                  </div>
                </div>
                <span className="shrink-0 text-xs text-[var(--color-text-muted)]">
                  {s.alertOn ? FREQUENCY_LABEL[s.alertFrequency] : "Alerts off"}
                </span>
                <Switch
                  checked={s.alertOn}
                  onCheckedChange={(v) => setField(s.id, { alertOn: v === true })}
                  aria-label={`Toggle alert for ${s.name}`}
                />
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setField(s.id, { pinned: !s.pinned })}
                  title={s.pinned ? "Unpin from sidebar" : "Pin to sidebar"}
                  aria-label={s.pinned ? `Unpin ${s.name}` : `Pin ${s.name}`}
                  className={
                    s.pinned
                      ? "h-auto w-auto rounded p-1.5 text-primary hover:bg-[var(--color-navy-50)]"
                      : "h-auto w-auto rounded p-1.5 text-[var(--color-text-muted)] hover:bg-[var(--color-surface)]"
                  }
                >
                  <Pin size={15} aria-hidden="true" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => onOpenSearch?.(s)}
                  title="Open search"
                  aria-label={`Open ${s.name}`}
                  className="h-auto w-auto rounded p-1.5 text-[var(--color-text-muted)] hover:bg-[var(--color-surface)]"
                >
                  <ArrowRight size={15} aria-hidden="true" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <h3 className="mb-1 text-sm font-semibold text-[var(--color-text-primary)]">Recent alerts</h3>
        <p className="mb-3 text-xs text-[var(--color-text-muted)]">
          New matches on a saved search land here using the same notification anatomy as everything else in the
          platform.
        </p>
        <NotificationInbox config={{ sessionHeader: config.sessionHeader }} />
      </div>
    </div>
  );
}
