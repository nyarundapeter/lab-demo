import { useEntity } from "@dbp/ps-data/client";
import { WizardDefinitionSchema } from "../types.js";
import type { WizardDefinition } from "../types.js";

/**
 * Fetches a `WizardDefinition` at runtime via PS.DATA's generic CRUD route
 * (`GET /api/platform/data/wizard-definition/:id`) — mirrors
 * `use-form-definition.ts`'s pattern for the sibling `WizardDefinition` schema.
 */
export function useWizardDefinition(id: string, options: { enabled?: boolean } = {}) {
  const { data, isLoading, error } = useEntity<WizardDefinition>("wizard-definition", id, options);

  let definition: WizardDefinition | undefined;
  let parseError: Error | undefined;

  if (data) {
    const parsed = WizardDefinitionSchema.safeParse(data);
    if (parsed.success) {
      definition = parsed.data;
    } else {
      parseError = new Error(
        `Invalid wizard-definition record (id: ${id}): ${parsed.error.issues.map((i) => i.message).join("; ")}`,
      );
    }
  }

  return {
    definition,
    isLoading,
    error: error ?? parseError,
  };
}
