import * as React from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createEntity, listEntities, updateEntity } from "@dbp/ps-data/client";
import { AUTOSAVE_DEBOUNCE_MS } from "@dbp/organisms/form-builder/hooks";
import { WizardDraftSchema } from "../types.js";
import type { WizardDefinition, WizardDraft } from "../types.js";

export { AUTOSAVE_DEBOUNCE_MS };

export interface UseWizardDraftOptions {
  userId: string;
  tenantId: string;
  enabled?: boolean;
}

export type SaveStatus = "idle" | "saving" | "saved";

export interface UseWizardDraftResult {
  draft: WizardDraft | undefined;
  isLoading: boolean;
  /** Cycles idle -> saving -> saved (spec §5 "genuinely cycling", not a static label). */
  saveStatus: SaveStatus;
  /** Debounced autosave — resets the 3s timer on every call (spec §5, F2 timing). */
  scheduleAutosave: (values: Record<string, unknown>, currentStepId: string, dirtyFieldIds: string[]) => void;
  /** Immediate save, bypassing the debounce — call on field blur / Save & exit. */
  flushAutosave: (values: Record<string, unknown>, currentStepId: string, dirtyFieldIds: string[]) => void;
}

const draftListKey = (wizardDefinitionId: string, userId: string) =>
  ["ps-data", "entity-list", "form-draft", "wizard", wizardDefinitionId, userId] as const;

/**
 * Draft persistence for `WizardDefinition`-driven wizards (spec §4/§5 —
 * "wire real debounced autosave... against the `form-draft` PS.DATA
 * sub-entity, with the indicator genuinely cycling saving -> saved").
 * Same "form-draft" PS.DATA entity type `use-form-draft.ts` uses, shaped for
 * the wizard's superset (`WizardDraftSchema`: adds `currentStepId`, keyed by
 * `wizardDefinitionId`/`wizardVersion` instead of `formDefinitionId`/`formVersion`).
 */
export function useWizardDraft(definition: WizardDefinition, options: UseWizardDraftOptions): UseWizardDraftResult {
  const { userId, tenantId, enabled = true } = options;
  const queryClient = useQueryClient();
  const listKey = draftListKey(definition.id, userId);
  const draftIdRef = React.useRef<string | undefined>(undefined);
  const timerRef = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [saveStatus, setSaveStatus] = React.useState<SaveStatus>("idle");

  const query = useQuery({
    queryKey: listKey,
    queryFn: async () => {
      const result = await listEntities<WizardDraft>("form-draft", {
        filters: { wizardDefinitionId: definition.id, userId },
        pageSize: 1,
      });
      return result.rows[0]?.data ?? null;
    },
    enabled,
  });

  const draft = query.data ?? undefined;
  React.useEffect(() => {
    if (draft) draftIdRef.current = draft.id;
  }, [draft]);

  const saveMutation = useMutation({
    mutationFn: async (payload: {
      values: Record<string, unknown>;
      currentStepId: string;
      dirtyFieldIds: string[];
    }) => {
      const savedAt = new Date().toISOString();
      if (draftIdRef.current) {
        const updated = await updateEntity<WizardDraft>("form-draft", draftIdRef.current, {
          values: payload.values,
          currentStepId: payload.currentStepId,
          dirtyFieldIds: payload.dirtyFieldIds,
          savedAt,
        });
        return updated.data;
      }
      const created = await createEntity<WizardDraft>(
        "form-draft",
        WizardDraftSchema.parse({
          id: crypto.randomUUID(),
          wizardDefinitionId: definition.id,
          wizardVersion: definition.version,
          userId,
          tenantId,
          currentStepId: payload.currentStepId,
          values: payload.values,
          dirtyFieldIds: payload.dirtyFieldIds,
          savedAt,
        }),
      );
      draftIdRef.current = created.id;
      return created.data;
    },
    onMutate: () => {
      setSaveStatus("saving");
    },
    onSuccess: (saved) => {
      queryClient.setQueryData(listKey, saved);
      setSaveStatus("saved");
    },
  });

  const clearTimer = React.useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = undefined;
    }
  }, []);

  const save = React.useCallback(
    (values: Record<string, unknown>, currentStepId: string, dirtyFieldIds: string[]) => {
      saveMutation.mutate({ values, currentStepId, dirtyFieldIds });
    },
    [saveMutation],
  );

  const scheduleAutosave = React.useCallback(
    (values: Record<string, unknown>, currentStepId: string, dirtyFieldIds: string[]) => {
      clearTimer();
      timerRef.current = setTimeout(() => {
        timerRef.current = undefined;
        save(values, currentStepId, dirtyFieldIds);
      }, AUTOSAVE_DEBOUNCE_MS);
    },
    [clearTimer, save],
  );

  const flushAutosave = React.useCallback(
    (values: Record<string, unknown>, currentStepId: string, dirtyFieldIds: string[]) => {
      clearTimer();
      save(values, currentStepId, dirtyFieldIds);
    },
    [clearTimer, save],
  );

  React.useEffect(() => clearTimer, [clearTimer]);

  return {
    draft,
    isLoading: query.isLoading,
    saveStatus,
    scheduleAutosave,
    flushAutosave,
  };
}
