import { evalPredicate } from "@dbp/organisms/form-builder/logic";
import type { WizardDefinition, WizardStep } from "../types.js";
import type { StepNavItem, StepNavState } from "@dbp/ui";

/**
 * Re-derives the visible step list from `WizardStepSchema.visibleWhen`
 * against accumulated cross-step values — exactly what the reference's
 * `buildSteps(form)` does on every render (spec §2/§4/§5). Steps are always
 * keyed by id, never index, so a step appearing/disappearing between renders
 * never corrupts sibling state.
 */
export function deriveVisibleSteps(
  definition: WizardDefinition,
  values: Record<string, unknown>,
): WizardStep[] {
  return definition.steps.filter((step) => {
    if (!step.visibleWhen || step.visibleWhen.length === 0) return true;
    return step.visibleWhen.every((p) => evalPredicate(p, values));
  });
}

/**
 * The full wizard "page list" including the auto-generated Review step
 * (spec §4/§5 — review is never authored as a `WizardStep`, always derived).
 */
export const REVIEW_STEP_ID = "__review";

export interface WizardPage {
  id: string;
  label: string;
  optional: boolean;
}

export function deriveWizardPages(definition: WizardDefinition, values: Record<string, unknown>): WizardPage[] {
  const steps = deriveVisibleSteps(definition, values).map((s) => ({
    id: s.id,
    label: s.label,
    optional: s.optional,
  }));
  return [...steps, { id: REVIEW_STEP_ID, label: definition.reviewStepLabel, optional: false }];
}

/**
 * Step-nav state derivation (`forms-runner.jsx:22-29`): active = current id;
 * error = step has entries in `stepErrors[id]`; done = visited AND appears
 * before the current step in the (possibly-just-changed) page list; upcoming
 * = everything else — never clickable (no forward-skip).
 */
export function deriveStepNavItems(
  pages: WizardPage[],
  currentStepId: string,
  visited: ReadonlySet<string>,
  stepErrors: Readonly<Record<string, string[]>>,
): StepNavItem[] {
  const currentIndex = pages.findIndex((p) => p.id === currentStepId);
  return pages.map((page, i) => {
    let state: StepNavState;
    if (page.id === currentStepId) state = "active";
    else if ((stepErrors[page.id]?.length ?? 0) > 0) state = "error";
    else if (visited.has(page.id) && i < currentIndex) state = "done";
    else state = "upcoming";
    return { id: page.id, label: page.label, optional: page.optional, state };
  });
}

/** Resolves a value + field options[] to display copy for the Review step (spec §2/§5). */
export function resolveReviewValue(
  value: unknown,
  field: { type: string; options?: Array<{ value: string; label: string }> | undefined },
): string {
  if (value === undefined || value === null || value === "") return "Not provided";

  if (field.type === "checkbox" || field.type === "switch") {
    return value ? "Required" : "Not required";
  }

  if (field.type === "checkbox-group" && Array.isArray(value)) {
    if (value.length === 0) return "Not provided";
    return value
      .map((v) => field.options?.find((o) => o.value === v)?.label ?? `${v} (no longer available)`)
      .join(", ");
  }

  if ((field.type === "select" || field.type === "radio-cards" || field.type === "search-select") && field.options) {
    const match = field.options.find((o) => o.value === value);
    return match ? match.label : `${String(value)} (no longer available)`;
  }

  return String(value);
}
