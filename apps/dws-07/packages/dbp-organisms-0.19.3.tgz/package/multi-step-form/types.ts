// APP.F27 — Multi-step Form (guided wizard). Config-schema re-export point.
//
// The wizard config contract (`WizardDefinitionSchema`/`WizardStepSchema`/
// `MultiStepFormOrganismConfigSchema`) is form-builder-owned (spec §4 —
// reuses `FormSectionSchema`/`FormFieldDefSchema`/`CrossFieldRuleSchema`
// verbatim, no parallel field vocabulary). This organism re-exports it as
// its own public config surface, same posture as `record-form` would.

export {
  WizardStepSchema,
  WizardDefinitionSchema,
  MultiStepFormOrganismConfigSchema,
  WizardDraftSchema,
} from "@dbp/organisms/form-builder/types";
export type {
  WizardStep,
  WizardDefinition,
  MultiStepFormOrganismConfig,
  WizardDraft,
} from "@dbp/organisms/form-builder/types";
