import * as React from "react";
import { Controller, useForm, type Control } from "react-hook-form";
import { useSessionIdentity } from "@dbp/ps-auth/client";
import { useFormSubmit } from "@dbp/organisms/form-builder/hooks";
import { compileDynamicSchema } from "@dbp/organisms/form-builder/logic";
import { FieldSet } from "@dbp/organisms/form-builder/renderer";
import type { FormDefinition, WizardStep } from "@dbp/organisms/form-builder/types";
import type { EntityData } from "@dbp/ps-data/client";
import { Alert, Badge, Button, Checkbox, StepNav } from "@dbp/ui";
import { MultiStepFormOrganismConfigSchema } from "./types.js";
import type { MultiStepFormOrganismConfig, WizardDefinition } from "./types.js";
import { useWizardDefinition, useWizardDraft } from "./hooks/index.js";
import { deriveVisibleSteps, deriveWizardPages, deriveStepNavItems, resolveReviewValue, REVIEW_STEP_ID } from "./logic/index.js";

const REVIEW_CONFIRM_FIELD = "__reviewConfirmed";

/**
 * APP.F27 — Multi-step Form (guided wizard).
 *
 * Config-driven wizard: `WizardDefinition.steps[]` (each a `FormSection[]`,
 * rendered via `@dbp/organisms/form-builder`'s `FieldSet`), a step-nav rail
 * (`@dbp/ui StepNav`), per-step validation, an auto-generated Review step,
 * and a real submit lifecycle — spec:
 * docs/03-features/specs/multi-step-form-spec-2026-07-12.md.
 */
export default function MultiStepForm(rawConfig: MultiStepFormOrganismConfig) {
  const parseResult = MultiStepFormOrganismConfigSchema.safeParse(rawConfig);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="MultiStepForm configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>{e.path.join(".") || "root"}: {e.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }

  const config = parseResult.data;
  if (config.wizardDefinition) {
    return <WizardInner definition={config.wizardDefinition} orientation={config.orientation} />;
  }
  return <WizardDefinitionLoader wizardDefinitionId={config.wizardDefinitionId!} orientation={config.orientation} />;
}

export type { MultiStepFormOrganismConfig } from "./types.js";

// ─── Loader (fetch-by-id path) ─────────────────────────────────────────────

function WizardDefinitionLoader({
  wizardDefinitionId,
  orientation,
}: {
  wizardDefinitionId: string;
  orientation: "horizontal" | "vertical";
}) {
  const { definition, isLoading, error } = useWizardDefinition(wizardDefinitionId);

  if (isLoading) {
    return <div className="animate-pulse text-sm text-[var(--color-text-muted)]" data-testid="wizard-loading">Loading…</div>;
  }
  if (error || !definition) {
    return (
      <Alert tone="danger" title="Could not load wizard definition" data-testid="definition-error">
        {error?.message ?? "Wizard definition not found."}
      </Alert>
    );
  }
  return <WizardInner definition={definition} orientation={orientation} />;
}

// ─── Inner (definition guaranteed valid here) ───────────────────────────────

type LifecycleStatus = "editing" | "saving" | "submitted";

function buildDefaultValues(definition: WizardDefinition): Record<string, unknown> {
  const defaults: Record<string, unknown> = { [REVIEW_CONFIRM_FIELD]: false };
  for (const step of definition.steps) {
    for (const section of step.sections) {
      for (const field of section.fields) {
        if (field.type === "checkbox" || field.type === "switch") defaults[field.id] = false;
        else if (field.type === "checkbox-group") defaults[field.id] = [];
        else if (field.type === "number") defaults[field.id] = undefined;
        else defaults[field.id] = "";
      }
    }
  }
  return defaults;
}

function stepAsFormDefinition(step: WizardStep): FormDefinition {
  // compileDynamicSchema only reads `.sections`/`.crossFieldRules` — the
  // other FormDefinition fields are irrelevant for a step-scoped compile.
  return { sections: step.sections, crossFieldRules: [] } as unknown as FormDefinition;
}

function WizardInner({ definition, orientation }: { definition: WizardDefinition; orientation: "horizontal" | "vertical" }) {
  const { identity } = useSessionIdentity();
  const userId = identity?.userId ?? "anonymous";
  const tenantId = identity?.tenantId ?? "default";

  const { register, control, watch, reset, formState: { errors } } = useForm<Record<string, unknown>>({
    defaultValues: buildDefaultValues(definition),
  });
  const values = watch();

  const [currentStepId, setCurrentStepId] = React.useState<string>(() => deriveVisibleSteps(definition, {})[0]?.id ?? REVIEW_STEP_ID);
  const [visited, setVisited] = React.useState<Set<string>>(() => new Set([currentStepId]));
  const [stepErrors, setStepErrors] = React.useState<Record<string, string[]>>({});
  const [announce, setAnnounce] = React.useState("");
  const [status, setStatus] = React.useState<LifecycleStatus>("editing");
  const [submitError, setSubmitError] = React.useState<string | null>(null);
  const returnToReviewRef = React.useRef(false);
  const dirtyFieldIdsRef = React.useRef<Set<string>>(new Set());

  const draftOptions = React.useMemo(() => ({ userId, tenantId }), [userId, tenantId]);
  const { draft, isLoading: draftLoading, saveStatus, scheduleAutosave, flushAutosave } = useWizardDraft(definition, draftOptions);

  // Resume a draft once, on load.
  const resumed = React.useRef(false);
  React.useEffect(() => {
    if (!resumed.current && draft) {
      resumed.current = true;
      reset({ ...buildDefaultValues(definition), ...draft.values });
      if (draft.currentStepId) setCurrentStepId(draft.currentStepId);
    }
  }, [draft, definition, reset]);

  // Debounced autosave (spec §5: "3s-after-change-or-on-blur"). Skipped
  // while resuming a draft or after submit.
  React.useEffect(() => {
    if (!resumed.current && draft === undefined && draftLoading) return;
    if (status !== "editing") return;
    scheduleAutosave(values, currentStepId, Array.from(dirtyFieldIdsRef.current));
  }, [values, currentStepId, status, scheduleAutosave, draft, draftLoading]);

  const pages = React.useMemo(() => deriveWizardPages(definition, values), [definition, values]);
  const visibleSteps = React.useMemo(() => deriveVisibleSteps(definition, values), [definition, values]);
  const stepNavItems = React.useMemo(
    () => deriveStepNavItems(pages, currentStepId, visited, stepErrors),
    [pages, currentStepId, visited, stepErrors],
  );

  const currentStep = visibleSteps.find((s) => s.id === currentStepId);
  const isReview = currentStepId === REVIEW_STEP_ID;
  const currentIndex = pages.findIndex((p) => p.id === currentStepId);

  const submitConfig = React.useMemo(
    () => ({ entityType: definition.entityType, mode: "create" as const, onSubmitWorkflow: definition.onSubmitWorkflow }),
    [definition.entityType, definition.onSubmitWorkflow],
  );
  const submitMutation = useFormSubmit(submitConfig);

  function announceStep(stepId: string) {
    const idx = pages.findIndex((p) => p.id === stepId);
    const title = pages[idx]?.label ?? stepId;
    setAnnounce(`Step ${idx + 1} of ${pages.length}: ${title}`);
  }

  function validateCurrentStep(): boolean {
    if (isReview) {
      if (definition.requireTermsAcceptance && !values[REVIEW_CONFIRM_FIELD]) {
        setStepErrors((prev) => ({ ...prev, [REVIEW_STEP_ID]: ["Confirm the details are correct before submitting."] }));
        setAnnounce("1 issue on this step");
        return false;
      }
      setStepErrors((prev) => ({ ...prev, [REVIEW_STEP_ID]: [] }));
      return true;
    }
    if (!currentStep) return true;
    const schema = compileDynamicSchema(stepAsFormDefinition(currentStep), values);
    const result = schema.safeParse(values);
    if (!result.success) {
      const messages = result.error.issues.map((i) => i.message);
      setStepErrors((prev) => ({ ...prev, [currentStepId]: messages }));
      setAnnounce(`${messages.length} issue${messages.length === 1 ? "" : "s"} on this step`);
      return false;
    }
    setStepErrors((prev) => ({ ...prev, [currentStepId]: [] }));
    return true;
  }

  function goTo(stepId: string) {
    setCurrentStepId(stepId);
    setVisited((prev) => new Set(prev).add(stepId));
    announceStep(stepId);
    flushAutosave(values, stepId, Array.from(dirtyFieldIdsRef.current));
  }

  function next() {
    if (!validateCurrentStep()) return;
    if (returnToReviewRef.current) {
      returnToReviewRef.current = false;
      goTo(REVIEW_STEP_ID);
      return;
    }
    const nextIndex = currentIndex + 1;
    const nextPage = pages[nextIndex];
    if (nextPage) goTo(nextPage.id);
  }

  function back() {
    // Back never validates (spec §5).
    const prevPage = pages[currentIndex - 1];
    if (prevPage) goTo(prevPage.id);
  }

  function editFromReview(stepId: string) {
    returnToReviewRef.current = true;
    goTo(stepId);
  }

  async function submit() {
    if (!validateCurrentStep()) return;
    setStatus("saving");
    setSubmitError(null);
    setAnnounce("Submitting…");
    try {
      const { [REVIEW_CONFIRM_FIELD]: _confirmed, ...payload } = values;
      await submitMutation.mutateAsync(payload as unknown as EntityData);
      setStatus("submitted");
      setAnnounce("Request submitted");
    } catch (err) {
      setStatus("editing");
      setSubmitError(err instanceof Error ? err.message : "Submission failed. Your answers were kept — try again.");
    }
  }

  if (status === "submitted") {
    return <ProvisionConfirmation definition={definition} />;
  }

  return (
    <div className="flex flex-col gap-6" data-testid="multi-step-form">
      <div aria-live="polite" className="sr-only" data-testid="wizard-announce">{announce}</div>

      {submitError && (
        <Alert tone="danger" title="Submission failed" data-testid="submit-error">
          {submitError}
        </Alert>
      )}

      <div className={orientation === "vertical" ? "flex gap-8" : "flex flex-col gap-6"}>
        <div className={orientation === "vertical" ? "sticky top-2 shrink-0 self-start" : "w-full"}>
          <StepNav steps={stepNavItems} orientation={orientation} onStepClick={goTo} />
        </div>

        <div className="flex min-w-0 flex-1 flex-col gap-4" data-testid="wizard-step-content">
          {isReview ? (
            <ReviewStep
              definition={definition}
              visibleSteps={visibleSteps}
              values={values}
              requireTermsAcceptance={definition.requireTermsAcceptance}
              errors={stepErrors[REVIEW_STEP_ID] ?? []}
              onEdit={editFromReview}
              control={control}
            />
          ) : currentStep ? (
            <>
              <div className="flex flex-col gap-0.5">
                <h2 className="text-base font-semibold text-[var(--color-text-primary)]">{currentStep.label}</h2>
                {currentStep.description && (
                  <p className="text-sm text-[var(--color-text-secondary)]">{currentStep.description}</p>
                )}
              </div>
              {currentStep.notice && (
                <Alert tone={currentStep.notice.tone} title={currentStep.notice.title} data-testid="step-notice">
                  {currentStep.notice.body}
                </Alert>
              )}
              {(stepErrors[currentStepId]?.length ?? 0) > 0 && (
                <Alert tone="danger" title={`${stepErrors[currentStepId]!.length} issue(s) on this step`} data-testid="step-validation-summary">
                  <ul className="mt-1 list-disc pl-4">
                    {stepErrors[currentStepId]!.map((m, i) => <li key={i}>{m}</li>)}
                  </ul>
                </Alert>
              )}
              <FieldSet
                sections={currentStep.sections}
                register={register}
                control={control}
                errors={errors}
                values={values}
                disabled={status === "saving"}
              />
            </>
          ) : null}
        </div>
      </div>

      <ActionFooter
        onBack={currentIndex > 0 ? back : undefined}
        onContinue={isReview ? submit : next}
        continueLabel={isReview ? definition.submitLabel : "Continue"}
        isSaving={status === "saving"}
        saveStatus={saveStatus}
        onSaveAndExit={() => flushAutosave(values, currentStepId, Array.from(dirtyFieldIdsRef.current))}
      />
    </div>
  );
}

// ─── ActionFooter ────────────────────────────────────────────────────────────

function ActionFooter({
  onBack,
  onContinue,
  continueLabel,
  isSaving,
  saveStatus,
  onSaveAndExit,
}: {
  onBack?: (() => void) | undefined;
  onContinue: () => void;
  continueLabel: string;
  isSaving: boolean;
  saveStatus: "idle" | "saving" | "saved";
  onSaveAndExit: () => void;
}) {
  return (
    <div className="sticky bottom-0 flex items-center justify-between gap-4 border-t border-[var(--color-border)] bg-[var(--color-surface)] px-1 py-3">
      <div className="flex items-center gap-3">
        <Button variant="ghost" type="button" onClick={onSaveAndExit} data-testid="save-and-exit">
          Save & exit
        </Button>
        <span aria-live="polite" className="text-xs text-[var(--color-text-muted)]" data-testid="save-status-indicator">
          {saveStatus === "saving" && "Saving draft…"}
          {saveStatus === "saved" && "Draft saved · just now"}
          {saveStatus === "idle" && ""}
        </span>
      </div>
      <div className="flex items-center gap-3">
        {onBack && (
          <Button variant="outline" type="button" onClick={onBack} data-testid="wizard-back">
            Previous
          </Button>
        )}
        <Button type="button" loading={isSaving} disabled={isSaving} onClick={onContinue} data-testid="wizard-continue">
          {isSaving ? "Submitting…" : continueLabel}
        </Button>
      </div>
    </div>
  );
}

// ─── Review step ─────────────────────────────────────────────────────────────

function ReviewStep({
  definition,
  visibleSteps,
  values,
  requireTermsAcceptance,
  errors,
  onEdit,
  control,
}: {
  definition: WizardDefinition;
  visibleSteps: WizardStep[];
  values: Record<string, unknown>;
  requireTermsAcceptance: boolean;
  errors: string[];
  onEdit: (stepId: string) => void;
  control: Control<Record<string, unknown>>;
}) {
  return (
    <div className="flex flex-col gap-5" data-testid="wizard-review">
      <h2 className="text-base font-semibold text-[var(--color-text-primary)]">{definition.reviewStepLabel}</h2>
      {visibleSteps.map((step) => (
        <div key={step.id} className="flex flex-col gap-2 rounded-[var(--radius-card)] border border-[var(--color-border)] p-4" data-testid={`review-block-${step.id}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">{step.label}</h3>
              {step.notice && <Badge tone="warning" size="sm">Approval required</Badge>}
            </div>
            <Button type="button" variant="link" className="text-xs font-medium" onClick={() => onEdit(step.id)} data-testid={`review-edit-${step.id}`}>
              Edit
            </Button>
          </div>
          <dl className="grid grid-cols-1 gap-x-6 gap-y-1.5 sm:grid-cols-2">
            {step.sections.flatMap((section) => section.fields).map((field) => (
              <div key={field.id} className="flex flex-col">
                <dt className="text-xs text-[var(--color-text-muted)]">{field.label}</dt>
                <dd className="text-sm text-[var(--color-text-primary)]">{resolveReviewValue(values[field.id], field)}</dd>
              </div>
            ))}
          </dl>
          {step.notice && (
            <div className="flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
              <Badge tone="navy" size="sm">Auto</Badge>
              <span>Route: Finance administrators</span>
            </div>
          )}
        </div>
      ))}

      {requireTermsAcceptance && (
        <div className="flex flex-col gap-1.5">
          <label className="flex cursor-pointer items-start gap-2.5 text-sm text-[var(--color-text-secondary)]">
            <Controller
              name={REVIEW_CONFIRM_FIELD}
              control={control}
              render={({ field }) => (
                <Checkbox
                  checked={Boolean(field.value)}
                  onCheckedChange={(v) => field.onChange(v === true)}
                  aria-invalid={errors.length > 0}
                />
              )}
            />
            <span className="flex flex-col gap-0.5">
              <span>{definition.labels["reviewConfirmLabel"] ?? "The information above is correct"}</span>
              <span className="text-xs text-[var(--color-text-muted)]">
                {definition.labels["reviewConfirmDescription"] ?? "You confirm these details are accurate before submitting."}
              </span>
            </span>
          </label>
          {errors.length > 0 && (
            <p className="text-xs leading-snug text-[var(--color-danger-text)]" role="alert" data-testid="review-confirm-error">
              {errors[0]}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Confirmation ────────────────────────────────────────────────────────────

function ProvisionConfirmation({ definition }: { definition: WizardDefinition }) {
  return (
    <div className="flex flex-col items-center gap-3 py-12 text-center" data-testid="wizard-confirmation">
      <Badge tone="success" size="default">Submitted</Badge>
      <h2 className="text-lg font-semibold text-[var(--color-text-primary)]">{definition.successMessage}</h2>
    </div>
  );
}
