# @dbp/organisms/multi-step-form (APP.F27)

Config-driven multi-step guided wizard — step-nav rail (horizontal/vertical),
per-step validation, an auto-generated Review step, real debounced autosave
against a `form-draft` PS.DATA sub-entity, and a submit lifecycle with
confirmation.

Spec: `docs/03-features/specs/multi-step-form-spec-2026-07-12.md`.

## Config

```ts
import type { MultiStepFormOrganismConfig } from "@dbp/organisms/multi-step-form";
```

Pass either an inline `wizardDefinition` (a `WizardDefinition` — see
`@dbp/organisms/form-builder/types`) or a `wizardDefinitionId` to fetch one at
runtime via PS.DATA (`wizard-definition` entity type).

## Composition

Reuses `@dbp/organisms/form-builder`'s `FieldSet` to render each step's
`FormSection[]` and `compileDynamicSchema` for per-step validation — no
parallel field-rendering code in this package. Step-nav chrome is
`@dbp/ui StepNav`.
