// Local patch — restores files missing from the published @dbp/organisms
// 0.19.3 tarball (upstream packaging gap, not a BioTest bug: the same gap
// reproduces from standard-menu-baseline routes, unrelated to this
// manifest). Baked into packages/dbp-organisms-0.19.3.tgz itself so it
// survives every `pnpm install`, instead of a node_modules-only edit that
// a clean install would silently drop.

export interface EditorialRailAction {
  id: string;
  label: string;
  source?: string;
  [key: string]: unknown;
}

export interface EditorialMediaChapter {
  label: string;
  [key: string]: unknown;
}

export interface EditorialMediaVisualStage {
  step: string;
  title: string;
  description: string;
  icon?: string;
  [key: string]: unknown;
}

export interface EditorialMedia {
  kind?: "video" | "image" | "article" | string;
  url?: string;
  posterUrl?: string;
  imageAlt?: string;
  imageCaption?: string;
  articleMeta?: string;
  contentTypeLabel?: string;
  durationLabel?: string;
  transcriptHref?: string;
  chapters?: EditorialMediaChapter[];
  visualStages?: EditorialMediaVisualStage[];
  [key: string]: unknown;
}

export interface EditorialPresentation {
  title?: string;
  summary?: string;
  code?: string;
  badges: unknown[];
  headerMeta?: unknown;
  updatedAtLabel?: string;
  media?: EditorialMedia;
  showRail?: boolean;
  railActions: EditorialRailAction[];
  actionsTitle?: string;
  actionsBlurb?: string;
  overviewTitle?: string;
  overviewLead?: string;
  overviewBody?: string;
  detailsTitle?: string;
  details: unknown[];
  outcomesTitle?: string;
  outcomes: unknown[];
  documentsTitle?: string;
  documents: unknown[];
  documentsZipHref?: string;
  governanceNote?: string;
  readiness?: unknown;
  relatedTitle?: string;
  related: unknown[];
  [key: string]: unknown;
}
