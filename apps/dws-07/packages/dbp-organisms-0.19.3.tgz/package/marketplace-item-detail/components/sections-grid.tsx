/**
 * SectionsGrid — renders the entity's app-data fields as icon+label+value rows.
 *
 * Overview tab content for the marketplace detail page. Fields in APPLIES_TO_FIELDS
 * are extracted into a separate "Applies to" badge pills section at the bottom;
 * everything else appears in the "Details" icon-row card.
 *
 * Dependency: @dbp/ui (SectionCard, Badge, Skeleton), @dbp/ps-data/client (EntityData).
 */
import React from "react";
import * as LucideIcons from "lucide-react";
import { Badge, Skeleton } from "@dbp/ui";
import { SectionCard } from "@dbp/ui";
import type { EntityData } from "@dbp/ps-data/client";

/** Fields excluded from display (PS.DATA envelope metadata). */
const EXCLUDED_FIELDS = new Set([
  "id", "type", "tenantId", "createdAt", "updatedAt", "__typename",
]);

/**
 * Fields that render as "Applies to" pill badges instead of icon rows.
 * Values may be comma-separated strings (split into individual pills).
 */
const APPLIES_TO_FIELDS = new Set([
  "appliesToDepartments", "appliesToTeams", "appliesToRoles",
  "tags", "audiences", "scope",
]);

/** Field name → Lucide icon name mapping. Fallback: Circle. */
const FIELD_ICONS: Record<string, string> = {
  name: "Tag",
  title: "FileText",
  description: "AlignLeft",
  summary: "AlignLeft",
  assetType: "FileText",
  category: "Store",
  tier: "Layers",
  code: "Hash",
  compliance: "Shield",
  recommended: "Star",
  status: "CircleDot",
  price: "DollarSign",
  version: "GitBranch",
  controlLevel: "Lock",
  owner: "User",
  approver: "UserCheck",
  lastReviewedDate: "Calendar",
  reviewCycle: "RefreshCcw",
  appliesToDepartments: "Target",
  appliesToTeams: "Users",
  tags: "Tag",
};

function resolveIcon(
  name?: string,
): React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }> {
  if (!name) return LucideIcons.Circle;
  const candidate = (LucideIcons as unknown as Record<string, unknown>)[name];
  return (
    (candidate as React.ComponentType<{
      size?: number;
      strokeWidth?: number;
      className?: string;
    }>) ?? LucideIcons.Circle
  );
}

function humanLabel(key: string): string {
  return key
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (s) => s.toUpperCase())
    .trim();
}

function formatFieldValue(value: unknown): React.ReactNode {
  if (value === null || value === undefined || value === "") {
    return <span className="text-gray-300">—</span>;
  }
  if (typeof value === "boolean") {
    return <Badge tone={value ? "success" : "gray"}>{value ? "Yes" : "No"}</Badge>;
  }
  if (typeof value === "object") return String(JSON.stringify(value));
  const str = String(value);
  // ISO date → localised short date
  if (/^\d{4}-\d{2}-\d{2}T/.test(str)) {
    try {
      return new Date(str).toLocaleDateString(undefined, {
        year: "numeric", month: "short", day: "numeric",
      });
    } catch {
      return str;
    }
  }
  return str;
}

interface Props {
  data: EntityData | undefined;
  isLoading: boolean;
  entityType: string;
}

export function SectionsGrid({ data, isLoading, entityType }: Props) {
  if (isLoading) {
    return (
      <div className="space-y-5">
        <div className="rounded-lg border border-gray-200 bg-white px-5 pt-5 pb-5">
          <Skeleton className="mb-4 h-4 w-32" />
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center gap-3 py-3 border-t border-gray-100 first:border-t-0">
              <Skeleton className="h-7 w-7 rounded-md shrink-0" />
              <div className="flex-1 space-y-1">
                <Skeleton className="h-3 w-20" />
                <Skeleton className="h-4 w-40" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <SectionCard title={`${entityType} Details`}>
        <p className="text-sm text-gray-500">No data available.</p>
      </SectionCard>
    );
  }

  // PS.DATA wraps app fields in record.data; fall back to top-level if absent.
  const appData = (data as Record<string, unknown>)["data"];
  const source: Record<string, unknown> =
    appData && typeof appData === "object" && !Array.isArray(appData)
      ? (appData as Record<string, unknown>)
      : (data as Record<string, unknown>);

  const fields: Array<{ key: string; value: unknown }> = [];
  const appliesToItems: string[] = [];

  for (const [key, value] of Object.entries(source)) {
    if (EXCLUDED_FIELDS.has(key)) continue;
    if (APPLIES_TO_FIELDS.has(key)) {
      if (value != null && value !== "") {
        const str = String(value);
        appliesToItems.push(...str.split(",").map((s) => s.trim()).filter(Boolean));
      }
      continue;
    }
    fields.push({ key, value });
  }

  if (fields.length === 0 && appliesToItems.length === 0) {
    return (
      <SectionCard title={`${entityType} Details`} data-testid="overview-section">
        <p className="text-sm text-gray-500">No fields to display.</p>
      </SectionCard>
    );
  }

  return (
    <div className="space-y-5" data-testid="overview-section">
      {fields.length > 0 && (
        <SectionCard title="Details">
          <div className="divide-y divide-gray-100">
            {fields.map(({ key, value }) => {
              const Icon = resolveIcon(FIELD_ICONS[key]);
              return (
                <div key={key} className="flex items-start gap-3 py-3 first:pt-0 last:pb-0">
                  <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-orange-50">
                    <Icon
                      size={14}
                      strokeWidth={1.5}
                      className="text-[var(--color-secondary)]"
                      aria-hidden="true"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold uppercase tracking-[0.08em] text-gray-400">
                      {humanLabel(key)}
                    </p>
                    <div className="mt-0.5 text-sm text-gray-900">
                      {formatFieldValue(value)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </SectionCard>
      )}

      {appliesToItems.length > 0 && (
        <SectionCard title="Applies to">
          <div className="flex flex-wrap gap-2">
            {appliesToItems.map((item) => (
              <Badge key={item} tone="gray">{item}</Badge>
            ))}
          </div>
        </SectionCard>
      )}
    </div>
  );
}
