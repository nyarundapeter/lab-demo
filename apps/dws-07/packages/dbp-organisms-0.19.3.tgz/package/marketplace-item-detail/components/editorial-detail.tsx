"use client";

import { toast } from "@dbp/ui";
import type { EditorialPresentation, EditorialRailAction } from "../editorial-types.js";
import { EditorialDetailHeader } from "./detail-header.js";
import { EditorialDetailBody } from "./detail-editorial.js";
import { EditorialDetailMedia } from "./detail-media.js";
import { EditorialDetailRail } from "./detail-rail.js";
import { EditorialDetailRelated } from "./detail-related.js";

function dispatchAction(
  action: EditorialRailAction,
  entityType: string,
  entityId: string,
) {
  document.dispatchEvent(
    new CustomEvent("dbp:marketplace-item-detail:action", {
      detail: { id: action.id, entityType, entityId },
      bubbles: true,
    }),
  );
  toast({ title: action.label, description: "Action dispatched (stub handler)." });
}

export function EditorialDetailView({
  presentation,
  entityType,
  entityId,
  suppressHeader = false,
  titleRowAction,
}: {
  presentation: EditorialPresentation;
  entityType: string;
  entityId: string;
  suppressHeader?: boolean;
  titleRowAction?: { label: string; onClick: () => void };
}) {
  const embedPrimaryInMedia =
    presentation.media?.kind === "video" && presentation.railActions.length > 0;
  const mediaPrimary = embedPrimaryInMedia ? presentation.railActions[0] : undefined;
  const railPresentation =
    embedPrimaryInMedia && mediaPrimary
      ? {
          ...presentation,
          railActions: presentation.railActions.filter((a) => a !== mediaPrimary),
          showRail:
            presentation.railActions.filter((a) => a !== mediaPrimary).length > 0 ||
            presentation.documents.length > 0 ||
            presentation.details.length > 0,
        }
      : presentation;

  const handleAction = (action: EditorialRailAction) => {
    if (action.source === "title-row" && titleRowAction) {
      titleRowAction.onClick();
      dispatchAction(action, entityType, entityId);
      return;
    }
    dispatchAction(action, entityType, entityId);
  };

  return (
    <main
      className="w-full"
      aria-label={`${presentation.title} detail`}
      data-testid="marketplace-item-detail"
    >
      <EditorialDetailHeader
        presentation={presentation}
        suppressHeader={suppressHeader}
        {...(titleRowAction && !presentation.showRail ? { titleRowAction } : {})}
      />

      <div
        className={
          railPresentation.showRail
            ? "grid grid-cols-1 items-start gap-x-8 gap-y-8 lg:grid-cols-[minmax(0,1fr)_320px]"
            : "grid grid-cols-1 items-start gap-y-8"
        }
      >
        <div className="min-w-0">
          {presentation.media ? (
            <EditorialDetailMedia
              media={presentation.media}
              title={presentation.title}
              subtitle={presentation.summary}
              {...(mediaPrimary
                ? {
                    primaryAction: mediaPrimary,
                    onPrimary: () => handleAction(mediaPrimary),
                  }
                : {})}
            />
          ) : null}
          <EditorialDetailBody presentation={presentation} />
        </div>

        {railPresentation.showRail ? (
          <EditorialDetailRail presentation={railPresentation} onAction={handleAction} />
        ) : null}

        <div className={railPresentation.showRail ? "min-w-0 lg:col-span-2" : "min-w-0"}>
          <EditorialDetailRelated presentation={presentation} />
        </div>
      </div>
    </main>
  );
}
