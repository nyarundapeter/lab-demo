"use client";

import * as React from "react";
import { ChevronDown, Clock, FileText, Play } from "lucide-react";
import { Button } from "@dbp/ui";
import type { EditorialMedia, EditorialRailAction } from "../editorial-types.js";

const STAGE_ICONS: Record<string, string> = {
  discern: "✕",
  design: "△",
  deploy: "→",
  drive: "◎",
};

function ContentTypeBadge({ label }: { label: string }) {
  return (
    <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-[var(--color-secondary)]">
      {label}
    </span>
  );
}

export function EditorialDetailMedia({
  media,
  title,
  subtitle,
  primaryAction,
  onPrimary,
}: {
  media: EditorialMedia;
  title?: string;
  subtitle?: string;
  primaryAction?: EditorialRailAction;
  onPrimary?: () => void;
}) {
  const [chaptersOpen, setChaptersOpen] = React.useState(false);

  if (media.kind === "video" && (media.url || media.posterUrl)) {
    const typeLabel = media.contentTypeLabel ?? "Video course";
    return (
      <section
        aria-label="Video content"
        className="mb-6 overflow-hidden rounded-[var(--radius-card,0.75rem)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)]"
        data-testid="detail-media"
      >
        <div className="relative aspect-video bg-[var(--color-primary)]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={media.posterUrl ?? media.url}
            alt={media.imageAlt ?? "Video poster"}
            className="size-full object-cover opacity-40"
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-6 text-center text-[var(--color-text-on-primary,white)]">
            <ContentTypeBadge label={typeLabel} />
            {title ? (
              <p className="max-w-lg text-[28px] font-bold leading-tight tracking-tight">{title}</p>
            ) : null}
            {subtitle ? (
              <p className="max-w-md text-[15px] opacity-80">{subtitle}</p>
            ) : null}
            {primaryAction ? (
              <Button
                type="button"
                variant="navy"
                className="mt-2 h-11 gap-2 cursor-pointer px-6"
                onClick={onPrimary}
                data-testid="media-primary-action"
              >
                <Play size={16} fill="currentColor" aria-hidden="true" />
                {primaryAction.label}
                {media.durationLabel ? (
                  <span className="opacity-80">· {media.durationLabel} introduction</span>
                ) : null}
              </Button>
            ) : null}
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-[var(--color-border-default)] px-4 py-3">
          <div className="flex flex-wrap items-center gap-3 text-sm text-[var(--color-text-muted)]">
            <ContentTypeBadge label={typeLabel} />
            {media.durationLabel ? (
              <span className="inline-flex items-center gap-1.5">
                <Clock size={14} aria-hidden="true" />
                {media.durationLabel}
              </span>
            ) : null}
          </div>
          {media.transcriptHref ? (
            <a
              href={media.transcriptHref}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--color-border-default)] px-3 py-1.5 text-sm font-medium text-[var(--color-primary)] hover:bg-[var(--color-surface-secondary)]"
            >
              <FileText size={14} aria-hidden="true" />
              Transcript
            </a>
          ) : null}
        </div>
        {media.chapters && media.chapters.length > 0 ? (
          <div className="border-t border-[var(--color-border-default)]">
            <button
              type="button"
              className="flex w-full cursor-pointer items-center justify-between px-4 py-3 text-left text-sm font-semibold text-[var(--color-primary)]"
              onClick={() => setChaptersOpen((open) => !open)}
              aria-expanded={chaptersOpen}
            >
              <span>Chapters</span>
              <span className="inline-flex items-center gap-2 text-[var(--color-text-muted)]">
                {media.chapters.length} chapters
                <ChevronDown
                  size={16}
                  className={`transition-transform ${chaptersOpen ? "rotate-180" : ""}`}
                  aria-hidden="true"
                />
              </span>
            </button>
            {chaptersOpen ? (
              <ol className="border-t border-[var(--color-border-default)] px-4 py-2 text-sm">
                {media.chapters.map((chapter) => (
                  <li key={chapter.label} className="py-2 text-[var(--color-text-muted)]">
                    {chapter.label}
                  </li>
                ))}
              </ol>
            ) : null}
          </div>
        ) : null}
      </section>
    );
  }

  if (media.kind === "image") {
    const typeLabel = media.contentTypeLabel ?? "Visual guide";
    return (
      <section
        aria-label="Visual guide"
        className="mb-6 overflow-hidden rounded-[var(--radius-card,0.75rem)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)]"
        data-testid="detail-media"
      >
        {media.visualStages && media.visualStages.length > 0 ? (
          <div className="bg-[var(--color-primary)] px-5 py-4">
            <ContentTypeBadge label={typeLabel} />
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {media.visualStages.map((stage) => (
                <div
                  key={stage.step}
                  className="rounded-lg border border-[color-mix(in_srgb,white_10%,transparent)] bg-[color-mix(in_srgb,white_5%,transparent)] p-4 text-[var(--color-text-on-primary,white)]"
                >
                  <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-[var(--color-secondary)]">
                    {stage.icon ? `${STAGE_ICONS[stage.icon] ?? ""} ` : ""}
                    {stage.step}
                  </p>
                  <p className="mt-2 text-[15px] font-bold">{stage.title}</p>
                  <p className="mt-1 text-[13px] leading-relaxed opacity-75">{stage.description}</p>
                </div>
              ))}
            </div>
          </div>
        ) : media.url ? (
          <figure>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={media.url} alt={media.imageAlt ?? ""} className="w-full object-cover" />
          </figure>
        ) : null}
        {media.imageCaption ? (
          <p className="border-t border-[var(--color-border-default)] px-4 py-3 text-sm text-[var(--color-text-muted)]">
            {media.imageCaption}
          </p>
        ) : null}
      </section>
    );
  }

  if (media.kind === "article" && media.articleMeta) {
    return (
      <section
        aria-label="Article metadata"
        className="mb-6 rounded-[var(--radius-card,0.75rem)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-5 py-4"
        data-testid="detail-media"
      >
        <p className="text-sm text-[var(--color-text-muted)]">{media.articleMeta}</p>
      </section>
    );
  }

  return null;
}
