"use client";

import * as React from "react";
import { Lock, Share2 } from "lucide-react";
import { Badge, Button } from "@dbp/ui";
import type { EditorialPresentation } from "../editorial-types.js";

export function EditorialDetailHeader({
  presentation,
  suppressHeader = false,
  titleRowAction,
}: {
  presentation: EditorialPresentation;
  suppressHeader?: boolean;
  titleRowAction?: { label: string; onClick: () => void };
}) {
  const handleShare = React.useCallback(async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    const title = presentation.title;
    try {
      if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
        await navigator.share({ title, url });
        return;
      }
      if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
      }
    } catch {
      // User cancelled share — ignore.
    }
  }, [presentation.title]);

  if (suppressHeader) {
    return (
      <div
        className="mb-6 flex items-center justify-between gap-4 border-b border-[var(--color-border-subtle)] pb-5"
        data-testid="detail-title-row"
      >
        <h1
          className="min-w-0 break-words text-2xl font-bold tracking-[-0.02em] text-[var(--color-primary)]"
          data-testid="detail-title"
        >
          {presentation.title}
        </h1>
        {titleRowAction ? (
          <Button
            type="button"
            variant="navy"
            size="sm"
            className="shrink-0 cursor-pointer"
            onClick={titleRowAction.onClick}
            data-testid="detail-title-row-action"
          >
            {titleRowAction.label}
          </Button>
        ) : null}
      </div>
    );
  }

  return (
    <header
      className="mb-6 border-b border-[var(--color-border-subtle)] pb-5"
      data-testid="detail-header"
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 flex-1">
          <h1
            className="break-words text-3xl font-bold leading-tight tracking-[-0.02em] text-[var(--color-primary)] md:text-4xl"
            data-testid="detail-title"
          >
            {presentation.title}
          </h1>
          <p className="mt-3 flex flex-wrap items-center gap-x-2.5 gap-y-2 text-sm text-[var(--color-text-muted)]">
            <span className="font-mono text-xs font-semibold uppercase tracking-[0.14em] text-[var(--color-primary)]">
              {presentation.code}
            </span>
            {presentation.updatedAtLabel ? (
              <>
                <span aria-hidden="true">·</span>
                <time dateTime={presentation.updatedAtLabel}>
                  Updated {presentation.updatedAtLabel}
                </time>
              </>
            ) : null}
            {presentation.headerMeta ? (
              <>
                <span aria-hidden="true">·</span>
                <span>{presentation.headerMeta}</span>
              </>
            ) : null}
          </p>
          {/* Badges only when no editorial meta line — avoids chip clutter on DEWA-style pages */}
          {presentation.badges.length > 0 && !presentation.headerMeta ? (
            <div className="mt-4 flex flex-wrap items-center gap-2">
              {presentation.badges.map((bf) => {
                if (bf.style === "lock") {
                  return (
                    <span
                      key={`${bf.style}-${bf.label}`}
                      className="inline-flex items-center gap-1.5 rounded-full bg-[var(--color-surface-secondary)] px-3 py-1 text-xs font-semibold text-[var(--color-primary)]"
                    >
                      <Lock size={12} strokeWidth={1.5} aria-hidden="true" />
                      {bf.label}
                    </span>
                  );
                }
                if (bf.style === "mono") {
                  return (
                    <span
                      key={`${bf.style}-${bf.label}`}
                      className="rounded-full bg-[var(--color-surface-secondary)] px-3 py-1 font-mono text-xs font-semibold uppercase tracking-[0.14em] text-[var(--color-primary)]"
                    >
                      {bf.label}
                    </span>
                  );
                }
                return (
                  <Badge key={`${bf.style}-${bf.label}`} tone="gray">
                    {bf.label}
                  </Badge>
                );
              })}
            </div>
          ) : null}
        </div>

        <div
          className="flex flex-wrap items-center gap-2 sm:shrink-0"
          data-testid="detail-header-actions"
        >
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="cursor-pointer gap-2 text-[var(--color-text-muted)]"
            aria-label="Share"
            onClick={() => {
              void handleShare();
            }}
            data-testid="detail-share-action"
          >
            <Share2 size={15} strokeWidth={1.5} aria-hidden="true" />
            Share
          </Button>
        </div>
      </div>
    </header>
  );
}
