"use client";

import { Skeleton } from "@dbp/ui";

export function EditorialDetailSkeleton() {
  return (
    <div className="w-full pb-8" aria-busy="true" aria-label="Loading" data-testid="detail-skeleton">
      <div className="mb-6 border-b border-[var(--color-border-subtle)] pb-5">
        <Skeleton className="h-9 w-80" />
        <Skeleton className="mt-3 h-4 w-[28rem] max-w-full" />
      </div>
      <div className="grid grid-cols-1 items-start gap-x-8 gap-y-8 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="min-w-0 space-y-4">
          <Skeleton className="h-7 w-40" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="mt-8 h-7 w-48" />
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </div>
        <div className="space-y-4">
          <Skeleton className="h-40 w-full rounded-lg" />
          <Skeleton className="h-32 w-full rounded-lg" />
        </div>
      </div>
    </div>
  );
}
