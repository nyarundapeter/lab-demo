"use client";

import * as React from "react";
import { Download, Send } from "lucide-react";
import { Button, RailSection } from "@dbp/ui";
import type { EditorialPresentation, EditorialRailAction } from "../editorial-types.js";

function openDocumentHref(href: string, label: string) {
  const anchor = document.createElement("a");
  anchor.href = href;
  anchor.target = "_blank";
  anchor.rel = "noopener noreferrer";
  anchor.download = label;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}

function actionTestId(action: EditorialRailAction): string {
  if (action.source === "acknowledge") return "rail-action-acknowledge";
  if (action.source === "governance") return `gov-action-${action.id}`;
  return `rail-action-${action.id}`;
}

export function EditorialDetailRail({
  presentation,
  onAction,
}: {
  presentation: EditorialPresentation;
  onAction: (action: EditorialRailAction) => void;
}) {
  const documents = presentation.documents;
  const hasDocuments = documents.length > 0;
  const hasDetails = presentation.details.length > 0;
  const ctaActions = presentation.railActions;
  const hasCta = ctaActions.length > 0;

  if (!hasCta && !hasDocuments && !hasDetails) {
    return null;
  }

  const primary = ctaActions.find((a) => a.tone === "navy") ?? ctaActions[0];
  const secondary = ctaActions.filter((a) => a !== primary);

  const secondaryRailClass =
    "rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-surface)] px-4 py-4 shadow-none";

  const handleDownloadAll = React.useCallback(() => {
    const zipHref = presentation.documentsZipHref;
    if (zipHref) {
      openDocumentHref(zipHref, "documents-pack.zip");
      return;
    }
    documents.forEach((doc, index) => {
      window.setTimeout(() => {
        openDocumentHref(doc.href, doc.label);
      }, index * 200);
    });
  }, [documents, presentation.documentsZipHref]);

  return (
    <aside
      aria-label="Item details and actions"
      className="flex w-full flex-col gap-[var(--space-4,1rem)] self-start lg:sticky lg:top-[var(--space-4,1rem)] lg:max-h-[calc(100dvh-var(--space-4,1rem)-var(--space-6,1.5rem))] lg:overflow-y-auto"
      data-testid="detail-rail"
    >
      {hasCta ? (
        <RailSection
          title={presentation.actionsTitle}
          className="border-[color-mix(in_srgb,var(--color-primary)_12%,var(--color-border-subtle))] bg-[color-mix(in_srgb,var(--color-primary)_3%,var(--color-surface-content))]"
        >
          {presentation.actionsBlurb ? (
            <p className="text-sm leading-relaxed text-[var(--color-text-muted)]">
              {presentation.actionsBlurb}
            </p>
          ) : null}
          <div className="mt-4 flex flex-col gap-2">
            {primary ? (
              <Button
                type="button"
                variant="navy"
                className="h-11 w-full cursor-pointer justify-center gap-2"
                onClick={() => onAction(primary)}
                data-testid={actionTestId(primary)}
              >
                {primary.source === "acknowledge" || primary.source === "title-row" ? (
                  <Send size={16} strokeWidth={1.5} aria-hidden="true" />
                ) : null}
                {primary.label}
              </Button>
            ) : null}
            {secondary.map((action) => (
              <Button
                key={action.id}
                type="button"
                variant="ghost"
                className="h-9 w-full cursor-pointer justify-start gap-2 px-2 text-sm font-medium text-[var(--color-text-secondary)]"
                onClick={() => onAction(action)}
                data-testid={actionTestId(action)}
              >
                {action.label}
              </Button>
            ))}
          </div>
        </RailSection>
      ) : null}

      {hasDocuments ? (
        <RailSection title={presentation.documentsTitle} className={secondaryRailClass}>
          {documents.length > 1 ? (
            <Button
              type="button"
              variant="ghost"
              className="mb-2 h-8 w-full cursor-pointer justify-start gap-2 px-1 text-[var(--color-text-secondary)]"
              onClick={handleDownloadAll}
              data-testid="documents-download-all"
            >
              <Download size={14} strokeWidth={1.5} aria-hidden="true" />
              Download all ({documents.length})
            </Button>
          ) : null}
          <ul className="flex flex-col" data-testid="detail-documents">
            {documents.map((doc) => (
              <li key={`${doc.label}-${doc.href}`}>
                <a
                  href={doc.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex w-full cursor-pointer items-center gap-2.5 rounded-md px-1 py-2 text-left text-xs font-medium text-[var(--color-text-secondary)] transition hover:bg-[var(--color-surface-secondary)] hover:text-[var(--color-text-primary)] focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
                  data-testid="document-download"
                >
                  <Download
                    size={14}
                    strokeWidth={1.5}
                    className="shrink-0 text-[var(--color-text-disabled)]"
                    aria-hidden="true"
                  />
                  <span className="min-w-0 flex-1 truncate">{doc.label}</span>
                  {doc.fileType ? (
                    <span className="shrink-0 font-mono text-xs uppercase tracking-[0.08em] text-[var(--color-text-muted)]">
                      {doc.fileType}
                    </span>
                  ) : null}
                </a>
              </li>
            ))}
          </ul>
        </RailSection>
      ) : null}

      {hasDetails ? (
        <RailSection title={presentation.detailsTitle} className={secondaryRailClass}>
          <dl className="divide-y divide-[var(--color-border-subtle)]">
            {presentation.details.map((row, index) => (
              <div
                key={`${row.label}-${index}`}
                className="flex items-baseline justify-between gap-3 py-2.5 first:pt-0 last:pb-0"
              >
                <dt className="text-xs text-[var(--color-text-muted)]">{row.label}</dt>
                <dd className="text-right text-sm font-medium text-[var(--color-text-primary)]">
                  {row.value}
                </dd>
              </div>
            ))}
          </dl>
        </RailSection>
      ) : null}
    </aside>
  );
}
