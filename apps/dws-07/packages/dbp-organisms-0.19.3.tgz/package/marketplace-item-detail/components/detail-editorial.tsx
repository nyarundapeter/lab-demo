"use client";

import type { ReactNode } from "react";
import type { EditorialPresentation } from "../editorial-types.js";

const RULE = "border-[var(--color-border-subtle)]";

function parseOutcomeItem(item: string): { title: string; description?: string } {
  const [title, ...rest] = item.split("|");
  const trimmedTitle = title?.trim() ?? item;
  const description = rest.join("|").trim();
  return description ? { title: trimmedTitle, description } : { title: trimmedTitle };
}

function SectionHeading({ id, children }: { id: string; children: ReactNode }) {
  return (
    <h2
      id={id}
      className="text-2xl font-bold tracking-[-0.01em] text-[var(--color-primary)]"
    >
      {children}
    </h2>
  );
}

export function EditorialDetailBody({
  presentation,
}: {
  presentation: EditorialPresentation;
}) {
  const bodyLines = presentation.overviewBody
    .split(/\n+/)
    .map((l) => l.trim())
    .filter(Boolean);
  const lead = presentation.overviewLead.trim();
  // Don't repeat the same sentence as both lead and first overview paragraph.
  const showLead =
    lead.length > 0 &&
    !bodyLines.some((line) => line.toLowerCase() === lead.toLowerCase());
  const hasOutcomes = presentation.outcomes.length > 0;
  const hasNotes = Boolean(presentation.readiness || presentation.governanceNote);

  return (
    <div className="min-w-0" data-testid="overview-section">
      <section aria-labelledby="detail-about-heading">
        <SectionHeading id="detail-about-heading">{presentation.overviewTitle}</SectionHeading>
        {showLead ? (
          <p className="mt-4 text-base leading-relaxed text-[var(--color-text-muted)]">
            {lead}
          </p>
        ) : null}
        {bodyLines.length > 0 ? (
          <div className={`max-w-3xl space-y-3 ${showLead ? "mt-4" : "mt-4"}`}>
            {bodyLines.map((line, i) => (
              <p
                key={`overview-line-${i}`}
                className="text-base leading-relaxed text-[var(--color-text-muted)]"
              >
                {line}
              </p>
            ))}
          </div>
        ) : null}
      </section>

      {hasOutcomes ? (
        <div className="mt-12 border-t border-[var(--color-border-subtle)] pt-10">
          <section aria-labelledby="detail-included-heading">
            <SectionHeading id="detail-included-heading">
              {presentation.outcomesTitle}
            </SectionHeading>
            <ol className="mt-8 space-y-6">
              {presentation.outcomes.map((item, index) => {
                const parsed = parseOutcomeItem(item);
                return (
                  <li
                    key={`${item}-${index}`}
                    className={`flex gap-5 border-t ${RULE} pt-6 first:border-t-0 first:pt-0`}
                  >
                    <span
                      className="shrink-0 text-xl font-bold tabular-nums text-[var(--color-secondary)]"
                      aria-hidden="true"
                    >
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0">
                      <p className="text-base font-semibold text-[var(--color-primary)]">
                        {parsed.title}
                      </p>
                      {parsed.description ? (
                        <p className="mt-1.5 text-sm leading-relaxed text-[var(--color-text-muted)]">
                          {parsed.description}
                        </p>
                      ) : null}
                    </div>
                  </li>
                );
              })}
            </ol>
          </section>
        </div>
      ) : null}

      {hasNotes ? (
        <div className={`mt-10 space-y-3 border-t ${RULE} pt-8`}>
          {presentation.readiness ? (
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-[0.12em] text-[var(--color-text-muted)]">
                Best for
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-[var(--color-text-muted)]">
                {presentation.readiness}
              </p>
            </div>
          ) : null}
          {presentation.governanceNote ? (
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-[0.12em] text-[var(--color-text-muted)]">
                Note
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-[var(--color-text-muted)]">
                {presentation.governanceNote}
              </p>
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
