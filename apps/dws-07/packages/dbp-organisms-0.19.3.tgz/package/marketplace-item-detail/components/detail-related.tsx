"use client";

import { ArrowUpRight } from "lucide-react";
import type { EditorialPresentation } from "../editorial-types.js";

const RELATED_MAX = 3;

function humanize(value: string): string {
  return value
    .replace(/[-_]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
}

export function EditorialDetailRelated({
  presentation,
}: {
  presentation: EditorialPresentation;
}) {
  const items = presentation.related.slice(0, RELATED_MAX);
  if (items.length === 0) return null;

  const sectionTitle = presentation.relatedTitle ?? "Related items";

  return (
    <section
      aria-labelledby="detail-related-heading"
      className="border-t border-[var(--color-border-subtle)] pt-8"
      data-testid="detail-related"
    >
      <h2
        id="detail-related-heading"
        className="mb-3 text-sm font-semibold leading-snug text-[var(--color-primary)]"
      >
        {sectionTitle}
      </h2>

      <ul className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:grid-cols-3">
        {items.map((item) => {
          const category = item.category ? humanize(item.category) : null;
          const status = item.status ? humanize(item.status) : null;

          return (
            <li key={item.id} className="min-h-0">
              <a
                href={item.href}
                className="group flex h-full min-h-[184px] w-full cursor-pointer flex-col rounded-[10px] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-5 py-4 text-left shadow-[0_1px_2px_color-mix(in_srgb,var(--color-primary)_6%,transparent)] transition hover:border-[color-mix(in_srgb,var(--color-secondary)_45%,var(--color-border-default))]"
              >
                <div className="mb-4 flex items-start justify-between gap-3">
                  <div className="flex min-w-0 flex-wrap items-center gap-2">
                    {category ? (
                      <span className="max-w-[11rem] truncate rounded-full bg-[var(--color-surface-secondary)] px-2.5 py-1 text-[10px] font-bold uppercase leading-none tracking-[0.13em] text-[var(--color-text-muted)]">
                        {category}
                      </span>
                    ) : null}
                    {status ? (
                      <span className="shrink-0 rounded-full border border-[color-mix(in_srgb,var(--color-secondary)_35%,var(--color-border-subtle))] bg-[color-mix(in_srgb,var(--color-secondary)_8%,var(--color-surface-content))] px-2 py-1 text-[10px] font-bold uppercase leading-none tracking-[0.13em] text-[var(--color-secondary)]">
                        {status}
                      </span>
                    ) : null}
                  </div>
                  <ArrowUpRight
                    size={13}
                    strokeWidth={1.9}
                    className="mt-1 shrink-0 text-[var(--color-secondary)] opacity-0 transition group-hover:opacity-100"
                    aria-hidden="true"
                  />
                </div>

                <h3 className="line-clamp-2 text-[15px] font-semibold leading-snug text-[var(--color-primary)]">
                  {item.label}
                </h3>

                {item.summary ? (
                  <p className="mt-2 line-clamp-2 text-[13px] leading-5 text-[var(--color-text-muted)]">
                    {item.summary}
                  </p>
                ) : null}

                <div className="mt-auto flex items-end justify-between gap-3 border-t border-[var(--color-border-subtle)] pt-4">
                  <span className="min-w-0 truncate font-mono text-[9px] font-semibold uppercase tracking-[0.24em] text-[var(--color-text-muted)]">
                    {item.id}
                  </span>
                  <span className="shrink-0 font-mono text-[9px] font-semibold uppercase tracking-[0.24em] text-[var(--color-secondary)] opacity-0 transition group-hover:opacity-100">
                    View
                  </span>
                </div>
              </a>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
