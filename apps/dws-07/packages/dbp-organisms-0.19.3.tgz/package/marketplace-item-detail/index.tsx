import React, { useState } from "react";
import * as LucideIcons from "lucide-react";
import { Lock, FileQuestion } from "lucide-react";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  Badge,
  Button,
  Skeleton,
  Alert,
  EmptyState,
  ErrorState,
  toast,
  DetailPageGrid,
  RailSection,
  RailActionButton,
  SectionCard,
  Breadcrumb,
  LandingCta,
  PublicPageHeader,
  useBreadcrumbOverride,
} from "@dbp/ui";
import { ActivityFeed } from "@dbp/organisms/activity-feed";
import { useEntity } from "@dbp/ps-data/client";
import type { EntityData } from "@dbp/ps-data/client";
import { SectionsGrid } from "./components/sections-grid.js";
import { EditorialDetailView } from "./components/editorial-detail.js";
import { EditorialDetailSkeleton } from "./components/editorial-skeleton.js";
import { toEditorialPresentation } from "./to-editorial-presentation.js";
import {
  MarketplaceItemDetailConfig,
  type MarketplaceItemDetailConfigInput,
  type BadgeFieldDef,
} from "./types.js";

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Prop types                                                                  */
/* ─────────────────────────────────────────────────────────────────────────── */

export interface MarketplaceItemDetailProps extends MarketplaceItemDetailConfigInput {
  /** The entity id from the `[id]` route param — drives the PS.DATA fetch. */
  entityId: string;
  /** Optional router callback — used by breadcrumb navigation. Pass `router.push` from next/navigation. */
  onNavigate?: (href: string) => void;
  /**
   * Render variant (React-only, not part of the Zod config schema).
   * - "ops" (default): header rendered inside the white content area — backwards-compat.
   * - "marketing": light editorial layout — a light-gray header band owns the
   *   title/summary/badges + a right-hand price/benefit card; an underline tab
   *   strip, numbered Key Outcomes grid, optional Related Services row, and an
   *   optional dark CTA band follow. Used by the DXP public marketplace detail page.
   */
  detailVariant?: "marketing" | "ops";
  /**
   * When true, the feature skips rendering its internal header block (h1 title,
   * subtitle, badge pills, primary CTA button). Use this when the page wraps the
   * feature in a CanvasLayout — the layout owns the PageHeader, not the feature.
   * Defaults to false so existing usages without the prop continue to work unchanged.
   */
  suppressHeader?: boolean;
  /**
   * N36: when `suppressHeader` is true, the feature still renders a compact
   * title row (record name + status badge, primary action right-aligned on
   * the same line) instead of nothing — the page's floating action button
   * (e.g. "Submit Enquiry") folds into this row rather than floating alone.
   */
  titleRowAction?: { label: string; onClick: () => void };
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Icon resolver                                                               */
/* ─────────────────────────────────────────────────────────────────────────── */

function resolveIcon(
  name?: string,
): React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }> {
  if (!name) return LucideIcons.ChevronRight;
  const candidate = (LucideIcons as unknown as Record<string, unknown>)[name];
  return (
    (candidate as React.ComponentType<{
      size?: number;
      strokeWidth?: number;
      className?: string;
    }>) ?? LucideIcons.ChevronRight
  );
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Action dispatcher (shared by header button + rail)                          */
/* ─────────────────────────────────────────────────────────────────────────── */

function dispatchAction(
  action: { id: string; label: string },
  entityType: string,
  entityId: string,
) {
  document.dispatchEvent(
    new CustomEvent("dbp:marketplace-item-detail:action", {
      detail: { id: action.id, entityType, entityId },
      bubbles: true,
    }),
  );
  toast({ title: action.label, description: "Action dispatched (stub handler)." });
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Header badge row                                                            */
/* ─────────────────────────────────────────────────────────────────────────── */

function HeaderBadgeRow({
  badgeFields,
  data,
}: {
  badgeFields: BadgeFieldDef[];
  data: EntityData | undefined;
}) {
  if (!badgeFields.length || !data) return null;

  return (
    <div className="mt-4 flex flex-wrap items-center gap-2">
      {badgeFields.map((bf) => {
        const value = data[bf.field];
        if (value == null || value === "") return null;
        const label = String(value);

        if (bf.style === "lock") {
          return (
            <span
              key={bf.field}
              className="inline-flex items-center gap-1.5 rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-[var(--color-primary)]"
            >
              <Lock size={12} strokeWidth={1.5} aria-hidden="true" />
              {label}
            </span>
          );
        }

        if (bf.style === "mono") {
          return (
            <span
              key={bf.field}
              className="rounded-full bg-gray-100 px-3 py-1 font-mono text-xs font-semibold uppercase tracking-[0.14em] text-[var(--color-primary)]"
            >
              {label}
            </span>
          );
        }

        return (
          <Badge key={bf.field} tone="gray">
            {label}
          </Badge>
        );
      })}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Skeleton loading state                                                      */
/* ─────────────────────────────────────────────────────────────────────────── */

function DetailPageSkeleton({ marketingVariant = false }: { marketingVariant?: boolean }) {
  return (
    <div className="pb-8" aria-busy="true" aria-label="Loading">
      {!marketingVariant && (
        <div className="pt-4">
          <div className="mb-6">
            <Skeleton className="mb-4 h-3 w-48" />
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <Skeleton className="h-9 w-80" />
                <Skeleton className="mt-3 h-4 w-[480px]" />
                <div className="mt-4 flex gap-2">
                  <Skeleton className="h-6 w-20 rounded-full" />
                  <Skeleton className="h-6 w-16 rounded-full" />
                </div>
              </div>
              <Skeleton className="h-9 w-36 rounded-md shrink-0" />
            </div>
          </div>
        </div>
      )}
      <div className="grid grid-cols-1 gap-x-8 gap-y-8 lg:grid-cols-12 lg:items-start">
        <div className="min-w-0 space-y-5 lg:col-span-8">
          <Skeleton className="h-10 w-full" />
          <div className="rounded-lg border border-gray-200 bg-white px-5 py-5">
            <Skeleton className="mb-4 h-4 w-32" />
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-3 py-3 border-t border-gray-100 first:border-t-0">
                <Skeleton className="h-7 w-7 rounded-md shrink-0" />
                <div className="flex-1 space-y-1">
                  <Skeleton className="h-3 w-20" />
                  <Skeleton className="h-4 w-40" />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="min-w-0 lg:col-span-4">
          <div className="lg:pt-[3.5rem] space-y-5">
            <div className="rounded-lg border border-gray-200 bg-white px-5 py-5">
              <Skeleton className="mb-4 h-4 w-24" />
              <div className="space-y-2">
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-8 w-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Curated metadata fields shown in the "Governance & Details" rail section   */
/* ─────────────────────────────────────────────────────────────────────────── */

const GOVERNANCE_META = [
  { key: "code",             label: "Code",          icon: "Hash"        },
  { key: "status",           label: "Status",        icon: "CircleDot"   },
  { key: "tier",             label: "Tier",          icon: "Layers"      },
  { key: "compliance",       label: "Compliance",    icon: "Shield"      },
  { key: "version",          label: "Version",       icon: "GitBranch"   },
  { key: "controlLevel",     label: "Control",       icon: "Lock"        },
  { key: "owner",            label: "Owner",         icon: "User"        },
  { key: "approver",         label: "Approver",      icon: "UserCheck"   },
  { key: "lastReviewedDate", label: "Last Updated",  icon: "Calendar"    },
  { key: "reviewCycle",      label: "Review Cycle",  icon: "RefreshCcw"  },
  { key: "recommended",      label: "Featured",      icon: "Star"        },
];

function formatMetaValue(value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  const str = String(value);
  if (/^\d{4}-\d{2}-\d{2}T/.test(str)) {
    try {
      return new Date(str).toLocaleDateString(undefined, {
        year: "numeric", month: "short", day: "numeric",
      });
    } catch {
      return str;
    }
  }
  return str;
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Right rail                                                                  */
/* ─────────────────────────────────────────────────────────────────────────── */

function DetailRail({
  entityType,
  entityId,
  railActions,
  acknowledgement,
  governanceActions,
  data,
}: {
  entityType: string;
  entityId: string;
  railActions: MarketplaceItemDetailConfig["railActions"];
  acknowledgement: MarketplaceItemDetailConfig["acknowledgement"];
  governanceActions: MarketplaceItemDetailConfig["governanceActions"];
  data: EntityData | undefined;
}) {
  const hasRailActions = railActions && railActions.length > 0;
  const hasGovActions = governanceActions && governanceActions.length > 0;

  // Extract governance metadata from the entity's app-data sub-object.
  const appData = data
    ? ((data as Record<string, unknown>)["data"] as Record<string, unknown> | undefined) ??
      (data as Record<string, unknown>)
    : undefined;

  const metaRows = appData
    ? GOVERNANCE_META.filter(({ key }) => {
        const v = appData[key];
        return v != null && v !== "" && v !== false;
      })
    : [];

  return (
    <div className="w-full space-y-5 lg:sticky lg:top-24">

      {/* ── Use in Work ─────────────────────────────────────────── */}
      {hasRailActions && (
        <RailSection title="Use in Work">
          <div className="space-y-2">
            {railActions!.map((action) => (
              <RailActionButton
                key={action.id}
                {...(action.icon !== undefined && { icon: action.icon })}
                tone={action.tone === "navy" ? "outline" : (action.tone ?? "outline")}
                onClick={() => dispatchAction(action, entityType, entityId)}
                data-testid={`rail-action-${action.id}`}
              >
                {action.label}
              </RailActionButton>
            ))}
          </div>
        </RailSection>
      )}

      {/* ── Acknowledgement ──────────────────────────────────────── */}
      {acknowledgement && (
        <RailSection title="Acknowledgement">
          <p className="mb-2.5 text-xs leading-relaxed text-gray-500">
            This guidance requires your acknowledgement before applying it to work.
          </p>
          {acknowledgement.required && (
            <RailActionButton
              icon="ShieldCheck"
              tone="navy"
              onClick={() => {
                dispatchAction(
                  { id: "acknowledge", label: acknowledgement.label },
                  entityType,
                  entityId,
                );
              }}
              data-testid="rail-action-acknowledge"
            >
              {acknowledgement.label}
            </RailActionButton>
          )}
        </RailSection>
      )}

      {/* ── Governance Actions ───────────────────────────────────── */}
      {hasGovActions && (
        <RailSection title="Governance Actions">
          <div className="space-y-0.5">
            {governanceActions!.map((action) => (
              <RailActionButton
                key={action.id}
                {...(action.icon !== undefined && { icon: action.icon })}
                tone={action.tone ?? "ghost"}
                onClick={() => dispatchAction(action, entityType, entityId)}
                data-testid={`gov-action-${action.id}`}
              >
                {action.label}
              </RailActionButton>
            ))}
          </div>
        </RailSection>
      )}

      {/* ── Governance & Details ─────────────────────────────────── */}
      {metaRows.length > 0 && (
        <RailSection title="Governance & Details">
          <div className="space-y-3">
            {metaRows.map(({ key, label, icon }) => {
              const Icon = resolveIcon(icon);
              const value = appData![key];
              return (
                <div key={key} className="flex items-center gap-2.5 text-xs">
                  <Icon
                    size={13}
                    strokeWidth={1.5}
                    className="shrink-0 text-gray-400"
                    aria-hidden="true"
                  />
                  <span className="min-w-0 flex-1 text-gray-500">{label}</span>
                  <span className="text-right font-semibold text-[var(--color-primary)] capitalize">
                    {formatMetaValue(value)}
                  </span>
                </div>
              );
            })}
          </div>
        </RailSection>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Marketing variant — helpers                                                 */
/* ─────────────────────────────────────────────────────────────────────────── */

/** Unwrap PS.DATA's nested `data` sub-object, with a top-level fallback. */
function unwrapEntityData(record: EntityData | undefined): Record<string, unknown> {
  if (!record) return {};
  const nested = (record as Record<string, unknown>)["data"];
  return nested && typeof nested === "object" && !Array.isArray(nested)
    ? (nested as Record<string, unknown>)
    : (record as Record<string, unknown>);
}

/** Read a string field from the unwrapped entity data. */
function readString(source: Record<string, unknown>, field?: string): string {
  if (!field) return "";
  const v = source[field];
  return v == null ? "" : String(v);
}

/** Read a string[] field from the unwrapped entity data. */
function readStringArray(source: Record<string, unknown>, field?: string): string[] {
  if (!field) return [];
  const v = source[field];
  return Array.isArray(v) ? v.map((x) => String(x)) : [];
}

/** Split an outcome ("Title|Description" or just "Title") into title + description. */
function parseOutcome(outcome: string): { title: string; desc: string } {
  const parts = outcome.split("|");
  return { title: (parts[0] ?? "").trim(), desc: parts.slice(1).join("|").trim() };
}

/**
 * KeyOutcomesGrid — plain numbered 01/02/03/04 grid (no cards), matching the TMaaS
 * "Key Outcomes" block: orange index, bold title, gray description.
 */
function KeyOutcomesGrid({ outcomes }: { outcomes: string[] }) {
  return (
    <div
      className="mt-6 grid grid-cols-1 gap-x-8 gap-y-8 sm:grid-cols-2 lg:grid-cols-4"
      data-testid="key-outcomes-grid"
    >
      {outcomes.map((outcome, i) => {
        const { title, desc } = parseOutcome(outcome);
        return (
          <div key={i}>
            <p className="text-3xl font-bold text-[var(--color-secondary)]">
              {String(i + 1).padStart(2, "0")}
            </p>
            <p className="mt-3 text-sm font-semibold text-[var(--color-primary)]">{title}</p>
            {desc && <p className="mt-1.5 text-xs leading-relaxed text-gray-500">{desc}</p>}
          </div>
        );
      })}
    </div>
  );
}

/**
 * DeliverablesList — the "What You Receive" tab: a "Duration / Scope" meta line and a
 * numbered list of deliverables (one per outcome), matching the TMaaS layout.
 */
function DeliverablesList({ outcomes, timeline }: { outcomes: string[]; timeline: string }) {
  return (
    <div data-testid="deliverables-list">
      <h2 className="text-2xl font-bold tracking-[-0.01em] text-[var(--color-primary)]">
        Deliverables
      </h2>
      <p className="mt-2 text-sm text-gray-500">
        {timeline && <>Duration: {timeline}</>}
        {timeline && outcomes.length > 0 && <span className="px-1.5">•</span>}
        {outcomes.length > 0 && <>Scope: {outcomes.length} core deliverables</>}
      </p>
      <ol className="mt-8 space-y-6">
        {outcomes.map((outcome, i) => {
          const { title, desc } = parseOutcome(outcome);
          return (
            <li key={i} className="flex gap-5 border-t border-gray-100 pt-6 first:border-t-0 first:pt-0">
              <span className="text-xl font-bold text-[var(--color-secondary)]">
                {String(i + 1).padStart(2, "0")}
              </span>
              <div className="min-w-0">
                <p className="text-base font-semibold text-[var(--color-primary)]">{title}</p>
                {desc && <p className="mt-1.5 text-sm leading-relaxed text-gray-600">{desc}</p>}
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

/**
 * ProcessSteps — "How It Works" tab: numbered process steps from a string[] of
 * "Step title|Description" entries.
 */
function ProcessSteps({ items }: { items: string[] }) {
  return (
    <ol className="space-y-6" data-testid="process-steps">
      {items.map((item, i) => {
        const { title, desc } = parseOutcome(item);
        return (
          <li key={i} className="flex gap-5">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[var(--color-surface-secondary)] text-sm font-bold text-[var(--color-secondary)]">
              {i + 1}
            </span>
            <div className="min-w-0 pt-0.5">
              <p className="text-base font-semibold text-[var(--color-primary)]">{title}</p>
              {desc && <p className="mt-1.5 text-sm leading-relaxed text-gray-600">{desc}</p>}
            </div>
          </li>
        );
      })}
    </ol>
  );
}

/**
 * PointsList — "Why It Matters" tab: a card grid of "Title|Description" points.
 */
function PointsList({ items }: { items: string[] }) {
  return (
    <ul className="grid grid-cols-1 gap-5 sm:grid-cols-2" data-testid="points-list">
      {items.map((item, i) => {
        const { title, desc } = parseOutcome(item);
        return (
          <li key={i} className="rounded-xl border border-gray-200 bg-white p-5">
            <p className="text-sm font-semibold text-[var(--color-primary)]">{title}</p>
            {desc && <p className="mt-1.5 text-sm leading-relaxed text-gray-600">{desc}</p>}
          </li>
        );
      })}
    </ul>
  );
}

/**
 * FaqList — "FAQs" tab: a definition list of "Question|Answer" entries.
 */
function FaqList({ items }: { items: string[] }) {
  return (
    <dl className="divide-y divide-gray-100" data-testid="faq-list">
      {items.map((item, i) => {
        const { title, desc } = parseOutcome(item);
        return (
          <div key={i} className="py-5 first:pt-0 last:pb-0">
            <dt className="text-base font-semibold text-[var(--color-primary)]">{title}</dt>
            {desc && <dd className="mt-2 text-sm leading-relaxed text-gray-600">{desc}</dd>}
          </div>
        );
      })}
    </dl>
  );
}

/**
 * TabEmpty — graceful fallback for a marketing tab whose backing entity content
 * has not been published yet (e.g. a builder added the tab but not the data).
 */
function TabEmpty({ label }: { label: string }) {
  return (
    <EmptyState
      icon={<FileQuestion size={22} strokeWidth={1.5} />}
      title={`${label} coming soon`}
      description="This information will be published shortly. In the meantime, talk to our team for the details you need."
    />
  );
}

type RelatedItem = {
  id: string;
  name: string;
  summary: string;
  category: string;
  priceFrom: string;
  timeline: string;
};

/**
 * RelatedServices — fetches up to 3 sibling records of the same entityType filtered
 * to the current item's category (client-side filter), excluding the current item.
 * Renders nothing while loading or when no siblings exist. Mirrors the direct-fetch
 * pattern used by FeaturedCarousel.
 */
function RelatedServices({
  entityType,
  entityId,
  category,
  priceFromField,
  timelineField,
  onNavigate,
}: {
  entityType: string;
  entityId: string;
  category: string;
  priceFromField?: string;
  timelineField?: string;
  onNavigate?: (href: string) => void;
}) {
  const [items, setItems] = useState<RelatedItem[]>([]);

  React.useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await fetch(
          `/api/platform/data/entities/${encodeURIComponent(entityType)}`,
          { headers: { "x-tenant-id": "tenant-alpha" } },
        );
        if (!res.ok) return;
        const json = (await res.json()) as
          | { rows?: Array<Record<string, unknown>>; items?: Array<Record<string, unknown>> }
          | Array<Record<string, unknown>>;
        // PS.DATA list endpoint returns { rows: [...] }; also tolerate { items } or a bare array.
        const rows = Array.isArray(json) ? json : (json.rows ?? json.items ?? []);
        const mapped: RelatedItem[] = rows
          .map((row) => {
            const id = String((row as Record<string, unknown>)["id"] ?? "");
            const d = unwrapEntityData(row as EntityData);
            return {
              id,
              name: readString(d, "name"),
              summary: readString(d, "summary"),
              category: readString(d, "category"),
              priceFrom: readString(d, priceFromField),
              timeline: readString(d, timelineField),
            };
          })
          .filter((r) => r.id && r.id !== entityId && (!category || r.category === category))
          .slice(0, 3);
        if (!cancelled) setItems(mapped);
      } catch {
        /* network/parse failure → render nothing */
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [entityType, entityId, category, priceFromField, timelineField]);

  if (items.length === 0) return null;

  return (
    <section className="bg-white px-5 pb-12 md:px-8 lg:px-10" data-testid="related-services">
      <div className="max-w-[1200px] mx-auto">
        <h2 className="text-xl font-bold text-[var(--color-primary)]">Related Services</h2>
        <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-3">
          {items.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                const href = `/marketplace/${encodeURIComponent(item.id)}`;
                if (onNavigate) onNavigate(href);
                else window.location.href = href;
              }}
              className="group flex h-full flex-col rounded-xl border border-gray-200 bg-white p-5 text-left shadow-sm transition hover:border-[var(--color-secondary)] hover:shadow-md"
            >
              <p className="text-sm font-semibold text-[var(--color-primary)]">{item.name}</p>
              {item.summary && (
                <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-gray-500">{item.summary}</p>
              )}
              <div className="mt-auto pt-4">
                {item.category && (
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-gray-400">
                    {item.category}
                  </p>
                )}
                {(item.priceFrom || item.timeline) && (
                  <p className="mt-1 flex items-center gap-2 text-xs font-semibold text-[var(--color-primary)]">
                    {item.priceFrom}
                    {item.priceFrom && item.timeline ? " · " : ""}
                    {item.timeline}
                    <LucideIcons.ArrowRight
                      size={13}
                      strokeWidth={1.5}
                      className="text-[var(--color-secondary)] transition-transform group-hover:translate-x-0.5"
                      aria-hidden="true"
                    />
                  </p>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Inner (after config parse passes)                                           */
/* ─────────────────────────────────────────────────────────────────────────── */

function MarketplaceItemDetailInner({
  entityId,
  entityType,
  titleField,
  summaryField,
  breadcrumb,
  badgeFields,
  tabs,
  railActions,
  acknowledgement,
  governanceActions,
  priceFromField,
  timelineField,
  idealForField,
  outcomesField,
  showRelated,
  ctaBand,
  onNavigate,
  detailVariant = "ops",
  suppressHeader = false,
  titleRowAction,
}: MarketplaceItemDetailConfig & {
  entityId: string;
  onNavigate?: (href: string) => void;
  detailVariant?: "marketing" | "ops";
  suppressHeader?: boolean;
  titleRowAction?: { label: string; onClick: () => void };
}) {
  const [activeTab, setActiveTab] = useState(tabs[0]?.id ?? "overview");

  const { data, isLoading, error } = useEntity<EntityData>(entityType, entityId, {
    enabled: true,
  });

  // N36: once the record resolves, override the top-bar breadcrumb's terminal
  // crumb with its display name (only when the page has delegated the header
  // to the shell via suppressHeader — the "marketing" variant owns its own
  // PublicPageHeader and isn't mounted inside the authenticated shell chrome).
  const breadcrumbTitle = data
    ? String(unwrapEntityData(data)[titleField] ?? unwrapEntityData(data)[summaryField] ?? entityId)
    : undefined;
  useBreadcrumbOverride(suppressHeader ? breadcrumbTitle : undefined);

  /* ── Loading ───────────────────────────────────────────────────────────── */
  if (isLoading) {
    if (detailVariant === "marketing") {
      return (
        <>
          <section className="bg-[var(--color-surface-secondary)] px-5 pb-12 pt-6 md:px-8 lg:px-10">
            <div className="max-w-[1200px] mx-auto">
              <span className="dq-overline text-[var(--color-secondary)]">← Back to marketplace</span>
              <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-[1fr_360px]">
                <div className="animate-pulse space-y-4">
                  <div className="h-6 w-40 rounded-full bg-gray-200" />
                  <div className="h-10 w-3/4 rounded bg-gray-200" />
                  <div className="h-4 w-1/2 rounded bg-gray-200" />
                </div>
                <div className="animate-pulse rounded-xl border border-gray-200 bg-white p-6">
                  <div className="h-7 w-32 rounded bg-gray-200" />
                  <div className="mt-4 space-y-2">
                    <div className="h-4 w-full rounded bg-gray-200" />
                    <div className="h-4 w-full rounded bg-gray-200" />
                    <div className="h-4 w-2/3 rounded bg-gray-200" />
                  </div>
                  <div className="mt-6 h-11 w-full rounded-full bg-gray-200" />
                </div>
              </div>
            </div>
          </section>
          <div className="bg-white px-5 py-10 md:px-8 lg:px-10">
            <div className="max-w-[1200px] mx-auto">
              <DetailPageSkeleton marketingVariant />
            </div>
          </div>
        </>
      );
    }
    return <EditorialDetailSkeleton />;
  }

  /* ── Error states ──────────────────────────────────────────────────────── */
  if (error) {
    const is404 =
      error instanceof Error &&
      (error.message.includes("404") || error.message.toLowerCase().includes("not found"));

    if (is404) {
      return (
        <div className="pb-8" role="alert" data-testid="not-found-state">
          <div className="pt-4">
            <EmptyState
              icon={<FileQuestion size={22} strokeWidth={1.5} />}
              title="Item not found"
              description={`No ${entityType} record was found for "${entityId}".`}
            />
          </div>
        </div>
      );
    }

    return (
      <div className="pb-8">
        <div className="pt-4">
          <ErrorState title="Failed to load item" error={error} />
        </div>
      </div>
    );
  }

  /* ── Resolve display values ────────────────────────────────────────────── */
  const appData = unwrapEntityData(data);

  /* ── Ops / default: DEWA-style editorial layout (UI-only swap) ─────────── */
  if (detailVariant !== "marketing") {
    const { presentation } = toEditorialPresentation(
      appData,
      {
        entityType,
        titleField,
        summaryField,
        ...(breadcrumb !== undefined ? { breadcrumb } : {}),
        badgeFields,
        tabs,
        ...(railActions !== undefined ? { railActions } : {}),
        ...(acknowledgement !== undefined ? { acknowledgement } : {}),
        ...(governanceActions !== undefined ? { governanceActions } : {}),
        ...(priceFromField !== undefined ? { priceFromField } : {}),
        ...(timelineField !== undefined ? { timelineField } : {}),
        ...(idealForField !== undefined ? { idealForField } : {}),
        ...(outcomesField !== undefined ? { outcomesField } : {}),
        showRelated,
        ...(ctaBand !== undefined ? { ctaBand } : {}),
      },
      {
        ...(titleRowAction
          ? { titleRowAction: { id: "submit-enquiry", label: titleRowAction.label } }
          : {}),
        ...(data && typeof (data as { updatedAt?: unknown }).updatedAt === "string"
          ? { updatedAt: (data as { updatedAt: string }).updatedAt }
          : {}),
      },
    );

    return (
      <EditorialDetailView
        presentation={presentation}
        entityType={entityType}
        entityId={entityId}
        suppressHeader={suppressHeader}
        {...(titleRowAction ? { titleRowAction } : {})}
      />
    );
  }

  const title = data ? String(appData[titleField] ?? appData[summaryField] ?? entityId) : entityId;
  const summary = data ? String(appData[summaryField] ?? "") : "";

  // First navy rail action → promoted to header primary CTA
  const headerAction = railActions?.find((a) => a.tone === "navy") ?? railActions?.[0];

  // Marketing-variant display values (read from the unwrapped entity data).
  const priceFrom = readString(appData, priceFromField);
  const timeline = readString(appData, timelineField);
  const idealFor = readString(appData, idealForField);
  const outcomes = readStringArray(appData, outcomesField);
  const benefitLines = outcomes.map((o) => (o.split("|")[0] ?? "").trim()).slice(0, 3);
  const category = readString(appData, "category");
  const tier = readString(appData, "tier");
  const recommended = appData["recommended"] === true;

  /* ── Tab content builder ───────────────────────────────────────────────── */
  function renderTabContent(tabId: string) {
    if (tabId === "overview") {
      return <SectionsGrid data={data} isLoading={false} entityType={entityType} />;
    }

    if (tabId === "governance") {
      const hasGovActions = governanceActions && governanceActions.length > 0;
      return (
        <div className="space-y-5" data-testid="governance-tab-content">
          <SectionCard title="Governance Actions">
            {hasGovActions ? (
              <div className="space-y-1">
                {governanceActions!.map((action) => {
                  const Icon = resolveIcon(action.icon);
                  return (
                    <div
                      key={action.id}
                      className="flex items-center gap-2 rounded-md px-1.5 py-1.5 text-xs text-gray-700"
                    >
                      <Icon
                        size={13}
                        strokeWidth={1.5}
                        className="shrink-0 text-gray-400"
                        aria-hidden="true"
                      />
                      {action.label}
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-gray-500">No governance actions configured.</p>
            )}
          </SectionCard>
        </div>
      );
    }

    if (tabId === "resources" || tabId === "activity") {
      return (
        <SectionCard title="Activity">
          <ActivityFeed entityId={entityId} />
        </SectionCard>
      );
    }

    return (
      <SectionCard>
        <p className="text-sm text-gray-500">
          Content for <strong>{tabId}</strong> tab.
        </p>
      </SectionCard>
    );
  }

  /* ── Marketing tab content (editorial; no rail, no raw field dump) ──────────
   * Extensible: a builder can add a tab to the config and (for the data-driven
   * tabs) populate the matching entity field. Any tab with no backing content —
   * including tab ids not handled here — falls back gracefully to TabEmpty. */
  function renderMarketingTab(tabId: string) {
    const tabLabel = tabs.find((t) => t.id === tabId)?.label ?? tabId;

    if (tabId === "overview") {
      return (
        <div data-testid="overview-marketing">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold tracking-[-0.01em] text-[var(--color-primary)]">
                About This Service
              </h2>
              {summary && (
                <p className="mt-4 text-base leading-relaxed text-gray-600 md:text-base">
                  {summary}
                </p>
              )}
            </div>
            {idealFor && (
              <aside className="lg:border-l lg:border-gray-200 lg:pl-8">
                <h3 className="text-xs font-semibold uppercase tracking-[0.12em] text-gray-400">
                  Who it&apos;s for
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-gray-600">{idealFor}</p>
              </aside>
            )}
          </div>
          {outcomes.length > 0 && (
            <div className="mt-12 border-t border-gray-100 pt-10">
              <h2 className="text-2xl font-bold tracking-[-0.01em] text-[var(--color-primary)]">
                Key Outcomes
              </h2>
              <KeyOutcomesGrid outcomes={outcomes} />
            </div>
          )}
        </div>
      );
    }

    if (tabId === "what-you-receive") {
      return outcomes.length > 0 ? (
        <DeliverablesList outcomes={outcomes} timeline={timeline} />
      ) : (
        <TabEmpty label={tabLabel} />
      );
    }

    if (tabId === "how-it-works") {
      const steps = readStringArray(appData, "howItWorks");
      return steps.length > 0 ? <ProcessSteps items={steps} /> : <TabEmpty label={tabLabel} />;
    }

    if (tabId === "why-it-matters") {
      const points = readStringArray(appData, "whyItMatters");
      return points.length > 0 ? <PointsList items={points} /> : <TabEmpty label={tabLabel} />;
    }

    if (tabId === "faqs") {
      const faqs = readStringArray(appData, "faqs");
      return faqs.length > 0 ? <FaqList items={faqs} /> : <TabEmpty label={tabLabel} />;
    }

    // Unknown / not-yet-populated tab → graceful fallback.
    return <TabEmpty label={tabLabel} />;
  }

  /* ── Layout ────────────────────────────────────────────────────────────── */
  const contentColumn = (
    <div className="min-w-0">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList aria-label="Detail page tabs">
          {tabs.map((tab) => (
            <TabsTrigger key={tab.id} value={tab.id}>
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>
        {tabs.map((tab) => (
          <TabsContent key={tab.id} value={tab.id} className="mt-6">
            {renderTabContent(tab.id)}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );

  const railColumn = (
    <DetailRail
      entityType={entityType}
      entityId={entityId}
      railActions={railActions}
      acknowledgement={acknowledgement}
      governanceActions={governanceActions}
      data={data}
    />
  );

  /* ── Marketing variant: light header band + editorial layout ──────────── */
  if (detailVariant === "marketing") {
    return (
      <>
        {/* A1 PublicPageHeader (gray band) — title + text meta + summary + ideal-for, price card as aside */}
        <PublicPageHeader
          title={title}
          meta={
            category || tier || recommended ? (
              <div
                className="flex flex-wrap items-center gap-x-2.5 gap-y-2 text-sm text-gray-500"
                data-testid="detail-meta"
              >
                {category && <span className="font-medium capitalize text-gray-600">{category}</span>}
                {category && tier && <span aria-hidden="true" className="text-gray-300">•</span>}
                {tier && <span className="capitalize">{tier}</span>}
                {recommended && (
                  <span className="ml-0.5 inline-flex items-center gap-1 rounded-full bg-[var(--color-primary)] px-2.5 py-1 text-xs font-semibold uppercase tracking-[0.1em] text-white">
                    <LucideIcons.Zap size={11} strokeWidth={2} aria-hidden="true" />
                    High-Impact
                  </span>
                )}
              </div>
            ) : undefined
          }
          subtitle={summary || undefined}
          aside={
            priceFrom || headerAction ? (
              <div
                className="rounded-2xl border border-gray-200 bg-white p-7 shadow-[0_1px_2px_rgba(3,15,53,0.04),0_18px_40px_-20px_rgba(3,15,53,0.18)]"
                data-testid="price-card"
              >
                {priceFrom && (
                  <p className="text-3xl font-bold tracking-[-0.01em] text-[var(--color-primary)]">
                    {priceFrom}
                  </p>
                )}
                {timeline && <p className="mt-1 text-sm text-gray-500">Timeline: {timeline}</p>}
                {benefitLines.length > 0 && (
                  <>
                    <div className="my-6 h-px bg-gray-100" />
                    <ul className="space-y-3.5">
                      {benefitLines.map((b, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-sm leading-snug text-gray-700">
                          <LucideIcons.CheckCircle2
                            size={18}
                            strokeWidth={1.75}
                            className="mt-px shrink-0 text-[var(--color-secondary)]"
                            aria-hidden="true"
                          />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  </>
                )}
                {headerAction && (
                  <button
                    type="button"
                    onClick={() => dispatchAction(headerAction, entityType, entityId)}
                    className="mt-7 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[var(--color-primary)] px-6 py-3.5 text-sm font-semibold text-white shadow-sm transition hover:opacity-90 focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
                    data-testid="header-primary-action"
                  >
                    {headerAction.label}
                    <LucideIcons.ArrowRight size={16} strokeWidth={2} aria-hidden="true" />
                  </button>
                )}
              </div>
            ) : undefined
          }
        >
          {idealFor && (
            <p className="mt-6 flex items-start gap-2 text-sm text-gray-500">
              <LucideIcons.Users
                size={15}
                strokeWidth={1.5}
                className="mt-0.5 shrink-0 text-gray-400"
                aria-hidden="true"
              />
              <span>
                <span className="font-medium text-gray-700">Ideal for: </span>
                {idealFor}
              </span>
            </p>
          )}
        </PublicPageHeader>

        {/* Editorial tabbed body — full width, white (distinct from the gray hero) */}
        <section className="border-t border-gray-200 bg-white px-5 py-12 md:px-8 lg:px-10">
          <div className="max-w-[1200px] mx-auto">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList aria-label="Service detail tabs">
                {tabs.map((tab) => (
                  <TabsTrigger key={tab.id} value={tab.id}>
                    {tab.label}
                  </TabsTrigger>
                ))}
              </TabsList>
              {tabs.map((tab) => (
                // Consistent min-height so switching tabs doesn't jump the page.
                <TabsContent key={tab.id} value={tab.id} className="mt-8 min-h-[22rem]">
                  {renderMarketingTab(tab.id)}
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>

        {/* Related services */}
        {showRelated && (
          <RelatedServices
            entityType={entityType}
            entityId={entityId}
            category={category}
            {...(priceFromField !== undefined && { priceFromField })}
            {...(timelineField !== undefined && { timelineField })}
            {...(onNavigate !== undefined && { onNavigate })}
          />
        )}

        {/* Dark CTA band */}
        {ctaBand && (
          <LandingCta
            headline={ctaBand.headline}
            {...(ctaBand.headlineAccent !== undefined && { headlineAccent: ctaBand.headlineAccent })}
            {...(ctaBand.body !== undefined && { body: ctaBand.body })}
            {...(ctaBand.primaryCta !== undefined && { primaryCta: ctaBand.primaryCta })}
            {...(ctaBand.secondaryCta !== undefined && { secondaryCta: ctaBand.secondaryCta })}
          />
        )}
      </>
    );
  }

  const statusBadgeField = badgeFields.find((bf) => bf.field === "status") ?? badgeFields[0];
  const statusValue = statusBadgeField && data ? appData[statusBadgeField.field] : undefined;

  return (
    <main className="pb-8" aria-label={`${title} detail`}>
      <div className="pt-4">

        {/* ── N36 compact title row — record name + status badge, primary action
             right-aligned on the same line. Replaces the old floating action
             button + Details-card-only title (breadcrumb terminal already
             carries the name via useBreadcrumbOverride above). ── */}
        {suppressHeader && (
          <div className="mb-4 flex items-center justify-between gap-4" data-testid="detail-title-row">
            <div className="flex min-w-0 items-center gap-3">
              <h2
                className="truncate text-lg font-bold leading-tight text-[var(--color-primary)] md:text-xl"
                data-testid="detail-title"
              >
                {title}
              </h2>
              {statusValue != null && statusValue !== "" && (
                <Badge tone="gray">{String(statusValue)}</Badge>
              )}
            </div>
            {titleRowAction && (
              <Button
                variant="navy"
                className="shrink-0"
                onClick={titleRowAction.onClick}
                data-testid="detail-title-row-action"
              >
                {titleRowAction.label}
              </Button>
            )}
          </div>
        )}

        {/* ── Page header — omitted when suppressHeader=true (layout owns the PageHeader) ── */}
        {!suppressHeader && (
          <header className="mb-6" data-testid="detail-header">
            {breadcrumb && breadcrumb.length > 0 && (
              <div className="mb-3">
                <Breadcrumb
                  items={[...breadcrumb, { label: title }]}
                  onNavigate={(href) => { if (href) onNavigate?.(href); }}
                />
              </div>
            )}
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div className="min-w-0 flex-1">
                <h1
                  className="text-3xl font-bold leading-tight tracking-[-0.02em] text-[var(--color-primary)] md:text-4xl"
                  data-testid="detail-title"
                >
                  {title}
                </h1>
                {summary && (
                  <p className="mt-3 max-w-3xl text-sm leading-relaxed text-gray-500 md:text-base">
                    {summary}
                  </p>
                )}
                <HeaderBadgeRow badgeFields={badgeFields} data={data} />
              </div>

              {/* Primary CTA — promotes the first navy rail action into the header */}
              {headerAction && (
                <div className="shrink-0 lg:pt-1">
                  {(() => {
                    const Icon = resolveIcon(headerAction.icon);
                    return (
                      <button
                        type="button"
                        onClick={() => dispatchAction(headerAction, entityType, entityId)}
                        className="inline-flex items-center gap-2 rounded-md bg-[var(--color-primary)] px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90 focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
                        data-testid="header-primary-action"
                      >
                        <Icon size={15} strokeWidth={1.5} aria-hidden="true" />
                        {headerAction.label}
                      </button>
                    );
                  })()}
                </div>
              )}
            </div>
          </header>
        )}

        {/* ── 8/4 detail grid ─────────────────────────────────────────── */}
        <DetailPageGrid content={contentColumn} rail={railColumn} />

      </div>
    </main>
  );
}

/* ─────────────────────────────────────────────────────────────────────────── */
/*  Public export — config-first entry point                                    */
/* ─────────────────────────────────────────────────────────────────────────── */

/**
 * MarketplaceItemDetail (APP.F11)
 *
 * Default (ops) render: editorial detail layout (header + overview/deliverables +
 * optional media + optional action rail). Layout mode is data-driven:
 * text-only / text+action / text+action+media.
 *
 * Marketing variant: unchanged light public marketplace layout.
 *
 * Public props + Zod config are stable for the scaffold generator.
 */
export default function MarketplaceItemDetail(
  props: MarketplaceItemDetailProps,
) {
  const {
    entityId,
    onNavigate,
    detailVariant,
    suppressHeader,
    titleRowAction,
    ...configProps
  } = props;

  const parsed = MarketplaceItemDetailConfig.safeParse(configProps);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="MarketplaceItemDetail — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <MarketplaceItemDetailInner
      entityId={entityId}
      {...(onNavigate !== undefined && { onNavigate })}
      {...(detailVariant !== undefined && { detailVariant })}
      {...(suppressHeader !== undefined && { suppressHeader })}
      {...(titleRowAction !== undefined && { titleRowAction })}
      {...parsed.data}
    />
  );
}
