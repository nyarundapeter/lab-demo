import { z } from "zod";

/* ─── Badge field ─────────────────────────────────────────────────────────── */

/**
 * BadgeFieldDef — a field rendered as a badge chip in the detail page header.
 *
 * `style`:
 *   - "pill"  — rounded-full, rendered using @dbp/ui Badge (tone="gray" by default)
 *   - "mono"  — rounded-full, mono font, uppercase tracking (version badges)
 *   - "lock"  — rendered as Lock icon + label (controlled/mandatory indicator)
 */
const BadgeFieldDef = z.object({
  field: z.string().min(1),
  style: z.enum(["pill", "mono", "lock"]),
});

/* ─── Tab definition ──────────────────────────────────────────────────────── */

const TabDef = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
});

/* ─── Rail action ─────────────────────────────────────────────────────────── */

/**
 * RailActionDef — an action rendered as a RailActionButton in the right rail.
 * Dispatches a `dbp:marketplace-item-detail:action` CustomEvent on click,
 * carrying `{ id, entityType, entityId }`.
 */
const RailActionDef = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  /** Optional lucide icon name, e.g. "CheckSquare", "Link2", "Play". */
  icon: z.string().optional(),
  /**
   * Tone for the RailActionButton:
   *   "outline" (default), "navy" (filled dark), "ghost" (text-only).
   */
  tone: z.enum(["outline", "navy", "ghost"]).optional(),
});

/* ─── Acknowledgement config ──────────────────────────────────────────────── */

const AcknowledgementDef = z.object({
  /** When true, a full-width navy "Acknowledge" button is rendered in the rail. */
  required: z.boolean(),
  /** Button label text. */
  label: z.string().min(1),
});

/* ─── Governance action ───────────────────────────────────────────────────── */

/**
 * GovernanceActionDef — an action in the Governance Actions rail section AND
 * also referenced in the Governance tab for additional context.
 */
const GovernanceActionDef = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  /** Optional lucide icon name. */
  icon: z.string().optional(),
  /**
   * Tone for the RailActionButton:
   *   "outline" (default), "navy", "ghost".
   */
  tone: z.enum(["outline", "navy", "ghost"]).optional(),
});

/* ─── Breadcrumb crumb ────────────────────────────────────────────────────── */

const BreadcrumbCrumb = z.object({
  label: z.string().min(1),
  href: z.string().min(1),
});

/* ─── CTA band (dark footer call-to-action) ───────────────────────────────── */

/**
 * CtaBandDef — dark "Not sure if this is the right fit?" band rendered at the
 * bottom of the "marketing" detail variant via the @dbp/ui LandingCta component.
 */
const CtaBandDef = z.object({
  headline: z.string().min(1),
  headlineAccent: z.string().optional(),
  body: z.string().optional(),
  primaryCta: z.object({ label: z.string().min(1), href: z.string().min(1) }).optional(),
  secondaryCta: z.object({ label: z.string().min(1), href: z.string().min(1) }).optional(),
});

/* ─── Root config schema ──────────────────────────────────────────────────── */

export const MarketplaceItemDetailConfig = z.object({
  /**
   * The entity type served by PS.DATA (e.g. "knowledge-asset", "service", "task-template").
   * Used for the PS.DATA fetch and the CustomEvent payload.
   */
  entityType: z.string().min(1),

  /**
   * Field name whose value is used as the page h1 title.
   * Defaults to "name". Must resolve to a non-empty string in the fetched record.
   */
  titleField: z.string().min(1).default("name"),

  /**
   * Field name whose value is used as the subtitle paragraph below the h1.
   * Required — must resolve to a non-empty string in the fetched record.
   */
  summaryField: z.string().min(1),

  /**
   * Optional breadcrumb ancestors shown above the title.
   * The current item title is auto-appended as the last (non-linked) crumb.
   * Omit → no breadcrumb rendered.
   */
  breadcrumb: z.array(BreadcrumbCrumb).optional(),

  /**
   * Badge chips rendered in the header below the title/summary.
   * Each badge reads a field value from the fetched record.
   */
  badgeFields: z.array(BadgeFieldDef).default([]),

  /**
   * Tab strip configuration.
   * Defaults: Overview, Governance, Resources are recommended but caller-supplied.
   */
  tabs: z.array(TabDef).min(1).default([
    { id: "overview", label: "Overview" },
    { id: "governance", label: "Governance" },
    { id: "resources", label: "Resources" },
  ]),

  /**
   * Right-rail "Use in Work" action buttons (outline tone by default).
   * Omit → the "Use in Work" rail section is not rendered.
   */
  railActions: z.array(RailActionDef).optional(),

  /**
   * Acknowledgement rail section.
   * When `required: true`, a navy full-width button is shown in the rail.
   * Omit → the Acknowledgement section is not rendered.
   */
  acknowledgement: AcknowledgementDef.optional(),

  /**
   * Governance actions rendered both in the right rail "Governance Actions" section
   * and referenced in the Governance tab. Ghost tone by default.
   * Omit → neither the rail section nor governance tab content is rendered.
   */
  governanceActions: z.array(GovernanceActionDef).optional(),

  /**
   * Marketing-variant: entity field containing a display price string
   * (e.g. "From $1,000"). Rendered in the right-hand price card.
   * Only used when the component is rendered with detailVariant="marketing".
   */
  priceFromField: z.string().optional(),

  /**
   * Marketing-variant: entity field containing a timeline string (e.g. "2 Weeks").
   */
  timelineField: z.string().optional(),

  /**
   * Marketing-variant: entity field for the italic "Ideal for:" line.
   */
  idealForField: z.string().optional(),

  /**
   * Marketing-variant: entity field holding a string[] of outcomes. The first
   * three render as benefit ticks in the price card; if 4+ exist they also
   * render as a numbered "Key Outcomes" grid in the overview tab. Each entry
   * may be "Title|Description" or just "Title".
   */
  outcomesField: z.string().optional(),

  /**
   * Marketing-variant: when true, a "Related Services" row of up to 3 cards is
   * fetched (same entityType, same category as the current item) and shown
   * below the tabs. Defaults to false.
   */
  showRelated: z.boolean().default(false),

  /**
   * Marketing-variant: dark CTA band rendered at the very bottom of the page
   * (via @dbp/ui LandingCta). Omit → no band.
   */
  ctaBand: CtaBandDef.optional(),
});

/** The fully-parsed config (all defaults applied). */
export type MarketplaceItemDetailConfig = z.infer<typeof MarketplaceItemDetailConfig>;

/** The raw input shape — fields with defaults are optional. Use this for prop types. */
export type MarketplaceItemDetailConfigInput = z.input<typeof MarketplaceItemDetailConfig>;
export type BadgeFieldDef = z.infer<typeof BadgeFieldDef>;
export type TabDef = z.infer<typeof TabDef>;
export type RailActionDef = z.infer<typeof RailActionDef>;
export type AcknowledgementDef = z.infer<typeof AcknowledgementDef>;
export type GovernanceActionDef = z.infer<typeof GovernanceActionDef>;
export type BreadcrumbCrumb = z.infer<typeof BreadcrumbCrumb>;
export type CtaBandDef = z.infer<typeof CtaBandDef>;
