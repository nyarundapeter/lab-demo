# @dbp/organisms/marketplace-item-detail

**registryId:** `APP.F11`

Marketplace listing detail: badges, tabs, rail actions, acknowledgements, governance actions, CTA band.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`MarketplaceItemDetailConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `collection-marketplace-detail` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/marketplace-item-detail` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
