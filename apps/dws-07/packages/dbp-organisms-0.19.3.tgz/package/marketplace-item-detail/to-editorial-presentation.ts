// Local patch — see editorial-types.ts for why this file exists.

import type { EditorialPresentation, EditorialRailAction } from "./editorial-types.js";

interface ToEditorialPresentationConfig {
  entityType?: string;
  titleField?: string;
  summaryField?: string;
  breadcrumb?: unknown;
  badgeFields?: string[];
  tabs?: unknown;
  railActions?: EditorialRailAction[];
  acknowledgement?: unknown;
  governanceActions?: unknown;
  priceFromField?: string;
  timelineField?: string;
  idealForField?: string;
  outcomesField?: string;
  showRelated?: boolean;
  ctaBand?: unknown;
  [key: string]: unknown;
}

interface ToEditorialPresentationOptions {
  titleRowAction?: { id: string; label: string };
  updatedAt?: string;
  [key: string]: unknown;
}

export function toEditorialPresentation(
  appData: Record<string, unknown> | null | undefined,
  config: ToEditorialPresentationConfig,
  options: ToEditorialPresentationOptions = {},
): { presentation: EditorialPresentation } {
  const data = appData ?? {};

  const badges = (config.badgeFields ?? [])
    .map((field) => data[field])
    .filter((value) => value !== undefined && value !== null && value !== "");

  const railActions = config.railActions ?? [];

  const presentation: EditorialPresentation = {
    title: config.titleField ? (data[config.titleField] as string | undefined) : (data.name as string | undefined) ?? (data.title as string | undefined),
    summary: config.summaryField ? (data[config.summaryField] as string | undefined) : (data.summary as string | undefined),
    code: data.code as string | undefined,
    badges,
    headerMeta: undefined,
    updatedAtLabel: options.updatedAt ? new Date(options.updatedAt).toLocaleString() : undefined,
    media: undefined,
    showRail: railActions.length > 0,
    railActions,
    actionsTitle: undefined,
    actionsBlurb: undefined,
    overviewTitle: "Overview",
    overviewLead: undefined,
    overviewBody: config.summaryField ? (data[config.summaryField] as string | undefined) : undefined,
    detailsTitle: undefined,
    details: [],
    outcomesTitle: undefined,
    outcomes: [],
    documentsTitle: undefined,
    documents: [],
    documentsZipHref: undefined,
    governanceNote: undefined,
    readiness: undefined,
    relatedTitle: config.showRelated ? "Related" : undefined,
    related: [],
  };

  return { presentation };
}
