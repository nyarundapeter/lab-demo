import * as React from "react";
import { ChevronLeft, Mail, CheckCircle2, ArrowRight } from "lucide-react";
import { Alert, Button, FormField, Input, passwordPolicyItems, passwordScore, PolicyList, PwField, StrengthMeter } from "@dbp/ui";
import { ResetRequestFormConfig, type ResetRequestFormConfigInput } from "./types.js";

export interface ResetRequestFormProps {
  config: ResetRequestFormConfigInput;
  /** "request" mode: called once the email is validated. */
  onRequestReset?: (email: string) => void;
  /** "set" mode: called once the new password meets the policy and both fields match. */
  onSetPassword?: (input: { password: string }) => void;
  onBackToSignIn?: () => void;
  onContinueToSignIn?: () => void;
}

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

/**
 * ResetRequestForm — password-reset request + set-new-password screens in
 * one organism (task's "your call" on 1-vs-2 organisms). Port of
 * `identity-mfa.jsx`'s `ResetRequest`/`ResetForm`. `mode="request"` never
 * reveals whether the account exists; `mode="set"` blocks submit until the
 * password meets the policy and both fields match, reusing `@dbp/ui`'s
 * `PwField`/`StrengthMeter`/`PolicyList`. Meant to be mounted as the
 * `children` of `@dbp/ui/auth-layout`'s `AuthLayout`.
 */
export default function ResetRequestForm({
  config,
  onRequestReset,
  onSetPassword,
  onBackToSignIn,
  onContinueToSignIn,
}: ResetRequestFormProps) {
  const parsed = ResetRequestFormConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="ResetRequestForm — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return parsed.data.mode === "request" ? (
    <ResetRequestScreen onRequestReset={onRequestReset} onBackToSignIn={onBackToSignIn} />
  ) : (
    <ResetFormScreen targetEmail={parsed.data.targetEmail} onSetPassword={onSetPassword} onContinueToSignIn={onContinueToSignIn} />
  );
}

function ResetRequestScreen({
  onRequestReset,
  onBackToSignIn,
}: {
  onRequestReset?: ((email: string) => void) | undefined;
  onBackToSignIn?: (() => void) | undefined;
}) {
  const [email, setEmail] = React.useState("");
  const [error, setError] = React.useState<string | undefined>(undefined);
  const [sent, setSent] = React.useState(false);

  function submit() {
    if (!EMAIL_RE.test(email)) {
      setError("Enter a valid email address");
      return;
    }
    setError(undefined);
    setSent(true);
    onRequestReset?.(email);
  }

  if (sent) {
    return (
      <div className="flex flex-col gap-4 text-center" data-testid="reset-request-sent">
        <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-[var(--radius-card)] bg-[var(--color-success-surface)]">
          <Mail size={20} className="text-[var(--color-success)]" aria-hidden="true" />
        </span>
        <h1 className="text-lg font-semibold text-primary">Check your email</h1>
        <p className="text-sm text-[var(--color-text-muted)]">
          If an account exists for <strong className="text-primary">{email}</strong>, we&rsquo;ve sent a link to
          reset your password. It expires in 30 minutes.
        </p>
        <Button variant="outline" size="lg" onClick={() => setSent(false)} data-testid="reset-request-back">
          <ChevronLeft size={15} aria-hidden="true" />
          Back to sign in
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4" data-testid="reset-request">
      <h1 className="text-lg font-semibold text-primary">Reset your password</h1>
      <p className="text-sm text-[var(--color-text-muted)]">
        Enter the email associated with your account and we&rsquo;ll send you a reset link.
      </p>
      <FormField label="Email" required {...(error !== undefined && { error })}>
        <Input
          type="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setError(undefined);
          }}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder="you@company.com"
          data-testid="reset-request-email"
        />
      </FormField>
      <Button size="lg" className="w-full" onClick={submit} data-testid="reset-request-submit">
        Send reset link
      </Button>
      <Button variant="ghost" className="w-full" onClick={onBackToSignIn} data-testid="reset-request-back-link">
        <ChevronLeft size={15} aria-hidden="true" />
        Back to sign in
      </Button>
    </div>
  );
}

function ResetFormScreen({
  targetEmail,
  onSetPassword,
  onContinueToSignIn,
}: {
  targetEmail?: string | undefined;
  onSetPassword?: ((input: { password: string }) => void) | undefined;
  onContinueToSignIn?: (() => void) | undefined;
}) {
  const [password, setPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [done, setDone] = React.useState(false);
  const mismatch = !!confirm && confirm !== password;
  const score = passwordScore(password);
  const strong = score >= 3;
  const canSubmit = strong && !mismatch && !!confirm;

  if (done) {
    return (
      <div className="flex flex-col gap-4 text-center" data-testid="reset-form-done">
        <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-[var(--radius-card)] bg-[var(--color-success-surface)]">
          <CheckCircle2 size={20} className="text-[var(--color-success)]" aria-hidden="true" />
        </span>
        <h1 className="text-lg font-semibold text-primary">Password updated</h1>
        <p className="text-sm text-[var(--color-text-muted)]">
          Your password has been changed. For your security, all other sessions have been signed out.
        </p>
        <Button size="lg" className="w-full" onClick={onContinueToSignIn} data-testid="reset-form-continue">
          Continue to sign in
          <ArrowRight size={15} aria-hidden="true" />
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4" data-testid="reset-form">
      <h1 className="text-lg font-semibold text-primary">Choose a new password</h1>
      <p className="text-sm text-[var(--color-text-muted)]">
        Create a strong password{targetEmail ? ` for ${targetEmail}` : ""}.
      </p>
      <FormField label="New password" required>
        <PwField value={password} onChange={(e) => setPassword(e.target.value)} data-testid="reset-form-password" />
      </FormField>
      <StrengthMeter score={password ? score : undefined} />
      <PolicyList items={passwordPolicyItems(password)} />
      <FormField
        label="Confirm password"
        required
        {...(mismatch && { error: "Passwords don't match" })}
        {...(confirm && !mismatch && { message: "Passwords match", state: "success" as const })}
      >
        <PwField value={confirm} onChange={(e) => setConfirm(e.target.value)} data-testid="reset-form-confirm" />
      </FormField>
      <Button
        size="lg"
        className="w-full"
        disabled={!canSubmit}
        onClick={() => {
          setDone(true);
          onSetPassword?.({ password });
        }}
        data-testid="reset-form-submit"
      >
        Update password
      </Button>
    </div>
  );
}

export type { ResetRequestFormConfig, ResetRequestFormConfigInput, ResetRequestFormMode } from "./types.js";
