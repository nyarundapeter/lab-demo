import { z } from "zod";

export const ResetRequestFormMode = z.enum(["request", "set"]);
export type ResetRequestFormMode = z.infer<typeof ResetRequestFormMode>;

export const ResetRequestFormConfig = z.object({
  /** "request" = enter-your-email screen; "set" = choose-a-new-password screen (reset link already followed). */
  mode: ResetRequestFormMode.default("request"),
  /** "set" mode only — the account the reset link resolved to. */
  targetEmail: z.string().email().optional(),
});
export type ResetRequestFormConfig = z.infer<typeof ResetRequestFormConfig>;
export type ResetRequestFormConfigInput = z.input<typeof ResetRequestFormConfig>;
