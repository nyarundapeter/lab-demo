import React from "react";
import { Layers, Check } from "lucide-react";
import {
  Alert,
  Badge,
  Button,
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue,
  UnsavedChangesConfirmDialog,
  useUnsavedGuard,
  FullScreenModal,
  FullScreenModalContent,
  FullScreenModalBar,
  FullScreenModalTitle,
  FullScreenModalDescription,
  FullScreenModalBody,
  FullScreenModalMain,
  FullScreenModalRail,
  FullScreenModalFooter,
} from "@dbp/ui";
import { FullscreenBulkEditConfig, type FullscreenBulkEditConfigInput } from "./types.js";

export interface FullscreenBulkEditProps extends FullscreenBulkEditConfigInput {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApply?: (values: Record<string, string>) => void;
}

/**
 * APP.F61 — Fullscreen Bulk Edit
 *
 * Multi-field bulk-edit review — port of `overlay-fullscreen.jsx`'s
 * `FullScreenSurface` (`mode === 'bulk'`) / `BulkEdit`. Composition on top of
 * the existing `FullScreenModal` primitive. Owns the fields' local edit
 * state (a bulk edit is unsaved-until-applied, matching the reference's
 * `dirty` flag) and guards the close action with `useUnsavedGuard` +
 * `UnsavedChangesConfirmDialog`.
 */
export default function FullscreenBulkEdit(props: FullscreenBulkEditProps) {
  const { open, onOpenChange, onApply, ...config } = props;
  const parsed = FullscreenBulkEditConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <FullScreenModal open={open} onOpenChange={onOpenChange}>
        <FullScreenModalContent hideClose>
          <Alert tone="danger" title="FullscreenBulkEdit — invalid config" data-testid="config-error">
            <ul className="mt-1 list-disc pl-5">
              {parsed.error.issues.map((issue, i) => (
                <li key={i}>
                  {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
                  {issue.message}
                </li>
              ))}
            </ul>
          </Alert>
        </FullScreenModalContent>
      </FullScreenModal>
    );
  }

  return (
    <FullscreenBulkEditInner
      config={parsed.data}
      open={open}
      onOpenChange={onOpenChange}
      {...(onApply !== undefined && { onApply })}
    />
  );
}

function FullscreenBulkEditInner({
  config: c,
  open,
  onOpenChange,
  onApply,
}: {
  config: FullscreenBulkEditConfig;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApply?: (values: Record<string, string>) => void;
}) {
  const [values, setValues] = React.useState<Record<string, string>>({});
  const isDirty = Object.keys(values).length > 0;

  const guard = useUnsavedGuard({
    isDirty,
    onDiscard: () => onOpenChange(false),
  });

  const shownRecords = c.affectedRecords.slice(0, 6);
  const moreCount = (c.totalCount ?? c.affectedRecords.length) - shownRecords.length;

  return (
    <>
      <FullScreenModal open={open} onOpenChange={(next) => (next ? onOpenChange(true) : guard.requestClose())}>
        <FullScreenModalContent hideClose data-testid="fullscreen-bulk-edit">
          <FullScreenModalBar>
            <div className="flex min-w-0 items-center gap-2.5">
              <div className="min-w-0">
                <FullScreenModalDescription>{c.eyebrow}</FullScreenModalDescription>
                <FullScreenModalTitle>{c.title}</FullScreenModalTitle>
              </div>
              {isDirty && <Badge tone="warning">Unsaved changes</Badge>}
            </div>
          </FullScreenModalBar>

          <FullScreenModalBody>
            <FullScreenModalMain>
              <div className="flex flex-col gap-5 p-6">
                <Alert tone="info">
                  <span className="inline-flex items-center gap-1.5">
                    <Layers size={14} aria-hidden="true" />
                    {c.description}
                  </span>
                </Alert>
                <div className="grid max-w-[560px] grid-cols-2 gap-4">
                  {c.fields.map((f) => (
                    <label key={f.key} className="flex flex-col gap-1.5 text-sm">
                      <span className="font-medium">{f.label}</span>
                      <Select
                        value={values[f.key] ?? ""}
                        onValueChange={(v) => setValues((s) => ({ ...s, [f.key]: v }))}
                      >
                        <SelectTrigger aria-label={f.label}>
                          <SelectValue placeholder={f.placeholder} />
                        </SelectTrigger>
                        <SelectContent>
                          {f.options.map((o) => (
                            <SelectItem key={o} value={o}>
                              {o}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </label>
                  ))}
                </div>
              </div>
            </FullScreenModalMain>
            {c.affectedRecords.length > 0 && (
              <FullScreenModalRail>
                <div className="mb-3 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
                  Affected records
                </div>
                <div className="flex flex-col gap-2">
                  {shownRecords.map((r) => (
                    <div key={r.id} className="flex items-center gap-2 text-xs">
                      <Check size={12} className="shrink-0 text-[var(--color-success-text)]" aria-hidden="true" />
                      <span className="truncate text-[var(--color-text-muted)]">{r.label}</span>
                    </div>
                  ))}
                  {moreCount > 0 && (
                    <div className="pl-5 text-xs text-[var(--color-text-muted)]">…and {moreCount} more</div>
                  )}
                </div>
              </FullScreenModalRail>
            )}
          </FullScreenModalBody>

          <FullScreenModalFooter>
            <div className="flex-1" />
            <Button type="button" variant="outline" onClick={guard.requestClose}>
              Cancel
            </Button>
            <Button
              type="button"
              disabled={!isDirty}
              onClick={() => {
                onApply?.(values);
                onOpenChange(false);
              }}
            >
              {c.applyLabel}
            </Button>
          </FullScreenModalFooter>
        </FullScreenModalContent>
      </FullScreenModal>

      <UnsavedChangesConfirmDialog
        open={guard.confirmOpen}
        onOpenChange={guard.setConfirmOpen}
        title="Leave without applying?"
        description="Your bulk changes haven't been applied yet. Leaving now discards them."
        discardLabel="Discard changes"
        onDiscard={guard.confirmDiscard}
      />
    </>
  );
}
