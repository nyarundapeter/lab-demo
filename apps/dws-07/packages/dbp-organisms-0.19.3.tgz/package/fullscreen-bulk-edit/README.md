# @dbp/organisms/fullscreen-bulk-edit

**registryId:** `APP.F61`

Multi-field bulk-edit review — leave-unchanged-by-default field selects + affected-records
preview rail + an Apply action gated on at least one field being touched. See `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`FullscreenBulkEditConfig` — Zod schema exported from `types.ts` (source of truth). Component
props also take `open`/`onOpenChange` (controlled) and an optional `onApply` callback
(receives the touched field values, not part of the Zod config).

## Consumed by
Not yet wired — no caller mounts this organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/fullscreen-bulk-edit` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
