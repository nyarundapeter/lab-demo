import { z } from "zod";

const BulkEditFieldSchema = z.object({
  key: z.string().min(1),
  label: z.string().min(1),
  options: z.array(z.string().min(1)).min(1),
  /** @default "Leave unchanged" */
  placeholder: z.string().default("Leave unchanged"),
});
export type BulkEditField = z.infer<typeof BulkEditFieldSchema>;

const AffectedRecordSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
});
export type AffectedRecord = z.infer<typeof AffectedRecordSchema>;

export const FullscreenBulkEditConfig = z.object({
  eyebrow: z.string().default("Bulk action review"),
  title: z.string().min(1),
  description: z.string().min(1),
  fields: z.array(BulkEditFieldSchema).min(1),
  affectedRecords: z.array(AffectedRecordSchema).default([]),
  /** Total records affected, if larger than `affectedRecords` — shown as "…and N more". */
  totalCount: z.number().int().positive().optional(),
  /** e.g. "Apply to 12 requests". */
  applyLabel: z.string().min(1),
});

export type FullscreenBulkEditConfig = z.infer<typeof FullscreenBulkEditConfig>;
export type FullscreenBulkEditConfigInput = z.input<typeof FullscreenBulkEditConfig>;
