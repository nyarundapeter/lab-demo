import React from "react";
import { Plus, Copy, Check } from "lucide-react";
import { Alert, Badge, Button, Card, DestructiveConfirmDialog, FormField, Input } from "@dbp/ui";
import { TokensSectionConfig, type TokensSectionConfigInput, type ApiToken } from "./types.js";
import { createToken, revokeToken } from "./mock-tokens-client.js";

const EXPIRY_OPTIONS = [
  { value: "30", label: "30 days" },
  { value: "90", label: "90 days" },
  { value: "365", label: "1 year" },
  { value: "never", label: "No expiry" },
] as const;

/**
 * API tokens section — personal-access-token issuance. Create with explicit
 * scopes and expiry; the secret is shown exactly once on creation, then the
 * list keeps a masked prefix, scopes and last-used time. Port of
 * `identity-account.jsx`'s `TokensSection`.
 *
 * **Not wired to a real service.** `packages/stack/platform-services/auth`
 * has no API-token issuance/revocation code anywhere (confirmed by grep).
 * Create/revoke below call a typed mock client (`mock-tokens-client.ts`).
 * Storybook-only until that Layer-06 capability lands. See
 * `wave3-build-plan.md`'s "Blocked-row build policy" (Amendment A).
 */
export default function TokensSection(config: TokensSectionConfigInput) {
  const parsed = TokensSectionConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="TokensSection — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <TokensSectionInner config={parsed.data} />;
}

function TokensSectionInner({ config }: { config: TokensSectionConfig }) {
  const [tokens, setTokens] = React.useState<ApiToken[]>(config.tokens);
  const [creating, setCreating] = React.useState(false);
  const [name, setName] = React.useState("");
  const [scopes, setScopes] = React.useState<string[]>([config.scopeOptions[0]!.id]);
  const [expiry, setExpiry] = React.useState<(typeof EXPIRY_OPTIONS)[number]["value"]>("90");
  const [reveal, setReveal] = React.useState<string | null>(null);
  const [copied, setCopied] = React.useState(false);
  const [revokeTarget, setRevokeTarget] = React.useState<ApiToken | null>(null);
  const [busy, setBusy] = React.useState(false);

  function toggleScope(id: string) {
    setScopes((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  }

  async function create() {
    setBusy(true);
    const result = await createToken({
      name: name || "Untitled token",
      scopes,
      expiryDays: expiry === "never" ? "never" : Number(expiry),
    });
    setBusy(false);
    setTokens((t) => [result.token, ...t]);
    setReveal(result.secret);
    setCreating(false);
    setName("");
    setScopes([config.scopeOptions[0]!.id]);
  }

  async function confirmRevoke() {
    if (!revokeTarget) return;
    setBusy(true);
    await revokeToken(revokeTarget.id);
    setBusy(false);
    setTokens((t) => t.filter((x) => x.id !== revokeTarget.id));
    setRevokeTarget(null);
  }

  function copySecret() {
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  if (reveal) {
    return (
      <div className="max-w-[620px]">
        <SecHead title="Copy your new token" desc="This is the only time you'll see this secret. Store it somewhere safe." />
        <Alert tone="warning" title="You won't be able to see this again">
          If you lose it, revoke the token and create a new one.
        </Alert>
        <div className="mt-4 flex gap-2">
          <div className="flex flex-1 items-center overflow-auto rounded-[var(--radius-input)] border border-[var(--color-border-default)] bg-[var(--color-surface)] px-3 py-2.5 font-mono text-sm">
            {reveal}
          </div>
          <Button type="button" className="shrink-0" onClick={copySecret}>
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? "Copied" : "Copy"}
          </Button>
        </div>
        <Button type="button" variant="outline" className="mt-5" onClick={() => setReveal(null)}>
          Done — I&apos;ve saved it
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-[720px]">
      <div className="mb-5 flex items-end justify-between gap-4">
        <SecHead title="API tokens" desc="Personal tokens authenticate scripts and integrations as you." />
        {!creating && (
          <Button type="button" size="sm" className="shrink-0" onClick={() => setCreating(true)}>
            <Plus size={13} />
            Create token
          </Button>
        )}
      </div>

      {creating && (
        <Card className="mb-5 p-5 shadow-none">
          <div className="flex flex-col gap-4">
            <FormField label="Token name" required helperText="A name to remember where this token is used.">
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Zapier production"
                autoFocus
              />
            </FormField>
            <div>
              <div className="mb-1.5 text-xs font-medium">
                Scopes<span className="ml-0.5 text-danger">*</span>
              </div>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {config.scopeOptions.map((s) => (
                  <label
                    key={s.id}
                    className="flex cursor-pointer items-start gap-2 rounded-[var(--radius-input)] border border-[var(--color-border-default)] p-2.5 text-xs"
                    data-on={scopes.includes(s.id)}
                  >
                    <input type="checkbox" checked={scopes.includes(s.id)} onChange={() => toggleScope(s.id)} className="mt-0.5" />
                    <span>
                      <span className="font-mono font-semibold">{s.name}</span>
                      <div className="mt-0.5 text-xs text-[var(--color-text-muted)]">{s.desc}</div>
                    </span>
                  </label>
                ))}
              </div>
            </div>
            <FormField label="Expiry">
              <select
                className="h-9 rounded-[var(--radius-input)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-2.5 text-sm"
                value={expiry}
                onChange={(e) => setExpiry(e.target.value as typeof expiry)}
              >
                {EXPIRY_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </FormField>
            <div className="flex gap-2">
              <Button type="button" disabled={busy || !name || scopes.length === 0} onClick={create}>
                {busy ? "Creating…" : "Create token"}
              </Button>
              <Button type="button" variant="ghost" onClick={() => setCreating(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}

      <div className="overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border-default)]">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)] text-xs text-[var(--color-text-muted)]">
            <tr>
              <th className="px-3.5 py-2.5 font-medium">Name</th>
              <th className="px-3.5 py-2.5 font-medium">Token</th>
              <th className="px-3.5 py-2.5 font-medium">Scopes</th>
              <th className="px-3.5 py-2.5 font-medium">Last used</th>
              <th className="px-3.5 py-2.5 font-medium">Expires</th>
              <th className="px-3.5 py-2.5" />
            </tr>
          </thead>
          <tbody>
            {tokens.length === 0 && (
              <tr>
                <td colSpan={6} className="border-t border-[var(--color-border-subtle)] px-3.5 py-8 text-center text-xs text-[var(--color-text-muted)]" data-testid="tokens-empty-state">
                  No API tokens yet. Create one to authenticate a script or integration as yourself.
                </td>
              </tr>
            )}
            {tokens.map((t) => (
              <tr key={t.id} className={t.dead ? "opacity-60" : undefined} data-testid={`token-row-${t.id}`}>
                <td className="border-t border-[var(--color-border-subtle)] px-3.5 py-2.5 font-medium">{t.name}</td>
                <td className="border-t border-[var(--color-border-subtle)] px-3.5 py-2.5 font-mono text-xs text-[var(--color-text-muted)]">
                  {t.prefix}…••••
                </td>
                <td className="border-t border-[var(--color-border-subtle)] px-3.5 py-2.5">
                  <span className="flex flex-wrap gap-1">
                    {t.scopes.map((s) => (
                      <Badge key={s} tone="gray" className="font-mono text-xs">
                        {s}
                      </Badge>
                    ))}
                  </span>
                </td>
                <td className="border-t border-[var(--color-border-subtle)] px-3.5 py-2.5 text-[var(--color-text-muted)]">
                  {t.lastUsedLabel}
                </td>
                <td className="border-t border-[var(--color-border-subtle)] px-3.5 py-2.5 text-[var(--color-text-muted)]">
                  {t.expiresLabel}
                </td>
                <td className="border-t border-[var(--color-border-subtle)] px-3.5 py-2.5 text-right">
                  <Button
                    type="button"
                    variant="link"
                    className="h-auto text-xs font-medium text-danger"
                    onClick={() => setRevokeTarget(t)}
                  >
                    Revoke
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <DestructiveConfirmDialog
        open={revokeTarget !== null}
        onOpenChange={(open) => !open && setRevokeTarget(null)}
        title="Revoke this token?"
        description={
          revokeTarget
            ? `"${revokeTarget.name}" will stop working immediately. Anything using it will fail.`
            : ""
        }
        confirmLabel="Revoke token"
        busy={busy}
        onConfirm={confirmRevoke}
      />
    </div>
  );
}

function SecHead({ title, desc }: { title: string; desc?: string }) {
  return (
    <div>
      <h2 className="text-lg font-semibold">{title}</h2>
      {desc && <p className="mt-1 text-sm leading-relaxed text-[var(--color-text-muted)]">{desc}</p>}
    </div>
  );
}
