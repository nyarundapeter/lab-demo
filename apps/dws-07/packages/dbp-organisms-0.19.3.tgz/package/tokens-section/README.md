# @dbp/organisms/tokens-section

**registryId:** `APP.F76` (placeholder — assigned during central registration)

Personal API-token issuance/revocation. See `FEATURE.md` — **not wired to a real service**,
PS.AUTH has no token capability yet.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`TokensSectionConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — Storybook-only until PS.AUTH token issuance exists. Composed by `AccountArea`'s
"API tokens" tab.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/tokens-section` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
