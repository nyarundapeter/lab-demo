import { z } from "zod";

export const ApiTokenScopeOption = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  desc: z.string().min(1),
});
export type ApiTokenScopeOption = z.infer<typeof ApiTokenScopeOption>;

export const ApiToken = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  scopes: z.array(z.string().min(1)).min(1),
  createdLabel: z.string().min(1),
  lastUsedLabel: z.string().min(1),
  expiresLabel: z.string().min(1),
  /** Masked display prefix, e.g. "nw_live_ab12cd34". Never the full secret. */
  prefix: z.string().min(1),
  /** Expired/revoked — rendered dimmed. */
  dead: z.boolean().default(false),
});
export type ApiToken = z.infer<typeof ApiToken>;

export const TokensSectionConfig = z.object({
  tokens: z.array(ApiToken),
  scopeOptions: z.array(ApiTokenScopeOption).min(1),
});

export type TokensSectionConfig = z.infer<typeof TokensSectionConfig>;
export type TokensSectionConfigInput = z.input<typeof TokensSectionConfig>;
