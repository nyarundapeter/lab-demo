import { z } from "zod";

// Config schema for the @dbp/organisms/admin-user-list organism. Promoted
// from packages/shared/ui/src/components (2026-07-21 Bindings/Admin
// resolution — it owns useAdminUsers/useAdminUserRoles/useAssignUserRole/
// useRevokeUserRole fetch/mutation state, so it is an organism, not a
// design-system primitive).
export const AdminUserRow = z.object({
  id: z.string(),
  email: z.string(),
  displayName: z.string(),
  /** Baseline roles from the identity source (shown until PS.RBAC overrides load). */
  roles: z.array(z.string()).optional(),
  tenantId: z.string().optional(),
});

export const AdminUserListConfig = z.object({
  /** Fallback rows, used when PS.AUTH's GET /users is unsupported (501) or errors. */
  users: z.array(AdminUserRow).optional(),
});

export type AdminUserRow = z.infer<typeof AdminUserRow>;
export type AdminUserListConfig = z.infer<typeof AdminUserListConfig>;
