"use client"

import * as React from "react"
import { useQuery } from "@tanstack/react-query"
import { fetchMatrix, useAdminUserRoles, useAssignUserRole, useRevokeUserRole } from "@dbp/ps-rbac/client"
import { useAdminUsers } from "@dbp/ps-auth/client"
import { Badge, Button, EmptyState, SectionLabel, toast } from "@dbp/ui"
import type { AdminUserListConfig, AdminUserRow } from "./types.js"

/* ─── AdminUserList ──────────────────────────────────────────────────────
 * User Management (admin/users) — real identity + membership data, not a
 * generic demo entity. The user rows come from PS.AUTH's GET /users admin
 * endpoint (useAdminUsers) when the configured identity provider supports
 * enumeration; providers that can't enumerate (LDAP, Entra) 501, in which
 * case this falls back to the `users` prop — the same DEMO_IDENTITIES
 * fixture the auth route itself authenticates against. Role data is live
 * PS.RBAC: current assignments via GET /admin/users/:id/roles,
 * assignment/revocation via the real admin mutations (useAssignUserRole /
 * useRevokeUserRole), role options from GET /matrix.
 * ─────────────────────────────────────────────────────────────────────── */

export type AdminUserListProps = AdminUserListConfig;

export function AdminUserList({ users: fallbackUsers }: AdminUserListProps) {
  const { data: matrix } = useQuery({
    queryKey: ["ps-rbac", "admin", "users-page-matrix"],
    queryFn: fetchMatrix,
  })
  const { data: adminUsers } = useAdminUsers()
  const users = adminUsers ?? fallbackUsers ?? []

  if (users.length === 0) {
    return <EmptyState title="No users" description="No identities are provisioned for this environment." />
  }

  return (
    // Entity-list (APP.F01) table card treatment (DR-5/DR-1): white surface +
    // shadow-sm so the table reads as content, not chrome blending into the
    // muted canvas — see @dbp/organisms/entity-list's table wrapper.
    <div className="w-full overflow-x-auto rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-2)] shadow-[var(--shadow-sm)]">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]">
            <SectionLabel as="th" size="2xs" className="text-left font-mono px-4 py-3 whitespace-nowrap">User</SectionLabel>
            <SectionLabel as="th" size="2xs" className="text-left font-mono px-4 py-3 whitespace-nowrap">Email</SectionLabel>
            <SectionLabel as="th" size="2xs" className="text-left font-mono px-4 py-3 whitespace-nowrap">Tenant</SectionLabel>
            <SectionLabel as="th" size="2xs" className="text-left font-mono px-4 py-3 whitespace-nowrap">Roles</SectionLabel>
            <SectionLabel as="th" size="2xs" className="text-left font-mono px-4 py-3 whitespace-nowrap">Assign role</SectionLabel>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <UserRow key={user.id} user={user} allRoles={matrix?.roles ?? []} />
          ))}
        </tbody>
      </table>
    </div>
  )
}

function UserRow({ user, allRoles }: { user: AdminUserRow; allRoles: Array<{ id: string; label: string }> }) {
  const { data: assigned } = useAdminUserRoles(user.id)
  const assign = useAssignUserRole()
  const revoke = useRevokeUserRole()
  const [pendingRole, setPendingRole] = React.useState("")

  // PS.RBAC assignments when loaded; identity-source baseline roles otherwise.
  const rbacRoleIds = assigned?.roles.map((r) => r.roleId)
  const effectiveRoles = rbacRoleIds && rbacRoleIds.length > 0 ? rbacRoleIds : (user.roles ?? [])
  const fromRbac = Boolean(rbacRoleIds && rbacRoleIds.length > 0)
  const assignable = allRoles.filter((r) => !effectiveRoles.includes(r.id))

  return (
    <tr className="border-b border-[var(--color-border-subtle)] last:border-0 align-top">
      <td className="px-4 py-2.5 font-medium text-[var(--color-text-primary)]">{user.displayName}</td>
      <td className="px-4 py-2.5 text-[var(--color-text-secondary)]">{user.email}</td>
      <td className="px-4 py-2.5 text-[var(--color-text-secondary)]">{user.tenantId ?? "—"}</td>
      <td className="px-4 py-2.5">
        <span className="flex flex-wrap gap-1.5">
          {effectiveRoles.length === 0 ? (
            <span className="text-[var(--color-text-secondary)]">No roles</span>
          ) : (
            effectiveRoles.map((roleId) => (
              <Badge key={roleId} tone={roleId.includes("admin") ? "info" : "gray"}>
                {roleId}
                {fromRbac ? (
                  // deliberate keep: bare "×" glyph inline inside a Badge chip — Button's min height/padding don't fit this footprint
                  <button
                    type="button"
                    aria-label={`Revoke ${roleId} from ${user.displayName}`}
                    className="ml-1 opacity-60 hover:opacity-100"
                    onClick={() =>
                      revoke.mutate(
                        { userId: user.id, roleId },
                        {
                          onSuccess: () => toast({ title: `Revoked ${roleId} from ${user.displayName}` }),
                          onError: (err) => toast({ title: "Revoke failed", description: err instanceof Error ? err.message : String(err), tone: "danger" }),
                        },
                      )
                    }
                  >
                    ×
                  </button>
                ) : null}
              </Badge>
            ))
          )}
        </span>
      </td>
      <td className="px-4 py-2.5">
        <span className="flex items-center gap-2">
          <select
            aria-label={`Role to assign to ${user.displayName}`}
            className="h-8 rounded border border-[var(--color-border-default)] bg-[var(--color-surface)] px-2 text-sm text-[var(--color-text-primary)] focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
            value={pendingRole}
            onChange={(e) => setPendingRole(e.target.value)}
          >
            <option value="">Select role…</option>
            {assignable.map((r) => (
              <option key={r.id} value={r.id}>{r.label}</option>
            ))}
          </select>
          <Button
            size="sm"
            variant="outline"
            disabled={pendingRole === "" || assign.isPending}
            onClick={() =>
              assign.mutate(
                { userId: user.id, roleId: pendingRole },
                {
                  onSuccess: () => {
                    toast({ title: `Assigned ${pendingRole} to ${user.displayName}` })
                    setPendingRole("")
                  },
                  onError: (err) => toast({ title: "Assign failed", description: err instanceof Error ? err.message : String(err), tone: "danger" }),
                },
              )
            }
          >
            Assign
          </Button>
        </span>
      </td>
    </tr>
  )
}

export type { AdminUserListConfig, AdminUserRow } from "./types.js";
