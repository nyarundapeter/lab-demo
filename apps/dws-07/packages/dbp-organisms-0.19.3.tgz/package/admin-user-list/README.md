# @dbp/organisms/admin-user-list

**registryId:** `APP.F31`

PS.AUTH admin user list with live PS.RBAC role assignment/revocation per row.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`AdminUserListConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Bespoke import — `apps/dbp/app/(authenticated)/admin/users/page.tsx`.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/admin-user-list` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
