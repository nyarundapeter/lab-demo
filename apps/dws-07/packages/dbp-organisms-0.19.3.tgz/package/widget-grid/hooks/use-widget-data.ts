import { useQuery } from "@tanstack/react-query";
import { listAllEntities } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { Widget } from "../types.js";

export interface WidgetDataResult {
  rows: EntityRecord<EntityData>[];
  isLoading: boolean;
  error: Error | null;
}

/**
 * Fetches the entity rows for a single widget from PS.DATA.
 *
 * NOTE — client-side aggregation:
 * PS.DATA exposes a flat entity store with no server-side aggregate endpoint.
 * Widgets page through all available rows (up to 2000) using MAX_PAGE_SIZE (200)
 * per request and compute count/sum/avg entirely in the browser.
 * A future PS.DATA aggregate endpoint can replace this without changing the widget contract.
 */
export function useWidgetData(widget: Widget): WidgetDataResult {
  const query = useQuery({
    queryKey: ["ps-data", "all-entities", widget.entityType, widget.filters ?? {}],
    queryFn: () => listAllEntities(widget.entityType, { ...(widget.filters !== undefined && { filters: widget.filters }) }),
  });

  return {
    rows: query.data?.rows ?? [],
    isLoading: query.isLoading,
    error: query.error as Error | null,
  };
}
