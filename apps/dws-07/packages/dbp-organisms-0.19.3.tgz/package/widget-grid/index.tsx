import * as React from "react";
import { Alert } from "@dbp/ui";
import { WidgetGridConfig } from "./types.js";
import { WidgetRenderer } from "./components/widget-renderer.js";

type ConfigInput = Omit<WidgetGridConfig, "columns"> & Partial<Pick<WidgetGridConfig, "columns">>;

/**
 * ANL.F01 — Dashboard Widget Grid
 *
 * Receives CONFIG, never data. Each widget independently fetches its entity
 * rows via PS.DATA (useEntityList). Client-side aggregation is applied per
 * widget type (count/sum/avg). See FEATURE.md for the aggregation-client-side
 * limitation notice.
 *
 * Config is validated at render time via WidgetGridConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 *
 * Widget failures are isolated — one widget erroring does not affect siblings.
 */
export default function WidgetGrid(rawConfig: ConfigInput) {
  const parseResult = WidgetGridConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="WidgetGrid configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const config = parseResult.data;

  return <WidgetGridInner config={config} />;
}

// Re-export the config type so consumers can import it from the root.
export type { WidgetGridConfig } from "./types.js";
export type { Widget, MetricConfig, ChartConfig, ListConfig } from "./types.js";

// ─── Inner component (config is guaranteed valid here) ────────────────────────

interface WidgetGridInnerProps {
  config: WidgetGridConfig;
}

function WidgetGridInner({ config }: WidgetGridInnerProps) {
  const { columns, widgets } = config;

  // CSS grid column template — capped at the configured column count.
  const gridStyle: React.CSSProperties = {
    display: "grid",
    gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
    gap: "1rem",
  };

  return (
    <div
      style={gridStyle}
      className="w-full"
      data-testid="widget-grid"
      data-columns={columns}
    >
      {widgets.map((widget) => {
        // Clamp span to available columns.
        const span = Math.min(widget.span ?? 1, columns);
        return (
          <div
            key={widget.id}
            style={{ gridColumn: span > 1 ? `span ${span} / span ${span}` : undefined }}
            data-testid={`widget-cell-${widget.id}`}
            data-span={span}
          >
            <WidgetRenderer widget={widget} />
          </div>
        );
      })}
    </div>
  );
}
