import * as React from "react";
import type { Widget } from "../types.js";
import { useWidgetData } from "../hooks/use-widget-data.js";
import { MetricWidget } from "./metric-widget.js";
import { BarWidget } from "./bar-widget.js";
import { LineWidget } from "./line-widget.js";
import { PieWidget } from "./pie-widget.js";
import { ListWidget } from "./list-widget.js";

interface WidgetRendererProps {
  widget: Widget;
}

/**
 * Fetches data for a single widget and delegates rendering to the
 * type-specific component. Failures are isolated — this component
 * never throws; the per-type component receives the error via props.
 */
export function WidgetRenderer({ widget }: WidgetRendererProps) {
  const { rows, isLoading, error } = useWidgetData(widget);

  switch (widget.type) {
    case "metric":
      return (
        <MetricWidget widget={widget} rows={rows} isLoading={isLoading} error={error} />
      );
    case "bar":
      return (
        <BarWidget widget={widget} rows={rows} isLoading={isLoading} error={error} />
      );
    case "line":
      return (
        <LineWidget widget={widget} rows={rows} isLoading={isLoading} error={error} />
      );
    case "pie":
      return (
        <PieWidget widget={widget} rows={rows} isLoading={isLoading} error={error} />
      );
    case "list":
      return (
        <ListWidget widget={widget} rows={rows} isLoading={isLoading} error={error} />
      );
  }
}
