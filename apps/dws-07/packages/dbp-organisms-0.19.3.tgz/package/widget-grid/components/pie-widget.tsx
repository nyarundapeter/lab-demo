import * as React from "react";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { Widget } from "../types.js";
import { PieChart } from "../../chart-panel/components/pie-chart.js";
import { aggregateByCategory } from "./aggregation.js";
import { getChartPalette } from "./chart-colors.js";
import { WidgetCard } from "./widget-card.js";

interface PieWidgetProps {
  widget: Extract<Widget, { type: "pie" }>;
  rows: EntityRecord<EntityData>[];
  isLoading: boolean;
  error: Error | null;
}

export function PieWidget({ widget, rows, isLoading, error }: PieWidgetProps) {
  const data = React.useMemo(
    () =>
      aggregateByCategory(
        rows,
        widget.chart.categoryField,
        widget.chart.valueField,
        widget.chart.aggregate ?? "sum",
        widget.chart.limit ?? 6,
      ),
    [rows, widget.chart],
  );

  const palette = React.useMemo(() => getChartPalette(), []);

  return (
    <WidgetCard
      title={widget.title}
      isLoading={isLoading}
      error={error}
      empty={data.length === 0}
      testId={`widget-pie-${widget.id}`}
    >
      <PieChart
        data={data.map((d) => ({ name: d.category, value: d.value }))}
        palette={palette}
        showLegend
        legendFormat="plain"
        legendFontSize={10}
        outerRadius={60}
        height={192}
        testId={`chart-container-${widget.id}`}
      />
    </WidgetCard>
  );
}
