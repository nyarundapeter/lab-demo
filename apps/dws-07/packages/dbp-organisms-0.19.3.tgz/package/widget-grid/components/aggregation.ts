import type { EntityData, EntityRecord } from "@dbp/ps-data/client";

type AggregateOp = "count" | "sum" | "avg";

/**
 * Computes count / sum / avg of a numeric field across the provided rows.
 * Non-numeric values are coerced to 0 (rather than NaN) so a partially-typed
 * entity does not corrupt the result.
 */
export function aggregate(
  rows: EntityRecord<EntityData>[],
  field: string,
  op: AggregateOp,
): number {
  if (op === "count") return rows.length;

  const nums = rows.map((r) => {
    const v = (r.data as Record<string, unknown>)[field];
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  });

  if (nums.length === 0) return 0;

  const total = nums.reduce((acc, n) => acc + n, 0);
  return op === "sum" ? total : total / nums.length;
}

/**
 * Groups rows by a category field and aggregates a value field per group.
 * Returns entries sorted descending by aggregated value, capped to `limit`.
 */
export function aggregateByCategory(
  rows: EntityRecord<EntityData>[],
  categoryField: string,
  valueField: string,
  op: AggregateOp = "sum",
  limit = 10,
): { category: string; value: number }[] {
  const groups = new Map<string, EntityRecord<EntityData>[]>();

  for (const row of rows) {
    const cat = String((row.data as Record<string, unknown>)[categoryField] ?? "");
    const existing = groups.get(cat);
    if (existing) {
      existing.push(row);
    } else {
      groups.set(cat, [row]);
    }
  }

  const entries: { category: string; value: number }[] = [];
  for (const [category, groupRows] of groups) {
    entries.push({ category, value: aggregate(groupRows, valueField, op) });
  }

  entries.sort((a, b) => b.value - a.value);
  return entries.slice(0, limit);
}

type FormatStyle = "number" | "currency" | "percent";

export function formatValue(value: number, style?: FormatStyle): string {
  switch (style) {
    case "currency":
      return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency: "USD",
        maximumFractionDigits: 0,
      }).format(value);
    case "percent":
      return new Intl.NumberFormat(undefined, {
        style: "percent",
        maximumFractionDigits: 1,
      }).format(value / 100);
    default:
      return new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value);
  }
}
