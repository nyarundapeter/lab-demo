import * as React from "react";
import { Separator } from "@dbp/ui";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { Widget } from "../types.js";
import { WidgetCard } from "./widget-card.js";

interface ListWidgetProps {
  widget: Extract<Widget, { type: "list" }>;
  rows: EntityRecord<EntityData>[];
  isLoading: boolean;
  error: Error | null;
}

export function ListWidget({ widget, rows, isLoading, error }: ListWidgetProps) {
  const limit = widget.list.limit ?? 5;
  const visibleRows = rows.slice(0, limit);

  return (
    <WidgetCard
      title={widget.title}
      isLoading={isLoading}
      error={error}
      empty={rows.length === 0}
      testId={`widget-list-${widget.id}`}
    >
      <ul className="flex flex-col gap-0" data-testid={`list-rows-${widget.id}`}>
        {visibleRows.map((row, idx) => {
          const data = row.data as Record<string, unknown>;
          const title = String(data[widget.list.titleField] ?? "");
          const subtitle = widget.list.subtitleField
            ? String(data[widget.list.subtitleField] ?? "")
            : null;

          return (
            <li key={row.id}>
              {idx > 0 && <Separator className="my-1" />}
              <div className="flex flex-col py-1">
                <span className="text-sm font-medium text-[var(--color-text)]">{title}</span>
                {subtitle && (
                  <span className="text-xs text-[var(--color-text)] opacity-60">{subtitle}</span>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </WidgetCard>
  );
}
