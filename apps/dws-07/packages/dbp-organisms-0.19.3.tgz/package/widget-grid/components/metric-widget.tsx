import * as React from "react";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import { StatTile } from "@dbp/ui";
import type { Widget } from "../types.js";
import { aggregate, formatValue } from "./aggregation.js";
import { WidgetCard } from "./widget-card.js";

interface MetricWidgetProps {
  widget: Extract<Widget, { type: "metric" }>;
  rows: EntityRecord<EntityData>[];
  isLoading: boolean;
  error: Error | null;
}

/**
 * Design-system de-dup Wave 1.F: value/caption now render via the canonical
 * `StatTile` (bare, label hidden) instead of hand-rolled divs. Accepted
 * delta: the caption drops its former mono/uppercase/tracked-letter-spacing
 * treatment for `StatTile`'s standard `subLabel` style (text-xs, no
 * uppercase) — content and test ids are unchanged.
 */
export function MetricWidget({ widget, rows, isLoading, error }: MetricWidgetProps) {
  const value = React.useMemo(
    () => aggregate(rows, widget.metric.field, widget.metric.aggregate),
    [rows, widget.metric.field, widget.metric.aggregate],
  );

  const formatted = React.useMemo(
    () => formatValue(value, widget.metric.format),
    [value, widget.metric.format],
  );

  return (
    <WidgetCard
      title={widget.title}
      isLoading={isLoading}
      error={error}
      empty={rows.length === 0}
      testId={`widget-metric-${widget.id}`}
    >
      {/*
       * Bare + hideLabel: WidgetCard already renders `widget.title` as its
       * own heading, so StatTile's overline label is visually hidden
       * (kept sr-only) here to avoid a duplicated title — the value/caption
       * typography is what's being reused (design-system de-dup Wave 1.F).
       */}
      <StatTile
        bare
        hideLabel
        label={widget.title}
        value={formatted}
        tone="primary"
        subLabel={`${widget.metric.aggregate} of ${widget.metric.field} · ${rows.length} records`}
        valueTestId={`metric-value-${widget.id}`}
        className="min-h-0 p-0"
      />
    </WidgetCard>
  );
}
