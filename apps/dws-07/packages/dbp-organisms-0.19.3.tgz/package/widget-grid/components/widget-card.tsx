import * as React from "react";
import { Skeleton, EmptyState } from "@dbp/ui";
import { Inbox } from "lucide-react";

interface WidgetCardProps {
  title: string;
  isLoading: boolean;
  error: Error | null;
  empty: boolean;
  children: React.ReactNode;
  testId?: string;
}

/**
 * Shared container for all widget types — provides title, loading skeleton,
 * error, and empty state. Each widget failure is self-contained: other widgets
 * in the grid are unaffected.
 */
export function WidgetCard({
  title,
  isLoading,
  error,
  empty,
  children,
  testId,
}: WidgetCardProps) {
  return (
    <div className="dq-card flex flex-col gap-3" data-testid={testId ?? "widget-card"}>
      <h3 className="dq-card-title">{title}</h3>

      {isLoading ? (
        <div role="status" aria-label="Loading" className="flex flex-col gap-2">
          <Skeleton className="h-8 w-1/2" />
          <Skeleton className="h-24 w-full" />
        </div>
      ) : error ? (
        <EmptyState
          tone="danger"
          headline="Failed to load"
          description={error.message}
          data-testid="widget-error"
          className="py-8"
        />
      ) : empty ? (
        <EmptyState
          icon={<Inbox size={22} strokeWidth={1.5} />}
          title="No data"
          data-testid="widget-empty"
          className="py-8"
        />
      ) : (
        children
      )}
    </div>
  );
}
