import * as React from "react";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { Widget } from "../types.js";
import { LineChart } from "../../chart-panel/components/line-chart.js";
import { aggregateByCategory } from "./aggregation.js";
import { getChartPalette } from "./chart-colors.js";
import { WidgetCard } from "./widget-card.js";

interface LineWidgetProps {
  widget: Extract<Widget, { type: "line" }>;
  rows: EntityRecord<EntityData>[];
  isLoading: boolean;
  error: Error | null;
}

export function LineWidget({ widget, rows, isLoading, error }: LineWidgetProps) {
  const data = React.useMemo(
    () =>
      aggregateByCategory(
        rows,
        widget.chart.categoryField,
        widget.chart.valueField,
        widget.chart.aggregate ?? "sum",
        widget.chart.limit ?? 10,
      ),
    [rows, widget.chart],
  );

  const palette = React.useMemo(() => getChartPalette(), []);

  return (
    <WidgetCard
      title={widget.title}
      isLoading={isLoading}
      error={error}
      empty={data.length === 0}
      testId={`widget-line-${widget.id}`}
    >
      <LineChart
        data={data}
        series={[{ dataKey: "value", name: widget.chart.valueField }]}
        palette={palette}
        height={160}
        tickFontSize={10}
        testId={`chart-container-${widget.id}`}
      />
    </WidgetCard>
  );
}
