/**
 * Re-exports the canonical chart color palette from `chart-panel` — see
 * that file for rationale. Consolidated in Wave 1.F (chart-primitive
 * dedup) after this feature and `chart-panel` had drifted to two
 * near-identical copies.
 */
export { getChartPalette } from "../../chart-panel/components/chart-colors.js";
