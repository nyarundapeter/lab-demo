import { z } from "zod";

// ─── Widget-level schemas ─────────────────────────────────────────────────────

const MetricConfigSchema = z.object({
  /** The entity data field to aggregate. */
  field: z.string().min(1),
  /** Aggregation function applied client-side to fetched rows. */
  aggregate: z.enum(["count", "sum", "avg"]),
  /** Number formatting applied to the computed value. */
  format: z.enum(["number", "currency", "percent"]).optional(),
});
export type MetricConfig = z.infer<typeof MetricConfigSchema>;

const ChartConfigSchema = z.object({
  /** The entity data field used for the x-axis / category. */
  categoryField: z.string().min(1),
  /** The entity data field to aggregate into the y-axis / value. */
  valueField: z.string().min(1),
  /** Aggregation function applied client-side per category. Defaults to sum. */
  aggregate: z.enum(["count", "sum", "avg"]).optional(),
  /** Limit the number of categories rendered (top-N by value). Defaults to 10. */
  limit: z.number().int().min(1).max(100).optional(),
});
export type ChartConfig = z.infer<typeof ChartConfigSchema>;

const ListConfigSchema = z.object({
  /** Entity data field used as the primary row title. */
  titleField: z.string().min(1),
  /** Entity data field used as the secondary row subtitle. */
  subtitleField: z.string().min(1).optional(),
  /** Maximum rows to display. Defaults to 5. */
  limit: z.number().int().min(1).max(50).optional(),
});
export type ListConfig = z.infer<typeof ListConfigSchema>;

// ─── Per-widget base ─────────────────────────────────────────────────────────

const WidgetBaseSchema = z.object({
  /** Stable identifier used as React key and for error isolation. */
  id: z.string().min(1),
  /** Human-readable widget heading. */
  title: z.string().min(1),
  /** PS.DATA entity type this widget queries. */
  entityType: z.string().min(1),
  /**
   * Grid column span (1–4). A widget spanning more columns than `columns`
   * is treated as spanning `columns`. Defaults to 1.
   */
  span: z.number().int().min(1).max(4).optional(),
  /**
   * Static field-equality filters forwarded to every PS.DATA request
   * for this widget.
   */
  filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
});

// ─── Discriminated widget union ──────────────────────────────────────────────
// NOTE: z.discriminatedUnion requires plain ZodObject members — do NOT wrap
// with .refine() / .superRefine() here (those produce ZodEffects, not ZodObject).
// The required-config fields (metric / chart / list) are already non-optional in
// the extend() call, which provides the same guarantee at the schema level.

const MetricWidgetSchema = WidgetBaseSchema.extend({
  type: z.literal("metric"),
  metric: MetricConfigSchema,
});

const BarWidgetSchema = WidgetBaseSchema.extend({
  type: z.literal("bar"),
  chart: ChartConfigSchema,
});

const LineWidgetSchema = WidgetBaseSchema.extend({
  type: z.literal("line"),
  chart: ChartConfigSchema,
});

const PieWidgetSchema = WidgetBaseSchema.extend({
  type: z.literal("pie"),
  chart: ChartConfigSchema,
});

const ListWidgetSchema = WidgetBaseSchema.extend({
  type: z.literal("list"),
  list: ListConfigSchema,
});

export const WidgetSchema = z.discriminatedUnion("type", [
  MetricWidgetSchema,
  BarWidgetSchema,
  LineWidgetSchema,
  PieWidgetSchema,
  ListWidgetSchema,
]);
export type Widget = z.infer<typeof WidgetSchema>;

// ─── Grid-level config ────────────────────────────────────────────────────────

/**
 * WidgetGridConfig — the single typed contract for ANL.F01.
 *
 * This is a DATA contract only (no function fields — Zod schemas are data-only).
 */
export const WidgetGridConfig = z.object({
  /**
   * Number of CSS grid columns in the layout (1–4). Widgets with a span
   * greater than this value are clamped to `columns`.
   * Defaults to 3.
   */
  columns: z.number().int().min(1).max(4).default(3),
  /** The set of widgets to render in grid order. At least one required. */
  widgets: z.array(WidgetSchema).min(1),
});
export type WidgetGridConfig = z.infer<typeof WidgetGridConfig>;
