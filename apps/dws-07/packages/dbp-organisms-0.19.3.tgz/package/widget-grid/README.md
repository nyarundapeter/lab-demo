# @dbp/organisms/widget-grid

**registryId:** `ANL.F01`

Config-driven dashboard widget grid; each widget (chart/list/kpi) fetches and errors independently.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`WidgetGridConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `analytics-dashboard` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/widget-grid` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
