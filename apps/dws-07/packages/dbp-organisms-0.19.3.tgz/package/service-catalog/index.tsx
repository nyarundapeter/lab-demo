"use client";
import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { listAllEntities } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import {
  CatalogCard,
  Checkbox,
  EmptyState,
  Grid,
  Col,
  Pagination,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  SectionLabel,
  Button,
  Skeleton,
} from "@dbp/ui";
import { ServiceCatalogConfig } from "./types.js";
import type {
  ServiceCatalogConfig as ServiceCatalogConfigType,
  ServiceCatalogTab,
} from "./types.js";

// Stable singleton so the `?? []` fallback doesn't itself defeat referential
// stability — a fresh `[]` literal on every render breaks the useMemo deps
// below (DEF-10, see @dbp/ps-data/client's own EMPTY_ROWS).
const EMPTY_ROWS: EntityRecord<EntityData>[] = [];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function readField(data: Record<string, unknown>, key: string | undefined): string {
  if (!key) return "";
  const v = data[key];
  return v == null ? "" : String(v);
}

function collectFacetValues(rows: EntityRecord<EntityData>[], fieldKey: string): string[] {
  const seen = new Set<string>();
  for (const r of rows) {
    const v = readField(r.data as Record<string, unknown>, fieldKey);
    if (v) seen.add(v);
  }
  return Array.from(seen).sort();
}

// ─── Props ────────────────────────────────────────────────────────────────────

type ConfigInput = Omit<ServiceCatalogConfigType, "pageSize" | "tabs" | "sharedFilters"> &
  Partial<Pick<ServiceCatalogConfigType, "pageSize" | "tabs" | "sharedFilters">>;

export interface ServiceCatalogProps extends ConfigInput {
  /** Called when a card is clicked. Receives (entityType, entityId). */
  onCardClick?: (entityType: string, id: string) => void;
}

// ─── Component ────────────────────────────────────────────────────────────────

/**
 * APP.F20 — Service Catalog
 *
 * A client-faceted, tab-isolated catalogue grid for browsable service or
 * offering catalogues. Fetches the full entity set up-front (no server
 * pagination), then filters and paginates client-side so tab and facet
 * selections operate across the entire dataset.
 *
 * Use when:
 *  - The full result set is ≤ 500 items.
 *  - Each tab represents a sub-market or category with independent filters.
 *  - Facet counts must reflect the full tab dataset, not just the current page.
 *
 * For large datasets where server-side pagination is required, use APP.F10
 * (CatalogGrid) instead.
 */
export default function ServiceCatalog(props: ServiceCatalogProps) {
  const parsed = ServiceCatalogConfig.safeParse(props);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    return (
      <EmptyState
        tone="danger"
        headline="ServiceCatalog config error"
        description={`APP.F20 received an invalid config. ${issues}`}
      />
    );
  }
  return (
    <ServiceCatalogInner
      config={parsed.data}
      {...(props.onCardClick ? { onCardClick: props.onCardClick } : {})}
    />
  );
}

// ─── Inner (validated config) ─────────────────────────────────────────────────

interface InnerProps {
  config: ServiceCatalogConfigType;
  onCardClick?: (entityType: string, id: string) => void;
}

function ServiceCatalogInner({ config, onCardClick }: InnerProps) {
  const { entityType, tabs, tabField, sharedFilters, cardFields, pageSize, filters, emptyState } =
    config;

  const hasTabs = tabs.length > 0;
  const firstTabId = hasTabs ? tabs[0]!.id : "__all__";

  const [activeTab, setActiveTab] = React.useState<string>(firstTabId);
  const [activeFilters, setActiveFilters] = React.useState<Record<string, Set<string>>>({});
  const [page, setPage] = React.useState(1);

  // Fetch the full set up-front (up to 2000 rows, MAX_PAGE_SIZE=200 per
  // request), then client-filter/paginate from there — same listAllEntities
  // pattern chart-panel/kpi-scorecard/widget-grid use. A single request for
  // pageSize:500 used to be issued here, which PS.DATA's server rejects
  // (its MAX_PAGE_SIZE is 200) with a permanent 400 "invalid pagination query".
  const query = useQuery({
    queryKey: ["ps-data", "all-entities", entityType, filters ?? {}],
    queryFn: () => listAllEntities(entityType, { ...(filters !== undefined && { filters }) }),
  });
  const allRows = query.data?.rows ?? EMPTY_ROWS;
  const isLoading = query.isLoading;
  const error = query.error as Error | null;

  // Reset filters + pagination when tab changes.
  const handleTabChange = React.useCallback((tabId: string) => {
    setActiveTab(tabId);
    setActiveFilters({});
    setPage(1);
  }, []);

  const currentTab: ServiceCatalogTab | undefined = tabs.find((t) => t.id === activeTab);

  // Tab-level filter: match by tabField === tab.id (short-hand) or explicit clientFilter map.
  const tabRows = React.useMemo(() => {
    if (!hasTabs) return allRows;
    if (!currentTab) return allRows;
    const { clientFilter } = currentTab;
    if (!clientFilter && tabField) {
      return allRows.filter((r) => {
        const v = readField(r.data as Record<string, unknown>, tabField);
        return v === currentTab.id;
      });
    }
    if (clientFilter) {
      return allRows.filter((r) => {
        const d = r.data as Record<string, unknown>;
        return Object.entries(clientFilter).every(([k, v]) => {
          const rv = d[k];
          return rv === v || String(rv) === String(v);
        });
      });
    }
    return allRows;
  }, [allRows, hasTabs, currentTab, tabField]);

  // Apply shared checkbox filters on top of tab rows.
  const filtered = React.useMemo(() => {
    let out = tabRows;
    for (const [f, vals] of Object.entries(activeFilters)) {
      if (vals.size === 0) continue;
      out = out.filter((r) => vals.has(readField(r.data as Record<string, unknown>, f)));
    }
    return out;
  }, [tabRows, activeFilters]);

  const total = filtered.length;
  const safePage = Math.min(page, Math.max(1, Math.ceil(total / pageSize)));
  const pageRows = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);

  const toggleFilter = React.useCallback((fieldKey: string, value: string) => {
    setActiveFilters((prev) => {
      const set = new Set(prev[fieldKey] ?? []);
      if (set.has(value)) set.delete(value);
      else set.add(value);
      return { ...prev, [fieldKey]: set };
    });
    setPage(1);
  }, []);

  const totalActiveFilters = Object.values(activeFilters).reduce((n, s) => n + s.size, 0);

  if (error) {
    return (
      <EmptyState
        tone="danger"
        headline="Failed to load catalogue"
        description={error instanceof Error ? error.message : String(error)}
      />
    );
  }

  const hasSharedFilters = sharedFilters.length > 0;

  const gridContent = (
    <div className={hasSharedFilters ? "flex min-h-0 flex-1 gap-6" : undefined}>
      {/* Sidebar filter panel */}
      {hasSharedFilters && (
        <aside className="w-[200px] shrink-0 space-y-5">
          {totalActiveFilters > 0 && (
            <Button
              type="button"
              variant="link"
              className="h-auto text-xs font-medium text-[var(--color-info-text)]"
              onClick={() => { setActiveFilters({}); setPage(1); }}
            >
              Clear all ({totalActiveFilters})
            </Button>
          )}
          {sharedFilters.map((sf) => {
            const values = collectFacetValues(tabRows, sf.field);
            if (values.length === 0) return null;
            const active = activeFilters[sf.field] ?? new Set<string>();
            return (
              <fieldset key={sf.field}>
                <SectionLabel as="legend" className="mb-2 text-xs tracking-widest">
                  {sf.label}
                </SectionLabel>
                <div className="space-y-1.5">
                  {values.map((v) => (
                    <label key={v} className="flex cursor-pointer items-center gap-2 text-sm">
                      <Checkbox
                        checked={active.has(v)}
                        onCheckedChange={() => toggleFilter(sf.field, v)}
                      />
                      <span className="truncate">{v}</span>
                    </label>
                  ))}
                </div>
              </fieldset>
            );
          })}
        </aside>
      )}

      {/* Card grid */}
      <div className="min-w-0 flex-1">
        {isLoading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: pageSize }).map((_, i) => (
              <Skeleton
                key={i}
                className="h-[200px] rounded-xl bg-[var(--color-navy-50)]"
              />
            ))}
          </div>
        ) : pageRows.length === 0 ? (
          <EmptyState
            title={emptyState?.title ?? "No results"}
            description={emptyState?.description ?? "Try adjusting your filters."}
          />
        ) : (
          <>
            <Grid>
              {pageRows.map((row) => {
                const d = row.data as Record<string, unknown>;
                const titleVal = readField(d, cardFields.title) || row.id;
                const descVal = readField(d, cardFields.description);
                const typeVal = readField(d, cardFields.typeLabel);
                const statusVal = readField(d, cardFields.status);
                const footerVal = readField(d, cardFields.footerId);
                return (
                  <Col key={row.id} span={6} xl={4}>
                    <CatalogCard
                      variant="catalog"
                      title={titleVal}
                      {...(descVal ? { description: descVal } : {})}
                      {...(typeVal ? { typeLabel: typeVal } : {})}
                      {...(statusVal ? { statusLabel: statusVal } : {})}
                      statusTone={cardFields.statusTone ?? "gray"}
                      {...(footerVal ? { footerId: footerVal } : {})}
                      onClick={() => onCardClick?.(entityType, row.id)}
                      onOpen={() => onCardClick?.(entityType, row.id)}
                    />
                  </Col>
                );
              })}
            </Grid>
            {total > pageSize && (
              <div className="mt-6 flex justify-center">
                <Pagination
                  page={safePage}
                  pageSize={pageSize}
                  total={total}
                  onPageChange={setPage}
                />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );

  if (!hasTabs) return gridContent;

  return (
    <Tabs value={activeTab} onValueChange={handleTabChange}>
      <div className="mb-4">
        <TabsList>
          {tabs.map((t) => (
            <TabsTrigger key={t.id} value={t.id}>
              {t.label}
            </TabsTrigger>
          ))}
        </TabsList>
      </div>
      {tabs.map((t) => (
        <TabsContent key={t.id} value={t.id}>
          {gridContent}
        </TabsContent>
      ))}
    </Tabs>
  );
}
