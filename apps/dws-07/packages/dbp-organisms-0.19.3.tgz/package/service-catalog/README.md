# @dbp/organisms/service-catalog

**registryId:** `APP.F20`

Client-faceted, tab-isolated service catalogue grid.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ServiceCatalogConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `object-page-detail` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/service-catalog` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
