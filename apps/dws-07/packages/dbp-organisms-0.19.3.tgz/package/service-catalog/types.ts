import { z } from "zod";

/**
 * A single tab in the service catalog tab strip.
 *
 * Each tab can optionally declare a clientFilter — a static field-equality map
 * applied client-side after fetch. Changing tabs resets shared filters and
 * pagination to page 1.
 */
export const ServiceCatalogTabSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  /**
   * Static field-equality filter applied client-side to items in this tab.
   * e.g. { submarket: "transform" } — shows only items where data.submarket === "transform".
   */
  clientFilter: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
});
export type ServiceCatalogTab = z.infer<typeof ServiceCatalogTabSchema>;

/**
 * A facet checkbox group shown in the filter panel.
 * Unique values are derived from the current tab's items (client-side).
 */
export const ServiceCatalogFilterSchema = z.object({
  /** The entity data field this facet filters on. */
  field: z.string().min(1),
  /** Human-readable label for the checkbox group heading. */
  label: z.string().min(1),
});
export type ServiceCatalogFilter = z.infer<typeof ServiceCatalogFilterSchema>;

/**
 * Maps entity data fields to CatalogCard presentation slots.
 * Identical contract to APP.F10 CardFieldsSchema — cards look the same.
 */
export const ServiceCatalogCardFieldsSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  typeLabel: z.string().optional(),
  status: z.string().optional(),
  statusTone: z
    .enum(["success", "warning", "danger", "info", "orange", "navy", "gray"])
    .optional(),
  footerId: z.string().optional(),
});
export type ServiceCatalogCardFields = z.infer<typeof ServiceCatalogCardFieldsSchema>;

/**
 * ServiceCatalogConfig — typed contract for APP.F20.
 *
 * Designed for browsable service/offering catalogues where:
 *  - The full result set fits in memory (<500 items).
 *  - Tab state is isolated — changing tabs resets filters + pagination.
 *  - Facet values are derived from the tab's items, not the full dataset.
 *  - Server pagination is NOT used: all items are fetched up-front.
 *
 * For large datasets (>500 items) where server pagination is required,
 * use APP.F10 (CatalogGrid) instead.
 */
export const ServiceCatalogConfig = z.object({
  /** The PS.DATA entity type to list (e.g. "drive-listing", "service-offering"). */
  entityType: z.string().min(1),

  /**
   * Tab strip above the grid. Each tab can declare a clientFilter to narrow
   * items to a sub-set of the fetched data. If omitted, all items are shown
   * with no tab strip.
   */
  tabs: z.array(ServiceCatalogTabSchema).default([]),

  /**
   * Entity data field used to match tab.clientFilter when tabField is provided.
   * Short-hand: if all tabs use a single field for their clientFilter, set
   * tabField here instead of repeating it in every tab.clientFilter.
   */
  tabField: z.string().optional(),

  /**
   * Facet filters shared across all tabs — shown in the sidebar filter panel.
   * Unique values are derived from the current tab's visible items.
   */
  sharedFilters: z.array(ServiceCatalogFilterSchema).default([]),

  /** Maps entity data fields to CatalogCard presentation slots. */
  cardFields: ServiceCatalogCardFieldsSchema,

  /**
   * Optional empty-state copy when no items match the active filters.
   */
  emptyState: z
    .object({
      title: z.string(),
      description: z.string().optional(),
    })
    .optional(),

  /** Number of items per page (client-side pagination). Defaults to 9 (3×3). */
  pageSize: z.number().int().min(1).max(200).default(9),

  /**
   * Static field-equality filters applied to every PS.DATA fetch request.
   * Applied server-side before client-side tab/shared filters.
   */
  filters: z
    .record(z.string(), z.union([z.string(), z.number(), z.boolean()]))
    .optional(),
});

export type ServiceCatalogConfig = z.infer<typeof ServiceCatalogConfig>;
