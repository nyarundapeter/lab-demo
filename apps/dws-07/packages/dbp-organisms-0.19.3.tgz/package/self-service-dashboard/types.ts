import { z } from "zod";

// ─── Column definition for a my-items list ────────────────────────────────────

const MyItemsColumnSchema = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
  /**
   * Optional display format hint for cell values (same semantics as EntityList ColumnDef).
   * "number" | "currency" | "percent" | "date" | "datetime"
   * When omitted, ISO date strings are auto-detected and formatted.
   */
  format: z.enum(["number", "currency", "percent", "date", "datetime"]).optional(),
});

// ─── A single "my items" list panel ──────────────────────────────────────────

const MyItemsListSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  entityType: z.string().min(1),
  /**
   * Static field-equality filters forwarded to every PS.DATA request for this
   * list. The solution is responsible for resolving user-specific values at
   * config-build time (e.g. substituting the current user's ID for a
   * submittedBy filter). PS.DATA has no $me placeholder; filters are pure
   * static field equality.  See FEATURE.md for the full constraint note.
   */
  filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
  columns: z.array(MyItemsColumnSchema).min(1),
  /** Maximum rows to display. Defaults to 5. */
  limit: z.number().int().min(1).max(100).default(5),
  /** Text shown when the list has no rows. */
  emptyText: z.string().optional(),
});

// ─── A quick-action link ──────────────────────────────────────────────────────

const QuickActionSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  /** Destination href — navigation is the host shell's concern. */
  href: z.string().min(1),
  /**
   * Optional lucide icon name (e.g. "Plus", "FileText", "Search") shown in the
   * action's icon tile. Defaults to a neutral icon when omitted. Additive/optional.
   */
  icon: z.string().optional(),
  /**
   * Optional icon-tile accent. "navy" → navy-50 tile, "orange" → orange-50 tile.
   * Defaults to "navy". Additive/optional.
   */
  tone: z.enum(["navy", "orange"]).optional(),
});

// ─── PS.AI recommendations config ────────────────────────────────────────────

const RecommendationsConfigSchema = z.object({
  /** The PS.DATA entity type passed to PS.AI /recommend as the entity argument. */
  entity: z.string().min(1),
  /** Optional freeform context forwarded to /recommend. */
  context: z.record(z.string(), z.unknown()).optional(),
  /** Section heading shown above the recommendation cards. */
  title: z.string().optional(),
  /**
   * Tenant identifier forwarded as x-tenant-id to PS.AI /recommend.
   * Required by the server contract — omitting it causes a 400 error.
   */
  tenantId: z.string().min(1).optional(),
});

// ─── Top-level dashboard config ───────────────────────────────────────────────

/**
 * SelfServiceDashboardConfig — the single typed contract for APP.F07.
 *
 * Data-only; no function fields (Zod schemas are data-only).
 */
export const SelfServiceDashboardConfig = z.object({
  /**
   * @deprecated — SelfServiceDashboard is body-only (single-header rule §4.4).
   * Accepted but not rendered. Pass the page title via the host shell/layout PageHeader.
   */
  title: z.string().min(1).optional(),
  /**
   * @deprecated — SelfServiceDashboard is body-only (single-header rule §4.4).
   * Accepted but not rendered. Pass the subtitle via the shell PageHeader.
   */
  subtitle: z.string().optional(),
  /** 1–4 entity lists personalised to the current user. */
  myItems: z.array(MyItemsListSchema).min(1).max(4),
  /** Optional set of plain navigation links rendered as buttons. */
  quickActions: z.array(QuickActionSchema).optional(),
  /**
   * When present, renders a PS.AI recommendation section.
   * Calls recommend(entity, context) and displays cards sorted by score desc.
   */
  recommendations: RecommendationsConfigSchema.optional(),
});

export type SelfServiceDashboardConfig = z.infer<typeof SelfServiceDashboardConfig>;
export type MyItemsList = z.infer<typeof MyItemsListSchema>;
export type MyItemsColumn = z.infer<typeof MyItemsColumnSchema>;
export type QuickAction = z.infer<typeof QuickActionSchema>;
export type RecommendationsConfig = z.infer<typeof RecommendationsConfigSchema>;
