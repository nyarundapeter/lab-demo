import * as React from "react";
import { Alert } from "@dbp/ui";

interface ListErrorProps {
  listId: string;
  error: Error;
}

export function ListError({ listId, error }: ListErrorProps) {
  return (
    <Alert tone="danger" data-testid={`list-error-${listId}`} className="text-xs">
      Failed to load: {error.message}
    </Alert>
  );
}
