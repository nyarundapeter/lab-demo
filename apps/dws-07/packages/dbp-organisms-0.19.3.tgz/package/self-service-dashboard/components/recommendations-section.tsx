import * as React from "react";
import { Alert, Grid, Col, Skeleton } from "@dbp/ui";
import type { RecommendationsConfig } from "../types.js";
import { useRecommendations } from "../hooks/use-recommendations.js";

interface RecommendationsSectionProps {
  config: RecommendationsConfig;
}

export function RecommendationsSection({ config }: RecommendationsSectionProps) {
  const { recommendations, isLoading, error } = useRecommendations(config);

  return (
    <section className="flex flex-col gap-3" data-testid="recommendations-section">
      <p className="dq-overline">{config.title ?? "Recommended for you"}</p>

      {isLoading ? (
        <Grid
          data-testid="recommendations-skeleton"
          aria-busy="true"
          aria-label="Loading recommendations"
        >
          {[1, 2, 3].map((i) => (
            <Col key={i} sm={6} span={6} xl={4}>
              <Skeleton className="h-20 rounded-[var(--radius-card)] bg-[var(--color-border-subtle)]" />
            </Col>
          ))}
        </Grid>
      ) : error ? (
        <Alert tone="danger" title="Could not load recommendations" data-testid="recommendations-error">
          {error.message}
        </Alert>
      ) : recommendations.length === 0 ? (
        <p className="py-2 text-sm text-[var(--color-text-muted)]" data-testid="recommendations-empty">
          No recommendations available right now.
        </p>
      ) : (
        <Grid
          as="ul"
          data-testid="recommendations-list"
        >
          {recommendations.map((rec) => (
            <Col
              as="li"
              key={rec.id}
              sm={6}
              span={6}
              xl={4}
              className="flex flex-col gap-1 rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] p-4 shadow-[var(--shadow-sm)] transition hover:border-[var(--color-border-strong)] hover:shadow-[var(--shadow-md)]"
              data-testid={`recommendation-card-${rec.id}`}
              data-score={rec.score}
            >
              <span className="text-sm font-semibold text-[var(--color-primary)]">
                {rec.label}
              </span>
              <span className="text-xs leading-relaxed text-[var(--color-text-muted)]">
                {rec.reason}
              </span>
            </Col>
          ))}
        </Grid>
      )}
    </section>
  );
}
