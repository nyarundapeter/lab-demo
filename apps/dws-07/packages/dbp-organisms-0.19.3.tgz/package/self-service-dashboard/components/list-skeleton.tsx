import * as React from "react";
import { Skeleton } from "@dbp/ui";

interface ListSkeletonProps {
  rows?: number;
}

export function ListSkeleton({ rows = 5 }: ListSkeletonProps) {
  return (
    <div className="flex flex-col gap-2" data-testid="list-skeleton" aria-busy="true" aria-label="Loading">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton
          key={i}
          className="h-10 rounded bg-[var(--color-border)] opacity-50"
        />
      ))}
    </div>
  );
}
