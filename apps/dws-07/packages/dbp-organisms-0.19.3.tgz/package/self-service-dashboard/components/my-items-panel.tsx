import * as React from "react";
import {
  Badge,
  formatNumber,
  formatCurrency,
  formatPercent,
  formatDate,
  isIsoDateString,
  isYearMonthString,
} from "@dbp/ui";
import type { BadgeProps } from "@dbp/ui";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { MyItemsList, MyItemsColumn } from "../types.js";
import { useMyItems } from "../hooks/use-my-items.js";
import { ListSkeleton } from "./list-skeleton.js";
import { ListError } from "./list-error.js";

/** Format a cell value for a MyItems row column. */
function formatMyItemsCell(value: unknown, col: MyItemsColumn): string {
  if (value === null || value === undefined) return "";
  const raw = value;

  if (col.format) {
    const n = Number(raw);
    switch (col.format) {
      case "number":
        return Number.isFinite(n)
          ? formatNumber(n, { compact: Math.abs(n) >= 10_000 })
          : String(raw);
      case "currency":
        return Number.isFinite(n)
          ? formatCurrency(n, "USD", { compact: Math.abs(n) >= 10_000 })
          : String(raw);
      case "percent":
        return Number.isFinite(n) ? formatPercent(n) : String(raw);
      case "date":
        return isIsoDateString(raw) || raw instanceof Date || typeof raw === "number"
          ? formatDate(raw as string | Date | number, "medium")
          : String(raw);
      case "datetime":
        return isIsoDateString(raw) || raw instanceof Date || typeof raw === "number"
          ? formatDate(raw as string | Date | number, "long")
          : String(raw);
    }
  }

  // Auto-detect: year-month (YYYY-MM) → "Jan 2026"
  if (isYearMonthString(raw)) {
    return formatDate(`${raw}-01`, "year-month");
  }

  // Auto-detect: full ISO date → "Jun 12, 2026"
  if (isIsoDateString(raw) && (raw as string).length > 7) {
    return formatDate(raw as string, "medium");
  }

  return String(raw);
}

/** True when a column reads a status/state-like field worth rendering as a badge. */
function isStatusColumn(col: MyItemsColumn): boolean {
  const f = col.field.toLowerCase();
  return f === "status" || f === "state" || f.endsWith("status") || f.endsWith("state");
}

/** Map a status string to a Badge tone (mirrors the spec StatusBadge mapping). */
function statusTone(value: string): NonNullable<BadgeProps["tone"]> {
  const v = value.toLowerCase();
  if (/(complete|done|active|approved|on track|resolved|open)/.test(v)) return "success";
  if (/(progress|review|pending|submitted|in-review)/.test(v)) return "info";
  if (/(attention|due|warning|waiting|hold)/.test(v)) return "warning";
  if (/(risk|overdue|blocked|critical|rejected|failed|error)/.test(v)) return "danger";
  return "gray";
}

interface MyItemsPanelProps {
  list: MyItemsList;
}

export function MyItemsPanel({ list }: MyItemsPanelProps) {
  const { rows, isLoading, error } = useMyItems(list);

  return (
    <div className="dq-card flex flex-col gap-3" data-testid={`my-items-panel-${list.id}`}>
      <h3 className="dq-card-title">{list.title}</h3>

      {isLoading ? (
        <ListSkeleton rows={list.limit} />
      ) : error ? (
        <ListError listId={list.id} error={error} />
      ) : rows.length === 0 ? (
        <p
          className="py-2 text-sm text-[var(--color-text-muted)]"
          data-testid={`my-items-empty-${list.id}`}
        >
          {list.emptyText ?? "No items found."}
        </p>
      ) : (
        <ul
          className="flex flex-col divide-y divide-[var(--color-border-subtle)]"
          data-testid={`my-items-rows-${list.id}`}
        >
          {rows.map((row) => (
            <ItemRow key={row.id} row={row} columns={list.columns} />
          ))}
        </ul>
      )}
    </div>
  );
}

// ─── Single list row ──────────────────────────────────────────────────────────

interface ItemRowProps {
  row: EntityRecord<EntityData>;
  columns: MyItemsList["columns"];
}

function ItemRow({ row, columns }: ItemRowProps) {
  const data = row.data as Record<string, unknown>;
  const [firstCol, ...restCols] = columns;

  return (
    <li className="flex items-center gap-3 py-2.5 text-sm first:pt-0 last:pb-0">
      {firstCol && (
        <span className="min-w-0 flex-1 truncate font-medium text-[var(--color-primary)]">
          {formatMyItemsCell(data[firstCol.field], firstCol)}
        </span>
      )}
      {restCols.map((col) => {
        const raw = data[col.field];
        const text = formatMyItemsCell(raw, col);
        if (isStatusColumn(col) && text) {
          return (
            <Badge key={col.field} tone={statusTone(text)} className="shrink-0" data-field={col.field}>
              {text}
            </Badge>
          );
        }
        return (
          <span
            key={col.field}
            className="shrink-0 text-[var(--color-text-muted)]"
            data-field={col.field}
          >
            {text}
          </span>
        );
      })}
    </li>
  );
}
