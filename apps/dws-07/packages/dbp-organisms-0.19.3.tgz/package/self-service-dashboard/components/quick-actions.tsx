import * as React from "react";
import * as LucideIcons from "lucide-react";
import { Grid, Col } from "@dbp/ui";
import type { QuickAction } from "../types.js";

interface QuickActionsProps {
  actions: QuickAction[];
}

/** Resolve a lucide icon name to a component, falling back to ArrowRight. */
function resolveIcon(name?: string): React.ComponentType<{ size?: number; strokeWidth?: number }> {
  if (!name) return LucideIcons.ArrowRight;
  const icon = (LucideIcons as unknown as Record<string, unknown>)[name];
  return (icon as React.ComponentType<{ size?: number; strokeWidth?: number }>) ?? LucideIcons.ArrowRight;
}

export function QuickActions({ actions }: QuickActionsProps) {
  if (actions.length === 0) return null;

  return (
    <Grid data-testid="quick-actions">
      {actions.map((action) => {
        const Icon = resolveIcon(action.icon);
        const isOrange = action.tone === "orange";
        return (
          <Col key={action.id} sm={6} span={6} xl={3}>
          <a
            href={action.href}
            className="group flex items-center gap-3 rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] p-4 text-sm font-semibold text-[var(--color-primary)] shadow-[var(--shadow-sm)] transition hover:border-[var(--color-border-strong)] hover:shadow-[var(--shadow-md)] focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-orange)] motion-safe:hover:-translate-y-0.5"
            data-testid={`quick-action-${action.id}`}
          >
            <span
              aria-hidden="true"
              className={
                isOrange
                  ? "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[var(--color-orange-50)] text-[var(--color-secondary)]"
                  : "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[var(--color-navy-50)] text-[var(--color-primary)]"
              }
            >
              <Icon size={20} strokeWidth={1.5} />
            </span>
            {action.label}
          </a>
          </Col>
        );
      })}
    </Grid>
  );
}
