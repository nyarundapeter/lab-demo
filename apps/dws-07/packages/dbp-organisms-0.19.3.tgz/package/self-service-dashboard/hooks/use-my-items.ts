import { useEntityList } from "@dbp/ps-data/client";
import type { EntityData, EntityRecord } from "@dbp/ps-data/client";
import type { MyItemsList } from "../types.js";

export interface MyItemsResult {
  rows: EntityRecord<EntityData>[];
  isLoading: boolean;
  error: Error | null;
}

export function useMyItems(list: MyItemsList): MyItemsResult {
  const { rows, isLoading, error } = useEntityList(list.entityType, {
    ...(list.filters !== undefined && { filters: list.filters }),
    pageSize: list.limit,
    page: 1,
  });

  return { rows, isLoading, error };
}
