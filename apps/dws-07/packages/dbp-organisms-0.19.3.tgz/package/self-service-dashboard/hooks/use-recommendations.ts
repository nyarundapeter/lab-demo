import { useRecommend } from "@dbp/ps-ai/client";
import type { Recommendation } from "@dbp/ps-ai/client";
import type { RecommendationsConfig } from "../types.js";

export interface RecommendationsResult {
  /** Score-ordered descending. */
  recommendations: Recommendation[];
  isLoading: boolean;
  error: Error | null;
}

export function useRecommendations(config: RecommendationsConfig): RecommendationsResult {
  const { recommendations, isLoading, error } = useRecommend(
    config.entity,
    config.context,
    config.tenantId,
  );

  const sorted = [...recommendations].sort((a, b) => b.score - a.score);

  return { recommendations: sorted, isLoading, error };
}
