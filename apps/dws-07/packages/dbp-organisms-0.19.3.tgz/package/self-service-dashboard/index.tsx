import * as React from "react";
import { Alert, Grid, Col } from "@dbp/ui";
import { SelfServiceDashboardConfig } from "./types.js";
import { MyItemsPanel } from "./components/my-items-panel.js";
import { QuickActions } from "./components/quick-actions.js";
import { RecommendationsSection } from "./components/recommendations-section.js";

type ConfigInput = Omit<SelfServiceDashboardConfig, "myItems"> & {
  myItems: SelfServiceDashboardConfig["myItems"];
};

/**
 * APP.F07 — Self-Service Dashboard
 *
 * Receives CONFIG, never data. Each myItems list independently fetches its
 * rows via PS.DATA (useEntityList). Recommendations are fetched via PS.AI
 * (useRecommend) when the recommendations config is present.
 *
 * Config is validated at render time via SelfServiceDashboardConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 *
 * List failures are isolated — one list erroring does not affect siblings.
 * The recommendations section has its own isolated loading/error/empty state.
 */
export default function SelfServiceDashboard(rawConfig: ConfigInput) {
  const parseResult = SelfServiceDashboardConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert
        tone="danger"
        title="SelfServiceDashboard configuration error"
        data-testid="config-error"
      >
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  const config = parseResult.data;

  return <SelfServiceDashboardInner config={config} />;
}

// Re-export types so consumers can import from the root.
export type {
  SelfServiceDashboardConfig,
  MyItemsList,
  MyItemsColumn,
  QuickAction,
  RecommendationsConfig,
} from "./types.js";

// ─── Inner component (config is guaranteed valid here) ────────────────────────

interface SelfServiceDashboardInnerProps {
  config: SelfServiceDashboardConfig;
}

function SelfServiceDashboardInner({ config }: SelfServiceDashboardInnerProps) {
  const { myItems, quickActions, recommendations } = config;

  return (
    <div className="flex w-full flex-col gap-8" data-testid="self-service-dashboard">
      {/* Quick actions */}
      {quickActions && quickActions.length > 0 && (
        <section className="flex flex-col gap-4">
          <p className="dq-overline">Quick actions</p>
          <QuickActions actions={quickActions} />
        </section>
      )}

      {/* My items lists — 2-up ≥ lg, stacked below */}
      <section className="flex flex-col gap-4">
        <p className="dq-overline">Action snapshot</p>
        <Grid data-testid="my-items-grid">
          {myItems.map((list) => (
            <Col key={list.id} lg={6}>
              <MyItemsPanel list={list} />
            </Col>
          ))}
        </Grid>
      </section>

      {/* Recommendations section */}
      {recommendations && <RecommendationsSection config={recommendations} />}
    </div>
  );
}
