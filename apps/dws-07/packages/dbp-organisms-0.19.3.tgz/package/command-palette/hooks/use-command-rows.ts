import * as React from "react";
import type { CommandPaletteConfig, CommandItemConfig } from "../types.js";

export interface CommandGroup {
  id: string;
  kind: string;
  label: string;
  items: CommandItemConfig[];
}

export interface FlatRow {
  key: string;
  groupId: string;
  groupLabel: string;
  groupKind: string;
  item: CommandItemConfig;
}

/** Title-cases a group id/kind for the fallback group heading, e.g. "reports" -> "Reports". */
export function titleCase(s: string): string {
  return s.replace(/(^|[\s-])\S/g, (c) => c.toUpperCase()).replace(/-/g, " ");
}

/** Dependency-free substring/subsequence match (no cmdk/fuzzy-match library —
 * see index.tsx doc-comment for the standardise-on-existing-libraries note).
 * Subsequence fallback lets "cprj" match "Create Project". */
export function matchesQuery(query: string, label: string, hint?: string): boolean {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  const haystack = `${label} ${hint ?? ""}`.toLowerCase();
  if (haystack.includes(q)) return true;
  let qi = 0;
  for (let i = 0; i < haystack.length && qi < q.length; i++) {
    if (haystack[i] === q[qi]) qi++;
  }
  return qi === q.length;
}

/** Max items shown per source group when the query is empty — the full list
 * is available by typing; this just keeps the default view scannable. */
const EMPTY_QUERY_GROUP_CAP = 5;

/** Groups + flattens `config` for the given `query`: empty query surfaces
 * `recentItems` (if any) followed by every source's items, capped per group
 * (mirrors Linear/Slack showing the full command list on open), a non-empty
 * query filters every source's items with no cap. */
export function useCommandRows(
  config: CommandPaletteConfig,
  query: string,
): { groups: CommandGroup[]; flatRows: FlatRow[]; isEmptyQuery: boolean } {
  const labels = config.labels ?? {};
  const isEmptyQuery = query.trim().length === 0;

  const groups = React.useMemo<CommandGroup[]>(() => {
    if (isEmptyQuery) {
      const recentGroup: CommandGroup[] =
        config.recentItems && config.recentItems.length > 0
          ? [
              {
                id: "__recent",
                kind: "recent",
                label: config.recentLabel ?? labels.recent ?? "Recent & suggested",
                items: config.recentItems,
              },
            ]
          : [];
      const sourceGroups = config.sources
        .map((src) => ({
          id: src.id,
          kind: src.group,
          label: src.groupLabel ?? titleCase(src.group),
          items: src.items.slice(0, EMPTY_QUERY_GROUP_CAP),
        }))
        .filter((g) => g.items.length > 0);
      return [...recentGroup, ...sourceGroups];
    }
    return config.sources
      .map((src) => ({
        id: src.id,
        kind: src.group,
        label: src.groupLabel ?? titleCase(src.group),
        items: src.items.filter((it) => matchesQuery(query, it.label, it.hint)),
      }))
      .filter((g) => g.items.length > 0);
  }, [config.sources, config.recentItems, config.recentLabel, labels.recent, isEmptyQuery, query]);

  const flatRows = React.useMemo<FlatRow[]>(
    () =>
      groups.flatMap((g) =>
        g.items.map((item) => ({
          key: `${g.id}:${item.id}`,
          groupId: g.id,
          groupLabel: g.label,
          groupKind: g.kind,
          item,
        })),
      ),
    [groups],
  );

  return { groups, flatRows, isEmptyQuery };
}
