# @dbp/organisms/command-palette

**registryId:** `APP.F26`

Global `cmd/ctrl+K` action/navigation search overlay — grouped, filterable, keyboard-navigable.
See `FEATURE.md` for the `APP.F26` id-collision flag against the backlog's "Data Export &
Reporting" row.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`CommandPaletteConfig` — Zod schema exported from `types.ts` (source of truth). `open`/`onClose`/
`onRun`/`asyncSourcesLoading` are separate component props, not part of the schema.

## Consumed by
Not yet wired into the generator's `FEATURE_COMPONENT` map — this build lands the organism per
`capability-keyboard-shortcuts-spec-2026-07-10.md` Deliverable B; shell mounting (the default
`mod+k`/`/` global binding via `@dbp/ui`'s `ShortcutProvider`/`useShortcuts`) is a follow-on
increment, not part of this package.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/command-palette` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
