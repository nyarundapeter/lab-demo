import * as React from "react";
import {
  Search,
  CornerDownLeft,
  ArrowUp,
  ArrowDown,
  X,
  FileQuestion,
  Loader2,
  Command as CommandIcon,
  Clock,
} from "lucide-react";
import { Alert, Button, Dialog, DialogContent, DialogTitle, DialogDescription, SectionLabel, cn } from "@dbp/ui";
import { CommandPaletteConfig } from "./types.js";
import type { CommandItemConfig } from "./types.js";
import { useCommandRows } from "./hooks/use-command-rows.js";
import { titleCase } from "./hooks/use-command-rows.js";
import { GROUP_ICON, DefaultGroupIcon } from "./components/icon-map.js";
import { KbdChip } from "./components/kbd.js";
import { ResultRow } from "./components/result-row.js";

/**
 * APP.F26 — Command Palette
 *
 * cmd/ctrl+K (and `/`) global action/navigation search overlay — Deliverable B
 * of `capability-keyboard-shortcuts-spec-2026-07-10.md`. Renders purely off
 * `config` (nav items, entity quick-creates, registered shortcut actions —
 * the caller assembles the sources; this component never fetches).
 *
 * Built on `@dbp/ui`'s `Dialog` (ADR-0044: focus trap, Escape-to-close,
 * portal, scroll lock, focus-restore all come from Radix via that wrapper —
 * no direct `@radix-ui/*` import here). Arrow-key/Enter row navigation is
 * hand-rolled because Radix has no "command menu" primitive for a
 * searchable, keyboard-navigable, grouped action list — cmdk is the usual
 * library for that shape, but it is not already a workspace dependency, so
 * per the standardise-on-existing-libraries rule this composes Dialog +
 * Input semantics + a native listbox instead of adding a new dependency
 * without an ADR (flagged in the build report for a follow-up ruling).
 */
export interface CommandPaletteProps {
  open: boolean;
  onClose: () => void;
  config: CommandPaletteConfig;
  onRun: (item: CommandItemConfig, groupId: string) => void;
  /** When true, the named async source is still resolving — renders a loading row. */
  asyncSourcesLoading?: Record<string, boolean>;
}

export default function CommandPalette({
  open,
  onClose,
  config: rawConfig,
  onRun,
  asyncSourcesLoading = {},
}: CommandPaletteProps) {
  const parseResult = CommandPaletteConfig.safeParse(rawConfig);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="CommandPalette configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <CommandPaletteInner
      open={open}
      onClose={onClose}
      config={parseResult.data}
      onRun={onRun}
      asyncSourcesLoading={asyncSourcesLoading}
    />
  );
}

export type { CommandPaletteConfig, CommandItemConfig, CommandSourceConfig, AsyncCommandSourceConfig } from "./types.js";

// ─── Inner component (config guaranteed valid) ────────────────────────────────

interface CommandPaletteInnerProps {
  open: boolean;
  onClose: () => void;
  config: CommandPaletteConfig;
  onRun: (item: CommandItemConfig, groupId: string) => void;
  asyncSourcesLoading: Record<string, boolean>;
}

function CommandPaletteInner({ open, onClose, config, onRun, asyncSourcesLoading }: CommandPaletteInnerProps) {
  const labels = config.labels ?? {};
  const [query, setQuery] = React.useState("");
  const [activeIndex, setActiveIndex] = React.useState(0);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const listRef = React.useRef<HTMLUListElement>(null);

  const { groups, flatRows, isEmptyQuery } = useCommandRows(config, query);

  const pendingAsync = React.useMemo(
    () => (isEmptyQuery ? [] : (config.asyncSources ?? []).filter((s) => asyncSourcesLoading[s.id])),
    [config.asyncSources, asyncSourcesLoading, isEmptyQuery],
  );

  const hasResults = flatRows.length > 0;
  const showNoResults = !isEmptyQuery && !hasResults && pendingAsync.length === 0;

  React.useEffect(() => {
    setActiveIndex(0);
  }, [query, flatRows.length]);

  // Reset query on every open (Dialog handles focus/scroll-lock/restore).
  React.useEffect(() => {
    if (!open) return;
    setQuery("");
    setActiveIndex(0);
  }, [open]);

  React.useEffect(() => {
    if (!open) return;
    const key = flatRows[activeIndex]?.key;
    // Keys are often route paths ("/a/b") — invalid in a raw #id selector without escaping.
    const row = key ? listRef.current?.querySelector(`#${CSS.escape(`palette-row-${key}`)}`) : null;
    row?.scrollIntoView({ block: "nearest" });
  }, [activeIndex, flatRows, open]);

  function runRow(row: (typeof flatRows)[number]) {
    onRun(row.item, row.groupId);
    onClose();
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      if (flatRows.length > 0) setActiveIndex((i) => (i + 1) % flatRows.length);
      return;
    }
    if (e.key === "ArrowUp") {
      e.preventDefault();
      if (flatRows.length > 0) setActiveIndex((i) => (i - 1 + flatRows.length) % flatRows.length);
      return;
    }
    if (e.key === "Enter") {
      e.preventDefault();
      const row = flatRows[activeIndex];
      if (row) runRow(row);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(next) => { if (!next) onClose(); }}>
      <DialogContent
        hideClose
        onOpenAutoFocus={(e) => {
          e.preventDefault();
          inputRef.current?.focus();
        }}
        onKeyDown={onKeyDown}
        aria-label={labels.title ?? "Command palette"}
        className={cn(
          "top-[12vh] max-w-xl translate-y-0 gap-0 overflow-hidden p-0",
          "data-[state=closed]:slide-out-to-top-4 data-[state=open]:slide-in-from-top-4",
        )}
      >
        <DialogTitle className="sr-only">{labels.title ?? "Command palette"}</DialogTitle>
        <DialogDescription className="sr-only">
          {labels.description ?? "Search records, actions, and pages. Use arrow keys to navigate and Enter to select."}
        </DialogDescription>

        {/* Search input */}
        <div className="flex shrink-0 items-center gap-2.5 border-b border-[var(--color-border)] px-4">
          <Search className="h-4 w-4 shrink-0 text-[var(--color-text-muted)]" aria-hidden="true" />
          <input
            ref={inputRef}
            role="combobox"
            aria-expanded={hasResults}
            aria-controls="palette-listbox"
            aria-activedescendant={flatRows[activeIndex] ? `palette-row-${flatRows[activeIndex]!.key}` : undefined}
            autoComplete="off"
            spellCheck={false}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={config.placeholder ?? labels.placeholder ?? "Search or jump to…"}
            className={cn(
              "h-12 flex-1 bg-transparent text-sm text-[var(--color-text)] outline-none",
              "placeholder:text-[var(--color-text-disabled)]",
            )}
          />
          {query && (
            <Button
              variant="ghost"
              size="icon"
              aria-label={labels.clear ?? "Clear search"}
              onClick={() => {
                setQuery("");
                inputRef.current?.focus();
              }}
              className={cn(
                "h-6 w-6 shrink-0 rounded-md text-[var(--color-text-muted)] hover:text-[var(--color-text)]",
                "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
              )}
            >
              <X className="h-3.5 w-3.5" aria-hidden="true" />
            </Button>
          )}
          <span className="hidden shrink-0 items-center gap-1 text-xs text-[var(--color-text-disabled)] sm:flex">
            <KbdChip>Esc</KbdChip>
          </span>
        </div>

        {/* Results */}
        <div className="min-h-0 max-h-[50vh] flex-1 overflow-y-auto p-2">
          {showNoResults ? (
            <div className="flex flex-col items-center gap-2 py-10 text-center" data-testid="no-results">
              <FileQuestion className="h-6 w-6 text-[var(--color-text-disabled)]" aria-hidden="true" />
              <p className="text-sm font-medium text-[var(--color-text)]">
                {labels.noResultsTitle ?? "No matches"}
              </p>
              <p className="max-w-[28ch] text-xs text-[var(--color-text-muted)]">
                {labels.noResultsBody ?? "Try a different term, or browse navigation from the sidebar."}
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setQuery("");
                  inputRef.current?.focus();
                }}
                className="mt-1 h-auto px-2.5 py-1 text-xs"
              >
                {labels.clearSearch ?? "Clear search"}
              </Button>
            </div>
          ) : (
            <ul id="palette-listbox" role="listbox" ref={listRef} className="flex flex-col gap-3">
              {isEmptyQuery && groups.length === 0 && pendingAsync.length === 0 && (
                <div className="flex flex-col items-center gap-2 py-10 text-center" data-testid="empty-recent">
                  <Clock className="h-6 w-6 text-[var(--color-text-disabled)]" aria-hidden="true" />
                  <p className="text-sm text-[var(--color-text-muted)]">
                    {labels.emptyRecent ?? "Start typing to search — nothing recent yet."}
                  </p>
                </div>
              )}
              {groups.map((g) => {
                const GroupIcon = GROUP_ICON[g.kind] ?? DefaultGroupIcon;
                return (
                  <li key={g.id}>
                    <SectionLabel as="div" size="2xs" className="flex items-center gap-1.5 px-3 pb-1 pt-1 tracking-[0.08em]">
                      <GroupIcon className="h-3 w-3" aria-hidden="true" />
                      {g.label}
                    </SectionLabel>
                    <ul role="group" aria-label={g.label} className="flex flex-col gap-0.5">
                      {g.items.map((item) => {
                        const idx = flatRows.findIndex((r) => r.groupId === g.id && r.item.id === item.id);
                        const row = flatRows[idx];
                        if (!row) return null;
                        return (
                          <ResultRow
                            key={row.key}
                            row={row}
                            active={idx === activeIndex}
                            onHover={() => setActiveIndex(idx)}
                            onSelect={() => runRow(row)}
                          />
                        );
                      })}
                    </ul>
                  </li>
                );
              })}
              {pendingAsync.map((src) => (
                <li key={src.id}>
                  <SectionLabel as="div" size="2xs" className="flex items-center gap-1.5 px-3 pb-1 pt-1 tracking-[0.08em]">
                    {titleCase(src.groupLabel ?? src.group)}
                  </SectionLabel>
                  <div className="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-[var(--color-text-muted)]">
                    <Loader2 className="h-3.5 w-3.5 motion-safe:animate-spin" aria-hidden="true" />
                    {src.loadingLabel ?? labels.searching ?? "Searching further…"}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Footer legend */}
        <div className="flex shrink-0 items-center justify-between gap-3 border-t border-[var(--color-border)] bg-[var(--color-surface)] px-4 py-2">
          <div className="flex items-center gap-3 text-xs text-[var(--color-text-muted)]">
            <span className="inline-flex items-center gap-1">
              <ArrowUp className="h-3 w-3" aria-hidden="true" />
              <ArrowDown className="h-3 w-3" aria-hidden="true" />
              {labels.navigate ?? "Navigate"}
            </span>
            <span className="inline-flex items-center gap-1">
              <CornerDownLeft className="h-3 w-3" aria-hidden="true" />
              {labels.select ?? "Select"}
            </span>
            <span className="inline-flex items-center gap-1">
              <KbdChip>Esc</KbdChip>
              {labels.dismiss ?? "Dismiss"}
            </span>
          </div>
          <span className="inline-flex items-center gap-1 text-xs text-[var(--color-text-disabled)]">
            <CommandIcon className="h-3 w-3" aria-hidden="true" />K
          </span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
