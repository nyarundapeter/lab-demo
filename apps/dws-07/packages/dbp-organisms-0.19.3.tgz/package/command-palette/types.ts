import { z } from "zod";

/**
 * CommandPaletteConfig — the single typed contract for APP.F26.
 *
 * Data contract only (no function fields — Zod schemas are data-only;
 * `open`/`onClose`/`onRun`/`asyncSourcesLoading` are separate component props,
 * mirroring the ApprovalSurface (APP.F06) split of config-vs-behaviour).
 *
 * Curated lucide-react icon keys a builder may reference from `item.icon` —
 * kept in sync with `components/icon-map.ts`.
 */
export const CommandPaletteIconName = z.enum([
  "home",
  "users",
  "server",
  "shield",
  "database",
  "fileText",
  "settings",
  "bell",
  "workflow",
  "building",
  "plus",
  "zap",
  "compass",
]);
export type CommandPaletteIconName = z.infer<typeof CommandPaletteIconName>;

export const CommandItemConfig = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  icon: CommandPaletteIconName.optional(),
  /** Short trailing hint, e.g. an entity type or breadcrumb — not a keybind. */
  hint: z.string().optional(),
  /** Rendered as kbd chips, e.g. ["G","H"] or ["mod","N"]. */
  kbd: z.array(z.string()).optional(),
});
export type CommandItemConfig = z.infer<typeof CommandItemConfig>;

export const CommandSourceConfig = z.object({
  id: z.string().min(1),
  /** "navigation" | "create" | "actions" | any builder-defined kind. */
  group: z.string().min(1),
  /** Group heading shown above its items — falls back to a title-cased group id. */
  groupLabel: z.string().optional(),
  items: z.array(CommandItemConfig),
});
export type CommandSourceConfig = z.infer<typeof CommandSourceConfig>;

/** A source resolved asynchronously (e.g. cross-tenant search) — config declares
 *  the shape only; the consumer drives `asyncSourcesLoading` on the component. */
export const AsyncCommandSourceConfig = z.object({
  id: z.string().min(1),
  group: z.string().min(1),
  groupLabel: z.string().optional(),
  /** Label shown on the loading row while this source resolves. */
  loadingLabel: z.string().optional(),
});
export type AsyncCommandSourceConfig = z.infer<typeof AsyncCommandSourceConfig>;

export const CommandPaletteConfig = z.object({
  sources: z.array(CommandSourceConfig),
  asyncSources: z.array(AsyncCommandSourceConfig).optional(),
  placeholder: z.string().optional(),
  /** Items shown when the query is empty (recent / suggested). */
  recentItems: z.array(CommandItemConfig).optional(),
  recentLabel: z.string().optional(),
  labels: z.record(z.string()).optional(),
});
export type CommandPaletteConfig = z.infer<typeof CommandPaletteConfig>;
