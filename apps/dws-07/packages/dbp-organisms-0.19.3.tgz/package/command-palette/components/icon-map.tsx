import type { ComponentType } from "react";
import {
  Home,
  Users,
  Server,
  Shield,
  Database,
  FileText,
  Settings,
  Bell,
  Workflow,
  Building2,
  PlusCircle,
  Zap,
  Compass,
  Clock,
} from "lucide-react";
import type { CommandPaletteIconName } from "../types.js";

/** Icon rendered for each curated `item.icon` value. */
export const ICON_MAP: Record<CommandPaletteIconName, ComponentType<{ className?: string }>> = {
  home: Home,
  users: Users,
  server: Server,
  shield: Shield,
  database: Database,
  fileText: FileText,
  settings: Settings,
  bell: Bell,
  workflow: Workflow,
  building: Building2,
  plus: PlusCircle,
  zap: Zap,
  compass: Compass,
};

/** Icon shown next to a group heading, keyed by `group` kind. Unrecognised
 * kinds (a builder-defined group string) fall back to `Clock` — never crash,
 * never drop the row. */
export const GROUP_ICON: Record<string, ComponentType<{ className?: string }>> = {
  navigation: Compass,
  create: PlusCircle,
  actions: Zap,
};

export { Clock as DefaultGroupIcon };
