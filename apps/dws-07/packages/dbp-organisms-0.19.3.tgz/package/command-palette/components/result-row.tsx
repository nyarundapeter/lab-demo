import * as React from "react";
import { CornerDownLeft, FileQuestion } from "lucide-react";
import { Button, cn } from "@dbp/ui";
import type { FlatRow } from "../hooks/use-command-rows.js";
import { ICON_MAP } from "./icon-map.js";
import { KbdCombo } from "./kbd.js";

export function ResultRow({
  row,
  active,
  onHover,
  onSelect,
}: {
  row: FlatRow;
  active: boolean;
  onHover: () => void;
  onSelect: () => void;
}) {
  const Icon = row.item.icon ? ICON_MAP[row.item.icon] : undefined;
  return (
    <li role="option" aria-selected={active} id={`palette-row-${row.key}`}>
      <Button
        variant="ghost"
        onMouseEnter={onHover}
        onClick={onSelect}
        className={cn(
          "h-auto w-full justify-start gap-3 rounded-md px-3 py-2 text-left font-normal",
          active ? "bg-[var(--color-secondary)]/10 hover:bg-[var(--color-secondary)]/10" : "hover:bg-[var(--color-surface)]",
        )}
      >
        <span
          className={cn(
            "flex h-7 w-7 shrink-0 items-center justify-center rounded-md border",
            active
              ? "border-[var(--color-secondary)] bg-[var(--color-surface-content)] text-[var(--color-secondary)]"
              : "border-[var(--color-border)] bg-[var(--color-surface-content)] text-[var(--color-text-muted)]",
          )}
        >
          {Icon ? (
            <Icon className="h-3.5 w-3.5" />
          ) : (
            <FileQuestion className="h-3.5 w-3.5" aria-hidden="true" />
          )}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-medium text-[var(--color-text)]">
            {row.item.label}
          </span>
        </span>
        {row.item.hint && (
          <span className="max-w-[30%] shrink-0 truncate text-xs text-[var(--color-text-muted)]">
            {row.item.hint}
          </span>
        )}
        {row.item.kbd && row.item.kbd.length > 0 && (
          <span className="shrink-0">
            <KbdCombo keys={row.item.kbd} />
          </span>
        )}
        {active && (
          <CornerDownLeft className="h-3.5 w-3.5 shrink-0 text-[var(--color-secondary)]" aria-hidden="true" />
        )}
      </Button>
    </li>
  );
}
