import * as React from "react";
import { cn } from "@dbp/ui";

export function KbdChip({ children }: { children: React.ReactNode }) {
  return (
    <kbd
      className={cn(
        "inline-flex h-5 min-w-[20px] items-center justify-center rounded-[4px] border px-1",
        "border-[var(--color-border-strong)] bg-[var(--color-surface-content)] text-xs font-medium leading-none",
        "text-[var(--color-text-muted)]",
      )}
    >
      {children}
    </kbd>
  );
}

export function KbdCombo({ keys }: { keys: string[] }) {
  return (
    <span className="inline-flex items-center gap-0.5">
      {keys.map((k, i) => (
        <KbdChip key={i}>{k}</KbdChip>
      ))}
    </span>
  );
}
