import React, { useState } from "react";
import { AssistantPanel } from "@dbp/organisms/assistant-panel";
import { Button } from "@dbp/ui";

interface Props {
  entityType: string;
  entityId: string;
  extraContext?: Record<string, unknown>;
}

export function AssistantZone({ entityType, entityId, extraContext }: Props) {
  const [expanded, setExpanded] = useState(true);

  const context: Record<string, unknown> = {
    entityType,
    entityId,
    ...extraContext,
  };

  return (
    <div
      data-testid="assistant-zone"
      style={{
        border: "1px solid var(--color-border)",
        borderRadius: "var(--radius, 6px)",
        background: "var(--color-surface)",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      <Button
        type="button"
        variant="ghost"
        onClick={() => setExpanded((prev) => !prev)}
        aria-expanded={expanded}
        aria-controls="assistant-zone-body"
        data-testid="assistant-zone-toggle"
        className="h-auto rounded-none"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0.625rem 0.75rem",
          borderBottom: expanded ? "1px solid var(--color-border)" : "none",
          width: "100%",
          textAlign: "left",
          fontFamily: "inherit",
        }}
      >
        <span
          style={{
            fontSize: "0.75rem",
            fontWeight: 600,
            textTransform: "uppercase",
            letterSpacing: "0.05em",
            color: "color-mix(in srgb, var(--color-text) 55%, transparent)",
          }}
        >
          Assistant
        </span>
        <span
          aria-hidden="true"
          style={{
            fontSize: "0.75rem",
            color: "color-mix(in srgb, var(--color-text) 40%, transparent)",
            transform: expanded ? "rotate(180deg)" : "none",
            transition: "transform 0.15s",
          }}
        >
          ▾
        </span>
      </Button>

      {expanded && (
        <div
          id="assistant-zone-body"
          data-testid="assistant-zone-body"
          style={{ flex: 1, minHeight: "280px", display: "flex", flexDirection: "column" }}
        >
          <AssistantPanel context={context} />
        </div>
      )}
    </div>
  );
}
