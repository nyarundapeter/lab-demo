import React from "react";
import { Skeleton, Alert } from "@dbp/ui";
import { useWorkbenchRecommendations } from "../hooks/use-workbench-recommendations.js";
import type { WorkbenchRecommendationsConfig } from "../types.js";

interface Props {
  config: WorkbenchRecommendationsConfig;
}

export function RecommendationsZone({ config }: Props) {
  const { recommendations, isLoading, error } = useWorkbenchRecommendations(config);

  return (
    <div
      data-testid="recommendations-zone"
      style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}
    >
      <h3
        style={{
          margin: 0,
          fontSize: "0.75rem",
          fontWeight: 600,
          textTransform: "uppercase",
          letterSpacing: "0.05em",
          color: "color-mix(in srgb, var(--color-text) 55%, transparent)",
        }}
      >
        {config.title ?? "Recommended Actions"}
      </h3>

      {error ? (
        <Alert tone="danger" title="Could not load recommendations" data-testid="recommendations-error">
          {error.message}
        </Alert>
      ) : isLoading ? (
        <div
          data-testid="recommendations-skeleton"
          aria-busy="true"
          aria-label="Loading recommendations"
          style={{ display: "flex", gap: "0.75rem" }}
        >
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 flex-1" />
          ))}
        </div>
      ) : recommendations.length === 0 ? (
        <p
          data-testid="recommendations-empty"
          style={{ fontSize: "0.875rem", color: "color-mix(in srgb, var(--color-text) 55%, transparent)" }}
        >
          No recommendations available right now.
        </p>
      ) : (
        <ul
          data-testid="recommendations-list"
          style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexWrap: "wrap", gap: "0.625rem" }}
        >
          {recommendations.map((rec) => (
            <li
              key={rec.id}
              data-testid={`recommendation-card-${rec.id}`}
              data-score={rec.score}
              style={{
                padding: "0.75rem",
                border: "1px solid var(--color-border)",
                borderRadius: "var(--radius, 6px)",
                background: "var(--color-surface)",
                display: "flex",
                flexDirection: "column",
                gap: "0.25rem",
                minWidth: "180px",
                flex: "1 1 180px",
              }}
            >
              <span style={{ fontSize: "0.875rem", fontWeight: 500, color: "var(--color-text)" }}>
                {rec.label}
              </span>
              <span style={{ fontSize: "0.75rem", color: "color-mix(in srgb, var(--color-text) 60%, transparent)" }}>
                {rec.reason}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
