import React from "react";
import { Input, Alert } from "@dbp/ui";
import { useRagLookup } from "../hooks/use-rag-lookup.js";

interface Props {
  ragScope: string;
}

export function RagLookupZone({ ragScope }: Props) {
  const { query, setQuery, results, isLoading, error } = useRagLookup(ragScope);

  return (
    <div
      className="flex flex-col gap-3"
      data-testid="rag-lookup-zone"
    >
      <h3
        style={{
          margin: 0,
          fontSize: "0.75rem",
          fontWeight: 600,
          textTransform: "uppercase",
          letterSpacing: "0.05em",
          color: "color-mix(in srgb, var(--color-text) 55%, transparent)",
        }}
      >
        Reference Lookup
      </h3>

      <Input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search reference documents…"
        aria-label="Reference lookup query"
        data-testid="rag-query-input"
      />

      {error ? (
        <Alert tone="danger" title="Reference lookup failed" data-testid="rag-error">
          {error.message}
        </Alert>
      ) : isLoading ? (
        <div
          data-testid="rag-loading"
          aria-busy="true"
          aria-label="Searching reference documents"
          style={{ fontSize: "0.875rem", color: "color-mix(in srgb, var(--color-text) 60%, transparent)" }}
        >
          Searching…
        </div>
      ) : query.length > 0 && results.length === 0 ? (
        <p
          data-testid="rag-empty"
          style={{ fontSize: "0.875rem", color: "color-mix(in srgb, var(--color-text) 55%, transparent)" }}
        >
          No reference documents found.
        </p>
      ) : results.length > 0 ? (
        <ul
          data-testid="rag-results-list"
          style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: "0.5rem" }}
        >
          {results.map((result) => (
            <li
              key={result.id}
              data-testid={`rag-result-${result.id}`}
              data-score={result.score}
              style={{
                padding: "0.625rem 0.75rem",
                border: "1px solid var(--color-border)",
                borderRadius: "var(--radius, 6px)",
                background: "var(--color-surface)",
                display: "flex",
                flexDirection: "column",
                gap: "0.25rem",
              }}
            >
              <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "0.5rem" }}>
                <span style={{ fontSize: "0.875rem", fontWeight: 500, color: "var(--color-text)" }}>
                  {result.title}
                </span>
                <span
                  data-testid={`rag-score-${result.id}`}
                  style={{
                    fontSize: "0.6875rem",
                    fontWeight: 600,
                    color: "color-mix(in srgb, var(--color-primary) 80%, transparent)",
                    whiteSpace: "nowrap",
                    flexShrink: 0,
                  }}
                >
                  {Math.round(result.score * 100)}%
                </span>
              </div>
              <p style={{ margin: 0, fontSize: "0.8125rem", color: "color-mix(in srgb, var(--color-text) 65%, transparent)" }}>
                {result.snippet}
              </p>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
