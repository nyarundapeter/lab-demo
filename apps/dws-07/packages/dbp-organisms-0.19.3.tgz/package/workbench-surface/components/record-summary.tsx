import React from "react";
import { Skeleton, Separator, Alert, EmptyState, FieldValue } from "@dbp/ui";
import type { WorkbenchSurfaceConfig } from "../types.js";
import type { EntityData } from "@dbp/ps-data/client";

interface Props {
  entityType: string;
  entityId: string;
  sections: WorkbenchSurfaceConfig["sections"];
  data: EntityData | undefined;
  isLoading: boolean;
  error: Error | null;
}

export function RecordSummary({ entityType, entityId, sections, data, isLoading, error }: Props) {
  if (error) {
    const is404 =
      error.message.includes("404") || error.message.toLowerCase().includes("not found");
    return is404 ? (
      <EmptyState
        title="Entity not found"
        description={`No record was found for ${entityType}/${entityId}.`}
        data-testid="record-error"
        role="alert"
      />
    ) : (
      <Alert tone="danger" title="Failed to load record" data-testid="record-error">
        {error.message}
      </Alert>
    );
  }

  if (isLoading) {
    return (
      <div
        data-testid="record-skeleton"
        aria-busy="true"
        style={{ display: "flex", flexDirection: "column", gap: "1rem" }}
      >
        <Skeleton className="h-6 w-48" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-8" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div data-testid="record-summary">
      {sections.map((section, si) => (
        <React.Fragment key={section.title}>
          {si > 0 ? <Separator style={{ margin: "0.75rem 0" }} /> : null}
          <div style={{ marginTop: si === 0 ? 0 : "0.25rem" }}>
            <p
              style={{
                margin: "0 0 0.5rem",
                fontSize: "0.6875rem",
                fontWeight: 600,
                textTransform: "uppercase",
                letterSpacing: "0.05em",
                color: "color-mix(in srgb, var(--color-text) 55%, transparent)",
              }}
            >
              {section.title}
            </p>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "0.625rem 1rem",
              }}
            >
              {section.fields.map((fd) => (
                <div key={fd.field} data-testid={`field-${fd.field}`}>
                  <p
                    style={{
                      margin: "0 0 0.125rem",
                      fontSize: "0.6875rem",
                      color: "color-mix(in srgb, var(--color-text) 50%, transparent)",
                    }}
                  >
                    {fd.label}
                  </p>
                  <div style={{ fontSize: "0.875rem", fontWeight: 500 }}>
                    <FieldValue value={data?.[fd.field]} format={fd.format} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}
