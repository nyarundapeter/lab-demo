import React from "react";
import { z } from "zod";
import { Alert } from "@dbp/ui";
import { WorkbenchSurfaceConfig } from "./types.js";
import { RecordSummary } from "./components/record-summary.js";
import { RagLookupZone } from "./components/rag-lookup-zone.js";
import { RecommendationsZone } from "./components/recommendations-zone.js";
import { AssistantZone } from "./components/assistant-zone.js";
import { useWorkbenchEntity } from "./hooks/use-workbench-entity.js";

type ConfigInput = z.input<typeof WorkbenchSurfaceConfig>;

/**
 * APP.F09 — Specialist Workbench Surface
 *
 * Expert/regulatory processing canvas for SH.04's workbench slot.
 * Receives CONFIG, never data. Each zone independently fetches via PS.*.
 *
 * Config is validated at render time via WorkbenchSurfaceConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 */
export default function WorkbenchSurface(rawConfig: ConfigInput) {
  const parseResult = WorkbenchSurfaceConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="WorkbenchSurface configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-5">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <WorkbenchSurfaceInner config={parseResult.data} />;
}

// Re-export types so consumers can import from the root.
export type {
  WorkbenchSurfaceConfig,
  WorkbenchSectionDef,
  WorkbenchFieldDef,
  WorkbenchRecommendationsConfig,
} from "./types.js";

// ─── Inner component (config is guaranteed valid here) ────────────────────────

interface InnerProps {
  config: WorkbenchSurfaceConfig;
}

function WorkbenchSurfaceInner({ config }: InnerProps) {
  const {
    entityType,
    entityId,
    sections,
    ragScope,
    recommendations,
    assistant,
    assistantContext,
  } = config;

  const { data, isLoading, error } = useWorkbenchEntity(entityType, entityId);

  return (
    <div
      data-testid="workbench-surface"
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "1.25rem",
        width: "100%",
        height: "100%",
      }}
    >
      {/* Record summary — always rendered */}
      <section
        data-testid="record-summary-section"
        style={{
          padding: "1rem",
          border: "1px solid var(--color-border)",
          borderRadius: "var(--radius, 6px)",
          background: "var(--color-surface)",
        }}
      >
        <RecordSummary
          entityType={entityType}
          entityId={entityId}
          sections={sections}
          data={data}
          isLoading={isLoading}
          error={error}
        />
      </section>

      {/* Middle + side zone: RAG lookup and assistant side by side at xl */}
      {(ragScope !== undefined || assistant) && (
        <div
          style={{
            display: "grid",
            gap: "1.25rem",
            gridTemplateColumns: ragScope !== undefined && assistant
              ? "minmax(0, 1fr) minmax(0, 320px)"
              : "1fr",
          }}
        >
          {ragScope !== undefined && (
            <section
              style={{
                padding: "1rem",
                border: "1px solid var(--color-border)",
                borderRadius: "var(--radius, 6px)",
                background: "var(--color-surface)",
              }}
            >
              <RagLookupZone ragScope={ragScope} />
            </section>
          )}

          {assistant && (
            <AssistantZone
              entityType={entityType}
              entityId={entityId}
              {...(assistantContext !== undefined && { extraContext: assistantContext })}
            />
          )}
        </div>
      )}

      {/* Recommendations — bottom zone */}
      {recommendations !== undefined && (
        <section
          style={{
            padding: "1rem",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius, 6px)",
            background: "var(--color-surface)",
          }}
        >
          <RecommendationsZone config={recommendations} />
        </section>
      )}
    </div>
  );
}
