import { z } from "zod";

// ─── Field and section definitions (same shape as entity-detail) ──────────────

const FieldFormat = z.enum(["text", "number", "date", "badge"]);

const FieldDef = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
  format: FieldFormat.optional(),
});

const SectionDef = z.object({
  title: z.string().min(1),
  fields: z.array(FieldDef).min(1),
});

// ─── Recommendations config ───────────────────────────────────────────────────

const RecommendationsConfig = z.object({
  /** The PS.DATA entity type forwarded to PS.AI /recommend. */
  entity: z.string().min(1),
  /** Optional freeform context forwarded to /recommend. */
  context: z.record(z.string(), z.unknown()).optional(),
  /** Section heading rendered above the recommendation cards. */
  title: z.string().optional(),
});

// ─── Top-level config ─────────────────────────────────────────────────────────

/**
 * WorkbenchSurfaceConfig — the single typed contract for APP.F09.
 *
 * Data-only; no function fields (Zod schemas are data-only).
 */
export const WorkbenchSurfaceConfig = z.object({
  /** PS.DATA entity type of the record under expert review. */
  entityType: z.string().min(1),
  /** PS.DATA entity ID of the record under expert review. */
  entityId: z.string().min(1),
  /**
   * Compact field grid shown in the record summary (same shape as
   * entity-detail sections).
   */
  sections: z.array(SectionDef).min(1),
  /**
   * When present, renders a Reference Lookup zone. The specialist can type a
   * free-text query; PS.AI ragSearch is called against this scope (debounced).
   */
  ragScope: z.string().min(1).optional(),
  /**
   * When present, renders a Recommendations zone with PS.AI next-best-action
   * cards ordered by score descending.
   */
  recommendations: RecommendationsConfig.optional(),
  /**
   * When true (default), embeds the AssistantPanel binding from @dbp/ui in a
   * collapsible zone. Set false to suppress the assistant entirely.
   */
  assistant: z.boolean().default(true),
  /**
   * Extra context merged into the AssistantPanel context (merged with the
   * auto-built { entityType, entityId } object). Optional.
   */
  assistantContext: z.record(z.string(), z.unknown()).optional(),
});

export type WorkbenchSurfaceConfig = z.infer<typeof WorkbenchSurfaceConfig>;
export type WorkbenchSectionDef = z.infer<typeof SectionDef>;
export type WorkbenchFieldDef = z.infer<typeof FieldDef>;
export type WorkbenchRecommendationsConfig = z.infer<typeof RecommendationsConfig>;
