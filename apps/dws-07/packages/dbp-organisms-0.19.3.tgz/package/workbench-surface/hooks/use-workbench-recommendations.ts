import { useRecommend } from "@dbp/ps-ai/client";
import type { Recommendation } from "@dbp/ps-ai/client";
import type { WorkbenchRecommendationsConfig } from "../types.js";

export interface WorkbenchRecommendationsResult {
  recommendations: Recommendation[];
  isLoading: boolean;
  error: Error | null;
}

export function useWorkbenchRecommendations(
  config: WorkbenchRecommendationsConfig,
): WorkbenchRecommendationsResult {
  const { recommendations, isLoading, error } = useRecommend(
    config.entity,
    config.context,
  );

  const sorted = [...recommendations].sort((a, b) => b.score - a.score);

  return { recommendations: sorted, isLoading, error };
}
