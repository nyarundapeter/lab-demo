import { useEntity } from "@dbp/ps-data/client";
import type { EntityData } from "@dbp/ps-data/client";

export function useWorkbenchEntity(entityType: string, entityId: string) {
  return useEntity<EntityData>(entityType, entityId);
}
