import { useState } from "react";
import { useDebounce } from "@dbp/ui";
import { useRagSearch } from "@dbp/ps-ai/client";
import type { RagResult } from "@dbp/ps-ai/client";

export interface RagLookupState {
  query: string;
  setQuery: (q: string) => void;
  results: RagResult[];
  isLoading: boolean;
  error: Error | null;
}

const DEBOUNCE_MS = 300;

export function useRagLookup(ragScope: string): RagLookupState {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounce(query, DEBOUNCE_MS);
  const { results, isLoading, error } = useRagSearch(debouncedQuery, ragScope);
  return { query, setQuery, results, isLoading, error };
}
