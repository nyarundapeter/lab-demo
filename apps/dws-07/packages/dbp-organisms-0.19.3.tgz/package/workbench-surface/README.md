# @dbp/organisms/workbench-surface

**registryId:** `APP.F09`

Single-entity policy/document workbench surface with sections and recommendations.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`WorkbenchSurfaceConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `object-page-detail` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/workbench-surface` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
