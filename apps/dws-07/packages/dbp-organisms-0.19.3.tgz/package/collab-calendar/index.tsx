import * as React from "react";
import { ChevronLeft, ChevronRight, Flag, Lock, Plus, Trash2, Users, Zap } from "lucide-react";
import { Alert, AvatarStack, Badge, Button, Input, Popover, PopoverTrigger, PopoverContent } from "@dbp/ui";
import {
  CollabCalendarConfig,
  type CollabCalendarEvent,
  type CollabCalendarEventSource,
  type CollabCalendarConfigInput,
} from "./types.js";
import { buildMonthGrid, formatHour, formatMonthLabel, toDateKey, weekdayLabels } from "./lib/date-utils.js";

export interface CollabCalendarProps extends CollabCalendarConfigInput {
  /** Fires when a "meeting" event is created via the day-cell CreatePopover. */
  onCreateEvent?: (event: { title: string; date: string; startHour: number; endHour: number }) => void;
}

const SOURCE_META: Record<CollabCalendarEventSource, { label: string; dotClass: string; textClass: string; surfaceClass: string; readonly: boolean }> = {
  meeting: {
    label: "Meetings",
    dotClass: "bg-[var(--color-info)]",
    textClass: "text-[var(--color-info-text)]",
    surfaceClass: "bg-[var(--color-info-surface)] border-l-2 border-l-[var(--color-info)]",
    readonly: false,
  },
  workflow: {
    label: "Workflow due dates",
    dotClass: "bg-[var(--color-testing)]",
    textClass: "text-[var(--color-testing-text)]",
    surfaceClass: "bg-[var(--color-testing-surface)] border-l-2 border-l-[var(--color-testing)]",
    readonly: true,
  },
  sla: {
    label: "SLA deadlines",
    dotClass: "bg-[var(--color-danger)]",
    textClass: "text-[var(--color-danger-text)]",
    surfaceClass: "bg-[var(--color-danger-surface)] border-l-2 border-l-[var(--color-danger)]",
    readonly: true,
  },
};

/**
 * APP.F56 — Collaboration Calendar (registry id assigned during central
 * registration)
 *
 * collaboration-system/calendar.jsx `CalendarPage`/`EventPill`/`EventDetail`/
 * `CreatePopover`, month view. **Scope note**: the reference also ships a
 * week/day-grid view (hourly columns) — this build ports the month view only
 * (the primary, most-used surface per the reference's own default `view`
 * state); week view is a follow-up, see FEATURE.md.
 */
export default function CollabCalendar(rawConfig: CollabCalendarProps) {
  const { onCreateEvent, ...rest } = rawConfig;
  const parseResult = CollabCalendarConfig.safeParse(rest);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="CollabCalendar configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>{e.path.join(".") || "root"}: {e.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <CollabCalendarInner config={parseResult.data} {...(onCreateEvent !== undefined && { onCreateEvent })} />;
}

function CollabCalendarInner({
  config,
  onCreateEvent,
}: {
  config: CollabCalendarConfig;
  onCreateEvent?: (event: { title: string; date: string; startHour: number; endHour: number }) => void;
}) {
  const todayIso = config.todayIso ?? toDateKey(new Date());
  const todayDate = React.useMemo(() => new Date(`${todayIso}T00:00:00`), [todayIso]);
  const [cursor, setCursor] = React.useState(() => new Date(todayDate.getFullYear(), todayDate.getMonth(), 1));
  const [events, setEvents] = React.useState<CollabCalendarEvent[]>(config.events);
  const [detailFor, setDetailFor] = React.useState<CollabCalendarEvent | null>(null);
  const [createFor, setCreateFor] = React.useState<string | null>(null);

  React.useEffect(() => setEvents(config.events), [config.events]);

  const evByDate = React.useMemo(() => {
    const m: Record<string, CollabCalendarEvent[]> = {};
    for (const e of events) {
      (m[e.date] ??= []).push(e);
    }
    return m;
  }, [events]);

  const cells = React.useMemo(() => buildMonthGrid(cursor.getFullYear(), cursor.getMonth()), [cursor]);
  const dow = React.useMemo(() => weekdayLabels(), []);

  function shift(dir: 1 | -1) {
    setCursor((c) => new Date(c.getFullYear(), c.getMonth() + dir, 1));
  }

  function createEvent(dateKey: string, data: { title: string; startHour: number; endHour: number }) {
    const event: CollabCalendarEvent = {
      id: `e${Date.now()}`,
      title: data.title,
      date: dateKey,
      source: "meeting",
      allDay: false,
      startHour: data.startHour,
      endHour: data.endHour,
      attendees: [],
    };
    setEvents((es) => [...es, event]);
    setCreateFor(null);
    onCreateEvent?.({ title: data.title, date: dateKey, startHour: data.startHour, endHour: data.endHour });
  }

  return (
    <div className="flex h-full flex-col" data-testid="collab-calendar">
      {/* toolbar */}
      <div className="flex flex-wrap items-center gap-2.5 border-b border-[var(--color-border-default)] px-4 py-2.5">
        <Button type="button" variant="outline" size="sm" onClick={() => setCursor(new Date(todayDate.getFullYear(), todayDate.getMonth(), 1))}>
          Today
        </Button>
        <div className="flex gap-0.5">
          <Button type="button" variant="ghost" size="icon" aria-label="Previous month" onClick={() => shift(-1)}>
            <ChevronLeft size={16} aria-hidden="true" />
          </Button>
          <Button type="button" variant="ghost" size="icon" aria-label="Next month" onClick={() => shift(1)}>
            <ChevronRight size={16} aria-hidden="true" />
          </Button>
        </div>
        <span className="min-w-[170px] text-base font-semibold" data-testid="period-label">
          {formatMonthLabel(cursor.getFullYear(), cursor.getMonth())}
        </span>
        <div className="flex-1" />
        <div className="flex gap-3">
          {(Object.entries(SOURCE_META) as [CollabCalendarEventSource, (typeof SOURCE_META)[CollabCalendarEventSource]][]).map(([key, meta]) => (
            <span key={key} className="flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
              <span className={`h-1.5 w-1.5 rounded-sm ${meta.dotClass}`} aria-hidden="true" />
              {meta.label}
              {meta.readonly && <Lock size={10} aria-hidden="true" />}
            </span>
          ))}
        </div>
      </div>

      {events.length === 0 && (
        <p className="border-b border-[var(--color-border-default)] px-4 py-2 text-xs text-[var(--color-text-muted)]" data-testid="calendar-empty-hint">
          This calendar is empty — click any day to schedule a meeting, or connect a workflow/SLA source to see their due dates here.
        </p>
      )}

      {/* month grid */}
      <div className="grid flex-shrink-0 grid-cols-7">
        {dow.map((d) => (
          <div key={d} className="border-b border-[var(--color-border-default)] px-2 py-1.5 text-center text-xs font-semibold uppercase text-[var(--color-text-muted)]">
            {d}
          </div>
        ))}
      </div>
      <div className="grid flex-1 auto-rows-fr grid-cols-7 overflow-y-auto">
        {cells.map((dateKey) => {
          const inMonth = new Date(`${dateKey}T00:00:00`).getMonth() === cursor.getMonth();
          const isToday = dateKey === todayIso;
          const dayEvents = evByDate[dateKey] ?? [];
          const shown = dayEvents.slice(0, 3);
          const more = dayEvents.length - shown.length;
          const dayNum = Number(dateKey.slice(-2));
          return (
            <Popover key={dateKey} open={createFor === dateKey} onOpenChange={(open) => setCreateFor(open ? dateKey : null)}>
              <PopoverTrigger asChild>
                <div
                  data-testid={`cal-cell-${dateKey}`}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if ((e.key === "Enter" || e.key === " ") && e.target === e.currentTarget) {
                      e.preventDefault();
                      setCreateFor(dateKey);
                    }
                  }}
                  className={`min-h-[92px] cursor-pointer border-b border-r border-[var(--color-border-default)] p-1.5 ${inMonth ? "" : "bg-[var(--color-surface)] opacity-60"}`}
                >
                  <span
                    className={`mb-1 inline-flex h-5 w-5 items-center justify-center rounded-full text-xs ${
                      isToday ? "bg-[var(--color-primary)] font-bold text-white" : "text-[var(--color-text-muted)]"
                    }`}
                  >
                    {dayNum}
                  </span>
                  <div className="flex flex-col gap-0.5">
                    {shown.map((ev) => (
                      <EventPill key={ev.id} event={ev} open={detailFor?.id === ev.id} onOpenChange={(open) => setDetailFor(open ? ev : null)} />
                    ))}
                    {more > 0 && <span className="pl-1 text-xs text-[var(--color-text-muted)]">+{more} more</span>}
                  </div>
                </div>
              </PopoverTrigger>
              <PopoverContent data-testid="create-event-popover">
                <CreatePopover dateKey={dateKey} onCreate={(data) => createEvent(dateKey, data)} onClose={() => setCreateFor(null)} />
              </PopoverContent>
            </Popover>
          );
        })}
      </div>
    </div>
  );
}

function EventPill({
  event,
  open,
  onOpenChange,
}: {
  event: CollabCalendarEvent;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const meta = SOURCE_META[event.source];
  return (
    <Popover open={open} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          data-testid={`event-pill-${event.id}`}
          onClick={(e) => e.stopPropagation()}
          className={`h-auto justify-start gap-1 truncate rounded-[5px] px-1.5 py-0.5 text-left text-xs font-medium ${meta.surfaceClass} ${meta.textClass}`}
        >
          {event.source !== "meeting" && (event.source === "sla" ? <Flag size={11} aria-hidden="true" /> : <Zap size={11} aria-hidden="true" />)}
          {event.source === "meeting" && !event.allDay && event.startHour !== undefined && (
            <span className="opacity-80">{formatHour(event.startHour)}</span>
          )}
          <span className="truncate">{event.title}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent data-testid="event-detail-popover" onClick={(e) => e.stopPropagation()}>
        <EventDetail event={event} />
      </PopoverContent>
    </Popover>
  );
}

function EventDetail({ event }: { event: CollabCalendarEvent }) {
  const meta = SOURCE_META[event.source];
  return (
    <div className="w-[240px]" data-testid="event-detail">
      <div className="flex items-start gap-2">
        <span className={`mt-1 h-1.5 w-1.5 shrink-0 rounded-sm ${meta.dotClass}`} aria-hidden="true" />
        <div>
          <div className="text-sm font-semibold">{event.title}</div>
          <div className="mt-0.5 text-xs text-[var(--color-text-muted)]">
            {event.allDay || event.startHour === undefined || event.endHour === undefined
              ? "All day"
              : `${formatHour(event.startHour)} – ${formatHour(event.endHour)}`}
          </div>
        </div>
      </div>
      <div className="mt-2 flex flex-col gap-1.5 text-xs">
        <span className="flex items-center gap-1.5">
          {meta.label.replace(/s$/, "")}
          {meta.readonly && (
            <Badge tone="gray" size="sm">
              <Lock size={9} aria-hidden="true" /> read-only
            </Badge>
          )}
        </span>
        {event.recordLabel && <span className="text-[var(--color-text-muted)]">{event.recordLabel}</span>}
        {event.attendees.length > 0 && (
          <span className="flex items-center gap-2">
            <Users size={13} aria-hidden="true" className="text-[var(--color-text-muted)]" />
            <AvatarStack items={event.attendees.map((a) => ({ name: a.name, ...(a.avatarSrc !== undefined && { src: a.avatarSrc }) }))} max={5} size="sm" />
          </span>
        )}
      </div>
      {meta.readonly ? (
        <p className="mt-2 flex items-center gap-1.5 border-t border-[var(--color-border-default)] pt-2 text-xs text-[var(--color-text-muted)]">
          <Zap size={12} aria-hidden="true" /> Synced from the work system — edit on the record.
        </p>
      ) : (
        <div className="mt-2 flex gap-1.5 border-t border-[var(--color-border-default)] pt-2">
          <Button type="button" variant="outline" size="sm" className="flex-1">
            Edit
          </Button>
          <Button type="button" variant="ghost" size="icon" aria-label="Delete">
            <Trash2 size={14} aria-hidden="true" />
          </Button>
        </div>
      )}
    </div>
  );
}

function CreatePopover({
  dateKey,
  onCreate,
  onClose,
}: {
  dateKey: string;
  onCreate: (data: { title: string; startHour: number; endHour: number }) => void;
  onClose: () => void;
}) {
  const [title, setTitle] = React.useState("");
  const [start, setStart] = React.useState(10);
  const [duration, setDuration] = React.useState(1);
  const dateLabel = new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(
    new Date(`${dateKey}T00:00:00`),
  );

  return (
    <div className="w-[280px]" data-testid="create-event-form">
      <Input
        autoFocus
        placeholder="Event title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        aria-label="Event title"
        className="mb-2"
      />
      <div className="mb-2.5 flex items-center gap-2 text-xs text-[var(--color-text-muted)]">
        <span className="text-[var(--color-text)]">{dateLabel}</span>
        <select
          aria-label="Start time"
          className="rounded-input border border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-1.5 py-1 text-xs"
          value={start}
          onChange={(e) => setStart(Number(e.target.value))}
        >
          {Array.from({ length: 12 }, (_, i) => i + 8).map((h) => (
            <option key={h} value={h}>
              {formatHour(h)}
            </option>
          ))}
        </select>
        <select
          aria-label="Duration"
          className="rounded-input border border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-1.5 py-1 text-xs"
          value={duration}
          onChange={(e) => setDuration(Number(e.target.value))}
        >
          <option value={0.5}>30m</option>
          <option value={1}>1h</option>
          <option value={1.5}>1.5h</option>
          <option value={2}>2h</option>
        </select>
      </div>
      <div className="flex justify-end gap-1.5 border-t border-[var(--color-border-default)] pt-2">
        <Button type="button" variant="ghost" size="sm" onClick={onClose}>
          Cancel
        </Button>
        <Button
          type="button"
          size="sm"
          disabled={!title.trim()}
          onClick={() => onCreate({ title: title.trim(), startHour: start, endHour: start + duration })}
          data-testid="create-event-submit"
        >
          <Plus size={13} aria-hidden="true" /> Create event
        </Button>
      </div>
    </div>
  );
}

export type {
  CollabCalendarConfig,
  CollabCalendarConfigInput,
  CollabCalendarEvent,
  CollabCalendarEventInput,
  CollabCalendarAttendee,
  CollabCalendarEventSource,
} from "./types.js";
