# @dbp/organisms/collab-calendar

**registryId:** `APP.F56` (placeholder — assigned during central registration)

Month-view calendar merging meetings, PS.WORKFLOW due-dates, and SLA deadlines. Deliberately
distinct from `@dbp/organisms/calendar` (APP.F05) — see FEATURE.md's naming note.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`CollabCalendarConfig` — Zod schema exported from `types.ts` (source of truth). Events arrive
fully resolved via config; no fetch is owned by this organism (see FEATURE.md).

## Consumed by
Bespoke import — mounted at a workspace-level "Calendar" route once a real events fan-out/merge
layer exists to feed it (see FEATURE.md).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/collab-calendar` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.
