/**
 * Pure date-math helpers using only native Date + Intl. Deliberately a
 * self-contained copy for this organism rather than an import from the
 * existing `calendar` feature (APP.F05) — the two are separate packages,
 * see FEATURE.md's "extend-vs-distinct" note.
 */

export function toDateKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Build the grid cells (YYYY-MM-DD) for a month view — always complete weeks (Sun-start). */
export function buildMonthGrid(year: number, month: number): string[] {
  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  const leadingBlanks = first.getDay();
  const gridStart = new Date(year, month, 1 - leadingBlanks);
  const totalDays = leadingBlanks + last.getDate();
  const cellCount = Math.ceil(totalDays / 7) * 7;

  const cells: string[] = [];
  for (let i = 0; i < cellCount; i++) {
    cells.push(toDateKey(new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + i)));
  }
  return cells;
}

export function formatMonthLabel(year: number, month: number): string {
  return new Intl.DateTimeFormat(undefined, { month: "long", year: "numeric" }).format(new Date(year, month, 1));
}

export function weekdayLabels(): string[] {
  const labels: string[] = [];
  for (let i = 0; i < 7; i++) {
    // 2026-01-04 is a Sunday.
    labels.push(new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(new Date(2026, 0, 4 + i)));
  }
  return labels;
}

export function formatHour(h: number): string {
  const hh = Math.floor(h);
  const mm = Math.round((h - hh) * 60);
  const ap = hh >= 12 ? "PM" : "AM";
  const h12 = hh % 12 || 12;
  return `${h12}${mm ? ":" + String(mm).padStart(2, "0") : ""} ${ap}`;
}
