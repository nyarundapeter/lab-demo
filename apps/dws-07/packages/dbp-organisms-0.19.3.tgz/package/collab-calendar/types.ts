import { z } from "zod";

// Config schema for the @dbp/organisms/collab-calendar organism
// (collaboration-system/calendar.jsx `CalendarPage`/`EventPill`/`EventDetail`/
// `CreatePopover`). UI-tier build per Wave 3 Family 4f scope — events arrive
// fully resolved via config (no fetch owned here); a host that wants a
// merged meetings + PS.WORKFLOW-due-date + SLA view supplies that merge as a
// separate fan-out layer feeding `events` (see FEATURE.md's "extend-vs-
// distinct" note — the existing `calendar` feature, APP.F05, is
// single-entity/single-fetch and cannot do this merge itself).

export const CollabCalendarAttendeeSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  avatarSrc: z.string().optional(),
});
export type CollabCalendarAttendee = z.infer<typeof CollabCalendarAttendeeSchema>;

/**
 * `meeting` events are user-created/editable; `workflow`/`sla` are read-only
 * — synced from PS.WORKFLOW due-dates and SLA deadlines respectively
 * (calendar.jsx `SRC` table, `readonly: true` for both).
 */
export const CollabCalendarEventSourceSchema = z.enum(["meeting", "workflow", "sla"]);
export type CollabCalendarEventSource = z.infer<typeof CollabCalendarEventSourceSchema>;

export const CollabCalendarEventSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  /** YYYY-MM-DD, local calendar day. */
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  source: CollabCalendarEventSourceSchema,
  allDay: z.boolean().optional().default(true),
  /** Decimal hour (e.g. 13.5 = 1:30 PM), only meaningful when `allDay` is false. */
  startHour: z.number().min(0).max(24).optional(),
  endHour: z.number().min(0).max(24).optional(),
  attendees: z.array(CollabCalendarAttendeeSchema).optional().default([]),
  /** Linked record label (e.g. "D-4821 · Meridian Logistics"). */
  recordLabel: z.string().optional(),
});
export type CollabCalendarEvent = z.infer<typeof CollabCalendarEventSchema>;
export type CollabCalendarEventInput = z.input<typeof CollabCalendarEventSchema>;

export const CollabCalendarConfig = z.object({
  events: z.array(CollabCalendarEventSchema).default([]),
  /** YYYY-MM-DD used to highlight "today" and seed the initial month. Defaults to the render-time date. */
  todayIso: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});
export type CollabCalendarConfig = z.infer<typeof CollabCalendarConfig>;
/** Pre-parse shape (defaulted fields optional) — what callers/stories/tests construct. */
export type CollabCalendarConfigInput = z.input<typeof CollabCalendarConfig>;
