import React from "react";
import { ArrowLeft, GitBranch, History, Slash, Users } from "lucide-react";
import { Alert, Badge, Button, InfoCard, Input, Progress, Switch, SuggestedAction } from "@dbp/ui";
import type { FeatureFlagsAdminConfig, Flag } from "../types.js";

type Strategy = "percentage" | "role" | "user" | "org" | "env";

const STRATEGIES: { id: Strategy; label: string }[] = [
  { id: "percentage", label: "Percentage" },
  { id: "role", label: "By role" },
  { id: "user", label: "By user" },
  { id: "org", label: "By organisation" },
  { id: "env", label: "By environment" },
];

const ROLLOUT_PRESETS = [0, 10, 25, 50, 100];

interface Props {
  flag: Flag;
  environments: FeatureFlagsAdminConfig["environments"];
  roles: FeatureFlagsAdminConfig["roles"];
  suggestion: FeatureFlagsAdminConfig["suggestion"];
  onBack: () => void;
}

/** Feature flag detail — port of admin-flags.jsx's `FlagDetail`. */
export function FlagDetail({ flag, environments, roles, suggestion, onBack }: Props) {
  const [enabled, setEnabled] = React.useState(flag.status === "active");
  const [rollout, setRollout] = React.useState(flag.rollout);
  const [strategy, setStrategy] = React.useState<Strategy>("percentage");
  const [killed, setKilled] = React.useState(false);

  const live = enabled && !killed;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <Button type="button" variant="ghost" size="sm" className="mb-1" onClick={onBack}>
            <ArrowLeft size={13} />
            Feature flags
          </Button>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold">{flag.label}</h2>
            <Badge tone={killed ? "gray" : flag.status === "active" ? "active" : "info"}>
              {killed ? "inactive" : flag.status}
            </Badge>
            <Badge tone="gray">{flag.env}</Badge>
          </div>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button type="button" variant="outline" size="sm">
            <History size={13} />
            History
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className={!killed ? "border-[var(--color-danger)] text-[var(--color-danger)]" : undefined}
            onClick={() => setKilled(!killed)}
          >
            <Slash size={13} />
            {killed ? "Restore" : "Kill switch"}
          </Button>
        </div>
      </div>

      {killed && (
        <Alert tone="danger" title="Kill switch active">
          This feature is force-disabled for all users regardless of rollout settings. Use only for
          incidents.
        </Alert>
      )}
      {flag.expired && (
        <Alert tone="warning" title="Flag expired">
          This flag passed its end date and is fully rolled out. Consider retiring it and removing the
          conditional code path.
        </Alert>
      )}

      <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[1.5fr_1fr]">
        <div className="flex flex-col gap-4">
          <InfoCard title={`${live ? "Enabled" : "Disabled"} in ${flag.env}`}>
            <div className="flex items-center gap-3.5">
              <p className="flex-1 text-xs text-text-muted">
                {live ? `Serving to ${rollout}% of ${flag.audience.toLowerCase()}` : "Not serving to any users"}
              </p>
              <Switch checked={live} onCheckedChange={setEnabled} disabled={killed} />
            </div>
          </InfoCard>

          <InfoCard title="Rollout strategy">
            <div className="flex flex-col gap-3.5">
              <div className="flex flex-wrap gap-1.5">
                {STRATEGIES.map((s) => (
                  <button
                    type="button"
                    key={s.id}
                    onClick={() => setStrategy(s.id)}
                    className={`rounded-pill border px-2.5 py-1 text-xs font-medium ${
                      strategy === s.id
                        ? "border-primary bg-[color-mix(in_srgb,var(--color-primary)_8%,white)] text-primary"
                        : "border-border-default text-text-secondary hover:bg-[var(--color-neutral-surface)]"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>

              {strategy === "percentage" && (
                <div>
                  <div className="mb-2 flex items-center justify-between text-xs">
                    <span className="font-medium">Rollout percentage</span>
                    <span className="font-mono">{rollout}%</span>
                  </div>
                  <Progress value={rollout} tone="primary" />
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={5}
                    value={rollout}
                    disabled={killed}
                    onChange={(e) => setRollout(Number(e.target.value))}
                    className="mt-2 w-full accent-[var(--color-primary)]"
                    aria-label="Rollout percentage"
                  />
                  <div className="mt-2.5 flex gap-1.5">
                    {ROLLOUT_PRESETS.map((p) => (
                      <button
                        type="button"
                        key={p}
                        onClick={() => setRollout(p)}
                        className={`rounded-pill border px-2 py-0.5 text-xs ${
                          rollout === p ? "border-primary text-primary" : "border-border-default text-text-secondary"
                        }`}
                      >
                        {p}%
                      </button>
                    ))}
                  </div>
                  <p className="mt-3.5 text-xs text-text-muted">
                    Approximately{" "}
                    <strong className="text-[var(--color-text)]">{Math.round(rollout * 18.9)}</strong> of ~1,890
                    eligible users will see this feature.
                  </p>
                </div>
              )}

              {strategy === "role" && (
                <div className="flex flex-col gap-1.5">
                  {roles.slice(0, 4).map((r) => (
                    <label key={r.id} className="flex cursor-pointer items-center gap-2 text-xs">
                      <Switch defaultChecked={false} />
                      <span className="flex-1">{r.name}</span>
                      <span className="text-text-muted">{r.users} users</span>
                    </label>
                  ))}
                </div>
              )}

              {strategy === "env" && (
                <div className="flex flex-col gap-1.5">
                  {environments.map((e) => (
                    <label key={e.id} className="flex cursor-pointer items-center gap-2 text-xs">
                      <Switch defaultChecked={e.id !== "prod"} />
                      <Badge tone="gray">{e.name}</Badge>
                      <span className="flex-1" />
                      {e.id === "prod" && <span className="text-xs text-[var(--color-danger)]">Requires approval</span>}
                    </label>
                  ))}
                </div>
              )}

              {(strategy === "user" || strategy === "org") && (
                <div>
                  <Input
                    className="h-8 text-xs"
                    placeholder={strategy === "user" ? "Search users…" : "Search organisations…"}
                    aria-label={strategy === "user" ? "Target users" : "Target organisations"}
                  />
                </div>
              )}
            </div>
          </InfoCard>

          <InfoCard title="Schedule">
            <div className="grid grid-cols-2 gap-3">
              <label className="flex flex-col gap-1 text-xs">
                <span className="font-medium text-text-secondary">Start date</span>
                <Input className="h-8 text-xs" defaultValue={flag.start ?? "Immediate"} />
              </label>
              <label className="flex flex-col gap-1 text-xs">
                <span className="font-medium text-text-secondary">End date</span>
                <Input className="h-8 text-xs" placeholder="No end date" />
              </label>
            </div>
          </InfoCard>
        </div>

        <div className="flex flex-col gap-4">
          <InfoCard
            title="Details"
            rows={[
              { label: "Key", value: <span className="font-mono text-xs">{flag.name}</span> },
              { label: "Owner", value: flag.owner ?? <span className="text-[var(--color-warning)]">Unassigned</span> },
              { label: "Environment", value: flag.env },
              { label: "Last modified", value: flag.modified ?? "—" },
              { label: "Dependencies", value: flag.deps > 0 ? `${flag.deps} flags` : "None" },
            ]}
          />

          {flag.deps > 0 && (
            <InfoCard title="Dependencies & conflicts">
              <div className="flex flex-col gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <GitBranch size={14} className="shrink-0 text-text-muted" aria-hidden="true" />
                  <span>Depends on {flag.deps} other flag{flag.deps === 1 ? "" : "s"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users size={14} className="shrink-0 text-text-muted" aria-hidden="true" />
                  <span>{Math.round(flag.rollout * 18.9)} active users currently affected</span>
                </div>
              </div>
            </InfoCard>
          )}

          {suggestion && (
            <SuggestedAction
              title={suggestion.title}
              reason={suggestion.reason}
              impact={suggestion.impact}
              records={suggestion.records}
              {...(suggestion.confidence !== undefined && { confidence: suggestion.confidence })}
              permission={suggestion.permission}
              onExplain={onBack}
            />
          )}
        </div>
      </div>
    </div>
  );
}
