import React from "react";
import { AlertTriangle, Download, Plus } from "lucide-react";
import { Alert, Badge, Button, Progress, Tabs, TabsList, TabsTrigger } from "@dbp/ui";
import type { Flag, FlagStatus } from "../types.js";

const STATUS_TONE: Record<FlagStatus, "active" | "info" | "gray" | "warning"> = {
  active: "active",
  scheduled: "info",
  inactive: "gray",
  deprecated: "warning",
};

interface Props {
  flags: Flag[];
  onOpen: (flag: Flag) => void;
}

/** Feature flag list — port of admin-flags.jsx's `FlagsList`. */
export function FlagsList({ flags, onOpen }: Props) {
  const [tab, setTab] = React.useState<"all" | FlagStatus>("all");

  const counts = {
    all: flags.length,
    active: flags.filter((f) => f.status === "active").length,
    scheduled: flags.filter((f) => f.status === "scheduled").length,
    inactive: flags.filter((f) => f.status === "inactive").length,
    deprecated: flags.filter((f) => f.status === "deprecated").length,
  };
  const filtered = tab === "all" ? flags : flags.filter((f) => f.status === tab);
  const warnings = flags.filter((f) => f.noOwnerWarn || f.expired);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold">Feature flags</h2>
            <Badge tone="gray">{flags.length}</Badge>
          </div>
          <p className="mt-1 text-xs text-text-muted">
            Control feature rollout across environments and audiences. Flags decouple deployment from
            release.
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button type="button" variant="outline" size="sm">
            <Download size={13} />
            Export
          </Button>
          <Button type="button" size="sm">
            <Plus size={13} />
            New flag
          </Button>
        </div>
      </div>

      {warnings.length > 0 && (
        <Alert tone="warning" title={`${warnings.length} flags need attention`}>
          Review flag ownership and expiry to keep flag hygiene.
        </Alert>
      )}

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList>
          <TabsTrigger value="all">All ({counts.all})</TabsTrigger>
          <TabsTrigger value="active">Active ({counts.active})</TabsTrigger>
          <TabsTrigger value="scheduled">Scheduled ({counts.scheduled})</TabsTrigger>
          <TabsTrigger value="inactive">Inactive ({counts.inactive})</TabsTrigger>
          <TabsTrigger value="deprecated">Deprecated ({counts.deprecated})</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-border-default text-xs text-text-muted">
              <th className="px-3.5 py-2.5 font-medium">Flag</th>
              <th className="w-[110px] px-3.5 py-2.5 font-medium">Status</th>
              <th className="w-[180px] px-3.5 py-2.5 font-medium">Rollout</th>
              <th className="w-[150px] px-3.5 py-2.5 font-medium">Audience</th>
              <th className="w-[80px] px-3.5 py-2.5 font-medium">Env</th>
              <th className="w-[150px] px-3.5 py-2.5 font-medium">Owner</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="px-3.5 py-8 text-center text-xs text-text-muted" data-testid="flags-empty">
                  No feature flags yet. Create a flag to roll a change out gradually or gate it behind an audience.
                </td>
              </tr>
            )}
            {filtered.map((f) => (
              <tr
                key={f.id}
                className="cursor-pointer border-b border-border-subtle last:border-b-0 hover:bg-[var(--color-neutral-surface)]"
                onClick={() => onOpen(f)}
              >
                <td className="px-3.5 py-2.5">
                  <div className="font-medium">{f.label}</div>
                  <div className="font-mono text-xs text-text-muted">{f.name}</div>
                </td>
                <td className="px-3.5 py-2.5">
                  <Badge tone={STATUS_TONE[f.status]}>{f.status}</Badge>
                </td>
                <td className="px-3.5 py-2.5">
                  <div className="flex items-center gap-2">
                    <Progress
                      value={f.rollout}
                      tone={f.rollout === 100 ? "success" : "primary"}
                      className="flex-1"
                    />
                    <span className="w-9 shrink-0 text-right font-mono text-xs">{f.rollout}%</span>
                  </div>
                </td>
                <td className="px-3.5 py-2.5 text-xs">{f.audience}</td>
                <td className="px-3.5 py-2.5">
                  <Badge tone="gray">{f.env}</Badge>
                </td>
                <td className="px-3.5 py-2.5 text-xs">
                  {f.owner ?? (
                    <span className="inline-flex items-center gap-1 text-[var(--color-warning)]">
                      <AlertTriangle size={12} aria-hidden="true" />
                      No owner
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
