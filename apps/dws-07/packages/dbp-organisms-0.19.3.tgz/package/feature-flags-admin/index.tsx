import React from "react";
import { Alert } from "@dbp/ui";
import { FlagsList } from "./components/flags-list.js";
import { FlagDetail } from "./components/flag-detail.js";
import { FeatureFlagsAdminConfig, type FeatureFlagsAdminConfigInput, type Flag } from "./types.js";

/**
 * Feature-flag runtime management surface: filterable list + a detail page
 * with a master toggle, rollout strategy tabs, schedule, and dependency
 * view. Port of admin-flags.jsx's `FlagsList`/`FlagDetail`, combined into
 * one organism with local list<->detail view state (no route needed).
 *
 * UI-only, prop-driven — no backend call. Per
 * `docs/03-features/specs/admin-system-ingestion-ledger-2026-07-13.md` §J
 * (not auto-decided): the manifest's `feature_flags` block is a build-time
 * release gate ({id,label,enabled}), not the runtime rollout/targeting/
 * kill-switch service this reference models — no `PS.FLAGS` platform
 * service exists today. Documented as an open architecture question, not
 * resolved here, same pattern as `rule-builder`/`schema-entity-detail`.
 */
export default function FeatureFlagsAdmin(config: FeatureFlagsAdminConfigInput) {
  const parsed = FeatureFlagsAdminConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="FeatureFlagsAdmin — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <FeatureFlagsAdminInner config={parsed.data} />;
}

function FeatureFlagsAdminInner({ config }: { config: FeatureFlagsAdminConfig }) {
  const [openFlag, setOpenFlag] = React.useState<Flag | null>(null);

  if (openFlag) {
    return (
      <FlagDetail
        flag={openFlag}
        environments={config.environments}
        roles={config.roles}
        suggestion={config.suggestion}
        onBack={() => setOpenFlag(null)}
      />
    );
  }

  return <FlagsList flags={config.flags} onOpen={setOpenFlag} />;
}
