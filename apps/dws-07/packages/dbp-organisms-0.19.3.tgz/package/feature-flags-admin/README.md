# @dbp/organisms/feature-flags-admin

**registryId:** `APP.F42`

Runtime feature-flag management: filterable list + detail (master toggle, rollout strategy
tabs, schedule, dependencies, kill switch). See `FEATURE.md` for why this ships UI-only — no
`PS.FLAGS` platform service exists today.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`FeatureFlagsAdminConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/flags` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/feature-flags-admin` via plain pnpm
workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
