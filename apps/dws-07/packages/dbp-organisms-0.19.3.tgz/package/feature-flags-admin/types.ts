import { z } from "zod";

export const FlagStatus = z.enum(["active", "scheduled", "inactive", "deprecated"]);
export type FlagStatus = z.infer<typeof FlagStatus>;

const Flag = z.object({
  id: z.string().min(1),
  /** Machine key, e.g. "ai-triage-assist". */
  name: z.string().min(1),
  label: z.string().min(1),
  status: FlagStatus,
  rollout: z.number().min(0).max(100),
  audience: z.string().min(1),
  env: z.string().min(1),
  owner: z.string().optional(),
  desc: z.string().optional(),
  modified: z.string().optional(),
  start: z.string().optional(),
  /** Count of other flags this one depends on. */
  deps: z.number().int().nonnegative().default(0),
  noOwnerWarn: z.boolean().optional(),
  expired: z.boolean().optional(),
});
export type Flag = z.infer<typeof Flag>;

const RoleOption = z.object({ id: z.string().min(1), name: z.string().min(1), users: z.number().int().nonnegative() });
const EnvOption = z.object({ id: z.string().min(1), name: z.string().min(1) });

const AiSuggestion = z.object({
  title: z.string().min(1),
  reason: z.string().min(1),
  impact: z.string().min(1),
  records: z.string().min(1),
  confidence: z.enum(["high", "medium", "low", "insufficient"]).optional(),
  permission: z.string().min(1),
});

export const FeatureFlagsAdminConfig = z.object({
  flags: z.array(Flag),
  environments: z.array(EnvOption).default([]),
  roles: z.array(RoleOption).default([]),
  suggestion: AiSuggestion.optional(),
});

export type FeatureFlagsAdminConfig = z.infer<typeof FeatureFlagsAdminConfig>;
export type FeatureFlagsAdminConfigInput = z.input<typeof FeatureFlagsAdminConfig>;
