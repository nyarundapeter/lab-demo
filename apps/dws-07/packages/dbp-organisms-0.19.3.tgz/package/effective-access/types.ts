import { z } from "zod";

const AccessKind = z.enum(["allow", "deny", "inherit", "none"]);

const ResourceRow = z.object({
  resource: z.string().min(1),
  access: z.enum(["Allowed", "Denied"]),
  /** Where the decision came from, e.g. "Role: Business Administrator", "Explicit deny overrides role". */
  source: z.string().min(1),
  kind: AccessKind,
});

const UserOption = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
});

export const EffectiveAccessConfig = z.object({
  users: z.array(UserOption).min(1),
  defaultUserId: z.string().optional(),
  /** Resolved resource rows keyed by user id. Switching the picker only ever changes which key is read — this component makes no fetch. */
  accessByUser: z.record(z.array(ResourceRow)),
});

export type EffectiveAccessConfig = z.infer<typeof EffectiveAccessConfig>;
export type EffectiveAccessConfigInput = z.input<typeof EffectiveAccessConfig>;
