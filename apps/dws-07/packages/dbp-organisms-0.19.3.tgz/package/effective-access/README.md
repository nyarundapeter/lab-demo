# @dbp/organisms/effective-access

**registryId:** `APP.F41`

Resolves direct grants, inherited role permissions, and explicit denies into a single
Allowed/Denied answer per resource, with a user picker and the resolution source shown.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`EffectiveAccessConfig` — Zod schema exported from `types.ts` (source of truth). Prop-driven —
see `FEATURE.md` for why this ships without a live `PS.RBAC` query despite one being genuinely
buildable today.

## Consumed by
Not yet wired — `scripts/scaffold-solution.mjs`'s `FEATURE_COMPONENT` map does not route
`admin/access-control` to this organism.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/effective-access` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
