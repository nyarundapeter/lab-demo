import React from "react";
import { Check, X } from "lucide-react";
import { Alert, Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@dbp/ui";
import { EffectiveAccessConfig, type EffectiveAccessConfigInput } from "./types.js";

const KIND_TONE: Record<string, string> = {
  allow: "text-[var(--color-success)]",
  inherit: "text-[var(--color-success)]",
  deny: "text-[var(--color-danger)]",
  none: "text-[var(--color-danger)]",
};

/**
 * Resolves direct grants, inherited role permissions, and explicit denies
 * into a single Allowed/Denied answer per resource, with the source shown.
 * Port of admin-specimens.jsx's `EffectiveAccess`.
 *
 * Prop-driven: `accessByUser` supplies pre-resolved rows per user, this
 * component makes no fetch. Per
 * `admin-system-ingestion-ledger-2026-07-13.md` §L, the real resolution
 * (`useCan()`/`getUserAbilities()`/`useAbility()` from `PS.RBAC` v0.2.0) is
 * genuinely buildable today, unlike `PermissionMatrix`'s write path — wiring
 * a live query in is a cheap, real follow-up, not done here to stay
 * consistent with the rest of this family's UI-only lift-and-shift scope.
 */
export default function EffectiveAccess(config: EffectiveAccessConfigInput) {
  const parsed = EffectiveAccessConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="EffectiveAccess — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <EffectiveAccessInner config={parsed.data} />;
}

function EffectiveAccessInner({ config }: { config: EffectiveAccessConfig }) {
  const [userId, setUserId] = React.useState(config.defaultUserId ?? config.users[0]?.id ?? "");
  const rows = config.accessByUser[userId] ?? [];

  return (
    <div className="mx-auto flex max-w-[720px] flex-col gap-3">
      <Select value={userId} onValueChange={setUserId}>
        <SelectTrigger className="h-8 w-[280px] text-xs">
          <SelectValue placeholder="Choose a user…" />
        </SelectTrigger>
        <SelectContent>
          {config.users.map((u) => (
            <SelectItem key={u.id} value={u.id}>
              {u.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <p className="text-xs text-text-muted">
        Effective access resolves direct grants, inherited role permissions, and explicit denies into a
        single answer per resource — and shows the source.
      </p>

      <div className="overflow-hidden rounded-[var(--radius-card)] border border-border-default">
        {rows.length === 0 ? (
          <div className="px-3.5 py-3 text-xs text-text-muted">No resources to show for this user.</div>
        ) : (
          rows.map((r, i) => (
            <div
              key={i}
              className="flex items-center gap-3 px-3.5 py-3"
              style={i < rows.length - 1 ? { borderBottom: "1px solid var(--color-border-subtle)" } : undefined}
            >
              <span className={KIND_TONE[r.kind]} aria-hidden="true">
                {r.kind === "deny" || r.kind === "none" ? <X size={12} /> : <Check size={12} />}
              </span>
              <span className="flex-1 text-sm font-medium">{r.resource}</span>
              <span className={`text-xs font-semibold ${KIND_TONE[r.kind]}`}>{r.access}</span>
              <span className="w-[220px] shrink-0 text-right text-xs text-text-muted">{r.source}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
