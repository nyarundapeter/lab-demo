import * as React from "react";
import { RefreshCw } from "lucide-react";
import { Alert, Button } from "@dbp/ui";
import { TourStageConfig, type TourStageConfigInput } from "./types.js";

export interface TourStageProps {
  config: TourStageConfigInput;
  /** The real app content the tour spotlights — each step's `anchorSelector` is resolved against this. */
  children: React.ReactNode;
  onFinish?: () => void;
  onSkip?: () => void;
}

interface AnchorBox {
  top: number;
  left: number;
  width: number;
  height: number;
}

/**
 * TourStage — guided-tour spotlight: anchored coach marks over real anchored
 * elements in `children` (via `[data-tour-anchor]`), so the spotlight
 * survives layout changes instead of using fixed coordinates. Port of
 * `identity-firstrun.jsx`'s `TourStage`. Owns its own step index and
 * active/replay state — genuinely new.
 */
export default function TourStage({ config, children, onFinish, onSkip }: TourStageProps) {
  const parsed = TourStageConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="TourStage — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <TourStageInner config={parsed.data} onFinish={onFinish} onSkip={onSkip}>
      {children}
    </TourStageInner>
  );
}

function TourStageInner({
  config,
  children,
  onFinish,
  onSkip,
}: {
  config: TourStageConfig;
  children: React.ReactNode;
  onFinish?: (() => void) | undefined;
  onSkip?: (() => void) | undefined;
}) {
  const stageRef = React.useRef<HTMLDivElement>(null);
  const [step, setStep] = React.useState(0);
  const [active, setActive] = React.useState(true);
  const [box, setBox] = React.useState<AnchorBox | null>(null);
  const steps = config.steps;
  const current = steps[step]!;

  React.useEffect(() => {
    if (!active) {
      setBox(null);
      return;
    }
    const measure = () => {
      const stage = stageRef.current;
      if (!stage) return;
      const el = stage.querySelector(current.anchorSelector);
      if (!el) return;
      const stageRect = stage.getBoundingClientRect();
      const rect = el.getBoundingClientRect();
      setBox({
        top: rect.top - stageRect.top,
        left: rect.left - stageRect.left,
        width: rect.width,
        height: rect.height,
      });
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [step, active, current.anchorSelector]);

  const pad = 6;
  const coachTop = box ? (current.placement === "right" ? Math.max(12, box.top - 10) : box.top + box.height + pad + 12) : 20;
  const coachLeft = box ? (current.placement === "right" ? box.left + box.width + pad + 12 : Math.min(box.left, 640)) : 20;

  function finish() {
    setActive(false);
    onFinish?.();
  }

  function skip() {
    setActive(false);
    onSkip?.();
  }

  function replay() {
    setStep(0);
    setActive(true);
  }

  return (
    <div ref={stageRef} className="relative" data-testid="tour-stage">
      {children}
      {active && (
        <>
          {box && (
            <div
              aria-hidden="true"
              data-testid="tour-spotlight"
              className="pointer-events-none absolute rounded-[var(--radius-card)] ring-2 ring-white [box-shadow:0_0_0_9999px_rgba(3,15,53,0.55)]"
              style={{ top: box.top - pad, left: box.left - pad, width: box.width + pad * 2, height: box.height + pad * 2 }}
            />
          )}
          <div
            className="absolute z-10 w-[280px] rounded-[var(--radius-modal)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] p-4 shadow-[var(--shadow-xl)]"
            style={{ top: coachTop, left: coachLeft }}
            data-testid="tour-coach"
          >
            <p className="text-xs font-semibold uppercase tracking-[0.05em] text-primary">
              Step {step + 1} of {steps.length}
            </p>
            <p className="mt-1.5 text-sm font-semibold text-primary">{current.title}</p>
            {current.body && <p className="mt-1 text-xs leading-relaxed text-[var(--color-text-muted)]">{current.body}</p>}
            <div className="mt-3 flex items-center justify-between">
              <div className="flex gap-1" aria-hidden="true">
                {steps.map((s, i) => (
                  <span
                    key={s.id}
                    className={"h-1.5 w-1.5 rounded-full " + (i === step ? "bg-primary" : "bg-[var(--color-border-default)]")}
                  />
                ))}
              </div>
              <div className="flex gap-1.5">
                {step > 0 && (
                  <Button variant="ghost" size="sm" onClick={() => setStep((s) => s - 1)} data-testid="tour-back">
                    Back
                  </Button>
                )}
                {step < steps.length - 1 ? (
                  <Button size="sm" onClick={() => setStep((s) => s + 1)} data-testid="tour-next">
                    Next
                  </Button>
                ) : (
                  <Button size="sm" onClick={finish} data-testid="tour-finish">
                    Finish
                  </Button>
                )}
              </div>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={skip}
            data-testid="tour-skip"
            // Deliberate keep: translucent white overlay tint on a dark tour-spotlight
            // backdrop, not a themeable surface fill — bg-white/15 is intentional here.
            className="absolute right-3.5 top-3.5 z-10 text-white hover:bg-white/15 hover:text-white"
          >
            Skip tour
          </Button>
        </>
      )}
      {!active && (
        <div className="absolute bottom-4 left-4 z-10">
          <Button variant="outline" size="sm" onClick={replay} data-testid="tour-replay">
            <RefreshCw size={13} aria-hidden="true" />
            Replay tour
          </Button>
        </div>
      )}
    </div>
  );
}

export type { TourStageConfig, TourStageConfigInput, TourStep } from "./types.js";
