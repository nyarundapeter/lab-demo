# @dbp/organisms/tour-stage

**registryId:** `APP.F77` (placeholder — assigned during central registration)

Anchored guided-tour spotlight over real app-shell content. See `FEATURE.md`.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`TourStageConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — no `FEATURE_COMPONENT` route in `scripts/scaffold-solution.mjs` targets this
organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/tour-stage` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
