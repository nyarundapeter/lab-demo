import { z } from "zod";

export const TourStep = z.object({
  id: z.string().min(1),
  /** CSS selector resolved within this organism's own `children`, typically `[data-tour-anchor="..."]`. */
  anchorSelector: z.string().min(1),
  title: z.string().min(1),
  body: z.string().optional(),
  placement: z.enum(["bottom", "right"]).default("bottom"),
});
export type TourStep = z.infer<typeof TourStep>;

export const TourStageConfig = z.object({
  steps: z.array(TourStep).min(1),
});
export type TourStageConfig = z.infer<typeof TourStageConfig>;
export type TourStageConfigInput = z.input<typeof TourStageConfig>;
