import { z } from "zod";

export const SsoProviderKind = z.enum(["microsoft", "saml", "ldap", "generic"]);
export type SsoProviderKind = z.infer<typeof SsoProviderKind>;

export const SsoProviderOption = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  kind: SsoProviderKind.default("generic"),
  /** Short helper line under the name, e.g. "Recommended" or a domain hint. */
  sub: z.string().optional(),
  /** OIDC/SAML authorize redirect — passed straight through to the "microsoft" kind's `MicrosoftSignInButton`. */
  authorizeUrl: z.string().optional(),
});
export type SsoProviderOption = z.infer<typeof SsoProviderOption>;

export const SsoPickConfig = z.object({
  orgName: z.string().min(1),
  orgDomain: z.string().optional(),
  providers: z.array(SsoProviderOption).default([]),
  allowPasswordFallback: z.boolean().default(true),
  enforcedNote: z.string().default("Enforced by your admin · SSO required for this workspace"),
});
export type SsoPickConfig = z.infer<typeof SsoPickConfig>;
export type SsoPickConfigInput = z.input<typeof SsoPickConfig>;
