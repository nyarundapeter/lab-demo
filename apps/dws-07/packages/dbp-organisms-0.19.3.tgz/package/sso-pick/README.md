# @dbp/organisms/sso-pick

**registryId:** `APP.F75` (placeholder — assigned during central registration)

Public sign-in provider picker (Microsoft/Entra + SAML/LDAP + email fallback). See `FEATURE.md`
for the reuse composition.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`SsoPickConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Not yet wired — no `FEATURE_COMPONENT` route in `scripts/scaffold-solution.mjs` targets this
organism yet.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/sso-pick` via plain pnpm workspace resolution
(`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.

See [../CHANGELOG.md](../CHANGELOG.md) for release history (tracked at the `@dbp/organisms`
package level, not per-feature).
