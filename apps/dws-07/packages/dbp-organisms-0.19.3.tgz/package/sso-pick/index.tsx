import * as React from "react";
import { ChevronLeft, ChevronRight, Mail } from "lucide-react";
import { Alert, Button, LoginCredentialsForm, MicrosoftSignInButton, OrgBadge } from "@dbp/ui";
import { SsoPickConfig, type SsoPickConfigInput, type SsoProviderOption } from "./types.js";

export interface SsoPickProps {
  config: SsoPickConfigInput;
  /** Non-Microsoft provider buttons (SAML/LDAP/generic) — Microsoft/Entra redirects for real via `MicrosoftSignInButton`. */
  onSelectProvider?: (provider: SsoProviderOption) => void;
  /** Email-fallback path. */
  onPasswordSubmit?: (credentials: { email: string; password: string }) => void;
  passwordLoading?: boolean;
  passwordError?: string | null;
}

/**
 * SsoPick — public sign-in provider picker: identity-provider buttons with
 * a plain-email fallback that swaps in a credentials form. Port of
 * `identity-mfa.jsx`'s `SsoPick`. Thin composition, not a fresh build — the
 * Microsoft/Entra branch reuses the real `MicrosoftSignInButton` (redirects
 * to the actual PS.AUTH OIDC authorize endpoint) and the email fallback
 * reuses `LoginCredentialsForm` (ADR-0035) verbatim. Only the SAML/LDAP/
 * generic provider row (no dedicated button component exists for those) is
 * new UI. Meant to be mounted as the `children` of `@dbp/ui/auth-layout`'s
 * `AuthLayout`.
 */
export default function SsoPick({ config, onSelectProvider, onPasswordSubmit, passwordLoading, passwordError }: SsoPickProps) {
  const parsed = SsoPickConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="SsoPick — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <SsoPickInner
      config={parsed.data}
      onSelectProvider={onSelectProvider}
      onPasswordSubmit={onPasswordSubmit}
      passwordLoading={passwordLoading}
      passwordError={passwordError}
    />
  );
}

function SsoPickInner({
  config,
  onSelectProvider,
  onPasswordSubmit,
  passwordLoading,
  passwordError,
}: {
  config: SsoPickConfig;
  onSelectProvider?: ((provider: SsoProviderOption) => void) | undefined;
  onPasswordSubmit?: ((credentials: { email: string; password: string }) => void) | undefined;
  passwordLoading?: boolean | undefined;
  passwordError?: string | null | undefined;
}) {
  const [emailMode, setEmailMode] = React.useState(false);

  if (emailMode) {
    return (
      <div className="flex flex-col gap-4" data-testid="sso-pick-email-form">
        <LoginCredentialsForm
          onSubmit={(c) => onPasswordSubmit?.(c)}
          loading={passwordLoading ?? false}
          {...(passwordError !== undefined && { error: passwordError })}
        />
        <Button variant="ghost" className="w-full" onClick={() => setEmailMode(false)} data-testid="sso-pick-back">
          <ChevronLeft size={14} aria-hidden="true" />
          Back to sign-in options
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5" data-testid="sso-pick">
      <OrgBadge name={config.orgName} domain={config.orgDomain} />
      <h1 className="text-lg font-semibold text-primary">Sign in</h1>
      <p className="text-sm text-[var(--color-text-muted)]">Choose how you&rsquo;d like to sign in to {config.orgName}.</p>

      <div className="flex flex-col gap-2.5">
        {config.providers.map((provider) =>
          provider.kind === "microsoft" ? (
            <MicrosoftSignInButton
              key={provider.id}
              label={provider.name}
              {...(provider.authorizeUrl !== undefined && { authorizeUrl: provider.authorizeUrl })}
            />
          ) : (
            <Button
              key={provider.id}
              type="button"
              variant="outline"
              onClick={() => onSelectProvider?.(provider)}
              data-testid={`sso-pick-provider-${provider.id}`}
              className="h-auto w-full justify-start gap-3 rounded-[var(--radius-input)] bg-[var(--color-surface-content)] px-4 py-2.5 text-left text-sm font-medium hover:border-[var(--color-border-strong)]"
            >
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-[var(--radius-button)] text-xs font-bold text-white"
                style={{ background: "var(--color-primary)" }}
                aria-hidden="true"
              >
                {provider.name.slice(0, 1).toUpperCase()}
              </span>
              <span className="min-w-0 flex-1">
                {provider.name}
                {provider.sub && <span className="block text-xs font-normal text-[var(--color-text-muted)]">{provider.sub}</span>}
              </span>
              <ChevronRight size={15} className="text-[var(--color-text-muted)]" aria-hidden="true" />
            </Button>
          ),
        )}
      </div>

      {config.allowPasswordFallback && (
        <>
          <div className="flex items-center gap-3 text-xs text-[var(--color-text-disabled)]">
            <span className="h-px flex-1 bg-[var(--color-border-default)]" />or<span className="h-px flex-1 bg-[var(--color-border-default)]" />
          </div>
          <Button variant="outline" size="lg" className="w-full" onClick={() => setEmailMode(true)} data-testid="sso-pick-use-email">
            <Mail size={15} aria-hidden="true" />
            Sign in with email
          </Button>
        </>
      )}

      <p className="text-center text-xs text-[var(--color-text-disabled)]">{config.enforcedNote}</p>
    </div>
  );
}

export type { SsoPickConfig, SsoPickConfigInput, SsoProviderOption } from "./types.js";
