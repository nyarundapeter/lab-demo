import { z } from "zod";

/** Badge/accent tone — mirrors the `@dbp/ui` `Badge` tone union (incl. the neutral triad). */
export const KanbanToneSchema = z.enum(["neutral", "success", "warning", "danger", "info"]);
export type KanbanTone = z.infer<typeof KanbanToneSchema>;

/**
 * KanbanColumnDef maps a workflow step ID to a board lane.
 * `color` is legacy (a design-token palette key, e.g. "blue"/"amber") —
 * `tone` supersedes it for the column accent + WIP-fill-bar color and should
 * be preferred by new configs; `color` is kept for backward compatibility.
 */
export const KanbanColumnDefSchema = z.object({
  stepId: z.string().min(1),
  label: z.string().min(1),
  color: z.string().optional(),
  /** Column accent tone. Defaults to "neutral". */
  tone: KanbanToneSchema.default("neutral"),
  /** Soft WIP limit for this column. Omitted = no limit shown. */
  wipLimit: z.number().int().positive().optional(),
});
export type KanbanColumnDef = z.infer<typeof KanbanColumnDefSchema>;

/**
 * CardFieldsConfig selects which context fields appear on each card.
 * Fields are keys into WorkflowInstance.context (Record<string, unknown>).
 *
 * `subtitleField`/`badgeField` are the original (0.1.0) fields, kept for
 * backward compatibility — `metaField`/`statusField` are their richer
 * successors (a status field renders as the card's primary tone chip,
 * `badgeField` still renders as a fallback secondary chip when `statusField`
 * is unset). All new fields are optional and additive.
 */
export const CardFieldsConfigSchema = z.object({
  titleField: z.string().min(1),
  subtitleField: z.string().optional(),
  badgeField: z.string().optional(),
  /** Secondary meta line shown next to the subtitle (e.g. category). */
  metaField: z.string().optional(),
  /** Drives the risk/priority chip tone via a caller-owned value→tone mapping is out of scope here — the raw value is shown, tone falls back to "neutral". */
  riskField: z.string().optional(),
  /** Drives the card's primary status chip label. */
  statusField: z.string().optional(),
  /** Assignee display name. Empty/missing renders an "Unassigned" placeholder. */
  assigneeField: z.string().optional(),
  /** ISO date string. Renders formatted; danger+bold when in the past. */
  dueDateField: z.string().optional(),
  /** Boolean/truthy field. When true the card is a locked compliance-hold: drag is refused. */
  lockField: z.string().optional(),
  /** Shown in the card's kebab menu in place of "Move to…" when locked. */
  lockReasonField: z.string().optional(),
  /** Array-of-strings field (e.g. `["urgent","external"]`). Renders as `#tag` chips on the card. */
  tagsField: z.string().optional(),
});
export type CardFieldsConfig = z.infer<typeof CardFieldsConfigSchema>;

/**
 * A board-level, one-click filter chip. `kind: "equals"` (default) matches
 * `context[field] === value`; `kind: "overdue"` ignores `field`/`value` and
 * matches cards whose `cardFields.dueDateField` is in the past (mirrors the
 * design ref's "Overdue" chip, which is date-relative rather than a static
 * equality check). `kind: "me"` matches `context[field ?? cardFields.assigneeField]`
 * against the board's `currentUserId` prop (a session-resolved value, not
 * manifest config — see KanbanBoard's ConfigInput) — this is what makes a
 * real "My items" chip expressible, unlike a static `equals`.
 */
export const KanbanFilterChipConfigSchema = z
  .object({
    id: z.string().min(1),
    label: z.string().min(1),
    kind: z.enum(["equals", "overdue", "me"]).default("equals"),
    field: z.string().min(1).optional(),
    value: z.union([z.string(), z.number(), z.boolean()]).optional(),
  })
  .refine((c) => c.kind !== "equals" || (c.field !== undefined && c.value !== undefined), {
    message: "field and value are required when kind is \"equals\"",
  });
export type KanbanFilterChipConfig = z.infer<typeof KanbanFilterChipConfigSchema>;

/** Every copy string the board renders — all optional, all sensibly defaulted. */
export const KanbanLabelsSchema = z
  .object({
    title: z.string().min(1).optional(),
    subtitle: z.string().min(1).optional(),
    searchPlaceholder: z.string().min(1).optional(),
    clearAll: z.string().min(1).optional(),
    emptyBoardTitle: z.string().min(1).optional(),
    emptyBoardBody: z.string().min(1).optional(),
    errorTitle: z.string().min(1).optional(),
    errorBody: z.string().min(1).optional(),
    retry: z.string().min(1).optional(),
    emptyColumn: z.string().min(1).optional(),
    emptyColumnFiltered: z.string().min(1).optional(),
    dropInvite: z.string().min(1).optional(),
    overWipLimit: z.string().min(1).optional(),
    moveTo: z.string().min(1).optional(),
    holdChip: z.string().min(1).optional(),
    unassigned: z.string().min(1).optional(),
    /** Noun used in the toolbar's "{n} of {total} {itemNoun}" result summary. Defaults to "cases". */
    itemNoun: z.string().min(1).optional(),
    /** Label for the synthetic trailing column collecting cards whose step matches no configured column. */
    uncategorized: z.string().min(1).optional(),
    /** Title of the board-level panel shown when active filters match nothing anywhere on the board. */
    noResultsTitle: z.string().min(1).optional(),
    /** No-date placeholder shown in place of a due-date label when the field is configured but unset. */
    noDate: z.string().min(1).optional(),
    /** Board-view segment label (only shown when showViewToggle is true). */
    boardView: z.string().min(1).optional(),
    /** Table-view segment label (only shown when showViewToggle is true). */
    tableView: z.string().min(1).optional(),
    /** Table-view "column" header — the workflow step/board-column a row is in. */
    tableColumnHeader: z.string().min(1).optional(),
  })
  .default({});
export type KanbanLabels = z.infer<typeof KanbanLabelsSchema>;

/**
 * `KanbanLabels` with every key resolved (defaults applied, `undefined`
 * stripped) — `Required<KanbanLabels>` alone is not enough because zod's
 * `.optional()` fields are typed `string | undefined`, and `Required<>` only
 * removes the `?` modifier, not the `undefined` from the value union.
 */
export type ResolvedKanbanLabels = { [K in keyof KanbanLabels]-?: NonNullable<KanbanLabels[K]> };

/**
 * KanbanConfig — the single typed contract for APP.F04.
 *
 * Data contract only (no function fields — Zod schemas are data-only).
 *
 * LIMITATION: PS.WORKFLOW does not expose GET /instances?definitionId=.
 * Therefore instanceIds must be provided by the consumer. Each ID is fetched
 * via useWorkflow (GET /instances/:id). A PS.WORKFLOW minor is needed to add
 * the list-by-definition endpoint — see FEATURE.md §Limitations.
 */
export const KanbanConfig = z.object({
  /** The workflow definition ID this board visualises (used for display/docs + legal-move derivation). */
  definitionId: z.string().min(1),
  /**
   * Explicit list of workflow instance IDs to display.
   * Required because PS.WORKFLOW lacks GET /instances?definitionId= today.
   * Provide at least one; the board shows an empty state for an empty array.
   */
  instanceIds: z.array(z.string().min(1)).min(0).default([]),
  /** Board column definitions — must cover at least one step. */
  columns: z.array(KanbanColumnDefSchema).min(1),
  /** Which WorkflowInstance.context fields to show on the card. */
  cardFields: CardFieldsConfigSchema,
  /** Show advance button on cards in non-terminal steps. Default true. Also the keyboard/a11y equivalent of a drag onto the "next" column. */
  allowAdvance: z.boolean().default(true),
  /** Show reject button on cards that support rejection. Default true. Also the keyboard/a11y equivalent of a drag onto the "onReject" column. */
  allowReject: z.boolean().default(true),
  /**
   * Enables pointer drag-and-drop card moves. Default true. When false, the
   * board still renders normally and Advance/Reject/the move menu keep
   * working — only the pointer-drag lift is disabled (mirrors the design
   * ref's permission-demo toggle).
   */
  allowDrag: z.boolean().default(true),
  /**
   * Static equality filters applied when grouping instances into columns
   * (server-shape filter, evaluated before client search/chips).
   * E.g. { "status": "running" } hides completed/rejected instances.
   */
  filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
  /** Board-level one-click filter chips (search + chips are combinable). */
  filterChips: z.array(KanbanFilterChipConfigSchema).optional(),
  /** All board copy — see KanbanLabelsSchema for keys and sensible defaults. */
  labels: KanbanLabelsSchema,
  /**
   * Show the KanbanFlowRail step-count strip above the board. Default false —
   * ruled 2026-07-16 (K1): the P2 elevation reference supersedes the earlier
   * vendor-pipeline design as the current visual authority, and no app in
   * this repo wires @dbp/organisms/kanban directly today, so there is no live
   * consumer to break by flipping the default off.
   */
  showFlowRail: z.boolean().default(false),
  /**
   * Item 9 (design-audit-2026-07-17): a SegmentedControl pairing the board
   * with a flat table view of the SAME instance data (title/status/
   * assignee/due/column columns, derived from cardFields) — a self-contained
   * alternative to a full `@dbp/organisms/entity-list` pairing, which would
   * require a PS.DATA-backed entity these demo workflow instances don't have
   * (see FEATURE.md §Limitations). Default false — opt-in, backward-compatible.
   */
  showViewToggle: z.boolean().default(false),
});
export type KanbanConfig = z.infer<typeof KanbanConfig>;
