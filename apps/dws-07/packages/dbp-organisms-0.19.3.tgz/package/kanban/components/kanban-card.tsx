import * as React from "react";
import {
  BoardCard,
  Alert,
  Button,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  cn,
} from "@dbp/ui";
import { MoreVertical, X } from "lucide-react";
import type { WorkflowInstance } from "@dbp/ps-workflow/client";
import type { CardFieldsConfig, KanbanColumnDef, ResolvedKanbanLabels } from "../types.js";
import { resolveCardDisplay, riskTone, resolveDueDisplay } from "../lib/card-fields.js";

export interface KanbanCardProps {
  instance: WorkflowInstance;
  stepId: string;
  cardFields: CardFieldsConfig;
  isTerminalColumn: boolean;
  columns: KanbanColumnDef[];
  legalTargetStepIds: string[];
  transitionError: string | null;
  onDismissError: () => void;
  onMoveTo: (toStepId: string) => void;
  onPointerDownCard: (e: React.PointerEvent<HTMLDivElement>) => void;
  /** Uncategorized-column cards (N — unmapped currentStep) aren't a pointer-drag source: only the kebab "Move to…" menu moves them. */
  dragDisabled?: boolean;
  /** Opens the card's record detail. Omitted when the host doesn't wire a click target. */
  onClick?: (() => void) | undefined;
  /** ↑/↓ within-column keyboard reorder (K2). -1 = move up/earlier, 1 = move down/later. */
  onReorder: (direction: -1 | 1) => void;
  isFirst: boolean;
  isLast: boolean;
  shaking: boolean;
  landed: boolean;
  labels: ResolvedKanbanLabels;
}

/**
 * DR-7 reference fidelity (design-ingestion-resolution-2026-07-17): the
 * reference kanban card has no on-card Advance/Reject buttons — advancing a
 * card happens via drag, ←→/↑↓ keyboard, or the kebab "Move to…" menu below,
 * all of which enforce PS.WORKFLOW legality the same way the removed buttons
 * did (see `onMoveTo` / the caller's `commitMove`). `config.allowAdvance` /
 * `allowReject` remain valid, unchanged manifest fields (no schema break) —
 * they're just no longer consulted here since there's no button left to gate.
 */
export function KanbanCard({
  instance,
  stepId,
  cardFields,
  isTerminalColumn,
  columns,
  legalTargetStepIds,
  transitionError,
  onDismissError,
  onMoveTo,
  onPointerDownCard,
  dragDisabled = false,
  onClick,
  onReorder,
  isFirst,
  isLast,
  shaking,
  landed,
  labels,
}: KanbanCardProps) {
  const display = resolveCardDisplay(instance.context, cardFields);
  // Item 7: graded due-date tiers (overdue / today / Nd soon / normal / no date)
  // instead of a plain overdue boolean.
  const dueDisplay =
    cardFields.dueDateField !== undefined
      ? resolveDueDisplay(display.due, isTerminalColumn, labels.noDate)
      : null;
  const moveTargets = columns.filter((c) => c.stepId !== stepId && legalTargetStepIds.includes(c.stepId));
  const [menuOpen, setMenuOpen] = React.useState(false);

  return (
    <div
      data-kanban-card={instance.workflowId}
      data-testid="kanban-card"
      data-workflow-id={instance.workflowId}
      onPointerDown={(e) => {
        if (dragDisabled) return;
        // Without this guard, a pointerdown on a menu item still reaches
        // this handler — React re-routes events from a Radix Portal (see
        // DropdownMenuContent's `data-nodrag` below, which IS a real DOM
        // ancestor of the portaled content, unlike the card's own
        // data-nodrag wrapper) through the owning React tree — and starts a
        // drag-lift, which filters this card out of the column's visible
        // list mid-click and swallows the menu-item click. Since DR-7
        // removed the on-card Advance/Reject buttons, this menu is the only
        // pointer-driven way left to commit a move — it must not race with
        // drag.
        if ((e.target as HTMLElement).closest("[data-nodrag]")) return;
        onPointerDownCard(e);
      }}
      onClick={(e) => {
        if (!onClick) return;
        if ((e.target as HTMLElement).closest("[data-nodrag]")) return;
        onClick();
      }}
      tabIndex={0}
      aria-label={`${display.title || instance.workflowId}.${
        dragDisabled
          ? " Uncategorized — press M or use the actions menu to move it onto the board."
          : " Press up or down arrow keys to reorder within this column, left/right to move it between columns, or M to open the move menu."
      }`}
      onKeyDown={(e) => {
        if (e.target !== e.currentTarget) return;
        if (e.key === "m" || e.key === "M") {
          // "M" opens the move menu even when locked, so the lock reason
          // (shown in place of "Move to…" — see DropdownMenuContent below)
          // is reachable from the keyboard, same as clicking the kebab.
          e.preventDefault();
          setMenuOpen(true);
          return;
        }
        if (display.locked) return;
        if (e.key === "ArrowUp") {
          e.preventDefault();
          if (!dragDisabled && !isFirst) onReorder(-1);
        } else if (e.key === "ArrowDown") {
          e.preventDefault();
          if (!dragDisabled && !isLast) onReorder(1);
        } else if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
          e.preventDefault();
          const currentIndex = columns.findIndex((c) => c.stepId === stepId);
          const dir = e.key === "ArrowLeft" ? -1 : 1;
          for (let i = currentIndex + dir; i >= 0 && i < columns.length; i += dir) {
            const candidate = columns[i]!;
            if (legalTargetStepIds.includes(candidate.stepId)) {
              onMoveTo(candidate.stepId);
              break;
            }
          }
        } else if (e.key === "Enter" && onClick) {
          e.preventDefault();
          onClick();
        }
      }}
      className={cn(
        "relative flex min-h-[44px] flex-col gap-1.5 rounded-[var(--radius-card)] border p-2.5",
        display.locked
          ? "border-[var(--color-neutral-border)] bg-[var(--color-neutral-surface)]"
          : "border-[var(--color-border)] bg-[var(--color-surface)]",
        display.locked || dragDisabled ? "cursor-not-allowed" : "cursor-grab active:cursor-grabbing",
        shaking && "animate-dbp-shake",
        landed && "animate-dbp-card-land",
      )}
      style={{ touchAction: "none" }}
    >
      {/* BoardCard's own border/background/padding are stripped (twMerge overrides
          below) so its content sits INSIDE this same bordered box as the kebab menu
          and transition error — a single calm visual card, matching the reference's
          anatomy: title · account/meta line · tags · avatar + due date. No on-card
          action buttons (see the module doc comment above). */}
      <BoardCard
        title={display.title || instance.workflowId}
        {...(display.subtitle ? { subtitle: display.subtitle } : {})}
        {...(display.meta ? { meta: display.meta } : {})}
        {...(display.risk
          ? { badgeTone: riskTone(display.risk), badgeLabel: display.risk }
          : display.badge
            ? { badgeTone: "navy" as const, badgeLabel: display.badge }
            : {})}
        {...(display.status ? { secondaryBadgeTone: "gray" as const, secondaryBadgeLabel: display.status } : {})}
        {...(display.tags.length > 0 ? { tags: display.tags } : {})}
        {...(cardFields.assigneeField !== undefined ? { assigneeName: display.assignee } : {})}
        {...(dueDisplay ? { dueLabel: dueDisplay.label, dueTier: dueDisplay.tier } : {})}
        locked={display.locked}
        {...(labels.holdChip ? { lockLabel: labels.holdChip } : {})}
        className="min-h-0 rounded-none border-0 bg-transparent p-0"
      />

      <div className="absolute right-1.5 top-1.5" data-nodrag>
        <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label={`Actions for ${display.title || instance.workflowId}`}
              className="h-6 w-6 rounded-[var(--radius-button)] text-[var(--color-text-muted)] hover:bg-[var(--color-neutral-surface)] hover:text-[var(--color-text)]"
            >
              <MoreVertical size={15} strokeWidth={2} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" data-nodrag>
            {display.locked ? (
              <div className="max-w-64 px-2 py-1.5 text-xs text-[var(--color-text-muted)]">
                {display.lockReason || "This card is on hold and can't be moved."}
              </div>
            ) : (
              <>
                <DropdownMenuLabel>{labels.moveTo}</DropdownMenuLabel>
                {moveTargets.length === 0 && (
                  <div className="px-2 py-1.5 text-xs text-[var(--color-text-muted)]">No legal moves</div>
                )}
                {moveTargets.map((col) => (
                  <DropdownMenuItem key={col.stepId} onSelect={() => onMoveTo(col.stepId)}>
                    {col.label}
                  </DropdownMenuItem>
                ))}
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {transitionError && (
        <Alert tone="danger" className="px-2 py-1 text-xs" data-testid="card-transition-error">
          <div className="flex items-start gap-2">
            <span className="flex-1">{transitionError}</span>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Dismiss error"
              onClick={onDismissError}
              data-nodrag
              className="h-auto w-auto shrink-0 p-0.5 text-[var(--color-text-muted)] hover:bg-transparent hover:text-[var(--color-text)]"
            >
              <X size={12} strokeWidth={2.2} />
            </Button>
          </div>
        </Alert>
      )}
    </div>
  );
}
