import * as React from "react";
import { Badge } from "@dbp/ui";
import type { WorkflowInstance } from "@dbp/ps-workflow/client";
import type { CardFieldsConfig, ResolvedKanbanLabels } from "../types.js";
import { resolveCardDisplay, riskTone, resolveDueDisplay } from "../lib/card-fields.js";

interface KanbanTableRow {
  instance: WorkflowInstance;
  columnLabel: string;
  isTerminalColumn: boolean;
}

interface KanbanTableViewProps {
  rows: KanbanTableRow[];
  cardFields: CardFieldsConfig;
  labels: ResolvedKanbanLabels;
  onRowClick?: ((workflowId: string) => void) | undefined;
}

/**
 * Item 9 — a flat table alternative to the board, over the SAME instance
 * data (no separate fetch, no PS.DATA entity). Columns are derived from
 * cardFields, same as BoardCard, so a row and its card show identical
 * information in a different shape.
 *
 * DR-5 reference fidelity (design-ingestion-resolution-2026-07-17): the
 * surface/header/row treatment below is lifted verbatim from the
 * entity-list (APP.F01) table — `bg-[var(--color-surface-2)]` white content
 * surface + `shadow-[var(--shadow-sm)]` container, uppercase mono `11px`
 * column headers on a `--color-surface` header row, `--color-border-subtle`
 * row dividers with a `--color-surface` row hover — instead of the bespoke
 * treatment that blended into the canvas. See
 * `features/entity-list/index.tsx`'s `<table>`/`<thead>`/`<tbody>` markup
 * for the shared reference; kanban doesn't consume TanStack Table here (no
 * PS.DATA entity backs these rows — see the module doc above), so the exact
 * className strings are duplicated rather than the component, but every
 * value is copied 1:1 from that source.
 */
export function KanbanTableView({ rows, cardFields, labels, onRowClick }: KanbanTableViewProps) {
  return (
    <div
      className="w-full overflow-x-auto rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-2)] shadow-[var(--shadow-sm)]"
      data-testid="kanban-table-view"
    >
      <table className="w-full border-collapse text-sm text-[var(--color-text-primary)]">
        <thead>
          <tr className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]">
            <th className="px-4 py-3 text-left font-mono text-xs font-medium uppercase tracking-wider text-[var(--color-text-muted)] whitespace-nowrap">
              {labels.tableColumnHeader}
            </th>
            <th className="px-4 py-3 text-left font-mono text-xs font-medium uppercase tracking-wider text-[var(--color-text-muted)] whitespace-nowrap">
              Title
            </th>
            {cardFields.statusField !== undefined && (
              <th className="px-4 py-3 text-left font-mono text-xs font-medium uppercase tracking-wider text-[var(--color-text-muted)] whitespace-nowrap">
                Status
              </th>
            )}
            {cardFields.riskField !== undefined && (
              <th className="px-4 py-3 text-left font-mono text-xs font-medium uppercase tracking-wider text-[var(--color-text-muted)] whitespace-nowrap">
                Risk
              </th>
            )}
            {cardFields.assigneeField !== undefined && (
              <th className="px-4 py-3 text-left font-mono text-xs font-medium uppercase tracking-wider text-[var(--color-text-muted)] whitespace-nowrap">
                Assignee
              </th>
            )}
            {cardFields.dueDateField !== undefined && (
              <th className="px-4 py-3 text-left font-mono text-xs font-medium uppercase tracking-wider text-[var(--color-text-muted)] whitespace-nowrap">
                Due
              </th>
            )}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td
                colSpan={2 + [cardFields.statusField, cardFields.riskField, cardFields.assigneeField, cardFields.dueDateField].filter((f) => f !== undefined).length}
                className="px-4 py-6 text-center text-xs text-[var(--color-text-muted)]"
              >
                {labels.emptyColumnFiltered}
              </td>
            </tr>
          ) : (
            rows.map(({ instance, columnLabel, isTerminalColumn }) => {
              const display = resolveCardDisplay(instance.context, cardFields);
              const due =
                cardFields.dueDateField !== undefined
                  ? resolveDueDisplay(display.due, isTerminalColumn, labels.noDate)
                  : null;
              return (
                <tr
                  key={instance.workflowId}
                  data-testid="kanban-table-row"
                  onClick={onRowClick ? () => onRowClick(instance.workflowId) : undefined}
                  className={
                    onRowClick
                      ? "cursor-pointer border-b border-[var(--color-border-subtle)] transition-colors last:border-0 hover:bg-[var(--color-surface)]"
                      : "border-b border-[var(--color-border-subtle)] last:border-0"
                  }
                >
                  <td className="px-4 py-2.5 whitespace-nowrap text-xs text-[var(--color-text-muted)]">{columnLabel}</td>
                  <td className="px-4 py-2.5 whitespace-nowrap font-medium text-[var(--color-text)]">
                    {display.title || instance.workflowId}
                  </td>
                  {cardFields.statusField !== undefined && (
                    <td className="px-4 py-2.5 whitespace-nowrap">
                      {display.status && <Badge tone="gray" size="sm">{display.status}</Badge>}
                    </td>
                  )}
                  {cardFields.riskField !== undefined && (
                    <td className="px-4 py-2.5 whitespace-nowrap">
                      {display.risk && (
                        <Badge tone={riskTone(display.risk)} size="sm">
                          {display.risk}
                        </Badge>
                      )}
                    </td>
                  )}
                  {cardFields.assigneeField !== undefined && (
                    <td className="px-4 py-2.5 whitespace-nowrap text-xs">{display.assignee || labels.unassigned}</td>
                  )}
                  {cardFields.dueDateField !== undefined && (
                    <td
                      className={
                        due?.tier === "overdue"
                          ? "px-4 py-2.5 whitespace-nowrap text-xs font-bold text-[var(--color-danger-text)]"
                          : due?.tier === "today" || due?.tier === "soon"
                            ? "px-4 py-2.5 whitespace-nowrap text-xs font-semibold text-[var(--color-warning-text)]"
                            : due?.tier === "none"
                              ? "px-4 py-2.5 whitespace-nowrap text-xs italic text-[var(--color-text-muted)]"
                              : "px-4 py-2.5 whitespace-nowrap text-xs text-[var(--color-text-secondary)]"
                      }
                    >
                      {due?.label}
                    </td>
                  )}
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
}
