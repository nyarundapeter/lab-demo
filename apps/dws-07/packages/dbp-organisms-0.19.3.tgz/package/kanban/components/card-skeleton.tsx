import * as React from "react";
import { Skeleton } from "@dbp/ui";

export function CardSkeleton() {
  return (
    <div
      className="rounded border border-[var(--color-border)] bg-[var(--color-surface)] p-3"
      aria-hidden="true"
    >
      <Skeleton className="mb-2 h-3 w-3/4 bg-[color-mix(in_srgb,var(--color-border)_60%,transparent)]" />
      <Skeleton className="h-2 w-1/2 bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)]" />
    </div>
  );
}
