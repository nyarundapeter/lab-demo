import type { KanbanColumnDef } from "../types.js";

interface KanbanFlowRailProps {
  columns: KanbanColumnDef[];
  countsByStep: Record<string, number>;
  onColumnClick: (stepId: string) => void;
}

/**
 * Mini per-column progress bars + click-to-scroll (design ref's "flow rail").
 * Genuinely organism-specific — no `@dbp/ui` equivalent exists (per the build
 * analysis §3b); kept intentionally small (no WIP-over styling duplicate —
 * that lives on the column header itself).
 */
export function KanbanFlowRail({ columns, countsByStep, onColumnClick }: KanbanFlowRailProps) {
  const max = Math.max(1, ...columns.map((c) => countsByStep[c.stepId] ?? 0));
  return (
    <div className="flex gap-1.5 overflow-x-auto border-b border-[var(--color-border-default)] px-1 py-2">
      {columns.map((col) => {
        const count = countsByStep[col.stepId] ?? 0;
        const over = col.wipLimit !== undefined && count > col.wipLimit;
        return (
          <button
            key={col.stepId}
            type="button"
            onClick={() => onColumnClick(col.stepId)}
            className="flex min-w-[100px] flex-1 flex-col gap-1 rounded p-1 text-left"
          >
            <div className="flex items-center justify-between gap-1">
              <span className="truncate text-xs font-bold uppercase tracking-wide text-[var(--color-text-muted)]">
                {col.label}
              </span>
              <span className={over ? "text-xs font-bold text-[var(--color-danger-text)]" : "text-xs font-bold text-[var(--color-text-secondary)]"}>
                {count}
              </span>
            </div>
            <div className="h-1 overflow-hidden rounded-full bg-[var(--color-neutral-surface)]">
              <div
                className={over ? "h-full rounded-full bg-[var(--color-danger)]" : "h-full rounded-full bg-primary"}
                style={{ width: `${(count / max) * 100}%` }}
              />
            </div>
          </button>
        );
      })}
    </div>
  );
}
