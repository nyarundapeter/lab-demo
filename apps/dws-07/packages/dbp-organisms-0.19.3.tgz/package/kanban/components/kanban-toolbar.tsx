import { FilterBar } from "@dbp/ui";
import type { KanbanFilterChipConfig, ResolvedKanbanLabels } from "../types.js";

interface KanbanToolbarProps {
  searchValue: string;
  onSearchChange: (value: string) => void;
  filterChips: KanbanFilterChipConfig[];
  activeChipIds: Set<string>;
  onToggleChip: (id: string) => void;
  resultSummary: string;
  hasActiveFilter: boolean;
  onClearAll: () => void;
  labels: ResolvedKanbanLabels;
}

/**
 * Wraps `@dbp/ui`'s `FilterBar` — search + multi-select filter chips (all
 * combinable, unlike FilterBar's default single `activeChip`) + result
 * summary + clear-all. FilterBar only supports one active chip at a time
 * natively, so chip active/toggle state is rendered here via `chips`/manual
 * styling isn't reused; combinability is achieved by calling FilterBar once
 * per chip group is unnecessary — instead we drive FilterBar's chips list
 * with a synthetic "active" indicator per id and delegate toggling to the
 * caller, matching the vendor-pipeline design's combinable-chip requirement.
 */
export function KanbanToolbar({
  searchValue,
  onSearchChange,
  filterChips,
  activeChipIds,
  onToggleChip,
  resultSummary,
  hasActiveFilter,
  onClearAll,
  labels,
}: KanbanToolbarProps) {
  return (
    <div className="flex flex-col gap-2 border-b border-[var(--color-border-default)] bg-[var(--color-surface)] px-1 py-2">
      <FilterBar
        searchValue={searchValue}
        onSearchChange={onSearchChange}
        searchPlaceholder={labels.searchPlaceholder}
        resultSummary={resultSummary}
        showClearAll={hasActiveFilter}
        onClearAll={onClearAll}
        clearAllLabel={labels.clearAll}
      />
      {filterChips.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          {filterChips.map((chip) => {
            const active = activeChipIds.has(chip.id);
            return (
              <button
                key={chip.id}
                type="button"
                aria-pressed={active}
                onClick={() => onToggleChip(chip.id)}
                className={
                  active
                    ? "inline-flex items-center gap-1.5 rounded-pill border border-[var(--color-secondary)] bg-[color-mix(in_srgb,var(--color-secondary)_12%,transparent)] px-3 h-8 text-xs font-semibold text-[var(--color-secondary)]"
                    : "inline-flex items-center gap-1.5 rounded-pill border border-[var(--color-border-default)] bg-[var(--color-surface)] px-3 h-8 text-xs font-semibold text-[var(--color-text-secondary)] hover:border-primary hover:text-primary"
                }
              >
                {chip.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
