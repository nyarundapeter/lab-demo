import * as React from "react";
import { ChevronLeft, ChevronRight, AlertTriangle } from "lucide-react";
import { Button, cn } from "@dbp/ui";
import type { WorkflowInstance } from "@dbp/ps-workflow/client";
import type { CardFieldsConfig, KanbanColumnDef, ResolvedKanbanLabels } from "../types.js";
import type { KanbanDragState } from "../hooks/use-kanban-drag.js";
import { KanbanCard } from "./kanban-card.js";
import { CardSkeleton } from "./card-skeleton.js";

const TONE_DOT: Record<string, string> = {
  neutral: "bg-[var(--color-text-muted)]",
  success: "bg-[var(--color-success)]",
  warning: "bg-[var(--color-warning)]",
  danger: "bg-[var(--color-danger)]",
  info: "bg-[var(--color-info)]",
};

const TONE_FILL: Record<string, string> = {
  neutral: "bg-[var(--color-text-muted)]",
  success: "bg-[var(--color-success)]",
  warning: "bg-[var(--color-warning)]",
  danger: "bg-[var(--color-danger)]",
  info: "bg-[var(--color-info)]",
};

interface KanbanColumnProps {
  column: KanbanColumnDef;
  columns: KanbanColumnDef[];
  instances: WorkflowInstance[];
  isLoading: boolean;
  cardFields: CardFieldsConfig;
  legalTargets: Record<string, string[]>;
  transitionErrors: Map<string, string>;
  onDismissError: (workflowId: string) => void;
  onMoveTo: (workflowId: string, fromStep: string, toStep: string) => void;
  onPointerDownCard: (workflowId: string, fromStep: string, e: React.PointerEvent<HTMLDivElement>) => void;
  onCardClick?: ((workflowId: string) => void) | undefined;
  /** ↑/↓ within-column keyboard reorder (K2) — see index.tsx `reorderCard`. */
  onReorder: (workflowId: string, direction: -1 | 1) => void;
  shakeId: string | null;
  landedId: string | null;
  drag: KanbanDragState | null;
  collapsed: boolean;
  onToggleCollapse: () => void;
  hasActiveFilter: boolean;
  labels: ResolvedKanbanLabels;
  /**
   * Synthetic trailing column collecting cards whose `currentStep` matches no
   * configured `columns` entry (design-audit-2026-07-17 kanban item 1 — those
   * cards were previously silently dropped from the board). Visually
   * distinct (dashed border, warning dot) and never a drag-drop target: cards
   * move out of it only via the kebab "Move to…" menu, using their own real
   * `currentStep` (not this column's synthetic stepId) as the move source.
   */
  isUncategorized?: boolean;
}

export function KanbanColumn({
  column,
  columns,
  instances,
  isLoading,
  cardFields,
  legalTargets,
  transitionErrors,
  onDismissError,
  onMoveTo,
  onPointerDownCard,
  onCardClick,
  onReorder,
  shakeId,
  landedId,
  drag,
  collapsed,
  onToggleCollapse,
  hasActiveFilter,
  labels,
  isUncategorized = false,
}: KanbanColumnProps) {
  const isTarget = !isUncategorized && drag?.targetStep === column.stepId;
  const isDropLegal = isTarget && drag !== null && drag.legal;
  const isDropIllegal = isTarget && drag !== null && !drag.legal;
  const isTerminalColumn = legalTargets[column.stepId]?.length === 0;

  const visible = instances.filter((inst) => !(drag && drag.cardId === inst.workflowId));
  const isEmpty = visible.length === 0;
  const over = column.wipLimit !== undefined && instances.length > column.wipLimit;

  if (collapsed) {
    return (
      <button
        type="button"
        data-kanban-col={column.stepId}
        onClick={onToggleCollapse}
        title={`Expand ${column.label}`}
        className="flex h-full w-11 shrink-0 flex-col items-center gap-2.5 rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface)] py-3"
      >
        <ChevronRight size={15} className="text-[var(--color-text-muted)]" />
        <span className="text-xs font-semibold text-[var(--color-text-muted)]">{instances.length}</span>
        <span
          className="whitespace-nowrap text-xs font-semibold text-[var(--color-text)]"
          style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
        >
          {column.label}
        </span>
      </button>
    );
  }

  return (
    <section
      data-kanban-col={isUncategorized ? undefined : column.stepId}
      data-collapsed="false"
      aria-label={isUncategorized ? `${column.label}: cards not on a configured board column` : `Column: ${column.label}`}
      data-testid={isUncategorized ? "kanban-column-uncategorized" : "kanban-column"}
      data-step-id={column.stepId}
      className={cn(
        "flex h-full w-[272px] shrink-0 flex-col rounded-[var(--radius-card)] border p-2 transition-colors",
        isUncategorized
          ? "border-2 border-dashed border-[var(--color-warning-border)] bg-[var(--color-warning-surface)]"
          : isDropLegal
            ? "border-[var(--color-secondary)] bg-[color-mix(in_srgb,var(--color-secondary)_8%,var(--color-surface-raised))]"
            : isDropIllegal
              ? "cursor-not-allowed border-[var(--color-border-default)] bg-[var(--color-neutral-surface)]"
              : "border-[var(--color-border-default)] bg-[var(--color-surface-raised)]",
      )}
    >
      <div className="flex items-center gap-2 px-1 py-1">
        {isUncategorized ? (
          <AlertTriangle size={12} className="shrink-0 text-[var(--color-warning-text)]" />
        ) : (
          <span className={cn("h-2 w-2 shrink-0 rounded-sm", TONE_DOT[column.tone] ?? TONE_DOT.neutral)} />
        )}
        <span className="truncate text-sm font-semibold text-[var(--color-text)]">{column.label}</span>
        <span className="text-xs font-semibold text-[var(--color-text-muted)]" data-testid="column-count">
          {isLoading ? "…" : instances.length}
        </span>
        {column.wipLimit !== undefined && (
          <span
            className={cn(
              "ml-auto rounded-pill px-2 py-0.5 text-xs font-bold",
              over ? "bg-[var(--color-danger)] text-white" : "bg-[var(--color-neutral-surface)] text-[var(--color-neutral-text)]",
            )}
          >
            {instances.length}/{column.wipLimit}
          </span>
        )}
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          title={`Collapse ${column.label}`}
          aria-label={`Collapse ${column.label}`}
          className={cn("h-auto w-auto shrink-0 rounded p-0.5 text-[var(--color-text-muted)] hover:bg-transparent hover:text-[var(--color-text)]", column.wipLimit === undefined && "ml-auto")}
        >
          <ChevronLeft size={15} />
        </Button>
      </div>

      {column.wipLimit !== undefined && (
        <div className="mx-1 mb-1 h-1 overflow-hidden rounded-full bg-[var(--color-neutral-surface)]">
          <div
            className={cn("h-full rounded-full transition-[width]", over ? "bg-[var(--color-danger)]" : (TONE_FILL[column.tone] ?? TONE_FILL.neutral))}
            style={{ width: `${Math.min(100, Math.round((instances.length / column.wipLimit) * 100))}%` }}
          />
        </div>
      )}
      {over && (
        <div className="mx-1 mb-1 flex items-center gap-1 text-xs font-semibold text-[var(--color-danger-text)]">
          <AlertTriangle size={12} />
          {labels.overWipLimit}
        </div>
      )}

      <div data-kanban-list className="flex min-h-[80px] flex-1 flex-col gap-2 overflow-y-auto px-1 py-1">
        {isLoading ? (
          <>
            <CardSkeleton />
            <CardSkeleton />
          </>
        ) : isEmpty ? (
          isTarget && drag ? (
            <div
              className={cn(
                "m-0.5 flex flex-1 items-center justify-center rounded-[var(--radius)] border-2 border-dashed text-xs font-semibold",
                drag.legal
                  ? "border-[var(--color-secondary)] text-[var(--color-secondary)]"
                  : "border-[var(--color-neutral-border)] text-[var(--color-neutral-text)]",
              )}
            >
              {drag.legal ? labels.dropInvite : "Not a valid target"}
            </div>
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-1 py-6 text-center text-xs text-[var(--color-text-muted)]" data-testid="column-empty">
              {hasActiveFilter ? labels.emptyColumnFiltered : labels.emptyColumn}
            </div>
          )
        ) : (
          visible.map((inst, i) => {
            // Uncategorized cards use their OWN real currentStep as the move
            // source (not this synthetic column's stepId) so the kebab
            // "Move to…" menu resolves real legal targets from the workflow
            // definition instead of always showing "No legal moves".
            const cardStepId = isUncategorized ? inst.currentStep ?? "" : column.stepId;
            const cardLegalTargets = legalTargets[cardStepId] ?? [];
            const cardIsTerminal = isUncategorized ? cardLegalTargets.length === 0 : isTerminalColumn;
            return (
              <React.Fragment key={inst.workflowId}>
                {isTarget && drag && drag.targetIndex === i && <DropGapIndicator legal={drag.legal} />}
                <KanbanCard
                  instance={inst}
                  stepId={cardStepId}
                  cardFields={cardFields}
                  isTerminalColumn={cardIsTerminal}
                  columns={columns}
                  legalTargetStepIds={cardLegalTargets}
                  transitionError={transitionErrors.get(inst.workflowId) ?? null}
                  onDismissError={() => onDismissError(inst.workflowId)}
                  onMoveTo={(toStep) => onMoveTo(inst.workflowId, cardStepId, toStep)}
                  onPointerDownCard={(e) => onPointerDownCard(inst.workflowId, cardStepId, e)}
                  dragDisabled={isUncategorized}
                  onClick={onCardClick ? () => onCardClick(inst.workflowId) : undefined}
                  onReorder={(direction) => onReorder(inst.workflowId, direction)}
                  isFirst={isUncategorized || i === 0}
                  isLast={isUncategorized || i === visible.length - 1}
                  shaking={shakeId === inst.workflowId}
                  landed={landedId === inst.workflowId}
                  labels={labels}
                />
              </React.Fragment>
            );
          })
        )}
        {isTarget && drag && !isEmpty && drag.targetIndex >= visible.length && <DropGapIndicator legal={drag.legal} />}
      </div>
    </section>
  );
}

function DropGapIndicator({ legal }: { legal: boolean }) {
  return (
    <div
      className={cn("mx-0.5 h-[3px] shrink-0 rounded-full", legal ? "bg-[var(--color-secondary)]" : "bg-[var(--color-neutral-border)]")}
      aria-hidden="true"
    />
  );
}
