import * as React from "react";
import { z } from "zod";
import { Alert, EmptyState, ErrorState, Button, SegmentedControl, useShortcuts } from "@dbp/ui";
import { WorkflowServiceError } from "@dbp/ps-workflow/client";
import type { WorkflowInstance } from "@dbp/ps-workflow/client";
import { KanbanConfig } from "./types.js";
import type { KanbanColumnDef, KanbanLabels, ResolvedKanbanLabels } from "./types.js";
import { useKanbanInstances } from "./hooks/use-kanban-instances.js";
import { useKanbanDrag } from "./hooks/use-kanban-drag.js";
import { KanbanColumn } from "./components/kanban-column.js";
import { KanbanToolbar } from "./components/kanban-toolbar.js";
import { KanbanFlowRail } from "./components/kanban-flow-rail.js";
import { KanbanTableView } from "./components/kanban-table-view.js";
import { isLegalMove, resolveMoveAction } from "./lib/legal-targets.js";
import { contextString, contextBoolean, isOverdue } from "./lib/card-fields.js";
import { sortByServerOrder, computeSortOrderForMove, moveWithinOrder } from "./lib/card-order.js";

/**
 * Props are the pre-parse (z.input) shape — every `.default()`-bearing field
 * (instanceIds, allowAdvance/Reject/Drag, labels, columns[].tone,
 * filterChips[].kind…) is optional here even though `KanbanConfig` (the
 * z.infer/output type) makes it required post-parse.
 */
type ConfigInput = z.input<typeof KanbanConfig> & {
  /**
   * Live client-side search text (e.g. wired to a CollectionToolbar search field).
   * Not part of KanbanConfig — this is transient UI state, not manifest config.
   * Seeds the board's own search box; the box is then locally editable.
   */
  searchQuery?: string;
  /**
   * Opens a card's record detail (e.g. a RecordDrawer) on click. Not part of
   * KanbanConfig — a function prop, not data-only manifest config. Optional:
   * cards render as plain drag-only cards when omitted.
   */
  onCardClick?: (workflowId: string) => void;
  /**
   * The signed-in actor's identity, as it appears in card context fields
   * (e.g. an owner name/id). Not part of KanbanConfig — session-resolved,
   * not manifest data. Required for a `filterChips[].kind: "me"` chip
   * ("My items") to match anything; omitted, that chip matches nothing.
   */
  currentUserId?: string;
};

const DEFAULT_LABELS: ResolvedKanbanLabels = {
  title: "",
  subtitle: "",
  searchPlaceholder: "Search cases…",
  clearAll: "Clear all",
  emptyBoardTitle: "Pipeline's all clear",
  emptyBoardBody: "No cases in the board right now.",
  errorTitle: "Couldn't load the board",
  errorBody: "We hit a snag loading this board. Give it another go.",
  retry: "Retry",
  emptyColumn: "No cases here yet",
  emptyColumnFiltered: "No matching cases",
  dropInvite: "Drop here",
  overWipLimit: "Over WIP limit",
  moveTo: "Move to",
  holdChip: "Hold",
  unassigned: "Unassigned",
  itemNoun: "cases",
  uncategorized: "Uncategorized",
  noResultsTitle: "No matching results",
  noDate: "No date",
  boardView: "Board",
  tableView: "Table",
  tableColumnHeader: "Column",
};

/** Merges config-provided labels over the defaults — every field statically `string`, never `string | undefined`. */
function resolveLabels(input: KanbanLabels): ResolvedKanbanLabels {
  return {
    title: input.title ?? DEFAULT_LABELS.title,
    subtitle: input.subtitle ?? DEFAULT_LABELS.subtitle,
    searchPlaceholder: input.searchPlaceholder ?? DEFAULT_LABELS.searchPlaceholder,
    clearAll: input.clearAll ?? DEFAULT_LABELS.clearAll,
    emptyBoardTitle: input.emptyBoardTitle ?? DEFAULT_LABELS.emptyBoardTitle,
    emptyBoardBody: input.emptyBoardBody ?? DEFAULT_LABELS.emptyBoardBody,
    errorTitle: input.errorTitle ?? DEFAULT_LABELS.errorTitle,
    errorBody: input.errorBody ?? DEFAULT_LABELS.errorBody,
    retry: input.retry ?? DEFAULT_LABELS.retry,
    emptyColumn: input.emptyColumn ?? DEFAULT_LABELS.emptyColumn,
    emptyColumnFiltered: input.emptyColumnFiltered ?? DEFAULT_LABELS.emptyColumnFiltered,
    dropInvite: input.dropInvite ?? DEFAULT_LABELS.dropInvite,
    overWipLimit: input.overWipLimit ?? DEFAULT_LABELS.overWipLimit,
    moveTo: input.moveTo ?? DEFAULT_LABELS.moveTo,
    holdChip: input.holdChip ?? DEFAULT_LABELS.holdChip,
    unassigned: input.unassigned ?? DEFAULT_LABELS.unassigned,
    itemNoun: input.itemNoun ?? DEFAULT_LABELS.itemNoun,
    uncategorized: input.uncategorized ?? DEFAULT_LABELS.uncategorized,
    noResultsTitle: input.noResultsTitle ?? DEFAULT_LABELS.noResultsTitle,
    noDate: input.noDate ?? DEFAULT_LABELS.noDate,
    boardView: input.boardView ?? DEFAULT_LABELS.boardView,
    tableView: input.tableView ?? DEFAULT_LABELS.tableView,
    tableColumnHeader: input.tableColumnHeader ?? DEFAULT_LABELS.tableColumnHeader,
  };
}

/**
 * APP.F04 — Kanban / Pipeline Board
 *
 * Receives CONFIG, never data. Workflow instances are fetched individually via
 * PS.WORKFLOW (GET /instances/:id) because PS.WORKFLOW does not expose a
 * list-by-definitionId endpoint. See FEATURE.md §Limitations.
 *
 * Config is validated at render time; a config-error element is rendered (not
 * thrown) on invalid config.
 *
 * LEGALITY-CONSTRAINED DRAG: cards drag freely via pointer; only columns that
 * are legal workflow-transition targets (derived from the workflow
 * definition's step graph — see lib/legal-targets.ts) accept the drop.
 * Advance / Reject buttons remain as the keyboard/a11y equivalent of the same
 * transitions (per Sharavi's ruling on the vendor-pipeline build).
 */
export default function KanbanBoard({ searchQuery, onCardClick, currentUserId, ...configInput }: ConfigInput) {
  const parseResult = KanbanConfig.safeParse(configInput);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="KanbanBoard configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>{e.path.join(".") || "root"}: {e.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <KanbanBoardInner
      config={parseResult.data}
      searchQuery={searchQuery}
      onCardClick={onCardClick}
      currentUserId={currentUserId}
    />
  );
}

export type { KanbanConfig } from "./types.js";

// ─── Inner component (config guaranteed valid) ────────────────────────────────

interface KanbanBoardInnerProps {
  config: KanbanConfig;
  /** Seeds the board's own local search box; see ConfigInput.searchQuery. */
  searchQuery?: string | undefined;
  /** Opens a card's record detail on click. See ConfigInput.onCardClick. */
  onCardClick?: ((workflowId: string) => void) | undefined;
  /** The signed-in actor's identity for a "me" filter chip. See ConfigInput.currentUserId. */
  currentUserId?: string | undefined;
}

/**
 * The demo actor's roles — aligned with the two identities PS.AUTH actually
 * seeds for every generated solution (`scripts/scaffold-solution.mjs`'s dev
 * users: "platform-admin" and "user") and with the roles
 * `scripts/standard-menu-scaffold.mjs`'s `demoWorkflow()` assigns its steps,
 * so the standard-menu Kanban demo page is genuinely interactable rather than
 * always 403ing. Also used for the client-side eligibility gate below.
 */
const DEMO_ACTOR_ROLES = ["platform-admin", "user"];

/**
 * Synthetic trailing column stepId for cards whose `currentStep` matches no
 * `config.columns` entry — never a real workflow step, so it can never
 * collide with one (design-audit-2026-07-17 kanban item 1: those instances
 * were previously silently dropped from the board — see instancesForColumn).
 */
const UNCATEGORIZED_STEP_ID = "__uncategorized__";

/**
 * Placeholder session token for advance/reject calls. In production the shell
 * injects the real session via context; for this blueprint a static demo token
 * is used so the feature compiles and tests without a live auth provider.
 */
const DEMO_SESSION = btoa(
  JSON.stringify({ userId: "demo-user", roles: DEMO_ACTOR_ROLES, tenantId: "demo" }),
);

/** How long a transition-error inline alert stays up before auto-dismissing (ms). */
const TRANSITION_ERROR_TTL_MS = 6000;

function KanbanBoardInner({ config, searchQuery, onCardClick, currentUserId }: KanbanBoardInnerProps) {
  const labels: ResolvedKanbanLabels = resolveLabels(config.labels);
  const { instances, isLoading, error, definition, legalTargets, advance, reject, reorder } =
    useKanbanInstances(config.definitionId, config.instanceIds);

  const trackRef = React.useRef<HTMLDivElement>(null);
  const [search, setSearch] = React.useState(searchQuery ?? "");
  const [activeChipIds, setActiveChipIds] = React.useState<Set<string>>(new Set());
  const [collapsed, setCollapsed] = React.useState<Record<string, boolean>>({});
  // Item 9: SegmentedControl-paired table view — opt-in via config.showViewToggle.
  const [view, setView] = React.useState<"board" | "table">("board");
  const [shakeId, setShakeId] = React.useState<string | null>(null);
  const [landedId, setLandedId] = React.useState<string | null>(null);
  const [announce, setAnnounce] = React.useState("");

  const [transitionErrors, setTransitionErrors] = React.useState<Map<string, string>>(new Map());

  // Wires the board's existing keyboard vocabulary (per-card ↑↓←→ reorder/move
  // and "M" move-menu — see components/kanban-card.tsx's own onKeyDown) into
  // the shared `?` shortcut-help overlay (wave3-build-plan.md §4b: ShortcutHelp
  // exists but was unwired anywhere in kanban). These bindings are
  // documentation-only — a no-op handler — because the real handling stays
  // local to whichever KanbanCard is focused; registering them here just
  // surfaces them in ShortcutProvider's self-documenting registry.
  useShortcuts(
    [
      { keys: "up", handler: () => {}, description: "Move the focused card earlier in its column", group: "Kanban board" },
      { keys: "down", handler: () => {}, description: "Move the focused card later in its column", group: "Kanban board" },
      { keys: "left", handler: () => {}, description: "Move the focused card to the previous legal column", group: "Kanban board" },
      { keys: "right", handler: () => {}, description: "Move the focused card to the next legal column", group: "Kanban board" },
      { keys: "m", handler: () => {}, description: "Open the move menu for the focused card", group: "Kanban board" },
    ],
    { scope: "page", enabled: view === "board" && config.instanceIds.length > 0 },
  );

  const shakeTimer = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const landTimer = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const errorTimers = React.useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  React.useEffect(() => {
    const timers = errorTimers.current;
    return () => {
      for (const t of timers.values()) clearTimeout(t);
      clearTimeout(shakeTimer.current);
      clearTimeout(landTimer.current);
    };
  }, []);

  /** A transition error is a transient, dismissible alert — never a persistent banner. */
  function scheduleErrorDismiss(workflowId: string) {
    const timers = errorTimers.current;
    const existing = timers.get(workflowId);
    if (existing) clearTimeout(existing);
    timers.set(
      workflowId,
      setTimeout(() => {
        timers.delete(workflowId);
        setTransitionErrors((prev) => {
          const next = new Map(prev);
          next.delete(workflowId);
          return next;
        });
      }, TRANSITION_ERROR_TTL_MS),
    );
  }

  function dismissError(workflowId: string) {
    const timers = errorTimers.current;
    const existing = timers.get(workflowId);
    if (existing) clearTimeout(existing);
    timers.delete(workflowId);
    setTransitionErrors((prev) => {
      const next = new Map(prev);
      next.delete(workflowId);
      return next;
    });
  }

  function stepOf(inst: WorkflowInstance): string {
    return inst.currentStep ?? "";
  }

  function isLocked(workflowId: string): boolean {
    const inst = instances.find((i) => i.workflowId === workflowId);
    if (!inst || !config.cardFields.lockField) return false;
    return contextBoolean(inst.context, config.cardFields.lockField);
  }

  function shake(cardId: string, message: string) {
    setShakeId(cardId);
    setAnnounce(message);
    clearTimeout(shakeTimer.current);
    shakeTimer.current = setTimeout(() => setShakeId(null), 470);
  }

  function pulse(cardId: string) {
    setLandedId(cardId);
    clearTimeout(landTimer.current);
    landTimer.current = setTimeout(() => setLandedId(null), 700);
  }

  async function handleAdvance(workflowId: string) {
    setTransitionErrors((prev) => {
      const next = new Map(prev);
      next.delete(workflowId);
      return next;
    });
    try {
      await advance(workflowId, DEMO_SESSION);
      pulse(workflowId);
    } catch (err) {
      const msg =
        err instanceof WorkflowServiceError && err.status === 403
          ? "You do not have permission to advance this item."
          : err instanceof WorkflowServiceError
          ? err.message
          : "Transition failed. Please try again.";
      setTransitionErrors((prev) => new Map([...prev, [workflowId, msg]]));
      scheduleErrorDismiss(workflowId);
    }
  }

  async function handleReject(workflowId: string) {
    setTransitionErrors((prev) => {
      const next = new Map(prev);
      next.delete(workflowId);
      return next;
    });
    try {
      await reject(workflowId, DEMO_SESSION);
      pulse(workflowId);
    } catch (err) {
      const msg =
        err instanceof WorkflowServiceError && err.status === 403
          ? "You do not have permission to reject this item."
          : err instanceof WorkflowServiceError
          ? err.message
          : "Transition failed. Please try again.";
      setTransitionErrors((prev) => new Map([...prev, [workflowId, msg]]));
      scheduleErrorDismiss(workflowId);
    }
  }

  function commitMove(cardId: string, fromStep: string, toStep: string) {
    const step = definition?.steps.find((s) => s.id === fromStep);
    const action = resolveMoveAction(step, toStep);
    const inst = instances.find((i) => i.workflowId === cardId);
    const label = inst ? contextString(inst.context, config.cardFields.titleField) || cardId : cardId;
    const toLabel = config.columns.find((c) => c.stepId === toStep)?.label ?? toStep;
    // Item 5: positional announcement — the moved card lands at the end of
    // the target column's current cards (best-effort: the exact server
    // position isn't known until the transition + refetch land).
    const position = instances.filter((i) => i.currentStep === toStep).length + 1;
    if (action === "advance") {
      void handleAdvance(cardId);
      setAnnounce(`Moved ${label} to ${toLabel}, position ${position} of ${position}`);
    } else if (action === "reject") {
      void handleReject(cardId);
      setAnnounce(`Moved ${label} to ${toLabel}, position ${position} of ${position}`);
    } else {
      shake(cardId, `${label} can't be moved to ${toLabel}.`);
    }
  }

  function refuseMove(cardId: string, reason: "locked" | "permission" | "illegal") {
    const inst = instances.find((i) => i.workflowId === cardId);
    const label = inst ? contextString(inst.context, config.cardFields.titleField) || cardId : cardId;
    const message =
      reason === "locked"
        ? `${label} is on hold and can't be moved.`
        : reason === "permission"
        ? `Dragging is turned off. Use the card menu to move ${label}.`
        : `${label} can't be dropped there.`;
    shake(cardId, message);
  }

  const { drag, onPointerDownCard } = useKanbanDrag({
    allowDrag: config.allowDrag,
    trackRef,
    isLocked,
    legalTargets,
    onCommit: commitMove,
    onRefuse: refuseMove,
  });

  function matchesSearch(inst: WorkflowInstance): boolean {
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    const hay = [
      contextString(inst.context, config.cardFields.titleField),
      config.cardFields.subtitleField ? contextString(inst.context, config.cardFields.subtitleField) : "",
      config.cardFields.metaField ? contextString(inst.context, config.cardFields.metaField) : "",
      config.cardFields.assigneeField ? contextString(inst.context, config.cardFields.assigneeField) : "",
    ]
      .join(" ")
      .toLowerCase();
    return hay.includes(q);
  }

  function matchesChips(inst: WorkflowInstance): boolean {
    for (const chipId of activeChipIds) {
      const chip = config.filterChips?.find((c) => c.id === chipId);
      if (!chip) continue;
      if (chip.kind === "overdue") {
        const due = config.cardFields.dueDateField
          ? contextString(inst.context, config.cardFields.dueDateField)
          : "";
        const terminal = (legalTargets[stepOf(inst)] ?? []).length === 0;
        if (!due || !isOverdue(due, terminal)) return false;
      } else if (chip.kind === "me") {
        // Item 8: "My items" — session-aware, unlike a static "equals" chip.
        const field = chip.field ?? config.cardFields.assigneeField;
        if (!field || !currentUserId) return false;
        if (contextString(inst.context, field) !== currentUserId) return false;
      } else if (chip.field !== undefined) {
        if (inst.context[chip.field] !== chip.value) return false;
      }
    }
    return true;
  }

  function matchesStaticFilters(inst: WorkflowInstance): boolean {
    if (!config.filters) return true;
    for (const [key, value] of Object.entries(config.filters)) {
      if (inst.context[key] !== value) return false;
    }
    return true;
  }

  function instancesForColumn(column: KanbanColumnDef): WorkflowInstance[] {
    const inColumn =
      column.stepId === UNCATEGORIZED_STEP_ID
        ? instances.filter((inst) => !config.columns.some((c) => c.stepId === inst.currentStep))
        : instances.filter((inst) => inst.currentStep === column.stepId);
    const ordered = sortByServerOrder(inColumn);
    return ordered.filter(
      (inst) => matchesStaticFilters(inst) && matchesSearch(inst) && matchesChips(inst),
    );
  }

  /**
   * ↑/↓ within-column keyboard reorder (N19). Optimistically re-sorts, then
   * persists the moved card's new `sortOrder` server-side — the board's
   * display order (instancesForColumn) is always derived from the server
   * value, so a reload keeps this order, unlike the superseded K2 client-
   * session-only implementation. `direction` -1 moves the card earlier, 1
   * moves it later.
   */
  function reorderCard(cardId: string, stepId: string, direction: -1 | 1) {
    const inColumn = instances.filter((inst) => inst.currentStep === stepId);
    const sorted = sortByServerOrder(inColumn);
    const sortedIds = sorted.map((inst) => inst.workflowId);
    const nextIds = moveWithinOrder(sortedIds, cardId, direction);
    if (!nextIds) return;

    const targetIndex = nextIds.indexOf(cardId);
    const siblings = nextIds
      .filter((id) => id !== cardId)
      .map((id) => sorted.find((inst) => inst.workflowId === id))
      .filter((inst): inst is WorkflowInstance => inst !== undefined);
    const newSortOrder = computeSortOrderForMove(siblings, targetIndex);

    void reorder(cardId, newSortOrder, DEMO_SESSION).catch(() => {
      const inst = instances.find((i) => i.workflowId === cardId);
      const label = inst ? contextString(inst.context, config.cardFields.titleField) || cardId : cardId;
      shake(cardId, `Couldn't save the new position for ${label}. Please try again.`);
    });

    const inst = instances.find((i) => i.workflowId === cardId);
    const label = inst ? contextString(inst.context, config.cardFields.titleField) || cardId : cardId;
    const columnLabel = config.columns.find((c) => c.stepId === stepId)?.label ?? stepId;
    const position = targetIndex + 1;
    setAnnounce(`Moved ${label} to position ${position} of ${nextIds.length} in ${columnLabel}`);
  }

  const totalAll = instances.length;
  const totalVisible = instances.filter(
    (inst) => matchesStaticFilters(inst) && matchesSearch(inst) && matchesChips(inst),
  ).length;
  const hasActiveFilter = search.trim().length > 0 || activeChipIds.size > 0;
  // Item 6: when the active search/chips empty the WHOLE board (every column,
  // not just one), show a single centered recovery panel instead of N
  // separate per-column "no matching" texts.
  const boardEmptyFiltered = hasActiveFilter && totalAll > 0 && totalVisible === 0;

  function toggleChip(id: string) {
    setActiveChipIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function clearAll() {
    setSearch("");
    setActiveChipIds(new Set());
  }

  function scrollToColumn(stepId: string) {
    setCollapsed((prev) => ({ ...prev, [stepId]: false }));
    const track = trackRef.current;
    if (!track) return;
    const col = track.querySelector<HTMLElement>(`[data-kanban-col="${stepId}"]`);
    if (col) {
      const delta = col.getBoundingClientRect().left - track.getBoundingClientRect().left;
      track.scrollTo({ left: track.scrollLeft + delta - 16, behavior: "smooth" });
    }
  }

  if (!isLoading && error && instances.length === 0 && config.instanceIds.length > 0) {
    return (
      <ErrorState
        title={labels.errorTitle}
        description={error instanceof WorkflowServiceError ? error.message : labels.errorBody}
        data-testid="error-state"
        action={
          <Button type="button" variant="navy" size="sm" onClick={() => window.location.reload()}>
            {labels.retry}
          </Button>
        }
      />
    );
  }

  const hasAnyInstances = config.instanceIds.length > 0;

  if (!hasAnyInstances && !isLoading) {
    return (
      <EmptyState
        headline={labels.emptyBoardTitle}
        description={labels.emptyBoardBody}
        data-testid="empty-state"
      />
    );
  }

  // Item 1 (design-audit-2026-07-17): a synthetic trailing "Uncategorized"
  // column collects any instance whose currentStep matches no configured
  // board column, so it's visible instead of silently disappearing.
  const hasUncategorized = instances.some(
    (inst) => !config.columns.some((c) => c.stepId === inst.currentStep),
  );
  const displayColumns: KanbanColumnDef[] = hasUncategorized
    ? [...config.columns, { stepId: UNCATEGORIZED_STEP_ID, label: labels.uncategorized, tone: "warning" }]
    : config.columns;

  // Item 9: table-view rows — the same filtered instances as the board, flattened
  // in column order, each carrying its column label + terminal-ness for due-tier grading.
  const tableRows = displayColumns.flatMap((col) =>
    instancesForColumn(col).map((instance) => ({
      instance,
      columnLabel: col.label,
      isTerminalColumn:
        col.stepId === UNCATEGORIZED_STEP_ID
          ? (legalTargets[instance.currentStep ?? ""] ?? []).length === 0
          : (legalTargets[col.stepId] ?? []).length === 0,
    })),
  );

  const countsByStep: Record<string, number> = {};
  for (const col of config.columns) {
    countsByStep[col.stepId] = instances.filter((i) => i.currentStep === col.stepId).length;
  }

  return (
    <div className="flex flex-col gap-2" data-testid="kanban-board">
      {/* Item 5: assertive (not polite) so moves/refusals interrupt and are heard
          immediately, matching the reference's announce-every-move behavior. */}
      <div aria-live="assertive" role="status" className="sr-only">
        {announce}
      </div>

      {(labels.title || labels.subtitle) && (
        <div className="flex flex-col">
          {labels.title && <h2 className="dq-card-title">{labels.title}</h2>}
          {labels.subtitle && <p className="text-xs text-[var(--color-text-muted)]">{labels.subtitle}</p>}
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-2">
        <KanbanToolbar
          searchValue={search}
          onSearchChange={setSearch}
          filterChips={config.filterChips ?? []}
          activeChipIds={activeChipIds}
          onToggleChip={toggleChip}
          resultSummary={`${totalVisible} of ${totalAll} ${labels.itemNoun}`}
          hasActiveFilter={hasActiveFilter}
          onClearAll={clearAll}
          labels={labels}
        />
        {config.showViewToggle && (
          <SegmentedControl
            name="kanban-view"
            value={view}
            onChange={(v) => setView(v as "board" | "table")}
            options={[
              { value: "board", label: labels.boardView },
              { value: "table", label: labels.tableView },
            ]}
          />
        )}
      </div>

      {config.showFlowRail && view === "board" && (
        <KanbanFlowRail columns={config.columns} countsByStep={countsByStep} onColumnClick={scrollToColumn} />
      )}

      {view === "table" ? (
        <KanbanTableView
          rows={tableRows}
          cardFields={config.cardFields}
          labels={labels}
          onRowClick={onCardClick}
        />
      ) : boardEmptyFiltered ? (
        <EmptyState
          headline={labels.noResultsTitle}
          description={`No ${labels.itemNoun} match the current search and filters.`}
          data-testid="board-no-results"
          action={
            <Button type="button" variant="outline" size="sm" onClick={clearAll}>
              {labels.clearAll}
            </Button>
          }
        />
      ) : (
      <div
        ref={trackRef}
        className="flex flex-1 gap-3 overflow-x-auto pb-2"
        role="region"
        aria-label="Kanban board columns"
      >
        {displayColumns.map((col) => (
          <KanbanColumn
            key={col.stepId}
            column={col}
            columns={config.columns}
            instances={instancesForColumn(col)}
            isLoading={isLoading}
            cardFields={config.cardFields}
            legalTargets={legalTargets}
            isUncategorized={col.stepId === UNCATEGORIZED_STEP_ID}
            transitionErrors={transitionErrors}
            onDismissError={dismissError}
            onMoveTo={(cardId, fromStep, toStep) => {
              if (isLegalMove({ fromStep, toStep, locked: isLocked(cardId), allowDrag: true, legalTargets })) {
                commitMove(cardId, fromStep, toStep);
              } else {
                refuseMove(cardId, "illegal");
              }
            }}
            onPointerDownCard={onPointerDownCard}
            onCardClick={onCardClick}
            onReorder={(cardId, direction) => reorderCard(cardId, col.stepId, direction)}
            shakeId={shakeId}
            landedId={landedId}
            drag={drag}
            collapsed={!!collapsed[col.stepId]}
            onToggleCollapse={() => setCollapsed((prev) => ({ ...prev, [col.stepId]: !prev[col.stepId] }))}
            hasActiveFilter={hasActiveFilter}
            labels={labels}
          />
        ))}
      </div>
      )}

      {/* DR-7 reference fidelity: the keyboard-hint footer bar the KAN audit
          flagged as MISSING — matches the reference's board-only footer
          ("Drag a card, or focus one and use ←→↑↓ to move · M opens the move
          menu"). Not shown in table view — the hints describe board gestures. */}
      {view === "board" && (
        <footer
          data-testid="kanban-keyboard-hint"
          className="flex flex-wrap items-center gap-1.5 border-t border-[var(--color-border-default)] px-2 py-1.5 text-xs text-[var(--color-text-muted)]"
        >
          <span>Drag a card, or focus one and use</span>
          <span className="inline-flex items-center gap-1">
            {["←", "→", "↑", "↓"].map((k) => (
              <kbd
                key={k}
                className="inline-flex h-[15px] min-w-[15px] items-center justify-center rounded-[4px] border border-[var(--color-border-strong)] bg-[var(--color-surface)] px-1 text-xs font-medium leading-none text-[var(--color-text)]"
              >
                {k}
              </kbd>
            ))}
          </span>
          <span>to move ·</span>
          <kbd className="inline-flex h-[15px] min-w-[15px] items-center justify-center rounded-[4px] border border-[var(--color-border-strong)] bg-[var(--color-surface)] px-1 text-xs font-medium leading-none text-[var(--color-text)]">
            M
          </kbd>
          <span>opens the move menu</span>
        </footer>
      )}

      {drag && (
        <DragGhost
          drag={drag}
          instance={instances.find((i) => i.workflowId === drag.cardId)}
          cardFields={config.cardFields}
        />
      )}
    </div>
  );
}

function DragGhost({
  drag,
  instance,
  cardFields,
}: {
  drag: { x: number; y: number; ox: number; oy: number; w: number };
  instance: WorkflowInstance | undefined;
  cardFields: KanbanConfig["cardFields"];
}) {
  if (!instance) return null;
  const title = contextString(instance.context, cardFields.titleField) || instance.workflowId;
  return (
    <div
      className="pointer-events-none fixed z-50 flex flex-col gap-1 rounded-[var(--radius-card)] border border-[var(--color-secondary)] bg-[var(--color-surface)] p-3 shadow-lg"
      style={{
        left: drag.x - drag.ox,
        top: drag.y - drag.oy,
        width: drag.w,
        transform: "rotate(2.5deg) scale(1.03)",
      }}
      aria-hidden="true"
    >
      <p className="m-0 text-sm font-semibold text-[var(--color-text)] line-clamp-2">{title}</p>
    </div>
  );
}
