import * as React from "react";
import { isLegalMove } from "../lib/legal-targets.js";

export interface KanbanDragState {
  cardId: string;
  fromStep: string;
  x: number;
  y: number;
  ox: number;
  oy: number;
  w: number;
  h: number;
  targetStep: string;
  targetIndex: number;
  legal: boolean;
}

export interface UseKanbanDragOptions {
  allowDrag: boolean;
  trackRef: React.RefObject<HTMLDivElement | null>;
  isLocked: (cardId: string) => boolean;
  legalTargets: Record<string, string[]>;
  onCommit: (cardId: string, fromStep: string, toStep: string) => void;
  onRefuse: (cardId: string, reason: "locked" | "permission" | "illegal") => void;
}

/**
 * Pointer-based lift/ghost/drop-indicator/autoscroll drag engine for the
 * kanban board (LEGALITY-CONSTRAINED DRAG). Cards lift freely on pointerdown;
 * `isLegalMove` (lib/legal-targets.ts, derived from the workflow definition)
 * decides whether the current hover column accepts the drop. Keyboard/a11y
 * parity is provided by the existing Advance/Reject buttons + the card's
 * "Move to…" menu — this hook only drives pointer interaction.
 */
export function useKanbanDrag(opts: UseKanbanDragOptions) {
  const [drag, setDrag] = React.useState<KanbanDragState | null>(null);
  const dragRef = React.useRef<KanbanDragState | null>(null);
  const rafRef = React.useRef<number | null>(null);
  const pointerRef = React.useRef({ x: 0, y: 0 });
  const scrollDirRef = React.useRef(0);
  const targetListElRef = React.useRef<HTMLElement | null>(null);
  const optsRef = React.useRef(opts);
  optsRef.current = opts;

  const recompute = React.useCallback(() => {
    const d = dragRef.current;
    const track = optsRef.current.trackRef.current;
    if (!d || !track) return;
    const { x, y } = pointerRef.current;
    const cols = Array.from(track.querySelectorAll<HTMLElement>("[data-kanban-col]"));
    if (cols.length === 0) return;

    let target: HTMLElement | null = null;
    let best = Infinity;
    for (const col of cols) {
      const r = col.getBoundingClientRect();
      if (x >= r.left && x <= r.right) {
        target = col;
        break;
      }
      const dist = Math.min(Math.abs(x - r.left), Math.abs(x - r.right));
      if (dist < best) {
        best = dist;
        target = col;
      }
    }
    if (!target) return;

    const stepId = target.dataset.kanbanCol ?? d.targetStep;
    const listEl = target.querySelector<HTMLElement>("[data-kanban-list]");
    targetListElRef.current = listEl;

    let idx = 0;
    if (listEl) {
      const cards = Array.from(listEl.querySelectorAll<HTMLElement>("[data-kanban-card]"));
      for (const cardEl of cards) {
        const r = cardEl.getBoundingClientRect();
        if (y > r.top + r.height / 2) idx++;
      }
    }

    const trackRect = track.getBoundingClientRect();
    scrollDirRef.current = x < trackRect.left + 80 ? -1 : x > trackRect.right - 80 ? 1 : 0;

    const legal = isLegalMove({
      fromStep: d.fromStep,
      toStep: stepId,
      locked: optsRef.current.isLocked(d.cardId),
      allowDrag: optsRef.current.allowDrag,
      legalTargets: optsRef.current.legalTargets,
    });

    if (d.targetStep !== stepId || d.targetIndex !== idx || d.x !== x || d.y !== y || d.legal !== legal) {
      const next: KanbanDragState = { ...d, targetStep: stepId, targetIndex: idx, x, y, legal };
      dragRef.current = next;
      setDrag(next);
    }
  }, []);

  const startLoop = React.useCallback(() => {
    const step = () => {
      if (!dragRef.current) {
        rafRef.current = null;
        return;
      }
      const track = optsRef.current.trackRef.current;
      if (scrollDirRef.current && track) track.scrollLeft += scrollDirRef.current * 16;
      const listEl = targetListElRef.current;
      if (listEl) {
        const r = listEl.getBoundingClientRect();
        const { y } = pointerRef.current;
        if (y < r.top + 48) listEl.scrollTop -= 12;
        else if (y > r.bottom - 48) listEl.scrollTop += 12;
      }
      recompute();
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
  }, [recompute]);

  const onMove = React.useCallback(
    (e: PointerEvent) => {
      pointerRef.current = { x: e.clientX, y: e.clientY };
      recompute();
    },
    [recompute],
  );

  const onUp = React.useCallback(() => {
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    scrollDirRef.current = 0;
    const d = dragRef.current;
    dragRef.current = null;
    setDrag(null);
    if (!d) return;
    if (d.targetStep === d.fromStep) return; // same-column drop — nothing to commit
    if (d.legal) optsRef.current.onCommit(d.cardId, d.fromStep, d.targetStep);
    else optsRef.current.onRefuse(d.cardId, "illegal");
  }, [onMove]);

  const onPointerDownCard = React.useCallback(
    (cardId: string, fromStep: string, e: React.PointerEvent<HTMLElement>) => {
      if (e.button !== 0) return;
      if ((e.target as HTMLElement).closest("[data-nodrag]")) return;
      if (optsRef.current.isLocked(cardId)) {
        optsRef.current.onRefuse(cardId, "locked");
        return;
      }
      if (!optsRef.current.allowDrag) {
        optsRef.current.onRefuse(cardId, "permission");
        return;
      }
      e.preventDefault();
      const rect = e.currentTarget.getBoundingClientRect();
      pointerRef.current = { x: e.clientX, y: e.clientY };
      scrollDirRef.current = 0;
      const initial: KanbanDragState = {
        cardId,
        fromStep,
        x: e.clientX,
        y: e.clientY,
        ox: e.clientX - rect.left,
        oy: e.clientY - rect.top,
        w: rect.width,
        h: rect.height,
        targetStep: fromStep,
        targetIndex: 0,
        legal: true,
      };
      dragRef.current = initial;
      setDrag(initial);
      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup", onUp);
      startLoop();
    },
    [onMove, onUp, startLoop],
  );

  React.useEffect(
    () => () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    },
    [onMove, onUp],
  );

  return { drag, onPointerDownCard };
}
