import { useQueries, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  getInstance,
  getDefinition,
  advanceInstance,
  rejectInstance,
  reorderInstance,
} from "@dbp/ps-workflow/client";
import type { WorkflowInstance, WorkflowDefinition } from "@dbp/ps-workflow/client";
import { computeLegalTargets } from "../lib/legal-targets.js";

const instanceKey = (workflowId: string) =>
  ["ps-workflow", "instance", workflowId] as const;

const definitionKey = (definitionId: string) =>
  ["ps-workflow", "definition", definitionId] as const;

/**
 * Fetches multiple workflow instances by ID in parallel, plus the workflow
 * definition (for legal-move derivation — see lib/legal-targets.ts).
 *
 * PS.WORKFLOW does not expose GET /instances?definitionId=, so each instance
 * must be fetched individually. See FEATURE.md §Limitations for the PS.WORKFLOW
 * minor required to add that endpoint.
 */
export function useKanbanInstances(definitionId: string, instanceIds: string[]) {
  const queryClient = useQueryClient();

  const results = useQueries({
    queries: instanceIds.map((id) => ({
      queryKey: instanceKey(id),
      queryFn: () => getInstance(id),
      retry: false,
    })),
  });

  const definitionQuery = useQuery({
    queryKey: definitionKey(definitionId),
    queryFn: () => getDefinition(definitionId),
    retry: false,
    enabled: definitionId.length > 0,
  });

  const instances: WorkflowInstance[] = [];
  let isLoading = false;
  let error: Error | null = null;

  for (const r of results) {
    if (r.isLoading) isLoading = true;
    if (r.error && !error) error = r.error as Error;
    if (r.data) instances.push(r.data);
  }

  const definition: WorkflowDefinition | undefined = definitionQuery.data;
  const legalTargets = computeLegalTargets(definition);

  function invalidateAll() {
    for (const id of instanceIds) {
      void queryClient.invalidateQueries({ queryKey: instanceKey(id) });
    }
  }

  async function advance(workflowId: string, session: string): Promise<void> {
    const updated = await advanceInstance(workflowId, {}, session);
    queryClient.setQueryData(instanceKey(workflowId), updated);
    // Refetch in background so the board reflects the latest server state.
    void queryClient.invalidateQueries({ queryKey: instanceKey(workflowId) });
  }

  async function reject(workflowId: string, session: string): Promise<void> {
    const updated = await rejectInstance(workflowId, {}, session);
    queryClient.setQueryData(instanceKey(workflowId), updated);
    void queryClient.invalidateQueries({ queryKey: instanceKey(workflowId) });
  }

  /**
   * N19 — persists a within-column reorder. Optimistically writes `sortOrder`
   * into the cached instance immediately (so the moved card doesn't jump
   * back while the request is in flight), then reconciles with the server's
   * response. On failure the cache is rolled back to the pre-move instance
   * and the error rethrown for the caller to surface.
   */
  async function reorder(workflowId: string, sortOrder: number, session: string): Promise<void> {
    const previous = queryClient.getQueryData<WorkflowInstance>(instanceKey(workflowId));
    if (previous) {
      queryClient.setQueryData(instanceKey(workflowId), { ...previous, sortOrder });
    }
    try {
      const updated = await reorderInstance(workflowId, { sortOrder }, session);
      queryClient.setQueryData(instanceKey(workflowId), updated);
    } catch (err) {
      if (previous) queryClient.setQueryData(instanceKey(workflowId), previous);
      throw err;
    }
  }

  return {
    instances,
    isLoading,
    error,
    definition,
    legalTargets,
    invalidateAll,
    advance,
    reject,
    reorder,
  };
}
