# @dbp/organisms/kanban

**registryId:** `APP.F04`

Legality-constrained drag-and-drop status-column board with configurable
columns, card fields, WIP limits, search + filter chips, and a locked
compliance-hold card state.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`KanbanConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Wired by convention: emitted apps render `@dbp/organisms/kanban` as `children`
of `CollectionBoardLayout` (`packages/stack/app-scaffolds/shells/transaction/layouts/collection-board.tsx`).
There is no separate `FEATURE_COMPONENT` registry constant in this repo.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/kanban` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
