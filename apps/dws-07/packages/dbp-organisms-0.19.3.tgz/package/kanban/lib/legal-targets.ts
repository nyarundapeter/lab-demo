import type { WorkflowDefinition, WorkflowStep } from "@dbp/ps-workflow/client";

/**
 * Pure, framework-free drag-legality logic (LEGALITY-CONSTRAINED DRAG, per
 * Sharavi's ruling on the vendor-pipeline kanban build): cards drag freely,
 * but only columns that are legal workflow-transition targets accept a drop.
 * "Legal" is derived from the workflow definition's own step graph, never
 * hardcoded per-board.
 */

/** The set of stepIds a card in `step` may legally move to (dedup, excludes self). */
export function legalTargetsForStep(step: WorkflowStep | undefined): string[] {
  if (!step) return [];
  const targets = new Set<string>();
  if (step.type === "subprocess") {
    targets.add(step.next);
    if (step.onReject) targets.add(step.onReject);
  } else {
    if (step.next) targets.add(step.next);
    if (step.onReject) targets.add(step.onReject);
    if (step.route) {
      for (const branch of step.route.branches) targets.add(branch.next);
      targets.add(step.route.default);
    }
  }
  targets.delete(step.id);
  return Array.from(targets);
}

/** stepId -> legal target stepIds, for every step in the definition. */
export function computeLegalTargets(
  definition: Pick<WorkflowDefinition, "steps"> | undefined,
): Record<string, string[]> {
  const map: Record<string, string[]> = {};
  if (!definition) return map;
  for (const step of definition.steps) {
    map[step.id] = legalTargetsForStep(step);
  }
  return map;
}

/**
 * Actor roles ∩ a step's assigneeRoles — mirrors PS.WORKFLOW's own server-side
 * role guard (server/engine.ts `hasRoleIntersection`), so the board can
 * pre-empt a 403 by not offering an action it already knows will fail.
 */
export function hasRoleIntersection(actorRoles: string[], assigneeRoles: string[]): boolean {
  return actorRoles.some((r) => assigneeRoles.includes(r));
}

/**
 * Whether `actorRoles` may act on `step` at all (the assigneeRoles guard
 * only — not full step-graph legality, see `isLegalMove` above). Fails OPEN
 * (returns true) when there is no step yet (definition not fetched) or the
 * step declares no assigneeRoles (e.g. a subprocess step) — Advance/Reject
 * stay visible rather than being hidden on missing data.
 */
export function actorEligibleForStep(
  step: WorkflowStep | undefined,
  actorRoles: string[],
): boolean {
  const assigneeRoles = step && "assigneeRoles" in step ? step.assigneeRoles : undefined;
  if (!assigneeRoles || assigneeRoles.length === 0) return true;
  return hasRoleIntersection(actorRoles, assigneeRoles);
}

export interface IsLegalMoveParams {
  fromStep: string;
  toStep: string;
  /** The card's own lock/compliance-hold state — locked cards may never move. */
  locked: boolean;
  /** The board-level drag-permission gate (KanbanConfig.allowDrag). */
  allowDrag: boolean;
  legalTargets: Record<string, string[]>;
}

/**
 * Whether a card may be dropped on `toStep`. Locked cards and a disabled
 * `allowDrag` gate always refuse. Moving within the same column (reorder) is
 * always legal. Moving to a different column requires `toStep` to be a
 * workflow-derived legal target of `fromStep`.
 */
export function isLegalMove(params: IsLegalMoveParams): boolean {
  const { fromStep, toStep, locked, allowDrag, legalTargets } = params;
  if (locked) return false;
  if (!allowDrag) return false;
  if (fromStep === toStep) return true;
  return (legalTargets[fromStep] ?? []).includes(toStep);
}

/**
 * Resolves which PS.WORKFLOW action commits a move to `toStep`. PS.WORKFLOW
 * has no generic "transitionTo" endpoint (see FEATURE.md §Limitations) — a
 * drag onto the step's declared `next`/route target commits via `advance`,
 * a drag onto `onReject` commits via `reject`. Returns null for a same-column
 * drop (no server call — a same-column drag is not a cross-column
 * transition) or for a target with no resolvable action. Within-column
 * ↑/↓ keyboard reorder (K2) is a separate, client-side-only concern — see
 * lib/card-order.ts — since PS.WORKFLOW has no order field/endpoint to
 * persist it to.
 */
export function resolveMoveAction(
  step: WorkflowStep | undefined,
  toStep: string,
): "advance" | "reject" | null {
  if (!step || step.type === "subprocess") {
    if (step?.type === "subprocess") {
      if (step.onReject === toStep) return "reject";
      if (step.next === toStep) return "advance";
    }
    return null;
  }
  if (step.onReject === toStep) return "reject";
  if (step.next === toStep) return "advance";
  if (step.route && (step.route.branches.some((b) => b.next === toStep) || step.route.default === toStep)) {
    // Route targets are resolved server-side from context at advance time —
    // dropping on any route-branch column requests "advance" and trusts the
    // server's own predicate evaluation to pick the actual destination.
    return "advance";
  }
  return null;
}
