/**
 * Pure, framework-free within-column card order logic.
 *
 * N19 (Sharavi 2026-07-17) supersedes the interim K2 client-session-only
 * ordering: PS.WORKFLOW now persists a `sortOrder` field server-side (POST
 * /instances/:id/reorder), so order survives a page reload instead of living
 * only in React state. `sortByServerOrder` is the read-side sort;
 * `computeSortOrderForMove` is the write-side gap calculation a
 * keyboard/drag reorder uses to pick the new value to persist for the
 * single moved card (never its neighbors).
 *
 * `sortByServerOrder` deliberately does NOT use a strict "sortOrder asc,
 * nulls last" comparator (that IS the contract for PS.WORKFLOW's generic
 * listInstances — see server/storage.ts): within one kanban column, a card
 * with no explicit sortOrder yet is not "unordered", it's simply at its
 * createdAt-derived position — that position must compare correctly against
 * a freshly-reordered sibling's real sortOrder value, or a single-card move
 * would always snap to the very bottom of the column instead of landing
 * next to its intended neighbor. `effectiveSortKey` gives every card
 * (touched or not) one comparable number for exactly this reason: it's a
 * pure function of the instance alone (sortOrder, or its createdAt
 * timestamp as a fallback) — never of its position in some other array —
 * so the read-side sort and the write-side gap calculation always agree on
 * "where a card currently sits", even across renders and after only one of
 * two originally-untouched siblings has been given a real sortOrder.
 */

type OrderableInstance = { workflowId: string; sortOrder: number | null; createdAt: string };

/** A stable numeric key for an instance whether or not `sortOrder` has ever been set. */
function effectiveSortKey(inst: OrderableInstance): number {
  return inst.sortOrder ?? new Date(inst.createdAt).getTime();
}

/** Effective-key ascending (see module doc comment for why this isn't a literal nulls-last comparator). */
export function sortByServerOrder<T extends OrderableInstance>(items: T[]): T[] {
  return [...items].sort((a, b) => {
    const delta = effectiveSortKey(a) - effectiveSortKey(b);
    return delta !== 0 ? delta : a.createdAt.localeCompare(b.createdAt);
  });
}

/**
 * Computes the sortOrder value to persist for a card moved to `targetIndex`
 * within `siblings` (the column's other cards, in current display order —
 * i.e. excluding the moved card). Gap-based ordering: the midpoint of the
 * two adjacent siblings' effective keys, so a single reorder only ever
 * writes the moved card, never its neighbors.
 */
export function computeSortOrderForMove(siblings: OrderableInstance[], targetIndex: number): number {
  const before = siblings[targetIndex - 1];
  const after = siblings[targetIndex];
  const beforeKey = before ? effectiveSortKey(before) : undefined;
  const afterKey = after ? effectiveSortKey(after) : undefined;
  if (beforeKey !== undefined && afterKey !== undefined) return (beforeKey + afterKey) / 2;
  if (beforeKey !== undefined) return beforeKey + 1000;
  if (afterKey !== undefined) return afterKey - 1000;
  return 0;
}

/** Applies a persisted order to a column's instance list; unordered/new items are appended, in their original relative order, after the ordered ones. */
export function applyOrder<T extends { workflowId: string }>(
  items: T[],
  order: string[] | undefined,
): T[] {
  if (!order || order.length === 0) return items;
  const byId = new Map(items.map((item) => [item.workflowId, item]));
  const ordered: T[] = [];
  for (const id of order) {
    const item = byId.get(id);
    if (item) {
      ordered.push(item);
      byId.delete(id);
    }
  }
  for (const item of items) {
    if (byId.has(item.workflowId)) ordered.push(item);
  }
  return ordered;
}

/**
 * Swaps `cardId` with its neighbor in `direction` (-1 = up/earlier, 1 =
 * down/later). Returns the new order, or `null` when `cardId` is missing or
 * already at that boundary (no-op — the caller should not announce a move).
 */
export function moveWithinOrder(
  order: string[],
  cardId: string,
  direction: -1 | 1,
): string[] | null {
  const index = order.indexOf(cardId);
  if (index === -1) return null;
  const target = index + direction;
  if (target < 0 || target >= order.length) return null;
  const next = [...order];
  const tmp = next[index]!;
  next[index] = next[target]!;
  next[target] = tmp;
  return next;
}
