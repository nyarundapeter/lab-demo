import type { BadgeProps } from "@dbp/ui";
import type { CardFieldsConfig } from "../types.js";

export function contextString(ctx: Record<string, unknown>, key: string | undefined): string {
  if (!key) return "";
  const val = ctx[key];
  if (val === undefined || val === null || val === "") return "";
  return String(val);
}

export function contextBoolean(ctx: Record<string, unknown>, key: string | undefined): boolean {
  if (!key) return false;
  return Boolean(ctx[key]);
}

/** Reads an array-of-strings context field (`tagsField`). Non-array/missing values render no chips. */
export function contextTags(ctx: Record<string, unknown>, key: string | undefined): string[] {
  if (!key) return [];
  const val = ctx[key];
  if (!Array.isArray(val)) return [];
  return val.filter((v): v is string => typeof v === "string" && v.length > 0);
}

/**
 * Risk/priority value → Badge tone. Any unmapped value safely falls back to
 * "gray" — Badge has no "neutral" tone name (the `--color-neutral-*` triad is
 * consumed directly by BoardCard's locked/assignee/due slots, not by Badge).
 */
export function riskTone(value: string): NonNullable<BadgeProps["tone"]> {
  const v = value.toLowerCase();
  if (v === "high" || v === "critical") return "danger";
  if (v === "medium") return "warning";
  return "gray";
}

export function isOverdue(dueIso: string, isTerminalColumn: boolean): boolean {
  if (isTerminalColumn) return false;
  const due = new Date(dueIso);
  if (Number.isNaN(due.getTime())) return false;
  return due.getTime() < Date.now();
}

export function formatDue(dueIso: string): string {
  const due = new Date(dueIso);
  if (Number.isNaN(due.getTime())) return dueIso;
  return due.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/** Graded due-date tier — drives both the label and the tone (never color-alone: label text always changes too). */
export type DueTier = "overdue" | "today" | "soon" | "normal" | "none";

export interface DueDisplay {
  label: string;
  tier: DueTier;
}

/**
 * Resolves a due-date field to a graded display: overdue (danger+bold, past
 * columns only — never in a terminal column), "Due today", "Nd" for the next
 * 3 days ("soon"), a formatted date beyond that ("normal"), or the italic
 * "No date" placeholder when the field is configured but unset — mirroring
 * the reference's graded warning tiers (design-audit-2026-07-17 kanban item 7).
 */
export function resolveDueDisplay(dueIso: string, isTerminalColumn: boolean, noDateLabel = "No date"): DueDisplay {
  if (!dueIso) return { label: noDateLabel, tier: "none" };
  const due = new Date(dueIso);
  if (Number.isNaN(due.getTime())) return { label: dueIso, tier: "normal" };
  if (isTerminalColumn) return { label: formatDue(dueIso), tier: "normal" };

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfDue = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();
  const diffDays = Math.round((startOfDue - startOfToday) / 86_400_000);

  if (diffDays < 0) return { label: formatDue(dueIso), tier: "overdue" };
  if (diffDays === 0) return { label: "Due today", tier: "today" };
  if (diffDays <= 3) return { label: `${diffDays}d`, tier: "soon" };
  return { label: formatDue(dueIso), tier: "normal" };
}

/** Resolves every card-facing display value from a WorkflowInstance's context in one place. */
export function resolveCardDisplay(context: Record<string, unknown>, cardFields: CardFieldsConfig) {
  const title = contextString(context, cardFields.titleField);
  const subtitle = cardFields.subtitleField ? contextString(context, cardFields.subtitleField) : "";
  const meta = cardFields.metaField ? contextString(context, cardFields.metaField) : "";
  const badge = cardFields.badgeField ? contextString(context, cardFields.badgeField) : "";
  const risk = cardFields.riskField ? contextString(context, cardFields.riskField) : "";
  const rawStatus = cardFields.statusField ? contextString(context, cardFields.statusField) : "";
  const status = cardFields.statusField ? rawStatus || "Unknown status" : "";
  const assignee = cardFields.assigneeField ? contextString(context, cardFields.assigneeField) : "";
  const due = cardFields.dueDateField ? contextString(context, cardFields.dueDateField) : "";
  const locked = contextBoolean(context, cardFields.lockField);
  const lockReason = cardFields.lockReasonField ? contextString(context, cardFields.lockReasonField) : "";
  const tags = contextTags(context, cardFields.tagsField);
  return { title, subtitle, meta, badge, risk, status, assignee, due, locked, lockReason, tags };
}
