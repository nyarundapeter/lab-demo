# @dbp/organisms/contact-form

**registryId:** `APP.F13`

Standalone public contact form. Real package with real stories, but the generator's public-detail-content composition is hand-generated JSX rather than importing this package.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`ContactFormConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
**Orphaned** — this is a real package with real stories, but `scripts/scaffold-solution.mjs` never references it: the generator's public-detail-content composition is hand-generated JSX rather than an import of this package. Not reached via the `FEATURE_COMPONENT` map or any bespoke import site. (Found while building `organism-catalogue.ts`, same discovery pattern as `ConversationalLayout` in `template-catalogue.ts`.)

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/contact-form` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
