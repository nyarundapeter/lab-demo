import * as React from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { sendEmail } from "@dbp/ps-notif/client";
import { Button, Alert, Input, FormField, Checkbox } from "@dbp/ui";
import { ContactFormConfig, ContactSubmissionSchema } from "./types.js";
import type { ContactSubmission } from "./types.js";
import { EMAIL_TOKENS } from "./email-tokens.js";

// ─── Public re-exports ────────────────────────────────────────────────────────
export type { ContactFormConfig, ContactSubmission } from "./types.js";

// ─── exactOptionalPropertyTypes helper ───────────────────────────────────────
// With exactOptionalPropertyTypes:true, passing `undefined` explicitly to an
// optional prop is a type error. Use this to conditionally include the error prop.
function opt(value: string | undefined): { error: string } | Record<never, never> {
  return value !== undefined ? { error: value } : {};
}

// ─── HTML escape helper (ported from TMaaS) ───────────────────────────────────

function escapeHtml(str: string | undefined | null): string {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;");
}

// ─── Email HTML builder (re-skinned to DBP design tokens) ─────────────────────
// Hex values are resolved in email-tokens.ts — EMAIL_TOKENS maps each to its
// CSS custom property equivalent for maintainability.

type EmailFields = {
  firstName: string;
  lastName: string;
  email: string;
  organisation: string;
  message: string;
  consent: boolean;
  phone?: string | undefined;
  role?: string | undefined;
  interest?: string | undefined;
  need?: string | undefined;
};

export function buildContactEmailHtml(fields: EmailFields): string {
  const row = (label: string, value: string | undefined) =>
    value
      ? `<tr><td style="padding:6px 12px 6px 0;font-weight:600;color:${EMAIL_TOKENS.labelText};white-space:nowrap;vertical-align:top">${label}</td><td style="padding:6px 0;color:${EMAIL_TOKENS.bodyText}">${escapeHtml(value)}</td></tr>`
      : "";

  return `<!DOCTYPE html>
<html lang="en">
<body style="margin:0;padding:0;font-family:system-ui,sans-serif;background:${EMAIL_TOKENS.pageBg}">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px">
    <tr><td>
      <table width="600" cellpadding="0" cellspacing="0" style="background:${EMAIL_TOKENS.cardBg};border-radius:12px;border:1px solid ${EMAIL_TOKENS.border};overflow:hidden;margin:0 auto">
        <tr><td style="background:${EMAIL_TOKENS.headerBg};padding:24px 32px">
          <span style="color:${EMAIL_TOKENS.headerText};font-size:18px;font-weight:700;letter-spacing:-0.3px">New Contact Request</span>
        </td></tr>
        <tr><td style="padding:28px 32px">
          <table cellpadding="0" cellspacing="0" width="100%">
            ${row("Name", `${fields.firstName} ${fields.lastName}`)}
            ${row("Email", fields.email)}
            ${row("Phone", fields.phone)}
            ${row("Organisation", fields.organisation)}
            ${row("Role", fields.role)}
            ${row("Area of Interest", fields.interest)}
            ${row("Need", fields.need)}
            ${row("Consent Given", fields.consent ? "Yes" : "No")}
          </table>
          <hr style="border:none;border-top:1px solid ${EMAIL_TOKENS.border};margin:20px 0">
          <p style="margin:0 0 6px;font-weight:600;color:${EMAIL_TOKENS.labelText}">Message</p>
          <p style="margin:0;color:${EMAIL_TOKENS.bodyText};line-height:1.6;white-space:pre-wrap">${escapeHtml(fields.message)}</p>
        </td></tr>
        <tr><td style="background:${EMAIL_TOKENS.footerBg};padding:16px 32px;font-size:12px;color:${EMAIL_TOKENS.mutedText};border-top:1px solid ${EMAIL_TOKENS.border}">
          Submitted via the contact form. Reply directly to this email to reach the submitter.
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

// ─── Default consent label ─────────────────────────────────────────────────────

const DEFAULT_CONSENT_LABEL =
  "I agree to the processing of my personal data for this enquiry.";

// ─── Default values ────────────────────────────────────────────────────────────

function buildDefaultValues(): ContactSubmission {
  return {
    firstName: "",
    lastName: "",
    email: "",
    organisation: "",
    message: "",
    phone: "",
    role: "",
    interest: "",
    need: "",
    // RHF default — zodResolver enforces literal true on submit
    consent: false as unknown as true,
    website: "",
  };
}

// ─── ContactForm ───────────────────────────────────────────────────────────────

/**
 * APP.F13 — Contact / Inquiry Form
 *
 * Receives CONFIG, never data. Submits via PS.NOTIF sendEmail()
 * (Layer 07 → Layer 06 client SDK only — no /server import).
 *
 * Honeypot: the hidden `website` field must remain empty.
 * If it is filled the form silently shows success without calling sendEmail.
 *
 * Dispatches "dbp:contact-form:submitted" CustomEvent on success.
 */
export default function ContactForm({ config }: { config: ContactFormConfig }) {
  const parseResult = ContactFormConfig.safeParse(config);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="ContactForm configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <ContactFormInner config={parseResult.data} />;
}

// ─── Inner component ───────────────────────────────────────────────────────────

function ContactFormInner({ config }: { config: ContactFormConfig }) {
  const [successVisible, setSuccessVisible] = React.useState(false);
  const [serverError, setServerError] = React.useState<string | null>(null);

  const showPhone = config.showPhone !== false;
  const showRole = config.showRole !== false;
  const showInterest = config.showInterest === true;
  const showNeed = config.showNeed === true;

  const {
    register,
    control,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ContactSubmission>({
    resolver: zodResolver(ContactSubmissionSchema),
    defaultValues: buildDefaultValues(),
  });

  async function onValid(data: ContactSubmission) {
    setServerError(null);
    setSuccessVisible(false);

    // Honeypot check — silently show success to fool bots; do NOT call sendEmail
    if (data.website) {
      setSuccessVisible(true);
      return;
    }

    const { firstName, lastName, email, organisation, message, phone, role, interest, need, consent } = data;

    // Only pass optional fields when non-empty (satisfies exactOptionalPropertyTypes)
    const emailFields: EmailFields = {
      firstName,
      lastName,
      email,
      organisation,
      message,
      consent,
      ...(phone ? { phone } : {}),
      ...(role ? { role } : {}),
      ...(interest ? { interest } : {}),
      ...(need ? { need } : {}),
    };

    const html = buildContactEmailHtml(emailFields);
    const subject = `${config.subjectPrefix ?? "Contact Request"} from ${firstName} ${lastName} - ${organisation}`;

    try {
      await sendEmail({ to: config.recipient, subject, html, replyTo: email });

      setSuccessVisible(true);
      document.dispatchEvent(
        new CustomEvent("dbp:contact-form:submitted", {
          detail: { recipient: config.recipient, firstName, lastName, organisation },
          bubbles: true,
        }),
      );
      reset(buildDefaultValues());
    } catch (err: unknown) {
      setServerError(
        err instanceof Error
          ? err.message
          : "Failed to send your message. Please try again.",
      );
    }
  }

  if (successVisible) {
    return (
      <div
        className="flex flex-col items-center gap-4 rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)] p-8 text-center"
        data-testid="success-state"
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[var(--color-success-subtle)]">
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-[var(--color-success)]"
            aria-hidden="true"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </div>
        <p className="text-base font-semibold text-[var(--color-text)]">
          {config.successMessage ?? "Your message has been sent."}
        </p>
        <Button
          variant="outline"
          size="sm"
          type="button"
          onClick={() => setSuccessVisible(false)}
          data-testid="reset-button"
        >
          Submit another message
        </Button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit(onValid)}
      noValidate
      className="flex flex-col gap-5"
      data-testid="contact-form"
    >
      {config.description && (
        <p className="text-sm text-[var(--color-text-muted)]">{config.description}</p>
      )}

      {/* Server-level error */}
      {serverError && (
        <Alert tone="danger" data-testid="server-error">
          {serverError}
        </Alert>
      )}

      {/* Name row */}
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="First Name" required {...opt(errors.firstName?.message)}>
          <Input
            type="text"
            autoComplete="given-name"
            disabled={isSubmitting}
            data-testid="input-firstName"
            {...register("firstName")}
          />
        </FormField>
        <FormField label="Last Name" required {...opt(errors.lastName?.message)}>
          <Input
            type="text"
            autoComplete="family-name"
            disabled={isSubmitting}
            data-testid="input-lastName"
            {...register("lastName")}
          />
        </FormField>
      </div>

      {/* Email + Phone */}
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Email" required {...opt(errors.email?.message)}>
          <Input
            type="email"
            autoComplete="email"
            placeholder="you@company.com"
            disabled={isSubmitting}
            data-testid="input-email"
            {...register("email")}
          />
        </FormField>
        {showPhone && (
          <FormField label="Phone" {...opt(errors.phone?.message)}>
            <Input
              type="tel"
              autoComplete="tel"
              placeholder="+1 000 000 0000"
              maxLength={20}
              disabled={isSubmitting}
              data-testid="input-phone"
              {...register("phone")}
            />
          </FormField>
        )}
      </div>

      {/* Organisation */}
      <FormField label="Organisation" required {...opt(errors.organisation?.message)}>
        <Input
          type="text"
          autoComplete="organization"
          disabled={isSubmitting}
          data-testid="input-organisation"
          {...register("organisation")}
        />
      </FormField>

      {/* Role */}
      {showRole && (
        <FormField label="Role / Title" {...opt(errors.role?.message)}>
          <Input
            type="text"
            autoComplete="organization-title"
            placeholder="e.g. Head of Digital Transformation"
            maxLength={150}
            disabled={isSubmitting}
            data-testid="input-role"
            {...register("role")}
          />
        </FormField>
      )}

      {/* Interest + Need */}
      {(showInterest || showNeed) && (
        <div className="grid gap-4 sm:grid-cols-2">
          {showInterest && (
            <FormField label="Area of Interest" {...opt(errors.interest?.message)}>
              <Input
                type="text"
                disabled={isSubmitting}
                data-testid="input-interest"
                {...register("interest")}
              />
            </FormField>
          )}
          {showNeed && (
            <FormField label="What do you need?" {...opt(errors.need?.message)}>
              <Input
                type="text"
                disabled={isSubmitting}
                data-testid="input-need"
                {...register("need")}
              />
            </FormField>
          )}
        </div>
      )}

      {/* Message */}
      <FormField
        label="Message"
        required
        helperText="Share your goals, challenges, or timeline."
        {...opt(errors.message?.message)}
      >
        <textarea
          rows={5}
          disabled={isSubmitting}
          data-testid="input-message"
          className="w-full resize-y rounded-md border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2 text-sm text-[var(--color-text)] placeholder:text-[var(--color-text-muted)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] disabled:opacity-50"
          {...register("message")}
        />
      </FormField>

      {/* Consent — uses Controller because Radix Checkbox uses onCheckedChange, not onChange */}
      <div className="flex flex-col gap-1">
        <label className="flex cursor-pointer items-start gap-3">
          <Controller
            name="consent"
            control={control}
            render={({ field }) => (
              <Checkbox
                checked={field.value === true}
                onCheckedChange={(checked) => field.onChange(checked === true)}
                disabled={isSubmitting}
                data-testid="consent-checkbox"
              />
            )}
          />
          <span
            className={`text-sm leading-relaxed ${
              errors.consent
                ? "text-[var(--color-danger-text)]"
                : "text-[var(--color-text-muted)]"
            }`}
          >
            {config.consentLabel ?? DEFAULT_CONSENT_LABEL}
          </span>
        </label>
        {errors.consent && (
          <p
            className="ml-7 text-xs text-[var(--color-danger-text)]"
            role="alert"
            data-testid="consent-error"
          >
            {errors.consent.message}
          </p>
        )}
      </div>

      {/* Honeypot — visually hidden from humans; bots fill it */}
      <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
        <label htmlFor="cf-website">Website</label>
        <input
          id="cf-website"
          type="text"
          tabIndex={-1}
          autoComplete="off"
          {...register("website")}
        />
      </div>

      {/* Submit */}
      <div className="flex items-center justify-between pt-1">
        <p className="text-xs text-[var(--color-text-muted)]">
          <span className="text-[var(--color-danger)]">*</span> Required fields
        </p>
        <Button
          type="submit"
          loading={isSubmitting}
          disabled={isSubmitting}
          data-testid="submit-button"
        >
          {isSubmitting ? "Sending…" : (config.submitLabel ?? "Send request")}
        </Button>
      </div>
    </form>
  );
}
