import { z } from "zod";

// ─── Contact Submission Schema (ported from TMaaS contactSchema) ─────────────
// Zod is the source of truth — use z.infer, never hand-authored interfaces.

/**
 * ContactSubmissionSchema — the validated shape of a form submission.
 *
 * Required: firstName, lastName, email, organisation, message, consent (must be true).
 * Optional: phone, role, interest, need (controlled by ContactFormConfig field toggles).
 * Honeypot: website — must be empty; bots fill it silently.
 */
export const ContactSubmissionSchema = z
  .object({
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    email: z.string().email("A valid email address is required"),
    organisation: z.string().min(1, "Organisation is required"),
    message: z.string().min(10, "Message must be at least 10 characters"),
    phone: z.string().optional(),
    role: z.string().max(150, "Role must be 150 characters or fewer").optional(),
    interest: z.string().optional(),
    need: z.string().optional(),
    consent: z.literal(true, {
      errorMap: () => ({ message: "You must consent to submit this form" }),
    }),
    /** Honeypot field — must remain empty; bots fill it, humans don't */
    website: z.string().optional(),
  })
  .strict();

export type ContactSubmission = z.infer<typeof ContactSubmissionSchema>;

// ─── ContactFormConfig ────────────────────────────────────────────────────────

/**
 * ContactFormConfig — the typed contract for APP.F13.
 *
 * Data-only contract (no function fields). Callbacks are surfaced via DOM
 * CustomEvent: "dbp:contact-form:submitted".
 */
export const ContactFormConfig = z
  .object({
    /**
     * Email address to send submissions to.
     * Passed per-solution so the feature is recipient-agnostic.
     */
    recipient: z.string().email("recipient must be a valid email address"),

    /**
     * @deprecated — ContactForm is body-only (single-header rule §4.4).
     * Accepted but not rendered. Pass the form/page title via the shell PageHeader.
     */
    title: z.string().optional(),

    /** Optional descriptive text shown below the title. */
    description: z.string().optional(),

    /** Text shown on the submit button. Defaults to "Send request". */
    submitLabel: z.string().optional(),

    /** Success message shown after a successful submission. Defaults to "Your message has been sent." */
    successMessage: z.string().optional(),

    /** Consent checkbox label. Defaults to a generic data-processing statement. */
    consentLabel: z.string().optional(),

    /**
     * Email subject line prefix.
     * Full subject: "<subjectPrefix> from <firstName> <lastName> - <organisation>".
     * Defaults to "Contact Request".
     */
    subjectPrefix: z.string().optional(),

    // ─── Optional field toggles ───────────────────────────────────────────
    /** Show the phone number field. Defaults to true. */
    showPhone: z.boolean().optional(),

    /** Show the role / title field. Defaults to true. */
    showRole: z.boolean().optional(),

    /** Show the area of interest select. Defaults to false. */
    showInterest: z.boolean().optional(),

    /** Show the "what do you need" select. Defaults to false. */
    showNeed: z.boolean().optional(),
  })
  .strict();

export type ContactFormConfig = z.infer<typeof ContactFormConfig>;
