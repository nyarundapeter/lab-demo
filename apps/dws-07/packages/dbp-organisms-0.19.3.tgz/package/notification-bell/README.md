# @dbp/organisms/notification-bell

**registryId:** `APP.F34`

Top-bar bell with an unread badge and a tabbed (All/Unread/Action) triage popover.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Consumed by
Bespoke import — mounted into `AppChrome`'s `notifications` slot by the solution's chrome composition (e.g. `apps/dbp/app/solution-chrome.tsx`).

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/notification-bell` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
