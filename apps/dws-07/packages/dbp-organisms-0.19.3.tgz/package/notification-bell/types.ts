import { z } from "zod";

// Config schema for the @dbp/organisms/notification-bell organism. Promoted
// from packages/shared/ui/src/bindings (2026-07-21 Bindings/Admin resolution
// — it owns useNotifications() fetch + mark-read mutation state, so it is an
// organism, not a presentation-layer binding).
export const NotificationBellConfig = z.object({
  sessionHeader: z.string().optional(),
});

export type NotificationBellConfig = z.infer<typeof NotificationBellConfig>;
