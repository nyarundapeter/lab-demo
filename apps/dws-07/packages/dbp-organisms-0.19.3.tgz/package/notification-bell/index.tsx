import * as React from "react";
import { Bell } from "lucide-react";
import { useNotifications } from "@dbp/ps-notif/client";
import type { Notification } from "@dbp/ps-notif/client";
import {
  Badge,
  Button,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  cn,
  relativeTimeCompact,
} from "@dbp/ui";
import type { NotificationBellConfig } from "./types.js";

export type NotificationBellProps = NotificationBellConfig;


const RECENT_LIMIT = 8;

/**
 * NotifPopover triage tabs (NOT-07). Reference (`notif-centre.jsx:109-123`)
 * is a tabbed popover: All / Unread / Action-required. "Action required" is
 * filtered on the existing (unconstrained) PS.NOTIF `type` field matching the
 * "action" taxonomy value — no new PS.NOTIF verb needed for this filter.
 * Archive/snooze affordances are out of scope here (no PS.NOTIF verb — W5b).
 */
type NotifTab = "all" | "unread" | "action";

function filterByTab(items: Notification[], tab: NotifTab): Notification[] {
  if (tab === "unread") return items.filter((n) => n.status === "unread");
  if (tab === "action") return items.filter((n) => n.type === "action");
  return items;
}

function NotifList({ items, isLoading, onMarkRead }: { items: Notification[]; isLoading: boolean; onMarkRead: (id: string) => void }) {
  const recent = items.slice(0, RECENT_LIMIT);

  if (isLoading) {
    return (
      <div className="px-3 py-4 text-sm text-[var(--color-text)] opacity-60 text-center">
        Loading…
      </div>
    );
  }

  if (recent.length === 0) {
    // Empty state: no notifications match the active tab yet.
    return (
      <div data-testid="notif-empty-state" className="px-3 py-4 text-sm text-[var(--color-text)] opacity-60 text-center">
        You're all caught up — new notifications will show up here as they arrive.
      </div>
    );
  }

  return (
    <>
      {recent.map((n) => (
        <DropdownMenuItem
          key={n.id}
          className={cn(
            "flex flex-col items-start gap-0.5 px-3 py-1.5 cursor-pointer",
            n.status === "unread" && "bg-[color-mix(in_srgb,var(--color-primary)_6%,transparent)]",
          )}
          onClick={() => onMarkRead(n.id)}
          aria-label={`${n.status === "unread" ? "Unread: " : ""}${n.message}`}
        >
          <span
            className={cn(
              "text-xs leading-snug",
              n.status === "unread"
                ? "font-medium text-[var(--color-text)]"
                : "text-[var(--color-text)] opacity-70",
            )}
          >
            {n.message}
          </span>
          <span className="text-xs text-[var(--color-text)] opacity-50">
            {relativeTimeCompact(n.ts)}
          </span>
        </DropdownMenuItem>
      ))}
    </>
  );
}

export function NotificationBell({ sessionHeader }: NotificationBellProps) {
  const { items, unread, markRead, markAllRead, isLoading } =
    useNotifications(sessionHeader);
  const [tab, setTab] = React.useState<NotifTab>("all");
  const actionCount = React.useMemo(
    () => items.filter((n) => n.type === "action" && n.status === "unread").length,
    [items],
  );

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          aria-label={`Notifications${unread > 0 ? `, ${unread} unread` : ""}`}
          style={{ height: "var(--shell-control-h)", width: "var(--shell-control-h)" }}
          className={cn(
            "relative rounded p-0",
            "text-[var(--color-text)] hover:bg-[color-mix(in_srgb,var(--color-border)_50%,transparent)]",
            "focus-visible:ring-2",
          )}
        >
          <Bell size={17} strokeWidth={1.5} aria-hidden="true" />
          {unread > 0 && (
            <Badge
              tone="danger"
              aria-hidden="true"
              className="absolute -top-1 -right-1 h-4 min-w-[1rem] px-1 text-xs leading-none flex items-center justify-center"
            >
              {unread > 99 ? "99+" : unread}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-80 max-h-[28rem] overflow-hidden p-0 flex flex-col">
        <div className="flex items-center justify-between px-2 py-1.5">
          <DropdownMenuLabel className="p-0 text-sm font-semibold">
            Notifications
          </DropdownMenuLabel>
          {unread > 0 && (
            <Button
              variant="link"
              onClick={markAllRead}
              className="text-xs"
              aria-label="Mark all notifications as read"
            >
              Mark all read
            </Button>
          )}
        </div>
        <DropdownMenuSeparator className="m-0" />

        <Tabs value={tab} onValueChange={(v) => setTab(v as NotifTab)} className="flex flex-col min-h-0">
          <TabsList className="shrink-0 px-1">
            <TabsTrigger value="all" className="min-h-8 px-2.5 text-xs">
              All
            </TabsTrigger>
            <TabsTrigger value="unread" className="min-h-8 px-2.5 text-xs">
              Unread{unread > 0 ? ` (${unread > 99 ? "99+" : unread})` : ""}
            </TabsTrigger>
            <TabsTrigger value="action" className="min-h-8 px-2.5 text-xs">
              Action{actionCount > 0 ? ` (${actionCount})` : ""}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="overflow-y-auto max-h-72">
            <NotifList items={filterByTab(items, "all")} isLoading={isLoading} onMarkRead={markRead} />
          </TabsContent>
          <TabsContent value="unread" className="overflow-y-auto max-h-72">
            <NotifList items={filterByTab(items, "unread")} isLoading={isLoading} onMarkRead={markRead} />
          </TabsContent>
          <TabsContent value="action" className="overflow-y-auto max-h-72">
            <NotifList items={filterByTab(items, "action")} isLoading={isLoading} onMarkRead={markRead} />
          </TabsContent>
        </Tabs>

        <DropdownMenuSeparator className="m-0" />
        <a
          href="/notifications"
          className="block shrink-0 px-3 py-2 text-center text-xs font-medium text-[var(--color-primary)] hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--color-primary)]"
        >
          View all
        </a>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export type { NotificationBellConfig } from "./types.js";
