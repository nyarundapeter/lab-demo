import * as React from "react";
import { CheckCircle2, Lock, MessageSquare, Reply } from "lucide-react";
import { Alert, Avatar, Badge, Button, ActivityComposer } from "@dbp/ui";
import type { ActivityDraft, ActivityTimelineConfig } from "@dbp/ui";
import { CommentThreadConfig, type Comment, type CommentReply, type CommentThreadConfigInput } from "./types.js";

/**
 * Mutation seam — function props are extracted before the Zod parse (Zod
 * schemas are data-only). Local state always applies the change immediately
 * (mirrors the reference's optimistic in-memory `setComments`); a real host
 * additionally persists via these callbacks.
 */
export interface CommentThreadProps extends CommentThreadConfigInput {
  onAddComment?: (body: string) => void;
  onReply?: (threadId: string, body: string) => void;
  onResolve?: (id: string, resolved: boolean) => void;
  onEditComment?: (id: string, body: string) => void;
}

const baseComposerConfig: Omit<ActivityTimelineConfig, "labels"> = {
  activityTypes: {},
  mentions: false,
  tags: false,
  attachments: false,
};

function composerConfigWith(placeholder?: string): ActivityTimelineConfig {
  return placeholder ? { ...baseComposerConfig, labels: { composerPlaceholder: placeholder } } : baseComposerConfig;
}

/**
 * APP.F57 — Comment Thread (registry id assigned during central registration)
 *
 * collaboration-system/comments.jsx `CommentThread`/`CommentItem`. Receives
 * fully-resolved comment data via config (no PS.DATA fetch owned here — see
 * types.ts doc comment); owns local reply-nesting/resolve/filter UI state,
 * mirroring the reference's in-memory `setComments`.
 */
export default function CommentThread(rawConfig: CommentThreadProps) {
  const { onAddComment, onReply, onResolve, onEditComment, ...rest } = rawConfig;
  const parseResult = CommentThreadConfig.safeParse(rest);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="CommentThread configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>{e.path.join(".") || "root"}: {e.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }

  return (
    <CommentThreadInner
      config={parseResult.data}
      {...(onAddComment !== undefined && { onAddComment })}
      {...(onReply !== undefined && { onReply })}
      {...(onResolve !== undefined && { onResolve })}
      {...(onEditComment !== undefined && { onEditComment })}
    />
  );
}

interface CommentThreadInnerProps {
  config: CommentThreadConfig;
  onAddComment?: (body: string) => void;
  onReply?: (threadId: string, body: string) => void;
  onResolve?: (id: string, resolved: boolean) => void;
  onEditComment?: (id: string, body: string) => void;
}

function CommentThreadInner({ config, onAddComment, onReply, onResolve, onEditComment }: CommentThreadInnerProps) {
  const [comments, setComments] = React.useState<Comment[]>(config.comments);
  const [filterUnresolved, setFilterUnresolved] = React.useState(false);
  const [replyFor, setReplyFor] = React.useState<string | null>(null);
  const [editId, setEditId] = React.useState<string | null>(null);
  const [expanded, setExpanded] = React.useState<Record<string, boolean>>({});

  React.useEffect(() => setComments(config.comments), [config.comments]);

  const unresolvedCount = comments.filter((c) => !c.resolved).length;
  const visible = filterUnresolved ? comments.filter((c) => !c.resolved) : comments;

  const groups: { day: string; items: Comment[] }[] = [];
  for (const c of visible) {
    let g = groups.find((x) => x.day === c.dayLabel);
    if (!g) {
      g = { day: c.dayLabel, items: [] };
      groups.push(g);
    }
    g.items.push(c);
  }

  function resolveThread(id: string, resolved: boolean) {
    setComments((cs) => cs.map((c) => (c.id === id ? { ...c, resolved } : c)));
    if (resolved) setExpanded((e) => ({ ...e, [id]: false }));
    onResolve?.(id, resolved);
  }

  function addReply(threadId: string, body: string) {
    const reply: CommentReply = {
      id: `r${Date.now()}`,
      author: { id: config.currentUserId, name: "You" },
      body,
      createdAtLabel: "just now",
      edited: false,
    };
    setComments((cs) => cs.map((c) => (c.id === threadId ? { ...c, replies: [...c.replies, reply] } : c)));
    setReplyFor(null);
    onReply?.(threadId, body);
  }

  function addComment(body: string) {
    const comment: Comment = {
      id: `c${Date.now()}`,
      author: { id: config.currentUserId, name: "You" },
      body,
      createdAtLabel: "just now",
      dayLabel: "Today",
      edited: false,
      resolved: false,
      replies: [],
    };
    setComments((cs) => [...cs, comment]);
    onAddComment?.(body);
  }

  function saveEdit(id: string, body: string) {
    setComments((cs) =>
      cs.map((c) => {
        if (c.id === id) return { ...c, body, edited: true };
        return { ...c, replies: c.replies.map((r) => (r.id === id ? { ...r, body, edited: true } : r)) };
      }),
    );
    setEditId(null);
    onEditComment?.(id, body);
  }

  const compact = config.density === "compact";

  return (
    <div className="flex h-full flex-col" data-testid="comment-thread">
      {/* filter bar */}
      <div
        className={`flex flex-shrink-0 items-center gap-2 border-b border-[var(--color-border-default)] ${compact ? "px-3.5 py-2.5" : "px-5 py-3"}`}
      >
        <Button
          variant="outline"
          size="sm"
          data-testid="unresolved-filter"
          aria-pressed={filterUnresolved}
          onClick={() => setFilterUnresolved((v) => !v)}
          className={`h-auto gap-1.5 rounded-pill px-2.5 py-1 text-xs font-semibold ${
            filterUnresolved
              ? "border-[var(--color-primary)] bg-[var(--color-navy-50)] text-primary"
              : "border-[var(--color-border-default)] text-[var(--color-text-muted)]"
          }`}
        >
          {unresolvedCount} unresolved
        </Button>
        {filterUnresolved && (
          <Button type="button" variant="ghost" size="sm" onClick={() => setFilterUnresolved(false)}>
            Show all
          </Button>
        )}
      </div>

      {/* thread list */}
      <div className={`flex-1 overflow-y-auto ${compact ? "px-3.5 py-2" : "px-5 py-2"}`}>
        {groups.map((g) => (
          <div key={g.day}>
            <div className="my-2 flex items-center gap-3 text-xs font-medium text-[var(--color-text-disabled)]">
              <span className="h-px flex-1 bg-[var(--color-border-default)]" />
              <span className="rounded-pill border border-[var(--color-border-default)] bg-[var(--color-surface)] px-2.5 py-1 text-[var(--color-text-muted)]">
                {g.day}
              </span>
              <span className="h-px flex-1 bg-[var(--color-border-default)]" />
            </div>
            {g.items.map((c) => {
              const collapsed = c.resolved && !expanded[c.id];
              if (collapsed) {
                return (
                  <div
                    key={c.id}
                    role="button"
                    tabIndex={0}
                    data-testid={`resolved-collapsed-${c.id}`}
                    onClick={() => setExpanded((e) => ({ ...e, [c.id]: true }))}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") setExpanded((ex) => ({ ...ex, [c.id]: true }));
                    }}
                    className="mb-1.5 flex cursor-pointer items-center gap-2.5 rounded-[9px] border border-[var(--color-success-border)] bg-[var(--color-success-surface)] px-3 py-2.5"
                  >
                    <CheckCircle2 size={16} className="shrink-0 text-[var(--color-success)]" aria-hidden="true" />
                    <div className="min-w-0 flex-1 text-xs">
                      <span className="font-semibold">Resolved thread</span>
                      <span className="ml-1.5 text-[var(--color-text-muted)]">
                        {c.author.name} · {c.replies.length + 1} messages
                        {c.resolvedBy && ` · resolved by ${c.resolvedBy.name}`}
                      </span>
                    </div>
                    <Button type="button" variant="ghost" size="sm">
                      Expand
                    </Button>
                  </div>
                );
              }
              return (
                <div
                  key={c.id}
                  data-testid={`comment-${c.id}`}
                  className={`mb-1 rounded-[10px] ${c.resolved ? "border border-[var(--color-success-border)] bg-[var(--color-success-surface)] pb-1" : ""}`}
                >
                  <CommentItem
                    c={c}
                    compact={compact}
                    own={c.author.id === config.currentUserId}
                    onEdit={setEditId}
                    editing={editId === c.id}
                    onSave={saveEdit}
                    onCancel={() => setEditId(null)}
                  />
                  {c.replies.map((r) => (
                    <CommentItem
                      key={r.id}
                      c={r}
                      isReply
                      compact={compact}
                      own={r.author.id === config.currentUserId}
                      onEdit={setEditId}
                      editing={editId === r.id}
                      onSave={saveEdit}
                      onCancel={() => setEditId(null)}
                    />
                  ))}
                  <div className="flex items-center gap-2 py-1.5 pl-8">
                    {replyFor !== c.id && (
                      <Button type="button" variant="ghost" size="sm" onClick={() => setReplyFor(c.id)}>
                        <Reply size={13} aria-hidden="true" /> Reply
                      </Button>
                    )}
                    {c.resolved ? (
                      <Button type="button" variant="ghost" size="sm" onClick={() => resolveThread(c.id, false)}>
                        Unresolve
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="text-[var(--color-success)]"
                        onClick={() => resolveThread(c.id, true)}
                        data-testid={`resolve-${c.id}`}
                      >
                        <CheckCircle2 size={13} aria-hidden="true" /> Resolve thread
                      </Button>
                    )}
                  </div>
                  {replyFor === c.id && (
                    <div className="pb-2 pl-8">
                      <ActivityComposer
                        config={composerConfigWith(`Reply to ${c.author.name}…`)}
                        onSave={(draft: ActivityDraft) => addReply(c.id, draft.plainText)}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
        {visible.length === 0 && (
          <div className="flex flex-col items-center gap-2 py-10 text-center" data-testid="empty-state">
            <MessageSquare size={22} strokeWidth={1.5} className="text-[var(--color-text-disabled)]" aria-hidden="true" />
            <h3 className="text-sm font-semibold">All caught up</h3>
            <p className="max-w-[280px] text-xs text-[var(--color-text-muted)]">
              No unresolved comments on this record. Switch off the filter to see resolved threads.
            </p>
          </div>
        )}
      </div>

      {/* composer pinned */}
      <div className={`flex-shrink-0 border-t border-[var(--color-border-default)] bg-[var(--color-surface-content)] ${compact ? "px-3.5 pb-3.5 pt-2.5" : "px-5 pb-4 pt-3"}`}>
        <ActivityComposer
          config={composerConfigWith(config.composerPlaceholder ?? "Add a comment…")}
          onSave={(draft: ActivityDraft) => addComment(draft.plainText)}
        />
      </div>
    </div>
  );
}

function CommentItem({
  c,
  isReply = false,
  compact,
  own,
  editing,
  onEdit,
  onSave,
  onCancel,
}: {
  c: Comment | CommentReply;
  isReply?: boolean;
  compact: boolean;
  /** Whether the current user authored this comment — gates the Edit affordance. */
  own: boolean;
  editing: boolean;
  onEdit: (id: string) => void;
  onSave: (id: string, body: string) => void;
  onCancel: () => void;
}) {
  return (
    <div
      data-testid={`comment-item-${c.id}`}
      className={isReply ? "py-1.5 pl-8" : "py-1.5"}
    >
      <div className="flex gap-2.5">
        <Avatar name={c.author.name} size={compact ? "sm" : "md"} {...(c.author.avatarSrc !== undefined && { src: c.author.avatarSrc })} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-2">
            <span className="text-sm font-semibold">{c.author.name}</span>
            {c.author.role && (
              <Badge tone="gray" size="sm">
                {c.author.role}
              </Badge>
            )}
            <span className="text-xs text-[var(--color-text-disabled)]">{c.createdAtLabel}</span>
            {c.edited && <span className="text-xs italic text-[var(--color-text-disabled)]">· edited</span>}
            <div className="flex-1" />
            {!editing && own && (
              <Button type="button" variant="ghost" size="sm" onClick={() => onEdit(c.id)} data-testid={`edit-${c.id}`}>
                Edit
              </Button>
            )}
          </div>
          {editing ? (
            <div className="mt-1.5">
              <ActivityComposer
                config={composerConfigWith("Edit comment…")}
                onSave={(draft: ActivityDraft) => onSave(c.id, draft.plainText)}
              />
              <Button type="button" variant="ghost" size="sm" className="mt-1" onClick={onCancel}>
                Cancel
              </Button>
            </div>
          ) : (
            <p className="mt-0.5 whitespace-pre-wrap text-sm text-[var(--color-text)]">{c.body}</p>
          )}
          {"resolved" in c && c.resolved && (
            <span className="mt-1 flex items-center gap-1.5 text-xs font-medium text-[var(--color-success)]">
              <Lock size={12} aria-hidden="true" /> Resolved
              {c.resolvedBy && ` by ${c.resolvedBy.name}`}
              {c.resolvedAtLabel && ` · ${c.resolvedAtLabel}`}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export type {
  CommentThreadConfig,
  CommentThreadConfigInput,
  Comment,
  CommentInput,
  CommentAuthor,
  CommentReply,
  CommentReplyInput,
} from "./types.js";
