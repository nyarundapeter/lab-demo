# @dbp/organisms/comment-thread

**registryId:** `APP.F57` (placeholder — assigned during central registration)

Record-scoped comment thread with reply nesting, resolve/unresolve, and an unresolved filter.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`CommentThreadConfig` — Zod schema exported from `types.ts` (source of truth). Comments arrive
fully resolved via config; no PS.DATA fetch is owned by this organism (see FEATURE.md).

## Consumed by
Bespoke import — mounted into a record detail rail/drawer alongside `activity-timeline`.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/comment-thread` via plain pnpm workspace
resolution (`workspace:*`). Standalone repos consume it as a committed tarball per
`docs/08-contributing/package-distribution.md`.
