import { z } from "zod";

// Config schema for the @dbp/organisms/comment-thread organism
// (collaboration-system/comments.jsx `CommentThread`/`CommentItem`). UI-tier
// build per Wave 3 Family 4f scope: comments arrive fully resolved via
// config (no PS.DATA fetch owned here) — a future host binds this to a real
// record-comments PS.DATA entity by supplying `comments` from its own query
// and wiring the `on*` callback props (function fields, not part of the Zod
// contract) to real mutations.

export const CommentAuthorSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  role: z.string().optional(),
  avatarSrc: z.string().optional(),
});
export type CommentAuthor = z.infer<typeof CommentAuthorSchema>;

export const CommentReplySchema = z.object({
  id: z.string().min(1),
  author: CommentAuthorSchema,
  body: z.string().min(1),
  createdAtLabel: z.string().min(1),
  edited: z.boolean().optional().default(false),
});
export type CommentReply = z.infer<typeof CommentReplySchema>;
export type CommentReplyInput = z.input<typeof CommentReplySchema>;

// `resolved`/`resolvedBy` model the reference's per-thread resolve state
// (comments.jsx `resolveThread`) — not present in any existing PS.DATA
// comment shape, so declared here as the fields a real comments entity
// would need.
export const CommentSchema = z.object({
  id: z.string().min(1),
  author: CommentAuthorSchema,
  body: z.string().min(1),
  createdAtLabel: z.string().min(1),
  /** Day-group heading (e.g. "Today", "Yesterday", "Jul 18") — pre-formatted by the caller. */
  dayLabel: z.string().min(1),
  edited: z.boolean().optional().default(false),
  resolved: z.boolean().optional().default(false),
  resolvedBy: CommentAuthorSchema.optional(),
  resolvedAtLabel: z.string().optional(),
  replies: z.array(CommentReplySchema).optional().default([]),
});
export type Comment = z.infer<typeof CommentSchema>;
export type CommentInput = z.input<typeof CommentSchema>;

export const CommentThreadConfig = z.object({
  comments: z.array(CommentSchema).default([]),
  /** Author id treated as "me" — gates the edit affordance on own comments. */
  currentUserId: z.string().min(1),
  density: z.enum(["roomy", "compact"]).optional().default("roomy"),
  composerPlaceholder: z.string().optional(),
});
export type CommentThreadConfig = z.infer<typeof CommentThreadConfig>;
/** Pre-parse shape (defaulted fields optional) — what callers/stories/tests construct. */
export type CommentThreadConfigInput = z.input<typeof CommentThreadConfig>;
