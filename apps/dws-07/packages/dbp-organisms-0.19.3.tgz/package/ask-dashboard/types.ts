import { z } from "zod";

// Config schema for the @dbp/organisms/ask-dashboard organism. Owns a live
// PS.AI query loop scoped to the current dashboard view (ai-example-
// dashboard/ai/page-dashboard.jsx:23-59, "Ask this dashboard"). `filters`/
// `answerActions` are caller-supplied ReactNode slots and are not
// representable in a Zod schema, so AskDashboardProps extends the parsed
// config with them directly.
export const AskDashboardConfig = z.object({
  placeholder: z.string().optional(),
  suggestedPrompts: z.array(z.string()).optional(),
  /** Forwarded to useAssistant() to scope the answer to the dashboard's active filters. */
  context: z.record(z.unknown()).optional(),
});

export type AskDashboardConfig = z.infer<typeof AskDashboardConfig>;
