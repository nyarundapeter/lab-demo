# @dbp/organisms/ask-dashboard

**registryId:** `APP.F35`

Inline "ask this dashboard" assistant scoped to the current view's filters.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Consumed by
Bespoke import — mounted at the top of a dashboard page.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/ask-dashboard` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.
