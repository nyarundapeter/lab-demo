import * as React from "react";
import { Send } from "lucide-react";
import { useAssistant } from "@dbp/ps-ai/client";
import { AiMark, AiThinking, FeedbackControl, Button, Input } from "@dbp/ui";
import type { AskDashboardConfig } from "./types.js";

export interface AskDashboardProps extends AskDashboardConfig {
  /** Caller-supplied filter chips describing the dashboard's active scope (e.g. period, region). */
  filters?: React.ReactNode;
  /** Rendered alongside feedback once an answer exists — caller-owned follow-through actions. */
  answerActions?: React.ReactNode;
}

/**
 * "Ask this dashboard" — an inline assistant scoped to the current view
 * (ai-example-dashboard/ai/page-dashboard.jsx:23-59). Owns a live PS.AI
 * query loop via `useAssistant(context)`; the answer is rendered as-is
 * (plain prose) — the reference's fabricated confidence/citation metadata
 * on the answer isn't real data `useAssistant` returns, so it isn't drawn.
 */
export function AskDashboard({
  placeholder = "e.g. Which cases are most likely to breach SLA this week?",
  suggestedPrompts = [],
  context,
  filters,
  answerActions,
}: AskDashboardProps) {
  const { ask, messages, streaming } = useAssistant(context);
  const [draft, setDraft] = React.useState("");

  const submit = (text: string) => {
    const q = text.trim();
    if (q === "" || streaming) return;
    setDraft("");
    void ask(q);
  };

  const lastAnswer = [...messages].reverse().find((m) => m.role === "assistant");

  return (
    <div
      className="rounded-[var(--radius-card,8px)] border border-[hsl(var(--ai-border))] bg-[hsl(var(--ai-soft)/0.35)] p-4"
      data-testid="ask-dashboard"
    >
      <div className="mb-2.5 flex flex-wrap items-center gap-2">
        <AiMark size={15} />
        <span className="text-sm font-semibold text-[var(--color-text)]">Ask this dashboard</span>
        {filters}
      </div>

      <div className="flex gap-2">
        <Input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") submit(draft);
          }}
          placeholder={placeholder}
          aria-label="Ask this dashboard"
          className="flex-1"
        />
        <Button type="button" variant="orange" onClick={() => submit(draft)} disabled={streaming} data-testid="ask-dashboard-submit">
          <Send size={14} aria-hidden="true" />
          Ask
        </Button>
      </div>

      {suggestedPrompts.length > 0 && (
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {suggestedPrompts.map((p) => (
            <Button key={p} type="button" variant="outline" size="sm" className="h-7 px-2.5 text-xs" onClick={() => submit(p)}>
              {p}
            </Button>
          ))}
        </div>
      )}

      {streaming && (
        <div className="mt-3.5">
          <AiThinking label="Composing answer" />
        </div>
      )}

      {!streaming && lastAnswer && (
        <div className="mt-3.5 border-t border-[hsl(var(--ai-border))] pt-3.5" data-testid="ask-dashboard-answer">
          <div className="mb-2 flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-[4px] border border-[hsl(var(--ai-border))] bg-[hsl(var(--ai-soft))] px-1.5 py-0.5 text-xs font-semibold text-[hsl(var(--ai-strong))]">
              <AiMark size={11} />
              AI answer
            </span>
          </div>
          <p className="mb-2 whitespace-pre-wrap text-sm leading-relaxed text-[var(--color-text)]">{lastAnswer.content}</p>
          <div className="flex items-center gap-2">
            {answerActions}
            <FeedbackControl compact className="ml-auto" />
          </div>
        </div>
      )}
    </div>
  );
}

export type { AskDashboardConfig } from "./types.js";
