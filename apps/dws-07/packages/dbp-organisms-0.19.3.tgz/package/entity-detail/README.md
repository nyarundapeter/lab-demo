# @dbp/organisms/entity-detail

**registryId:** `APP.F02`

Single-record detail panel: header fields, rail actions/meta, and a NotFound fallback.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`EntityDetailConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `object-page-detail` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/entity-detail` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
