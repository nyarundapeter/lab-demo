import { z } from "zod";

const FieldFormat = z.enum(["text", "number", "date", "badge"]);

const FieldDef = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
  format: FieldFormat.optional(),
});

const SectionDef = z.object({
  title: z.string().min(1),
  fields: z.array(FieldDef).min(1),
});

const HeaderConfig = z.object({
  titleField: z.string().min(1),
  subtitleField: z.string().optional(),
  statusField: z.string().optional(),
});

/**
 * Right-rail action (optional, additive).
 * Renders as a stacked outline button in the "Use in Work"-style rail card.
 * `event` is dispatched as a `dbp:entity-detail:action` CustomEvent on click,
 * carrying { id, entityType, entityId } — solutions wire behaviour off the event.
 */
const RailActionDef = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  /** Optional lucide icon name (e.g. "CheckSquare", "Link2", "Play"). */
  icon: z.string().optional(),
});

/**
 * Right-rail meta row (optional, additive).
 * Renders a label + value (mono, version-badge style) in the rail's meta card.
 */
const RailMetaDef = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
});

/**
 * Extra tab metadata (id/label only — Zod can't carry a React node). The
 * body for each id is supplied separately via the `extraTabsContent` prop on
 * the `EntityDetail` component, keyed by `id`. Used by domain-specific
 * wrappers (e.g. `@dbp/organism-config-detail`) that need tabs beyond the
 * built-in Details/Activity pair without forking this component.
 */
const ExtraTabDef = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
});

export const EntityDetailConfig = z.object({
  entityType: z.string().min(1),
  /**
   * The id of the record to show. May be empty or the sentinel "placeholder"
   * when no record is selected yet (master-detail). In that case the panel
   * renders a "select a record" empty state and skips the PS.DATA fetch — no
   * 404 retry loop. Solutions update this from a `dbp:entity-list:row-select`
   * CustomEvent (see FEATURE.md §Master-detail wiring).
   */
  entityId: z.string().default(""),
  sections: z.array(SectionDef).min(1),
  showActivity: z.boolean().default(true),
  header: HeaderConfig.optional(),
  /**
   * Optional right-rail actions ("Use in Work"-style stacked outline buttons).
   * Omitted → the actions rail card is not rendered.
   */
  actions: z.array(RailActionDef).optional(),
  /**
   * Optional right-rail meta rows (mono version-style badges).
   * Omitted → the meta rail is derived from the header status field only.
   */
  meta: z.array(RailMetaDef).optional(),
  /** Additional tabs appended after Activity. Bodies come from `extraTabsContent`, not this config. */
  extraTabs: z.array(ExtraTabDef).optional(),
  /** Label for the built-in details tab when extraTabs are present. @default "Details" */
  detailsLabel: z.string().min(1).default("Details"),
});

export type EntityDetailConfig = z.infer<typeof EntityDetailConfig>;
/** Pre-parse shape (defaulted fields like `showActivity`/`detailsLabel` are optional here) — use this for component prop types, not the post-parse output type. */
export type EntityDetailConfigInput = z.input<typeof EntityDetailConfig>;
export type RailAction = z.infer<typeof RailActionDef>;
export type RailMeta = z.infer<typeof RailMetaDef>;
export type ExtraTab = z.infer<typeof ExtraTabDef>;
