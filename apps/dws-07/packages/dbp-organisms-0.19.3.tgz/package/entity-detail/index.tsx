import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent, Alert, EmptyState, Grid, Col } from "@dbp/ui";
import { FileQuestion, MousePointerClick } from "lucide-react";
import { EntityDetailConfig, type EntityDetailConfigInput } from "./types.js";
import { EntityHeader } from "./components/entity-header.js";
import { SectionsGrid } from "./components/sections-grid.js";
import { ActivityTab } from "./components/activity-tab.js";
import { DetailRail } from "./components/detail-rail.js";
import { useEntityDetail } from "./hooks/use-entity-detail.js";

/**
 * `extraTabsContent` supplies the React body for each `config.extraTabs`
 * entry, keyed by `id`. Not part of `EntityDetailConfig` — Zod configs carry
 * serializable data only, and tab bodies are arbitrary JSX. Passed as a
 * sibling prop (not config data) so it survives JSX invocation
 * (`<EntityDetail {...config} extraTabsContent={...} />`). See
 * `@dbp/organism-config-detail` for the reference consumer.
 */
export default function EntityDetail(
  props: EntityDetailConfigInput & { extraTabsContent?: Record<string, React.ReactNode> }
) {
  const { extraTabsContent, ...config } = props;
  const parsed = EntityDetailConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Alert tone="danger" title="EntityDetail — invalid config">
        <ul className="mt-1 list-disc pl-5">
          {parsed.error.issues.map((issue, i) => (
            <li key={i}>{issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}{issue.message}</li>
          ))}
        </ul>
      </Alert>
    );
  }

  const { entityType, entityId, sections, showActivity, header, actions, meta, extraTabs, detailsLabel } = parsed.data;

  return (
    <EntityDetailInner
      entityType={entityType}
      entityId={entityId}
      sections={sections}
      showActivity={showActivity}
      header={header}
      actions={actions}
      meta={meta}
      extraTabs={extraTabs}
      extraTabsContent={extraTabsContent}
      detailsLabel={detailsLabel}
    />
  );
}

interface InnerProps {
  entityType: string;
  entityId: string;
  sections: EntityDetailConfig["sections"];
  showActivity: boolean;
  header: EntityDetailConfig["header"];
  actions: EntityDetailConfig["actions"];
  meta: EntityDetailConfig["meta"];
  extraTabs: EntityDetailConfig["extraTabs"];
  extraTabsContent: Record<string, React.ReactNode> | undefined;
  detailsLabel: string;
}

/** A record is "selected" when entityId is a real id (not empty, not the placeholder sentinel). */
export function isRecordSelected(entityId: string): boolean {
  const trimmed = entityId.trim();
  return trimmed.length > 0 && trimmed !== "placeholder";
}

function EntityDetailInner({
  entityType,
  entityId,
  sections,
  showActivity,
  header,
  actions,
  meta,
  extraTabs,
  extraTabsContent,
  detailsLabel,
}: InnerProps) {
  const selected = isRecordSelected(entityId);
  // Gate the fetch — when nothing is selected we must NOT hit
  // /entities/<type>/placeholder (404 → retry loop → permanent skeletons).
  const { data, isLoading, error } = useEntityDetail(entityType, entityId, selected);

  // ── No-selection state (master-detail: nothing picked yet) ────────────────
  if (!selected) {
    return (
      <EmptyState
        icon={<MousePointerClick size={22} strokeWidth={1.5} />}
        title="Select a record"
        description={`Choose a ${entityType} from the list to see its details here.`}
        data-testid="entity-detail-empty"
      />
    );
  }

  if (error) {
    const is404 =
      error instanceof Error &&
      (error.message.includes("404") || error.message.toLowerCase().includes("not found"));

    return is404 ? (
      <EmptyState
        icon={<FileQuestion size={22} strokeWidth={1.5} />}
        title="Entity not found"
        description={`No ${entityType} record was found for "${entityId}".`}
        role="alert"
      />
    ) : (
      <EmptyState tone="danger" headline="Failed to load entity" description={error.message} />
    );
  }

  // ── Content column (8 cols on wide layouts) ───────────────────────────────
  const contentColumn = (
    <div className="min-w-0">
      {header ? <EntityHeader config={header} data={data} isLoading={isLoading} /> : null}
      <SectionsGrid sections={sections} data={data} isLoading={isLoading} />
    </div>
  );

  const rail = (
    <DetailRail
      entityType={entityType}
      entityId={entityId}
      header={header}
      {...(actions !== undefined && { actions })}
      {...(meta !== undefined && { meta })}
      data={data}
      isLoading={isLoading}
    />
  );

  // ── Details body: 8/4 grid (collapses to single column in narrow slots) ───
  const detailsBody = (
    <Grid className="lg:items-start">
      <Col span={12} lg={8} className="min-w-0">{contentColumn}</Col>
      <Col span={12} lg={4} className="min-w-0">{rail}</Col>
    </Grid>
  );

  const hasExtraTabs = Boolean(extraTabs && extraTabs.length > 0);

  if (!showActivity && !hasExtraTabs) {
    return <div className="w-full">{detailsBody}</div>;
  }

  return (
    <div className="w-full">
      <Tabs defaultValue="details">
        <TabsList>
          <TabsTrigger value="details">{detailsLabel}</TabsTrigger>
          {showActivity && <TabsTrigger value="activity">Activity</TabsTrigger>}
          {extraTabs?.map((tab) => (
            <TabsTrigger key={tab.id} value={tab.id}>
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="details" className="mt-6">
          {detailsBody}
        </TabsContent>

        {showActivity && (
          <TabsContent value="activity" className="mt-6">
            <ActivityTab entityId={entityId} />
          </TabsContent>
        )}

        {extraTabs?.map((tab) => (
          <TabsContent key={tab.id} value={tab.id} className="mt-6">
            {extraTabsContent?.[tab.id] ?? (
              <EmptyState
                icon={<FileQuestion size={22} strokeWidth={1.5} />}
                title="No content"
                description={`No content was supplied for the "${tab.label}" tab.`}
              />
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
