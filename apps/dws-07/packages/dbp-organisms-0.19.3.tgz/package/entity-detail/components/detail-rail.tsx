import React from "react";
import * as LucideIcons from "lucide-react";
import { Button, SectionLabel, Skeleton } from "@dbp/ui";
import type { EntityDetailConfig, RailAction, RailMeta } from "../types.js";
import type { EntityData } from "@dbp/ps-data/client";

interface Props {
  entityType: string;
  entityId: string;
  header: EntityDetailConfig["header"];
  actions?: RailAction[];
  meta?: RailMeta[];
  data: EntityData | undefined;
  isLoading: boolean;
}

/** Resolve a lucide icon name to a component, falling back to a neutral dot. */
function resolveIcon(name?: string): React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }> {
  if (!name) return LucideIcons.ChevronRight;
  const icon = (LucideIcons as unknown as Record<string, unknown>)[name];
  return (icon as React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }>) ?? LucideIcons.ChevronRight;
}

function RailSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-5 py-5">
      <h3 className="mb-4 dq-card-title text-sm leading-snug">{title}</h3>
      {children}
    </section>
  );
}

export function DetailRail({ entityType, entityId, header, actions, meta, data, isLoading }: Props) {
  const status =
    header?.statusField && data ? String(data[header.statusField] ?? "") : undefined;

  // Build meta rows: explicit config.meta, otherwise derive from header status.
  const metaRows: { label: string; value: string }[] = [];
  if (meta && meta.length > 0) {
    for (const m of meta) {
      const v = data ? data[m.field] : undefined;
      metaRows.push({ label: m.label, value: v === null || v === undefined || v === "" ? "—" : String(v) });
    }
  } else if (status) {
    metaRows.push({ label: "Status", value: status });
  }

  function fireAction(action: RailAction) {
    document.dispatchEvent(
      new CustomEvent("dbp:entity-detail:action", {
        detail: { id: action.id, entityType, entityId },
        bubbles: true,
      }),
    );
  }

  if (isLoading) {
    return (
      <div className="w-full space-y-5">
        <section className="rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-5 py-5">
          <Skeleton className="mb-4 h-4 w-24" />
          <div className="space-y-2">
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
          </div>
        </section>
      </div>
    );
  }

  const hasActions = actions && actions.length > 0;

  if (!hasActions && metaRows.length === 0) return null;

  return (
    <div className="w-full space-y-5 lg:sticky lg:top-24">
      {hasActions && (
        <RailSection title="Use in Work">
          <div className="space-y-2">
            {actions!.map((action) => {
              const Icon = resolveIcon(action.icon);
              return (
                <Button
                  key={action.id}
                  variant="ghost"
                  onClick={() => fireAction(action)}
                  className="h-auto w-full justify-start gap-2.5 rounded-md border border-[var(--color-border-default)] bg-[var(--color-surface)] px-2.5 py-2 text-left text-xs font-medium text-[var(--color-primary)] hover:border-[var(--color-border-strong)] hover:bg-[var(--color-surface-content)]"
                  data-testid={`rail-action-${action.id}`}
                >
                  <Icon size={14} strokeWidth={1.5} className="shrink-0 text-[var(--color-text-muted)]" />
                  {action.label}
                </Button>
              );
            })}
          </div>
        </RailSection>
      )}

      {metaRows.length > 0 && (
        // "Metadata", not "Details" — the tab bar already has a "Details" tab and body
        // sections often carry a Details-like title; three "Details" labels on one
        // page read as a bug (admin review 2026-07-17).
        <RailSection title="Metadata">
          <div className="flex flex-wrap gap-2">
            {metaRows.map((row) => (
              <SectionLabel
                as="span"
                key={row.label}
                size="2xs"
                tone="primary"
                className="inline-flex items-center gap-1.5 rounded-pill border border-[var(--color-border-default)] bg-[var(--color-surface)] px-2.5 py-1 font-mono tracking-[0.12em]"
              >
                <span className="text-[var(--color-text-muted)]">{row.label}</span>
                {row.value}
              </SectionLabel>
            ))}
          </div>
        </RailSection>
      )}
    </div>
  );
}
