import React from "react";
import { Badge, Skeleton, useBreadcrumbOverride } from "@dbp/ui";
import type { EntityDetailConfig } from "../types.js";
import type { EntityData } from "@dbp/ps-data/client";

interface Props {
  config: NonNullable<EntityDetailConfig["header"]>;
  data: EntityData | undefined;
  isLoading: boolean;
}

export function EntityHeader({ config, data, isLoading }: Props) {
  // N36: once the record resolves, override the top-bar breadcrumb's terminal
  // crumb with its display name — this is the ONLY header EntityDetail renders
  // (ADR-0034 single-header rule), so it owns the breadcrumb override too.
  const resolvedTitle = data ? String(data[config.titleField] ?? "") : undefined;
  useBreadcrumbOverride(!isLoading && resolvedTitle ? resolvedTitle : undefined);

  if (isLoading) {
    return (
      <div className="mb-6 flex flex-col gap-2">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="h-4 w-36" />
      </div>
    );
  }

  const title = data ? String(data[config.titleField] ?? "—") : "—";
  const subtitle =
    config.subtitleField && data ? String(data[config.subtitleField] ?? "") : undefined;
  const status =
    config.statusField && data ? String(data[config.statusField] ?? "") : undefined;

  return (
    <header className="mb-6">
      <div className="flex flex-wrap items-center gap-3">
        <h2 className="text-xl font-bold leading-tight tracking-tight text-[var(--color-primary)]">
          {title}
        </h2>
        {status ? <Badge tone="gray">{status}</Badge> : null}
      </div>
      {subtitle ? (
        <p className="mt-2 text-sm leading-relaxed text-[var(--color-text-muted)]">
          {subtitle}
        </p>
      ) : null}
    </header>
  );
}
