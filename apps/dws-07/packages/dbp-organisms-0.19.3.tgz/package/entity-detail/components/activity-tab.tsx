import React from "react";
import { ScrollArea, Skeleton, Button, EmptyState, SectionLabel, formatDate } from "@dbp/ui";
import { History } from "lucide-react";
import { useActivityFeed } from "@dbp/ps-audit/client";

interface Props {
  entityId: string;
}

export function ActivityTab({ entityId }: Props) {
  const { events, loadMore, hasMore, isLoading, isFetchingNextPage } = useActivityFeed(entityId);

  if (isLoading) {
    return (
      <div className="flex flex-col gap-2">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }

  if (events.length === 0) {
    return (
      <EmptyState
        icon={<History size={22} strokeWidth={1.5} />}
        title="No activity yet"
        description="No activity has been recorded for this record."
      />
    );
  }

  return (
    <ScrollArea>
      <div className="flex flex-col gap-2">
        {events.map((event) => (
          <div
            key={event.id}
            className="rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-3.5 py-2.5 text-sm"
          >
            <div className="mb-1 flex items-center justify-between gap-2">
              <span className="font-semibold text-[var(--color-primary)]">
                {event.actor.displayName}
              </span>
              <SectionLabel size="2xs" className="font-mono tracking-[0.12em]">
                {formatDate(event.ts, "long")}
              </SectionLabel>
            </div>
            <p className="text-[var(--color-text-secondary)]">{event.action}</p>
          </div>
        ))}

        {hasMore ? (
          <Button
            variant="outline"
            size="sm"
            className="mt-2 w-full"
            onClick={loadMore}
            loading={isFetchingNextPage}
            disabled={isFetchingNextPage}
          >
            {isFetchingNextPage ? "Loading…" : "Load more"}
          </Button>
        ) : null}
      </div>
    </ScrollArea>
  );
}
