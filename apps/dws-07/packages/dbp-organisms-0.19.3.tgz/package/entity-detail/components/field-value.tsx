// De-duplicated onto the shared @dbp/ui renderer (design-system de-dup
// strategy, `docs/plans/design-system-dedup-2026-07-25/strategy.md` §3) —
// this file used to hand-roll the same value/format renderer now extracted
// to `packages/shared/ui/src/components/field-value.tsx`. Re-exported here
// (rather than switching call sites to import `@dbp/ui` directly) so the
// public API of this feature's internal module path is unchanged.
export { FieldValue, formatDate } from "@dbp/ui";
export type { FieldFormat } from "@dbp/ui";
