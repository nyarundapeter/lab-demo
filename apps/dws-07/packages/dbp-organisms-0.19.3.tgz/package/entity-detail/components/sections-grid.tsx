import React from "react";
import { Skeleton, Grid, Col } from "@dbp/ui";
import { FieldValue } from "./field-value.js";
import type { EntityDetailConfig } from "../types.js";
import type { EntityData } from "@dbp/ps-data/client";

interface Props {
  sections: EntityDetailConfig["sections"];
  data: EntityData | undefined;
  isLoading: boolean;
}

export function SectionsGrid({ sections, data, isLoading }: Props) {
  if (isLoading) {
    return (
      <div className="space-y-5">
        {[1, 2].map((i) => (
          <section
            key={i}
            className="rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-5 pb-5 pt-5"
          >
            <Skeleton className="mb-4 h-4 w-32" />
            <div className="grid grid-cols-2 gap-[var(--grid-gutter)]">
              {[1, 2, 3, 4].map((j) => (
                <Skeleton key={j} className="h-9" />
              ))}
            </div>
          </section>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {sections.map((section) => (
        <section
          key={section.title}
          className="rounded-lg border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-5 pb-5 pt-5"
        >
          <h2 className="mb-4 dq-card-title text-sm leading-snug">{section.title}</h2>
          <Grid>
            {section.fields.map((fd) => (
              <Col key={fd.field} sm={6} span={6} className="min-w-0">
                <p className="mb-1 text-xs text-[var(--color-text-muted)]">{fd.label}</p>
                <div className="text-sm font-medium text-[var(--color-text-secondary)]">
                  <FieldValue value={data?.[fd.field]} format={fd.format} />
                </div>
              </Col>
            ))}
          </Grid>
        </section>
      ))}
    </div>
  );
}
