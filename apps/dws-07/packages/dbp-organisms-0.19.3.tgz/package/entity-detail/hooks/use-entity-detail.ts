import { useEntity } from "@dbp/ps-data/client";
import type { EntityData } from "@dbp/ps-data/client";

/**
 * Fetches a single entity's detail record from PS.DATA.
 *
 * `enabled` gates the fetch: when false (no record selected — empty or
 * "placeholder" id) the query is skipped entirely, so no 404 retry loop fires
 * and the panel can render a "select a record" empty state instead of skeletons.
 */
export function useEntityDetail(
  entityType: string,
  entityId: string,
  enabled = true,
) {
  return useEntity<EntityData>(entityType, entityId, { enabled });
}
