import * as React from "react";
import { DataServiceError } from "@dbp/ps-data/client";
import { Skeleton, Badge, Alert, EmptyState } from "@dbp/ui";
import { CaseWorkspaceConfig } from "./types.js";
import { useCaseEntity } from "./hooks/use-case-entity.js";
import { CaseSections } from "./components/case-sections.js";
import { WorkflowRail } from "./components/workflow-rail.js";

type ConfigInput = Omit<CaseWorkspaceConfig, "actions" | "timeline"> &
  Partial<Pick<CaseWorkspaceConfig, "actions" | "timeline">>;

/**
 * APP.F08 — Case Management Workspace
 *
 * Two-zone workspace for the back-office case handler:
 * - Left/main zone: the case entity record (header + sectioned field grid).
 * - Right rail (stacks below lg breakpoint): workflow state + action controls
 *   when a workflowId is configured; quiet "no workflow" state otherwise.
 *
 * Config is validated at render time via safeParse. A config-error element is
 * rendered (never thrown) on invalid config.
 *
 * RBAC note: CaseWorkspace does NOT gate actions locally. The workflow engine
 * enforces role-based transitions server-side and returns 403 when a transition
 * is not permitted; these are surfaced inline in the rail. Solutions that need
 * UI-level permission gating should compose APP.F06 ApprovalSurface in a
 * dedicated slot alongside CaseWorkspace.
 */
export default function CaseWorkspace(rawConfig: ConfigInput) {
  const parseResult = CaseWorkspaceConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="CaseWorkspace — invalid config" data-testid="config-error">
        <ul className="mt-1 list-disc pl-5">
          {parseResult.error.issues.map((issue, i) => (
            <li key={i}>
              {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
              {issue.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <CaseWorkspaceInner config={parseResult.data} />;
}

export type { CaseWorkspaceConfig } from "./types.js";

// ─── Inner component (config guaranteed valid) ────────────────────────────────

interface InnerProps {
  config: CaseWorkspaceConfig;
}

const DEFAULT_ACTIONS: NonNullable<CaseWorkspaceConfig["actions"]> = {
  allowAdvance: true,
  allowReject: true,
  requireComment: "on-reject",
};

function CaseWorkspaceInner({ config }: InnerProps) {
  const { data, isLoading, error } = useCaseEntity(config.entityType, config.entityId);

  const actions = config.actions ?? DEFAULT_ACTIONS;
  const showTimeline = config.timeline;

  const is404 =
    error instanceof Error &&
    (error.message.includes("404") || error.message.toLowerCase().includes("not found"));

  return (
    /*
     * Two-zone layout:
     * - main zone flex-grows; rail is fixed at 20rem (lg+) or full-width (< lg).
     * Using CSS custom property breakpoints so no Tailwind media variant is needed
     * and the layout works in the storybook/test sandbox too.
     */
    <div
      style={{
        display: "flex",
        gap: "1.5rem",
        flexWrap: "wrap",
        alignItems: "flex-start",
        minHeight: "100%",
      }}
      data-testid="case-workspace"
    >
      {/* ── Main zone: case entity record ──────────────────────────────────── */}
      <div
        style={{
          flex: "1 1 28rem",
          minWidth: 0,
          background: "var(--color-surface)",
          border: "1px solid var(--color-border)",
          borderRadius: "0.375rem",
          overflow: "hidden",
        }}
        data-testid="case-main-zone"
      >
        <CaseEntityRecord
          entityType={config.entityType}
          entityId={config.entityId}
          sections={config.sections}
          data={data}
          isLoading={isLoading}
          error={error}
          is404={is404}
        />
      </div>

      {/* ── Right rail: workflow state ──────────────────────────────────────── */}
      <div
        style={{
          flex: "0 0 20rem",
          width: "20rem",
          minWidth: 0,
          background: "var(--color-surface)",
          border: "1px solid var(--color-border)",
          borderRadius: "0.375rem",
          padding: "1rem",
        }}
        data-testid="workflow-rail-container"
      >
        {config.workflowId ? (
          <WorkflowRail
            workflowId={config.workflowId}
            actions={actions}
            showTimeline={showTimeline}
          />
        ) : (
          <NoWorkflowState />
        )}
      </div>
    </div>
  );
}

// ─── Case entity record sub-view ─────────────────────────────────────────────

interface CaseEntityRecordProps {
  entityType: string;
  entityId: string;
  sections: CaseWorkspaceConfig["sections"];
  data: Record<string, unknown> | undefined;
  isLoading: boolean;
  error: Error | null;
  is404: boolean;
}

function CaseEntityRecord({
  entityType,
  entityId,
  sections,
  data,
  isLoading,
  error,
  is404,
}: CaseEntityRecordProps) {
  if (error && !isLoading) {
    return is404 ? (
      <EmptyState
        title="Case not found"
        description={`No case record was found for ${entityType}/${entityId}.`}
        data-testid="not-found-state"
        role="alert"
      />
    ) : (
      <EmptyState
        tone="danger"
        headline="Failed to load case"
        description={error instanceof DataServiceError ? error.message : (error as Error).message}
        data-testid="entity-error-state"
      />
    );
  }

  return (
    <>
      {/* Case record header */}
      <div
        style={{
          padding: "1rem 1rem 0.75rem",
          borderBottom: "1px solid var(--color-border)",
          display: "flex",
          alignItems: "center",
          gap: "0.5rem",
        }}
        data-testid="case-header"
      >
        {isLoading ? (
          <>
            <Skeleton className="h-5 w-40" />
            <Skeleton className="h-5 w-20" />
          </>
        ) : (
          <>
            <h2
              style={{
                margin: 0,
                fontSize: "1.125rem",
                fontWeight: 700,
                color: "var(--color-text)",
              }}
              data-testid="case-title"
            >
              {data?.["title"]
                ? String(data["title"])
                : data?.["name"]
                ? String(data["name"])
                : `${entityType} / ${entityId}`}
            </h2>
            {data?.["status"] && (
              <Badge tone="gray" data-testid="case-status-badge">
                {String(data["status"])}
              </Badge>
            )}
          </>
        )}
      </div>

      <CaseSections sections={sections} data={data} isLoading={isLoading} />
    </>
  );
}

// ─── No-workflow quiet state ──────────────────────────────────────────────────

function NoWorkflowState() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: "0.5rem",
        padding: "2rem 1rem",
        textAlign: "center",
      }}
      data-testid="no-workflow-state"
    >
      <span
        style={{
          fontSize: "1.5rem",
          color: "color-mix(in srgb, var(--color-text) 30%, transparent)",
        }}
        aria-hidden="true"
      >
        ○
      </span>
      <p
        style={{
          margin: 0,
          fontSize: "0.875rem",
          color: "color-mix(in srgb, var(--color-text) 55%, transparent)",
        }}
      >
        No workflow attached
      </p>
      <p
        style={{
          margin: 0,
          fontSize: "0.75rem",
          color: "color-mix(in srgb, var(--color-text) 40%, transparent)",
        }}
      >
        Set <code>workflowId</code> in config to enable the workflow rail.
      </p>
    </div>
  );
}
