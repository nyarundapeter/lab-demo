import { z } from "zod";

const FieldFormat = z.enum(["text", "number", "date", "badge"]);

const FieldDef = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
  format: FieldFormat.optional(),
});

const SectionDef = z.object({
  title: z.string().min(1),
  fields: z.array(FieldDef).min(1),
});

const ActionsConfig = z.object({
  allowAdvance: z.boolean().default(true),
  allowReject: z.boolean().default(true),
  /**
   * Comment requirement for advance/reject actions.
   * - "never"     — textarea never shown
   * - "on-reject" — textarea shown and required only when rejecting (default)
   * - "always"    — textarea shown and required for both advance and reject
   *
   * Note: CaseWorkspace does NOT gate actions on RBAC locally.
   * Solutions that need RBAC gating should place APP.F06 ApprovalSurface in the
   * appropriate permission-gated slot. The workflow engine always enforces roles
   * server-side; a 403 response surfaces inline in the rail.
   */
  requireComment: z.enum(["never", "on-reject", "always"]).default("on-reject"),
});

export const CaseWorkspaceConfig = z.object({
  /** The PS.DATA entity type for the case record (e.g. "case", "claim", "complaint"). */
  entityType: z.string().min(1),

  /** The PS.DATA entity ID of the case record to load. */
  entityId: z.string().min(1),

  /**
   * Optional PS.WORKFLOW instance ID for the case's workflow.
   * When present the workflow rail renders; when absent the rail shows a quiet
   * "no workflow attached" state.
   */
  workflowId: z.string().min(1).optional(),

  /** Field sections rendered in the left/main zone. Same shape as APP.F02 EntityDetail. */
  sections: z.array(SectionDef).min(1),

  /** Action controls in the workflow rail. Defaults to allow advance + reject with on-reject comment. */
  actions: ActionsConfig.optional(),

  /**
   * When true (default) the workflow step history renders as a vertical timeline
   * in the workflow rail below the action controls.
   */
  timeline: z.boolean().default(true),
});

export type CaseWorkspaceConfig = z.infer<typeof CaseWorkspaceConfig>;
