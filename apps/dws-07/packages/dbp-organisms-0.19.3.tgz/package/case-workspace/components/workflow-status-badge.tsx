import * as React from "react";
import { StatusBadge } from "@dbp/ui";
import type { BadgeProps } from "@dbp/ui";
import type { WorkflowStatus } from "@dbp/ps-workflow/client";

interface Props {
  status: WorkflowStatus;
}

// See step-status-badge.tsx for why `WorkflowStatus` composes `StatusBadge`
// via an explicit `tone` override rather than folding into its 11-state
// admin lifecycle vocabulary (design-system de-dup Wave 1.F).
const STATUS_TONES: Record<WorkflowStatus, NonNullable<BadgeProps["tone"]>> = {
  running: "info",
  completed: "success",
  rejected: "danger",
  cancelled: "gray",
};

const STATUS_LABELS: Record<WorkflowStatus, string> = {
  running: "In Progress",
  completed: "Completed",
  rejected: "Rejected",
  cancelled: "Cancelled",
};

export function WorkflowStatusBadge({ status }: Props) {
  return (
    <StatusBadge tone={STATUS_TONES[status]} data-testid="workflow-status-badge">
      {STATUS_LABELS[status]}
    </StatusBadge>
  );
}
