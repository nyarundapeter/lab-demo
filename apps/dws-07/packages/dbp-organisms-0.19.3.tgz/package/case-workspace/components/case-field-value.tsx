import * as React from "react";
import { FieldValue, type FieldFormat } from "@dbp/ui";

// De-duplicated onto the shared @dbp/ui renderer (design-system de-dup
// strategy, `docs/plans/design-system-dedup-2026-07-25/strategy.md` §3) —
// this used to hand-roll the same value/format renderer now extracted to
// `packages/shared/ui/src/components/field-value.tsx`. Kept as a thin
// wrapper (rather than switching call sites) so the `CaseFieldValue` name
// this feature's components import stays unchanged.
interface Props {
  value: unknown;
  format: FieldFormat;
}

export function CaseFieldValue({ value, format }: Props) {
  return <FieldValue value={value} format={format} />;
}
