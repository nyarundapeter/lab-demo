import * as React from "react";
import { Button, Alert } from "@dbp/ui";
import { WorkflowServiceError } from "@dbp/ps-workflow/client";
import type { CaseWorkspaceConfig } from "../types.js";
import { useCaseWorkflow } from "../hooks/use-case-workflow.js";
import { WorkflowStatusBadge } from "./workflow-status-badge.js";
import { WorkflowTimeline } from "./workflow-timeline.js";

interface Props {
  workflowId: string;
  actions: NonNullable<CaseWorkspaceConfig["actions"]>;
  showTimeline: boolean;
}

/**
 * DEMO_SESSION — placeholder session token injected for blueprint demonstrations.
 * In production the shell provides the real session via context. The workflow
 * engine enforces role-based step transitions server-side regardless of this token;
 * a 403 from the engine surfaces inline (see service-error testid).
 *
 * CaseWorkspace deliberately omits local RBAC gating. Solutions that need
 * permission-gated actions should compose APP.F06 ApprovalSurface in a dedicated
 * slot. This keeps CaseWorkspace as the handler's operational surface (always
 * visible to the case handler) while the engine remains the authoritative guard.
 */
const DEMO_SESSION = btoa(
  JSON.stringify({ userId: "demo-handler", roles: ["case-handler"], tenantId: "demo" }),
);

export function WorkflowRail({ workflowId, actions, showTimeline }: Props) {
  const { instance, isLoading, error, isAdvancing, isRejecting, advance, reject } =
    useCaseWorkflow(workflowId);

  const [comment, setComment] = React.useState("");
  const [commentError, setCommentError] = React.useState<string | null>(null);
  const [serviceError, setServiceError] = React.useState<string | null>(null);

  const isTerminal =
    instance !== null &&
    (instance.status === "completed" || instance.status === "rejected");

  const isBusy = isAdvancing || isRejecting;

  function requiresCommentFor(action: "advance" | "reject"): boolean {
    const policy = actions.requireComment;
    if (policy === "always") return true;
    if (policy === "on-reject" && action === "reject") return true;
    return false;
  }

  function showTextarea(): boolean {
    return actions.requireComment !== "never";
  }

  async function handleAdvance() {
    if (requiresCommentFor("advance") && comment.trim() === "") {
      setCommentError("A comment is required before advancing.");
      return;
    }
    setCommentError(null);
    setServiceError(null);
    try {
      await advance({ comment: comment.trim() || undefined }, DEMO_SESSION);
    } catch (err) {
      const msg =
        err instanceof WorkflowServiceError && err.status === 403
          ? "The workflow engine denied the transition. Your role may not permit this action."
          : err instanceof WorkflowServiceError
          ? err.message
          : "Failed to advance. Please try again.";
      setServiceError(msg);
    }
  }

  async function handleReject() {
    if (requiresCommentFor("reject") && comment.trim() === "") {
      setCommentError("A comment is required before rejecting.");
      return;
    }
    setCommentError(null);
    setServiceError(null);
    try {
      await reject({ comment: comment.trim() || undefined }, DEMO_SESSION);
    } catch (err) {
      const msg =
        err instanceof WorkflowServiceError && err.status === 403
          ? "The workflow engine denied the transition. Your role may not permit this action."
          : err instanceof WorkflowServiceError
          ? err.message
          : "Failed to reject. Please try again.";
      setServiceError(msg);
    }
  }

  if (isLoading) {
    return (
      <div
        style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}
        data-testid="workflow-rail-loading"
        aria-busy="true"
        aria-label="Loading workflow"
      >
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            style={{
              height: "1rem",
              borderRadius: "0.25rem",
              background: "var(--color-bg)",
              animation: "pulse 1.5s ease-in-out infinite",
              width: i === 2 ? "100%" : i === 1 ? "8rem" : "12rem",
            }}
          />
        ))}
      </div>
    );
  }

  if (error && instance === null) {
    const msg =
      error instanceof WorkflowServiceError
        ? error.message
        : "Unexpected error loading workflow.";
    return (
      <Alert tone="danger" title="Failed to load workflow" data-testid="workflow-rail-error">
        {msg}
      </Alert>
    );
  }

  if (instance === null) return null;

  return (
    <div
      style={{ display: "flex", flexDirection: "column", gap: "1rem" }}
      data-testid="workflow-rail"
    >
      {/* Current step header */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "0.5rem",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: "0.125rem" }}>
          <span
            style={{
              fontSize: "0.6875rem",
              fontWeight: 600,
              textTransform: "uppercase",
              letterSpacing: "0.05em",
              color: "color-mix(in srgb, var(--color-text) 50%, transparent)",
            }}
          >
            Current Step
          </span>
          <span
            className="text-sm font-semibold text-[var(--color-text)]"
            data-testid="current-step"
          >
            {instance.currentStep ?? "—"}
          </span>
        </div>
        <WorkflowStatusBadge status={instance.status} />
      </div>

      {/* Assignee roles from the most recent step */}
      {instance.steps.length > 0 && (
        <div
          className="text-xs text-[var(--color-text)] opacity-60"
          data-testid="assignee-roles"
        >
          Last actor:{" "}
          <span className="font-medium">
            {instance.steps[instance.steps.length - 1]?.actor.roles.join(", ")}
          </span>
        </div>
      )}

      {/* Action area */}
      {isTerminal ? (
        <div
          style={{
            padding: "0.75rem 1rem",
            borderRadius: "0.375rem",
            border: "1px solid var(--color-border)",
            background: "var(--color-bg)",
            fontSize: "0.875rem",
            color: "color-mix(in srgb, var(--color-text) 65%, transparent)",
          }}
          data-testid="terminal-outcome"
        >
          This case is <strong>{instance.status}</strong>. No further actions are available.
        </div>
      ) : (
        <div
          style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}
          data-testid="action-controls"
        >
          {showTextarea() && (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}>
              <label
                htmlFor="case-action-comment"
                style={{
                  fontSize: "0.75rem",
                  fontWeight: 500,
                  color: "var(--color-text)",
                }}
              >
                Comment
                {actions.requireComment === "always" && (
                  <span style={{ marginLeft: "0.25rem", color: "var(--color-danger)" }}>*</span>
                )}
                {actions.requireComment === "on-reject" && (
                  <span
                    style={{
                      marginLeft: "0.25rem",
                      color: "color-mix(in srgb, var(--color-text) 50%, transparent)",
                    }}
                  >
                    (required when rejecting)
                  </span>
                )}
              </label>
              <textarea
                id="case-action-comment"
                style={{
                  minHeight: "5rem",
                  width: "100%",
                  borderRadius: "0.375rem",
                  border: "1px solid var(--color-border)",
                  background: "var(--color-surface)",
                  padding: "0.5rem 0.75rem",
                  fontSize: "0.875rem",
                  color: "var(--color-text)",
                  resize: "vertical",
                  outline: "none",
                }}
                placeholder="Add a comment…"
                value={comment}
                onChange={(e) => {
                  setComment(e.target.value);
                  if (commentError) setCommentError(null);
                }}
                disabled={isBusy}
                data-testid="comment-textarea"
              />
              {commentError && (
                <p
                  style={{ fontSize: "0.75rem", color: "var(--color-danger-text)" }}
                  data-testid="comment-error"
                  role="alert"
                >
                  {commentError}
                </p>
              )}
            </div>
          )}

          {serviceError && (
            <Alert tone="danger" data-testid="service-error">
              {serviceError}
            </Alert>
          )}

          <div style={{ display: "flex", gap: "0.5rem" }}>
            {actions.allowAdvance && (
              <Button
                type="button"
                variant="navy"
                onClick={handleAdvance}
                loading={isAdvancing}
                disabled={isBusy}
                data-testid="advance-button"
              >
                {isAdvancing ? "Advancing…" : "Advance"}
              </Button>
            )}
            {actions.allowReject && (
              <Button
                type="button"
                variant="outline"
                onClick={handleReject}
                loading={isRejecting}
                disabled={isBusy}
                data-testid="reject-button"
              >
                {isRejecting ? "Rejecting…" : "Reject"}
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Timeline */}
      {showTimeline && (
        <div
          style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}
          data-testid="timeline-section"
        >
          <h3
            style={{
              margin: 0,
              fontSize: "0.6875rem",
              fontWeight: 600,
              textTransform: "uppercase",
              letterSpacing: "0.05em",
              color: "color-mix(in srgb, var(--color-text) 50%, transparent)",
            }}
          >
            History
          </h3>
          <WorkflowTimeline steps={instance.steps} />
        </div>
      )}
    </div>
  );
}
