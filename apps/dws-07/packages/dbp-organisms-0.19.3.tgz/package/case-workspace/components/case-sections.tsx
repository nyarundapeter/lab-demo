import * as React from "react";
import { Skeleton } from "@dbp/ui";
import { CaseFieldValue } from "./case-field-value.js";
import type { CaseWorkspaceConfig } from "../types.js";
import type { EntityData } from "@dbp/ps-data/client";

interface Props {
  sections: CaseWorkspaceConfig["sections"];
  data: EntityData | undefined;
  isLoading: boolean;
}

export function CaseSections({ sections, data, isLoading }: Props) {
  if (isLoading) {
    return (
      <div
        style={{ padding: "1rem", display: "flex", flexDirection: "column", gap: "1.25rem" }}
        data-testid="case-sections-loading"
        aria-busy="true"
      >
        {[1, 2].map((i) => (
          <div key={i} style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
            <Skeleton className="h-4 w-24" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
              {[1, 2, 3, 4].map((j) => (
                <Skeleton key={j} className="h-8" />
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div style={{ padding: "0.5rem 1rem 1rem" }} data-testid="case-sections">
      {sections.map((section, si) => (
        <React.Fragment key={section.title}>
          {si > 0 ? (
            <hr
              style={{
                margin: "1rem 0",
                border: "none",
                borderTop: "1px solid var(--color-border)",
              }}
            />
          ) : null}
          <div style={{ marginTop: si === 0 ? "0.75rem" : 0 }}>
            <p
              style={{
                margin: "0 0 0.625rem",
                fontSize: "0.75rem",
                fontWeight: 600,
                textTransform: "uppercase",
                letterSpacing: "0.05em",
                color: "color-mix(in srgb, var(--color-text) 55%, transparent)",
              }}
            >
              {section.title}
            </p>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "0.75rem 1rem",
              }}
            >
              {section.fields.map((fd) => (
                <div key={fd.field}>
                  <p
                    style={{
                      margin: "0 0 0.125rem",
                      fontSize: "0.6875rem",
                      color: "color-mix(in srgb, var(--color-text) 50%, transparent)",
                    }}
                  >
                    {fd.label}
                  </p>
                  <div style={{ fontSize: "0.875rem", fontWeight: 500 }}>
                    <CaseFieldValue value={data?.[fd.field]} format={fd.format} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}
