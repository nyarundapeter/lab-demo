import * as React from "react";
import { SectionLabel } from "@dbp/ui";
import type { StepHistoryEntry } from "@dbp/ps-workflow/client";

interface Props {
  steps: StepHistoryEntry[];
}

const ACTION_COLORS: Record<string, string> = {
  start: "bg-[var(--color-border-strong)]",
  advance: "bg-[var(--color-success)]",
  reject: "bg-[var(--color-danger)]",
};

const ACTION_LABELS: Record<string, string> = {
  start: "Started",
  advance: "Advanced",
  reject: "Rejected",
};

export function WorkflowTimeline({ steps }: Props) {
  if (steps.length === 0) {
    return (
      <p
        className="text-sm text-[var(--color-text)] opacity-50"
        data-testid="timeline-empty"
      >
        No history yet.
      </p>
    );
  }

  return (
    <ol
      style={{ listStyle: "none", margin: 0, padding: 0, position: "relative" }}
      data-testid="workflow-timeline"
    >
      {steps.map((entry, i) => {
        const dotColor = ACTION_COLORS[entry.action] ?? "bg-[var(--color-border-strong)]";
        const isLast = i === steps.length - 1;

        return (
          <li
            key={i}
            style={{
              display: "flex",
              gap: "0.75rem",
              paddingBottom: isLast ? 0 : "1rem",
              position: "relative",
            }}
            data-testid="timeline-entry"
          >
            {/* Connector line */}
            {!isLast && (
              <div
                style={{
                  position: "absolute",
                  left: "0.4375rem",
                  top: "1.125rem",
                  bottom: 0,
                  width: "2px",
                  background: "var(--color-border)",
                }}
                aria-hidden="true"
              />
            )}

            {/* Dot */}
            <div style={{ flexShrink: 0, paddingTop: "0.1875rem" }}>
              <span
                className={`block h-3.5 w-3.5 rounded-full ${dotColor}`}
                aria-hidden="true"
              />
            </div>

            {/* Content */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "baseline",
                  justifyContent: "space-between",
                  gap: "0.5rem",
                  flexWrap: "wrap",
                }}
              >
                <span
                  className="text-xs font-semibold text-[var(--color-text)]"
                  data-testid="timeline-actor"
                >
                  {entry.actor.userId}
                </span>
                <span
                  className="text-[0.6875rem] text-[var(--color-text)] opacity-55"
                  data-testid="timeline-ts"
                >
                  {new Date(entry.ts).toLocaleString()}
                </span>
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.375rem",
                  marginTop: "0.1875rem",
                }}
              >
                <SectionLabel
                  className="rounded bg-[var(--color-bg)] px-1.5 py-0.5 font-mono text-[0.65rem] text-[var(--color-text)] opacity-70"
                  data-testid="timeline-action"
                >
                  {ACTION_LABELS[entry.action] ?? entry.action}
                </SectionLabel>
                <span className="text-[0.6875rem] text-[var(--color-text)] opacity-55">
                  step: {entry.stepId}
                </span>
              </div>

              {entry.comment && (
                <p
                  className="mt-1 text-xs italic text-[var(--color-text)] opacity-75"
                  data-testid="timeline-comment"
                >
                  &ldquo;{entry.comment}&rdquo;
                </p>
              )}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
