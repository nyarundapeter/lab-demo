import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getInstance,
  advanceInstance,
  rejectInstance,
} from "@dbp/ps-workflow/client";
import type { WorkflowInstance, AdvanceRequest, RejectRequest } from "@dbp/ps-workflow/client";

const instanceKey = (workflowId: string) =>
  ["ps-workflow", "instance", workflowId] as const;

export function useCaseWorkflow(workflowId: string) {
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: instanceKey(workflowId),
    queryFn: () => getInstance(workflowId),
  });

  const advanceMutation = useMutation({
    mutationFn: ({ payload, session }: { payload: AdvanceRequest; session: string }) =>
      advanceInstance(workflowId, payload, session),
    onSuccess: (updated: WorkflowInstance) => {
      queryClient.setQueryData(instanceKey(workflowId), updated);
    },
  });

  const rejectMutation = useMutation({
    mutationFn: ({ payload, session }: { payload: RejectRequest; session: string }) =>
      rejectInstance(workflowId, payload, session),
    onSuccess: (updated: WorkflowInstance) => {
      queryClient.setQueryData(instanceKey(workflowId), updated);
    },
  });

  return {
    instance: query.data ?? null,
    isLoading: query.isLoading,
    error: query.error,
    isAdvancing: advanceMutation.isPending,
    isRejecting: rejectMutation.isPending,
    advance: (payload: AdvanceRequest, session: string) =>
      advanceMutation.mutateAsync({ payload, session }),
    reject: (payload: RejectRequest, session: string) =>
      rejectMutation.mutateAsync({ payload, session }),
  };
}
