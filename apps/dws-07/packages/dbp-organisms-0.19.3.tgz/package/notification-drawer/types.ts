import { z } from "zod";

// ─── NotificationDrawerConfig ──────────────────────────────────────────────
// Data-only contract — no function fields. `open`/`onOpenChange` are React
// props on the component (see index.tsx), not part of the Zod config, per
// the same convention as `publish-review`.

export const NotificationDrawerConfig = z
  .object({
    /** Drawer header title. */
    title: z.string().default("Notifications"),
    /** Session header forwarded to PS.NOTIF (matches NotificationBell/NotificationInbox's prop). */
    sessionHeader: z.string().optional(),
    /** Text shown when there are no notifications. */
    emptyMessage: z.string().optional(),
  })
  .strict();

export type NotificationDrawerConfig = z.infer<typeof NotificationDrawerConfig>;
export type NotificationDrawerConfigInput = z.input<typeof NotificationDrawerConfig>;
