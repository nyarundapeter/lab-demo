# @dbp/organisms/notification-drawer

**registryId:** `APP.F68` (placeholder — pending central registration, see
[FEATURE.md](./FEATURE.md))

Right-side drawer for richer notification triage — composes the existing
`notification-inbox` organism inside a `Sheet` rather than reimplementing its
list/filter logic. See [FEATURE.md](./FEATURE.md) for the full contract.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`NotificationDrawerConfig` — Zod schema (and inferred type of the same name)
exported from `types.ts` (source of truth). `open`/`onOpenChange` are
component props, not part of the schema.

## Layer boundary
Layer 07 feature. Imports `@dbp/ui` and the sibling `notification-inbox`
organism only.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/notification-drawer` via
plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it
as a committed tarball per `docs/08-contributing/package-distribution.md`.
