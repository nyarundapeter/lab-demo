import React from "react";
import { Bell } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, Alert } from "@dbp/ui";
import NotificationInbox from "../notification-inbox/index.js";
import { NotificationDrawerConfig, type NotificationDrawerConfigInput } from "./types.js";

export interface NotificationDrawerProps extends NotificationDrawerConfigInput {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/**
 * APP.F68 (placeholder — central registration assigns the real id) —
 * Notification Drawer
 *
 * The richer-triage entry point alongside the popover
 * (notif-centre.jsx:126-141 `NotifDrawer`): search/filter without leaving
 * the page behind, vs. the popover's read-only quick scan. Deliberately
 * does NOT reimplement the list/filter/mark-read logic — it composes the
 * existing `notification-inbox` organism (APP.F29) inside a right-side
 * `Sheet`, the same "extend, don't duplicate" pattern `config-detail` uses
 * for `entity-detail` and `publish-review` uses for its Sheet shell.
 */
export default function NotificationDrawer(props: NotificationDrawerProps) {
  const { open, onOpenChange, ...config } = props;
  const parsed = NotificationDrawerConfig.safeParse(config);

  if (!parsed.success) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="right" size="wide">
          <SheetHeader>
            <SheetTitle>NotificationDrawer — invalid config</SheetTitle>
          </SheetHeader>
          <Alert tone="danger" title="NotificationDrawer — invalid config">
            <ul className="mt-1 list-disc pl-5">
              {parsed.error.issues.map((issue, i) => (
                <li key={i}>
                  {issue.path.join(".") ? `${issue.path.join(".")}: ` : ""}
                  {issue.message}
                </li>
              ))}
            </ul>
          </Alert>
        </SheetContent>
      </Sheet>
    );
  }

  const { title, sessionHeader, emptyMessage } = parsed.data;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" size="wide" data-testid="notification-drawer">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Bell size={16} className="text-[var(--color-primary)]" aria-hidden="true" />
            {title}
          </SheetTitle>
          <SheetDescription>Search, filter, and act on notifications without leaving the page.</SheetDescription>
        </SheetHeader>

        <div className="-mx-6 flex-1 overflow-y-auto px-6">
          <NotificationInbox
            config={{
              ...(sessionHeader !== undefined && { sessionHeader }),
              ...(emptyMessage !== undefined && { emptyMessage }),
            }}
          />
        </div>
      </SheetContent>
    </Sheet>
  );
}
