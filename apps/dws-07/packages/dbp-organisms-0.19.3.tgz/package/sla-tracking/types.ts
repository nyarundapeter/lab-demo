import { z } from "zod";

/**
 * SlaDef maps a workflow step to a time target.
 * targetMinutes: how long an instance may sit in this step before breach.
 */
export const SlaDefSchema = z.object({
  stepId: z.string().min(1),
  label: z.string().optional(),
  targetMinutes: z.number().positive(),
});
export type SlaDef = z.infer<typeof SlaDefSchema>;

/**
 * CardFieldsConfig selects which instance.context fields appear on each row.
 * Fields are keys into WorkflowInstance.context (Record<string, unknown>).
 */
export const SlaCardFieldsSchema = z.object({
  titleField: z.string().min(1),
  subtitleField: z.string().optional(),
});
export type SlaCardFields = z.infer<typeof SlaCardFieldsSchema>;

/**
 * SlaTrackingConfig — the single typed contract for ANL.F05.
 *
 * LIMITATION: PS.WORKFLOW does not expose GET /instances?definitionId=.
 * Therefore instanceIds must be provided by the consumer. Each ID is fetched
 * via GET /instances/:id. A PS.WORKFLOW minor is needed to add the
 * list-by-definition endpoint — see FEATURE.md §Limitations.
 *
 * nowIso: optional fixed "now" timestamp (ISO 8601). When set, elapsed-time
 * computation uses this value instead of Date.now(). Intended exclusively for
 * deterministic tests and Storybook stories — never set in production.
 */
export const SlaTrackingConfig = z.object({
  title: z.string().optional(),
  /**
   * Explicit list of workflow instance IDs under SLA watch.
   * Required because PS.WORKFLOW lacks GET /instances?definitionId= today.
   */
  instanceIds: z.array(z.string().min(1)).default([]),
  /** Step-level SLA definitions — at least one step must be declared. */
  slas: z.array(SlaDefSchema).min(1),
  /**
   * Percentage of targetMinutes at which a row enters "warning" status.
   * Must be in (0, 100). Default 75 means ≥75% elapsed → warning.
   */
  warnAtPercent: z.number().min(1).max(99).default(75),
  /** Which instance.context fields to render per row. */
  cardFields: SlaCardFieldsSchema.optional(),
  /**
   * Fixed ISO timestamp used as "now" for elapsed calculations.
   * Test/demo affordance only — do not set in production.
   */
  nowIso: z.string().datetime().optional(),
});
export type SlaTrackingConfig = z.infer<typeof SlaTrackingConfig>;

/** The computed SLA status for one active instance in one step. */
export type SlaStatus = "ok" | "warning" | "breached";
