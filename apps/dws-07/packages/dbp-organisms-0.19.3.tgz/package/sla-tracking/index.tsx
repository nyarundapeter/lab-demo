import * as React from "react";
import { z } from "zod";
import { Skeleton, Alert, SectionLabel } from "@dbp/ui";
import { SlaTrackingConfig } from "./types.js";
import { useSlaInstances } from "./hooks/use-sla-instances.js";
import { computeSlaRow, sortActiveRows } from "./components/sla-math.js";
import { SlaActiveRow, SlaCompletedRow, SlaSkeletonRow } from "./components/sla-row.js";
import { SlaSummaryStrip } from "./components/sla-summary-strip.js";
import type { ActiveSlaRow, CompletedSlaRow } from "./components/sla-math.js";

type ConfigInput = z.input<typeof SlaTrackingConfig>;

/**
 * ANL.F05 — SLA Tracking View
 *
 * Receives CONFIG, never data. Each workflow instance is fetched individually via
 * PS.WORKFLOW (GET /instances/:id) because PS.WORKFLOW does not expose a
 * list-by-definitionId endpoint. See FEATURE.md §Limitations.
 *
 * Config is validated at render time via SlaTrackingConfig.safeParse.
 * A config-error element (never a thrown exception) is rendered on invalid config.
 *
 * nowIso in config is a test/demo affordance for deterministic elapsed time —
 * never set in production.
 */
export default function SlaTracking(rawConfig: ConfigInput) {
  const parseResult = SlaTrackingConfig.safeParse(rawConfig);

  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="SlaTracking configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <SlaTrackingInner config={parseResult.data} />;
}

export type { SlaTrackingConfig, SlaDef, SlaCardFields, SlaStatus } from "./types.js";

// ─── Inner component (config guaranteed valid) ────────────────────────────────

interface SlaTrackingInnerProps {
  config: SlaTrackingConfig;
}

function SlaTrackingInner({ config }: SlaTrackingInnerProps) {
  const { slas, warnAtPercent, cardFields, instanceIds, nowIso } = config;
  const nowMs = nowIso ? new Date(nowIso).getTime() : Date.now();

  const results = useSlaInstances(instanceIds);

  const anyLoading = results.some((r) => r.isLoading);
  const allErrored = results.length > 0 && results.every((r) => r.isError);

  if (allErrored) {
    return (
      <Alert tone="danger" title="Failed to load workflow instances" data-testid="sla-tracking-error">
        Please try again.
      </Alert>
    );
  }

  if (instanceIds.length === 0) {
    return (
      <div
        className="flex flex-col gap-3"
        data-testid="sla-tracking"
      >
        {config.title && <h2 className="dq-card-title">{config.title}</h2>}
        <p
          className="py-6 text-center text-sm text-[var(--color-text-muted)]"
          data-testid="sla-tracking-empty"
        >
          No instance IDs configured.
        </p>
      </div>
    );
  }

  // Compute rows only for instances that have loaded successfully.
  const activeRows: ActiveSlaRow[] = [];
  const completedRows: CompletedSlaRow[] = [];

  for (const result of results) {
    if (!result.data) continue;
    const row = computeSlaRow(
      result.data,
      slas,
      warnAtPercent,
      nowMs,
      cardFields?.titleField,
      cardFields?.subtitleField,
    );
    if (row.kind === "active") {
      activeRows.push(row);
    } else {
      completedRows.push(row);
    }
  }

  const sortedActive = sortActiveRows(activeRows);
  const noDataYet = !anyLoading && activeRows.length === 0 && completedRows.length === 0;

  return (
    <div className="flex flex-col gap-4" data-testid="sla-tracking">
      {config.title && <h2 className="dq-card-title">{config.title}</h2>}

      {!anyLoading && activeRows.length > 0 && (
        <SlaSummaryStrip rows={activeRows} />
      )}

      {anyLoading && (
        <div data-testid="sla-tracking-loading" className="flex flex-col gap-2">
          <Skeleton className="h-8 w-full" />
          {[1, 2, 3].map((i) => (
            <div key={i} />
          ))}
        </div>
      )}

      {noDataYet && !anyLoading && (
        <p
          className="py-6 text-center text-sm text-[var(--color-text-muted)]"
          data-testid="sla-tracking-empty"
        >
          No instances loaded.
        </p>
      )}

      {(sortedActive.length > 0 || anyLoading) && (
        // Entity-list (APP.F01) table card treatment (DR-5/DR-1), matching
        // AdminUserList: white surface + shadow-sm so the table reads as
        // content, not chrome blending into the muted canvas. The scroll
        // container is bounded to the card itself, never the page (DR-4).
        <div className="w-full overflow-x-auto rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-2)] shadow-[var(--shadow-sm)]">
          <table
            className="w-full border-collapse text-left text-sm"
            data-testid="sla-active-table"
          >
            <thead>
              <tr className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]">
                <SectionLabel as="th" className="px-4 py-3 text-left font-mono text-xs font-medium tracking-wider whitespace-nowrap">Instance</SectionLabel>
                <SectionLabel as="th" className="px-4 py-3 text-left font-mono text-xs font-medium tracking-wider whitespace-nowrap">Current Step</SectionLabel>
                <SectionLabel as="th" className="px-4 py-3 text-left font-mono text-xs font-medium tracking-wider whitespace-nowrap">Elapsed / Target</SectionLabel>
                <SectionLabel as="th" className="px-4 py-3 text-left font-mono text-xs font-medium tracking-wider whitespace-nowrap">Status</SectionLabel>
              </tr>
            </thead>
            <tbody>
              {anyLoading &&
                instanceIds.map((id) => <SlaSkeletonRow key={id} />)}
              {!anyLoading &&
                sortedActive.map((row) => (
                  <SlaActiveRow key={row.workflowId} row={row} />
                ))}
            </tbody>
          </table>
        </div>
      )}

      {completedRows.length > 0 && (
        <details className="rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-2)] shadow-[var(--shadow-sm)]" open={false}>
          <summary
            className="cursor-pointer select-none px-4 py-2 text-sm font-medium text-[var(--color-text-secondary)]"
            data-testid="completed-section-toggle"
          >
            Completed / Rejected ({completedRows.length})
          </summary>
          <div className="w-full overflow-x-auto border-t border-[var(--color-border-subtle)]">
            <table
              className="w-full border-collapse text-left text-sm"
              data-testid="sla-completed-table"
            >
              <thead>
                <tr className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]">
                  <SectionLabel as="th" className="px-4 py-3 text-left font-mono text-xs font-medium tracking-wider whitespace-nowrap">Instance</SectionLabel>
                  <SectionLabel as="th" className="px-4 py-3 text-left font-mono text-xs font-medium tracking-wider whitespace-nowrap">Outcome</SectionLabel>
                  <SectionLabel as="th" className="px-4 py-3 text-left font-mono text-xs font-medium tracking-wider whitespace-nowrap">Total Duration</SectionLabel>
                  <SectionLabel as="th" className="px-4 py-3 text-left font-mono text-xs font-medium tracking-wider whitespace-nowrap">Status</SectionLabel>
                </tr>
              </thead>
              <tbody>
                {completedRows.map((row) => (
                  <SlaCompletedRow key={row.workflowId} row={row} />
                ))}
              </tbody>
            </table>
          </div>
        </details>
      )}
    </div>
  );
}
