# @dbp/organisms/sla-tracking

**registryId:** `ANL.F05`

SLA definition tracking view with status (ok/warning/breached) rendering.

**Tier:** organism

## Exports
| Export | Path |
|---|---|
| `.` | `index.tsx` |

## Config schema
`SlaTrackingConfig` — Zod schema exported from `types.ts` (source of truth).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` looks this organism up via the `FEATURE_COMPONENT` map at JSX emission time and mounts it into the `analytics-dashboard` layout.

## Shipping
Inside this monorepo, apps resolve `@dbp/organisms/sla-tracking` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed tarball per `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
