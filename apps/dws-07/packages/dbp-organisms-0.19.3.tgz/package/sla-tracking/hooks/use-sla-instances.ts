import { useQueries } from "@tanstack/react-query";
import { getInstance } from "@dbp/ps-workflow/client";
import type { WorkflowInstance } from "@dbp/ps-workflow/client";

const instanceKey = (workflowId: string) =>
  ["ps-workflow", "instance", workflowId] as const;

export interface SlaInstanceResult {
  id: string;
  data: WorkflowInstance | undefined;
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
}

/**
 * Fetches multiple workflow instances in parallel, one query per ID.
 * Isolation is by design — a 404 or network error on one ID does not
 * affect the remaining queries.
 *
 * PS.WORKFLOW does not expose GET /instances?definitionId=, so each
 * instance must be fetched individually. See FEATURE.md §Limitations.
 */
export function useSlaInstances(instanceIds: string[]): SlaInstanceResult[] {
  const results = useQueries({
    queries: instanceIds.map((id) => ({
      queryKey: instanceKey(id),
      queryFn: () => getInstance(id),
      retry: false,
    })),
  });

  return instanceIds.map((id, i) => {
    const r = results[i]!;
    return {
      id,
      data: r.data,
      isLoading: r.isLoading,
      isError: r.isError,
      error: r.error as Error | null,
    };
  });
}
