import * as React from "react";
import { Badge, Skeleton, Progress } from "@dbp/ui";
import type { ActiveSlaRow, CompletedSlaRow } from "./sla-math.js";
import { formatDuration } from "./sla-math.js";

// ─── Active row ───────────────────────────────────────────────────────────────

interface SlaActiveRowProps {
  row: ActiveSlaRow;
}

const STATUS_BADGE_VARIANT = {
  ok: "success",
  warning: "warning",
  breached: "danger",
} as const;

const STATUS_LABEL = {
  ok: "On track",
  warning: "At risk",
  breached: "Breached",
} as const;

export function SlaActiveRow({ row }: SlaActiveRowProps) {
  const barPct = Math.min(row.pct, 100);
  const progressTone =
    row.status === "breached" ? "danger" : row.status === "warning" ? "warning" : "primary";

  return (
    <tr
      data-testid="sla-row"
      data-status={row.status}
      data-workflow-id={row.workflowId}
      className="border-b border-[var(--color-border)] last:border-0"
    >
      <td className="py-3 pl-4 pr-4 align-top">
        <span className="block text-sm font-medium text-[var(--color-text)]">
          {row.title}
        </span>
        {row.subtitle && (
          <span className="block text-xs text-[var(--color-text)] opacity-60">
            {row.subtitle}
          </span>
        )}
      </td>
      <td className="py-3 pr-4 align-middle text-sm text-[var(--color-text)]">
        {row.stepLabel}
      </td>
      <td className="py-3 pr-4 align-middle">
        <div className="flex flex-col gap-1">
          <span
            className="text-xs tabular-nums text-[var(--color-text)]"
            data-testid="sla-duration"
          >
            {formatDuration(row.elapsedMinutes, row.targetMinutes)}
          </span>
          <Progress
            value={barPct}
            tone={progressTone}
            size="default"
            className="w-32"
            data-testid="sla-progress-bar"
          />
        </div>
      </td>
      <td className="py-3 pr-4 align-middle">
        <Badge tone={STATUS_BADGE_VARIANT[row.status]} data-testid="sla-status-badge">
          {STATUS_LABEL[row.status]}
        </Badge>
      </td>
    </tr>
  );
}

// ─── Completed row ────────────────────────────────────────────────────────────

interface SlaCompletedRowProps {
  row: CompletedSlaRow;
}

export function SlaCompletedRow({ row }: SlaCompletedRowProps) {
  return (
    <tr
      data-testid="sla-completed-row"
      data-workflow-id={row.workflowId}
      data-final-status={row.finalStatus}
      className="border-b border-[var(--color-border)] last:border-0 opacity-60"
    >
      <td className="py-2 pl-4 pr-4 align-top">
        <span className="block text-sm text-[var(--color-text)]">{row.title}</span>
        {row.subtitle && (
          <span className="block text-xs text-[var(--color-text)] opacity-60">
            {row.subtitle}
          </span>
        )}
      </td>
      <td className="py-2 pr-4 align-middle text-sm text-[var(--color-text)]">
        {row.finalStatus === "rejected" ? "Rejected" : "Completed"}
      </td>
      <td className="py-2 pr-4 align-middle text-xs tabular-nums text-[var(--color-text)]">
        {Math.floor(row.totalMinutes)}m total
      </td>
      <td className="py-2 pr-4 align-middle">
        <Badge tone="gray" data-testid="sla-completed-badge">
          {row.finalStatus === "rejected" ? "Rejected" : "Done"}
        </Badge>
      </td>
    </tr>
  );
}

// ─── Loading skeleton row ─────────────────────────────────────────────────────

export function SlaSkeletonRow() {
  return (
    <tr className="border-b border-[var(--color-border)]">
      <td className="py-3 pl-4 pr-4"><Skeleton className="h-4 w-32" /></td>
      <td className="py-3 pr-4"><Skeleton className="h-4 w-20" /></td>
      <td className="py-3 pr-4"><Skeleton className="h-4 w-28" /></td>
      <td className="py-3 pr-4"><Skeleton className="h-5 w-16 rounded-full" /></td>
    </tr>
  );
}
