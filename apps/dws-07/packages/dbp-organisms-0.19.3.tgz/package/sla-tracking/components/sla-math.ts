import type { WorkflowInstance, StepHistoryEntry } from "@dbp/ps-workflow/client";
import type { SlaDef, SlaStatus } from "../types.js";

export interface ActiveSlaRow {
  kind: "active";
  workflowId: string;
  title: string;
  subtitle: string | undefined;
  stepId: string;
  stepLabel: string;
  elapsedMinutes: number;
  targetMinutes: number;
  pct: number;
  status: SlaStatus;
}

export interface CompletedSlaRow {
  kind: "completed";
  workflowId: string;
  title: string;
  subtitle: string | undefined;
  totalMinutes: number;
  finalStatus: "completed" | "rejected";
}

export type SlaRow = ActiveSlaRow | CompletedSlaRow;

/**
 * Returns the ISO timestamp of the most recent history entry with action "start"
 * for the given stepId — i.e., when the instance entered that step.
 * Returns null if no such entry is found.
 */
function stepEntryTs(steps: StepHistoryEntry[], stepId: string): string | null {
  // History entries are ordered oldest → newest. We want the LATEST "start"
  // entry for this step (an instance may re-enter a step after rejection).
  let last: string | null = null;
  for (const s of steps) {
    if (s.stepId === stepId && s.action === "start") {
      last = s.ts;
    }
  }
  return last;
}

function elapsedMinutes(fromIso: string, nowMs: number): number {
  return (nowMs - new Date(fromIso).getTime()) / 60_000;
}

function computeStatus(pct: number, warnAtPercent: number): SlaStatus {
  if (pct >= 100) return "breached";
  if (pct >= warnAtPercent) return "warning";
  return "ok";
}

function resolveTitle(
  context: Record<string, unknown>,
  titleField: string | undefined,
  workflowId: string,
): string {
  if (!titleField) return workflowId;
  const v = context[titleField];
  return typeof v === "string" || typeof v === "number" ? String(v) : workflowId;
}

function resolveSubtitle(
  context: Record<string, unknown>,
  subtitleField: string | undefined,
): string | undefined {
  if (!subtitleField) return undefined;
  const v = context[subtitleField];
  return typeof v === "string" || typeof v === "number" ? String(v) : undefined;
}

/**
 * Computes SlaRow data for a single WorkflowInstance.
 *
 * Terminal instances (completed/rejected) skip SLA verdict and simply show
 * total duration from createdAt to the last history entry. This is documented
 * as intentional — we cannot determine SLA compliance retroactively from a
 * partial step history without knowing which step was "final".
 */
export function computeSlaRow(
  instance: WorkflowInstance,
  slas: SlaDef[],
  warnAtPercent: number,
  nowMs: number,
  titleField: string | undefined,
  subtitleField: string | undefined,
): SlaRow {
  const title = resolveTitle(instance.context, titleField, instance.workflowId);
  const subtitle = resolveSubtitle(instance.context, subtitleField);

  // Terminal instances (completed / rejected)
  if (instance.status !== "running" || instance.currentStep === null) {
    const lastEntry = instance.steps.at(-1);
    const endMs = lastEntry ? new Date(lastEntry.ts).getTime() : nowMs;
    const totalMinutes = (endMs - new Date(instance.createdAt).getTime()) / 60_000;
    return {
      kind: "completed",
      workflowId: instance.workflowId,
      title,
      subtitle,
      totalMinutes,
      finalStatus: instance.status === "rejected" ? "rejected" : "completed",
    };
  }

  const currentStep = instance.currentStep;
  const slaDef = slas.find((s) => s.stepId === currentStep);
  const entryTs = stepEntryTs(instance.steps, currentStep);

  if (!slaDef || !entryTs) {
    // Step not covered by SLA config, or entry timestamp missing — treat as ok.
    return {
      kind: "active",
      workflowId: instance.workflowId,
      title,
      subtitle,
      stepId: currentStep,
      stepLabel: slaDef?.label ?? currentStep,
      elapsedMinutes: entryTs ? elapsedMinutes(entryTs, nowMs) : 0,
      targetMinutes: slaDef?.targetMinutes ?? 0,
      pct: 0,
      status: "ok",
    };
  }

  const elapsed = elapsedMinutes(entryTs, nowMs);
  const pct = (elapsed / slaDef.targetMinutes) * 100;

  return {
    kind: "active",
    workflowId: instance.workflowId,
    title,
    subtitle,
    stepId: currentStep,
    stepLabel: slaDef.label ?? currentStep,
    elapsedMinutes: elapsed,
    targetMinutes: slaDef.targetMinutes,
    pct,
    status: computeStatus(pct, warnAtPercent),
  };
}

const STATUS_ORDER: Record<SlaStatus, number> = { breached: 0, warning: 1, ok: 2 };

/** Sort active rows: breached first, then warning, then ok. */
export function sortActiveRows(rows: ActiveSlaRow[]): ActiveSlaRow[] {
  return [...rows].sort((a, b) => STATUS_ORDER[a.status] - STATUS_ORDER[b.status]);
}

/** Format elapsed vs target for display, e.g. "38m / 60m". */
export function formatDuration(elapsedMinutes: number, targetMinutes: number): string {
  const fmt = (m: number) => `${Math.floor(m)}m`;
  return `${fmt(elapsedMinutes)} / ${fmt(targetMinutes)}`;
}
