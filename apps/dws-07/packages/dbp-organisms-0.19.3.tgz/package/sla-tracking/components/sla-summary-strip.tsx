import * as React from "react";
import type { ActiveSlaRow } from "./sla-math.js";

interface SlaSummaryStripProps {
  rows: ActiveSlaRow[];
}

/**
 * Summary counts bar — shows how many active instances are ok / warning / breached.
 */
export function SlaSummaryStrip({ rows }: SlaSummaryStripProps) {
  const breached = rows.filter((r) => r.status === "breached").length;
  const warning = rows.filter((r) => r.status === "warning").length;
  const ok = rows.filter((r) => r.status === "ok").length;

  return (
    <div
      className="flex gap-5 rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-4 py-2.5 text-sm"
      data-testid="sla-summary-strip"
    >
      <span>
        <span className="font-semibold tabular-nums text-[var(--color-danger-text)]" data-testid="summary-breached">
          {breached}
        </span>{" "}
        <span className="text-[var(--color-text-muted)]">breached</span>
      </span>
      <span>
        <span className="font-semibold tabular-nums text-[var(--color-warning-text)]" data-testid="summary-warning">
          {warning}
        </span>{" "}
        <span className="text-[var(--color-text-muted)]">at risk</span>
      </span>
      <span>
        <span className="font-semibold tabular-nums text-[var(--color-success-text)]" data-testid="summary-ok">
          {ok}
        </span>{" "}
        <span className="text-[var(--color-text-muted)]">on track</span>
      </span>
    </div>
  );
}
