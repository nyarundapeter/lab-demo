import * as React from "react";
import { Alert, Skeleton } from "@dbp/ui";
import { WorkflowServiceError } from "@dbp/ps-workflow/client";
import { ApprovalSurfaceConfig, ApprovalQueueConfig as ApprovalQueueConfigSchema } from "./types.js";
import type { ApprovalQueueConfig as ApprovalQueueConfigType } from "./types.js";
import { ApprovalQueue } from "./components/approval-queue.js";
import { useApprovalWorkflow } from "./hooks/use-approval-workflow.js";
import { StepStatusBadge } from "./components/step-status-badge.js";
import { StepHistory } from "./components/step-history.js";
import { ActionPanel } from "./components/action-panel.js";

type ConfigInput = Omit<
  ApprovalSurfaceConfig,
  "requireComment" | "showHistory" | "allowDelegate" | "allowRequestInfo"
> &
  Partial<
    Pick<ApprovalSurfaceConfig, "requireComment" | "showHistory" | "allowDelegate" | "allowRequestInfo">
  >;

/**
 * APP.F06 — Approval Action Surface
 *
 * Renders the current step of a PS.WORKFLOW instance and exposes RBAC-gated
 * approve/reject actions. Used by finance approvers in SH.02/SH.03 context
 * and inline slots.
 *
 * Two-layer permission enforcement:
 * 1. UI gate (PS.RBAC packed rules, local CASL evaluation) — hides action
 *    buttons when the calling user's roles do not include the approveAction.
 * 2. Workflow engine (server-side) — re-validates roles on advance/reject POST.
 *    A 403 from the engine is surfaced as an inline service error.
 *
 * This double-check is intentional: the UI gate prevents users from even
 * attempting an action they cannot perform (UX), while the engine enforces
 * the structural transition rule authoritatively (security).
 */
export default function ApprovalSurface(rawConfig: ConfigInput | ApprovalQueueConfigType) {
  // Queue mode (P1a): a definitionId-shaped config lists every instance
  // awaiting approval and mounts the single-instance surface for the selected
  // row. Keeps the generator's generic `<Component {...config}/>` emission
  // working for both modes of APP.F06.
  if ("definitionId" in rawConfig) {
    const queueParse = ApprovalQueueConfigSchema.safeParse(rawConfig);
    if (!queueParse.success) {
      return (
        <Alert tone="danger" title="ApprovalQueue configuration error" data-testid="config-error">
          <ul className="mt-1 list-disc pl-4">
            {queueParse.error.errors.map((e, i) => (
              <li key={i}>
                {e.path.join(".") || "root"}: {e.message}
              </li>
            ))}
          </ul>
        </Alert>
      );
    }
    return <ApprovalQueue config={queueParse.data} />;
  }
  const parseResult = ApprovalSurfaceConfig.safeParse(rawConfig);
  if (!parseResult.success) {
    return (
      <Alert tone="danger" title="ApprovalSurface configuration error" data-testid="config-error">
        <ul className="mt-1 list-disc pl-4">
          {parseResult.error.errors.map((e, i) => (
            <li key={i}>
              {e.path.join(".") || "root"}: {e.message}
            </li>
          ))}
        </ul>
      </Alert>
    );
  }

  return <ApprovalSurfaceInner config={parseResult.data} />;
}

export type { ApprovalSurfaceConfig } from "./types.js";
export { ApprovalQueue } from "./components/approval-queue.js";
export { ApprovalQueueConfig } from "./types.js";

// Wave 3 Family 3 (2026-07-22) — exported so approval-drawer (a sibling
// organism composing this surface's action/history pieces + a new
// EvidencePanel) and consumers of the threshold/parallel route variants
// don't need a second copy of these components.
export { ActionPanel } from "./components/action-panel.js";
export { StepHistory } from "./components/step-history.js";
export { StepStatusBadge } from "./components/step-status-badge.js";
export { useApprovalWorkflow } from "./hooks/use-approval-workflow.js";
export { RuleBanner } from "./components/rule-banner.js";
export { ThresholdApproval } from "./components/threshold-approval.js";
export type { ThresholdTier, ThresholdRouteStep, ThresholdRouteDecision } from "./components/threshold-approval.js";
export { ParallelApproval } from "./components/parallel-approval.js";
export type { ParallelApprovalStep, ParallelApprovalDecision } from "./components/parallel-approval.js";

// ─── Inner component (config guaranteed valid) ────────────────────────────────

interface ApprovalSurfaceInnerProps {
  config: ApprovalSurfaceConfig;
}

/**
 * Placeholder session for the demo blueprint. In production the shell injects
 * the real session via context; for this blueprint a static demo token is used
 * so the feature compiles and tests without a live auth provider.
 */
// Roles include the two identities scaffold-solution seeds for every generated
// solution ("platform-admin"/"user") so the engine's assigneeRoles intersection
// passes on standard-menu demo steps (same parity rule as the Kanban organism's
// DEMO_ACTOR_ROLES — see standard-menu-scaffold.mjs KANBAN_DEMO_ROLES).
const DEMO_SESSION = btoa(
  JSON.stringify({
    userId: "demo-approver",
    roles: ["finance-approver", "platform-admin", "user"],
    tenantId: "demo",
  }),
);

function ApprovalSurfaceInner({ config }: ApprovalSurfaceInnerProps) {
  const { instance, isLoading, error, isAdvancing, isRejecting, advance, reject } =
    useApprovalWorkflow(config.workflowId);

  const [serviceError, setServiceError] = React.useState<string | null>(null);

  // A terminal instance (completed or rejected) is read-only.
  const isTerminal =
    instance !== null &&
    (instance.status === "completed" || instance.status === "rejected");

  async function handleApprove(comment: string) {
    setServiceError(null);
    try {
      await advance({ comment: comment || undefined }, DEMO_SESSION);
    } catch (err) {
      const msg =
        err instanceof WorkflowServiceError && err.status === 403
          ? "The workflow engine denied the transition. You may not have permission to approve this step."
          : err instanceof WorkflowServiceError
          ? err.message
          : "Failed to approve. Please try again.";
      setServiceError(msg);
    }
  }

  // Decision context (WFL-24/25) — local-only events; see the doc-comment on
  // ActionPanel's onDelegate/onRequestInfo props for why these don't call the
  // workflow engine.
  function handleDelegate(_targetUserId: string, _comment: string) {
    setServiceError(null);
  }

  function handleRequestInfo(_comment: string) {
    setServiceError(null);
  }

  async function handleReject(comment: string) {
    setServiceError(null);
    try {
      await reject({ comment: comment || undefined }, DEMO_SESSION);
    } catch (err) {
      const msg =
        err instanceof WorkflowServiceError && err.status === 403
          ? "The workflow engine denied the transition. You may not have permission to reject this step."
          : err instanceof WorkflowServiceError
          ? err.message
          : "Failed to reject. Please try again.";
      setServiceError(msg);
    }
  }

  if (isLoading) {
    return (
      <div
        className="flex flex-col gap-3 rounded border border-[var(--color-border)] bg-[var(--color-surface)] p-4"
        data-testid="approval-surface-loading"
        aria-busy="true"
        aria-label="Loading approval surface"
      >
        <Skeleton className="h-4 w-32" />
        <Skeleton className="h-4 w-48" />
        <Skeleton className="h-10 w-full" />
      </div>
    );
  }

  if (error && instance === null) {
    const msg =
      error instanceof WorkflowServiceError
        ? error.message
        : "Unexpected error loading workflow instance.";
    return (
      <Alert tone="danger" title="Failed to load workflow instance" data-testid="error-state">
        {msg}
      </Alert>
    );
  }

  if (instance === null) {
    return null;
  }

  return (
    <div className="dq-card flex flex-col gap-4" data-testid="approval-surface">
      {/* Header: current step + status */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex flex-col gap-1">
          <span className="dq-overline">Current Step</span>
          <span
            className="text-sm font-semibold text-[var(--color-primary)]"
            data-testid="current-step"
          >
            {instance.currentStep ?? "—"}
          </span>
        </div>
        <StepStatusBadge status={instance.status} />
      </div>

      {/* Assignee roles (from last step actor) */}
      {instance.steps.length > 0 && (
        <div className="text-xs text-[var(--color-text-muted)]" data-testid="assignee-roles">
          Last actor:{" "}
          <span className="font-medium text-[var(--color-text-secondary)]">
            {instance.steps[instance.steps.length - 1]?.actor.roles.join(", ")}
          </span>
        </div>
      )}

      {/* Action area — read-only outcome for terminal instances */}
      {isTerminal ? (
        <div
          className="rounded border border-[var(--color-border)] bg-[var(--color-bg)] px-4 py-3 text-sm text-[var(--color-text)] opacity-70"
          data-testid="terminal-outcome"
        >
          This instance is <strong>{instance.status}</strong>. No further actions are available.
        </div>
      ) : (
        <ActionPanel
          config={config}
          isAdvancing={isAdvancing}
          isRejecting={isRejecting}
          serviceError={serviceError}
          onApprove={handleApprove}
          onReject={handleReject}
          onDelegate={handleDelegate}
          onRequestInfo={handleRequestInfo}
        />
      )}

      {/* Step history */}
      {config.showHistory && (
        <div className="flex flex-col gap-2" data-testid="history-section">
          <h3 className="dq-overline">History</h3>
          <StepHistory steps={instance.steps} />
        </div>
      )}
    </div>
  );
}
