import { z } from "zod";

/**
 * ApprovalSurfaceConfig — the single typed contract for APP.F06.
 *
 * Data contract only (no function fields — Zod schemas are data-only).
 *
 * The feature wires PS.WORKFLOW (instance state, advance/reject) and PS.RBAC
 * (packed-rules evaluation via useCan). Both services must be configured before
 * the feature renders in tests/stories.
 */
export const ApprovalSurfaceConfig = z.object({
  /** The PS.WORKFLOW instance ID to load and act on. */
  workflowId: z.string().min(1),

  /**
   * RBAC action string to gate the approve/reject buttons.
   * E.g. "invoice.approve". The packed rules from PS.RBAC are evaluated
   * locally — no per-check network call (sub-10 ms SLO).
   */
  approveAction: z.string().min(1),

  /**
   * Optional RBAC resource type passed to useCan for subject matching.
   * E.g. "invoice". Omit for action-only checks.
   */
  resource: z.string().optional(),

  /** Label for the approve button. Defaults to "Approve". */
  approveLabel: z.string().optional(),

  /** Label for the reject button. Defaults to "Reject". */
  rejectLabel: z.string().optional(),

  /**
   * When a comment is required:
   * - "never"     — textarea never shown
   * - "on-reject" — textarea shown and required only when rejecting (default)
   * - "always"    — textarea shown and required for both approve and reject
   */
  requireComment: z.enum(["never", "on-reject", "always"]).default("on-reject"),

  /**
   * Whether to render the step-history list below the action surface.
   * Defaults to true.
   */
  showHistory: z.boolean().default(true),

  /**
   * Whether the "Delegate" action is offered alongside approve/reject
   * (WFL-24, design-audit-2026-07-17-admin-workflow.md — "delegate & request
   * info not verified present"). Delegation and request-info are recorded as
   * local decision-context events, not PS.WORKFLOW transitions — the engine
   * has no delegate/request-info verb yet; see the "Decision context" panel
   * doc-comment in components/action-panel.tsx.
   */
  allowDelegate: z.boolean().default(true),

  /** Whether the "Request info" action is offered. See `allowDelegate`. */
  allowRequestInfo: z.boolean().default(true),

  /**
   * Evidence backing the decision (attachments/links) — WFL-24's evidence
   * panel. Purely presentational; the caller supplies whatever links/labels
   * are relevant to the record.
   */
  evidence: z
    .array(
      z.object({
        label: z.string().min(1),
        href: z.string().min(1),
      }),
    )
    .optional(),
});

export type ApprovalSurfaceConfig = z.infer<typeof ApprovalSurfaceConfig>;

/**
 * ApprovalQueueConfig — queue mode of APP.F06 (P1a, design-audit remediation).
 *
 * Instead of a single `workflowId`, the queue lists every running instance of
 * `definitionId` currently sitting in one of `approvalStepIds` and mounts the
 * single-instance surface for the selected row. The generator derives
 * `approvalStepIds` from the definition's approval-type steps at emission
 * time, keeping the client free of a definition fetch.
 */
export const ApprovalQueueConfig = z.object({
  definitionId: z.string().min(1),
  approvalStepIds: z.array(z.string().min(1)).min(1),
  approveAction: z.string().min(1),
  resource: z.string().optional(),
  requireComment: z.enum(["never", "on-reject", "always"]).optional(),
  showHistory: z.boolean().optional(),
  allowDelegate: z.boolean().optional(),
  allowRequestInfo: z.boolean().optional(),
  evidence: z
    .array(
      z.object({
        label: z.string().min(1),
        href: z.string().min(1),
      }),
    )
    .optional(),
});

export type ApprovalQueueConfig = z.infer<typeof ApprovalQueueConfig>;
