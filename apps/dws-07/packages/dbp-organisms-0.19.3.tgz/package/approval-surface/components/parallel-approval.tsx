import * as React from "react";
import { Users, Check, Clock } from "lucide-react";
import { Badge, Avatar } from "@dbp/ui";
import type { BadgeProps } from "@dbp/ui";
import { RuleBanner } from "./rule-banner.js";

export type ParallelApprovalDecision = "approved" | "pending";

export interface ParallelApprovalStep {
  id: string;
  name: string;
  role: string;
  decision: ParallelApprovalDecision;
  /** "Approved {at}" or "Pending · due {due}". */
  detail: string;
  /** The step currently awaiting a decision. */
  current?: boolean;
}

interface ParallelApprovalProps {
  /** e.g. "Completion rule: 2 of 3 required approvers must approve". */
  ruleLabel: React.ReactNode;
  steps: ParallelApprovalStep[];
}

const DECISION_TONE: Record<ParallelApprovalDecision, NonNullable<BadgeProps["tone"]>> = {
  approved: "success",
  pending: "active",
};

/**
 * ParallelApproval — Wave 3 Family 3 (APP.F06). Reference: wf-approval.jsx
 * `ParallelApproval` — independent approvers deciding concurrently against
 * an N-of-M completion rule, rendered without the sequential connecting
 * line ThresholdApproval/ApprovalSummary use. A molecule extension of
 * approval-surface, purely props-driven (see ThresholdApproval's
 * doc-comment for why this is not a standalone `ApprovalRoute` base).
 */
export function ParallelApproval({ ruleLabel, steps }: ParallelApprovalProps) {
  return (
    <div data-testid="parallel-approval">
      <RuleBanner icon={Users}>{ruleLabel}</RuleBanner>
      <div className="flex flex-col gap-2.5">
        {steps.map((step) => (
          <div
            key={step.id}
            className="flex items-center gap-2.5"
            data-testid="parallel-approval-step"
            data-current={step.current ?? false}
          >
            <Avatar name={step.name} size="sm" />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-[var(--color-text-primary)]">{step.name}</span>
                <span className="text-xs text-[var(--color-text-muted)]">{step.role}</span>
                {step.current && (
                  <Badge tone="active" size="sm">
                    <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-active)]" aria-hidden="true" />
                    Current
                  </Badge>
                )}
              </div>
              <div className="text-xs text-[var(--color-text-muted)]">{step.detail}</div>
            </div>
            <Badge tone={DECISION_TONE[step.decision]} size="sm">
              {step.decision === "approved" ? <Check size={11} aria-hidden="true" /> : <Clock size={11} aria-hidden="true" />}
              {step.decision === "approved" ? "Approved" : "Pending"}
            </Badge>
          </div>
        ))}
      </div>
    </div>
  );
}
