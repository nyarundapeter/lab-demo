import * as React from "react";
import { SectionLabel } from "@dbp/ui";
import type { StepHistoryEntry } from "@dbp/ps-workflow/client";

interface StepHistoryProps {
  steps: StepHistoryEntry[];
}

export function StepHistory({ steps }: StepHistoryProps) {
  if (steps.length === 0) {
    return (
      <p
        className="text-sm text-[var(--color-text)] opacity-50"
        data-testid="history-empty"
      >
        No history yet.
      </p>
    );
  }

  return (
    <ol className="space-y-2" data-testid="step-history-list">
      {steps.map((entry, i) => (
        <li
          key={i}
          className="flex flex-col gap-0.5 rounded border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2 text-xs"
          data-testid="history-entry"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="font-medium text-[var(--color-text)]">
              {entry.actor.userId}
            </span>
            <span className="text-[var(--color-text)] opacity-60">
              {new Date(entry.ts).toLocaleString()}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <SectionLabel className="rounded bg-[var(--color-bg)] px-1.5 py-0.5 font-mono text-[0.65rem] text-[var(--color-text)] opacity-70">
              {entry.action}
            </SectionLabel>
            <span className="text-[var(--color-text)] opacity-60">
              step: {entry.stepId}
            </span>
          </div>
          {entry.comment && (
            <p className="mt-0.5 italic text-[var(--color-text)] opacity-80">
              &ldquo;{entry.comment}&rdquo;
            </p>
          )}
        </li>
      ))}
    </ol>
  );
}
