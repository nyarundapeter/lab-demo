"use client";
import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Alert, Badge, Button, LoadingSkeleton } from "@dbp/ui";
import { useWorkflowInstances, getInstance } from "@dbp/ps-workflow/client";
import type { WorkflowInstanceView } from "@dbp/ps-workflow/client";
import ApprovalSurface from "../index.js";
import type { ApprovalQueueConfig } from "../types.js";

/**
 * ApprovalQueue — the queue mode of APP.F06 (P1a, design-audit remediation).
 *
 * Lists the running instances of a definition that currently sit in an
 * approval-type step, and mounts the single-instance ApprovalSurface for the
 * selected one. Approving/rejecting moves the real instance; the queue refetch
 * happens through the surface's own cache updates plus this list's refetch on
 * selection change.
 *
 * Which steps count as "approval" comes from config.approvalStepIds — the
 * generator derives it from the definition's step types at emission time, so
 * the client needs no definition fetch here.
 */
export function ApprovalQueue({ config }: { config: ApprovalQueueConfig }) {
  const { data, isLoading, error, refetch } = useWorkflowInstances({
    definitionId: config.definitionId,
    status: "active",
  });

  const approvalSteps = React.useMemo(
    () => new Set(config.approvalStepIds),
    [config.approvalStepIds],
  );
  const queue = React.useMemo(
    () =>
      (data?.rows ?? []).filter((i: WorkflowInstanceView) => {
        const step = i.currentStepId ?? i.currentStep;
        return step !== null && approvalSteps.has(step);
      }),
    [data, approvalSteps],
  );

  const [selectedId, setSelectedId] = React.useState<string | null>(null);
  const activeId =
    selectedId !== null && queue.some((i: WorkflowInstanceView) => i.workflowId === selectedId)
      ? selectedId
      : queue[0]?.workflowId ?? null;

  // Watch the selected instance's shared cache entry (the single-instance
  // surface writes advance/reject results into ["ps-workflow","instance",id]
  // via useApprovalWorkflow's onSuccess). When the instance leaves its
  // approval step — approved, rejected, or moved on — refetch the queue so
  // the acted-on row disappears without a manual refresh.
  const { data: activeInstance } = useQuery({
    queryKey: ["ps-workflow", "instance", activeId],
    queryFn: () => getInstance(activeId as string),
    enabled: activeId !== null,
  });
  React.useEffect(() => {
    if (!activeInstance) return;
    const step = activeInstance.currentStep;
    const stillPending =
      activeInstance.status === "running" && step !== null && approvalSteps.has(step);
    if (!stillPending) void refetch();
  }, [activeInstance, approvalSteps, refetch]);

  if (isLoading) {
    return (
      <div data-testid="approval-queue-loading">
        <LoadingSkeleton rows={4} />
      </div>
    );
  }
  if (error) {
    return (
      <Alert tone="danger" title="Failed to load approval queue" data-testid="approval-queue-error">
        {error instanceof Error ? error.message : "Unexpected error loading the queue."}
      </Alert>
    );
  }
  if (queue.length === 0) {
    return (
      <div
        className="rounded border border-[var(--color-border)] bg-[var(--color-surface)] p-6 text-center text-sm text-[var(--color-text-muted)]"
        data-testid="approval-queue-empty"
      >
        Nothing is waiting for approval right now.
      </div>
    );
  }

  return (
    <div className="flex h-full min-h-0 gap-4" data-testid="approval-queue">
      {/* Queue list */}
      <div className="w-72 shrink-0 overflow-y-auto rounded border border-[var(--color-border)] bg-[var(--color-surface-content)]">
        <div className="border-b border-[var(--color-border-subtle)] px-3 py-2 text-xs font-semibold text-[var(--color-text-muted)]">
          Awaiting approval · {queue.length}
        </div>
        <ul>
          {queue.map((inst: WorkflowInstanceView) => {
            const title =
              (inst.context as Record<string, unknown> | undefined)?.["name"] ??
              inst.workflowId.slice(0, 8);
            const owner = (inst.context as Record<string, unknown> | undefined)?.["owner"];
            return (
              <li key={inst.workflowId}>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setSelectedId(inst.workflowId);
                    void refetch();
                  }}
                  aria-current={inst.workflowId === activeId ? "true" : undefined}
                  className={[
                    "h-auto w-full flex-col items-start justify-start rounded-none border-b border-[var(--color-border-subtle)] px-3 py-2.5 text-left transition-colors",
                    inst.workflowId === activeId
                      ? "bg-[var(--color-navy-50)] hover:bg-[var(--color-navy-50)]"
                      : "hover:bg-[var(--color-surface)]",
                  ].join(" ")}
                >
                  <div className="truncate text-sm font-medium text-primary">{String(title)}</div>
                  <div className="mt-0.5 flex items-center gap-2">
                    <Badge tone="info">{inst.currentStep}</Badge>
                    {typeof owner === "string" && (
                      <span className="truncate text-xs text-[var(--color-text-muted)]">{owner}</span>
                    )}
                  </div>
                </Button>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Selected instance's approval surface */}
      <div className="min-w-0 flex-1 overflow-y-auto">
        {activeId !== null && (
          <ApprovalSurface
            key={activeId}
            workflowId={activeId}
            approveAction={config.approveAction}
            {...(config.resource !== undefined && { resource: config.resource })}
            requireComment={config.requireComment ?? "on-reject"}
            showHistory={config.showHistory ?? true}
            allowDelegate={config.allowDelegate ?? true}
            allowRequestInfo={config.allowRequestInfo ?? true}
            {...(config.evidence !== undefined && { evidence: config.evidence })}
          />
        )}
      </div>
    </div>
  );
}
