import * as React from "react";
import { Scale, Check } from "lucide-react";
import { Badge, Avatar } from "@dbp/ui";
import type { BadgeProps } from "@dbp/ui";
import { RuleBanner } from "./rule-banner.js";

export interface ThresholdTier {
  range: string;
  approverLabel: string;
  /** Whether this tier applies to the request being shown. */
  active: boolean;
}

export type ThresholdRouteDecision = "approved" | "pending" | "upcoming";

export interface ThresholdRouteStep {
  id: string;
  name: string;
  role: string;
  decision: ThresholdRouteDecision;
  /** "Approved {at}" / "Pending · due {due}" detail text. */
  detail: string;
}

interface ThresholdApprovalProps {
  /** e.g. "Threshold rule: €48,000 ≥ €25,000 → VP approval required". */
  ruleLabel: React.ReactNode;
  tiers: ThresholdTier[];
  route: ThresholdRouteStep[];
}

const DECISION_TONE: Record<ThresholdRouteDecision, NonNullable<BadgeProps["tone"]>> = {
  approved: "success",
  pending: "active",
  upcoming: "gray",
};

/**
 * ThresholdApproval — Wave 3 Family 3 (APP.F06). Reference: wf-approval.jsx
 * `ThresholdApproval` — amount-tier routing rule (below-threshold auto/
 * manager-approved, above-threshold escalates) rendered as a rule banner +
 * tier grid + the resulting approval route. A molecule extension of
 * approval-surface, not a standalone `ApprovalRoute` base
 * (wave3-family3-tier-audit.md row 19) — purely props-driven; the caller
 * supplies the resolved tiers/route (no PS.WORKFLOW route-topology fetch
 * exists to derive this from).
 */
export function ThresholdApproval({ ruleLabel, tiers, route }: ThresholdApprovalProps) {
  return (
    <div data-testid="threshold-approval">
      <RuleBanner icon={Scale}>{ruleLabel}</RuleBanner>
      <div className="mb-3.5 grid grid-cols-3 gap-2">
        {tiers.map((tier) => (
          <div
            key={tier.range}
            className={
              tier.active
                ? "rounded-[var(--radius-card)] border border-[var(--color-active)]/50 bg-[var(--color-active-surface)] p-2.5"
                : "rounded-[var(--radius-card)] border border-[var(--color-border-default)] p-2.5"
            }
            data-testid="threshold-tier"
            data-active={tier.active}
          >
            <div className="text-xs font-semibold text-[var(--color-text-primary)]">{tier.range}</div>
            <div className="text-xs text-[var(--color-text-muted)]">{tier.approverLabel}</div>
            {tier.active && (
              <Badge tone="active" size="sm" className="mt-1.5">
                This request
              </Badge>
            )}
          </div>
        ))}
      </div>
      <div className="flex flex-col gap-2.5">
        {route.map((step) => (
          <div key={step.id} className="flex items-center gap-2.5" data-testid="threshold-route-step">
            <Avatar name={step.name} size="sm" />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-[var(--color-text-primary)]">{step.name}</span>
                <span className="text-xs text-[var(--color-text-muted)]">{step.role}</span>
              </div>
              <div className="text-xs text-[var(--color-text-muted)]">{step.detail}</div>
            </div>
            <Badge tone={DECISION_TONE[step.decision]} size="sm">
              {step.decision === "approved" && <Check size={11} aria-hidden="true" />}
              {step.decision === "approved" ? "Approved" : step.decision === "pending" ? "Pending" : "Upcoming"}
            </Badge>
          </div>
        ))}
      </div>
    </div>
  );
}
