import * as React from "react";
import { PermissionGate, Button, Alert, Input, Textarea, AiMark, AiConfidence, Advisory, CtrlBadge } from "@dbp/ui";
import { Paperclip } from "lucide-react";
import type { ApprovalSurfaceConfig } from "../types.js";

interface ActionPanelProps {
  config: ApprovalSurfaceConfig;
  isAdvancing: boolean;
  isRejecting: boolean;
  serviceError: string | null;
  onApprove: (comment: string) => void;
  onReject: (comment: string) => void;
  /**
   * Decision context (WFL-24/25) — delegate and request-info are recorded as
   * local decision-context events, not PS.WORKFLOW transitions: the engine
   * has no delegate/request-info verb yet (only advance/reject/reassign/
   * force-advance/cancel — see use-record-workflow.ts and
   * use-approval-workflow.ts). These callbacks let the surface log the event
   * inline; a future PS.WORKFLOW verb would replace the local-only handling.
   */
  onDelegate?: (targetUserId: string, comment: string) => void;
  onRequestInfo?: (comment: string) => void;
}

type DecisionMode = "approve-reject" | "delegate" | "request-info";

/**
 * Renders the approve/reject buttons wrapped in a PermissionGate, plus
 * (WFL-24/25) delegate and request-info decision-context actions and an
 * evidence panel of attachments/links backing the decision.
 * When the RBAC gate denies, renders a quiet "no permission" note instead.
 * Comment textarea is displayed per the requireComment policy.
 */
export function ActionPanel({
  config,
  isAdvancing,
  isRejecting,
  serviceError,
  onApprove,
  onReject,
  onDelegate,
  onRequestInfo,
}: ActionPanelProps) {
  const [comment, setComment] = React.useState("");
  const [commentError, setCommentError] = React.useState<string | null>(null);
  const [mode, setMode] = React.useState<DecisionMode>("approve-reject");
  const [delegateTarget, setDelegateTarget] = React.useState("");
  const [delegateComment, setDelegateComment] = React.useState("");
  const [requestInfoComment, setRequestInfoComment] = React.useState("");
  const [lastEvent, setLastEvent] = React.useState<string | null>(null);

  const approveLabel = config.approveLabel ?? "Approve";
  const rejectLabel = config.rejectLabel ?? "Reject";
  const isBusy = isAdvancing || isRejecting;
  const allowDelegate = config.allowDelegate ?? true;
  const allowRequestInfo = config.allowRequestInfo ?? true;

  function requiresComment(action: "approve" | "reject"): boolean {
    if (config.requireComment === "always") return true;
    if (config.requireComment === "on-reject" && action === "reject") return true;
    return false;
  }

  function handleApprove() {
    if (requiresComment("approve") && comment.trim() === "") {
      setCommentError("A comment is required before approving.");
      return;
    }
    setCommentError(null);
    onApprove(comment.trim());
  }

  function handleReject() {
    if (requiresComment("reject") && comment.trim() === "") {
      setCommentError("A comment is required before rejecting.");
      return;
    }
    setCommentError(null);
    onReject(comment.trim());
  }

  function handleSendDelegate() {
    if (delegateTarget.trim() === "") return;
    onDelegate?.(delegateTarget.trim(), delegateComment.trim());
    setLastEvent(`Delegated to ${delegateTarget.trim()}.`);
    setDelegateTarget("");
    setDelegateComment("");
    setMode("approve-reject");
  }

  function handleSendRequestInfo() {
    if (requestInfoComment.trim() === "") return;
    onRequestInfo?.(requestInfoComment.trim());
    setLastEvent("Info requested from the record owner.");
    setRequestInfoComment("");
    setMode("approve-reject");
  }

  const showTextarea = config.requireComment !== "never";

  return (
    <PermissionGate
      action={config.approveAction}
      {...(config.resource !== undefined && { resource: config.resource })}
      fallback={
        <p
          className="text-sm text-[var(--color-text-muted)]"
          data-testid="no-permission-note"
        >
          You do not have permission to action this step.
        </p>
      }
    >
      <div className="flex flex-col gap-3" data-testid="action-panel">
        {/*
         * AI recommendation (WFL-38, design-audit-2026-07-17-admin-workflow.md).
         * Inline demo composition of the W3 primitives on the decision surface —
         * PS.AI is a stub gateway, so the confidence value here is illustrative,
         * not model-derived. CtrlBadge level 2 ("Recommend") + Advisory make
         * clear this never auto-decides; a human still has to press a button.
         */}
        <div
          className="flex flex-col gap-1.5 rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-bg-subtle,var(--color-bg))] px-3.5 py-3"
          data-testid="ai-recommendation"
        >
          <div className="flex flex-wrap items-center gap-2">
            <AiMark size={14} />
            <span className="text-sm font-medium text-[var(--color-text-primary)]">
              AI recommends {approveLabel.toLowerCase()} (87%)
            </span>
            <AiConfidence
              level="high"
              note="Demo confidence — PS.AI is a stub gateway; this value is illustrative, not model-derived."
            />
            <CtrlBadge level={2} />
          </div>
          <Advisory />
        </div>

        {config.evidence && config.evidence.length > 0 && (
          <div className="flex flex-col gap-1.5" data-testid="evidence-panel">
            <h3 className="dq-overline">Evidence</h3>
            <ul className="flex flex-col gap-1">
              {config.evidence.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline"
                    data-testid="evidence-item"
                  >
                    <Paperclip size={13} aria-hidden="true" />
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}

        {(allowDelegate || allowRequestInfo) && (
          <div className="flex gap-1.5" data-testid="decision-mode-tabs">
            <Button
              type="button"
              variant={mode === "approve-reject" ? "navy" : "ghost"}
              size="sm"
              onClick={() => setMode("approve-reject")}
              data-testid="mode-approve-reject-button"
            >
              Decide
            </Button>
            {allowDelegate && (
              <Button
                type="button"
                variant={mode === "delegate" ? "navy" : "ghost"}
                size="sm"
                onClick={() => setMode("delegate")}
                data-testid="mode-delegate-button"
              >
                Delegate
              </Button>
            )}
            {allowRequestInfo && (
              <Button
                type="button"
                variant={mode === "request-info" ? "navy" : "ghost"}
                size="sm"
                onClick={() => setMode("request-info")}
                data-testid="mode-request-info-button"
              >
                Request info
              </Button>
            )}
          </div>
        )}

        {lastEvent && (
          <Alert tone="info" data-testid="decision-context-event">
            {lastEvent}
          </Alert>
        )}

        {serviceError && (
          <Alert tone="danger" data-testid="service-error">
            {serviceError}
          </Alert>
        )}

        {mode === "approve-reject" && (
          <>
            {showTextarea && (
              <div className="flex flex-col gap-1.5">
                <label
                  htmlFor="approval-comment"
                  className="text-xs font-medium text-[var(--color-text-secondary)]"
                >
                  Comment
                  {config.requireComment === "always" && (
                    <span className="ml-1 text-[var(--color-danger)]">*</span>
                  )}
                  {config.requireComment === "on-reject" && (
                    <span className="ml-1 text-[var(--color-text-muted)]">
                      (required when rejecting)
                    </span>
                  )}
                </label>
                <textarea
                  id="approval-comment"
                  className="min-h-[80px] w-full rounded-[var(--radius-input)] border-[1.5px] border-[var(--color-border-default)] bg-surface px-3 py-2 text-sm text-[var(--color-text-primary)] placeholder:text-[var(--color-text-disabled)] hover:border-[var(--color-border-strong)] focus:outline-none focus-visible:border-primary focus-visible:[box-shadow:var(--focus-ring-navy)] disabled:opacity-50"
                  placeholder="Add a comment…"
                  value={comment}
                  onChange={(e) => {
                    setComment(e.target.value);
                    if (commentError) setCommentError(null);
                  }}
                  disabled={isBusy}
                  data-testid="comment-textarea"
                />
                {commentError && (
                  <p
                    className="text-xs text-[var(--color-danger-text)]"
                    data-testid="comment-error"
                    role="alert"
                  >
                    {commentError}
                  </p>
                )}
              </div>
            )}

            <div className="flex gap-2">
              <Button
                type="button"
                variant="navy"
                onClick={handleApprove}
                loading={isAdvancing}
                disabled={isBusy}
                data-testid="approve-button"
              >
                {isAdvancing ? "Approving…" : approveLabel}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={handleReject}
                loading={isRejecting}
                disabled={isBusy}
                data-testid="reject-button"
              >
                {isRejecting ? "Rejecting…" : rejectLabel}
              </Button>
            </div>
          </>
        )}

        {mode === "delegate" && (
          <div className="flex flex-col gap-2" data-testid="delegate-form">
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="delegate-target"
                className="text-xs font-medium text-[var(--color-text-secondary)]"
              >
                Delegate to (user ID)
              </label>
              <Input
                id="delegate-target"
                placeholder="e.g. u-approver-02"
                value={delegateTarget}
                onChange={(e) => setDelegateTarget(e.target.value)}
                data-testid="delegate-target-input"
              />
            </div>
            <Textarea
              placeholder="Add a note for the delegate (optional)…"
              value={delegateComment}
              onChange={(e) => setDelegateComment(e.target.value)}
              data-testid="delegate-comment-textarea"
            />
            <div className="flex gap-2">
              <Button
                type="button"
                variant="navy"
                onClick={handleSendDelegate}
                disabled={delegateTarget.trim() === ""}
                data-testid="delegate-send-button"
              >
                Send delegation
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setMode("approve-reject")}
                data-testid="delegate-cancel-button"
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        {mode === "request-info" && (
          <div className="flex flex-col gap-2" data-testid="request-info-form">
            <Textarea
              placeholder="What information is needed before deciding?"
              value={requestInfoComment}
              onChange={(e) => setRequestInfoComment(e.target.value)}
              data-testid="request-info-comment-textarea"
            />
            <div className="flex gap-2">
              <Button
                type="button"
                variant="navy"
                onClick={handleSendRequestInfo}
                disabled={requestInfoComment.trim() === ""}
                data-testid="request-info-send-button"
              >
                Send request
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setMode("approve-reject")}
                data-testid="request-info-cancel-button"
              >
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>
    </PermissionGate>
  );
}
