import * as React from "react";
import type { LucideIcon } from "lucide-react";

interface RuleBannerProps {
  icon: LucideIcon;
  children: React.ReactNode;
}

/**
 * RuleBanner — Wave 3 Family 3 (APP.F06). Reference: wf-approval.jsx
 * `RuleBanner` — a small info-toned strip stating the routing rule that
 * produced a given approval topology (threshold/parallel/committee). Used
 * by ThresholdApproval/ParallelApproval below; extends approval-surface's
 * own components rather than a new standalone @dbp/ui base
 * (wave3-tier-audits/wave3-family3-tier-audit.md row 19 — no
 * `ApprovalRoute` primitive exists to extend, so this ships as a
 * approval-surface-local molecule).
 */
export function RuleBanner({ icon: Icon, children }: RuleBannerProps) {
  return (
    <div
      className="mb-3.5 flex items-center gap-2 rounded-[var(--radius-card)] bg-[var(--color-info-surface)] px-3 py-2 text-xs text-[var(--color-info-text)]"
      data-testid="rule-banner"
    >
      <Icon size={14} className="shrink-0" aria-hidden="true" />
      {children}
    </div>
  );
}
