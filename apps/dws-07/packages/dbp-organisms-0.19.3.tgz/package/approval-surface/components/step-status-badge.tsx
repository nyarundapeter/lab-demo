import * as React from "react";
import { StatusBadge } from "@dbp/ui";
import type { BadgeProps } from "@dbp/ui";
import type { WorkflowStatus } from "@dbp/ps-workflow/client";

interface StepStatusBadgeProps {
  status: WorkflowStatus;
}

// `WorkflowStatus` is a workflow *step* run-state vocabulary, distinct from
// `StatusBadge`'s 11-state admin *entity* lifecycle vocabulary (design-system
// de-dup Wave 1.F — see status-badge.tsx doc-comment for why these aren't
// folded into one enum). Composes `StatusBadge` via its `tone` override for
// exactly this cross-domain case.
const STATUS_TONES: Record<WorkflowStatus, NonNullable<BadgeProps["tone"]>> = {
  running: "info",
  completed: "success",
  rejected: "danger",
  cancelled: "gray",
};

const STATUS_LABELS: Record<WorkflowStatus, string> = {
  running: "In Progress",
  completed: "Approved",
  rejected: "Rejected",
  cancelled: "Cancelled",
};

export function StepStatusBadge({ status }: StepStatusBadgeProps) {
  return (
    <StatusBadge tone={STATUS_TONES[status]} data-testid="step-status-badge">
      {STATUS_LABELS[status]}
    </StatusBadge>
  );
}
