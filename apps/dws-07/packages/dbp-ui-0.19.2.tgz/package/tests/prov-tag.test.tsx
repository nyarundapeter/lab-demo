import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { ProvTag, PROV_LABEL } from "../src/components/prov-tag.js";
import type { AiProvenance } from "@dbp/contracts";

afterEach(() => { cleanup(); });

const ALL_PROVENANCE: AiProvenance[] = ["source", "calc", "ai", "predict", "human", "auto"];

describe("ProvTag", () => {
  it("renders the default label for every provenance kind", () => {
    for (const provenance of ALL_PROVENANCE) {
      const { unmount } = render(<ProvTag provenance={provenance} />);
      expect(screen.getByText(PROV_LABEL[provenance])).toBeDefined();
      unmount();
    }
  });

  it("defaults to the source provenance when none is given", () => {
    render(<ProvTag />);
    expect(screen.getByText(PROV_LABEL.source)).toBeDefined();
  });

  it("allows a children override of the default label", () => {
    render(<ProvTag provenance="human">Reviewed by Jane</ProvTag>);
    expect(screen.getByText("Reviewed by Jane")).toBeDefined();
    expect(screen.queryByText(PROV_LABEL.human)).toBeNull();
  });
});
