import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { InlineEditable } from "../src/components/inline-editable.js";

afterEach(() => { cleanup(); });

describe("InlineEditable", () => {
  it("renders the value in read mode", () => {
    render(<InlineEditable label="Title" value="Q3 renewal" onSave={() => {}} />);
    expect(screen.getByText("Q3 renewal")).toBeDefined();
  });

  it("shows the placeholder when value is empty", () => {
    render(<InlineEditable label="Title" value="" onSave={() => {}} placeholder="Untitled" />);
    expect(screen.getByText("Untitled")).toBeDefined();
  });

  it("switches to an input on click and commits on Enter", () => {
    const onSave = vi.fn();
    render(<InlineEditable label="Title" value="Old" onSave={onSave} />);
    fireEvent.click(screen.getByTestId("inline-editable-display"));
    const input = screen.getByDisplayValue("Old");
    fireEvent.change(input, { target: { value: "New" } });
    fireEvent.keyDown(input, { key: "Enter" });
    expect(onSave).toHaveBeenCalledWith("New");
  });

  it("commits on blur", () => {
    const onSave = vi.fn();
    render(<InlineEditable label="Title" value="Old" onSave={onSave} />);
    fireEvent.click(screen.getByTestId("inline-editable-display"));
    const input = screen.getByDisplayValue("Old");
    fireEvent.change(input, { target: { value: "New" } });
    fireEvent.blur(input);
    expect(onSave).toHaveBeenCalledWith("New");
  });

  it("does not call onSave when the value is unchanged", () => {
    const onSave = vi.fn();
    render(<InlineEditable label="Title" value="Same" onSave={onSave} />);
    fireEvent.click(screen.getByTestId("inline-editable-display"));
    fireEvent.blur(screen.getByDisplayValue("Same"));
    expect(onSave).not.toHaveBeenCalled();
  });

  it("cancels on Escape without calling onSave", () => {
    const onSave = vi.fn();
    render(<InlineEditable label="Title" value="Old" onSave={onSave} />);
    fireEvent.click(screen.getByTestId("inline-editable-display"));
    const input = screen.getByDisplayValue("Old");
    fireEvent.change(input, { target: { value: "New" } });
    fireEvent.keyDown(input, { key: "Escape" });
    expect(onSave).not.toHaveBeenCalled();
    expect(screen.getByText("Old")).toBeDefined();
  });

  it("does not enter edit mode when disabled", () => {
    render(<InlineEditable label="Title" value="Locked" onSave={() => {}} disabled />);
    fireEvent.click(screen.getByTestId("inline-editable-display"));
    expect(screen.queryByDisplayValue("Locked")).toBeNull();
  });

  it("renders a textarea for multiline and commits on Cmd/Ctrl+Enter", () => {
    const onSave = vi.fn();
    render(<InlineEditable label="Notes" value="Old notes" onSave={onSave} multiline />);
    fireEvent.click(screen.getByTestId("inline-editable-display"));
    const textarea = screen.getByDisplayValue("Old notes");
    fireEvent.change(textarea, { target: { value: "New notes" } });
    fireEvent.keyDown(textarea, { key: "Enter", ctrlKey: true });
    expect(onSave).toHaveBeenCalledWith("New notes");
  });
});
