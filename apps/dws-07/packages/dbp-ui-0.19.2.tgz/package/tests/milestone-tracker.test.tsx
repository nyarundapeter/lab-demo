import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { MilestoneTracker } from "../src/components/milestone-tracker.js";
import type { StageRow } from "../src/components/vertical-stage-tracker.js";

afterEach(() => { cleanup(); });

const MILESTONES: StageRow[] = [
  { id: "beta", label: "Beta release", status: "done", completedAt: "2026-06-20T00:00:00.000Z" },
  {
    id: "ga",
    label: "General availability",
    status: "active",
    dueAt: "2026-07-30T00:00:00.000Z",
    risk: "medium",
    note: "Two suites still red.",
  },
];

describe("MilestoneTracker", () => {
  it("renders every milestone with target/actual framing", () => {
    render(<MilestoneTracker milestones={MILESTONES} />);
    expect(screen.getByText("Beta release")).toBeDefined();
    expect(screen.getByText("General availability")).toBeDefined();
    expect(screen.getByText(/Actual/)).toBeDefined();
    expect(screen.getByText(/Target/)).toBeDefined();
  });

  it("surfaces slippage risk as a badge and tints the note", () => {
    render(<MilestoneTracker milestones={MILESTONES} />);
    expect(screen.getByText("medium risk")).toBeDefined();
    expect(screen.getByText("Two suites still red.")).toBeDefined();
  });

  it("is non-expandable — rows carry no toggle affordance", () => {
    render(<MilestoneTracker milestones={MILESTONES} />);
    expect(screen.queryByRole("button")).toBeNull();
  });
});
