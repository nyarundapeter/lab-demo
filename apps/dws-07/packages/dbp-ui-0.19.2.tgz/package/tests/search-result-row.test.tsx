import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { User } from "lucide-react";
import { Highlight, TypePill, StatusChip, MetaLine } from "../src/components/search-result-row.js";

afterEach(() => { cleanup(); });

describe("Highlight", () => {
  it("wraps matched terms in <mark>", () => {
    render(<Highlight text="Platform renewal Q3" terms={["renewal"]} />);
    const mark = screen.getByText("renewal");
    expect(mark.tagName).toBe("MARK");
  });

  it("renders plain text when no terms match", () => {
    render(<Highlight text="Nothing matches here" terms={["zzz"]} />);
    expect(screen.queryByText((_, el) => el?.tagName === "MARK")).toBeNull();
  });

  it("renders text unchanged when terms is empty", () => {
    render(<Highlight text="Plain text" terms={[]} />);
    expect(screen.getByText("Plain text")).toBeDefined();
  });
});

describe("TypePill", () => {
  it("renders the label and icon", () => {
    render(<TypePill icon={User} label="Contact" />);
    expect(screen.getByText("Contact")).toBeDefined();
  });
});

describe("StatusChip", () => {
  it("renders the default label for a status", () => {
    render(<StatusChip status="good" />);
    expect(screen.getByText("On track")).toBeDefined();
  });

  it("renders an overridden label", () => {
    render(<StatusChip status="warn" label="At risk deal" />);
    expect(screen.getByText("At risk deal")).toBeDefined();
  });
});

describe("MetaLine", () => {
  it("renders every item with separators", () => {
    render(<MetaLine items={[{ label: "Ava Okafor" }, { label: "2h ago" }, { label: "DEAL-4021", mono: true }]} />);
    expect(screen.getByText("Ava Okafor")).toBeDefined();
    expect(screen.getByText("2h ago")).toBeDefined();
    expect(screen.getByText("DEAL-4021")).toBeDefined();
  });

  it("renders nothing for an empty item list", () => {
    const { container } = render(<MetaLine items={[]} />);
    expect(container.firstChild).toBeNull();
  });
});
