import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { PwField } from "../src/components/pw-field.js";

afterEach(() => { cleanup(); });

describe("PwField", () => {
  it("renders as a password input by default", () => {
    render(<PwField value="secret" onChange={() => {}} aria-label="Password" />);
    expect(screen.getByLabelText("Password").getAttribute("type")).toBe("password");
  });

  it("toggles to a text input on show/hide click", () => {
    render(<PwField value="secret" onChange={() => {}} aria-label="Password" />);
    const toggle = screen.getByRole("button", { name: "Show password" });
    fireEvent.click(toggle);
    expect(screen.getByLabelText("Password").getAttribute("type")).toBe("text");
    fireEvent.click(screen.getByRole("button", { name: "Hide password" }));
    expect(screen.getByLabelText("Password").getAttribute("type")).toBe("password");
  });

  it("forwards value changes", () => {
    let value = "";
    render(<PwField value={value} onChange={(e) => { value = e.target.value; }} aria-label="Password" />);
    fireEvent.change(screen.getByLabelText("Password"), { target: { value: "abc" } });
    expect(value).toBe("abc");
  });
});
