import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { RootCauseCard, type RootCauseCardData } from "../src/components/root-cause-card.js";

afterEach(() => { cleanup(); });

const DATA: RootCauseCardData = {
  problem: "Checkout failures",
  hypotheses: [
    {
      cause: "Deploy regression",
      confidence: "high",
      support: ["Onset aligns with deploy"],
      contradicting: ["Some nodes unaffected"],
      validate: "Roll back one node and compare.",
      sources: [],
    },
    {
      cause: "Upstream outage",
      confidence: "low",
      support: ["Brief blip observed"],
      contradicting: ["Blip is too short"],
      validate: "Cross-reference incident logs.",
      sources: [],
    },
  ],
};

describe("RootCauseCard", () => {
  it("renders every hypothesis and marks the first as most supported", () => {
    render(<RootCauseCard data={DATA} />);
    expect(screen.getByText("Deploy regression")).toBeDefined();
    expect(screen.getByText("Upstream outage")).toBeDefined();
    expect(screen.getByText("Most supported")).toBeDefined();
  });

  it("renders the advisory footer, not a confirmed-cause claim", () => {
    render(<RootCauseCard data={DATA} />);
    expect(screen.getByText(/not a confirmed cause/)).toBeDefined();
  });

  it("calls onCreateInvestigation with the hypothesis index", () => {
    const onCreateInvestigation = vi.fn();
    render(<RootCauseCard data={DATA} onCreateInvestigation={onCreateInvestigation} />);
    const buttons = screen.getAllByRole("button", { name: "Create investigation" });
    fireEvent.click(buttons[1]!);
    expect(onCreateInvestigation).toHaveBeenCalledWith(1);
  });
});
