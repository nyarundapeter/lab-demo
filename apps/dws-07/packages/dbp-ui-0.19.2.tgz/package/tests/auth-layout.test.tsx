import { describe, it, expect, afterEach } from "vitest"
import { render, screen, cleanup } from "@testing-library/react"

afterEach(() => {
  cleanup()
})

import { AuthLayout } from "../src/components/auth-layout.js"

describe("AuthLayout", () => {
  it("renders the headline", () => {
    render(<AuthLayout headline="Join Northwind Labs"><div>card</div></AuthLayout>)
    expect(screen.getByRole("heading", { name: "Join Northwind Labs" })).toBeDefined()
  })

  it("renders children inside the credential card", () => {
    render(<AuthLayout><button>Accept</button></AuthLayout>)
    expect(screen.getByRole("button", { name: "Accept" })).toBeDefined()
  })

  it("renders subtitle when provided", () => {
    render(<AuthLayout subtitle="Set up your account">{null}</AuthLayout>)
    expect(screen.getByText("Set up your account")).toBeDefined()
  })

  it("renders feature bullets when provided", () => {
    render(<AuthLayout features={["SSO", "Audit logs"]}>{null}</AuthLayout>)
    expect(screen.getByText("SSO")).toBeDefined()
    expect(screen.getByText("Audit logs")).toBeDefined()
  })

  it("does not render a quote block when omitted", () => {
    render(<AuthLayout>{null}</AuthLayout>)
    expect(screen.queryByText(/—/)).toBeNull()
  })

  it("renders the quote and attribution when provided", () => {
    render(
      <AuthLayout quote={{ text: "It just works.", attribution: "A happy admin" }}>
        {null}
      </AuthLayout>,
    )
    expect(screen.getByText(/It just works\./)).toBeDefined()
    expect(screen.getByText("A happy admin")).toBeDefined()
  })
})
