import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";

afterEach(() => { cleanup(); });
import userEvent from "@testing-library/user-event";
import { Button } from "../src/components/button.js";

describe("Button", () => {
  it("renders with label text", () => {
    render(<Button>Save</Button>);
    expect(screen.getByRole("button", { name: "Save" })).toBeDefined();
  });

  it("is focusable and activatable by keyboard", async () => {
    const user = userEvent.setup();
    let clicked = false;
    render(<Button onClick={() => { clicked = true; }}>Act</Button>);
    const btn = screen.getByRole("button", { name: "Act" });
    btn.focus();
    await user.keyboard("{Enter}");
    expect(clicked).toBe(true);
  });

  it("applies variant classes", () => {
    render(<Button variant="outline" data-testid="btn">Outline</Button>);
    const btn = screen.getByTestId("btn");
    expect(btn.className).toContain("border");
  });

  it("is disabled when disabled prop is set", () => {
    render(<Button disabled>Disabled</Button>);
    const btn = screen.getByRole("button", { name: "Disabled" });
    expect((btn as HTMLButtonElement).disabled).toBe(true);
  });

  it("renders as Slot when asChild is true", () => {
    render(
      <Button asChild>
        <a href="#">Link Button</a>
      </Button>,
    );
    expect(screen.getByRole("link", { name: "Link Button" })).toBeDefined();
  });
});
