import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { FormField } from "../src/components/form-field.js";
import { Input } from "../src/components/input.js";

afterEach(() => { cleanup(); });

describe("FormField", () => {
  it("renders label and child input", () => {
    render(
      <FormField label="Email">
        <Input placeholder="you@example.com" />
      </FormField>
    );
    expect(screen.getByText("Email")).toBeDefined();
    expect(screen.getByPlaceholderText("you@example.com")).toBeDefined();
  });

  it("shows error message with role=alert", () => {
    render(
      <FormField label="Name" error="Name is required">
        <Input />
      </FormField>
    );
    expect(screen.getByRole("alert")).toBeDefined();
    expect(screen.getByText("Name is required")).toBeDefined();
  });

  it("shows helper text when no error", () => {
    render(
      <FormField label="Password" helperText="At least 8 characters">
        <Input type="password" />
      </FormField>
    );
    expect(screen.getByText("At least 8 characters")).toBeDefined();
  });

  it("links label htmlFor to input id", () => {
    render(
      <FormField label="Username">
        <Input />
      </FormField>
    );
    const label = screen.getByText("Username") as HTMLLabelElement;
    const input = screen.getByRole("textbox") as HTMLInputElement;
    expect(label.htmlFor).toBe(input.id);
  });

  it("required field shows an aria-hidden asterisk plus a screen-reader-only '(required)' suffix", () => {
    render(
      <FormField label="Full name" required>
        <Input />
      </FormField>
    );
    expect(screen.getByText("*").getAttribute("aria-hidden")).toBe("true");
    expect(screen.getByText("(required)")).toBeDefined();
  });

  it("optional field shows an explicit '(optional)' label suffix", () => {
    render(
      <FormField label="Middle name" optional>
        <Input />
      </FormField>
    );
    expect(screen.getByText("(optional)")).toBeDefined();
  });

  it("required takes precedence when both required and optional are set", () => {
    render(
      <FormField label="Edge case" required optional>
        <Input />
      </FormField>
    );
    expect(screen.getByText("(required)")).toBeDefined();
    expect(screen.queryByText("(optional)")).toBeNull();
  });

  it("defaults data-field-state to 'default'", () => {
    const { container } = render(
      <FormField label="Name">
        <Input />
      </FormField>
    );
    expect(container.querySelector("[data-field-state]")?.getAttribute("data-field-state")).toBe("default");
  });

  it("resolves data-field-state to 'error' when an error message is set, regardless of the state prop", () => {
    const { container } = render(
      <FormField label="Name" error="Required" state="warning">
        <Input />
      </FormField>
    );
    expect(container.querySelector("[data-field-state]")?.getAttribute("data-field-state")).toBe("error");
  });

  it("threads a warning/success state prop through to data-field-state (visual seam only, no styling yet)", () => {
    const { container: warningContainer } = render(
      <FormField label="Account name" state="warning">
        <Input />
      </FormField>
    );
    expect(warningContainer.querySelector("[data-field-state]")?.getAttribute("data-field-state")).toBe("warning");

    const { container: successContainer } = render(
      <FormField label="Username" state="success">
        <Input />
      </FormField>
    );
    expect(successContainer.querySelector("[data-field-state]")?.getAttribute("data-field-state")).toBe("success");
  });
});
