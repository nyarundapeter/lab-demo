import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { DashboardDensityProvider, useDashboardDensity } from "../src/components/dashboard-density.js";

afterEach(() => { cleanup(); });

function Probe() {
  return <span data-testid="density">{useDashboardDensity()}</span>;
}

describe("DashboardDensityProvider", () => {
  it("defaults to standard density outside any provider", () => {
    render(<Probe />);
    expect(screen.getByTestId("density").textContent).toBe("standard");
  });

  it("provides the density value to descendants", () => {
    render(
      <DashboardDensityProvider density="operational">
        <Probe />
      </DashboardDensityProvider>,
    );
    expect(screen.getByTestId("density").textContent).toBe("operational");
  });

  it("stamps the data-density DOM attribute for the ported .dash[data-density] CSS rules", () => {
    render(
      <DashboardDensityProvider density="executive" data-testid="wrapper">
        <span>content</span>
      </DashboardDensityProvider>,
    );
    expect(screen.getByTestId("wrapper").getAttribute("data-density")).toBe("executive");
  });
});
