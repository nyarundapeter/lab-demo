import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ConfirmationPreview, type ConfirmationPreviewField } from "../src/components/confirmation-preview.js";

afterEach(() => { cleanup(); });

const FIELDS: ConfirmationPreviewField[] = [
  { label: "Status", before: "Open", after: "Closed" },
];

describe("ConfirmationPreview", () => {
  it("does not render when closed", () => {
    render(
      <ConfirmationPreview open={false} onOpenChange={vi.fn()} fields={FIELDS} onConfirm={vi.fn()} />
    );
    expect(screen.queryByText("Review AI-suggested change")).toBeNull();
  });

  it("renders the default title and before/after diff for each field when open", () => {
    render(
      <ConfirmationPreview open onOpenChange={vi.fn()} fields={FIELDS} onConfirm={vi.fn()} />
    );
    expect(screen.getByText("Review AI-suggested change")).toBeDefined();
    expect(screen.getByText("Status")).toBeDefined();
    expect(screen.getByLabelText("Before: Open")).toBeDefined();
    expect(screen.getByLabelText("After: Closed")).toBeDefined();
  });

  it("renders a custom title and description", () => {
    render(
      <ConfirmationPreview
        open
        onOpenChange={vi.fn()}
        title="Apply proposed change?"
        description="Review before applying"
        fields={FIELDS}
        onConfirm={vi.fn()}
      />
    );
    expect(screen.getByText("Apply proposed change?")).toBeDefined();
    expect(screen.getByText("Review before applying")).toBeDefined();
  });

  it("calls onConfirm when the confirm button is clicked", async () => {
    const user = userEvent.setup();
    const onConfirm = vi.fn();
    render(
      <ConfirmationPreview open onOpenChange={vi.fn()} fields={FIELDS} onConfirm={onConfirm} />
    );
    await user.click(screen.getByRole("button", { name: "Confirm & apply" }));
    expect(onConfirm).toHaveBeenCalledTimes(1);
  });

  it("calls onCancel and onOpenChange(false) when cancel is clicked", async () => {
    const user = userEvent.setup();
    const onCancel = vi.fn();
    const onOpenChange = vi.fn();
    render(
      <ConfirmationPreview
        open
        onOpenChange={onOpenChange}
        fields={FIELDS}
        onConfirm={vi.fn()}
        onCancel={onCancel}
      />
    );
    await user.click(screen.getByRole("button", { name: "Cancel" }));
    expect(onCancel).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("renders a custom confirm label", () => {
    render(
      <ConfirmationPreview open onOpenChange={vi.fn()} fields={FIELDS} onConfirm={vi.fn()} confirmLabel="Apply now" />
    );
    expect(screen.getByRole("button", { name: "Apply now" })).toBeDefined();
  });
});
