import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { AutofillLauncher } from "../src/components/autofill-launcher.js";

afterEach(() => { cleanup(); });

describe("AutofillLauncher", () => {
  it("renders every source picker and dispatches onStart", () => {
    const onStart = vi.fn();
    render(<AutofillLauncher onStart={onStart} />);
    expect(screen.getByText("Upload a document")).toBeDefined();
    expect(screen.getByText("From email / message")).toBeDefined();
    fireEvent.click(screen.getByRole("button", { name: /Upload a document/ }));
    expect(onStart).toHaveBeenCalledOnce();
  });
});
