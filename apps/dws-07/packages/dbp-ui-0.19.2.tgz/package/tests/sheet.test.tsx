import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "../src/components/sheet.js";

afterEach(() => {
  cleanup();
});

describe("SheetContent — hideClose", () => {
  it("renders the default close button when hideClose is not set", async () => {
    const user = userEvent.setup();
    render(
      <Sheet>
        <SheetTrigger>Open</SheetTrigger>
        <SheetContent>
          <SheetTitle>My sheet</SheetTitle>
        </SheetContent>
      </Sheet>
    );
    await user.click(screen.getByText("Open"));
    expect(screen.getByRole("button", { name: "Close" })).toBeDefined();
  });

  it("omits the default close button when hideClose is true", async () => {
    const user = userEvent.setup();
    render(
      <Sheet>
        <SheetTrigger>Open</SheetTrigger>
        <SheetContent hideClose>
          <SheetTitle>My sheet</SheetTitle>
        </SheetContent>
      </Sheet>
    );
    await user.click(screen.getByText("Open"));
    expect(screen.queryByRole("button", { name: "Close" })).toBeNull();
  });
});

function fireDrag(handle: Element, deltaY: number) {
  handle.dispatchEvent(
    new (window as unknown as { PointerEvent: typeof MouseEvent }).PointerEvent("pointerdown", {
      bubbles: true,
      clientY: 0,
    } as PointerEventInit),
  );
  window.dispatchEvent(
    new (window as unknown as { PointerEvent: typeof MouseEvent }).PointerEvent("pointermove", {
      bubbles: true,
      clientY: deltaY,
    } as PointerEventInit),
  );
  window.dispatchEvent(
    new (window as unknown as { PointerEvent: typeof MouseEvent }).PointerEvent("pointerup", {
      bubbles: true,
      clientY: deltaY,
    } as PointerEventInit),
  );
}

describe("SheetContent — mobile swipe-to-dismiss (OVL-11)", () => {
  it("closes on a large downward drag of the grip handle when swipeToDismiss is set", async () => {
    render(
      <Sheet defaultOpen>
        <SheetContent side="bottom" detent="half" swipeToDismiss data-testid="sheet-content">
          <SheetHeader>
            <SheetTitle>Filters</SheetTitle>
          </SheetHeader>
        </SheetContent>
      </Sheet>,
    );

    expect(screen.getByText("Filters")).toBeDefined();
    const grip = document.querySelector('[aria-hidden="true"].cursor-grab');
    expect(grip).not.toBeNull();

    fireDrag(grip as Element, 200);

    await waitFor(() => expect(screen.queryByText("Filters")).toBeNull());
  });

  it("does not close on swipe when dismissable is false", () => {
    render(
      <Sheet defaultOpen>
        <SheetContent side="bottom" detent="half" swipeToDismiss dismissable={false}>
          <SheetHeader>
            <SheetTitle>New request</SheetTitle>
          </SheetHeader>
        </SheetContent>
      </Sheet>,
    );

    const grip = document.querySelector('[aria-hidden="true"].cursor-grab');
    expect(grip).not.toBeNull();

    fireDrag(grip as Element, 200);

    expect(screen.getByText("New request")).toBeDefined();
  });

  it("does not render a grabbable grip when swipeToDismiss is not set", () => {
    render(
      <Sheet defaultOpen>
        <SheetContent side="bottom" detent="half">
          <SheetHeader>
            <SheetTitle>Static sheet</SheetTitle>
          </SheetHeader>
        </SheetContent>
      </Sheet>,
    );

    expect(document.querySelector('[aria-hidden="true"].cursor-grab')).toBeNull();
  });
});
