import * as React from 'react'
import { describe, it, expect, afterEach, vi } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { PageHeader } from '../src/components/page-header.js'

afterEach(cleanup)

describe('PageHeader', () => {
  it('renders the title as an h1', () => {
    render(<PageHeader title="My Dashboard" />)
    expect(screen.getByRole('heading', { level: 1, name: 'My Dashboard' })).toBeTruthy()
  })

  it('title is rendered sr-only, not visibly (Amendment D-2 — shell owns page identity)', () => {
    render(<PageHeader title="Reports" />)
    const heading = screen.getByRole('heading', { level: 1, name: 'Reports' })
    // sr-only clips visually but stays in the DOM/a11y tree — jsdom can't assert
    // computed visibility, so this checks the class that does the clipping.
    expect(heading.className).toContain('sr-only')
  })

  it('subtitle is accepted but no longer rendered (deprecated, Amendment D-2)', () => {
    render(<PageHeader title="Reports" subtitle="Last 30 days" />)
    expect(screen.queryByText('Last 30 days')).toBeNull()
  })

  it('breadcrumb is not rendered unless showBreadcrumb is true (Amendment D-2 default-off)', () => {
    render(<PageHeader title="Cases" breadcrumb={[{ label: 'Workspace' }, { label: 'Cases' }]} />)
    expect(screen.queryByRole('navigation', { name: 'Breadcrumb' })).toBeNull()
  })

  it('renders breadcrumb when showBreadcrumb is true (legacy no-chrome layout path)', () => {
    render(
      <PageHeader
        title="Cases"
        breadcrumb={[{ label: 'Workspace' }, { label: 'Cases' }]}
        showBreadcrumb
      />,
    )
    expect(screen.getByRole('navigation', { name: 'Breadcrumb' })).toBeTruthy()
  })

  it('renders action button and fires onClick', async () => {
    const onClick = vi.fn()
    render(<PageHeader title="Tasks" action={{ label: 'Create Task', onClick }} />)
    const btn = screen.getByRole('button', { name: 'Create Task' })
    await userEvent.setup().click(btn)
    expect(onClick).toHaveBeenCalledOnce()
  })

  it('does not render a button when no action provided', () => {
    render(<PageHeader title="Home" />)
    expect(screen.queryByRole('button')).toBeNull()
  })

  it('renders actions ReactNode when no action shorthand provided', () => {
    render(<PageHeader title="Home" actions={<button>Custom</button>} />)
    expect(screen.getByRole('button', { name: 'Custom' })).toBeTruthy()
  })

  it('root element has data-page-title attribute', () => {
    const { container } = render(<PageHeader title="Test" />)
    expect(container.querySelector('[data-page-title]')).toBeTruthy()
  })
})
