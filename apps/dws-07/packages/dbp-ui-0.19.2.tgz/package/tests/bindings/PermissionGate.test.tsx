import { describe, it, expect, afterEach } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import { createElement } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  configureRbacClient,
  resetRbacClient,
} from "@dbp/ps-rbac/client";
import { PermissionGate } from "../../src/bindings/PermissionGate.js";

const BASE = "http://test.local/api/platform/rbac";

// CASL packRules produces tuples: [action, subject] — NOT plain objects.
// See @casl/ability/extra packRules output.
function makeRulesFetch(actions: string[]) {
  const rules = actions.map((action): [string, string] => [action, "all"]);
  return (): Promise<Response> =>
    Promise.resolve(
      new Response(
        JSON.stringify({ rules, tenantId: "demo", roles: ["admin"] }),
        { status: 200, headers: { "content-type": "application/json" } },
      ),
    );
}

function wrapper() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client: qc }, children);
}

afterEach(() => {
  cleanup();
  resetRbacClient();
});

describe("PermissionGate", () => {
  it("renders children when permission is allowed", async () => {
    configureRbacClient({ baseUrl: BASE, fetch: makeRulesFetch(["invoice.approve"]) });

    render(
      <PermissionGate action="invoice.approve">
        <span data-testid="allowed-child">Approve</span>
      </PermissionGate>,
      { wrapper: wrapper() },
    );

    await waitFor(() => {
      expect(screen.getByTestId("allowed-child")).toBeDefined();
    });
  });

  it("renders fallback when permission is denied", async () => {
    configureRbacClient({ baseUrl: BASE, fetch: makeRulesFetch([]) });

    render(
      <PermissionGate action="invoice.approve" fallback={<span data-testid="denied">Access denied</span>}>
        <span data-testid="allowed-child">Approve</span>
      </PermissionGate>,
      { wrapper: wrapper() },
    );

    await waitFor(() => {
      expect(screen.getByTestId("denied")).toBeDefined();
    });
    expect(screen.queryByTestId("allowed-child")).toBeNull();
  });

  it("renders nothing (no fallback) when denied and fallback omitted", async () => {
    configureRbacClient({ baseUrl: BASE, fetch: makeRulesFetch([]) });

    render(
      <PermissionGate action="invoice.approve">
        <span data-testid="allowed-child">Approve</span>
      </PermissionGate>,
      { wrapper: wrapper() },
    );

    // Allow time for rules to load
    await new Promise((r) => setTimeout(r, 50));
    expect(screen.queryByTestId("allowed-child")).toBeNull();
  });

  it("forwards the resource prop correctly", async () => {
    configureRbacClient({ baseUrl: BASE, fetch: makeRulesFetch(["read"]) });

    render(
      <PermissionGate action="read" resource="invoice">
        <span data-testid="resource-child">Read invoices</span>
      </PermissionGate>,
      { wrapper: wrapper() },
    );

    await waitFor(() => {
      expect(screen.getByTestId("resource-child")).toBeDefined();
    });
  });
});
