import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { ProvTag } from "../src/components/prov-tag.js";
import { CtrlBadge } from "../src/components/ctrl-badge.js";
import { AiConfidence } from "../src/components/ai-confidence.js";
import { AiMark } from "../src/components/ai-mark.js";

afterEach(() => { cleanup(); });

describe("ProvTag", () => {
  it("renders the default label for a provenance value", () => {
    render(<ProvTag provenance="ai" />);
    expect(screen.getByText("AI interpretation")).toBeDefined();
  });

  it("renders custom children over the default label", () => {
    render(<ProvTag provenance="human">Verified by Jordan</ProvTag>);
    expect(screen.getByText("Verified by Jordan")).toBeDefined();
  });

  it.each(["source", "calc", "ai", "predict", "human", "auto"] as const)(
    "renders the %s hue without throwing",
    (provenance) => {
      render(<ProvTag provenance={provenance} data-testid={`prov-${provenance}`} />);
      expect(screen.getByTestId(`prov-${provenance}`)).toBeDefined();
    }
  );
});

describe("CtrlBadge", () => {
  it("renders the control-level label", () => {
    render(<CtrlBadge level={2} />);
    expect(screen.getByText("Recommend")).toBeDefined();
  });

  it("shows the L{n} prefix by default", () => {
    render(<CtrlBadge level={4} />);
    expect(screen.getByText("L4")).toBeDefined();
  });

  it("hides the numeric prefix when showNum is false", () => {
    render(<CtrlBadge level={1} showNum={false} />);
    expect(screen.queryByText("L1")).toBeNull();
  });

  it("renders the humanDecisionOnly qualifier as an orthogonal flag, not a 5th rung", () => {
    render(<CtrlBadge level={1} humanDecisionOnly />);
    expect(screen.getByText("Human decision only")).toBeDefined();
    expect(screen.getByText("Inform")).toBeDefined();
  });

  it("omits the humanDecisionOnly qualifier when false", () => {
    render(<CtrlBadge level={3} humanDecisionOnly={false} />);
    expect(screen.queryByText("Human decision only")).toBeNull();
  });
});

describe("AiConfidence", () => {
  it("renders the confidence label", () => {
    render(<AiConfidence level="high" />);
    expect(screen.getByText("High confidence")).toBeDefined();
  });

  it("renders inline without a note trigger", () => {
    render(<AiConfidence level="medium" inline note="should be ignored in inline mode" />);
    expect(screen.getByText("Medium confidence")).toBeDefined();
    expect(screen.queryByRole("button")).toBeNull();
  });

  it("renders a button when a note is provided in non-inline mode", () => {
    render(<AiConfidence level="low" note="Small sample size" />);
    expect(screen.getByRole("button")).toBeDefined();
  });

  it("renders insufficient confidence without a meter", () => {
    render(<AiConfidence level="insufficient" />);
    expect(screen.getByText("Insufficient information")).toBeDefined();
  });
});

describe("AiMark", () => {
  it("renders the Bot glyph container", () => {
    render(<AiMark data-testid="ai-mark" />);
    expect(screen.getByTestId("ai-mark")).toBeDefined();
  });
});
