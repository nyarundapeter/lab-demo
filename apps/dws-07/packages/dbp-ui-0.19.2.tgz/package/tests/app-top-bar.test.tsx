import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { AppTopBar } from "../src/components/app-top-bar.js";
import type { TopBarConfig } from "@dbp/contracts";

afterEach(() => { cleanup(); });

const baseConfig: TopBarConfig = {
  appName: "DBP App",
  logoAlt: "DBP",
  actions: [],
  showSearch: false,
  showNotifications: false,
  showUser: false,
};

describe("AppTopBar", () => {
  // Shell v3 anatomy (N27 ruling): the app lockup moved to the sidebar
  // header (SidebarIdentity) — AppTopBar no longer renders any lockup text
  // or logo image regardless of `config.appName` / `config.logoSrc`.
  it("does not render the app name as lockup text", () => {
    render(<AppTopBar config={baseConfig} />);
    expect(screen.queryByText("DBP App")).toBeNull();
  });

  it("does not render a logo image even when logoSrc is provided", () => {
    const config: TopBarConfig = { ...baseConfig, logoSrc: "/logo.png", logoAlt: "Logo" };
    render(<AppTopBar config={config} />);
    expect(screen.queryByRole("img")).toBeNull();
  });

  it("renders the breadcrumb slot flush left with no lockup preceding it", () => {
    render(<AppTopBar config={baseConfig} breadcrumbSlot={<span>Records / Deals</span>} />);
    expect(screen.getByText("Records / Deals")).toBeDefined();
  });

  it("renders notification slot when showNotifications=true", () => {
    const config: TopBarConfig = { ...baseConfig, showNotifications: true };
    render(
      <AppTopBar config={config} notificationSlot={<button>Bell</button>} />
    );
    expect(screen.getByRole("button", { name: "Bell" })).toBeDefined();
  });

  it("does NOT render notification slot when showNotifications=false", () => {
    render(
      <AppTopBar config={baseConfig} notificationSlot={<button>Bell</button>} />
    );
    expect(screen.queryByRole("button", { name: "Bell" })).toBeNull();
  });

  it("renders search slot when showSearch=true", () => {
    const config: TopBarConfig = { ...baseConfig, showSearch: true };
    render(
      <AppTopBar config={config} searchSlot={<input placeholder="Search" />} />
    );
    expect(screen.getByPlaceholderText("Search")).toBeDefined();
  });
});
