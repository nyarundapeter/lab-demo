import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AdminSettingsForm } from "../src/components/admin-settings-form.js";
import type { AdminSettingsFormField } from "../src/components/admin-settings-form.js";

afterEach(() => { cleanup(); });

const FIELDS: AdminSettingsFormField[] = [
  { name: "org-name", label: "Organisation name", fieldType: "text", required: true },
  { name: "billing-email", label: "Billing email", fieldType: "email" },
  { name: "log-admin-actions", label: "Log administrative actions", fieldType: "switch", defaultChecked: true },
];

function submitButton(formId: string) {
  return <button type="submit" form={formId}>Save</button>;
}

describe("AdminSettingsForm", () => {
  it("renders a field for each config entry", () => {
    render(<AdminSettingsForm formId="test-form" fields={FIELDS} />);
    expect(screen.getByLabelText("Organisation name", { exact: false })).toBeDefined();
    expect(screen.getByLabelText("Billing email")).toBeDefined();
    expect(screen.getByLabelText("Log administrative actions")).toBeDefined();
  });

  it("shows a validation error when a required field is left empty", async () => {
    const user = userEvent.setup();
    render(
      <>
        <AdminSettingsForm formId="test-form" fields={FIELDS} />
        {submitButton("test-form")}
      </>,
    );
    await user.click(screen.getByRole("button", { name: "Save" }));
    await waitFor(() => {
      expect(screen.getByRole("alert").textContent).toBe("Organisation name is required");
    });
  });

  it("calls onSubmit and dispatches a CustomEvent on valid submit", async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn();
    const eventListener = vi.fn();
    document.addEventListener("dbp:admin-settings:submit", eventListener);

    render(
      <>
        <AdminSettingsForm formId="test-form" fields={FIELDS} onSubmit={onSubmit} />
        {submitButton("test-form")}
      </>,
    );

    await user.type(screen.getByLabelText("Organisation name", { exact: false }), "Acme Co");
    await user.click(screen.getByRole("button", { name: "Save" }));

    await waitFor(() => {
      expect(onSubmit).toHaveBeenCalledWith(
        expect.objectContaining({ "org-name": "Acme Co", "log-admin-actions": true }),
      );
    });
    expect(eventListener).toHaveBeenCalledTimes(1);
    const call = eventListener.mock.calls[0];
    const event = call?.[0] as CustomEvent;
    expect(event.detail).toMatchObject({ formId: "test-form" });

    document.removeEventListener("dbp:admin-settings:submit", eventListener);
  });
});
