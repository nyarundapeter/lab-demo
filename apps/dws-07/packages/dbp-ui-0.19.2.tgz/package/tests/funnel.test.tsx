import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Funnel } from "../src/components/funnel.js";

afterEach(() => { cleanup(); });

describe("Funnel", () => {
  it("renders one stage row per entry with its formatted value", () => {
    render(
      <Funnel
        stages={[
          { label: "Signed up", value: 1000 },
          { label: "Activated", value: 400 },
        ]}
      />,
    );
    expect(screen.getByTestId("funnel-stage-0").textContent).toContain("Signed up");
    expect(screen.getByTestId("funnel-stage-0").textContent).toContain("1,000");
  });

  it("computes stage-over-stage conversion percentage for stages after the first", () => {
    render(
      <Funnel
        stages={[
          { label: "Viewed", value: 200 },
          { label: "Converted", value: 50 },
        ]}
      />,
    );
    expect(screen.getByTestId("funnel-stage-1").textContent).toContain("25%");
  });

  it("does not show a conversion percentage on the first stage", () => {
    render(<Funnel stages={[{ label: "Viewed", value: 200 }]} />);
    expect(screen.getByTestId("funnel-stage-0").textContent).not.toContain("%");
  });
});
