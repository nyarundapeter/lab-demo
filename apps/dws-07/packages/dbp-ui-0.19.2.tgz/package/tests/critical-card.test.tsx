import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { CriticalCard, type CriticalCardField } from "../src/components/critical-card.js";

afterEach(() => { cleanup(); });

const FIELDS: CriticalCardField[] = [
  { label: "Impact", value: "All regions" },
  { label: "Owner", value: "Platform team" },
];

describe("CriticalCard", () => {
  it("renders the record, title, message, and field grid", () => {
    render(
      <CriticalCard record="Sync Service" title="Sync failure" message="Sync has stopped." fields={FIELDS} />
    );
    expect(screen.getByText(/Sync Service/)).toBeDefined();
    expect(screen.getByText("Sync failure")).toBeDefined();
    expect(screen.getByText("Sync has stopped.")).toBeDefined();
    expect(screen.getByText("Impact")).toBeDefined();
    expect(screen.getByText("All regions")).toBeDefined();
  });

  it("defaults to the 'investigating' step and marks it current", () => {
    render(
      <CriticalCard record="Sync Service" title="Sync failure" message="Sync has stopped." fields={FIELDS} />
    );
    const step = screen.getByText("Investigating").closest("button");
    expect(step?.getAttribute("aria-current")).toBe("step");
  });

  it("advances the lifecycle step and calls onStatusChange when a step is clicked", async () => {
    const user = userEvent.setup();
    const onStatusChange = vi.fn();
    render(
      <CriticalCard
        record="Sync Service"
        title="Sync failure"
        message="Sync has stopped."
        fields={FIELDS}
        onStatusChange={onStatusChange}
      />
    );
    await user.click(screen.getByText("Mitigated"));
    expect(onStatusChange).toHaveBeenCalledWith("mitigated");
    expect(screen.getByText("Mitigated").closest("button")?.getAttribute("aria-current")).toBe("step");
  });

  it("only renders action buttons whose callback is provided", () => {
    render(
      <CriticalCard
        record="Sync Service"
        title="Sync failure"
        message="Sync has stopped."
        fields={FIELDS}
        onAck={vi.fn()}
      />
    );
    expect(screen.getByRole("button", { name: "Acknowledge" })).toBeDefined();
    expect(screen.queryByRole("button", { name: "Open incident" })).toBeNull();
    expect(screen.queryByRole("button", { name: "Mark false positive" })).toBeNull();
  });

  it("calls onAck and onMarkFalsePositive when their buttons are clicked", async () => {
    const user = userEvent.setup();
    const onAck = vi.fn();
    const onMarkFalsePositive = vi.fn();
    render(
      <CriticalCard
        record="Sync Service"
        title="Sync failure"
        message="Sync has stopped."
        fields={FIELDS}
        onAck={onAck}
        onMarkFalsePositive={onMarkFalsePositive}
      />
    );
    await user.click(screen.getByRole("button", { name: "Acknowledge" }));
    expect(onAck).toHaveBeenCalledTimes(1);
    await user.click(screen.getByRole("button", { name: "Mark false positive" }));
    expect(onMarkFalsePositive).toHaveBeenCalledTimes(1);
  });
});
