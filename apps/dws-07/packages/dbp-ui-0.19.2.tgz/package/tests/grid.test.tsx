import * as React from "react"
import { describe, it, expect, afterEach } from "vitest"
import { render, cleanup } from "@testing-library/react"
import { Grid, Col } from "../src/components/grid.js"

afterEach(cleanup)

describe("Grid / Col — canonical 12-column grid", () => {
  it("Grid is a 12-column grid with the gutter token", () => {
    const { container } = render(<Grid data-testid="g"><div /></Grid>)
    const el = container.querySelector('[data-testid="g"]') as HTMLElement
    expect(el.className).toContain("grid-cols-12")
    expect(el.className).toContain("gap-[var(--grid-gutter)]")
  })

  it("Col is full-width on mobile and spans N at md+", () => {
    const { container } = render(<Col span={4} data-testid="c">x</Col>)
    const el = container.querySelector('[data-testid="c"]') as HTMLElement
    expect(el.className).toContain("col-span-12")
    expect(el.className).toContain("md:col-span-4")
  })

  it("Col defaults to full width (span 12)", () => {
    const { container } = render(<Col data-testid="c">x</Col>)
    const el = container.querySelector('[data-testid="c"]') as HTMLElement
    expect(el.className).toContain("md:col-span-12")
  })

  it("Grid renders as a custom element when `as` is given", () => {
    const { container } = render(<Grid as="ul"><li /></Grid>)
    expect(container.querySelector("ul")).toBeTruthy()
  })
})
