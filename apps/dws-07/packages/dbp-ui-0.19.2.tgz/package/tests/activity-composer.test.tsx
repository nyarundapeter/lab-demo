import * as React from "react";
import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ActivityComposer } from "../src/components/activity-composer.js";
import type { ActivityDraft, ActivityMentionUser, ActivityTimelineConfig } from "../src/schemas/activity.js";

afterEach(() => { cleanup(); });

const MENTION_CANDIDATES: ActivityMentionUser[] = [
  { id: "u1", name: "Priya Nair" },
  { id: "u2", name: "Tomas Berg" },
];

function config(overrides: Partial<ActivityTimelineConfig> = {}): ActivityTimelineConfig {
  return { activityTypes: {}, mentions: false, tags: false, attachments: false, ...overrides };
}

describe("ActivityComposer — Tiptap composer (ADR-0048)", () => {
  it("disables Save until the note is dirty", async () => {
    const user = userEvent.setup();
    render(<ActivityComposer config={config()} onSave={vi.fn()} />);
    const save = screen.getByRole("button", { name: /save note/i });
    expect(save).toHaveProperty("disabled", true);
    await user.type(screen.getByRole("textbox", { name: /activity note/i }), "Hello");
    await waitFor(() => expect(save).toHaveProperty("disabled", false));
  });

  it("calls onSave with body(JSON)/plainText/tags and resets the editor", async () => {
    const user = userEvent.setup();
    let saved: ActivityDraft | undefined;
    const onSave = vi.fn((draft: ActivityDraft) => { saved = draft; });
    render(<ActivityComposer config={config()} onSave={onSave} />);
    const textbox = screen.getByRole("textbox", { name: /activity note/i });
    await user.type(textbox, "Champion confirmed budget.");
    await user.click(screen.getByRole("button", { name: /save note/i }));

    expect(onSave).toHaveBeenCalledTimes(1);
    expect(saved?.plainText).toBe("Champion confirmed budget.");
    expect(saved?.tags).toEqual([]);
    expect(saved?.mentionedUserIds).toEqual([]);
    // body is the serialized Tiptap doc — round-trips as JSON containing the plain text.
    const doc = JSON.parse(saved!.body) as { type: string };
    expect(doc.type).toBe("doc");
    expect(JSON.stringify(doc)).toContain("Champion confirmed budget.");

    // Editor clears after save.
    await waitFor(() => expect(textbox.textContent).toBe(""));
  });

  it("round-trips bold formatting: body JSON carries the mark, plainText strips it", async () => {
    const user = userEvent.setup();
    let saved: ActivityDraft | undefined;
    const onSave = vi.fn((draft: ActivityDraft) => { saved = draft; });
    render(<ActivityComposer config={config()} onSave={onSave} />);
    const textbox = screen.getByRole("textbox", { name: /activity note/i });
    await user.click(textbox);
    await user.click(screen.getByRole("button", { name: "Bold" }));
    await user.type(textbox, "urgent");
    await user.click(screen.getByRole("button", { name: /save note/i }));

    expect(saved?.plainText).toBe("urgent");
    const doc = JSON.parse(saved!.body) as { content: Array<{ content?: Array<{ marks?: Array<{ type: string }> }> }> };
    const marks = doc.content[0]?.content?.[0]?.marks ?? [];
    expect(marks.some((m) => m.type === "bold")).toBe(true);
  });

  it("does not render the mention picker or attachment affordance when config-gated off", () => {
    render(<ActivityComposer config={config()} onSave={vi.fn()} />);
    expect(screen.queryByRole("listbox", { name: /mention a teammate/i })).toBeNull();
    expect(screen.queryByRole("button", { name: /attach a file/i })).toBeNull();
  });

  it("renders a disabled attach affordance when attachments is config-gated on", () => {
    render(<ActivityComposer config={config({ attachments: true })} onSave={vi.fn()} />);
    const attachBtn = screen.getByRole("button", { name: /attach a file/i });
    expect(attachBtn).toHaveProperty("disabled", true);
  });

  it("opens the mention picker on @, inserts a mention node, and reports mentionedUserIds on save", async () => {
    const user = userEvent.setup();
    let saved: ActivityDraft | undefined;
    const onSave = vi.fn((draft: ActivityDraft) => { saved = draft; });
    render(
      <ActivityComposer
        config={config({ mentions: true })}
        mentionCandidates={MENTION_CANDIDATES}
        onSave={onSave}
      />,
    );
    const textbox = screen.getByRole("textbox", { name: /activity note/i });
    await user.type(textbox, "Hey @Pri");
    await waitFor(() => expect(screen.getByRole("listbox", { name: /mention a teammate/i })).toBeDefined());
    await user.click(await screen.findByRole("option", { name: /Priya Nair/i }));

    expect(textbox.textContent).toContain("Priya Nair");
    await user.click(screen.getByRole("button", { name: /save note/i }));

    expect(saved?.mentionedUserIds).toEqual(["u1"]);
    expect(saved?.plainText).toContain("Priya Nair");
  });

  it("adds and removes tags when tags is config-gated on", async () => {
    const user = userEvent.setup();
    const onSave = vi.fn();
    render(<ActivityComposer config={config({ tags: true })} onSave={onSave} />);
    const tagInput = screen.getByRole("textbox", { name: /add tag/i });
    await user.type(tagInput, "renewal{Enter}");
    expect(screen.getByText("renewal")).toBeDefined();
    await user.click(screen.getByRole("button", { name: /remove tag renewal/i }));
    expect(screen.queryByText("renewal")).toBeNull();
  });
});
