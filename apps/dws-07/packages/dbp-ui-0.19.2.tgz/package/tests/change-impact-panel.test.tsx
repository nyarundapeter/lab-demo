import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ChangeImpactPanel, type ImpactItem } from "../src/components/change-impact-panel.js";

afterEach(() => cleanup());

const ITEMS: ImpactItem[] = [
  { type: "Workflows", count: 2, items: ["Incident escalation", "SLA breach handling"], to: "workflows" },
  { type: "Rules", count: 1, items: ["VIP customer fast-track"], to: "rules", conflict: true },
  { type: "Forms", count: 2, items: ["Service request intake", "Escalation form"] },
];

describe("ChangeImpactPanel", () => {
  it("renders the panel title and item types", () => {
    render(<ChangeImpactPanel items={ITEMS} />);
    expect(screen.getByText("Change impact analysis")).toBeDefined();
    expect(screen.getByText("Workflows")).toBeDefined();
    expect(screen.getByText("Forms")).toBeDefined();
  });

  it("shows the risk label for the given riskLevel", () => {
    render(<ChangeImpactPanel items={ITEMS} riskLevel="high" />);
    expect(screen.getByText("High risk")).toBeDefined();
  });

  it("shows a Conflict badge for conflicting items", () => {
    render(<ChangeImpactPanel items={ITEMS} />);
    expect(screen.getByText("Conflict")).toBeDefined();
  });

  it("shows the approval-required callout", () => {
    render(<ChangeImpactPanel items={ITEMS} />);
    expect(screen.getByText("1 approval required")).toBeDefined();
  });

  it("calls onNavigate when an item's open action is clicked", async () => {
    const onNavigate = vi.fn();
    render(<ChangeImpactPanel items={ITEMS} onNavigate={onNavigate} />);
    const openButtons = screen.getAllByRole("button", { name: /^Open /i });
    await userEvent.click(openButtons[0]!);
    expect(onNavigate).toHaveBeenCalledWith("workflows");
  });

  it("calls onNavigate when a linked affected item is clicked", async () => {
    const onNavigate = vi.fn();
    render(<ChangeImpactPanel items={ITEMS} onNavigate={onNavigate} />);
    await userEvent.click(screen.getByText("Incident escalation"));
    expect(onNavigate).toHaveBeenCalledWith("workflows");
  });
});
