import { describe, it, expect } from "vitest"
import { render, screen } from "@testing-library/react"
import { SectionHeading } from "../src/components/section-heading.js"

describe("SectionHeading", () => {
  it("renders the title", () => {
    render(<SectionHeading title="Our services" />)
    expect(screen.getByText("Our services")).toBeDefined()
  })

  it("renders the kicker with the dq-overline class", () => {
    const { container } = render(<SectionHeading kicker="MARKETPLACE" title="x" />)
    const kicker = screen.getByText("MARKETPLACE")
    expect(kicker.className).toContain("dq-overline")
    expect(container).toBeDefined()
  })

  it("renders the description when provided", () => {
    render(<SectionHeading title="x" description="Browse offerings" />)
    expect(screen.getByText("Browse offerings")).toBeDefined()
  })

  it("applies left alignment when align=left", () => {
    const { container } = render(<SectionHeading title="x" align="left" />)
    expect((container.firstChild as HTMLElement).className).toContain("text-left")
  })

  it("centers by default", () => {
    const { container } = render(<SectionHeading title="x" />)
    expect((container.firstChild as HTMLElement).className).toContain("text-center")
  })
})
