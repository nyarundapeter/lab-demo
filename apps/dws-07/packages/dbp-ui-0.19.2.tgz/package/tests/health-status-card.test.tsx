import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { HealthStatusCard } from "../src/components/health-status-card.js";

afterEach(() => { cleanup(); });

describe("HealthStatusCard", () => {
  it("renders title, headline, and status label", () => {
    render(<HealthStatusCard title="Q3 Renewals" status="good" headline="94%" />);
    expect(screen.getByText("Q3 Renewals")).toBeDefined();
    expect(screen.getByText("94%")).toBeDefined();
    expect(screen.getByText("On track")).toBeDefined();
  });

  it("renders sub-metrics when provided", () => {
    render(
      <HealthStatusCard
        title="SLA"
        status="warn"
        headline="98%"
        subMetrics={[{ label: "Incidents", value: 4 }]}
      />,
    );
    expect(screen.getByText("Incidents")).toBeDefined();
    expect(screen.getByText("4")).toBeDefined();
  });

  it("renders the action button when provided", () => {
    render(<HealthStatusCard title="X" status="good" headline="1" action="View" />);
    expect(screen.getByRole("button", { name: /View/ })).toBeDefined();
  });
});
