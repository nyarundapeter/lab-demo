import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { DetailPageGrid } from "../src/components/detail-page-grid.js";

afterEach(() => {
  cleanup();
});

describe("DetailPageGrid", () => {
  it("renders the content slot", () => {
    render(
      <DetailPageGrid
        content={<div data-testid="content-slot">Content area</div>}
        rail={<div data-testid="rail-slot">Rail area</div>}
      />,
    );
    expect(screen.getByTestId("content-slot")).toBeDefined();
    expect(screen.getByText("Content area")).toBeDefined();
  });

  it("renders the rail slot", () => {
    render(
      <DetailPageGrid
        content={<div>Content</div>}
        rail={<div data-testid="rail-slot">Rail area</div>}
      />,
    );
    expect(screen.getByTestId("rail-slot")).toBeDefined();
    expect(screen.getByText("Rail area")).toBeDefined();
  });

  it("applies the 12-col grid class", () => {
    const { container } = render(
      <DetailPageGrid
        content={<div>Content</div>}
        rail={<div>Rail</div>}
      />,
    );
    const grid = container.firstElementChild as HTMLElement;
    // Built on the canonical Grid (always-on 12 columns; columns stack until lg via Col).
    expect(grid.className).toContain("grid-cols-12");
  });

  it("applies custom className", () => {
    const { container } = render(
      <DetailPageGrid
        content={<div>Content</div>}
        rail={<div>Rail</div>}
        className="my-custom-class"
      />,
    );
    const grid = container.firstElementChild as HTMLElement;
    expect(grid.className).toContain("my-custom-class");
  });

  it("applies lg:col-span-8 to content and lg:col-span-4 to rail column", () => {
    const { container } = render(
      <DetailPageGrid
        content={<div>Content</div>}
        rail={<div>Rail</div>}
      />,
    );
    const children = Array.from(container.firstElementChild!.children) as HTMLElement[];
    expect(children[0]!.className).toContain("lg:col-span-8");
    expect(children[1]!.className).toContain("lg:col-span-4");
  });

  it("applies rail offset (lg:pt-[3.5rem]) inside the rail column", () => {
    const { container } = render(
      <DetailPageGrid
        content={<div>Content</div>}
        rail={<div>Rail</div>}
      />,
    );
    const railColumn = Array.from(container.firstElementChild!.children)[1] as HTMLElement;
    const innerDiv = railColumn.firstElementChild as HTMLElement;
    expect(innerDiv.className).toContain("lg:pt-[3.5rem]");
  });
});
