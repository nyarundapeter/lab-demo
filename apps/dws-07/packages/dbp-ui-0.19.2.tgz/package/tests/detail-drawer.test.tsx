import type * as React from "react";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { DetailDrawer } from "../src/components/detail-drawer.js";

afterEach(() => {
  cleanup();
});

function renderDrawer(overrides: Partial<React.ComponentProps<typeof DetailDrawer>> = {}) {
  const onClose = vi.fn();
  const onExpandedChange = vi.fn();
  const onActiveTabChange = vi.fn();
  render(
    <DetailDrawer
      open
      onClose={onClose}
      expanded={false}
      onExpandedChange={onExpandedChange}
      title="REQ-2026-041"
      activeTab="overview"
      onActiveTabChange={onActiveTabChange}
      tabs={[
        { key: "overview", label: "Overview", content: <p>Overview body</p> },
        { key: "controls", label: "Controls", content: <p>Controls body</p> },
      ]}
      {...overrides}
    />,
  );
  return { onClose, onExpandedChange, onActiveTabChange };
}

describe("DetailDrawer", () => {
  it("renders the title, subtitle, and active tab content", () => {
    renderDrawer({ subtitle: "Regulatory Register" });
    expect(screen.getByText("REQ-2026-041")).toBeDefined();
    expect(screen.getByText("Regulatory Register")).toBeDefined();
    expect(screen.getByText("Overview body")).toBeDefined();
  });

  it("renders pills", () => {
    renderDrawer({ pills: [{ label: "Active", tone: "success" }] });
    expect(screen.getByText("Active")).toBeDefined();
  });

  it("calls onClose when the close button is clicked", async () => {
    const user = userEvent.setup();
    const { onClose } = renderDrawer();
    await user.click(screen.getByRole("button", { name: "Close" }));
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("calls onExpandedChange when the expand button is clicked", async () => {
    const user = userEvent.setup();
    const { onExpandedChange } = renderDrawer();
    await user.click(screen.getByRole("button", { name: "Expand" }));
    expect(onExpandedChange).toHaveBeenCalledWith(true);
  });

  it("switches tabs via onActiveTabChange", async () => {
    const user = userEvent.setup();
    const { onActiveTabChange } = renderDrawer();
    await user.click(screen.getByText("Controls"));
    expect(onActiveTabChange).toHaveBeenCalledWith("controls");
  });

  it("renders footer actions only when provided", () => {
    renderDrawer({ footerActions: <button type="button">Save</button> });
    expect(screen.getByText("Save")).toBeDefined();
  });

  it("does not render the Sheet's own built-in close button (hideClose)", () => {
    renderDrawer();
    expect(screen.getAllByRole("button", { name: "Close" })).toHaveLength(1);
  });
});
