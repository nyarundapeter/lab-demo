import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { FileText, Link2 } from "lucide-react";
import { EvidencePanel } from "../src/components/evidence-panel.js";
import type { EvidenceItem } from "../src/components/evidence-panel.js";

afterEach(() => { cleanup(); });

describe("EvidencePanel", () => {
  it("renders verified and missing items with the verified count", () => {
    const items: EvidenceItem[] = [
      { id: "1", name: "Vendor invoice PDF", meta: "PDF · 2.4 MB", icon: FileText, verified: true },
      { id: "2", name: "Security assessment", meta: "Required for renewals", icon: Link2, verified: false },
    ];
    render(<EvidencePanel items={items} />);
    expect(screen.getByText("1/2 verified")).toBeDefined();
    expect(screen.getByText("Verified")).toBeDefined();
    expect(screen.getByText("Missing")).toBeDefined();
  });

  it("calls onPreview when the preview button is clicked", () => {
    const onPreview = vi.fn();
    const items: EvidenceItem[] = [
      { id: "1", name: "Vendor invoice PDF", meta: "PDF · 2.4 MB", icon: FileText, verified: true, onPreview },
    ];
    render(<EvidencePanel items={items} />);
    fireEvent.click(screen.getByTestId("evidence-preview-button"));
    expect(onPreview).toHaveBeenCalledTimes(1);
  });
});
