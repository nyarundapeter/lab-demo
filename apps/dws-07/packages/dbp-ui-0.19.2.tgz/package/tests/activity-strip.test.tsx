import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { ActivityStrip, type ActivityStripEvent } from "../src/components/activity-strip.js";

afterEach(() => { cleanup(); });

const EVENTS: ActivityStripEvent[] = [
  { id: "1", label: "Case summary regenerated", kind: "summary", status: "accepted" },
  { id: "2", label: "Anomaly flagged", kind: "anomaly", status: "pending" },
  { id: "3", label: "Draft reply written", kind: "draft", status: "edited" },
];

describe("ActivityStrip", () => {
  it("renders up to the limit and truncates the rest", () => {
    render(<ActivityStrip events={EVENTS} limit={2} />);
    expect(screen.getByText("Case summary regenerated")).toBeDefined();
    expect(screen.getByText("Anomaly flagged")).toBeDefined();
    expect(screen.queryByText("Draft reply written")).toBeNull();
  });

  it("defaults the limit to 3", () => {
    render(<ActivityStrip events={EVENTS} />);
    expect(screen.getByText("Draft reply written")).toBeDefined();
  });

  it("renders each row's status chip", () => {
    render(<ActivityStrip events={EVENTS} />);
    expect(screen.getByText("Accepted")).toBeDefined();
    expect(screen.getByText("Pending review")).toBeDefined();
  });

  it("calls onViewAll", () => {
    const onViewAll = vi.fn();
    render(<ActivityStrip events={EVENTS} onViewAll={onViewAll} />);
    fireEvent.click(screen.getByRole("button", { name: "View full AI activity" }));
    expect(onViewAll).toHaveBeenCalledOnce();
  });
});
