import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { DetailTabStrip } from "../src/components/detail-tab-strip.js";

afterEach(() => {
  cleanup();
});

const tabs = [
  { key: "overview", label: "Overview", content: null },
  { key: "controls", label: "Controls", content: null },
];

describe("DetailTabStrip", () => {
  it("renders every tab label", () => {
    render(<DetailTabStrip tabs={tabs} activeTab="overview" onActiveTabChange={vi.fn()} />);
    expect(screen.getByText("Overview")).toBeDefined();
    expect(screen.getByText("Controls")).toBeDefined();
  });

  it("calls onActiveTabChange with the clicked tab's key", async () => {
    const user = userEvent.setup();
    const onActiveTabChange = vi.fn();
    render(<DetailTabStrip tabs={tabs} activeTab="overview" onActiveTabChange={onActiveTabChange} />);
    await user.click(screen.getByText("Controls"));
    expect(onActiveTabChange).toHaveBeenCalledWith("controls");
  });
});
