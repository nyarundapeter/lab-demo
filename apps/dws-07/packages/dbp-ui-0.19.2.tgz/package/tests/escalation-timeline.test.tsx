import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { EscalationTimeline, type EscalationStep } from "../src/components/escalation-timeline.js";

afterEach(() => { cleanup(); });

const STEPS: EscalationStep[] = [
  { id: "1", label: "First reminder", time: "Wed 09:00", severity: "info", note: "Initial notice sent.", done: true },
  { id: "2", label: "Escalated", time: "Wed 17:30", severity: "warning", note: "2 hours left.", current: true },
  { id: "3", label: "Final warning", time: "Thu 09:00", severity: "critical", note: "SLA breach imminent." },
];

describe("EscalationTimeline", () => {
  it("renders a step for each entry with its label, time, and note", () => {
    render(<EscalationTimeline steps={STEPS} />);
    expect(screen.getByText("First reminder")).toBeDefined();
    expect(screen.getByText("Wed 09:00")).toBeDefined();
    expect(screen.getByText("Initial notice sent.")).toBeDefined();
    expect(screen.getByText("Escalated")).toBeDefined();
    expect(screen.getByText("Final warning")).toBeDefined();
  });

  it("shows a 'Now' badge only on the current step", () => {
    render(<EscalationTimeline steps={STEPS} />);
    expect(screen.getByText("Now")).toBeDefined();
    const items = screen.getAllByRole("listitem");
    expect(items).toHaveLength(3);
  });

  it("renders as an ordered list with one item per step", () => {
    render(<EscalationTimeline steps={STEPS} />);
    expect(screen.getByRole("list").tagName).toBe("OL");
    expect(screen.getAllByRole("listitem")).toHaveLength(3);
  });
});
