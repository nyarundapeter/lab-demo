import { describe, it, expect, afterEach } from "vitest";
import { render, cleanup } from "@testing-library/react";
import { AiMark } from "../src/components/ai-mark.js";

afterEach(() => { cleanup(); });

describe("AiMark", () => {
  it("renders without throwing and is hidden from the accessibility tree", () => {
    const { container } = render(<AiMark />);
    const mark = container.querySelector("[aria-hidden]");
    expect(mark).not.toBeNull();
  });

  it("applies a custom className", () => {
    const { container } = render(<AiMark className="extra-class" />);
    expect(container.querySelector(".extra-class")).not.toBeNull();
  });
});
