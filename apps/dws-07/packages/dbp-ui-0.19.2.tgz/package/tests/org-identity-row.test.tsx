import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { OrgIdentityRow } from "../src/components/org-identity-row.js";

afterEach(() => { cleanup(); });

describe("OrgIdentityRow", () => {
  it("renders the org name and domain", () => {
    render(<OrgIdentityRow name="Northwind" domain="northwind.example" />);
    expect(screen.getByText("Northwind")).toBeDefined();
    expect(screen.getByText("northwind.example")).toBeDefined();
  });

  it("omits the domain line when not given", () => {
    render(<OrgIdentityRow name="Northwind" />);
    expect(screen.queryByText("northwind.example")).toBeNull();
  });
});
