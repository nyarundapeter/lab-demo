import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { SevChip } from "../src/components/sev-chip.js";

afterEach(() => cleanup());

describe("SevChip", () => {
  it("renders the default label for a severity", () => {
    render(<SevChip severity="warning" />);
    expect(screen.getByText("Warning")).toBeDefined();
  });

  it("renders the default label for each severity in the taxonomy", () => {
    render(
      <>
        <SevChip severity="info" />
        <SevChip severity="success" />
        <SevChip severity="error" />
        <SevChip severity="critical" />
      </>
    );
    expect(screen.getByText("Info")).toBeDefined();
    expect(screen.getByText("Success")).toBeDefined();
    expect(screen.getByText("Error")).toBeDefined();
    expect(screen.getByText("Critical")).toBeDefined();
  });

  it("renders a custom label override instead of the default", () => {
    render(<SevChip severity="error" label="Blocking issue" />);
    expect(screen.getByText("Blocking issue")).toBeDefined();
    expect(screen.queryByText("Error")).toBeNull();
  });

  it("renders an icon alongside the label (never colour alone)", () => {
    const { container } = render(<SevChip severity="critical" />);
    expect(container.querySelector("svg")).not.toBeNull();
  });
});
