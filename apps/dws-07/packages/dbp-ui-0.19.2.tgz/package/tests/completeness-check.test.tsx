import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { CompletenessCheck } from "../src/components/completeness-check.js";

afterEach(() => { cleanup(); });

describe("CompletenessCheck", () => {
  it("renders every item's text and detail", () => {
    render(
      <CompletenessCheck
        items={[
          { ok: true, text: "Contact confirmed" },
          { warn: true, text: "SLA missing", detail: "Required" },
        ]}
      />,
    );
    expect(screen.getByText("Contact confirmed")).toBeDefined();
    expect(screen.getByText("SLA missing")).toBeDefined();
    expect(screen.getByText(/Required/)).toBeDefined();
  });

  it("renders an action button and dispatches onAction", () => {
    const onAction = vi.fn();
    render(<CompletenessCheck items={[{ text: "Owner missing", action: "Assign", onAction }]} />);
    fireEvent.click(screen.getByRole("button", { name: "Assign" }));
    expect(onAction).toHaveBeenCalledOnce();
  });

  it("shows the advisory footer", () => {
    render(<CompletenessCheck items={[]} />);
    expect(screen.getByText(/Advisory/)).toBeDefined();
  });
});
