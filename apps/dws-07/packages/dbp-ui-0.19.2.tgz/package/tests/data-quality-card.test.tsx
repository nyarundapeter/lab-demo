import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { DataQualityCard, type DataQualityCardItem } from "../src/components/data-quality-card.js";

afterEach(() => { cleanup(); });

const ITEM: DataQualityCardItem = {
  issue: "23 records have a malformed postcode",
  severity: "medium",
  records: "23 of 1,204",
  impact: "Regional rollups may undercount",
  fix: "Normalize postcode format",
  owner: "Data Engineering",
};

describe("DataQualityCard", () => {
  it("renders the issue and severity badge", () => {
    render(<DataQualityCard item={ITEM} />);
    expect(screen.getByText("23 records have a malformed postcode")).toBeDefined();
    expect(screen.getByText("Medium risk")).toBeDefined();
  });

  it("applying the fix moves to the queued-for-review state", () => {
    render(<DataQualityCard item={ITEM} />);
    fireEvent.click(screen.getByRole("button", { name: "Apply suggested fix" }));
    expect(screen.getByText("Correction queued for review.")).toBeDefined();
  });

  it("undo returns to idle", () => {
    render(<DataQualityCard item={ITEM} />);
    fireEvent.click(screen.getByRole("button", { name: "Apply suggested fix" }));
    fireEvent.click(screen.getByRole("button", { name: "Undo" }));
    expect(screen.getByRole("button", { name: "Apply suggested fix" })).toBeDefined();
  });

  it("calls onAssignOwner and onDismiss", () => {
    const onAssignOwner = vi.fn();
    const onDismiss = vi.fn();
    render(<DataQualityCard item={ITEM} onAssignOwner={onAssignOwner} onDismiss={onDismiss} />);
    fireEvent.click(screen.getByRole("button", { name: "Assign owner" }));
    fireEvent.click(screen.getByRole("button", { name: "Dismiss" }));
    expect(onAssignOwner).toHaveBeenCalledOnce();
    expect(onDismiss).toHaveBeenCalledOnce();
  });
});
