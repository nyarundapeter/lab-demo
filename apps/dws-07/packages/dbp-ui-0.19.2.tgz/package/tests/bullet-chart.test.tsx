import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { BulletChart } from "../src/components/bullet-chart.js";

afterEach(() => { cleanup(); });

describe("BulletChart", () => {
  it("sizes the fill bar to value/max as a percentage", () => {
    const { container } = render(<BulletChart value={50} target={80} max={100} />);
    const fill = container.querySelector(".h-full") as HTMLElement;
    expect(fill.style.width).toBe("50%");
  });

  it("positions the target marker at target/max as a percentage", () => {
    const { container } = render(<BulletChart value={50} target={80} max={100} />);
    const marker = container.querySelector("[title='Target']") as HTMLElement;
    expect(marker.style.left).toBe("80%");
  });

  it("clamps value and target above max to 100%", () => {
    const { container } = render(<BulletChart value={150} target={200} max={100} />);
    const fill = container.querySelector(".h-full") as HTMLElement;
    const marker = container.querySelector("[title='Target']") as HTMLElement;
    expect(fill.style.width).toBe("100%");
    expect(marker.style.left).toBe("100%");
  });

  it("renders label and valueLabel when provided", () => {
    render(<BulletChart value={72} target={85} max={100} label="Revenue" valueLabel="$72K / $85K" />);
    expect(screen.getByText("Revenue")).toBeDefined();
    expect(screen.getByText("$72K / $85K")).toBeDefined();
  });

  it("omits the label row when neither label nor valueLabel is provided", () => {
    const { container } = render(<BulletChart value={72} target={85} max={100} />);
    expect(container.querySelector(".mb-1")).toBeNull();
  });
});
