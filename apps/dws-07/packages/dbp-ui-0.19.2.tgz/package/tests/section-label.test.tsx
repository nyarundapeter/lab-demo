import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { SectionLabel } from "../src/components/section-label.js";

afterEach(() => { cleanup(); });

describe("SectionLabel", () => {
  it("renders its children", () => {
    render(<SectionLabel>Overview</SectionLabel>);
    expect(screen.getByText("Overview")).toBeDefined();
  });

  it("renders as a span by default", () => {
    render(<SectionLabel data-testid="label">Overview</SectionLabel>);
    expect(screen.getByTestId("label").tagName).toBe("SPAN");
  });

  it("renders as the element passed via `as`", () => {
    render(<SectionLabel as="h2" data-testid="label">Overview</SectionLabel>);
    expect(screen.getByTestId("label").tagName).toBe("H2");
  });
});
