import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { CodeInput } from "../src/components/code-input.js";

afterEach(() => { cleanup(); });

describe("CodeInput", () => {
  it("renders `length` digit boxes", () => {
    render(<CodeInput length={4} />);
    expect(screen.getAllByRole("textbox")).toHaveLength(4);
  });

  it("advances focus to the next box after typing a digit", () => {
    render(<CodeInput length={4} />);
    const boxes = screen.getAllByRole("textbox");
    fireEvent.change(boxes[0]!, { target: { value: "1" } });
    expect(document.activeElement).toBe(boxes[1]);
  });

  it("calls onComplete once every box is filled", () => {
    const onComplete = vi.fn();
    render(<CodeInput length={3} onComplete={onComplete} />);
    const boxes = screen.getAllByRole("textbox");
    fireEvent.change(boxes[0]!, { target: { value: "1" } });
    fireEvent.change(boxes[1]!, { target: { value: "2" } });
    fireEvent.change(boxes[2]!, { target: { value: "3" } });
    expect(onComplete).toHaveBeenCalledWith("123");
  });

  it("moves focus back on backspace from an empty box", () => {
    render(<CodeInput length={4} />);
    const boxes = screen.getAllByRole("textbox");
    fireEvent.change(boxes[0]!, { target: { value: "1" } });
    boxes[1]!.focus();
    fireEvent.keyDown(boxes[1]!, { key: "Backspace" });
    expect(document.activeElement).toBe(boxes[0]);
  });

  it("distributes a pasted code across all boxes", () => {
    const onComplete = vi.fn();
    render(<CodeInput length={4} onComplete={onComplete} />);
    const boxes = screen.getAllByRole("textbox");
    fireEvent.paste(boxes[0]!, { clipboardData: { getData: () => "5678" } });
    expect((boxes[0] as HTMLInputElement).value).toBe("5");
    expect((boxes[3] as HTMLInputElement).value).toBe("8");
    expect(onComplete).toHaveBeenCalledWith("5678");
  });
});
