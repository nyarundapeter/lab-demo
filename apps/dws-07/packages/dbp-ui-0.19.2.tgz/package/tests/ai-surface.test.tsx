import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { AiSurface, AiSurfaceFacet, CategoryTag } from "../src/components/ai-surface.js";

afterEach(() => { cleanup(); });

describe("AiSurface", () => {
  it("renders the AILabel banner, title, and children", () => {
    render(
      <AiSurface label="summary" title="Case summary">
        <p>Body content</p>
      </AiSurface>,
    );
    expect(screen.getByText("AI-generated summary")).toBeDefined();
    expect(screen.getByText("Case summary")).toBeDefined();
    expect(screen.getByText("Body content")).toBeDefined();
  });

  it("renders meta, actions, and foot slots when provided", () => {
    render(
      <AiSurface meta={<span>Generated 10:42</span>} actions={<button>Regenerate</button>} foot={<span>Footer</span>}>
        <p>Body</p>
      </AiSurface>,
    );
    expect(screen.getByText("Generated 10:42")).toBeDefined();
    expect(screen.getByText("Regenerate")).toBeDefined();
    expect(screen.getByText("Footer")).toBeDefined();
  });

  it("keeps the oracle head / body / foot structure (left accent + bands)", () => {
    const { container } = render(
      <AiSurface label="summary" title="Case summary" meta={<span>Generated 10:42</span>} foot={<span>Footer</span>}>
        <p>Body content</p>
      </AiSurface>,
    );
    const card = container.firstElementChild as HTMLElement;
    expect(card.className).toContain("overflow-hidden");
    expect(card.className).toContain("p-0");
    // Left accent rail is aria-hidden decorative.
    expect(card.querySelector('[aria-hidden="true"]')).not.toBeNull();
  });
});

describe("AiSurfaceFacet", () => {
  it("renders the label and children", () => {
    render(
      <AiSurfaceFacet label="Key findings" prov="ai">
        Some finding
      </AiSurfaceFacet>,
    );
    expect(screen.getByText("Key findings")).toBeDefined();
    expect(screen.getByText("Some finding")).toBeDefined();
    expect(screen.getByText("AI interpretation")).toBeDefined();
  });
});

describe("CategoryTag", () => {
  it("renders every category label", () => {
    render(<CategoryTag category="Anomaly" />);
    expect(screen.getByText("Anomaly")).toBeDefined();
  });

  it("falls back to Trend for an unrecognised category", () => {
    // @ts-expect-error — intentionally invalid to exercise the fallback
    render(<CategoryTag category="Unknown" />);
    expect(screen.getByText("Unknown")).toBeDefined();
  });
});
