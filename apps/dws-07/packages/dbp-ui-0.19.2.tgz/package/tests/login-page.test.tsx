import { describe, it, expect, afterEach } from "vitest"
import { render, screen, cleanup } from "@testing-library/react"

afterEach(() => {
  cleanup()
})

import { LoginPage } from "../src/components/login-page.js"

describe("LoginPage", () => {
  it("renders product name in left panel", () => {
    render(<LoginPage productName="Digital Catalyst" title="Sign in"><form>Login Form</form></LoginPage>)
    const heading = screen.getByRole("heading", { name: "Digital Catalyst" })
    expect(heading).toBeDefined()
  })

  it("renders form title", () => {
    render(<LoginPage productName="Digital Catalyst" title="Welcome Back"><form>Login Form</form></LoginPage>)
    const heading = screen.getByRole("heading", { name: "Welcome Back" })
    expect(heading).toBeDefined()
    expect(heading.tagName).toBe("H2")
  })

  it("renders children (form content)", () => {
    render(<LoginPage productName="Digital Catalyst" title="Sign in"><input type="email" placeholder="Email" /></LoginPage>)
    const input = screen.getByPlaceholderText("Email")
    expect(input).toBeDefined()
  })

  it("renders tagline when provided", () => {
    render(<LoginPage productName="Digital Catalyst" tagline="Enterprise Platform" title="Sign in"><form>Login Form</form></LoginPage>)
    expect(screen.getByText("Enterprise Platform")).toBeDefined()
  })

  it("does not render tagline when absent", () => {
    render(<LoginPage productName="Digital Catalyst" title="Sign in"><form>Login Form</form></LoginPage>)
    expect(screen.queryByText("Enterprise Platform")).toBeNull()
  })

  it("renders subtitle when provided", () => {
    render(<LoginPage productName="Digital Catalyst" title="Sign in" subtitle="Enter your credentials to continue"><form>Login Form</form></LoginPage>)
    expect(screen.getByText("Enter your credentials to continue")).toBeDefined()
  })

  it("renders logo when provided", () => {
    const logo = <img src="/logo.png" alt="Logo" />
    render(<LoginPage productName="Digital Catalyst" logo={logo} title="Sign in"><form>Login Form</form></LoginPage>)
    const logoImg = screen.getByAltText("Logo")
    expect(logoImg).toBeDefined()
  })

  it("has default title 'Sign in' when not provided", () => {
    render(<LoginPage productName="Digital Catalyst"><form>Login Form</form></LoginPage>)
    const heading = screen.getByRole("heading", { name: "Sign in" })
    expect(heading).toBeDefined()
  })
})
