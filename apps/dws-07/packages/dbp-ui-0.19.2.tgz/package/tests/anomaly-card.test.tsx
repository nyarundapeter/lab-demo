import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { AnomalyCard } from "../src/components/anomaly-card.js";

afterEach(() => { cleanup(); });

describe("AnomalyCard", () => {
  it("renders metric, detail, and Anomaly detected label", () => {
    render(<AnomalyCard metric="Error rate" detail="Spiked to 4.8%" when="12 min ago" />);
    expect(screen.getByText("Anomaly detected")).toBeDefined();
    expect(screen.getByText("Error rate")).toBeDefined();
    expect(screen.getByText("Spiked to 4.8%")).toBeDefined();
  });

  it("shows a resolution state and calls onConfirm when Confirm is clicked", () => {
    let confirmed = false;
    render(
      <AnomalyCard
        metric="X"
        detail="Y"
        when="now"
        onConfirm={() => { confirmed = true; }}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));
    expect(confirmed).toBe(true);
    expect(screen.getByText("Confirmed")).toBeDefined();
  });
});
