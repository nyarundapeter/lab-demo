import * as React from "react";
import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ConflictBanner } from "../src/components/conflict-banner.js";

afterEach(() => { cleanup(); });

const FIELDS = [
  { field: "status", label: "Status", mine: "Blocked", theirs: "In progress" },
];

describe("ConflictBanner", () => {
  it("shows who changed the record, when, and how many fields differ", () => {
    render(
      <ConflictBanner
        updatedByLabel="Priya Shah"
        updatedAtLabel="12s ago"
        fields={FIELDS}
        canOverwrite
        onResolve={vi.fn()}
      />,
    );
    expect(screen.getByText(/Priya Shah changed this record 12s ago/)).toBeTruthy();
    expect(screen.getByText(/1 field differ/)).toBeTruthy();
    expect(screen.getByTestId("conflict-field-status")).toBeTruthy();
  });

  it("calls onResolve('refresh') from the refresh action", async () => {
    const user = userEvent.setup();
    const onResolve = vi.fn();
    render(
      <ConflictBanner updatedByLabel="Priya" updatedAtLabel="now" fields={FIELDS} onResolve={onResolve} />,
    );
    await user.click(screen.getByTestId("conflict-resolve-refresh"));
    expect(onResolve).toHaveBeenCalledWith("refresh");
  });

  it("disables the overwrite action when canOverwrite is false", () => {
    render(
      <ConflictBanner
        updatedByLabel="Priya"
        updatedAtLabel="now"
        fields={FIELDS}
        canOverwrite={false}
        onResolve={vi.fn()}
      />,
    );
    expect(screen.getByTestId("conflict-resolve-overwrite")).toHaveProperty("disabled", true);
  });

  it("calls onResolve('overwrite') when permitted", async () => {
    const user = userEvent.setup();
    const onResolve = vi.fn();
    render(
      <ConflictBanner
        updatedByLabel="Priya"
        updatedAtLabel="now"
        fields={FIELDS}
        canOverwrite
        onResolve={onResolve}
      />,
    );
    await user.click(screen.getByTestId("conflict-resolve-overwrite"));
    expect(onResolve).toHaveBeenCalledWith("overwrite");
  });

  it("hides the save-as-new action by default", () => {
    render(
      <ConflictBanner updatedByLabel="Priya" updatedAtLabel="now" fields={FIELDS} onResolve={vi.fn()} />,
    );
    expect(screen.queryByTestId("conflict-resolve-save-as-new")).toBeNull();
  });

  it("shows and fires the save-as-new action when opted in", async () => {
    const user = userEvent.setup();
    const onResolve = vi.fn();
    render(
      <ConflictBanner
        updatedByLabel="Priya"
        updatedAtLabel="now"
        fields={FIELDS}
        allowSaveAsNew
        onResolve={onResolve}
      />,
    );
    await user.click(screen.getByTestId("conflict-resolve-save-as-new"));
    expect(onResolve).toHaveBeenCalledWith("saveAsNew");
  });
});
