import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { FileDropzone } from "../src/components/file-dropzone.js";

afterEach(() => { cleanup(); });

describe("FileDropzone", () => {
  it("renders a real file input (keyboard/screen-reader fallback)", () => {
    render(<FileDropzone />);
    const input = document.querySelector('input[type="file"]');
    expect(input).not.toBeNull();
  });

  it("shows the prompt text and browse label", () => {
    render(<FileDropzone />);
    expect(screen.getByText(/Drag and drop files here/)).toBeDefined();
    expect(screen.getByText("browse")).toBeDefined();
  });

  it("shows visible helper text describing accepted types/size", () => {
    render(
      <FileDropzone helperText="Max file size 25MB per file. Allowed types: PDF, DOCX, XLSX, PPTX, ZIP." />
    );
    expect(
      screen.getByText("Max file size 25MB per file. Allowed types: PDF, DOCX, XLSX, PPTX, ZIP.")
    ).toBeDefined();
  });

  it("wires helper text to the file input via aria-describedby", () => {
    render(<FileDropzone helperText="Max 25MB" />);
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    const descId = input.getAttribute("aria-describedby");
    expect(descId).toBeTruthy();
    const desc = document.getElementById(descId as string);
    expect(desc?.textContent).toBe("Max 25MB");
  });

  it("passes accept and multiple through to the input", () => {
    render(<FileDropzone accept=".pdf,.docx" multiple={false} />);
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    expect(input.accept).toBe(".pdf,.docx");
    expect(input.multiple).toBe(false);
  });

  it("calls onFilesSelected when a file is chosen via the input", () => {
    let received: FileList | undefined;
    render(<FileDropzone onFilesSelected={(files) => { received = files; }} />);
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    const file = new File(["hello"], "hello.pdf", { type: "application/pdf" });
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    Object.defineProperty(input, "files", { value: dataTransfer.files });
    input.dispatchEvent(new Event("change", { bubbles: true }));
    expect(received?.length).toBe(1);
    expect(received?.[0]?.name).toBe("hello.pdf");
  });
});
