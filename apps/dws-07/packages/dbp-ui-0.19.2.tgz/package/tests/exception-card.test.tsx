import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { ExceptionCard } from "../src/components/exception-card.js";

afterEach(() => { cleanup(); });

describe("ExceptionCard", () => {
  it("renders a policy exception", () => {
    render(
      <ExceptionCard
        variant="policy"
        title="Spend threshold exception approved"
        detail="A manager override was recorded."
      />,
    );
    expect(screen.getByText("Policy exception")).toBeDefined();
    expect(screen.getByText("Spend threshold exception approved")).toBeDefined();
  });

  it("renders a system exception", () => {
    render(<ExceptionCard variant="system" title="X" detail="Y" />);
    expect(screen.getByText("System exception")).toBeDefined();
  });

  it("calls onResolve when Resolve is clicked", () => {
    let resolved = false;
    render(
      <ExceptionCard variant="policy" title="X" detail="Y" onResolve={() => { resolved = true; }} />,
    );
    fireEvent.click(screen.getByTestId("exception-resolve-button"));
    expect(resolved).toBe(true);
  });
});
