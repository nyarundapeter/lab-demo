import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { ConditionalTracker } from "../src/components/conditional-tracker.js";
import type { ConditionalAlternative } from "../src/components/conditional-tracker.js";
import type { StageRow } from "../src/components/vertical-stage-tracker.js";

afterEach(() => { cleanup(); });

const STAGES: StageRow[] = [
  { id: "a", label: "Intake", status: "done" },
  { id: "b", label: "VP review", status: "active" },
];

const ALTERNATIVES: ConditionalAlternative[] = [
  { id: "alt-1", label: "Auto-approval", description: "Taken when amount is below €5,000" },
];

describe("ConditionalTracker", () => {
  it("renders the active path and decision, with alternatives collapsed by default", () => {
    render(<ConditionalTracker stages={STAGES} decision="Amount ≥ €25,000" alternatives={ALTERNATIVES} />);
    expect(screen.getByText("Amount ≥ €25,000")).toBeDefined();
    expect(screen.getByText("Intake")).toBeDefined();
    expect(screen.queryByTestId("conditional-tracker-alternative")).toBeNull();
    expect(screen.getByText("Show alternative paths (1)")).toBeDefined();
  });

  it("reveals alternatives on toggle", () => {
    render(<ConditionalTracker stages={STAGES} decision="Amount ≥ €25,000" alternatives={ALTERNATIVES} />);
    fireEvent.click(screen.getByTestId("conditional-tracker-toggle-alternatives"));
    expect(screen.getByTestId("conditional-tracker-alternative")).toBeDefined();
    expect(screen.getByText("Auto-approval")).toBeDefined();
    expect(screen.getByText("Hide alternative paths (1)")).toBeDefined();
  });
});
