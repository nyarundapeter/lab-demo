import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { FindInRecord, type FindInRecordEntry } from "../src/components/find-in-record.js";

afterEach(() => { cleanup(); });

const ENTRIES: FindInRecordEntry[] = [
  { id: "1", who: "Ava", text: "Sent renewal proposal for Q3 term.", timeLabel: "2h ago" },
  { id: "2", who: "Jon", text: "Called to discuss the renewal timeline.", timeLabel: "1d ago" },
  { id: "3", who: "System", text: "Deal stage changed to Renewal.", timeLabel: "5d ago" },
];

describe("FindInRecord", () => {
  it("renders every entry", () => {
    render(<FindInRecord entries={ENTRIES} />);
    expect(screen.getByText(/Sent renewal proposal/)).toBeDefined();
    expect(screen.getByText(/Called to discuss/)).toBeDefined();
  });

  it("opens the find bar when the launcher is clicked", async () => {
    const user = userEvent.setup();
    render(<FindInRecord entries={ENTRIES} />);
    await user.click(screen.getByRole("button", { name: /find in page/i }));
    expect(screen.getByRole("search")).toBeDefined();
    expect(screen.getByLabelText("Find in record")).toBeDefined();
  });

  it("shows a match count while typing a query", async () => {
    const user = userEvent.setup();
    render(<FindInRecord entries={ENTRIES} />);
    await user.click(screen.getByRole("button", { name: /find in page/i }));
    await user.type(screen.getByLabelText("Find in record"), "renewal");
    expect(screen.getByText("1 / 3")).toBeDefined();
  });

  it("closes the find bar on Escape", async () => {
    const user = userEvent.setup();
    render(<FindInRecord entries={ENTRIES} />);
    await user.click(screen.getByRole("button", { name: /find in page/i }));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("search")).toBeNull();
  });
});
