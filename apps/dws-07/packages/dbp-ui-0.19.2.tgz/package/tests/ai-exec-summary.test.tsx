import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { AiExecSummary, type AiExecSummaryPoint } from "../src/components/ai-exec-summary.js";

afterEach(() => { cleanup(); });

const POINTS: AiExecSummaryPoint[] = [
  { text: "Revenue trending above plan.", tone: "good", cite: "Revenue vs target" },
];

describe("AiExecSummary", () => {
  it("renders the label, period, points, and citation", () => {
    render(<AiExecSummary period="Q3 to date" points={POINTS} />);
    expect(screen.getByText("AI-generated summary")).toBeDefined();
    expect(screen.getByText("Executive summary")).toBeDefined();
    expect(screen.getByText("Q3 to date")).toBeDefined();
    expect(screen.getByText("Revenue trending above plan.", { exact: false })).toBeDefined();
    expect(screen.getByText("Revenue vs target")).toBeDefined();
  });

  it("renders the outlook callout only when supplied", () => {
    const { rerender } = render(<AiExecSummary period="Q3" points={POINTS} outlook="Full-year lands at £34.6M." />);
    expect(screen.getByText("Full-year lands at £34.6M.")).toBeDefined();
    rerender(<AiExecSummary period="Q3" points={POINTS} />);
    expect(screen.queryByText("Forecast")).toBeNull();
  });

  it("fires onRefresh and onCiteOpen", () => {
    const onRefresh = vi.fn();
    const onCiteOpen = vi.fn();
    render(<AiExecSummary period="Q3" points={POINTS} onRefresh={onRefresh} onCiteOpen={onCiteOpen} />);
    fireEvent.click(screen.getByRole("button", { name: "Regenerate" }));
    expect(onRefresh).toHaveBeenCalled();
    fireEvent.click(screen.getByText("Revenue vs target"));
    expect(onCiteOpen).toHaveBeenCalledWith("Revenue vs target");
  });
});
