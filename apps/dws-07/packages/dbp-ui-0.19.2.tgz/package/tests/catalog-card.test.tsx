import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { CatalogCard } from "../src/components/catalog-card.js";

afterEach(() => {
  cleanup();
});

// ── MEDIA VARIANT (existing tests, preserved) ────────────────────────────────

describe("CatalogCard — media variant (default)", () => {
  it("renders title", () => {
    render(<CatalogCard title="Test Solution" />);
    expect(screen.getByText("Test Solution")).toBeDefined();
  });

  it("renders description when provided", () => {
    render(
      <CatalogCard
        title="Test Solution"
        description="This is a test description"
      />
    );
    expect(screen.getByText("This is a test description")).toBeDefined();
  });

  it("renders tags as badges", () => {
    render(
      <CatalogCard title="Test Solution" tags={["analytics", "data"]} />
    );
    expect(screen.getByText("analytics")).toBeDefined();
    expect(screen.getByText("data")).toBeDefined();
  });

  it("renders img when media is a string", () => {
    render(
      <CatalogCard
        title="Test Solution"
        media="https://example.com/image.jpg"
        mediaAlt="Solution image"
      />
    );
    const img = screen.getByRole("img");
    expect(img).toBeDefined();
    expect(img.getAttribute("src")).toBe("https://example.com/image.jpg");
    expect(img.getAttribute("alt")).toBe("Solution image");
  });

  it("uses title as alt text when mediaAlt is not provided", () => {
    render(
      <CatalogCard title="Test Solution" media="https://example.com/image.jpg" />
    );
    const img = screen.getByRole("img");
    expect(img.getAttribute("alt")).toBe("Test Solution");
  });

  it("renders status badge overlay when provided", () => {
    render(
      <CatalogCard
        title="Test Solution"
        statusBadge={{ label: "Beta", tone: "warning" }}
      />
    );
    expect(screen.getByText("Beta")).toBeDefined();
  });

  it("onClick fires on click", async () => {
    const user = userEvent.setup();
    let clicked = false;
    render(
      <CatalogCard
        title="Test Solution"
        onClick={() => {
          clicked = true;
        }}
      />
    );
    const card = screen.getByRole("button", { name: /Test Solution/i });
    await user.click(card);
    expect(clicked).toBe(true);
  });

  it("onClick fires on Enter key", async () => {
    const user = userEvent.setup();
    let clicked = false;
    render(
      <CatalogCard
        title="Test Solution"
        onClick={() => {
          clicked = true;
        }}
      />
    );
    const card = screen.getByRole("button", { name: /Test Solution/i });
    card.focus();
    await user.keyboard("{Enter}");
    expect(clicked).toBe(true);
  });

  it("onClick fires on Space key", async () => {
    const user = userEvent.setup();
    let clicked = false;
    render(
      <CatalogCard
        title="Test Solution"
        onClick={() => {
          clicked = true;
        }}
      />
    );
    const card = screen.getByRole("button", { name: /Test Solution/i });
    card.focus();
    await user.keyboard(" ");
    expect(clicked).toBe(true);
  });

  it("renders icon when media is a ReactNode", () => {
    render(
      <CatalogCard
        title="Test Solution"
        media={<div data-testid="icon">icon</div>}
      />
    );
    expect(screen.getByTestId("icon")).toBeDefined();
  });

  it("applies custom className", () => {
    render(
      <CatalogCard
        title="Test Solution"
        className="custom-class"
        data-testid="card"
      />
    );
    const card = screen.getByTestId("card");
    expect(card.className).toContain("custom-class");
  });
});

// ── CATALOG VARIANT (new tests) ──────────────────────────────────────────────

describe("CatalogCard — catalog variant", () => {
  it("renders typeLabel in header row", () => {
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        typeLabel="G · KNOWLEDGE"
      />
    );
    expect(screen.getByText("G · KNOWLEDGE")).toBeDefined();
  });

  it("renders statusLabel in header row", () => {
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        statusLabel="EFFECTIVE"
        statusTone="success"
      />
    );
    expect(screen.getByText("EFFECTIVE")).toBeDefined();
  });

  it("renders metaLine below header row", () => {
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        metaLine="5 MIN · EFFECTIVE"
      />
    );
    expect(screen.getByText("5 MIN · EFFECTIVE")).toBeDefined();
  });

  it("renders title", () => {
    render(
      <CatalogCard variant="catalog" title="Procurement Playbook" />
    );
    expect(screen.getByText("Procurement Playbook")).toBeDefined();
  });

  it("renders description", () => {
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        description="Defines the approval chain for all procurement requests."
      />
    );
    expect(
      screen.getByText("Defines the approval chain for all procurement requests.")
    ).toBeDefined();
  });

  it("renders footerId in footer row", () => {
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        footerId="KNO-001"
        onClick={() => {}}
      />
    );
    expect(screen.getByText("KNO-001")).toBeDefined();
  });

  it("does not render media area", () => {
    const { container } = render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        media="https://example.com/image.jpg"
      />
    );
    const img = container.querySelector("img");
    expect(img).toBeNull();
  });

  it("renders ArrowUpRight open button when onClick is provided", () => {
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        onClick={() => {}}
      />
    );
    expect(screen.getByRole("button", { name: /open procurement playbook/i })).toBeDefined();
  });

  it("onClick fires on card click", async () => {
    const user = userEvent.setup();
    let clicked = false;
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        onClick={() => {
          clicked = true;
        }}
      />
    );
    // The card itself has role="button" with aria-label=title
    const card = screen.getByRole("button", { name: "Procurement Playbook" });
    await user.click(card);
    expect(clicked).toBe(true);
  });

  it("onClick fires on Enter key", async () => {
    const user = userEvent.setup();
    let clicked = false;
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        onClick={() => {
          clicked = true;
        }}
      />
    );
    const card = screen.getByRole("button", { name: "Procurement Playbook" });
    card.focus();
    await user.keyboard("{Enter}");
    expect(clicked).toBe(true);
  });

  it("onClick fires on Space key", async () => {
    const user = userEvent.setup();
    let clicked = false;
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        onClick={() => {
          clicked = true;
        }}
      />
    );
    const card = screen.getByRole("button", { name: "Procurement Playbook" });
    card.focus();
    await user.keyboard(" ");
    expect(clicked).toBe(true);
  });

  it("onOpen fires separately from onClick when provided", async () => {
    const user = userEvent.setup();
    let cardClicked = false;
    let openCalled = false;
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        onClick={() => {
          cardClicked = true;
        }}
        onOpen={() => {
          openCalled = true;
        }}
      />
    );
    const openBtn = screen.getByRole("button", { name: /open procurement playbook/i });
    await user.click(openBtn);
    expect(openCalled).toBe(true);
    expect(cardClicked).toBe(false);
  });

  it("does not have role=button when onClick is absent", () => {
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
      />
    );
    // There should be no card-level button (only the open icon button if onClick given)
    // With no onClick, there is no role=button on the card div
    const buttons = screen.queryAllByRole("button");
    expect(buttons.length).toBe(0);
  });

  it("applies custom className", () => {
    render(
      <CatalogCard
        variant="catalog"
        title="Procurement Playbook"
        className="custom-class"
        data-testid="cat-card"
      />
    );
    const card = screen.getByTestId("cat-card");
    expect(card.className).toContain("custom-class");
  });
});
