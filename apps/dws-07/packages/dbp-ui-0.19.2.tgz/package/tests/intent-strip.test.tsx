import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { IntentStrip } from "../src/components/intent-strip.js";

afterEach(() => { cleanup(); });

describe("IntentStrip", () => {
  it("renders all four fields with their values", () => {
    render(
      <IntentStrip
        audience="CxO, board"
        decisions="Where to invest"
        questions="Are we on track?"
        mode="Monthly review"
      />,
    );
    expect(screen.getByText("Audience")).toBeDefined();
    expect(screen.getByText("CxO, board")).toBeDefined();
    expect(screen.getByText("Decisions supported")).toBeDefined();
    expect(screen.getByText("Where to invest")).toBeDefined();
    expect(screen.getByText("Questions answered")).toBeDefined();
    expect(screen.getByText("Are we on track?")).toBeDefined();
    expect(screen.getByText("Mode")).toBeDefined();
    expect(screen.getByText("Monthly review")).toBeDefined();
  });
});
