import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { PersonaSwitcher, type Persona } from "../src/components/persona-switcher.js";

afterEach(() => { cleanup(); });

const personas: Persona[] = [
  { id: "platform", label: "Platform administrator", description: "Full access" },
  { id: "business", label: "Business administrator", description: "Business settings" },
];

describe("PersonaSwitcher", () => {
  it("renders the active persona in the trigger", () => {
    render(<PersonaSwitcher personas={personas} value="platform" onChange={() => {}} />);
    expect(screen.getByText("Platform administrator")).toBeDefined();
  });

  it("opens the persona list on trigger click", async () => {
    const user = userEvent.setup();
    render(<PersonaSwitcher personas={personas} value="platform" onChange={() => {}} />);
    await user.click(screen.getByTitle("Switch admin persona"));
    expect(screen.getByText("Business administrator")).toBeDefined();
  });

  it("calls onChange with the selected persona id", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<PersonaSwitcher personas={personas} value="platform" onChange={onChange} />);
    await user.click(screen.getByTitle("Switch admin persona"));
    await user.click(screen.getByText("Business administrator"));
    expect(onChange).toHaveBeenCalledWith("business");
  });
});
