import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { EscalationCard } from "../src/components/escalation-card.js";

afterEach(() => { cleanup(); });

describe("EscalationCard", () => {
  it("renders an SLA escalation with title, detail, and escalatedTo badge", () => {
    render(
      <EscalationCard
        variant="sla"
        title="Approval step exceeded its SLA"
        detail="No action taken within the SLA window."
        escalatedTo="Finance Manager"
        when="2h ago"
      />,
    );
    expect(screen.getByText("SLA escalation")).toBeDefined();
    expect(screen.getByText("Approval step exceeded its SLA")).toBeDefined();
    expect(screen.getByText("Escalated to Finance Manager")).toBeDefined();
  });

  it("renders a manual escalation label", () => {
    render(<EscalationCard variant="manual" title="X" detail="Y" when="now" />);
    expect(screen.getByText("Manual escalation")).toBeDefined();
  });

  it("calls onResolve when Resolve is clicked", () => {
    let resolved = false;
    render(
      <EscalationCard variant="sla" title="X" detail="Y" when="now" onResolve={() => { resolved = true; }} />,
    );
    fireEvent.click(screen.getByTestId("escalation-resolve-button"));
    expect(resolved).toBe(true);
  });
});
