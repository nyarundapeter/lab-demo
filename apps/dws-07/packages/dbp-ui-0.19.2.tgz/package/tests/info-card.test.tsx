import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { InfoCard } from "../src/components/info-card.js";

afterEach(() => { cleanup(); });

describe("InfoCard", () => {
  it("renders the title, badge, rows, children, and actions", () => {
    render(
      <InfoCard
        tone="warning"
        title="Escalation"
        badge={<span>Severity: High</span>}
        rows={[{ label: "Reason", value: "SLA breach imminent" }]}
        actions={<button>Acknowledge</button>}
      >
        <p>Extra context</p>
      </InfoCard>,
    );
    expect(screen.getByText("Escalation")).toBeDefined();
    expect(screen.getByText("Severity: High")).toBeDefined();
    expect(screen.getByText("Reason")).toBeDefined();
    expect(screen.getByText("SLA breach imminent")).toBeDefined();
    expect(screen.getByText("Extra context")).toBeDefined();
    expect(screen.getByText("Acknowledge")).toBeDefined();
  });

  it("renders with no rows/children/actions (bare header)", () => {
    render(<InfoCard title="Dependency" />);
    expect(screen.getByText("Dependency")).toBeDefined();
  });
});
