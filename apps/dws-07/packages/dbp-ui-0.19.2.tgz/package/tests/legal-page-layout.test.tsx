import { describe, it, expect, beforeAll, afterEach } from "vitest"
import { render, screen, cleanup } from "@testing-library/react"
import { LegalPageLayout } from "../src/components/legal-page-layout.js"

const SECTIONS = [
  { id: "agreement", heading: "1. Agreement", body: ["By using this platform you agree."] },
  { id: "contact", heading: "2. Contact", body: ["Email us at info@digitalqatalyst.com any time."] },
]

beforeAll(() => {
  // jsdom has no IntersectionObserver; stub it so the effect can run.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ;(globalThis as any).IntersectionObserver = class {
    observe() {}
    disconnect() {}
    unobserve() {}
  }
})

afterEach(() => {
  cleanup()
})

describe("LegalPageLayout", () => {
  it("renders the title, subtitle and eyebrow", () => {
    render(
      <LegalPageLayout
        eyebrow="LEGAL"
        title="Terms of Use"
        subtitle="The terms governing your use."
        lastUpdated="June 2026"
        sections={SECTIONS}
      />,
    )
    expect(screen.getByText("Terms of Use")).toBeDefined()
    expect(screen.getByText("The terms governing your use.")).toBeDefined()
    expect(screen.getByText("LEGAL")).toBeDefined()
    expect(screen.getByText("Last updated: June 2026")).toBeDefined()
  })

  it("renders each section heading (TOC + body, hence multiple occurrences)", () => {
    render(
      <LegalPageLayout eyebrow="L" title="t" subtitle="s" lastUpdated="x" sections={SECTIONS} />,
    )
    expect(screen.getAllByText("1. Agreement").length).toBeGreaterThanOrEqual(1)
  })

  it("linkifies the contactEmail when present in a paragraph", () => {
    render(
      <LegalPageLayout
        eyebrow="L"
        title="t"
        subtitle="s"
        lastUpdated="x"
        sections={SECTIONS}
        contactEmail="info@digitalqatalyst.com"
      />,
    )
    const link = screen.getByText("info@digitalqatalyst.com").closest("a") as HTMLAnchorElement
    expect(link.getAttribute("href")).toBe("mailto:info@digitalqatalyst.com")
  })

  it("renders the email as plain text when contactEmail is omitted", () => {
    render(
      <LegalPageLayout eyebrow="L" title="t" subtitle="s" lastUpdated="x" sections={SECTIONS} />,
    )
    const node = screen.getByText(/info@digitalqatalyst.com/)
    expect(node.closest("a")).toBeNull()
  })
})
