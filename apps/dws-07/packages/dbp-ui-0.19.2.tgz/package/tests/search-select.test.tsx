import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { SearchSelect } from "../src/components/search-select.js";
import type { SearchSelectOption } from "../src/components/search-select.js";

afterEach(() => { cleanup(); });

const OPTIONS: SearchSelectOption[] = [
  { value: "ava", label: "Ava Stone" },
  { value: "ben", label: "Ben Carter" },
  { value: "cara", label: "Cara Nolan" },
];

describe("SearchSelect", () => {
  it("shows the placeholder when nothing is selected", () => {
    render(<SearchSelect options={OPTIONS} placeholder="Pick a person" />);
    expect(screen.getByText("Pick a person")).toBeDefined();
  });

  it("shows the selected option's label on the trigger", () => {
    render(<SearchSelect options={OPTIONS} value="ben" />);
    expect(screen.getByText("Ben Carter")).toBeDefined();
  });

  it("opens the option list on trigger click", async () => {
    const user = userEvent.setup();
    render(<SearchSelect options={OPTIONS} />);
    await user.click(screen.getByRole("button"));
    expect(screen.getByRole("listbox")).toBeDefined();
    expect(screen.getByRole("option", { name: "Ava Stone" })).toBeDefined();
    expect(screen.getByRole("option", { name: "Ben Carter" })).toBeDefined();
  });

  it("filters the option list as the search query changes", async () => {
    const user = userEvent.setup();
    render(<SearchSelect options={OPTIONS} searchPlaceholder="Search…" />);
    await user.click(screen.getByRole("button"));
    await user.type(screen.getByPlaceholderText("Search…"), "nolan");
    expect(screen.getByRole("option", { name: "Cara Nolan" })).toBeDefined();
    expect(screen.queryByRole("option", { name: "Ava Stone" })).toBeNull();
    expect(screen.queryByRole("option", { name: "Ben Carter" })).toBeNull();
  });

  it("shows the empty-state text when no option matches", async () => {
    const user = userEvent.setup();
    render(<SearchSelect options={OPTIONS} emptyText="Nobody found." />);
    await user.click(screen.getByRole("button"));
    await user.type(screen.getByPlaceholderText("Search…"), "zzz");
    expect(screen.getByText("Nobody found.")).toBeDefined();
  });

  it("calls onValueChange and closes the list when an option is selected", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<SearchSelect options={OPTIONS} onValueChange={onValueChange} />);
    await user.click(screen.getByRole("button"));
    await user.click(screen.getByRole("option", { name: "Cara Nolan" }));
    expect(onValueChange).toHaveBeenCalledWith("cara");
    expect(screen.queryByRole("listbox")).toBeNull();
  });

  it("marks the selected option with aria-selected", async () => {
    const user = userEvent.setup();
    render(<SearchSelect options={OPTIONS} value="ben" />);
    await user.click(screen.getByRole("button"));
    expect(screen.getByRole("option", { name: "Ben Carter" }).getAttribute("aria-selected")).toBe("true");
    expect(screen.getByRole("option", { name: "Ava Stone" }).getAttribute("aria-selected")).toBe("false");
  });

  it("disables the trigger when disabled is set", () => {
    render(<SearchSelect options={OPTIONS} disabled />);
    expect((screen.getByRole("button") as HTMLButtonElement).disabled).toBe(true);
  });
});
