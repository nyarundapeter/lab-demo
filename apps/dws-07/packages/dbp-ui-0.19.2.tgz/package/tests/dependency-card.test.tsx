import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { DependencyCard } from "../src/components/dependency-card.js";

afterEach(() => { cleanup(); });

describe("DependencyCard", () => {
  it("renders a blocking dependency", () => {
    render(<DependencyCard direction="blocking" recordLabel="PR-1042 Vendor onboarding" statusLabel="In review" />);
    expect(screen.getByText("Blocking")).toBeDefined();
    expect(screen.getByText("PR-1042 Vendor onboarding")).toBeDefined();
    expect(screen.getByText("In review")).toBeDefined();
  });

  it("renders a blocked-by dependency", () => {
    render(<DependencyCard direction="blocked-by" recordLabel="INV-9001" />);
    expect(screen.getByText("Blocked by")).toBeDefined();
  });

  it("renders the record label as a button and calls onNavigate when clicked", () => {
    let navigated = false;
    render(
      <DependencyCard direction="blocking" recordLabel="X" onNavigate={() => { navigated = true; }} />,
    );
    fireEvent.click(screen.getByTestId("dependency-navigate-button"));
    expect(navigated).toBe(true);
  });
});
