import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Wrench } from "lucide-react";
import { CenteredNotice } from "../src/components/centered-notice.js";

afterEach(() => { cleanup(); });

describe("CenteredNotice", () => {
  it("renders icon, kicker, title, body, actions, footer, and brand", () => {
    render(
      <CenteredNotice
        icon={Wrench}
        tone="brand"
        brand={{ name: "Workspace" }}
        kicker="SCHEDULED MAINTENANCE"
        title="We'll be right back"
        actions={<button>Retry now</button>}
        footer="Follow the status page"
      >
        Back shortly.
      </CenteredNotice>,
    );
    expect(screen.getByText("Workspace")).toBeDefined();
    expect(screen.getByText("SCHEDULED MAINTENANCE")).toBeDefined();
    expect(screen.getByText("We'll be right back")).toBeDefined();
    expect(screen.getByText("Back shortly.")).toBeDefined();
    expect(screen.getByRole("button", { name: "Retry now" })).toBeDefined();
    expect(screen.getByText("Follow the status page")).toBeDefined();
  });

  it("renders without optional brand/actions/footer", () => {
    render(
      <CenteredNotice icon={Wrench} title="Time for an update">
        Please update.
      </CenteredNotice>,
    );
    expect(screen.getByText("Time for an update")).toBeDefined();
  });
});
