import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { AiActionCard } from "../src/components/ai-action-card.js";

afterEach(() => { cleanup(); });

describe("AiActionCard", () => {
  it("renders the label, title, badge, and fields", () => {
    render(
      <AiActionCard
        label={<span>AI action</span>}
        badge={<span>Medium risk</span>}
        title="Example title"
        fields={[
          { label: "Records affected", value: "12 of 340" },
          { label: "Owner", value: "Data Engineering" },
        ]}
      />,
    );
    expect(screen.getByText("AI action")).toBeDefined();
    expect(screen.getByText("Medium risk")).toBeDefined();
    expect(screen.getByText("Example title")).toBeDefined();
    expect(screen.getByText("Records affected")).toBeDefined();
    expect(screen.getByText("12 of 340")).toBeDefined();
  });

  it("renders inline footer content without a wrapper section when footerFullWidth is false", () => {
    render(<AiActionCard label="AI action" title="Title" fields={[]} footer={<span>Inline footer</span>} />);
    expect(screen.getByText("Inline footer")).toBeDefined();
  });

  it("renders footer content inside a full-width bordered section when footerFullWidth is true", () => {
    const { container } = render(
      <AiActionCard label="AI action" title="Title" fields={[]} footerFullWidth footer={<span>Full-width footer</span>} />,
    );
    expect(screen.getByText("Full-width footer")).toBeDefined();
    expect(container.querySelector(".border-t")).not.toBeNull();
  });

  it("renders the optional icon and note", () => {
    render(
      <AiActionCard
        icon={<span data-testid="icon">icon</span>}
        label="AI action"
        title="Title"
        fields={[]}
        note={<span>Heads up</span>}
      />,
    );
    expect(screen.getByTestId("icon")).toBeDefined();
    expect(screen.getByText("Heads up")).toBeDefined();
  });
});
