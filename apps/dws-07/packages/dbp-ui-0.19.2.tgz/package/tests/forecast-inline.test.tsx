import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { ForecastInline } from "../src/components/forecast-inline.js";

afterEach(() => { cleanup(); });

describe("ForecastInline", () => {
  it("renders the default label and the forecast text", () => {
    render(<ForecastInline text="Backlog reaches ~290 in 2 weeks." />);
    expect(screen.getByText("Forecast")).toBeDefined();
    expect(screen.getByText("Backlog reaches ~290 in 2 weeks.")).toBeDefined();
  });

  it("renders a custom label", () => {
    render(<ForecastInline label="Projected" text="Volume up 12%." />);
    expect(screen.getByText("Projected")).toBeDefined();
  });
});
