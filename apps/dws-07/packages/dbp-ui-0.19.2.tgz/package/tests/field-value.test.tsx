import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { FieldValue } from "../src/components/field-value.js";

afterEach(() => { cleanup(); });

describe("FieldValue", () => {
  it("renders an em-dash for null, undefined, and empty-string values", () => {
    render(<FieldValue value={null} format="text" />);
    expect(screen.getByText("—")).toBeDefined();
    cleanup();

    render(<FieldValue value={undefined} format="text" />);
    expect(screen.getByText("—")).toBeDefined();
    cleanup();

    render(<FieldValue value="" format="number" />);
    expect(screen.getByText("—")).toBeDefined();
  });

  it("renders plain text for the default/text format", () => {
    render(<FieldValue value="Acme Co" format="text" />);
    expect(screen.getByText("Acme Co")).toBeDefined();
  });

  it("formats a numeric value with locale grouping", () => {
    render(<FieldValue value={38000} format="number" />);
    expect(screen.getByText("38,000")).toBeDefined();
  });

  it("falls back to the raw string for a non-numeric 'number' value", () => {
    render(<FieldValue value="not-a-number" format="number" />);
    expect(screen.getByText("not-a-number")).toBeDefined();
  });

  it("formats a valid date value", () => {
    render(<FieldValue value="2026-01-15" format="date" />);
    expect(screen.queryByText("2026-01-15")).toBeNull();
  });

  it("falls back to the raw string for an invalid date value", () => {
    render(<FieldValue value="not-a-date" format="date" />);
    expect(screen.getByText("not-a-date")).toBeDefined();
  });

  it("renders a Badge for the badge format", () => {
    render(<FieldValue value="Active" format="badge" />);
    expect(screen.getByText("Active")).toBeDefined();
  });
});
