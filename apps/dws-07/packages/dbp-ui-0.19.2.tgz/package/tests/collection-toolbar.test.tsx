import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { CollectionToolbar } from "../src/components/collection-toolbar.js";

afterEach(() => { cleanup(); });

describe("CollectionToolbar", () => {
  it("renders status tabs, search, result count and actions", () => {
    render(
      <CollectionToolbar
        statusOptions={[
          { value: "all", label: "All", count: 128 },
          { value: "open", label: "Open", count: 32 },
        ]}
        statusValue="all"
        onStatusChange={() => {}}
        searchValue=""
        onSearchChange={() => {}}
        resultCount="128 results"
        actions={<button type="button">Export</button>}
      />
    );
    expect(screen.getByText("All")).toBeDefined();
    expect(screen.getByText("Open")).toBeDefined();
    expect(screen.getByText("128 results")).toBeDefined();
    expect(screen.getByText("Export")).toBeDefined();
  });

  it("renders removable chips and calls onRemove when the remove button is clicked", async () => {
    const user = userEvent.setup();
    const onRemove = vi.fn();
    render(
      <CollectionToolbar
        chips={[{ key: "priority-high", label: "Priority: High", onRemove }]}
      />
    );
    const removeBtn = screen.getByRole("button", { name: "Remove filter: Priority: High" });
    await user.click(removeBtn);
    expect(onRemove).toHaveBeenCalledTimes(1);
  });

  it("calls onClearAll when Clear all is clicked", async () => {
    const user = userEvent.setup();
    const onClearAll = vi.fn();
    render(
      <CollectionToolbar
        chips={[{ key: "priority-high", label: "Priority: High", onRemove: () => {} }]}
        onClearAll={onClearAll}
      />
    );
    await user.click(screen.getByText("Clear all"));
    expect(onClearAll).toHaveBeenCalledTimes(1);
  });
});
