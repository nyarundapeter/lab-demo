import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { AiSteps, AiThinking, type AiStep } from "../src/components/ai-steps.js";

afterEach(() => { cleanup(); });

const STEPS: AiStep[] = [
  { label: "Reading case history", state: "done" },
  { label: "Querying related tickets", state: "active" },
  { label: "Composing summary", state: "pending" },
];

describe("AiThinking", () => {
  it("renders the default label with role=status", () => {
    render(<AiThinking />);
    expect(screen.getByRole("status")).toBeDefined();
    expect(screen.getByText("Thinking…")).toBeDefined();
  });

  it("renders a custom label", () => {
    render(<AiThinking label="Summarising" />);
    expect(screen.getByText("Summarising…")).toBeDefined();
  });
});

describe("AiSteps", () => {
  it("renders every step's label", () => {
    render(<AiSteps steps={STEPS} />);
    expect(screen.getByText("Reading case history")).toBeDefined();
    expect(screen.getByText("Querying related tickets")).toBeDefined();
    expect(screen.getByText("Composing summary")).toBeDefined();
  });

  it("renders with role=status for live-region reasoning updates", () => {
    render(<AiSteps steps={STEPS} />);
    expect(screen.getByRole("status")).toBeDefined();
  });
});
