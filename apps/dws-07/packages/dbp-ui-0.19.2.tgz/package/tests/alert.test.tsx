import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Alert } from "../src/components/alert.js";

afterEach(() => { cleanup(); });

describe("Alert", () => {
  it("renders with role=alert", () => {
    render(<Alert tone="danger" title="Error occurred">Details here</Alert>);
    expect(screen.getByRole("alert")).toBeDefined();
    expect(screen.getByText("Error occurred")).toBeDefined();
  });

  it("renders all tones", () => {
    const tones = ["info", "success", "warning", "danger"] as const;
    for (const tone of tones) {
      const { unmount } = render(<Alert tone={tone} data-testid="al">{tone}</Alert>);
      expect(screen.getByTestId("al")).toBeDefined();
      unmount();
    }
  });

  it("dismisses when dismissible and close is clicked", async () => {
    const user = userEvent.setup();
    render(<Alert dismissible tone="info">Alert content</Alert>);
    expect(screen.getByText("Alert content")).toBeDefined();
    await user.click(screen.getByLabelText("Dismiss alert"));
    expect(screen.queryByText("Alert content")).toBeNull();
  });
});
