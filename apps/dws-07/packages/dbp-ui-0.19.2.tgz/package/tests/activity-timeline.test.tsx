import * as React from "react";
import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ActivityTimeline } from "../src/components/activity-timeline.js";
import type { ActivityEntry, ActivityTimelineConfig } from "../src/schemas/activity.js";

afterEach(() => { cleanup(); });

const CONFIG: ActivityTimelineConfig = {
  activityTypes: {
    note: { icon: "note", tone: "warning", label: "Note" },
    call: { icon: "phone", tone: "success", label: "Call" },
  },
  mentions: false,
  tags: true,
  attachments: true,
};

const ENTRIES: ActivityEntry[] = [
  {
    id: "e1",
    type: "note",
    actorName: "Diego Ruiz",
    timestamp: new Date(Date.now() - 60_000).toISOString(),
    bodyText: "Champion confirmed budget.",
    tags: ["budget"],
  },
  {
    id: "e2",
    type: "call",
    actorName: "Tomas Berg",
    timestamp: new Date(Date.now() - 2 * 60_000).toISOString(),
    bodyText: "Confirmed rollout timeline.",
    tags: ["timeline"],
    attachments: [{ id: "a1", name: "notes.pdf", sizeKb: 42 }],
  },
];

describe("ActivityTimeline", () => {
  it("renders every entry with actor and body text", () => {
    render(<ActivityTimeline config={CONFIG} state="populated" entries={ENTRIES} />);
    expect(screen.getByText("Diego Ruiz")).toBeDefined();
    expect(screen.getByText("Champion confirmed budget.")).toBeDefined();
    expect(screen.getByText("Tomas Berg")).toBeDefined();
  });

  it("falls back to a neutral chip for an unmapped activity type", () => {
    const entries: ActivityEntry[] = [
      { id: "e3", type: "legacy_import", actorName: "Migration Bot", timestamp: new Date().toISOString(), bodyText: "Imported." },
    ];
    render(<ActivityTimeline config={CONFIG} state="populated" entries={entries} />);
    expect(screen.getByText(/unrecognised type/i)).toBeDefined();
  });

  it("shows the loading skeleton", () => {
    render(<ActivityTimeline config={CONFIG} state="loading" entries={ENTRIES} />);
    expect(screen.queryByText("Diego Ruiz")).toBeNull();
  });

  it("shows the empty state", () => {
    render(<ActivityTimeline config={CONFIG} state="empty" />);
    expect(screen.getByText(/no activity yet/i)).toBeDefined();
  });

  it("shows the error state and calls onRetry", async () => {
    const user = userEvent.setup();
    const onRetry = vi.fn();
    render(<ActivityTimeline config={CONFIG} state="error" onRetry={onRetry} />);
    await user.click(screen.getByRole("button", { name: /retry/i }));
    expect(onRetry).toHaveBeenCalledOnce();
  });

  it("does not render a connector line after the last entry", () => {
    const { container } = render(<ActivityTimeline config={CONFIG} state="populated" entries={[ENTRIES[0]!]} />);
    expect(container.querySelectorAll("li").length).toBe(1);
    expect(container.querySelector("[data-activity-connector]")).toBeNull();
  });

  it("filters entries by tag when a filter chip is toggled", async () => {
    const user = userEvent.setup();
    render(<ActivityTimeline config={CONFIG} state="populated" entries={ENTRIES} />);
    await user.click(screen.getByRole("button", { name: /budget/i }));
    expect(screen.getByText("Diego Ruiz")).toBeDefined();
    expect(screen.queryByText("Tomas Berg")).toBeNull();
  });

  it("calls onDownloadAttachment when an attachment chip is clicked", async () => {
    const user = userEvent.setup();
    const onDownload = vi.fn();
    render(<ActivityTimeline config={CONFIG} state="populated" entries={ENTRIES} onDownloadAttachment={onDownload} />);
    await user.click(screen.getByRole("button", { name: /notes.pdf/i }));
    expect(onDownload).toHaveBeenCalledWith("a1");
  });
});
