import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Ranking } from "../src/components/ranking.js";

afterEach(() => { cleanup(); });

describe("Ranking", () => {
  it("renders each item's position, name, and formatted value", () => {
    render(
      <Ranking
        items={[
          { name: "Amara Chen", value: 100 },
          { name: "Marcus Osei", value: 80 },
        ]}
        format={(v) => `${v} pts`}
      />,
    );
    expect(screen.getByText("1")).toBeDefined();
    expect(screen.getByText("2")).toBeDefined();
    expect(screen.getByText("Amara Chen")).toBeDefined();
    expect(screen.getByText("100 pts")).toBeDefined();
  });

  it("renders an avatar only when item.avatar is true", () => {
    const { container } = render(
      <Ranking items={[{ name: "Amara Chen", value: 1, avatar: true }]} />,
    );
    expect(container.querySelector("[role='img']")).not.toBeNull();
  });
});
