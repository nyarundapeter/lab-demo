import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Checkbox } from "../src/components/checkbox.js";

afterEach(() => { cleanup(); });

describe("Checkbox", () => {
  it("renders as a checkbox role", () => {
    render(<Checkbox aria-label="Accept terms" />);
    expect(screen.getByRole("checkbox", { name: "Accept terms" })).toBeDefined();
  });

  it("is checked when defaultChecked is true", () => {
    render(<Checkbox aria-label="Checked" defaultChecked />);
    const cb = screen.getByRole("checkbox") as HTMLButtonElement;
    expect(cb.getAttribute("data-state")).toBe("checked");
  });

  it("is disabled when disabled prop set", () => {
    render(<Checkbox aria-label="Disabled" disabled />);
    expect((screen.getByRole("checkbox") as HTMLButtonElement).disabled).toBe(true);
  });
});
