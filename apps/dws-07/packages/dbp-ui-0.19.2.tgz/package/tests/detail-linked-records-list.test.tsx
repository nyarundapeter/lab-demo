import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import {
  DetailLinkedRecordsList,
  DetailStatusText,
  DetailChip,
  standardLinkedRecordColumns,
} from "../src/components/detail-linked-records-list.js";

afterEach(() => {
  cleanup();
});

const records = [
  { id: "1", primary: "Encryption at rest control", secondary: "CTL-0142", badge: { label: "effective", tone: "success" as const } },
  { id: "2", primary: "Access review control", secondary: "CTL-0198", badge: { label: "partially-effective", tone: "warning" as const } },
];

describe("DetailLinkedRecordsList", () => {
  it("renders records in list variant", () => {
    render(<DetailLinkedRecordsList records={records} />);
    expect(screen.getByText("Encryption at rest control")).toBeDefined();
    expect(screen.getByText("Partially effective")).toBeDefined();
  });

  it("renders records in table variant with standard columns", () => {
    render(<DetailLinkedRecordsList records={records} variant="table" columns={standardLinkedRecordColumns()} />);
    expect(screen.getByText("Record")).toBeDefined();
    expect(screen.getByText("Status")).toBeDefined();
    expect(screen.getByText("Access review control")).toBeDefined();
  });

  it("renders the empty state", () => {
    render(<DetailLinkedRecordsList records={[]} emptyTitle="No linked records" emptyDescription="Nothing yet." />);
    expect(screen.getByText("No linked records")).toBeDefined();
    expect(screen.getByText("Nothing yet.")).toBeDefined();
  });

  it("renders a loading state", () => {
    render(<DetailLinkedRecordsList records={[]} isLoading />);
    expect(screen.getByText("Loading…")).toBeDefined();
  });
});

describe("DetailStatusText / DetailChip", () => {
  it("renders children with a tone class", () => {
    render(<DetailStatusText tone="danger">Not effective</DetailStatusText>);
    expect(screen.getByText("Not effective")).toBeDefined();
  });

  it("DetailChip renders as status text", () => {
    render(<DetailChip tone="gray">Privacy</DetailChip>);
    expect(screen.getByText("Privacy")).toBeDefined();
  });
});
