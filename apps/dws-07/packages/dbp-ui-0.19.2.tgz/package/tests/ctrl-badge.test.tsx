import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { CtrlBadge } from "../src/components/ctrl-badge.js";

afterEach(() => { cleanup(); });

describe("CtrlBadge", () => {
  it("defaults to level 1 (Inform) with the numeric prefix", () => {
    render(<CtrlBadge />);
    expect(screen.getByText("Inform")).toBeDefined();
    expect(screen.getByText("L1")).toBeDefined();
  });

  it("renders each control level's label", () => {
    render(<CtrlBadge level={2} />);
    expect(screen.getByText("Recommend")).toBeDefined();
    cleanup();

    render(<CtrlBadge level={3} />);
    expect(screen.getByText("Prepare")).toBeDefined();
    cleanup();

    render(<CtrlBadge level={4} />);
    expect(screen.getByText("Automate")).toBeDefined();
  });

  it("hides the numeric prefix when showNum is false", () => {
    render(<CtrlBadge level={2} showNum={false} />);
    expect(screen.queryByText("L2")).toBeNull();
    expect(screen.getByText("Recommend")).toBeDefined();
  });

  it("renders custom children instead of the default label", () => {
    render(<CtrlBadge level={1}>Custom label</CtrlBadge>);
    expect(screen.getByText("Custom label")).toBeDefined();
    expect(screen.queryByText("Inform")).toBeNull();
  });

  it("shows a 'Human decision only' qualifier when humanDecisionOnly is set", () => {
    render(<CtrlBadge level={4} humanDecisionOnly />);
    expect(screen.getByText("Human decision only")).toBeDefined();
  });

  it("omits the qualifier by default", () => {
    render(<CtrlBadge level={4} />);
    expect(screen.queryByText("Human decision only")).toBeNull();
  });
});
