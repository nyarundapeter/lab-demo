import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { AiLabel, AI_LABEL, type AiLabelKind } from "../src/components/ai-label.js";

afterEach(() => { cleanup(); });

describe("AiLabel", () => {
  it("defaults to the generated kind", () => {
    render(<AiLabel />);
    expect(screen.getByText("AI-generated")).toBeDefined();
  });

  it("renders the default text for every kind", () => {
    for (const kind of Object.keys(AI_LABEL) as AiLabelKind[]) {
      const { unmount } = render(<AiLabel kind={kind} />);
      expect(screen.getByText(AI_LABEL[kind].text)).toBeDefined();
      unmount();
    }
  });

  it("overrides the default text with a custom label", () => {
    render(<AiLabel kind="summary" text="AI-generated case summary" />);
    expect(screen.getByText("AI-generated case summary")).toBeDefined();
    expect(screen.queryByText("AI-generated summary")).toBeNull();
  });

  it("renders human-provenance kinds without the AI badge tone", () => {
    render(<AiLabel kind="confirmed" />);
    expect(screen.getByText("User-confirmed")).toBeDefined();
  });
});
