import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Heatmap } from "../src/components/heatmap.js";

afterEach(() => { cleanup(); });

const colorFor = (v: number) => ({ bg: v > 2 ? "red" : "green", fg: "#fff" });

describe("Heatmap", () => {
  it("renders a role=img table with the given aria-label", () => {
    render(
      <Heatmap
        rows={["A", "B"]}
        cols={["X", "Y"]}
        data={[[1, 2], [3, 4]]}
        colorFor={colorFor}
        ariaLabel="Test heatmap"
      />,
    );
    expect(screen.getByRole("img", { name: "Test heatmap" })).toBeDefined();
  });

  it("renders one cell per row/col combination with its numeric value as text", () => {
    render(
      <Heatmap
        rows={["A", "B"]}
        cols={["X", "Y"]}
        data={[[1, 2], [3, 4]]}
        colorFor={colorFor}
      />,
    );
    expect(screen.getByTestId("heatmap-cell-0-0").textContent).toBe("1");
    expect(screen.getByTestId("heatmap-cell-1-1").textContent).toBe("4");
  });

  it("applies colorFor's bg/fg to each cell (never colour-alone — text is always present)", () => {
    render(
      <Heatmap
        rows={["A"]}
        cols={["X"]}
        data={[[5]]}
        colorFor={colorFor}
      />,
    );
    const cell = screen.getByTestId("heatmap-cell-0-0");
    expect(cell.style.background).toBe("red");
    expect(cell.textContent).toBe("5");
  });
});
