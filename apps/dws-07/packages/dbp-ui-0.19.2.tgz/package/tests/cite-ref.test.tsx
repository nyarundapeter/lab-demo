import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { CiteRef } from "../src/components/cite-ref.js";

afterEach(() => { cleanup(); });

describe("CiteRef", () => {
  it("renders the citation number and a descriptive aria-label", () => {
    render(<CiteRef n={3} />);
    expect(screen.getByText("3")).toBeDefined();
    expect(screen.getByRole("button", { name: "Source 3" })).toBeDefined();
  });

  it("calls onOpen with the citation number when clicked", async () => {
    const user = userEvent.setup();
    const onOpen = vi.fn();
    render(<CiteRef n={2} onOpen={onOpen} />);
    await user.click(screen.getByRole("button", { name: "Source 2" }));
    expect(onOpen).toHaveBeenCalledWith(2);
  });
});
