import { describe, it, expect } from "vitest"
import { render, screen } from "@testing-library/react"
import { LandingCta } from "../src/components/landing-sections.js"

describe("LandingCta", () => {
  it("renders the headline and accent", () => {
    render(<LandingCta headline="Ready to go?" headlineAccent="Start now." />)
    expect(screen.getByText("Ready to go?", { exact: false })).toBeDefined()
    expect(screen.getByText("Start now.")).toBeDefined()
  })

  it("renders the primary CTA link", () => {
    render(<LandingCta primaryCta={{ label: "Get Started", href: "/signup" }} />)
    const link = screen.getByText("Get Started").closest("a") as HTMLAnchorElement
    expect(link.getAttribute("href")).toBe("/signup")
  })

  it("renders the ctaOrange mesh background via MeshSection", () => {
    const { container } = render(<LandingCta />)
    const meshLayer = container.querySelector("[aria-hidden]") as HTMLElement
    expect(meshLayer.style.background).toContain("--mesh-cta-orange")
  })
})
