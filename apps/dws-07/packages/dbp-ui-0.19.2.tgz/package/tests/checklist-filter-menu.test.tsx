import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ChecklistFilterMenu } from "../src/components/checklist-filter-menu.js";

afterEach(() => {
  cleanup();
});

const OPTIONS = [
  { value: "high", label: "High" },
  { value: "critical", label: "Critical" },
];

describe("ChecklistFilterMenu", () => {
  it("shows the selected count on the trigger", () => {
    render(
      <ChecklistFilterMenu triggerLabel="Priority" options={OPTIONS} values={["high"]} onValuesChange={vi.fn()} />,
    );
    expect(screen.getByRole("button", { name: /priority · 1/i })).toBeDefined();
  });

  it("toggles a value on click without closing the menu", async () => {
    const user = userEvent.setup();
    const onValuesChange = vi.fn();
    render(
      <ChecklistFilterMenu triggerLabel="Priority" options={OPTIONS} values={[]} onValuesChange={onValuesChange} />,
    );
    await user.click(screen.getByRole("button", { name: /priority/i }));
    await user.click(screen.getByText("High"));
    expect(onValuesChange).toHaveBeenCalledWith(["high"]);
  });

  it("renders an Apply/Clear footer only when onApply is supplied", async () => {
    const user = userEvent.setup();
    render(
      <ChecklistFilterMenu
        triggerLabel="Priority"
        options={OPTIONS}
        values={[]}
        onValuesChange={vi.fn()}
        onApply={vi.fn()}
      />,
    );
    await user.click(screen.getByRole("button", { name: /priority/i }));
    expect(screen.getByRole("button", { name: "Apply" })).toBeDefined();
    expect(screen.getByRole("button", { name: "Clear" })).toBeDefined();
  });
});
