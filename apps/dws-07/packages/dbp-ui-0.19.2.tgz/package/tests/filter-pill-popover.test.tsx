import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { FilterPillPopover } from "../src/components/filter-pill-popover.js";

afterEach(() => {
  cleanup();
});

describe("FilterPillPopover", () => {
  it("renders the trigger label and opens the popover body on click", async () => {
    const user = userEvent.setup();
    render(
      <FilterPillPopover label="Assign owner">
        <p>Owner picker content</p>
      </FilterPillPopover>,
    );
    expect(screen.queryByText("Owner picker content")).toBeNull();

    await user.click(screen.getByRole("button", { name: /assign owner/i }));
    expect(screen.getByText("Owner picker content")).toBeDefined();
  });

  it("marks the trigger active via aria-pressed", () => {
    render(
      <FilterPillPopover label="Assign owner" active>
        <p>content</p>
      </FilterPillPopover>,
    );
    expect(screen.getByRole("button", { name: /assign owner/i }).getAttribute("aria-pressed")).toBe("true");
  });
});
