import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { FeedbackControl } from "../src/components/feedback-control.js";

afterEach(() => { cleanup(); });

describe("FeedbackControl", () => {
  it("renders the 'Helpful?' label and both rating buttons by default", () => {
    render(<FeedbackControl />);
    expect(screen.getByText("Helpful?")).toBeDefined();
    expect(screen.getByRole("button", { name: "Helpful" })).toBeDefined();
    expect(screen.getByRole("button", { name: "Not helpful" })).toBeDefined();
  });

  it("hides the leading label when compact", () => {
    render(<FeedbackControl compact />);
    expect(screen.queryByText("Helpful?")).toBeNull();
  });

  it("shows a thank-you message and calls onChange('up') after a positive rating", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<FeedbackControl onChange={onChange} />);
    await user.click(screen.getByRole("button", { name: "Helpful" }));
    expect(onChange).toHaveBeenCalledWith("up");
    expect(screen.getByText("Thanks for the feedback")).toBeDefined();
    expect(screen.queryByRole("button", { name: "Helpful" })).toBeNull();
  });

  it("opens a reason picker after a negative rating and calls onChange('down', reason)", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<FeedbackControl onChange={onChange} />);
    await user.click(screen.getByRole("button", { name: "Not helpful" }));
    expect(screen.getByText("What was wrong?")).toBeDefined();

    await user.click(screen.getByText("Outdated"));
    expect(onChange).toHaveBeenCalledWith("down", "Outdated");
    expect(screen.queryByText("What was wrong?")).toBeNull();
  });
});
