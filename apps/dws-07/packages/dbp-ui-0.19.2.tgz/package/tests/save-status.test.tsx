import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { SaveStatus } from "../src/components/save-status.js";

afterEach(() => { cleanup(); });

describe("SaveStatus", () => {
  it("renders nothing for idle", () => {
    const { container } = render(<SaveStatus status="idle" />);
    expect(container.firstChild).toBeNull();
  });

  it("shows 'Saving…' while saving", () => {
    render(<SaveStatus status="saving" />);
    expect(screen.getByText("Saving…")).toBeDefined();
  });

  it("shows 'All changes saved' when saved without a time", () => {
    render(<SaveStatus status="saved" />);
    expect(screen.getByText("All changes saved")).toBeDefined();
  });

  it("shows the saved time when provided", () => {
    render(<SaveStatus status="saved" savedAt="just now" />);
    expect(screen.getByText("Saved just now")).toBeDefined();
  });

  it("shows the default error text", () => {
    render(<SaveStatus status="error" />);
    expect(screen.getByText("Save failed — retry")).toBeDefined();
  });

  it("shows a custom error label", () => {
    render(<SaveStatus status="error" errorLabel="Couldn't save. Try again." />);
    expect(screen.getByText("Couldn't save. Try again.")).toBeDefined();
  });
});
