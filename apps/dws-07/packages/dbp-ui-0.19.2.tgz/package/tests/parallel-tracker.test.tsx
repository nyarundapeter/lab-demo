import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { ParallelTracker } from "../src/components/parallel-tracker.js";
import type { ParallelBranch } from "../src/components/parallel-tracker.js";

afterEach(() => { cleanup(); });

const BRANCHES: ParallelBranch[] = [
  { id: "a", label: "IT provisioning", status: "done", percent: 100, ownerLabel: "Ava Okafor", dueLabel: "Jul 10" },
  { id: "b", label: "Security training", status: "active", percent: 40, ownerLabel: "Milo Chen", dueLabel: "Jul 14" },
  { id: "c", label: "Facilities badge", status: "blocked", percent: 0, ownerLabel: "Tom Reyes", dueLabel: "Jul 12", note: "Waiting on ID photo" },
];

describe("ParallelTracker", () => {
  it("renders every branch and the completion count", () => {
    render(<ParallelTracker branches={BRANCHES} rule="2 of 3 must complete" />);
    expect(screen.getAllByTestId("parallel-branch")).toHaveLength(3);
    expect(screen.getByText("IT provisioning")).toBeDefined();
    expect(screen.getByText("1/3 complete")).toBeDefined();
    expect(screen.getByText("2 of 3 must complete")).toBeDefined();
  });

  it("shows a note on a blocked branch", () => {
    render(<ParallelTracker branches={BRANCHES} />);
    expect(screen.getByText("Waiting on ID photo")).toBeDefined();
  });
});
