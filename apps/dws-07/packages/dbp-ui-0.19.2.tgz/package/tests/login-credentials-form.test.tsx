import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { LoginCredentialsForm } from "../src/components/login-credentials-form.js";

afterEach(() => { cleanup(); });

// No shared password-policy schema exists in the repo yet (checked
// @dbp/contracts and packages/shared for a PasswordPolicy/passwordSchema —
// none found); LoginCredentialsForm itself enforces no password rules beyond
// HTML `required`, so these tests exercise only that real behaviour.

describe("LoginCredentialsForm", () => {
  it("requires email and password before native submit fires", () => {
    render(<LoginCredentialsForm onSubmit={vi.fn()} />);
    expect(screen.getByTestId("login-email")).toHaveProperty("required", true);
    expect(screen.getByTestId("login-password")).toHaveProperty("required", true);
  });

  it("calls onSubmit with the entered email and password", async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn();
    render(<LoginCredentialsForm onSubmit={onSubmit} />);
    await user.type(screen.getByTestId("login-email"), "dummy.user@example.test");
    await user.type(screen.getByTestId("login-password"), "not-a-real-password-1");
    await user.click(screen.getByTestId("login-submit"));
    expect(onSubmit).toHaveBeenCalledWith({
      email: "dummy.user@example.test",
      password: "not-a-real-password-1",
    });
  });

  it("shows the error alert when error is set", () => {
    render(<LoginCredentialsForm onSubmit={vi.fn()} error="Invalid credentials" />);
    expect(screen.getByTestId("login-error").textContent).toBe("Invalid credentials");
  });

  it("does not render an error alert when error is not set", () => {
    render(<LoginCredentialsForm onSubmit={vi.fn()} />);
    expect(screen.queryByTestId("login-error")).toBeNull();
  });

  it("disables the submit button while loading", () => {
    render(<LoginCredentialsForm onSubmit={vi.fn()} loading />);
    expect((screen.getByTestId("login-submit") as HTMLButtonElement).disabled).toBe(true);
    expect(screen.getByText(/signing in/i)).toBeDefined();
  });

  it("omits the demo-accounts section when seedUsers is not given", () => {
    render(<LoginCredentialsForm onSubmit={vi.fn()} />);
    expect(screen.queryByText(/demo accounts/i)).toBeNull();
  });

  it("prefills email (and password, when seedPassword is given) on seed-user click", async () => {
    const user = userEvent.setup();
    render(
      <LoginCredentialsForm
        onSubmit={vi.fn()}
        seedUsers={[{ label: "Demo Admin", email: "demo.admin@example.test" }]}
        seedPassword="demo-only-1234"
      />
    );
    await user.click(screen.getByTestId("seed-user-demo.admin@example.test"));
    expect((screen.getByTestId("login-email") as HTMLInputElement).value).toBe("demo.admin@example.test");
    expect((screen.getByTestId("login-password") as HTMLInputElement).value).toBe("demo-only-1234");
  });
});
