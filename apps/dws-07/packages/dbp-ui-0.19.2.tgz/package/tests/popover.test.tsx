import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
} from "../src/components/popover.js";

afterEach(() => { cleanup(); });

describe("Popover", () => {
  it("does not render content when closed", () => {
    render(
      <Popover>
        <PopoverTrigger>Open</PopoverTrigger>
        <PopoverContent>Popover body</PopoverContent>
      </Popover>
    );
    expect(screen.queryByText("Popover body")).toBeNull();
  });

  it("shows content after trigger click", async () => {
    const user = userEvent.setup();
    render(
      <Popover>
        <PopoverTrigger>Open</PopoverTrigger>
        <PopoverContent>Popover body</PopoverContent>
      </Popover>
    );
    await user.click(screen.getByText("Open"));
    expect(screen.getByText("Popover body")).toBeDefined();
  });

  it("closes on Escape", async () => {
    const user = userEvent.setup();
    render(
      <Popover>
        <PopoverTrigger>Open</PopoverTrigger>
        <PopoverContent>Popover body</PopoverContent>
      </Popover>
    );
    await user.click(screen.getByText("Open"));
    expect(screen.getByText("Popover body")).toBeDefined();
    await user.keyboard("{Escape}");
    expect(screen.queryByText("Popover body")).toBeNull();
  });
});
