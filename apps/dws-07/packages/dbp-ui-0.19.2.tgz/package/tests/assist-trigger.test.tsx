import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { AssistTrigger } from "../src/components/assist-trigger.js";

afterEach(() => { cleanup(); });

describe("AssistTrigger", () => {
  it("renders a ready button that calls onClick", () => {
    const onClick = vi.fn();
    render(<AssistTrigger state="ready" onClick={onClick} />);
    fireEvent.click(screen.getByRole("button", { name: /Suggest/ }));
    expect(onClick).toHaveBeenCalledOnce();
  });

  it("renders a loading indicator and no button when state is loading", () => {
    render(<AssistTrigger state="loading" />);
    expect(screen.getByText("Suggesting")).toBeDefined();
    expect(screen.queryByRole("button")).toBeNull();
  });

  it("renders an unavailable message and no button when state is unavailable", () => {
    render(<AssistTrigger state="unavailable" />);
    expect(screen.getByText("AI unavailable")).toBeDefined();
    expect(screen.queryByRole("button")).toBeNull();
  });

  it("treats busy as an alias for loading", () => {
    render(<AssistTrigger busy />);
    expect(screen.getByText("Suggesting")).toBeDefined();
  });

  it("renders a custom label when ready", () => {
    render(<AssistTrigger label="Suggest options" />);
    expect(screen.getByText("Suggest options")).toBeDefined();
  });
});
