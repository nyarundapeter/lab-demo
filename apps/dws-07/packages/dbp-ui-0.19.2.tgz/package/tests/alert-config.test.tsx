import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AlertConfig } from "../src/components/alert-config.js";

afterEach(() => { cleanup(); });

describe("AlertConfig", () => {
  it("hides frequency options when disabled", () => {
    render(<AlertConfig enabled={false} frequency="realtime" onEnabledChange={vi.fn()} onFrequencyChange={vi.fn()} />);
    expect(screen.queryByRole("radiogroup")).toBeNull();
  });

  it("shows frequency options when enabled", () => {
    render(<AlertConfig enabled frequency="realtime" onEnabledChange={vi.fn()} onFrequencyChange={vi.fn()} />);
    expect(screen.getByRole("radiogroup")).toBeDefined();
    expect(screen.getByText("Real-time")).toBeDefined();
    expect(screen.getByText("Daily digest")).toBeDefined();
    expect(screen.getByText("Weekly digest")).toBeDefined();
  });

  it("calls onEnabledChange when the switch is toggled", async () => {
    const user = userEvent.setup();
    const onEnabledChange = vi.fn();
    render(<AlertConfig enabled={false} frequency="realtime" onEnabledChange={onEnabledChange} onFrequencyChange={vi.fn()} />);
    await user.click(screen.getByRole("switch"));
    expect(onEnabledChange).toHaveBeenCalledWith(true);
  });

  it("calls onFrequencyChange when a different frequency is picked", async () => {
    const user = userEvent.setup();
    const onFrequencyChange = vi.fn();
    render(<AlertConfig enabled frequency="realtime" onEnabledChange={vi.fn()} onFrequencyChange={onFrequencyChange} />);
    await user.click(screen.getByText("Daily digest"));
    expect(onFrequencyChange).toHaveBeenCalledWith("daily");
  });
});
