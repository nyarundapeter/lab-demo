import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Advisory } from "../src/components/advisory.js";

afterEach(() => { cleanup(); });

describe("Advisory", () => {
  it("renders the default advisory text with role=note", () => {
    render(<Advisory />);
    expect(screen.getByRole("note")).toBeDefined();
    expect(screen.getByText("Advisory only — human decision required")).toBeDefined();
  });

  it("renders custom children instead of the default text", () => {
    render(<Advisory>Advisory only — a manager must approve before this ships</Advisory>);
    expect(screen.getByText("Advisory only — a manager must approve before this ships")).toBeDefined();
    expect(screen.queryByText("Advisory only — human decision required")).toBeNull();
  });
});
