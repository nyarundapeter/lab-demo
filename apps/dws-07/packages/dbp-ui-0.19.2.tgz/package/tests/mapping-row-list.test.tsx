import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { MappingRowList } from "../src/components/mapping-row-list.js";

describe("MappingRowList", () => {
  it("renders table variant rows with source, target, and meta", () => {
    render(
      <MappingRowList
        variant="table"
        rows={[{ source: "customer_id", target: "accountId", meta: "Direct" }]}
      />
    );
    expect(screen.getByText("customer_id")).toBeDefined();
    expect(screen.getByText("accountId")).toBeDefined();
    expect(screen.getByText("Direct")).toBeDefined();
  });

  it("renders connector variant rows with source, target, meta, and label", () => {
    render(
      <MappingRowList
        variant="connector"
        rows={[{ source: "Case", target: "Account", meta: "Many-to-one", label: "belongs to" }]}
      />
    );
    expect(screen.getByText("Case")).toBeDefined();
    expect(screen.getByText("Account")).toBeDefined();
    expect(screen.getByText("Many-to-one")).toBeDefined();
    expect(screen.getByText("belongs to")).toBeDefined();
  });

  it("shows an add-row action in connector variant when onAddRow is provided", () => {
    render(
      <MappingRowList
        variant="connector"
        rows={[{ source: "Case", target: "Account" }]}
        onAddRow={() => {}}
        addRowLabel="Add relationship"
      />
    );
    expect(screen.getByText("Add relationship")).toBeDefined();
  });
});
