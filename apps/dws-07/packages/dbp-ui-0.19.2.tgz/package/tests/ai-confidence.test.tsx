import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AiConfidence } from "../src/components/ai-confidence.js";

afterEach(() => { cleanup(); });

describe("AiConfidence", () => {
  it("renders the label for each confidence level", () => {
    const levels = ["high", "medium", "low", "insufficient"] as const;
    const labels = {
      high: "High confidence",
      medium: "Medium confidence",
      low: "Low confidence",
      insufficient: "Insufficient information",
    };
    for (const level of levels) {
      const { unmount } = render(<AiConfidence level={level} />);
      expect(screen.getByText(labels[level])).toBeDefined();
      unmount();
    }
  });

  it("renders inline without a note popover trigger", () => {
    render(<AiConfidence level="high" note="Some reasoning" inline />);
    expect(screen.getByLabelText("High confidence")).toBeDefined();
    expect(screen.queryByRole("button")).toBeNull();
  });

  it("renders as plain text when no note is provided", () => {
    render(<AiConfidence level="medium" />);
    expect(screen.getByText("Medium confidence")).toBeDefined();
    expect(screen.queryByRole("button")).toBeNull();
  });

  it("opens the why-this-confidence popover when a note is provided", async () => {
    const user = userEvent.setup();
    render(<AiConfidence level="high" note="Based on the last 3 audits." />);
    expect(screen.queryByText("Why this confidence")).toBeNull();
    await user.click(screen.getByRole("button"));
    expect(screen.getByText("Why this confidence")).toBeDefined();
    expect(screen.getByText("Based on the last 3 audits.")).toBeDefined();
  });
});
