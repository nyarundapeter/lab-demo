import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  FullScreenModal,
  FullScreenModalContent,
  FullScreenModalBar,
  FullScreenModalTitle,
  FullScreenModalBody,
  FullScreenModalMain,
  FullScreenModalFooter,
} from "../src/components/fullscreen-modal.js";

afterEach(() => { cleanup(); });

function renderModal(open: boolean, onOpenChange = vi.fn()) {
  return render(
    <FullScreenModal open={open} onOpenChange={onOpenChange}>
      <FullScreenModalContent>
        <FullScreenModalBar>
          <FullScreenModalTitle>Edit record</FullScreenModalTitle>
        </FullScreenModalBar>
        <FullScreenModalBody>
          <FullScreenModalMain>Body content</FullScreenModalMain>
        </FullScreenModalBody>
        <FullScreenModalFooter>
          <button type="button">Save</button>
        </FullScreenModalFooter>
      </FullScreenModalContent>
    </FullScreenModal>
  );
}

describe("FullScreenModal", () => {
  it("renders nothing when closed", () => {
    renderModal(false);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("renders the bar, title, body and footer when open", () => {
    renderModal(true);
    expect(screen.getByRole("dialog")).toBeDefined();
    expect(screen.getByText("Edit record")).toBeDefined();
    expect(screen.getByText("Body content")).toBeDefined();
    expect(screen.getByRole("button", { name: "Save" })).toBeDefined();
  });

  it("shows a close button by default and calls onOpenChange when clicked", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    renderModal(true, onOpenChange);
    await user.click(screen.getByRole("button", { name: /close/i }));
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("hides the close button when hideClose is set", () => {
    render(
      <FullScreenModal open onOpenChange={vi.fn()}>
        <FullScreenModalContent hideClose>
          <FullScreenModalBar>
            <FullScreenModalTitle>No close</FullScreenModalTitle>
          </FullScreenModalBar>
        </FullScreenModalContent>
      </FullScreenModal>
    );
    expect(screen.queryByRole("button", { name: /close/i })).toBeNull();
  });

  it("calls onOpenChange(false) on Escape", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    renderModal(true, onOpenChange);
    await user.keyboard("{Escape}");
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it("traps focus inside the dialog content", async () => {
    renderModal(true);
    const dialog = screen.getByRole("dialog");
    expect(dialog.contains(document.activeElement)).toBe(true);
  });
});
