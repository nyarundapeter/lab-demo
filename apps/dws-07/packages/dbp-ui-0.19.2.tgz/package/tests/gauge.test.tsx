import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Gauge } from "../src/components/gauge.js";

afterEach(() => { cleanup(); });

const THRESHOLDS = [
  { upTo: 60, color: "var(--color-success)" },
  { upTo: 85, color: "var(--color-warning)" },
  { upTo: 100, color: "var(--color-danger)" },
];

describe("Gauge", () => {
  it("renders with an accessible label including value and unit", () => {
    render(<Gauge value={42} thresholds={THRESHOLDS} label="Licence usage" />);
    expect(screen.getByRole("img", { name: "Licence usage: 42%" })).toBeDefined();
  });

  it("picks the color of the first threshold the value falls within", () => {
    const { container } = render(<Gauge value={42} thresholds={THRESHOLDS} />);
    const arcs = container.querySelectorAll("path");
    expect(arcs[1]?.getAttribute("stroke")).toBe("var(--color-success)");
  });

  it("falls back to the last threshold color when value exceeds all bounds", () => {
    const { container } = render(<Gauge value={150} max={100} thresholds={THRESHOLDS} />);
    const arcs = container.querySelectorAll("path");
    expect(arcs[1]?.getAttribute("stroke")).toBe("var(--color-danger)");
  });

  it("renders the numeric value and unit as text", () => {
    render(<Gauge value={72} thresholds={THRESHOLDS} unit="ms" />);
    expect(screen.getByText("72ms")).toBeDefined();
  });
});
