import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { NotifPopover, type NotifPopoverItem } from "../src/components/notif-popover.js";

afterEach(() => { cleanup(); });

function activePanel() {
  const panels = screen.getAllByRole("tabpanel", { hidden: true });
  return panels.find((p) => p.getAttribute("data-state") === "active")!;
}

const ITEMS: NotifPopoverItem[] = [
  {
    id: "n1",
    title: "SLA at risk — case CS-2093",
    message: "Breaches in ~22 minutes.",
    type: "action",
    severity: "critical",
    unread: true,
    actionRequired: true,
    time: "4 min ago",
  },
  {
    id: "n2",
    title: "Deploy completed",
    message: "All EU-West nodes updated.",
    type: "system",
    unread: false,
    time: "1h ago",
  },
];

describe("NotifPopover", () => {
  it("renders items on the All tab", () => {
    render(<NotifPopover items={ITEMS} />);
    expect(screen.getByText("SLA at risk — case CS-2093")).toBeDefined();
    expect(screen.getByText("Deploy completed")).toBeDefined();
  });

  it("filters to unread items on the Unread tab", async () => {
    const user = userEvent.setup();
    render(<NotifPopover items={ITEMS} />);
    await user.click(screen.getByRole("tab", { name: "Unread" }));
    const panel = activePanel();
    expect(panel.textContent).toContain("SLA at risk");
    expect(panel.textContent).not.toContain("Deploy completed");
  });

  it("filters to action-required items on the Action required tab", async () => {
    const user = userEvent.setup();
    render(<NotifPopover items={ITEMS} />);
    await user.click(screen.getByRole("tab", { name: "Action required" }));
    const panel = activePanel();
    expect(panel.textContent).toContain("SLA at risk");
    expect(panel.textContent).not.toContain("Deploy completed");
  });

  it("renders an empty state when a tab has no items", () => {
    render(<NotifPopover items={[]} />);
    expect(screen.getByText("You’re all caught up")).toBeDefined();
  });

  it("calls onItemClick with the clicked item", () => {
    const onItemClick = vi.fn();
    render(<NotifPopover items={ITEMS} onItemClick={onItemClick} />);
    fireEvent.click(screen.getByText("Deploy completed"));
    expect(onItemClick).toHaveBeenCalledWith(ITEMS[1]);
  });

  it("calls onMarkAllRead and disables the button when there is nothing unread", () => {
    const onMarkAllRead = vi.fn();
    const { rerender } = render(
      <NotifPopover items={ITEMS} unreadCount={1} onMarkAllRead={onMarkAllRead} />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Mark all read" }));
    expect(onMarkAllRead).toHaveBeenCalledTimes(1);

    rerender(<NotifPopover items={ITEMS} unreadCount={0} onMarkAllRead={onMarkAllRead} />);
    expect(screen.getByRole("button", { name: "Mark all read" })).toHaveProperty("disabled", true);
  });

  it("calls onViewAll", () => {
    const onViewAll = vi.fn();
    render(<NotifPopover items={ITEMS} onViewAll={onViewAll} />);
    fireEvent.click(screen.getByRole("button", { name: "View all notifications" }));
    expect(onViewAll).toHaveBeenCalledTimes(1);
  });
});
