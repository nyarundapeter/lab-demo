import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Delta } from "../src/components/delta.js";

afterEach(() => { cleanup(); });

describe("Delta", () => {
  it("marks a positive value good under up-good polarity", () => {
    render(<Delta value={5} polarity="up-good" />);
    expect(screen.getByText(/\+5%/).getAttribute("data-good")).toBe("true");
  });

  it("marks a positive value bad under down-good polarity", () => {
    render(<Delta value={5} polarity="down-good" />);
    expect(screen.getByText(/\+5%/).getAttribute("data-good")).toBe("false");
  });

  it("marks a zero value as flat with no good/bad attribute", () => {
    render(<Delta value={0} />);
    expect(screen.getByText("0%").getAttribute("data-direction")).toBe("flat");
    expect(screen.getByText("0%").hasAttribute("data-good")).toBe(false);
  });
});
