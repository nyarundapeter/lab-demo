import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { Badge } from "../src/components/badge.js";

describe("Badge", () => {
  it("renders text content", () => {
    render(<Badge>Active</Badge>);
    expect(screen.getByText("Active")).toBeDefined();
  });

  it("applies the outline variant class", () => {
    render(<Badge tone="gray" data-testid="b">Draft</Badge>);
    expect(screen.getByTestId("b").className).toContain("border");
  });
});
