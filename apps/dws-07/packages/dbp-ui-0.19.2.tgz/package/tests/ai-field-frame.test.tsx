import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { AiFieldFrame } from "../src/components/ai-field-frame.js";

afterEach(() => { cleanup(); });

describe("AiFieldFrame", () => {
  it("renders the label, children, and required marker", () => {
    render(
      <AiFieldFrame label="Customer name" required>
        <input aria-label="name-input" />
      </AiFieldFrame>,
    );
    expect(screen.getByText("Customer name")).toBeDefined();
    expect(screen.getByText("*")).toBeDefined();
    expect(screen.getByLabelText("name-input")).toBeDefined();
  });

  it("renders the assist slot and provenance note when provided", () => {
    render(
      <AiFieldFrame label="Priority" assist={<button>Suggest</button>} provNote="AI-suggested">
        <input />
      </AiFieldFrame>,
    );
    expect(screen.getByText("Suggest")).toBeDefined();
    expect(screen.getByText("AI-suggested")).toBeDefined();
  });

  it("omits the required marker and hint when not provided", () => {
    render(
      <AiFieldFrame label="Notes">
        <textarea />
      </AiFieldFrame>,
    );
    expect(screen.queryByText("*")).toBeNull();
  });
});
