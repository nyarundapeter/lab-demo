import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { SaveDraftButton } from "../src/components/save-draft-button.js";

afterEach(() => {
  cleanup();
});

describe("SaveDraftButton", () => {
  it("renders the default label and fires onClick", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    render(<SaveDraftButton onClick={onClick} />);

    const button = screen.getByRole("button", { name: /save draft/i });
    await user.click(button);

    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("shows the saving label and disables the button while saving", () => {
    render(<SaveDraftButton saving />);
    const button = screen.getByRole("button", { name: /saving draft/i });
    expect(button).toHaveProperty("disabled", true);
  });

  it("accepts a custom label", () => {
    render(<SaveDraftButton label="Keep draft" />);
    expect(screen.getByRole("button", { name: "Keep draft" })).toBeDefined();
  });
});
