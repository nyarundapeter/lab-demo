import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { OrgBadge } from "../src/components/org-badge.js";

afterEach(() => { cleanup(); });

describe("OrgBadge", () => {
  it("renders the org name and domain", () => {
    render(<OrgBadge name="Northwind" domain="northwind.example" />);
    expect(screen.getByText("Northwind")).toBeDefined();
    expect(screen.getByText("northwind.example")).toBeDefined();
  });

  it("omits the domain line when not given", () => {
    render(<OrgBadge name="Northwind" />);
    expect(screen.queryByText("northwind.example")).toBeNull();
  });
});
