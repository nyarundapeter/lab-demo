import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { CompactTracker } from "../src/components/compact-tracker.js";
import type { StageRow } from "../src/components/vertical-stage-tracker.js";

afterEach(() => { cleanup(); });

const STAGES: StageRow[] = [
  { id: "a", label: "Intake", status: "done" },
  { id: "b", label: "Review", status: "active" },
  { id: "c", label: "Approval", status: "upcoming" },
];

describe("CompactTracker", () => {
  it("renders one pill per stage", () => {
    render(<CompactTracker stages={STAGES} />);
    expect(screen.getAllByTestId("compact-tracker-stage")).toHaveLength(3);
    expect(screen.getByText("Intake")).toBeDefined();
    expect(screen.getByText("Review")).toBeDefined();
    expect(screen.getByText("Approval")).toBeDefined();
  });

  it("stamps data-status per stage so state is readable without colour", () => {
    render(<CompactTracker stages={STAGES} />);
    const pills = screen.getAllByTestId("compact-tracker-stage");
    expect(pills.map((p) => p.getAttribute("data-status"))).toEqual(["done", "active", "upcoming"]);
  });
});
