import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { MilestoneRow } from "../src/components/milestone-row.js";

afterEach(() => { cleanup(); });

describe("MilestoneRow", () => {
  it("renders title, phase, owner, and date", () => {
    render(
      <MilestoneRow title="Discovery" phase="Phase 1" owner="A. Chen" date="Jun 12" status="good" />,
    );
    expect(screen.getByText("Discovery")).toBeDefined();
    expect(screen.getByText("Phase 1")).toBeDefined();
    expect(screen.getByText("A. Chen")).toBeDefined();
    expect(screen.getByText("Jun 12")).toBeDefined();
  });

  it("shows a Late chip when late is true", () => {
    render(<MilestoneRow title="Cutover" status="bad" late />);
    expect(screen.getByText("Late")).toBeDefined();
  });

  it("does not show a Late chip when late is false", () => {
    render(<MilestoneRow title="On time" status="good" />);
    expect(screen.queryByText("Late")).toBeNull();
  });
});
