import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { AutofillPreview, type AutofillPreviewData } from "../src/components/autofill-preview.js";

afterEach(() => { cleanup(); });

const DATA: AutofillPreviewData = {
  sourceName: "meridian-intake.eml",
  fields: [
    { field: "Company", value: "Meridian Foods", note: "Email signature", conf: "high" },
    {
      field: "Priority",
      value: "High",
      note: "Keyword match",
      conf: "low",
      conflict: true,
      existing: "Medium",
    },
  ],
};

describe("AutofillPreview", () => {
  it("defaults conflicting fields to unchecked and non-conflicting fields to checked", () => {
    render(<AutofillPreview data={DATA} />);
    const checkboxes = screen.getAllByRole("checkbox");
    expect(checkboxes[0]?.getAttribute("data-state")).toBe("checked");
    expect(checkboxes[1]?.getAttribute("data-state")).toBe("unchecked");
  });

  it("shows the conflict count and warning note", () => {
    render(<AutofillPreview data={DATA} />);
    expect(screen.getByText("1 conflict")).toBeDefined();
    expect(screen.getByText(/never overwritten silently/)).toBeDefined();
  });

  it("Select all checks every field", () => {
    render(<AutofillPreview data={DATA} />);
    fireEvent.click(screen.getByRole("button", { name: "Select all" }));
    const checkboxes = screen.getAllByRole("checkbox");
    expect(checkboxes.every((c) => c.getAttribute("data-state") === "checked")).toBe(true);
  });

  it("applying shows the confirmation step with the selected count and calls onApply", () => {
    const onApply = vi.fn();
    render(<AutofillPreview data={DATA} onApply={onApply} />);
    fireEvent.click(screen.getByRole("button", { name: /Apply 1 selected/ }));
    expect(screen.getByText("1 fields populated")).toBeDefined();
    expect(onApply).toHaveBeenCalledWith([0]);
  });

  it("Undo autofill returns to the review step", () => {
    render(<AutofillPreview data={DATA} />);
    fireEvent.click(screen.getByRole("button", { name: /Apply 1 selected/ }));
    fireEvent.click(screen.getByRole("button", { name: "Undo autofill" }));
    expect(screen.getByText(/review before applying/)).toBeDefined();
  });

  it("calls onClose from the close button", () => {
    const onClose = vi.fn();
    render(<AutofillPreview data={DATA} onClose={onClose} />);
    fireEvent.click(screen.getByRole("button", { name: "Close" }));
    expect(onClose).toHaveBeenCalledOnce();
  });
});
