import { describe, it, expect, afterEach } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import { createElement } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureAuditClient, resetAuditClient, type AuditEvent } from "@dbp/ps-audit/client";
import { AdminAuditLog } from "../src/components/admin-audit-log.js";

const BASE = "http://test.local/api/platform/audit";

const EVENTS: AuditEvent[] = [
  {
    id: "e1",
    ts: "2026-06-20T08:00:00.000Z",
    actor: { userId: "u-1", email: "alice@example.com", displayName: "Alice Nguyen" },
    action: "user.login",
    target: { entityType: "Session", entityId: "sess-1" },
    delta: null,
    tenantId: "tenant-alpha",
  },
  {
    id: "e2",
    ts: "2026-06-20T09:00:00.000Z",
    actor: { userId: "u-2", email: "bob@example.com", displayName: "Bob Kaur" },
    action: "role.assign",
    target: { entityType: "User", entityId: "u-3" },
    delta: null,
    tenantId: "tenant-alpha",
  },
];

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), { status: 200, headers: { "content-type": "application/json" } }),
    );
}

function wrapper() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client: qc }, children);
}

afterEach(() => {
  cleanup();
  resetAuditClient();
});

describe("AdminAuditLog", () => {
  it("renders each event's actor, action, and target", async () => {
    configureAuditClient({ baseUrl: BASE, fetch: makeFetch({ events: EVENTS, nextCursor: null }) });
    render(<AdminAuditLog />, { wrapper: wrapper() });

    await waitFor(() => {
      expect(screen.getByText("Alice Nguyen")).toBeDefined();
    });
    expect(screen.getByText("Bob Kaur")).toBeDefined();
    expect(screen.getAllByText("user.login").length).toBeGreaterThan(0);
    expect(screen.getAllByText("role.assign").length).toBeGreaterThan(0);
  });

  it("shows the empty state when there are no events", async () => {
    configureAuditClient({ baseUrl: BASE, fetch: makeFetch({ events: [], nextCursor: null }) });
    render(<AdminAuditLog />, { wrapper: wrapper() });

    await waitFor(() => {
      expect(screen.getByText("No audit events")).toBeDefined();
    });
  });

  it("shows the error state when the feed fails to load", async () => {
    configureAuditClient({
      baseUrl: BASE,
      fetch: () =>
        Promise.resolve(
          new Response(JSON.stringify({ error: "Internal Server Error" }), {
            status: 500,
            headers: { "content-type": "application/json" },
          }),
        ),
    });
    render(<AdminAuditLog />, { wrapper: wrapper() });

    await waitFor(() => {
      expect(screen.getByText("Failed to load audit log")).toBeDefined();
    });
  });
});
