import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { BoardCard } from "../src/components/board-card.js";

afterEach(() => { cleanup(); });

describe("BoardCard", () => {
  it("renders title, subtitle, meta and badge with role=listitem", () => {
    render(
      <BoardCard
        title="CDD Clarification Request"
        subtitle="Ahmed Al-Mansoori"
        meta="Compliance · Jun 18, 2026"
        badgeTone="danger"
        badgeLabel="High"
      />
    );
    expect(screen.getByRole("listitem")).toBeDefined();
    expect(screen.getByText("CDD Clarification Request")).toBeDefined();
    expect(screen.getByText("Ahmed Al-Mansoori")).toBeDefined();
    expect(screen.getByText("Compliance · Jun 18, 2026")).toBeDefined();
    expect(screen.getByText("High")).toBeDefined();
  });

  it("renders a non-interactive div when onClick is not provided", () => {
    render(<BoardCard title="Static Card" />);
    const el = screen.getByRole("listitem");
    expect(el.tagName).toBe("DIV");
  });

  it("renders a real button and calls onClick when interactive", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    render(<BoardCard title="Clickable Card" onClick={onClick} />);
    const el = screen.getByRole("listitem");
    expect(el.tagName).toBe("BUTTON");
    await user.click(el);
    expect(onClick).toHaveBeenCalledTimes(1);
  });
});
