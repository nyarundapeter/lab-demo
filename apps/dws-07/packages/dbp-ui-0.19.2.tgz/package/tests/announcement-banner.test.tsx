import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AnnouncementBanner } from "../src/components/announcement-banner.js";

afterEach(() => { cleanup(); });

describe("AnnouncementBanner", () => {
  it("renders the title and body", () => {
    render(<AnnouncementBanner title="New feature" body="Check it out" />);
    expect(screen.getByText("New feature")).toBeDefined();
    expect(screen.getByText("Check it out")).toBeDefined();
  });

  it("omits the CTA button when ctaLabel is not provided", () => {
    render(<AnnouncementBanner title="New feature" body="Check it out" />);
    expect(screen.queryByRole("button")).toBeNull();
  });

  it("calls onCtaClick when the CTA is clicked", async () => {
    const user = userEvent.setup();
    const onCtaClick = vi.fn();
    render(
      <AnnouncementBanner title="New feature" body="Check it out" ctaLabel="Learn more" onCtaClick={onCtaClick} />,
    );
    await user.click(screen.getByRole("button", { name: "Learn more" }));
    expect(onCtaClick).toHaveBeenCalledTimes(1);
  });

  it("calls onDontShowAgain when clicked", async () => {
    const user = userEvent.setup();
    const onDontShowAgain = vi.fn();
    render(
      <AnnouncementBanner title="New feature" body="Check it out" onDontShowAgain={onDontShowAgain} />,
    );
    await user.click(screen.getByRole("button", { name: "Don't show again" }));
    expect(onDontShowAgain).toHaveBeenCalledTimes(1);
  });

  it("calls onDismiss when the dismiss button is clicked", async () => {
    const user = userEvent.setup();
    const onDismiss = vi.fn();
    render(<AnnouncementBanner title="New feature" body="Check it out" onDismiss={onDismiss} />);
    await user.click(screen.getByRole("button", { name: "Dismiss" }));
    expect(onDismiss).toHaveBeenCalledTimes(1);
  });
});
