import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { AssigneeCard } from "../src/components/assignee-card.js";

afterEach(() => { cleanup(); });

describe("AssigneeCard", () => {
  it("renders an individual assignee with subtitle and workload", () => {
    render(
      <AssigneeCard kind="individual" name="Fatima Al-Rashid" subtitle="Finance Approver" workload="6 open items" />,
    );
    expect(screen.getByText("Fatima Al-Rashid")).toBeDefined();
    expect(screen.getByText("Finance Approver")).toBeDefined();
    expect(screen.getByText("6 open items")).toBeDefined();
  });

  it("renders a team assignee", () => {
    render(<AssigneeCard kind="team" name="Finance Ops" subtitle="8 members" />);
    expect(screen.getByText("Finance Ops")).toBeDefined();
  });

  it("renders unassigned state without a name", () => {
    render(<AssigneeCard kind="unassigned" />);
    expect(screen.getByText("Unassigned")).toBeDefined();
  });

  it("calls onReassign and labels the button Assign when unassigned", () => {
    let called = false;
    render(<AssigneeCard kind="unassigned" onReassign={() => { called = true; }} />);
    fireEvent.click(screen.getByTestId("assignee-reassign-button"));
    expect(called).toBe(true);
    expect(screen.getByTestId("assignee-reassign-button").textContent).toBe("Assign");
  });

  it("labels the button Reassign when already assigned", () => {
    render(<AssigneeCard kind="individual" name="X" onReassign={() => {}} />);
    expect(screen.getByTestId("assignee-reassign-button").textContent).toBe("Reassign");
  });

  it("renders a queue assignee", () => {
    render(<AssigneeCard kind="queue" name="Security queue" subtitle="Queue · 6 waiting" />);
    expect(screen.getByText("Security queue")).toBeDefined();
    expect(screen.getByText("Queue · 6 waiting")).toBeDefined();
  });

  it("renders a delegation assignee", () => {
    render(
      <AssigneeCard kind="delegation" name="Sana Iqbal" subtitle="Delegated by Nadia Ahmadi · until Jul 20" />,
    );
    expect(screen.getByText("Sana Iqbal")).toBeDefined();
    expect(screen.getByText("Delegated by Nadia Ahmadi · until Jul 20")).toBeDefined();
  });

  it("renders a multiple assignee as a stacked co-owner cluster without a name row", () => {
    render(
      <AssigneeCard
        kind="multiple"
        subtitle="3 co-owners"
        coOwners={[{ name: "Ava Chen" }, { name: "Milo Ferreira" }, { name: "Tom Weiss" }]}
      />,
    );
    expect(screen.getByText("3 co-owners")).toBeDefined();
    expect(screen.getByLabelText("Ava Chen")).toBeDefined();
  });
});
