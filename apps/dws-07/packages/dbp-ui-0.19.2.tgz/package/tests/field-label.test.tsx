import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { FieldLabel } from "../src/components/field-label.js";

afterEach(() => { cleanup(); });

describe("FieldLabel", () => {
  it("renders its children as label text", () => {
    render(<FieldLabel htmlFor="name">Full name</FieldLabel>);
    expect(screen.getByText("Full name")).toBeDefined();
  });

  it("shows a required asterisk plus an sr-only '(required)' suffix", () => {
    render(<FieldLabel required>Full name</FieldLabel>);
    expect(screen.getByText("*").getAttribute("aria-hidden")).toBe("true");
    expect(screen.getByText("(required)")).toBeDefined();
  });

  it("shows an '(optional)' suffix when optional", () => {
    render(<FieldLabel optional>Middle name</FieldLabel>);
    expect(screen.getByText("(optional)")).toBeDefined();
  });

  it("required takes precedence over optional", () => {
    render(<FieldLabel required optional>Edge case</FieldLabel>);
    expect(screen.getByText("(required)")).toBeDefined();
    expect(screen.queryByText("(optional)")).toBeNull();
  });

  it("omits required/optional suffixes by default", () => {
    render(<FieldLabel>Plain label</FieldLabel>);
    expect(screen.queryByText("(required)")).toBeNull();
    expect(screen.queryByText("(optional)")).toBeNull();
  });
});
