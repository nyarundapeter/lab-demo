import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { LifecycleBar, deriveConfigLifecycleStages, CONFIG_LIFECYCLE_STAGES } from "../src/components/lifecycle-bar.js";
import type { StageRow } from "../src/components/vertical-stage-tracker.js";

afterEach(() => { cleanup(); });

describe("deriveConfigLifecycleStages", () => {
  it("marks stages before current as done, current as active, rest upcoming", () => {
    const stages = deriveConfigLifecycleStages("Approved");
    expect(stages.map((s) => s.status)).toEqual(["done", "done", "active", "upcoming", "upcoming", "upcoming"]);
    expect(stages.map((s) => s.label)).toEqual([...CONFIG_LIFECYCLE_STAGES]);
  });
});

describe("LifecycleBar", () => {
  it("chip variant renders every stage label", () => {
    render(<LifecycleBar variant="chip" stages={deriveConfigLifecycleStages("Published")} />);
    for (const label of CONFIG_LIFECYCLE_STAGES) {
      expect(screen.getByText(label)).toBeDefined();
    }
  });

  it("stepper variant renders every stage label and numbers upcoming stages", () => {
    const stages: StageRow[] = [
      { id: "a", label: "Intake", status: "done" },
      { id: "b", label: "Review", status: "active" },
      { id: "c", label: "Resolution", status: "upcoming" },
    ];
    render(<LifecycleBar variant="stepper" stages={stages} />);
    expect(screen.getByText("Intake")).toBeDefined();
    expect(screen.getByText("Review")).toBeDefined();
    expect(screen.getByText("Resolution")).toBeDefined();
    // upcoming stage renders its 1-based position as the node glyph
    expect(screen.getByText("3")).toBeDefined();
  });

  it("defaults to the stepper variant", () => {
    const stages: StageRow[] = [{ id: "a", label: "Only stage", status: "upcoming" }];
    render(<LifecycleBar stages={stages} />);
    expect(screen.getByText("Only stage")).toBeDefined();
    expect(screen.getByText("1")).toBeDefined();
  });

  // wave3-family3-tier-audit.md row 13 — CompactTracker (wf-trackers.jsx)
  // needs blocked/error tones the chip variant didn't render before.
  it("chip variant renders blocked and error stages in their own tone", () => {
    const stages: StageRow[] = [
      { id: "a", label: "Submitted", status: "done" },
      { id: "b", label: "Blocked stage", status: "blocked" },
      { id: "c", label: "Error stage", status: "error" },
    ];
    render(<LifecycleBar variant="chip" stages={stages} />);
    expect(screen.getByText("Blocked stage")).toBeDefined();
    expect(screen.getByText("Error stage")).toBeDefined();
  });
});
