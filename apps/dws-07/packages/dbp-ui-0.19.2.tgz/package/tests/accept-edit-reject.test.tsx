import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AcceptEditReject } from "../src/components/accept-edit-reject.js";

afterEach(() => { cleanup(); });

describe("AcceptEditReject", () => {
  it("renders the Accept button and calls onAccept", async () => {
    const user = userEvent.setup();
    const onAccept = vi.fn();
    render(<AcceptEditReject onAccept={onAccept} />);
    await user.click(screen.getByRole("button", { name: /accept/i }));
    expect(onAccept).toHaveBeenCalledTimes(1);
  });

  it("uses a custom acceptLabel", () => {
    render(<AcceptEditReject acceptLabel="Approve" />);
    expect(screen.getByRole("button", { name: /approve/i })).toBeDefined();
  });

  it("omits Edit when onEdit is not provided", () => {
    render(<AcceptEditReject />);
    expect(screen.queryByRole("button", { name: /edit/i })).toBeNull();
  });

  it("renders Edit and calls onEdit when provided", async () => {
    const user = userEvent.setup();
    const onEdit = vi.fn();
    render(<AcceptEditReject onEdit={onEdit} />);
    await user.click(screen.getByRole("button", { name: /edit/i }));
    expect(onEdit).toHaveBeenCalledTimes(1);
  });

  it("omits Reject when onReject is not provided", () => {
    render(<AcceptEditReject />);
    expect(screen.queryByRole("button", { name: /reject/i })).toBeNull();
  });

  it("opens the reject-reason popover and calls onReject with the picked reason", async () => {
    const user = userEvent.setup();
    const onReject = vi.fn();
    render(<AcceptEditReject onReject={onReject} />);
    await user.click(screen.getByRole("button", { name: /reject/i }));
    expect(screen.getByText("Reject — reason (optional)")).toBeDefined();
    await user.click(screen.getByText("Incorrect"));
    expect(onReject).toHaveBeenCalledWith("Incorrect");
  });

  it("calls onReject with undefined for reject-without-reason", async () => {
    const user = userEvent.setup();
    const onReject = vi.fn();
    render(<AcceptEditReject onReject={onReject} />);
    await user.click(screen.getByRole("button", { name: /reject/i }));
    await user.click(screen.getByText("Reject without reason"));
    expect(onReject).toHaveBeenCalledWith(undefined);
  });
});
