import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ShortcutHelp } from "../src/components/shortcut-help.js";
import type { ShortcutHelpConfig } from "../src/components/shortcut-help.js";

afterEach(() => { cleanup(); });

const CONFIG: ShortcutHelpConfig = {
  groups: [
    {
      id: "global",
      title: "Global",
      bindings: [{ id: "cmdk", keys: ["mod", "k"], description: "Open command palette" }],
    },
    {
      id: "navigation",
      title: "Navigation",
      bindings: [
        { id: "next", keys: ["j"], description: "Next item in list" },
        { id: "home", keys: ["g", "h"], description: "Go to Home", separator: "sequence" as const },
      ],
    },
  ],
};

describe("ShortcutHelp", () => {
  it("does not render when closed", () => {
    render(<ShortcutHelp open={false} onClose={() => {}} config={CONFIG} />);
    expect(screen.queryByText("Open command palette")).toBeNull();
  });

  it("shows every binding grouped when open", () => {
    render(<ShortcutHelp open onClose={() => {}} config={CONFIG} />);
    expect(screen.getByText("Open command palette")).toBeDefined();
    expect(screen.getByText("Next item in list")).toBeDefined();
    expect(screen.getByText("Global")).toBeDefined();
    expect(screen.getByText("Navigation")).toBeDefined();
  });

  it("filters bindings by search query", async () => {
    const user = userEvent.setup();
    render(<ShortcutHelp open onClose={() => {}} config={CONFIG} />);
    await user.type(screen.getByLabelText("Search shortcuts"), "palette");
    expect(screen.getByText("Open command palette")).toBeDefined();
    expect(screen.queryByText("Next item in list")).toBeNull();
  });

  it("shows the no-results state for an unmatched query", async () => {
    const user = userEvent.setup();
    render(<ShortcutHelp open onClose={() => {}} config={CONFIG} />);
    await user.type(screen.getByLabelText("Search shortcuts"), "zzz-no-match");
    expect(screen.getByText("No matching shortcuts")).toBeDefined();
  });

  it("shows the empty state when there are no registrations", () => {
    render(<ShortcutHelp open onClose={() => {}} config={{ groups: [] }} state="empty" />);
    expect(screen.getByText("No shortcuts registered")).toBeDefined();
  });

  it("shows a loading skeleton in the loading state", () => {
    render(<ShortcutHelp open onClose={() => {}} config={CONFIG} state="loading" />);
    expect(screen.queryByText("Open command palette")).toBeNull();
  });

  it("renders Ctrl for a non-mac platform", () => {
    render(<ShortcutHelp open onClose={() => {}} config={CONFIG} platform="other" />);
    expect(screen.getAllByText("Ctrl").length).toBeGreaterThan(0);
  });

  it("renders Cmd for the mac platform", () => {
    render(<ShortcutHelp open onClose={() => {}} config={CONFIG} platform="mac" />);
    expect(screen.getAllByText("Cmd").length).toBeGreaterThan(0);
  });

  it("renders a sequence binding with a \"then\" separator, not \"+\"", () => {
    render(<ShortcutHelp open onClose={() => {}} config={CONFIG} platform="other" />);
    expect(screen.getByText("Go to Home")).toBeDefined();
    expect(screen.getByText("then")).toBeDefined();
  });

  it("closes on Escape (Radix Dialog default)", async () => {
    const user = userEvent.setup();
    let closed = false;
    render(<ShortcutHelp open onClose={() => { closed = true; }} config={CONFIG} />);
    await user.keyboard("{Escape}");
    expect(closed).toBe(true);
  });
});
