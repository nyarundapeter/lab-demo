import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { RepeatableGroup } from "../src/components/repeatable-group.js";

afterEach(() => { cleanup(); });

describe("RepeatableGroup", () => {
  it("renders one row per item via renderItem", () => {
    render(
      <RepeatableGroup
        items={["a", "b", "c"]}
        onAdd={vi.fn()}
        onRemove={vi.fn()}
        renderItem={(item) => <span>Row {item}</span>}
      />
    );
    expect(screen.getByText("Row a")).toBeDefined();
    expect(screen.getByText("Row b")).toBeDefined();
    expect(screen.getByText("Row c")).toBeDefined();
  });

  it("calls onAdd when the add button is clicked", async () => {
    const user = userEvent.setup();
    const onAdd = vi.fn();
    render(
      <RepeatableGroup
        items={["a"]}
        onAdd={onAdd}
        onRemove={vi.fn()}
        renderItem={(item) => <span>Row {item}</span>}
      />
    );
    await user.click(screen.getByRole("button", { name: /add another/i }));
    expect(onAdd).toHaveBeenCalledTimes(1);
  });

  it("uses the custom addLabel when given", () => {
    render(
      <RepeatableGroup
        items={["a"]}
        onAdd={vi.fn()}
        onRemove={vi.fn()}
        addLabel="Add contact"
        renderItem={(item) => <span>Row {item}</span>}
      />
    );
    expect(screen.getByRole("button", { name: "Add contact" })).toBeDefined();
  });

  it("calls onRemove with the row index when its remove button is clicked", async () => {
    const user = userEvent.setup();
    const onRemove = vi.fn();
    render(
      <RepeatableGroup
        items={["a", "b"]}
        onAdd={vi.fn()}
        onRemove={onRemove}
        renderItem={(item) => <span>Row {item}</span>}
      />
    );
    await user.click(screen.getByRole("button", { name: "Remove item 2" }));
    expect(onRemove).toHaveBeenCalledWith(1);
  });

  it("hides the remove button once the item count reaches minItems", () => {
    render(
      <RepeatableGroup
        items={["a"]}
        onAdd={vi.fn()}
        onRemove={vi.fn()}
        minItems={1}
        renderItem={(item) => <span>Row {item}</span>}
      />
    );
    expect(screen.queryByRole("button", { name: /remove item/i })).toBeNull();
  });

  it("shows remove buttons for every row above minItems", () => {
    render(
      <RepeatableGroup
        items={["a", "b"]}
        onAdd={vi.fn()}
        onRemove={vi.fn()}
        minItems={1}
        renderItem={(item) => <span>Row {item}</span>}
      />
    );
    expect(screen.getAllByRole("button", { name: /remove item/i })).toHaveLength(2);
  });
});
