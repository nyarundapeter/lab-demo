import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { DateRangeField } from "../src/components/date-range-field.js";

afterEach(() => { cleanup(); });

describe("DateRangeField", () => {
  it("renders start and end date inputs from value", () => {
    render(<DateRangeField value={{ from: "2026-01-01", to: "2026-01-31" }} onChange={vi.fn()} />);
    expect(screen.getByLabelText("Start date")).toHaveProperty("value", "2026-01-01");
    expect(screen.getByLabelText("End date")).toHaveProperty("value", "2026-01-31");
  });

  it("uses the label prop to build the start/end aria-labels", () => {
    render(<DateRangeField value={{}} onChange={vi.fn()} label="Effective period" />);
    expect(screen.getByLabelText("Effective period start")).toBeDefined();
    expect(screen.getByLabelText("Effective period end")).toBeDefined();
  });

  it("calls onChange with the updated 'from' value, preserving 'to'", () => {
    const onChange = vi.fn();
    render(<DateRangeField value={{ to: "2026-02-01" }} onChange={onChange} />);
    fireEvent.change(screen.getByLabelText("Start date"), { target: { value: "2026-01-01" } });
    expect(onChange).toHaveBeenCalledWith({ from: "2026-01-01", to: "2026-02-01" });
  });

  it("calls onChange with the updated 'to' value, preserving 'from'", () => {
    const onChange = vi.fn();
    render(<DateRangeField value={{ from: "2026-01-01" }} onChange={onChange} />);
    fireEvent.change(screen.getByLabelText("End date"), { target: { value: "2026-01-31" } });
    expect(onChange).toHaveBeenCalledWith({ from: "2026-01-01", to: "2026-01-31" });
  });

  it("constrains the 'to' input's min to the 'from' value", () => {
    render(<DateRangeField value={{ from: "2026-01-01" }} onChange={vi.fn()} />);
    expect(screen.getByLabelText("End date").getAttribute("min")).toBe("2026-01-01");
  });

  it("disables both inputs when disabled", () => {
    render(<DateRangeField value={{}} onChange={vi.fn()} disabled />);
    expect(screen.getByLabelText("Start date")).toHaveProperty("disabled", true);
    expect(screen.getByLabelText("End date")).toHaveProperty("disabled", true);
  });
});
