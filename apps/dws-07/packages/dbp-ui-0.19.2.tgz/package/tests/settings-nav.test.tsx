import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { SettingsNav } from "../src/components/settings-nav.js";

afterEach(() => { cleanup(); });

const LINKS = [
  { href: "/settings/profile", label: "Profile" },
  { href: "/settings/security", label: "Security" },
];

describe("SettingsNav", () => {
  it("renders a link for each entry with its label and href", () => {
    render(<SettingsNav links={LINKS} />);
    const profile = screen.getByRole("link", { name: "Profile" });
    const security = screen.getByRole("link", { name: "Security" });
    expect(profile.getAttribute("href")).toBe("/settings/profile");
    expect(security.getAttribute("href")).toBe("/settings/security");
  });

  it("labels the nav for accessibility", () => {
    render(<SettingsNav links={LINKS} />);
    expect(screen.getByRole("navigation", { name: /settings navigation/i })).toBeDefined();
  });

  it("renders no links when given an empty list", () => {
    render(<SettingsNav links={[]} />);
    expect(screen.queryAllByRole("link")).toHaveLength(0);
  });
});
