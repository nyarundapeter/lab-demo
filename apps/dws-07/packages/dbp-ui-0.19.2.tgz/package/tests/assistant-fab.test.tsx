import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { AssistantFab } from "../src/components/assistant-fab.js";

afterEach(() => { cleanup(); });

describe("AssistantFab", () => {
  it("links to /copilot by default", () => {
    render(<AssistantFab />);
    const link = screen.getByRole("link", { name: /Ask AI/ });
    expect(link.getAttribute("href")).toBe("/copilot");
  });

  it("honours a custom href", () => {
    render(<AssistantFab href="/copilot?context=operational" />);
    const link = screen.getByRole("link");
    expect(link.getAttribute("href")).toBe("/copilot?context=operational");
  });
});
