import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { ReadOnlyValue } from "../src/components/read-only-value.js";

afterEach(() => { cleanup(); });

describe("ReadOnlyValue", () => {
  it("renders the label and value", () => {
    render(<ReadOnlyValue label="Requested by" value="Priya Sharma" />);
    expect(screen.getByText("Requested by")).toBeDefined();
    expect(screen.getByText("Priya Sharma")).toBeDefined();
  });

  it("shows the empty-text fallback when value is missing", () => {
    render(<ReadOnlyValue label="Assigned to" />);
    expect(screen.getByText("Not set")).toBeDefined();
  });

  it("supports a custom empty-text", () => {
    render(<ReadOnlyValue label="Assigned to" emptyText="Unassigned" />);
    expect(screen.getByText("Unassigned")).toBeDefined();
  });

  it("renders a badge next to the value when provided", () => {
    render(<ReadOnlyValue label="Reference number" value="REQ-1" badge="Auto" />);
    expect(screen.getByText("Auto")).toBeDefined();
  });

  it("renders helper text below the value", () => {
    render(<ReadOnlyValue label="Status" value="Approved" helperText="Approved by Finance." />);
    expect(screen.getByText("Approved by Finance.")).toBeDefined();
  });

  it("treats an empty string value as empty", () => {
    render(<ReadOnlyValue label="Notes" value="" />);
    expect(screen.getByText("Not set")).toBeDefined();
  });
});
