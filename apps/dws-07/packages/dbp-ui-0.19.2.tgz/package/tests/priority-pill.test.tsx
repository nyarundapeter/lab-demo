import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { PriorityPill } from "../src/components/priority-pill.js";
import type { NotificationPriority } from "@dbp/contracts";

afterEach(() => { cleanup(); });

const ALL_PRIORITIES: NotificationPriority[] = ["low", "normal", "high", "urgent"];

describe("PriorityPill", () => {
  it("renders the default label for every notification priority", () => {
    const expected: Record<NotificationPriority, string> = {
      low: "Low",
      normal: "Normal",
      high: "High",
      urgent: "Urgent",
    };
    for (const priority of ALL_PRIORITIES) {
      const { unmount } = render(<PriorityPill priority={priority} />);
      expect(screen.getByText(expected[priority])).toBeDefined();
      unmount();
    }
  });

  it("allows a label override", () => {
    render(<PriorityPill priority="high" label="Escalated" />);
    expect(screen.getByText("Escalated")).toBeDefined();
    expect(screen.queryByText("High")).toBeNull();
  });
});
