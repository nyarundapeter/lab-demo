import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { DashSection } from "../src/components/dash-section.js";

afterEach(() => { cleanup(); });

describe("DashSection", () => {
  it("renders the title and children", () => {
    render(
      <DashSection title="Renewals">
        <div>Body content</div>
      </DashSection>
    );
    expect(screen.getByText("Renewals")).toBeDefined();
    expect(screen.getByText("Body content")).toBeDefined();
  });

  it("renders the sub-label when provided", () => {
    render(<DashSection title="Renewals" sub="Last 30 days" />);
    expect(screen.getByText("Last 30 days")).toBeDefined();
  });

  it("renders the action slot when provided", () => {
    render(<DashSection title="Renewals" action={<button type="button">View all</button>} />);
    expect(screen.getByRole("button", { name: "View all" })).toBeDefined();
  });

  it("renders children without a header row when no title or action is given", () => {
    const { container } = render(
      <DashSection>
        <div>Untitled section</div>
      </DashSection>
    );
    expect(screen.getByText("Untitled section")).toBeDefined();
    expect(container.querySelector("h2")).toBeNull();
  });
});
