import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { createElement, type ReactNode } from "react";
import { AppChrome } from "../src/components/app-chrome.js";
import type { AppChromeSession } from "../src/components/app-chrome.js";

afterEach(() => {
  cleanup();
});

const session: AppChromeSession = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  displayName: "Alpha Finance Approver",
  primaryRole: "Finance Approver",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
};

const multiRoleSession: AppChromeSession = {
  ...session,
  roles: ["finance-approver", "platform-admin"],
};

const noRolesSession: AppChromeSession = {
  ...session,
  primaryRole: "",
  roles: [],
};

/** Stand-in for a caller-supplied search element (real callers pass `@dbp/organisms/search-bar`). */
function TestSearchSlot() {
  return createElement("input", { type: "text", role: "searchbox", "aria-label": "Search shifts" });
}
/** Stand-in for a caller-supplied notifications element (real callers pass `@dbp/organisms/notification-bell`). */
function TestNotificationSlot() {
  return createElement("button", { type: "button" }, "Notifications");
}

function noQuery(ui: ReactNode) {
  return ui;
}

describe("AppChrome — product lockup", () => {
  // Amendment D-2 (component-architecture-standard.md §7b): the app lockup
  // moved to the sidebar header (SidebarIdentity) — AppChrome/AppTopBar no
  // longer render the solution code or product name as top-bar text.
  it("does not render the solution code or product name as top-bar text", () => {
    render(
      noQuery(
        <AppChrome productCode="DIA.02" productName="AnalyticsOps" session={session} />,
      ),
    );
    expect(screen.queryByText("DIA.02")).toBeNull();
    expect(screen.queryByText("/ AnalyticsOps")).toBeNull();
  });
});

describe("AppChrome — search/notifications slots (Layer 06/07 boundary)", () => {
  it("does NOT render global search when the search slot is omitted", () => {
    render(
      noQuery(
        <AppChrome productCode="DIA.02" productName="AnalyticsOps" session={session} />,
      ),
    );
    // Neither a caller-supplied searchbox nor the default collapsed-search pill.
    expect(screen.queryByRole("searchbox")).toBeNull();
    expect(screen.queryByRole("button", { name: /open search/i })).toBeNull();
  });

  it("renders whatever is passed via the search slot", () => {
    render(
      noQuery(
        <AppChrome
          productCode="DWS.05"
          productName="Digital WFMS"
          session={session}
          search={<TestSearchSlot />}
        />,
      ),
    );
    expect(screen.getAllByRole("searchbox", { name: /search shifts/i }).length).toBeGreaterThan(0);
  });

  it("does NOT render a notification control when the notifications slot is omitted", () => {
    render(
      noQuery(
        <AppChrome productCode="DIA.02" productName="AnalyticsOps" session={session} />,
      ),
    );
    expect(screen.queryByText("Notifications")).toBeNull();
  });

  it("renders whatever is passed via the notifications slot", () => {
    render(
      noQuery(
        <AppChrome
          productCode="DWS.05"
          productName="Digital WFMS"
          session={session}
          notifications={<TestNotificationSlot />}
        />,
      ),
    );
    expect(screen.getByText("Notifications")).toBeTruthy();
  });
});

describe("AppChrome — settings affordance", () => {
  it("always renders a settings control", () => {
    render(noQuery(<AppChrome productCode="DIA.02" session={session} />));
    expect(screen.getByRole("button", { name: /settings/i })).toBeTruthy();
  });
});

describe("AppChrome — avatar / role from session", () => {
  it("renders the avatar block from the session display name + role", () => {
    render(noQuery(<AppChrome productCode="DIA.02" session={session} />));
    expect(screen.getByText("Alpha Finance Approver")).toBeTruthy();
    expect(screen.getByText("Finance Approver")).toBeTruthy();
  });

  it("renders NO avatar block when session is null (loading / unauthenticated)", () => {
    render(noQuery(<AppChrome productCode="DIA.02" session={null} />));
    expect(screen.queryByText("Alpha Finance Approver")).toBeNull();
  });

  it("renders a STATIC user chip (no role switcher) for a single-role session", () => {
    render(noQuery(<AppChrome productCode="DIA.02" session={session} />));
    // N33: no standalone role combobox, and the chip itself is not clickable.
    expect(screen.queryByRole("combobox", { name: /active role/i })).toBeNull();
    expect(screen.queryByRole("button", { name: /switch role/i })).toBeNull();
  });

  it("the user chip IS the role switcher when the session has 2+ roles (N33)", () => {
    render(noQuery(<AppChrome productCode="DWS.04" session={multiRoleSession} />));
    // No standalone Active-role combobox in the bar…
    expect(screen.queryByRole("combobox", { name: /active role/i })).toBeNull();
    // …the avatar chip opens the role popover instead.
    expect(screen.getByRole("button", { name: /switch role/i })).toBeTruthy();
  });

  it("renders a muted 'No roles in this workspace' state when the session has zero roles", () => {
    render(noQuery(<AppChrome productCode="DWS.04" session={noRolesSession} />));
    expect(screen.getByText("No roles in this workspace")).toBeTruthy();
    // Consistent with the single-role behaviour: no role switcher control.
    expect(screen.queryByRole("button", { name: /switch role/i })).toBeNull();
  });
});

describe("AppChrome — tenant switcher removed from the top bar (N30)", () => {
  it("renders no workspace/tenant combobox even for an authenticated session", () => {
    render(noQuery(<AppChrome productCode="DWS.04" session={multiRoleSession} />));
    // The tenant switcher moved to the sidebar identity block (@dbp/organisms/tenant-switcher).
    expect(screen.queryByRole("combobox", { name: /active workspace/i })).toBeNull();
    expect(screen.queryByRole("button", { name: /switch workspace/i })).toBeNull();
  });
});

describe("AppChrome — no Sparkles icon", () => {
  it("emits no element referencing a sparkles glyph", () => {
    const { container } = render(noQuery(<AppChrome productCode="DIA.02" session={session} />));
    expect(container.innerHTML.toLowerCase()).not.toContain("sparkle");
  });
});
