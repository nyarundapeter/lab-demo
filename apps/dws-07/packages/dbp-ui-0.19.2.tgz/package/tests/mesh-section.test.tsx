import { describe, it, expect } from "vitest"
import { render, screen } from "@testing-library/react"
import { MeshSection } from "../src/components/mesh-section.js"

describe("MeshSection", () => {
  it("renders children", () => {
    render(<MeshSection><p>hello</p></MeshSection>)
    expect(screen.getByText("hello")).toBeDefined()
  })

  it("defaults to the heroLight mesh background", () => {
    const { container } = render(<MeshSection><span>x</span></MeshSection>)
    const layer = container.querySelector("[aria-hidden]") as HTMLElement
    expect(layer.style.background).toContain("--mesh-hero-light")
  })

  it("uses the ctaOrange mesh for the ctaOrange variant", () => {
    const { container } = render(<MeshSection variant="ctaOrange"><span>x</span></MeshSection>)
    const layer = container.querySelector("[aria-hidden]") as HTMLElement
    expect(layer.style.background).toContain("--mesh-cta-orange")
  })

  it("renders the hero grid overlay only when grid is set", () => {
    const { container } = render(<MeshSection grid><span>x</span></MeshSection>)
    expect(container.querySelector(".hero-grid")).not.toBeNull()
  })

  it("omits the hero grid overlay by default", () => {
    const { container } = render(<MeshSection><span>x</span></MeshSection>)
    expect(container.querySelector(".hero-grid")).toBeNull()
  })

  it("applies the id for anchor navigation", () => {
    const { container } = render(<MeshSection id="band"><span>x</span></MeshSection>)
    expect(container.querySelector("#band")).not.toBeNull()
  })
})
