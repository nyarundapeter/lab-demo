import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { ProvenanceKey } from "../src/components/provenance-key.js";

afterEach(() => { cleanup(); });

describe("ProvenanceKey", () => {
  it("renders all 6 provenance labels", () => {
    render(<ProvenanceKey />);
    expect(screen.getByText("Source data")).toBeDefined();
    expect(screen.getByText("Calculated")).toBeDefined();
    expect(screen.getByText("AI interpretation")).toBeDefined();
    expect(screen.getByText("AI prediction")).toBeDefined();
    expect(screen.getByText("Human-confirmed")).toBeDefined();
    expect(screen.getByText("Automated")).toBeDefined();
  });
});
