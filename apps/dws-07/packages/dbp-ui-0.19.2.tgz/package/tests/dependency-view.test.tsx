import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { DependencyView } from "../src/components/dependency-view.js";

afterEach(() => cleanup());

const UPSTREAM = [{ label: "Request created", sub: "Trigger event" }];
const CURRENT = { label: "Tier 1 routing", sub: "This rule · v7" };
const DOWNSTREAM = [
  { label: "EMEA Infra Desk", sub: "Assignment target", to: "teams" },
  { label: "Incident escalation", sub: "Workflow · triggered", to: "workflows" },
];

describe("DependencyView", () => {
  it("renders the panel title and node labels", () => {
    render(<DependencyView upstream={UPSTREAM} current={CURRENT} downstream={DOWNSTREAM} />);
    expect(screen.getByText("Dependencies")).toBeDefined();
    expect(screen.getByText("Request created")).toBeDefined();
    expect(screen.getByText("Tier 1 routing")).toBeDefined();
    expect(screen.getByText("EMEA Infra Desk")).toBeDefined();
  });

  it("shows the circular-dependency-check callout", () => {
    render(<DependencyView upstream={UPSTREAM} current={CURRENT} downstream={DOWNSTREAM} />);
    expect(screen.getByText("Circular dependency check passed")).toBeDefined();
  });

  it("calls onNavigate when a downstream node is clicked", async () => {
    const onNavigate = vi.fn();
    render(
      <DependencyView
        upstream={UPSTREAM}
        current={CURRENT}
        downstream={DOWNSTREAM}
        onNavigate={onNavigate}
      />
    );
    await userEvent.click(screen.getByText("EMEA Infra Desk"));
    expect(onNavigate).toHaveBeenCalledWith("teams");
  });

  it("renders without a downstream list", () => {
    render(<DependencyView upstream={UPSTREAM} current={CURRENT} downstream={[]} />);
    expect(screen.getByText("Tier 1 routing")).toBeDefined();
  });
});
