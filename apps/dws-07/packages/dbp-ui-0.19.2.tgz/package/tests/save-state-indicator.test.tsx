import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { SaveStateIndicator, SAVE_STATE } from "../src/components/save-state-indicator.js";

afterEach(() => {
  cleanup();
});

describe("SaveStateIndicator", () => {
  it("renders nothing for the clean state", () => {
    const { container } = render(<SaveStateIndicator state="clean" />);
    expect(container.firstChild).toBeNull();
  });

  it("renders an 'Unsaved changes' badge for the dirty state", () => {
    render(<SaveStateIndicator state="dirty" />);
    expect(screen.getByText("Unsaved changes")).toBeDefined();
  });

  it("renders a note for every non-clean/non-dirty state", () => {
    const labels: Record<string, string> = {
      saving: "Saving…",
      saved: "Saved · just now",
      autosaved: "Draft autosaved",
      failed: "Save failed",
    };
    for (const state of SAVE_STATE.filter((s) => s !== "clean" && s !== "dirty")) {
      const { unmount } = render(<SaveStateIndicator state={state} />);
      expect(screen.getByText(labels[state]!)).toBeDefined();
      unmount();
    }
  });
});
