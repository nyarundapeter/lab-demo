import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { AnomalyInsightCard, type AnomalyInsightCardData } from "../src/components/anomaly-insight-card.js";

afterEach(() => { cleanup(); });

const DATA: AnomalyInsightCardData = {
  detected: "08:52 today",
  title: "Checkout error rate spiked",
  confidence: "high",
  expected: "0.6 – 0.9%",
  observed: "4.8%",
  causes: "Onset aligns with a recent deploy.",
  sources: [{ n: 1, type: "Metric", title: "Error rate", meta: "Live", fresh: "1 min", rel: "high" }],
};

describe("AnomalyInsightCard", () => {
  it("renders the expected/observed comparison and category", () => {
    render(<AnomalyInsightCard data={DATA} />);
    expect(screen.getByText("0.6 – 0.9%")).toBeDefined();
    expect(screen.getByText("4.8%")).toBeDefined();
    expect(screen.getByText("Anomaly")).toBeDefined();
    expect(screen.getByText("Possible causes")).toBeDefined();
  });

  it("renders the metric context chip when supplied", () => {
    render(
      <AnomalyInsightCard data={{ ...DATA, metric: "Error rate · EU-West" }} />,
    );
    expect(screen.getByText("Using Error rate · EU-West")).toBeDefined();
  });

  it("confirms the anomaly and hides the action row", () => {
    const onConfirm = vi.fn();
    render(<AnomalyInsightCard data={DATA} onConfirm={onConfirm} />);
    fireEvent.click(screen.getByTestId("anomaly-insight-confirm"));
    expect(onConfirm).toHaveBeenCalled();
    expect(screen.getByText("Confirmed")).toBeDefined();
    expect(screen.queryByTestId("anomaly-insight-confirm")).toBeNull();
  });

  it("dismisses the anomaly", () => {
    const onDismiss = vi.fn();
    render(<AnomalyInsightCard data={DATA} onDismiss={onDismiss} />);
    fireEvent.click(screen.getByRole("button", { name: "Dismiss" }));
    expect(onDismiss).toHaveBeenCalled();
    expect(screen.getByText("Dismissed")).toBeDefined();
  });

  it("renders nothing for the source list when sources is empty", () => {
    render(<AnomalyInsightCard data={{ ...DATA, sources: [] }} />);
    expect(screen.queryByText(/Supporting data · /)).toBeNull();
  });
});
