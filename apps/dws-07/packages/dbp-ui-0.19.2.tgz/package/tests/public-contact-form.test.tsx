import { describe, it, expect, vi, beforeEach, afterEach } from "vitest"
import { render, screen, fireEvent, waitFor, cleanup } from "@testing-library/react"
import { PublicContactForm } from "../src/components/public-contact-form.js"

const baseProps = {
  headline: "Tell us what you need.",
  body: "We will help you get started.",
  email: "info@digitalqatalyst.com",
}

describe("PublicContactForm", () => {
  beforeEach(() => {
    vi.restoreAllMocks()
  })

  afterEach(() => {
    cleanup()
  })

  it("renders headline, body and contact email", () => {
    render(<PublicContactForm {...baseProps} />)
    expect(screen.getByText("Tell us what you need.")).toBeDefined()
    expect(screen.getByText("We will help you get started.")).toBeDefined()
    expect(screen.getAllByText("info@digitalqatalyst.com").length).toBeGreaterThanOrEqual(1)
  })

  it("shows validation errors and does not POST when empty", () => {
    const fetchSpy = vi.fn()
    vi.stubGlobal("fetch", fetchSpy)
    render(<PublicContactForm {...baseProps} />)
    fireEvent.click(screen.getByRole("button", { name: /send request/i }))
    expect(screen.getByText("First name is required")).toBeDefined()
    expect(fetchSpy).not.toHaveBeenCalled()
  })

  it("renders interest + need selects only when options provided", () => {
    const { rerender } = render(<PublicContactForm {...baseProps} />)
    expect(screen.queryByLabelText(/What are you exploring/i)).toBeNull()
    rerender(<PublicContactForm {...baseProps} interestOptions={["A", "B"]} needOptions={["C"]} />)
    expect(screen.getByLabelText(/What are you exploring/i)).toBeDefined()
    expect(screen.getByLabelText(/What do you need/i)).toBeDefined()
  })

  it("POSTs to the action endpoint and shows confirmation on success", async () => {
    const fetchSpy = vi.fn().mockResolvedValue({ ok: true, json: async () => ({ ok: true }) })
    vi.stubGlobal("fetch", fetchSpy)
    render(<PublicContactForm {...baseProps} action="/api/platform/notify/contact" />)

    fireEvent.change(screen.getByLabelText(/First Name/i), { target: { value: "Ada" } })
    fireEvent.change(screen.getByLabelText(/Last Name/i), { target: { value: "Lovelace" } })
    fireEvent.change(screen.getByLabelText(/Work Email/i), { target: { value: "ada@x.com" } })
    fireEvent.change(screen.getByLabelText(/Organisation/i), { target: { value: "DQ" } })
    fireEvent.change(screen.getByLabelText(/Your Message/i), { target: { value: "Hello" } })
    fireEvent.click(screen.getByLabelText(/I agree to the processing/i))
    fireEvent.click(screen.getByRole("button", { name: /send request/i }))

    await waitFor(() => expect(fetchSpy).toHaveBeenCalledTimes(1))
    expect(fetchSpy.mock.calls[0]![0]).toBe("/api/platform/notify/contact")
    await waitFor(() => expect(screen.getByText("We've got your request")).toBeDefined())
  })
})
