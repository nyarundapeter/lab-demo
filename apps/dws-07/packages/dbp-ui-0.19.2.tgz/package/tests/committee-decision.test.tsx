import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { CommitteeDecision } from "../src/components/committee-decision.js";
import type { CommitteeMemberVote } from "../src/components/committee-decision.js";

afterEach(() => { cleanup(); });

const MEMBERS: CommitteeMemberVote[] = [
  { id: "1", name: "Nadia Rahimi", vote: "approve", tag: "Chair" },
  { id: "2", name: "Omar Al-Hashimi", vote: "approve" },
  { id: "3", name: "Jonas Weber", vote: "reject" },
  { id: "4", name: "Leo Fischer", vote: "abstain" },
  { id: "5", name: "Grace Okonkwo", vote: "pending" },
];

describe("CommitteeDecision", () => {
  it("renders every member's vote and the vote tally", () => {
    render(
      <CommitteeDecision
        title="Change Approval Board"
        subtitle="REL-243 · Meeting Jul 12, 14:00"
        members={MEMBERS}
        quorum="4/5"
        quorumMet
      />,
    );
    expect(screen.getByTestId("committee-decision")).toBeDefined();
    expect(screen.getAllByTestId("committee-member-vote")).toHaveLength(5);
    expect(screen.getByText("2 for · 1 against · 1 abstain")).toBeDefined();
  });

  it("shows quorum-not-met tone when quorumMet is false", () => {
    render(
      <CommitteeDecision
        title="Change Approval Board"
        subtitle="REL-243"
        members={MEMBERS}
        quorum="4/5"
        quorumMet={false}
      />,
    );
    expect(screen.getByText("Quorum 4/5")).toBeDefined();
  });
});
