import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { ActionFooter } from "../src/components/action-footer.js";

afterEach(() => { cleanup(); });

describe("ActionFooter", () => {
  it("renders only the actions that are provided", () => {
    render(<ActionFooter primary={{ label: "Submit", onClick: () => {} }} />);
    expect(screen.getByRole("button", { name: "Submit" })).toBeDefined();
    expect(screen.queryByRole("button", { name: "Cancel" })).toBeNull();
  });

  it("dispatches onClick for each action", () => {
    const onPrimary = vi.fn();
    const onSecondary = vi.fn();
    const onTertiary = vi.fn();
    const onDestructive = vi.fn();
    render(
      <ActionFooter
        primary={{ label: "Submit", onClick: onPrimary }}
        secondary={{ label: "Cancel", onClick: onSecondary }}
        tertiary={{ label: "Save draft", onClick: onTertiary }}
        destructive={{ label: "Delete", onClick: onDestructive }}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Submit" }));
    fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
    fireEvent.click(screen.getByRole("button", { name: "Save draft" }));
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    expect(onPrimary).toHaveBeenCalledOnce();
    expect(onSecondary).toHaveBeenCalledOnce();
    expect(onTertiary).toHaveBeenCalledOnce();
    expect(onDestructive).toHaveBeenCalledOnce();
  });

  it("disables the primary action when requested", () => {
    render(<ActionFooter primary={{ label: "Submit", onClick: () => {}, disabled: true }} />);
    expect((screen.getByRole("button", { name: "Submit" }) as HTMLButtonElement).disabled).toBe(true);
  });

  it("renders a SaveStatus indicator when saveStatus is provided", () => {
    render(<ActionFooter primary={{ label: "Submit", onClick: () => {} }} saveStatus="saving" />);
    expect(screen.getByText("Saving…")).toBeDefined();
  });

  it("renders no SaveStatus indicator when omitted", () => {
    render(<ActionFooter primary={{ label: "Submit", onClick: () => {} }} />);
    expect(screen.queryByText("Saving…")).toBeNull();
  });
});
