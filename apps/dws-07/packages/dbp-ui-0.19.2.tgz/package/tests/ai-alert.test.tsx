import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { AiAlert, type AiAlertData } from "../src/components/ai-alert.js";

afterEach(() => { cleanup(); });

const DATA: AiAlertData = {
  title: "Predicted SLA breach across 4 open cases",
  detected: "Queue velocity suggests 4 Tier-2 cases will breach first-response within 2 hours.",
  confidence: "high",
  related: "Tier-2 queue",
  evidence: [
    "Inbound rate up 40% vs. the trailing 7-day average for this hour.",
    "Only 2 agents online; 3 typically staffed at this time.",
  ],
  action: "Review anomaly",
};

describe("AiAlert", () => {
  it("renders the title, detected description, and AI-generated label", () => {
    render(<AiAlert data={DATA} />);
    expect(screen.getByText(DATA.title as string)).toBeDefined();
    expect(screen.getByText(DATA.detected as string)).toBeDefined();
    expect(screen.getByText("AI-generated")).toBeDefined();
  });

  it("hides evidence until expanded", () => {
    render(<AiAlert data={DATA} />);
    expect(screen.queryByText(/Inbound rate up 40%/)).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: /Show evidence/ }));
    expect(screen.getByText(/Inbound rate up 40%/)).toBeDefined();
  });

  it("renders evidence expanded when defaultExpanded is set", () => {
    render(<AiAlert data={DATA} defaultExpanded />);
    expect(screen.getByText(/Inbound rate up 40%/)).toBeDefined();
  });

  it("calls onAction when the recommended action is clicked", () => {
    const onAction = vi.fn();
    render(<AiAlert data={DATA} onAction={onAction} />);
    fireEvent.click(screen.getByRole("button", { name: "Review anomaly" }));
    expect(onAction).toHaveBeenCalledTimes(1);
  });

  it("calls onDismiss when Dismiss is clicked", () => {
    const onDismiss = vi.fn();
    render(<AiAlert data={DATA} onDismiss={onDismiss} />);
    fireEvent.click(screen.getByRole("button", { name: "Dismiss" }));
    expect(onDismiss).toHaveBeenCalledTimes(1);
  });

  it("calls onFeedback with the rating", () => {
    const onFeedback = vi.fn();
    render(<AiAlert data={DATA} onFeedback={onFeedback} />);
    fireEvent.click(screen.getByRole("button", { name: "Helpful" }));
    expect(onFeedback).toHaveBeenCalledWith("up");
  });

  it("calls onOpenRelated when the related link is clicked", () => {
    const onOpenRelated = vi.fn();
    render(<AiAlert data={DATA} defaultExpanded onOpenRelated={onOpenRelated} />);
    fireEvent.click(screen.getByRole("button", { name: /Open supporting data/ }));
    expect(onOpenRelated).toHaveBeenCalledTimes(1);
  });
});
