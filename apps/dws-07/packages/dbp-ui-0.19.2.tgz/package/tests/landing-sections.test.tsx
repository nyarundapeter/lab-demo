import { describe, it, expect, afterEach } from "vitest"
import { render, screen, cleanup } from "@testing-library/react"
import { ShieldCheck, Zap } from "lucide-react"
import {
  LandingFeatures,
  LandingHowItWorks,
  LandingCta,
} from "../src/components/landing-sections.js"

afterEach(() => {
  cleanup()
})

/* ── LandingFeatures ──────────────────────────────────────────────────────── */

describe("LandingFeatures", () => {
  it("renders the section landmark with heading", () => {
    render(<LandingFeatures />)
    // Region is named by its aria-labelledby h2 — "Everything your team needs in one place."
    expect(screen.getByRole("region", { name: /Everything your team needs/i })).toBeDefined()
  })

  it("renders custom headline", () => {
    render(<LandingFeatures headline="Custom headline" />)
    expect(screen.getByText("Custom headline")).toBeDefined()
  })

  it("renders overline", () => {
    render(<LandingFeatures overline="Platform features" />)
    expect(screen.getByText("Platform features")).toBeDefined()
  })

  it("renders provided feature items", () => {
    render(
      <LandingFeatures
        items={[
          { icon: <ShieldCheck size={20} />, title: "Secure access", description: "Role-based." },
          { icon: <Zap size={20} />, title: "Fast delivery", description: "Rapid." },
        ]}
      />
    )
    // Items appear in both the feature list AND the card grid — use getAllByText
    expect(screen.getAllByText("Secure access").length).toBeGreaterThan(0)
    expect(screen.getAllByText("Fast delivery").length).toBeGreaterThan(0)
  })

  it("renders default placeholder cards when no items provided", () => {
    render(<LandingFeatures />)
    expect(screen.getByText("Governed workflows")).toBeDefined()
  })

  it("renders optional see-more link", () => {
    render(<LandingFeatures linkLabel="See all" linkHref="#all" />)
    const link = screen.getByRole("link", { name: /See all/i })
    expect(link).toBeDefined()
  })

  it("does not render link when linkLabel absent", () => {
    render(<LandingFeatures />)
    expect(screen.queryByRole("link", { name: /Explore/i })).toBeNull()
  })

})

/* ── LandingHowItWorks ────────────────────────────────────────────────────── */

describe("LandingHowItWorks", () => {
  it("renders the section landmark with heading", () => {
    render(<LandingHowItWorks />)
    // Region is named by its aria-labelledby h2 — "Up and running in minutes"
    expect(screen.getByRole("region", { name: /Up and running in minutes/i })).toBeDefined()
  })

  it("renders overline and headline", () => {
    render(<LandingHowItWorks overline="Steps" headline="Simple process" />)
    expect(screen.getByText("Steps")).toBeDefined()
    expect(screen.getByText("Simple process")).toBeDefined()
  })

  it("renders provided steps", () => {
    render(
      <LandingHowItWorks
        steps={[
          { title: "Connect", description: "Wire it up." },
          { title: "Configure", description: "Set it up." },
        ]}
      />
    )
    expect(screen.getByText("Connect")).toBeDefined()
    expect(screen.getByText("Configure")).toBeDefined()
  })

  it("renders default steps when none provided", () => {
    render(<LandingHowItWorks />)
    expect(screen.getByText("Request access")).toBeDefined()
  })

  it("step list is accessible via role=list", () => {
    render(<LandingHowItWorks />)
    expect(screen.getByRole("list")).toBeDefined()
  })

})

/* ── LandingCta ───────────────────────────────────────────────────────────── */

describe("LandingCta", () => {
  it("renders the section landmark with heading", () => {
    render(<LandingCta />)
    // Region named by aria-labelledby h2 — default headline text
    expect(screen.getByRole("region", { name: /Ready to transform/i })).toBeDefined()
  })

  it("renders headline and accent", () => {
    render(<LandingCta headline="Join us today" headlineAccent="Free forever." />)
    expect(screen.getByText("Join us today")).toBeDefined()
    expect(screen.getByText("Free forever.")).toBeDefined()
  })

  it("renders primary CTA link", () => {
    render(<LandingCta primaryCta={{ label: "Get Started", href: "/signup" }} />)
    const link = screen.getByRole("link", { name: /Get Started/i })
    expect(link).toBeDefined()
    expect((link as HTMLAnchorElement).href).toContain("/signup")
  })

  it("renders secondary CTA when provided", () => {
    render(
      <LandingCta
        primaryCta={{ label: "Get Started", href: "#" }}
        secondaryCta={{ label: "Book a demo", href: "/demo" }}
      />
    )
    expect(screen.getByRole("link", { name: /Book a demo/i })).toBeDefined()
  })

  it("does not render secondary CTA when absent", () => {
    render(<LandingCta />)
    expect(screen.queryByRole("link", { name: /demo/i })).toBeNull()
  })

  it("renders feature tile titles", () => {
    render(
      <LandingCta
        featureTiles={[
          { title: "SOC 2", description: "Compliant" },
          { title: "GDPR", description: "Ready" },
        ]}
      />
    )
    expect(screen.getByText("SOC 2")).toBeDefined()
    expect(screen.getByText("GDPR")).toBeDefined()
  })

  it("renders default feature tiles when none provided", () => {
    render(<LandingCta />)
    expect(screen.getByText("Enterprise-grade security")).toBeDefined()
  })
})
