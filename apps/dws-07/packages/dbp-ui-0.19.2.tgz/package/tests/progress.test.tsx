import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Progress } from "../src/components/progress.js";

afterEach(() => { cleanup(); });

describe("Progress", () => {
  it("renders with progressbar role", () => {
    render(<Progress value={40} />);
    expect(screen.getByRole("progressbar")).toBeDefined();
  });

  it("reflects value in aria-valuenow", () => {
    render(<Progress value={75} />);
    const bar = screen.getByRole("progressbar");
    expect(bar.getAttribute("aria-valuenow")).toBe("75");
  });

  it("clamps value to 0-100", () => {
    render(<Progress value={150} />);
    const bar = screen.getByRole("progressbar");
    expect(bar.getAttribute("aria-valuenow")).toBe("100");
  });

  it("shows label text when provided", () => {
    render(<Progress value={50} label="Upload progress" />);
    expect(screen.getByText("Upload progress")).toBeDefined();
  });

  it("shows percentage when showLabel=true", () => {
    render(<Progress value={33} showLabel />);
    expect(screen.getByText("33%")).toBeDefined();
  });

  it("renders a target marker at the target position when target is set", () => {
    render(<Progress value={40} target={75} />);
    const marker = screen.getByTestId("progress-target-marker");
    expect(marker.style.left).toBe("75%");
  });

  it("does not render a target marker when target is omitted", () => {
    render(<Progress value={40} />);
    expect(screen.queryByTestId("progress-target-marker")).toBeNull();
  });
});
