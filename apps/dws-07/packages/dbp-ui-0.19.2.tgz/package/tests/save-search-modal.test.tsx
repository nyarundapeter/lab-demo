import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { SaveSearchModal } from "../src/components/save-search-modal.js";

afterEach(() => { cleanup(); });

const CHIPS = [{ label: "renewal" }, { label: "in:deals" }, { label: "status:open", kind: "filter" as const }];

describe("SaveSearchModal", () => {
  it("renders nothing when closed", () => {
    render(<SaveSearchModal open={false} onOpenChange={vi.fn()} queryChips={CHIPS} onSave={vi.fn()} />);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("shows the query chips and default name when open", () => {
    render(<SaveSearchModal open onOpenChange={vi.fn()} queryChips={CHIPS} defaultName="At-risk renewals" onSave={vi.fn()} />);
    expect(screen.getByDisplayValue("At-risk renewals")).toBeDefined();
    expect(screen.getByText("renewal")).toBeDefined();
    expect(screen.getByText("status:open")).toBeDefined();
  });

  it("disables Save when the name is empty", async () => {
    const user = userEvent.setup();
    render(<SaveSearchModal open onOpenChange={vi.fn()} queryChips={CHIPS} defaultName="Renewals" onSave={vi.fn()} />);
    const nameInput = screen.getByDisplayValue("Renewals");
    await user.clear(nameInput);
    expect((screen.getByRole("button", { name: /save search/i }) as HTMLButtonElement).disabled).toBe(true);
  });

  it("calls onSave with the captured name/pin/alert state", async () => {
    const user = userEvent.setup();
    const onSave = vi.fn();
    render(<SaveSearchModal open onOpenChange={vi.fn()} queryChips={CHIPS} defaultName="Renewals" onSave={onSave} />);
    await user.click(screen.getByRole("button", { name: /save search/i }));
    expect(onSave).toHaveBeenCalledWith({ name: "Renewals", pinToSidebar: true, alertOn: true, alertFrequency: "realtime" });
  });
});
