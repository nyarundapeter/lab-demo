import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { EnvPill } from "../src/components/env-pill.js";

afterEach(() => { cleanup(); });

describe("EnvPill", () => {
  it("defaults to the dev environment mark", () => {
    render(<EnvPill />);
    expect(screen.getByText("DEV")).toBeDefined();
    expect(screen.getByTitle("Development environment")).toBeDefined();
  });

  it("renders each environment's mark and title", () => {
    render(<EnvPill env="test" />);
    expect(screen.getByText("TEST")).toBeDefined();
    expect(screen.getByTitle("Test environment")).toBeDefined();
    cleanup();

    render(<EnvPill env="stage" />);
    expect(screen.getByText("STG")).toBeDefined();
    expect(screen.getByTitle("Staging environment")).toBeDefined();
    cleanup();

    render(<EnvPill env="prod" />);
    expect(screen.getByText("PROD")).toBeDefined();
    expect(screen.getByTitle("Production environment")).toBeDefined();
  });

  it("renders the region label when provided", () => {
    render(<EnvPill env="prod" region="eu-west-1" />);
    expect(screen.getByText("· eu-west-1")).toBeDefined();
  });

  it("omits the region label when not provided", () => {
    const { container } = render(<EnvPill env="prod" />);
    expect(container.textContent).not.toContain("·");
  });
});
