import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { RadioGroup } from "../src/components/radio-group.js";

afterEach(() => { cleanup(); });

const OPTIONS = [
  { value: "a", label: "Option A" },
  { value: "b", label: "Option B", description: "Description for B" },
  { value: "c", label: "Option C", disabled: true },
];

describe("RadioGroup", () => {
  it("renders a radiogroup with a radio per option", () => {
    render(<RadioGroup name="test" options={OPTIONS} />);
    expect(screen.getByRole("radiogroup")).toBeDefined();
    expect(screen.getAllByRole("radio")).toHaveLength(3);
  });

  it("marks the selected option's radio as checked", () => {
    render(<RadioGroup name="test" options={OPTIONS} value="b" />);
    const radios = screen.getAllByRole("radio") as HTMLInputElement[];
    expect(radios.find((r) => r.value === "b")?.checked).toBe(true);
    expect(radios.find((r) => r.value === "a")?.checked).toBe(false);
  });

  it("calls onValueChange with the clicked option's value", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<RadioGroup name="test" options={OPTIONS} value="a" onValueChange={onValueChange} />);
    await user.click(screen.getByText("Option B"));
    expect(onValueChange).toHaveBeenCalledWith("b");
  });

  it("renders a per-option description when provided", () => {
    render(<RadioGroup name="test" options={OPTIONS} variant="card" />);
    expect(screen.getByText("Description for B")).toBeDefined();
  });

  it("disables a per-option disabled radio even when the group is enabled", () => {
    render(<RadioGroup name="test" options={OPTIONS} />);
    const radios = screen.getAllByRole("radio") as HTMLInputElement[];
    expect(radios.find((r) => r.value === "c")?.disabled).toBe(true);
    expect(radios.find((r) => r.value === "a")?.disabled).toBe(false);
  });

  it("disables every option when the group-level disabled prop is set", () => {
    render(<RadioGroup name="test" options={OPTIONS} disabled />);
    const radios = screen.getAllByRole("radio") as HTMLInputElement[];
    expect(radios.every((r) => r.disabled)).toBe(true);
  });
});
