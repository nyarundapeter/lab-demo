import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { PolicyList } from "../src/components/policy-list.js";

afterEach(() => { cleanup(); });

describe("PolicyList", () => {
  it("renders every item's label", () => {
    render(
      <PolicyList
        items={[
          { label: "At least 12 characters", met: true },
          { label: "A number", met: false },
        ]}
      />,
    );
    expect(screen.getByText("At least 12 characters")).toBeDefined();
    expect(screen.getByText("A number")).toBeDefined();
  });

  it("renders a check mark only for met items", () => {
    render(
      <PolicyList
        items={[
          { label: "Met rule", met: true },
          { label: "Unmet rule", met: false },
        ]}
      />,
    );
    const checkIcons = document.querySelectorAll("svg");
    expect(checkIcons.length).toBe(1);
  });
});
