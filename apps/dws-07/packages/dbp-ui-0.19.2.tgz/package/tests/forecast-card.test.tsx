import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { ForecastCard, type ForecastCardData } from "../src/components/forecast-card.js";

afterEach(() => {
  cleanup();
});

const DATA: ForecastCardData = {
  label: "SLA breach risk — open high-priority cases",
  value: "5 cases likely to breach",
  period: "Next 48 hours",
  updated: "6m ago",
  confidence: "medium",
  confidenceNote: "Forecast uncertainty widens beyond 30 hours.",
  range: "3–7 cases (80% interval)",
  target: "Target: ≤ 2 breaches / week",
  drivers: ["Queue depth +34% vs. last week", "One fewer agent on EU shift"],
  basis: "12 weeks of resolution-time history.",
};

describe("ForecastCard", () => {
  it("renders oracle forecast chrome and value", () => {
    render(<ForecastCard data={DATA} />);
    expect(screen.getByText("AI forecast")).toBeDefined();
    expect(screen.getByText("5 cases likely to breach")).toBeDefined();
    expect(screen.getByText(/Confidence range: 3–7 cases/)).toBeDefined();
    expect(screen.getByText(/Historical basis:/)).toBeDefined();
    expect(screen.getAllByText("AI prediction").length).toBeGreaterThanOrEqual(2);
    expect(screen.getByText("Main assumptions & key drivers")).toBeDefined();
    expect(screen.getByText("Queue depth +34% vs. last week")).toBeDefined();
  });

  it("fires regenerate and scenario actions", () => {
    const onRegenerate = vi.fn();
    const onScenario = vi.fn();
    const onDetail = vi.fn();
    render(
      <ForecastCard
        data={DATA}
        onRegenerate={onRegenerate}
        onScenarioOptions={onScenario}
        onOpenDetail={onDetail}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Regenerate" }));
    expect(onRegenerate).toHaveBeenCalled();
    fireEvent.click(screen.getByTestId("forecast-scenario-options"));
    expect(onScenario).toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: /Open forecast detail/ }));
    expect(onDetail).toHaveBeenCalled();
  });
});
