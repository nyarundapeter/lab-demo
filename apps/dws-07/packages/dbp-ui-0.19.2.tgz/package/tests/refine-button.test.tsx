import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { RefineButton } from "../src/components/refine-button.js";

afterEach(() => { cleanup(); });

describe("RefineButton", () => {
  it("opens the popover and dispatches onRefine with the picked axis and value", async () => {
    const onRefine = vi.fn();
    render(<RefineButton onRefine={onRefine} />);
    fireEvent.click(screen.getByRole("button", { name: "Refine" }));
    const brief = await screen.findByRole("button", { name: "Brief" });
    fireEvent.click(brief);
    expect(onRefine).toHaveBeenCalledWith("length", "Brief");
  });

  it("dispatches a tone pick", async () => {
    const onRefine = vi.fn();
    render(<RefineButton onRefine={onRefine} />);
    fireEvent.click(screen.getByRole("button", { name: "Refine" }));
    const formal = await screen.findByRole("button", { name: "Formal" });
    fireEvent.click(formal);
    expect(onRefine).toHaveBeenCalledWith("tone", "Formal");
  });
});
