import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { EmptyState } from "../src/components/empty-state.js";
import { ErrorState } from "../src/components/error-state.js";

afterEach(() => { cleanup(); });

describe("EmptyState", () => {
  it("renders title and description", () => {
    render(<EmptyState title="No results" description="Try a different filter" />);
    expect(screen.getByText("No results")).toBeDefined();
    expect(screen.getByText("Try a different filter")).toBeDefined();
  });

  it("renders action slot", () => {
    render(
      <EmptyState title="Empty" action={<button>Add item</button>} />
    );
    expect(screen.getByRole("button", { name: "Add item" })).toBeDefined();
  });
});

describe("ErrorState", () => {
  it("renders with role=alert", () => {
    render(<ErrorState error={new Error("Fetch failed")} />);
    expect(screen.getByRole("alert")).toBeDefined();
    expect(screen.getByText("Fetch failed")).toBeDefined();
  });

  it("shows custom title", () => {
    render(<ErrorState title="Oops!" />);
    expect(screen.getByText("Oops!")).toBeDefined();
  });
});
