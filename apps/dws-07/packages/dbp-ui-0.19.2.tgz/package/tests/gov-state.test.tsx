import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { GovState, GOV_STATE } from "../src/components/gov-state.js";
import type { GovStateKind } from "../src/components/gov-state.js";

afterEach(() => { cleanup(); });

describe("GovState", () => {
  it("renders the default title for every governance state kind", () => {
    for (const state of Object.keys(GOV_STATE) as GovStateKind[]) {
      const { unmount } = render(<GovState state={state} manual={false} />);
      expect(screen.getByText(GOV_STATE[state].title)).toBeDefined();
      unmount();
    }
  });

  it("defaults to the unavailable state when none is given", () => {
    render(<GovState manual={false} />);
    expect(screen.getByText(GOV_STATE.unavailable.title)).toBeDefined();
  });

  it("overrides the title via the title prop", () => {
    render(<GovState state="restricted" title="Custom title" manual={false} />);
    expect(screen.getByText("Custom title")).toBeDefined();
    expect(screen.queryByText(GOV_STATE.restricted.title)).toBeNull();
  });

  it("renders the why and next lines when given", () => {
    render(<GovState state="insufficient" why="Not enough records." next="Add more data." manual={false} />);
    expect(screen.getByText("Not enough records.")).toBeDefined();
    expect(screen.getByText("Add more data.")).toBeDefined();
  });

  it("shows the manual-fallback line by default", () => {
    render(<GovState state="disabled" />);
    expect(screen.getByText(/complete this manually/i)).toBeDefined();
  });

  it("hides the manual-fallback line when manual is false", () => {
    render(<GovState state="disabled" manual={false} />);
    expect(screen.queryByText(/complete this manually/i)).toBeNull();
  });

  it("renders the actions slot when given", () => {
    render(
      <GovState state="error" manual={false} actions={<button type="button">Retry</button>} />
    );
    expect(screen.getByRole("button", { name: "Retry" })).toBeDefined();
  });

  it("uses role=alert for error and review tones, role=status otherwise", () => {
    const { unmount: unmountError } = render(<GovState state="error" manual={false} />);
    expect(screen.getByRole("alert")).toBeDefined();
    unmountError();

    const { unmount: unmountReview } = render(<GovState state="review" manual={false} />);
    expect(screen.getByRole("alert")).toBeDefined();
    unmountReview();

    render(<GovState state="unavailable" manual={false} />);
    expect(screen.getByRole("status")).toBeDefined();
  });
});
