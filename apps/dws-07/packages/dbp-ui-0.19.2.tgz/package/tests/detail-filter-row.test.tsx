import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { DetailFilterRow } from "../src/components/detail-filter-row.js";

afterEach(() => {
  cleanup();
});

describe("DetailFilterRow", () => {
  it("renders the count label", () => {
    render(<DetailFilterRow countLabel="12 of 513" />);
    expect(screen.getByText("12 of 513")).toBeDefined();
  });

  it("renders mapping options and reports clicks", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <DetailFilterRow
        countLabel="1 of 1"
        mapping={{
          options: [
            { value: "all", label: "All" },
            { value: "mapped", label: "Mapped" },
          ],
          active: "all",
          onChange,
        }}
      />,
    );
    await user.click(screen.getByText("Mapped"));
    expect(onChange).toHaveBeenCalledWith("mapped");
  });

  it("renders a search input and reports changes", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(
      <DetailFilterRow
        countLabel="1 of 1"
        search={{ value: "", onChange, placeholder: "Search…" }}
      />,
    );
    await user.type(screen.getByPlaceholderText("Search…"), "a");
    expect(onChange).toHaveBeenCalledWith("a");
  });
});
