import * as React from "react";
import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { RichTextField } from "../src/components/rich-text-field.js";

afterEach(() => {
  cleanup();
});

describe("RichTextField — Tiptap minimal profile (reused from ActivityComposer, ADR-0048)", () => {
  it("typing updates the bound value via onChange", async () => {
    const user = userEvent.setup();
    function Harness() {
      const [value, setValue] = React.useState("");
      return (
        <>
          <RichTextField id="notes" value={value} onChange={setValue} />
          <output data-testid="value">{value}</output>
        </>
      );
    }
    render(<Harness />);
    const textbox = screen.getByRole("textbox");
    await user.type(textbox, "Hello world");
    await waitFor(() => expect(screen.getByTestId("value").textContent).toContain("Hello world"));
  });

  it("toggles bold via the toolbar", async () => {
    const user = userEvent.setup();
    function Harness() {
      const [value, setValue] = React.useState("");
      return <RichTextField id="notes" value={value} onChange={setValue} />;
    }
    render(<Harness />);
    const textbox = screen.getByRole("textbox");
    await user.click(textbox);
    await user.click(screen.getByRole("button", { name: "Bold" }));
    await user.type(textbox, "urgent");
    await waitFor(() => expect(textbox.innerHTML).toContain("<strong>"));
  });

  it("initializes from an existing value", () => {
    render(<RichTextField id="notes" value="<p>Existing note</p>" onChange={vi.fn()} />);
    expect(screen.getByText("Existing note")).toBeDefined();
  });
});
