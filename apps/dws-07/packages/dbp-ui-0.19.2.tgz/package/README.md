# @dbp/ui

The DBP Blueprint's shared component library — the primary UI surface every generated solution app builds on. Exports primitives (Button, Input, Tabs, Card, Badge, Separator, Skeleton, DropdownMenu, Popover, ScrollArea), layout/shell components (SlotFrame, AppTopBar, AppChrome, AppFooter, PageHeader, Breadcrumb, Grid/Col), domain components (CatalogCard, CollectionToolbar, AdminSettingsForm, LoginPage, MicrosoftSignInButton, PublicHeader/PublicPageHeader/PublicContactForm, LegalPageLayout, MeshSection, LandingFooter), the cross-cutting `ShortcutProvider`/`useShortcuts`/`ShortcutHelp` keyboard-shortcut manager, and a `Toaster`/`toast` notification API — plus a `./bindings` entry point and a wildcard `./*` export exposing individual `src/components/*.tsx` files directly. It wires in several Layer 06 Platform Services (`@dbp/ps-ai`, `@dbp/ps-audit`, `@dbp/ps-notif`, `@dbp/ps-rbac`, `@dbp/ps-search`) as direct dependencies, and Radix UI primitives + `react-hook-form`/`zod` for interactive components.

**Tier:** shared

## Exports
| Export | Path |
|---|---|
| `.` | `./src/index.ts` |
| `./bindings` | `./src/bindings/index.ts` |
| `./*` | `./src/components/*.tsx` |

No `publishConfig.exports` override — ships raw TSX source (no build step); tarball-installed standalones must list this package in `next.config.ts`'s `transpilePackages` (see `docs/08-contributing/package-distribution.md` §"Corrected full export recipe").

## Config schema
N/A — no config schema in this package (component library, not config). Component prop types (e.g. `ButtonProps`, `AppChromeProps`, `PageHeaderProps`) are hand-authored TS types, not Zod-derived — this package is UI, not a data-model source of truth (that's `@dbp/contracts`).

## Consumed by
Generator emit — by far the most emitted-into import across `scripts/scaffold-solution.mjs` (60+ import sites): `PageHeader`, `Breadcrumb`, `AppChrome`, `AppFooter`, `AdminSettingsForm`, `CollectionToolbar`, `LoginPage`, `MicrosoftSignInButton`, `PublicHeader`, `MeshSection`, `toast`, and more are all emitted directly into generated app code across every solution.

## Shipping
Workspace package during monorepo development (`workspace:*`). For standalone repos, it ships as a committed tarball (`file:packages/dbp-ui-0.1.0.tgz`) resolved via `.pnpmfile.cjs` — critically, the standalone's own `tailwind.config.mjs` `content` globs must scan the vendored `.pnpm/@dbp+*` path or `@dbp/ui`'s classes get purged (see `docs/08-contributing/package-distribution.md` §3b).

See [CHANGELOG.md](./CHANGELOG.md) for release history.
