# Changelog

All notable changes to this package are documented here.

## [0.19.2] - 2026-07-31
### Changed
- `WorkspaceHomeClosing` — vertical outcome cards (mono `01`–`04` above title),
  staggered `animate-home-closing-fadein` entrance, token-coloured particle
  canvas (`useWorkspaceHomeClosingCanvas`, no hardcoded client greens), soft
  secondary wash. Story args updated to the EA closing composition.

## [0.19.1] - 2026-07-31
### Changed
- `WorkspaceHomeJourney` orbital visual — Discover (step 02) organic blob
  core (`--core-rotation: 18deg`), spinning orbit ring, light sweep,
  particles, and soft disc using `animate-home-journey-*` utilities from
  `@dbp/design-tokens` 0.4.2. Content column layout unchanged.

## [0.19.0] - 2026-07-28
### Fixed
- **`AppSidebar` (D2):** sidebar nav rows that navigate (childless leaf/group
  items, nested children) now render as real `<a href>` elements instead of
  `<button>`. Right-click "open in new tab", middle-click, Ctrl/Cmd/Shift-click,
  and native URL-preview-on-hover all work again; a plain left click still
  preventDefaults and calls `onNavigate` for client-side routing. Rows that
  only expand/collapse a group (items with `children`) remain `<button>` —
  that's not navigation. Screen readers now correctly announce these rows as
  links. `tests/app-sidebar.test.tsx` role queries updated from `"button"` to
  `"link"` for the now-anchor leaf rows to match the corrected DOM.
- **`AppTopBar`/`Breadcrumb` (D5):** at mobile width the top bar's breadcrumb
  protected every ancestor crumb at full width (`shrink-0`) and left only a
  `min-w-[3ch]` floor for the terminal (page-identity) crumb — with 5 action
  icons holding `shrink-0` on the right, all the squeeze landed on the one
  element that cannot be recovered from anywhere else on the page (ADR-0052 /
  Amendment D-2 removed the page-level `PageHeader` on the strength of the
  top bar owning that job), truncating it to ~3 characters. `Breadcrumb`
  (`nowrap` mode) now hides ancestor crumbs below `sm` and lets the terminal
  crumb claim `flex-1 min-w-0` — the page name wins the space; at `sm`+,
  ancestors reappear and truncate/shrink individually instead of being
  protected. `AppTopBar` collapses the theme toggle, notifications, and
  settings controls into a single `Popover`-based "More actions" trigger
  below `sm`; the sidebar hamburger (rendered by the shell) and the
  avatar/account chip stay inline at every width. Global search already
  collapsed to an icon below `xl` and needed no change.

### Changed
- `AppSidebar`/`AppTopBar` and the collapsed-rail flyout (`@dbp/shell-transaction`)
  now depend on this minor's behaviour change (nav rows as `<a>`, not `<button>`) —
  bumped minor rather than patch since role-based queries against these
  components need updating (see above).

## [0.18.0] - 2026-07-27
### Changed
**`ThemeToggle` no longer follows the OS colour scheme; light is the default.** Previously a
first visit with no stored preference consulted `prefers-color-scheme`, so anyone on a dark
OS opened the app in dark — a theme the screens were never signed off in. The design system
is light-first (content surfaces are white by contract) and every design reference is
authored in light; dark is a verified-but-secondary mode. Dark remains one click away and,
once chosen, sticks.

### Fixed
**An OS preference was being captured as if it were a user choice.** The apply-effect wrote to
`localStorage` on every mount, not only on an explicit toggle, so a browser that had ever
loaded the app on a dark OS had `dark` persisted permanently. Changing the default alone would
not have reached those users — their stored value would keep winning. Persistence now happens
only on an explicit click, and the storage key moved to `dbp-theme-v2` so previously
auto-captured values are ignored.

## [0.17.12] - 2026-07-28
### Changed
- APP.F12 authenticated-home sections — user-reviewed polish pass on
  `workspace-home-{hero,platform,journey,closing}.tsx` and
  `workspace-home-scale.ts`:
  - Halved `sectionVerticalRhythm` (`py-16 sm:py-20 lg:py-24` →
    `py-10 sm:py-12 lg:py-14`) so adjacent sections no longer stack to
    ~192px of dead space; hero now consumes the same shared constant on
    its inner wrapper instead of inlining its own copy.
  - Alternated section backgrounds down the page:
    Hero `--color-surface` (grey) → Platform `--color-surface-content`
    (white) → Journey `--color-surface` (grey) → Closing
    `--color-surface-content` (white, coral wash retained at the top).
  - Enforced "a card is never the same colour as its section" for every
    card/tile: Platform's lead feature card and capability cards now sit
    on a solid `--color-surface` (previously the capability cards matched
    the new white section, and the lead card's icon tile used a
    translucent `color-mix` fill whose effective colour depended on
    whatever was behind it — replaced with the solid `surface-content`
    token). Closing's outcome tiles moved off a translucent
    `bg-[var(--color-surface)]/60 backdrop-blur-sm` onto a solid
    `--color-surface` fill so they contrast with the now-white Closing
    section. Journey's cards were already `surface-content` against a
    `surface` section and needed no change.
  - Journey's orb stage numeral (`01`–`04`) moved off `font-mono` onto a
    non-mono `orbNumeralClass` (new `workspace-home-scale.ts` export) —
    mono stays reserved for small uppercase meta text (chips, metric
    labels), matching sibling usage in `catalog-card.tsx`/`app-footer.tsx`/
    `app-top-bar.tsx`/`code-input.tsx`. Platform's capability chips keep
    `font-mono` (matches that same sibling pattern) but the arbitrary
    `tracking-[0.04em]` was replaced with the named `tracking-wider`.

## [0.17.11] - 2026-07-28
### Removed
- `HomeHero` (`home-hero.tsx`) — the last consumer was the pre-APP.F12-redo
  `/home` composition; the authenticated home now composes
  `WorkspaceHomeHero`/`WorkspaceHomePlatform`/`WorkspaceHomeJourney`/
  `WorkspaceHomeClosing` instead, leaving `HomeHero` with zero consumers.
  Stories and tests removed with it. `WorkspaceGreetingCard` was assessed
  for the same treatment but retained — it is still imported by committed
  `/home` pages in `apps/dia-03`, `apps/dxp-01a`, `apps/wfd-01`,
  `apps/sdo-01`, `apps/dbp`, `apps/dws-03`, and `apps/sdo`.

## [0.17.10] - 2026-07-28
### Changed
- Renamed the four APP.F12 home section components to the repo's
  `workspace-` naming convention for authenticated-workspace components
  (matching `WorkspaceGreetingCard`): `AppHomeHero` → `WorkspaceHomeHero`
  (`app-home-hero.tsx` → `workspace-home-hero.tsx`), `PlatformSection` →
  `WorkspaceHomePlatform` (`platform-section.tsx` →
  `workspace-home-platform.tsx`), `JourneySection` → `WorkspaceHomeJourney`
  (`journey-section.tsx` → `workspace-home-journey.tsx`), `AppHomeClosing`
  → `WorkspaceHomeClosing` (`app-home-closing.tsx` →
  `workspace-home-closing.tsx`). Shared helpers renamed to match:
  `app-home-type-scale.ts` → `workspace-home-scale.ts`,
  `useJourneyStack`/`use-journey-stack.ts` →
  `useWorkspaceHomeJourneyStack`/`use-workspace-home-journey-stack.ts`.
  Pure rename — no prop or behaviour changes. `AppHomeHero`/`AppHomeClosing`
  carried the name of the `@dbp/organisms/app-home` package develop deleted
  2026-07-20 (see the tombstone at
  `packages/shared/contracts/src/solution-manifest.ts:565`); `PlatformSection`/
  `JourneySection` were too generic for a shared UI package.

## [0.17.9] - 2026-07-28
### Changed
- `AppHomeHero`, `PlatformSection`, `JourneySection`, `AppHomeClosing` polish
  pass: collapsed five divergent border-radius systems down to the token
  scale (`rounded-card` for every card/panel, `rounded-pill` for every
  pill-shaped badge/CTA — previously a mix of `rounded-[12px]`,
  `rounded-[22px]`, `rounded-pill`, and `rounded-full` for the same pill
  shape); collapsed three shadow systems (a bespoke `color-mix` hover
  shadow and a raw-`rgba()` inset highlight) down to one declared
  `elevatedCardShadowClass`/`elevatedCardHoverShadowClass` recipe plus a
  token-built `journeyOrbInsetShadowClass` (no more raw `rgba()`); unified
  the four sections' content-box width to `max-w-[1200px]` via a new
  `contentMaxWidthClass` (previously `max-w-[1240px]` on Hero/Closing,
  10px wider than the shell's actual 1200px `main` measure); hoisted ~20
  scattered arbitrary-pixel art-direction values (section min-heights,
  glow/orb sizing, card content widths) into named constants in
  `app-home-type-scale.ts` instead of inline magic numbers repeated across
  files. The journey orb's organic-blob radius is kept as a declared,
  commented divergence (decorative motif, not a card/panel). No prop
  surface changes.

## [0.17.8] - 2026-07-27
### Changed
- `AppHomeHero`, `PlatformSection`, `JourneySection`, `AppHomeClosing` now
  share one type-scale/spacing contract via new
  `packages/shared/ui/src/components/app-home-type-scale.ts` (eyebrow,
  section-heading, lead-card-title, card-title, sub-card-title, body,
  meta-label, metric-value rungs), fixing visual inconsistency across the
  four APP.F12 home sections: Journey step titles now share the Platform
  capability card's `card-title` rung (18px/600, was 18px/400); Closing
  outcome tile titles moved to a `sub-card-title` rung (14px/600, was
  12px/600 — collapsed to the same size as the eyebrow label above them);
  Closing's "READY WHEN YOU ARE" label now renders via `SectionLabel` (same
  props as every other section's eyebrow) instead of `Badge`, with the
  coral tint applied as a `className` color override; Closing's outer
  `<section>` now carries the same 3-tier vertical-rhythm padding
  (`py-16 sm:py-20 lg:py-24`) directly, matching Platform/Journey, instead
  of a mismatched `py-20 sm:py-24` on the section with horizontal padding
  on an inner wrapper.

## [0.17.7] - 2026-07-27
### Changed
- `emitHomeRoute()` (`scripts/scaffold-solution.mjs`) now emits the APP.F12
  4-section composition — `AppHomeHero` → `PlatformSection` →
  `JourneySection` → `AppHomeClosing` — instead of `LandingHero` +
  `WorkspaceGreetingCard` + `Landing*`. `WorkspaceGreetingCard` no longer
  renders on `/home` at all (design-spec §7 explicit non-feature).
### Removed
- Reverted the dead prop extensions added for the rejected `LandingHero`-based
  approach, now unused: `LandingHero`'s `headlinePrefix`/`headlineSuffix`/
  `artwork`/`artworkAlt`, `LandingFeatures`'s `lead`/`LandingFeaturesLead`/
  per-item `index`/`chips`, `LandingHowItWorks`'s per-step `metricValue`/
  `metricLabel`. No live consumer outside the generator/tests/stories being
  reverted in the same change.

## [0.17.6] - 2026-07-27
### Added
- `PlatformSection` and `JourneySection` — new APP.F12 authenticated-home
  section components rebuilding PR #65's "Platform" and "How It Works"
  sections as real components on canonical primitives (`Badge`,
  `SectionLabel`), per
  `docs/09-plans/app-f12-home-redo-2026-07-27/design-spec.md` §2/§3.
  `PlatformSection` renders a wide photo-lead feature card plus a 3-up grid
  of capability cards, each with an icon tile (icon inverts to solid accent
  fill on hover), index label, title, description, and `Badge` chip list.
  `JourneySection` renders 4 steps as a sticky card-stack (`useJourneyStack`
  hook, exported), each step's covered-depth driving a shrink/shift/shadow
  transform computed from real `getBoundingClientRect()` scroll geometry —
  ported from PR #65's `use-home-motion.ts` but reading the shell's real
  `--shell-header-h` token (`packages/shared/design-tokens/base.css`,
  confirmed via grep against `app-top-bar.tsx`) instead of the original's
  hardcoded `|| 68` fallback, and driven by React state rather than direct
  `element.style.setProperty` writes. Desktop-only and fully disabled under
  `prefers-reduced-motion: reduce` (all cards render at scale 1 / shift 0 /
  depth 0, `useJourneyStack`'s effect exits before touching any transform).
  Each step also renders a decorative "glass core" orb (index-varied shape).
  All new text sizes floor at `text-xs` (12px) per the type-floor ruling
  (headings use `text-3xl`, matching `AppHomeClosing`'s H2 rung).

## [0.17.5] - 2026-07-27
### Added
- `AppHomeHero` and `AppHomeClosing` — new APP.F12 authenticated-home section
  components rebuilding PR #65's orientation hero and closing/CTA sections as
  real components on canonical primitives (`Button`, `Badge`, `SectionLabel`),
  per `docs/09-plans/app-f12-home-redo-2026-07-27/design-spec.md` §1/§4.
  `AppHomeHero` renders an overline, prefix/accent/suffix headline, body,
  primary/secondary actions, trust signals, and an optional background
  `artwork` image (omitted entirely — no `<img>` — when absent, and hidden on
  load error so a broken artwork href never leaves a broken-image icon).
  `AppHomeClosing` renders a coral label, heading, body, two actions, and up
  to four glassmorphic outcome tiles with zero-padded index badges. Neither
  component renders a greeting card, preview panel, KPI row, activity feed,
  quick-links deck, or search input (explicit non-features, design-spec §7).
  All new text sizes floor at `text-xs` (12px) per the type-floor ruling.

## [0.17.4] - 2026-07-27
### Added
- `LandingHero` — optional `headlinePrefix?: string` / `headlineSuffix?: string` render a 2-line
  prefix/accent/suffix headline layout (prefix on its own leading line, suffix continuing after
  the orange accent span); optional `artwork?: string` / `artworkAlt?: string` render a
  manifest-supplied image above the `preview` slot (defaults alt text to the headline). When both
  `artwork` and `preview` are supplied, artwork stacks above preview rather than replacing it.
  Closes the APP.F12 orientation-home hero gap — `home.hero.headlinePrefix/headlineSuffix/artwork`
  were added to the manifest schema ahead of these props; now wired end to end through
  `emitHomeRoute()`. All additions optional and backwards-compatible; `headline`/`headlineAccent`
  render unchanged when prefix/suffix/artwork are absent.

## [0.17.3] - 2026-07-27
### Added
- `LandingFeatures` — optional `lead` prop (`{index?, title, description?}`) rendering a single
  wide lead/feature card above the item grid; per-item `LandingFeatureItem.index?: string` label;
  per-item `LandingFeatureItem.chips?: string[]` rendered via the canonical `Badge` primitive
  (`tone="gray"`). Supports the APP.F12 orientation-home "Platform" section (one wide feature card
  + capability cards with index/chips) per `docs/09-plans/app-f12-home-redo-2026-07-27/plan.md`.
  All additions optional and backwards-compatible.
- `LandingHowItWorks` — optional per-step `metricValue?: string` / `metricLabel?: string` rendered
  below the step description. Supports the APP.F12 "Journey" section step metrics. Optional,
  backwards-compatible.

## [0.17.2] - 2026-07-27
### Added
- `SheetContent` — optional `hideClose?: boolean` prop (default `false`, re-applied from the
  pre-merge 0.7.1 entry against the current detent/resize/swipe sheet API, GG-14). Lets a consumer
  that supplies its own header close control suppress the built-in top-right `DialogPrimitive.Close`
  `X` button, avoiding two stacked close buttons. Purely additive, default preserves existing
  behaviour byte-for-byte. `HideDefaultClose` story and `tests/sheet.test.tsx` cover both states.

## 0.17.1 — 2026-07-27 (craft review — AI molecules oracle align + de-dup reconciliation)

Workstream A craft pass on AI insight-rail molecules (branch
`feature/craft-review-rewiring-chamath`), merged onto `@dbp/ui` 0.17.0 and then
reconciled against the design-system de-dup wave's craft rules (PR #69 craft
review, `docs/plans/pr69-craft-review-2026-07-27.md`).

### Changed
- `AiSurface` — oracle head/body/foot bands + 3px AI rail; soft `--ai-border`
  frame; facet eyebrows via `SectionLabel` + `whitespace-nowrap`; white/content
  fill only (no purple wash). `headPad`/`bodyPad`/`footPad`'s 15px content pad
  now consumes the new `--ai-surface-pad-l` token (was an inline `pl-[15px]`
  literal) — see Added.
- `AnomalyInsightCard` / `ForecastCard` / `SuggestedAction` — oracle structure
  at ~340px rail width; SuggestedAction flat surface (not `AiActionCard` shell)
  with soft foot tint; dark-mode uses `--color-surface-content` (no literal
  `bg-white`). SuggestedAction polish: one-row chips, plain permission/
  confirmation text (matches oracle `.kv`), factory purple/navy (not teal).
- All 6 touched components (`AiExecSummary`, `AiSurface`/`AiSurfaceFacet`/
  `CategoryTag`, `AnomalyInsightCard`, `ForecastCard`, `SourceRow`,
  `SuggestedAction`) — every arbitrary `text-[Npx]` / `p-`,`m-`,`gap-[Npx]`
  literal reintroduced or newly added by the craft pass snapped back onto the
  named type/spacing scale (`text-xs`/`text-sm`/`text-base`, `pl-7`, `gap-1`,
  `py-2`/`py-3`, `mb-2`), per the design-system de-dup wave's own precedent
  (commit `ccfadf07`). `AnomalyInsightCard`'s `Stat` tile `min-h-[52px]` →
  `min-h-14`. Ratchet's `arbitraryTextPx`/`arbitrarySpacingPx` counters back
  at their locked baselines (9/3); zero exceptions taken.
- 5 raw `<button>` elements (in `AnomalyInsightCard`, `ForecastCard`,
  `SuggestedAction`) reintroduced by the craft pass replaced with the `Button`
  primitive (`variant="ghost" size="sm"`), restoring the pre-craft-pass
  pattern the de-dup wave's Wave 2 sweep established.
- `AiExecSummary`'s "Forecast" eyebrow restored to `SectionLabel` (was a
  hand-rolled `<span>` duplicating `SectionLabel`'s recipe).
- `forecast-card.stories.tsx` — `Default`/`HighConfidence` stories converted
  to `args`-driven (`args: { data }` + `render: (args) => ...`) so Storybook
  controls render; was `render`-only with hardcoded data, tripping the
  `storiesWithoutControls` ratchet gate.
- `ai-surface.stories.tsx` — fixture `type: "Incident"` → `type: "Case"`
  (`"Incident"` isn't a valid `AiSourceType`; typecheck failure from the craft
  pass, not previously caught).

### Added
- `--ai-surface-pad-l` design token (`packages/shared/design-tokens/base.css`)
  — 15px = 12px content pad (`--space-3`) + 3px accent-rail offset, an oracle
  layout constraint that doesn't land on the 4px `--space-*` scale. Replaces
  the inline `pl-[15px]` literal at all three `AiSurface` pad sites and in
  `SuggestedAction`'s own body/foot padding (approved scale extension, not an
  arbitrary-value exception).
- `--forecast-chart-h` design token (`packages/shared/ui/src/components/
  forecast-card.tsx`'s `ForecastMiniChart`) — 74px, exactly matching the
  hand-authored SVG's `viewBox`/`height` coordinates; not 4px-scale-snappable
  by nature, named rather than left as an inline arbitrary value.

### Removed
- `ForecastMiniChart` dropped from the `@dbp/ui` public barrel
  (`src/index.ts`) — it has zero real consumers outside `forecast-card.tsx`
  itself (which uses it internally as `ForecastCard`'s default chart), so it
  tripped the ratchet's zero-consumer-export gate. The component still exists
  and is still used internally; it is simply no longer re-exported until a
  real external consumer needs it. `ForecastCardData` remains exported (it's
  referenced by `ForecastCardProps.data`).

### Known follow-up (not fixed in this change — tracked, not silently dropped)
- **`SuggestedAction` no longer composes `AiActionCard`.** The craft pass
  rewrote `SuggestedAction` as a bespoke `AiSurface`-adjacent shell instead of
  using `AiActionCard` (the shared base extracted in `65f9ecab` specifically
  so `DataQualityCard` and `SuggestedAction` could share one shell). Accepted
  as-is for this merge — re-composing `SuggestedAction`'s new oracle-fidelity
  markup onto `AiActionCard`'s `bodyClassName`/`headerClassName`/etc. prop
  contract would risk losing that markup and wasn't required to pass the
  ratchet (no zero-consumer trip: `DataQualityCard` still uses it). Net
  effect: `AiActionCard` is now a single-consumer component. Follow-up:
  either re-compose `SuggestedAction` onto `AiActionCard`, or reconsider
  whether `AiActionCard` should keep existing as a shared abstraction with
  only one real consumer. See
  `docs/plans/pr69-vs-pr64-reconciliation-2026-07-27.md` §2.

## 0.17.0 — 2026-07-26 (workflow-system — CompactTracker + MilestoneTracker)

Closes the last two oracle-declared-awaiting-wiring gaps in the `wf-trackers.jsx` progress-
tracker family (`work-list/admin-workflow.md` annex F2 item 13):

### Added
- `CompactTracker` (new) — the single-row "workbench" variant of the progress tracker for dense
  list/table contexts, where `VerticalStageTracker`'s multi-line rows are too tall: one small
  `Badge` pill per stage, chevron-separated, done stages carry a check glyph, the active stage
  a pulse dot (`Badge`'s existing `dot` prop), upcoming stages fade. Takes `StageRow[]` directly
  (only `id`/`label`/`status` read) so it composes off the same data
  `VerticalStageTracker`/`ConditionalTracker`/`MilestoneTracker` consume.
- `MilestoneTracker` (new) — a thin semantic wrapper over `VerticalStageTracker`'s existing
  `variant="milestone"` rail (flag nodes, Target/Actual date labelling, slippage-risk badge +
  note tint), rendered non-expandable to match the oracle's always-open milestone rows. No new
  rendering logic — the milestone anatomy already existed in `VerticalStageTracker`, this only
  names the dedicated entry point the ledger was tracking as missing.
- Both components are oracle-declared with no consumers yet — allowlisted in
  `scripts/ui-zero-consumer-allowlist.json` pending page-level wiring.

## 0.16.0 — 2026-07-26 (design-system de-dup Wave 1.F/G — dashboard kit + auth-policy)

Design-system de-dup Wave 1.F part 1 (`docs/plans/design-system-dedup-2026-07-25/strategy.md` §4
R5/R7, `dashboard-kit` territory — shared KPI tile + density system + admin `StatusBadge`):

### Added
- `StatTile` — evolved into the canonical KPI/stat tile with the oracle's 8 declared variants
  (`dash-states.jsx` "KPI card variants": simple/with-trend/with-target[existing `attainment`]/
  with-sparkline[existing `sparkline`]/with-status/with-forecast/with-benchmark/clickable) plus
  loading/error/help states. New props: `status` (health dot), `forecast`/`benchmark` (footer
  callouts), `help` (tooltip), `loading`/`error` (replace value/trend with a skeleton or a
  compact "couldn't load" + retry), `bare` (renders without the `Card` shell, for embedding in
  another card shell), `hideLabel` (visually hides the overline label — `sr-only` — for the same
  embedding case). Existing `attainment`/`attainmentLabel` already served the "with-target"
  variant; `onClick` (inherited from `HTMLAttributes`) now gets `role="button"`/`tabIndex`/
  Enter-Space keyboard handling for the "clickable" variant. All new visuals sit behind optional
  props — no change for existing consumers that don't pass them.
- `StatTile` now reads `useDashboardDensity()` and applies executive/standard/operational
  padding, gap, and value type-scale deltas via existing named Tailwind steps only (no arbitrary
  values). `standard` (the default when no `DashboardDensityProvider` is present) renders
  identically to the previous fixed layout — zero visual delta for existing consumers.
- `dashboard-density.tsx` (new) — `DashboardDensityProvider` + `useDashboardDensity()`: the real
  3-mode dashboard density system (oracle DensityView, "same components, grid, colours — only
  rhythm and count change"). The provider also stamps the `data-density` DOM attribute the
  ported `dashboard.css` `.dash[data-density]` rules key off, so it's a drop-in replacement for a
  bare `data-density="executive"` div, not just an internal mechanism. Consumed by `StatTile` and
  `DashSection`.
- `DashSection` — now reads `useDashboardDensity()` for its section gap and title type scale
  (same rhythm-only rule as `StatTile`).
- `status-badge.tsx` (new) — `StatusBadge`, a semantic wrapper over `Badge` carrying the
  admin-system's 11-state content lifecycle vocabulary (`draft`/`active`/`inactive`/`scheduled`/
  `testing`/`review`/`published`/`deprecated`/`archived`/`error`/`pending`, from
  `_outputs/admin-system/admin-primitives.jsx`). Deliberately a new enum rather than folding into
  `WorkflowStatus` (component-architecture-standard §4b central-extension rule) — the two
  vocabularies model different domains (entity publication lifecycle vs. workflow step run
  state); documented in the file. Accepts an explicit `tone` override for exactly this
  cross-domain composition case.
- `Card`'s `density` prop doc-comment now points to the new dashboard density system for
  dashboard tiles/sections specifically (still a no-op on `Card` itself — least-invasive of the
  two options per the Wave 1.F brief, since `Card` sets no padding and ~19 `*-card.tsx` consumers
  are W1.B territory).

### Changed
- `packages/stack/app-scaffolds/features/widget-grid/components/metric-widget.tsx` — now renders
  its value/caption via `StatTile` (`bare hideLabel`) instead of hand-rolled divs, since
  `WidgetCard` already renders the widget's title as its own heading. Accepted delta: the caption
  drops its former mono/uppercase/tracked-letter-spacing treatment for `StatTile`'s standard
  `subLabel` style. Test ids and content unchanged.
- `packages/stack/app-scaffolds/features/kpi-scorecard/components/kpi-tile.tsx` — already a
  direct `StatTile` consumer; unchanged (satisfies the Wave 1.F migration by construction).
- `packages/stack/app-scaffolds/features/executive-dashboard/components/kpi-card.tsx` — NOT
  migrated onto `StatTile`. Documented as an accepted divergence in-file: it's a verbatim
  pixel-for-pixel port of the design reference's own `.kpi`/`dashboard.css` classes
  (`docs/09-plans/design-ingestion-resolution-2026-07-17/dashboard-verbatim-port-contract.md`),
  whose acceptance criterion is exact visual match to the reference screenshot; rebuilding it on
  `Card`'s border/radius/shadow/spacing would break that match.
- `packages/stack/app-scaffolds/features/executive-dashboard/index.tsx` — replaced the
  decorative `<div className="dash" data-density="executive">` with
  `<DashboardDensityProvider density="executive" className="dash">` (identical DOM output; real
  provider instead of a hardcoded string).
- `packages/stack/app-scaffolds/features/approval-surface/components/step-status-badge.tsx` and
  `packages/stack/app-scaffolds/features/case-workspace/components/workflow-status-badge.tsx` —
  now compose `StatusBadge` (via its `tone` override) instead of `Badge` directly. Public APIs
  (`status: WorkflowStatus`) unchanged.

Design-system de-dup Wave 1.G (`docs/plans/design-system-dedup-2026-07-25/strategy.md` §5 W1.G,
annexes F1/F2, `auth-policy` territory):

- **Password-policy consolidation.** The 4-rule password policy (`PASSWORD_POLICY`,
  `passwordScore`, `passwordPolicyItems`) — previously an identical implementation duplicated in
  `app-scaffolds/features/accept-card/lib/password-policy.ts` and
  `app-scaffolds/features/reset-request-form/lib/password-policy.ts` — now lives in one place,
  `packages/shared/ui/src/lib/password-policy.ts`, exported from the `@dbp/ui` barrel. Both
  organisms' `lib/password-policy.ts` files are deleted; their `index.tsx` now imports
  `passwordScore`/`passwordPolicyItems` from `@dbp/ui` alongside the other atoms they already
  consumed from there. Verified against the oracle declaration (`identity-core.jsx` `PW_POLICY`,
  design-run-pack-2026-07-12 identity-onboarding-system) — the 4 rules (≥12 chars, upper+lower
  case, a number, a symbol) are an exact match, no divergence to reconcile. `PolicyList` (the
  presentational `{label, met}[]` renderer) is unchanged — it never owned the rule logic. Public
  API of both organisms unchanged.
- **`Assignee` variant completion.** `AssigneeCard`'s `AssigneeKind` extended from 3 variants
  (`individual`/`team`/`unassigned`) to the oracle's full 6 (`wf-status.jsx`'s `Assignee`,
  workflow-system): added `queue` (rounded-square inbox icon), `delegation` (same avatar+text
  lockup as `individual`, distinguished by the `subtitle` convention "Delegated by X · until Y"),
  and `multiple` (new `coOwners` prop rendered via the existing `AvatarStack` primitive, capped at
  3 shown + overflow chip, with no name row — matches the oracle's avatar-cluster-only layout).
  Stories and tests added for all 3 new variants. Public API additive only (`coOwners` is new and
  optional); existing 3 variants unchanged.
- **Chart-primitive consolidation (Wave 1.F part 2).** `packages/shared/ui/src/components/
  {gauge,funnel,heatmap,sparkline,bullet-chart}.tsx` — the 5 recharts-lacking, hand-rolled chart
  types — were already single-sourced (`@dbp/ui`) with no true duplication; `chart-panel`'s
  `heatmap-chart-panel.tsx`/`funnel-chart-panel.tsx` were already thin wrappers over `@dbp/ui`'s
  `Heatmap`/`Funnel` (composition, not duplication) — kept as-is, no change needed there. The real
  duplication (annex E rows 46/47/48, inventory item 2) was the recharts-based bar/line/pie charts,
  independently reimplemented in `app-scaffolds/features/chart-panel` and `.../widget-grid`. New
  canonical presentational atoms `chart-panel/components/{bar,line,pie}-chart.tsx` (pure, prop-driven
  recharts wrappers — kept inside `@dbp/organisms`' `chart-panel` rather than `@dbp/ui`, since
  `@dbp/ui` deliberately excludes recharts for bundle weight per the 2026-07-16 chart-library ruling
  — see `sparkline.tsx`'s doc comment). `chart-panel`'s `bar-chart-panel.tsx`/`line-chart-panel.tsx`/
  `pie-chart-panel.tsx` and `widget-grid`'s `bar-widget.tsx`/`line-widget.tsx`/`pie-widget.tsx` are
  now thin wrappers around the shared atoms; both organisms' public APIs (props, config schemas)
  unchanged. `chart-colors.ts` (11-entry-palette-adjacent, forked ×2 per annex B §6 and deferred
  backlog D17) is unified onto one canonical file at `chart-panel/components/chart-colors.ts`;
  `widget-grid/components/chart-colors.ts` now re-exports it. The two forks had drifted (different
  navy-ramp step, different opacity steps) — kept `widget-grid`'s navy-400 ramp as canonical (a
  deliberate prior readability fix noted in its own comment; navy-200 was too light). D17's
  "flat-fill bar bug" claim was investigated and found NOT to be a real bug relative to `chart-panel`
  — both organisms colour bars per-series (not per-category), and `widget-grid`'s bar widgets only
  ever have one series, so `palette[0]` was already correct/equivalent to `chart-panel`'s own
  single-series case; see `deferred-backlog.md` D17 for the full note. Minor intentional visual
  deltas from unification, flagged rather than hidden: `widget-grid`'s bar/line widgets now get
  `chart-panel`'s richer category-tick handling (label truncation + -20° rotation) instead of flat
  unrotated ticks, and its pie legend can optionally show the "Label NN% (count)" format `chart-panel`
  uses (`pie-widget.tsx` opts out via the new `legendFormat="plain"` prop to preserve its prior plain
  look).

## 0.15.0 — 2026-07-26 (design-system de-dup Wave 1)
### Changed
Design-system de-dup Wave 1.A (`docs/plans/design-system-dedup-2026-07-25/strategy.md` §3/§5,
badge family, rulings DS-R2/R3) — Badge is now the single chip/pill styling source:
- `CtrlBadge` — re-implemented as a `Badge` composition, removing its bespoke `cva` and all 6
  inline literal `hsl(N N% N%)` triples (the ratchet-tracked count for `@dbp/ui` in
  `scripts/check-ui-dedup-ratchet.mjs` drops from 6 to 2, the remaining 2 living in
  `ai-confidence.tsx`, outside this change's scope). The 4 control levels map onto existing Badge
  tones: `neutral` (Inform), `ai` (Recommend — exact former hue via the shared `--ai-*` vars),
  `warning` (Prepare — closest existing amber to the former bespoke one), `testing` (Automate —
  closest existing purple to the former bespoke violet). The "Human decision only" qualifier now
  renders as a `Badge tone="danger"`. Accepted visual delta: the qualifier and levels 1/3/4 pick up
  Badge's pill radius and size scale instead of their former bespoke rounded-rect/height values.
  Public API (`level`, `showNum`, `humanDecisionOnly`, `children`) unchanged; `ctrlBadgeVariants`
  export removed (no longer a `cva`), `CTRL_TONE` added.
- `CiteRef` — now built on Badge's shared shell mechanics (new `badgeShellClass` export from
  `badge.tsx`) with Badge's `ai`-tone colour tokens, rather than a hand-rolled class string. Stays
  a `<button>` (not a `<Badge>` composition) since it must itself be the focusable element. API
  unchanged.
- `StatusDot` — the `pill` variant now renders through `badgeVariants()` tone classes instead of
  inline `style={{borderColor, color}}`. The 5 status→colour mappings are declared as Badge tones
  (`success`/`warning`/`danger`/`gray`/`info`) instead of a private colour map. `StatusToken`'s
  shape changed from `{ color, label, icon }` to `{ tone, textVar, label, icon }` (no external
  consumers referenced `.color`, verified). API (`status`, `children`, `pill`) unchanged.
- `GovState` — its private `TONE_CLASS`/`TONE_ICON_CLASS` "default" entries now reference the same
  `--color-border-default`/`--color-text-muted` tokens Badge's `neutral`/`gray` tones use, instead
  of the parallel `--border`/`--muted-foreground` token family. `warn`/`review`/`error` already
  matched Badge's `warning`/`ai`/`danger` tone triads and are unchanged. API unchanged.
- `ProvTag` — folds its outer shell onto Badge's new shared `badgeShellClass`, removing the
  duplicated inline-flex/border/font-semibold/select-none/whitespace-nowrap declarations. Colours
  stay on the distinct `--prov-*` token family (a real 6-way taxonomy, not a Badge-tone duplicate —
  documented in the file). API unchanged.
- `EnvPill` — now consumes the same `badgeShellClass` export instead of re-declaring Badge's shell
  classes. Stays a separate component (documented rationale in the file, unchanged from
  2026-07-17). API unchanged.
- `OrgBadge` renamed to `OrgIdentityRow` ("badge" collided with the chip-family `Badge` naming;
  this is an identity row, not a chip) and now composes `Card` for its outer shell, fixing its
  `bg-[var(--color-surface)]` grey fill to Card's default white `--color-surface-content`
  (component-surface-default-white rule). `OrgBadge`/`OrgBadgeProps` remain as `@deprecated`
  re-exports for the 2 existing import sites (`accept-card`, `sso-pick`).

Design-system de-dup Wave 1.C (`docs/plans/design-system-dedup-2026-07-25/strategy.md` §3/§5,
family `states-banners`):
- `ConflictBanner` — re-implemented its warning-strip header as an `Alert tone="warning"` wrapper
  (icon + copy + `role="alert"` now come from `Alert`), removing ~15 lines of hand-rolled
  `role="alert"` shell CSS. Field-diff table and 3-button resolution footer unchanged. Public API
  unchanged.
- `AnnouncementBanner` — evaluated against `Alert`; not migrated. `Alert`'s single title/body/
  dismiss slot cannot host the pill-badge-next-to-title, two-button CTA row, or brand-gradient
  fill this component needs, and it remains unmounted anywhere in the app (documented in its own
  file). Kept as the hand-rolled layout; every color already routed through `--color-primary`/
  `white` tokens, so no token-hygiene delta existed to fix.
- `AssistTrigger` — "ready"-state hand-rolled `<button>` now renders through `Button
  variant="ghost" size="sm"` with the existing AI-tone (`hsl(var(--ai-*))`) styling layered on via
  `className`. Loading/unavailable branches unchanged. Public API unchanged.
- `ErrorState` → `EmptyState tone="danger"` consumer swap completed at all 12 `packages/stack/
  app-scaffolds/features/**` import sites that reference `ErrorState` from `@dbp/ui` (prop mapping:
  `title` → `headline`, `error`/`description` → `description`). `error-state.tsx` itself is
  unchanged — the deprecated wrapper stays until a later major per its own doc-comment.
  `marketplace-item-detail/index.tsx`'s single `ErrorState` site was intentionally left as-is —
  that feature is PR #66's active territory (strategy.md §5 Wave 2 note) — and is not counted
  above.

Design-system de-dup Wave 1.B (`docs/plans/design-system-dedup-2026-07-25/strategy.md` §3/§5,
card/surface family, ruling DS-R1) — `Card` is now the single outer-shell primitive for the
`*-card.tsx` family; internal layout stays bespoke, public APIs unchanged:
- `DependencyCard`, `AssigneeCard` — outer shell now composes `Card` instead of a hand-rolled
  `rounded-[var(--radius-card)] border ... bg-white` div, fixing the literal `bg-white` to Card's
  token-backed `bg-surface-content` (same rendered colour, single source of truth).
- `ErrorCard` — re-implemented as a thin wrapper over `Alert tone="danger"` (structurally identical
  per inventory-a §2); marked `@deprecated`, pointing callers at `Alert` directly. Public API
  (`message`, `onRetry`) unchanged.
- `HealthStatusCard` — swapped its `dq-card` utility-class shell (`base.css`) for `Card` +
  `p-[var(--space-card)]` (byte-identical computed styles: same radius/border/background/shadow
  tokens, same 24px padding).
- `CriticalCard` — outer shell now composes `Card` (border-color override for the critical tone
  stays via `className`). Its two hand-typed `text-[10.5px] font-*/uppercase/tracking-wide` eyebrow
  spans (inventory-b §1, items 13/14) now render through `SectionLabel`, with `className` overrides
  keeping the exact original computed size/weight/color — no visual delta.
- `CatalogCard` — both `catalog` and `media` shell variants now compose `Card` (the `catalog`
  variant's literal `bg-white` and the `media` variant's `bg-surface-content` both resolve to
  Card's default, so no colour delta). Its `typeLabel` and `metaLine` mono eyebrow chips
  (inventory-b §1, items 18/19) now render through `SectionLabel` with `className` overrides
  preserving the original mono font/size/weight/colour exactly.
- `StatTile` — outer shell now composes `Card`; its progress-track fill swapped from the raw
  Tailwind `bg-gray-100` to the token-backed `bg-[var(--color-border-subtle)]` (closest existing
  neutral-track token, same rendered colour family).
- `InfoCard` (base for `ExceptionCard`/`EscalationCard`) — outer shell now composes `Card`
  (`shadow-none` override, since the original had no shadow) instead of a hand-rolled
  `rounded-[var(--radius-card)] border` div; the per-tone `border-color` stays dynamic via inline
  `style` (unchanged). Accepted visual delta: the body area, previously transparent over the page
  background, is now Card's opaque `bg-surface-content` white — consistent with the
  component-surface-default-white rule the rest of this family now follows.
- `WorkspaceGreetingCard` — outer shell now composes `Card`, with `rounded-2xl`/custom multi-value
  hero shadow/`--color-surface` grey background kept via `className`/`style` overrides (deliberate
  hero-panel look, documented in-file — not the standard Card recipe). Its two eyebrow labels
  ("Welcome back", updates-title) now render through `SectionLabel`.
- `RootCauseCard` — already composed `AiSurface` correctly (left as-is); its one hand-typed
  "Hypothesis N" eyebrow span now renders through `SectionLabel`.
- `AnomalyCard`, `AnomalyInsightCard`, `ForecastCard`, `DataQualityCard`, `SummaryCard`,
  `ExceptionCard`, `EscalationCard` — verified as already composing `AiSurface`/`AiActionCard`/
  `InfoCard` correctly; no shell changes needed.
- `BoardCard` — evaluated against `Card`; not migrated. It renders either a `<button>` (interactive)
  or a `<div>` (static) depending on `onClick`, which `Card`'s single `<div>` element cannot express
  without losing native button semantics; its `bg-[var(--color-surface)]` grey fill matches the
  sibling `kanban-card.tsx`'s deliberate grey-on-raised-column convention, so kept as-is.

Design-system de-dup Wave 1.D (`docs/plans/design-system-dedup-2026-07-25/strategy.md` §3/§5,
labels row, ruling DS-R2) — sweep of the remaining hand-rolled eyebrow and form-`<label>` recipes
outside the badge/card/state families already covered above:
- Eyebrow/section-label recipes swapped onto `SectionLabel`: `admin-settings-form.tsx` (section
  heading), `ai-alert.tsx` ("Evidence"), `ai-exec-summary.tsx` ("Forecast"), `ai-surface.tsx`
  (`AiSurfaceFacet` label — dynamic `tone` colour now passed through `style`), `app-footer.tsx` (env
  pill — typography now `SectionLabel tone="secondary"`, pill shell kept via `className`),
  `landing-sections.tsx` ("Step N"), `persona-switcher.tsx` ("View as persona" menu heading).
  `select.tsx`'s Radix-forwarded `SelectLabel` can't render a `SectionLabel` directly (it must stay
  a `SelectPrimitive.Label`), so it now composes the shared `sectionLabelVariants()` recipe function
  instead of hand-typing the same classes. `read-only-value.tsx`'s badge-internal `text-[10px]`
  suffix is below `SectionLabel`'s smallest step and stays as-is (commented as deliberate).
  `public-contact-form.tsx`'s field-label has a right-aligned "Optional" badge (`justify-between`)
  that `FieldLabel`'s inline suffix layout can't express — kept as-is (commented as deliberate).
  Ratchet counter (`scripts/check-ui-dedup-ratchet.mjs`): 80 → 65.
- Form-`<label>` recipes swapped onto `FieldLabel`: `login-credentials-form.tsx` (Email/Password —
  typography classes overridden via `className` to preserve the existing sentence-case look),
  `ai-field-frame.tsx` (label row — overridden to stay inline instead of `FieldLabel`'s block
  default). Other `<label>` sites surveyed (`radio-group.tsx`, `alert-dialog.tsx`,
  `save-search-modal.tsx`, `file-dropzone.tsx`, checkbox/consent labels in `public-contact-form.tsx`)
  are composite or non-field-value labels, not the plain recipe — left as-is.
- Raw gray-family classes (`border-gray-200`/`bg-gray-50`/`text-gray-400`/`text-gray-700`/
  `text-gray-600`) swapped for the matching `--color-border-subtle`/`--color-surface`/
  `--color-text-disabled`/`--color-text-secondary` tokens in `detail-rail.tsx`, `legal-page-layout.tsx`,
  `public-page-header.tsx`, `public-contact-form.tsx`, `section-heading.tsx` (doc-comment prose only
  — no gray classes in the actual markup). `detail-rail.test.tsx`'s three assertions on the literal
  gray class strings updated to match. Ratchet counter: 84 → 67.
- No public API changes beyond the incidental `SelectLabel`/`AiFieldFrame`/`FieldLabel`-consuming
  sites above; all are internal recipe swaps.

## [0.14.0] - 2026-07-25
### Added
Design-system de-dup Wave 0.1 (`docs/plans/design-system-dedup-2026-07-25/strategy.md`, rulings
DS-R1/R2/R3) — 4 new canonical primitives, minting-only (no consumer migration in this change):
- `SectionLabel` — the one canonical eyebrow/section-label recipe (`text-xs uppercase tracking-wide
  font-semibold` + `size`/`tone` variants), consolidating the ~108-site, ~30-variant label sprawl
  documented in inventory-b §1.
- `FieldLabel` — extracted from `input.tsx` into its own file as the canonical form-`<label>`
  primitive, with new `required`/`optional`/`disabled`/`error` props aligned to the oracle
  form-system's declared field states. `input.tsx` re-exports it for backward compatibility
  (7 existing import sites unaffected).
- `FieldValue` — the shared field-value renderer, extracted from the byte-identical triplicate in
  `case-workspace`, `entity-detail`, and `workbench-surface` (inventory-c §2). Reuses this
  package's existing `formatNumber`/`formatDate` (`lib/format.ts`) instead of re-implementing them
  a fourth time.
- `EmptyState` gained a `tone?: "neutral" | "danger"` prop, absorbing `ErrorState`'s danger
  icon/text tokens and `role="alert"` behavior. `ErrorState` is now a thin `@deprecated` wrapper
  over `EmptyState tone="danger"` — both APIs remain fully backward-compatible (17+10 existing
  import sites).
## [0.13.0] - 2026-07-23
### Added
~24 new flat components for Wave 3 Family 3/4 (Workflow risk cards + forms/kanban/notification/
overlay/search/collaboration/identity remainder): `ActionFooter`, `SaveStatus`,
`ValidationSummary`, `InlineEditable`, `NotifPopover`, `AiAlert`, `ParallelTracker`,
`ConditionalTracker`, `CommitteeDecision`, `EvidencePanel`, `SearchResultRow`, `FindInRecord`,
`SaveSearchModal`, `SlowSearch`, `AlertConfig`, `AnnouncementBanner`, `SaveStateIndicator`,
`SidePanelExtension`, `StatusPickerPopover`, `ChecklistFilterMenu`, `FilterPillPopover`,
`PwField`, `StrengthMeter`, `PolicyList`, `CodeInput`, `OrgBadge`, `CenteredNotice`, `AuthLayout`.
Extended existing components rather than duplicating: `Sheet` (drag-to-resize, mobile
swipe-to-dismiss — radius tokens untouched), `AlertDialog` (6th `UnsavedChangesConfirmDialog`
risk tier), `Avatar` (presence-dot + new `AvatarStack`), `LifecycleBar`/`VerticalStageTracker`
(milestone variant instead of a new tracker component). New `useUnsavedGuard` hook extracted
from `record-form`'s single (not duplicated, correcting an earlier plan assumption) inline
implementation.

### Fixed
- `Tooltip` — radius token was a hardcoded `rounded-[8px]`, now `rounded-[var(--radius-card)]`
  matching every other floating-panel component; added a Radix `Arrow` (none existed anywhere in
  this codebase before); added an `Open state` story via Radix's `defaultOpen` so the Docs page
  actually demonstrates the triggered state (root cause of Sharavi's "looks ugly and not
  functional" — the static story never showed it open).
- `DropdownMenuContent` — now defaults `align="start"` (was falling through to Radix's
  `align="center"` default, causing the trigger/panel left-edge misalignment Sharavi flagged).
- `AiAlert` — `FeedbackControl`'s `onChange` was calling `onFeedback(rating, undefined)` instead
  of `onFeedback(rating)` when no reason was given; now omits the second arg entirely.

## [0.12.3] - 2026-07-22
### Fixed
- `ChangeImpactPanel`'s `ImpactItem` type now explicitly allows `| undefined`
  on its optional fields (`icon`/`to`/`conflict`), matching this project's
  `exactOptionalPropertyTypes` setting. Same class of fix as `0.12.2`,
  surfaced by `@dbp/organism-publish-review` passing Zod-parsed impact data
  straight through.

## [0.12.2] - 2026-07-22
### Fixed
- `DependencyView`'s `DependencyNode` and `VersionHistory`'s `VersionRecord`
  types now explicitly allow `| undefined` on their optional fields
  (`sub`/`to`/`current`), matching this project's `exactOptionalPropertyTypes`
  setting — a Zod-inferred optional field (`T | undefined`) couldn't be
  assigned to the old plain-optional (`T`) declaration. Surfaced by
  `@dbp/organism-config-detail` passing Zod-parsed dependency/version data
  straight through.

## [0.12.1] - 2026-07-22
### Added
- `SuggestedAction` gains an optional `confidence` prop (swaps in for the
  risk badge) so it also covers the Config-governance admin-system
  reference's `AISuggestionCard` — no new component needed, a reuse win the
  original Family 2 tier audit didn't know about since `SuggestedAction`
  already existed on this branch. See `WithConfidence` story.

## [0.12.0] - 2026-07-22
### Added
- Wave 3 Family 2 (Config-governance) molecules, lifted from the accepted
  admin-system design reference: `ChangeImpactPanel`, `DependencyView`,
  `VersionCompare`, `VersionHistory` (from `admin-panels.jsx`), the shared
  `MappingRowList` (merges the near-duplicate `MappingTablePreview`/
  `RelationshipEditor` reference patterns into one prop-driven component),
  and `PersonaSwitcher` (from `admin-shell.jsx` — backend-agnostic pending
  an open architecture ruling, see the component's own docs and
  `admin-system-ingestion-ledger-2026-07-13.md` §D).
- `EmptyState`'s `Restricted` story variant, demonstrating a reuse win:
  no new component was needed for the reference's `RestrictedState`.

## [0.11.0] - 2026-07-21
### Removed
- `ActivityFeed`, `AssistantPanel`, `TenantSwitcher` (from `bindings/`) and
  `AdminAccessMatrix`, `AdminRoleList`, `AdminUserList`,
  `NotificationPreferenceMatrix` (from `components/`) — promoted to
  `@dbp/organisms` (APP.F14/F16/F17/F18/F30/F31/F32). Each owned real
  fetch/mutation state against a Platform Service, so they were mis-filed as
  presentation-layer primitives (Bindings/Admin resolution,
  `wave3-build-plan.md`). Consumers now import from
  `@dbp/organisms/<kebab-name>`. `PermissionGate` and `AdminSettingsForm`
  were reviewed under the same pass and confirmed to stay — both are
  genuinely stateless.
- `NotificationBell` and `SearchBar` were reviewed under the same pass and
  also own real fetch state, but were NOT removed — `AppChrome` (this
  package) renders them by default via `AppChromeCapabilities`, and moving
  them to `@dbp/organisms` would invert the Layer 06/07 dependency
  direction. Left in place pending a follow-up architectural decision.

## [0.10.4] - 2026-07-18
### Fixed
- DQ-Shell defect-inventory pass (`docs/03-features/audits/dq-defect-inventory-2026-07-18.md`):
  - `AppTopBar`/`Breadcrumb` (DR-4) — breadcrumb trail now shrinks and truncates instead of
    forcing the top bar to overflow at narrow widths; right-side controls always keep their
    space via `shrink-0`.
  - `AdminUserList` (DR-5/DR-1) — table now uses the entity-list white-card treatment
    (surface + `shadow-sm`, uppercase-mono headers) instead of blending into the canvas.
  - `Button` `variant="orange"` (craft checklist §7) — primary CTA now renders in the single
    established primary token (`--color-primary`) instead of the accent orange; the variant
    name is kept for source compatibility, no new color introduced.
  - `Badge` (craft checklist §6) — icon children (e.g. a status checkmark) are now sized and
    spaced as a normal flex sibling of the label, never overlapping it.
  - `LandingHero` — trust-bullet row now wraps instead of overflowing at narrow widths.

## [0.10.3] - 2026-07-18
### Changed
- `BoardCard` — `#tag` chips (DR-7 kanban reference-fidelity pass, see
  `@dbp/organisms/kanban`'s CHANGELOG): swapped the filled
  `bg-[var(--color-neutral-surface)]` pill for a subtle outlined chip
  (`border-[var(--color-border-default)]`, `text-[var(--color-text-muted)]`),
  matching the Claude Design kanban reference's quieter tag treatment.
  CSS-only — no prop/DOM-structure change.

## [0.10.2] - 2026-07-18
### Fixed
- `RichTextField` — fixed the value-sync `useEffect` stomping the editor's
  live content with a stale `value` prop while the user was actively
  typing, which dropped/reordered characters (e.g. "Hello world" landing
  as "Hlowrd") and could duplicate an empty paragraph. The effect now skips
  resyncing when the change is an echo of the editor's own `onUpdate`
  (tracked via a ref set synchronously inside `onUpdate`), and only applies
  genuinely external value changes (initial load, programmatic reset).

## [0.10.1] - 2026-07-18
Foundation primitive polish — craft-discipline pass (states, tokens,
interaction coherence). No API changes; see
`docs/03-features/specs/design-quality-checklist.md` for the standard this
enforces going forward.
### Changed
- `Input`/`Textarea` (`defaultFieldStateClasses`) — added a `hover:border`
  affordance (matching `Select`'s pattern) so all field controls give the
  same pre-focus feedback.
- `Checkbox`/`Switch` — added `disabled:pointer-events-none` so a disabled
  control's hover styling can no longer leak through (it previously changed
  border/fill color under a mouse hover even while disabled).
- `Switch` — added on/off hover feedback (`color-mix` darken), matching
  `Button`'s hover treatment; previously had no hover state at all.
- `RadioGroup` — added a hover affordance to the "list" variant's mark
  (matching `Checkbox`'s `hover:border-primary`) and fixed the "card"
  variant so hover no longer applies to disabled options.
- `Sheet`'s close button, overlay scrim, `SheetTitle`, and
  `SheetDescription` now match `Dialog`'s exact treatment (radius/hover/
  focus-ring tokens, scrim color, heading style) — previously a visibly
  different, less-refined pattern (raw `rounded-sm`, plain `black/50`
  scrim, and two references to an undefined `--color-text` token that
  silently fell back to browser default color).
- `Popover` content now matches `Select`/`Dialog`'s overlay treatment
  (`--radius-card`, `--color-border-default`, `bg-white`,
  `--shadow-lg`) instead of a plain `rounded`/`shadow-md`/gray-surface
  card, which also violated the surface rule (content = white, gray is
  chrome-only).
- `DropdownMenu` content, items, checkbox/radio items, label, separator,
  and shortcut — same overlay-surface + hover-token alignment as `Popover`
  (was the least-refined overlay: `rounded-sm` items, an undefined
  `--color-text` token, and a `color-mix(--color-border)` hover fill that
  didn't match any other menu/list surface's `--color-navy-50` hover).
### Fixed
- `DropdownMenu`/`Popover` stories used raw `text-red-600` (destructive
  items) or an undefined `--color-text` token — swapped for the
  `--color-danger`/`--color-text-primary` tokens to match every other
  affordance in the system; added a disabled-item story for `DropdownMenu`.

## [0.10.0] - 2026-07-18
Workflow-system design-audit gap resolution (W6a,
`docs/03-features/audits/design-audit-2026-07-17-admin-workflow.md`).
### Added
- `AssigneeCard` (WFL-08) — individual/team/unassigned assignee display with
  a workload hint and a reassign/assign action.
- `EscalationCard` (WFL-10) — SLA-triggered vs manually-raised escalation
  surface with an optional resolve action.
- `DependencyCard` (WFL-11) — blocking/blocked-by related-record link with
  an optional status badge and navigate action.
- `ExceptionCard` (WFL-12) — policy vs system exception surface with an
  optional resolve action; complements the generic `ErrorCard`.
- `TaskChecklist` (WFL-26, ruling R4) — compact/full checklist of per-task
  status for mounting inside a record/case. Presentational mount only, not
  the broader task-management entity (gated separately on TQ-01).

## [0.9.0] - 2026-07-18
- `NotificationPreferenceMatrix` (NOT-22) — type×channel opt-in/out matrix,
  self-fetching binding (mirrors `AdminAccessMatrix`'s pattern) over the new
  `usePreferences()` hook. Mandatory-tier rows render a locked, always-on
  switch, mirroring `resolveShouldSend`/`MandatoryTierOptOutError`'s
  server-side enforcement.

## [0.8.0] - 2026-07-18
Notification-system + overlay-system design-audit gap resolution (W5a,
`docs/03-features/audits/design-audit-2026-07-17-notification-overlay.md`).
### Added
- `SevChip`, `PriorityPill`, `TypeTag` (NOT-24) — typed Badge wrappers driven
  by `@dbp/contracts`' `NotificationSeverity`/`Priority`/`TypeSchema`; the
  taxonomy file named these as its consumers but they never existed.
- `CriticalCard` (NOT-14) — highest-severity notification surface: solid
  critical header, impact/detected/owner/required-response grid, 4-step
  status lifecycle, open-incident/acknowledge/mark-false-positive actions.
  Ack/false-positive persistence deferred to W5b (no PS.NOTIF verb yet).
- `EscalationTimeline` (NOT-19) — stepped reminder-escalation progression,
  presentational (props-driven, same contract as `ActivityTimeline`).
- Risk-tier `alert-dialog.tsx` variants (OVL-05): `DestructiveConfirmDialog`,
  `HighImpactConfirmDialog` (required-reason `Select`), `BulkConfirmDialog`
  (count + affected preview), `ProductionConfirmDialog` (typed-phrase
  arm-to-confirm + ack checkbox).
- `sheet.tsx` drag-to-resize handle (OVL-07) — optional `resizable` prop on
  `SheetContent` for `side="left"|"right"`, pointer-drag + arrow-key resize
  clamped to `minWidth`/`maxWidth`, `onResizeEnd` callback.
### Changed
- `bindings/NotificationBell.tsx` (NOT-07) — dropdown is now a tabbed
  All/Unread/Action-required popover (was a flat 8-item list), dense items,
  unchanged "View all" footer.
## [0.7.0] - 2026-07-12
Activity timeline + composer molecules (`activity-timeline-spec-2026-07-10.md` §7 — EXTEND
verdict, no new `@dbp/organism-*` package). Presentational, no fetch calls; the host organism
(lve-workspace's `useActivityFeed`, record-drawer's record context) owns data fetching.
### Added
- `ActivityTimeline` — typed, connector-lined activity feed: per-type icon chip (design-token
  tone, never hex), unknown-type neutral fallback with visible label, actor `Avatar` + locale-aware
  relative timestamp, tag chips (`Badge`), attachment chips (read-only, `onDownloadAttachment`
  callback), config-gated tag filter row. Four states (loading/empty/error/populated) built on the
  existing `LoadingSkeleton`/`EmptyState`/`ErrorState` primitives rather than bespoke markup.
  Single-item connector-line edge case covered (no trailing connector after the last entry).
- `ActivityComposer` — note entry surface, disabled-until-dirty Save. Per **ADR-0048** (Tiptap
  convergence on `@dbp/doc-editor`), ships the interim plain `<Textarea>` fallback — no Tiptap
  dependency in this package. `@mention` is plain-text-parsed (regex against the textarea value,
  no inline node) with a candidate picker (config-gated `mentions`); `#tag` entry is a simple chip
  input (config-gated `tags`). No bold/italic/list toolbar — a plain textarea can't support them,
  and DoD §4.2 forbids dead formatting buttons. Attachments ship as a **stub**: a disabled attach
  affordance (config-gated `attachments`) plus an `onAttachFiles` prop seam reserved for
  `@dbp/ps-storage` (spec §6.4) — not built in this lane.
- `src/schemas/activity.ts` — Zod schemas for the event model (`ActivityEntry`,
  `ActivityTimelineConfig`, `ActivityTypeConfig`, `ActivityAttachment`, `ActivityMentionUser`,
  `ActivityDraft`); component prop types derive via `z.infer`, per the house "Zod is the source of
  truth" rule.
- Both molecules exported from the package root; stories under
  `Design System/Capabilities/ActivityTimeline` and `.../ActivityComposer` (loading/empty/error/
  populated states, single-item and unmapped-type fixtures, mentions+tags+attachments-stub and
  minimal-config composer variants).

## [0.6.0] - 2026-07-13
Shortcut manager capability, P3 lane (`capability-keyboard-shortcuts-spec-2026-07-10.md`
Deliverable A).
### Added
- `ShortcutProvider`/`useShortcuts` — the scoped shortcut manager: one provider per shell owns
  the single `window` keydown listener, the registry, and the input-focus guard
  (INPUT/TEXTAREA/SELECT/contentEditable — modifier ("mod") combos still fire from inputs, bare
  keys and shift-only combos never do, matching the accepted reference's split exactly).
  `useShortcuts(bindings, { scope, enabled })` registers `{ keys, handler, description, group }`
  for as long as the calling component is mounted. Scopes (`global < page < surface`) resolve
  combo conflicts across scopes by precedence; a duplicate binding in the *same* scope is a
  dev-mode `console.error` (loud, not last-wins), matching the registryId-guard precedent.
  Handlers receive no DOM event details beyond the manager's own `preventDefault` — navigation
  models (j/k focus walking) stay in the consuming organism.
- `ShortcutHelp` — the `?`-bound self-documenting registry overlay: grouped, searchable,
  platform-aware kbd rendering (Cmd on Mac, Ctrl elsewhere). Built on `Dialog` (ADR-0044) rather
  than the reference's hand-rolled focus-trap/Tab-cycling code — focus trap, Escape-to-close,
  portal, scroll lock, and focus-restore are all inherited from Radix. `ShortcutProvider` renders
  one instance internally (built-in `?` binding, disable via `disableHelp`), feeding it from the
  live registry; `ShortcutHelp` itself stays presentational (props in, no registry access) for
  isolated story/test coverage. Loading/Empty/No-results/Populated states.
- Note: this is a distinct mechanism from the pre-existing `useKeyboardShortcuts` hook (used by
  `AppFooter`'s shortcut display/sequence-navigation) — that hook is one of the "ad-hoc
  `window.addEventListener` per surface" patterns this capability is meant to eventually replace,
  but migrating it is out of scope for this lane (not touched; flagged for a follow-up).

## [0.5.0] - 2026-07-13
Popover primitive, P3 lane (`capability-keyboard-shortcuts-spec-2026-07-10.md`).
### Added
- `Popover`/`PopoverTrigger`/`PopoverAnchor`/`PopoverContent`/`PopoverClose` —
  new primitive wrapping `@radix-ui/react-popover`, matching `dialog.tsx`/
  `dropdown-menu.tsx` conventions (`forwardRef`, `cn`, portal, DBP token
  surface/border/shadow, `data-[state]`/`data-[side]` animate-in/out). Per
  ADR-0044 (shadcn pattern locked), anchored dismissible-content behaviour
  rides Radix rather than a hand-rolled positioning/dismiss layer. Unblocks
  the AI-system promotions and `SearchSelect` combobox work, both of which
  need anchored overlay content.

## [0.4.1] - 2026-07-12
### Fixed
- `RadioGroupOption`/`RadioGroupProps` — widened `description`/`disabled`/
  `value`/`onValueChange`/`variant` to explicitly include `undefined` so
  callers under `exactOptionalPropertyTypes: true` (e.g. form-builder's
  `FieldRenderer`, wiring `radio-cards` fields into this primitive) can pass
  possibly-`undefined` values without a type error. No behavior change.

## [0.4.0] - 2026-07-12
Universal field layer, increment 1 — primitive promotions batch 2.
### Added
- `RadioGroup` — new primitive (`list`/`card` variants), native
  `<input type="radio">` + custom mark (no Radix radio-group dependency
  installed in this workspace; matches the ingested Form System reference's
  `.choice-radio`/`.choice-card` geometry, `forms.css`, mapped to DBP tokens:
  17px ring-plus-dot mark, navy "on" state, `--radius-card` card border).
  Per-option `description`/`disabled`. Promoted per record-form spec §3 —
  today `radio-cards` fields silently fall back to a plain `Select`, losing
  the card-with-description visual; this primitive is the fix (wiring into
  `form-builder` lands in a follow-on commit).
- `ReadOnlyValue` — new primitive, the field-primitive layer's READ-mode
  counterpart to `FormField` (Sharavi ruling 2026-07-12: field components are
  the rendering layer everywhere a field is displayed, editable or read-only
  — LVE, entity-detail rails, admin forms). Matches the reference's
  `.ro-value`/`.ro-empty` "Not set" pattern; folds the reference's
  `SystemValue` variant into an optional `badge` prop rather than shipping a
  second component.
- `FormField` — `state?: "default" | "error" | "warning" | "success"` prop.
  The seam is wired (`data-field-state` on the wrapper; `error` always wins
  and resolves to `"error"`) but only `"error"` carries a visual treatment —
  `"warning"`/`"success"` render identically to `"default"` today, pending
  Sharavi's FG2 ruling on those states' visuals.

## [0.3.0] - 2026-07-12
Universal field layer, increment 1 (`universal-field-layer-adoption-map-2026-07-12.md`,
Sharavi ruling 2026-07-12: the ingested Form System field components are the
field rendering layer everywhere a field is displayed, editable or read-only).
### Added
- `FormField` — `optional?: boolean` prop, the other half of the required/optional
  marking convention (Sharavi ruling 2026-07-12, `forms-system-guidelines-ingestion-2026-07-12.md`
  Conflict 1, NN/g convention). `required` already rendered an `aria-hidden`
  asterisk; it now also renders a screen-reader-only "(required)" suffix.
  `optional` renders an explicit "(optional)" label suffix. `required` takes
  precedence if both are set on the same field.

## [0.2.2] - 2026-07-11
Fixed the last known `@dbp/ui` tsc error (same class as the case-workspace
`WorkflowStatusBadge` fix — `WorkflowStatus` gained `cancelled` in contracts
0.3.0):
- `src/stories/services/ps-workflow.stories.tsx` — `STATUS_COLORS`
  `Record<WorkflowStatus, ...>` was missing the `cancelled` key; added a
  neutral-gray treatment. Added missing `assignedUserId: null` to two
  `WorkflowInstance` story fixtures (SP-11 field).
- `pnpm --filter @dbp/ui exec tsc --noEmit` now reports zero errors.

## [0.2.1] - 2026-07-11
DoD §6.3 interaction-state allowlist burn-down (`interaction-state-conformance.test.ts`):
- `WorkspaceGreetingCard` — quick-link buttons now carry
  `focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary`
  (previously hover-only).
- `FeaturedCarousel` — the left/right scroll-arrow buttons now carry the same
  focus-visible ring treatment (previously hover-only).

## [0.2.0] - 2026-07-11
Extended `BoardCard` and `FilterBar` per the kanban vendor-pipeline build
analysis (primitive-swap pass, §3b):

- `BoardCard` — added `secondaryBadgeTone`/`secondaryBadgeLabel` (dual risk +
  status chip row), `locked`/`lockLabel` (compliance-hold state: neutral-wash
  card surface + a danger lock chip), `assigneeName` (initials `Avatar` or an
  "Unassigned" dashed placeholder), and `dueLabel`/`overdue` (due-date slot,
  danger + bold when overdue). All new props are optional; existing
  single-badge/meta consumers render unchanged.
- `FilterBar` — added `resultSummary` (always-visible "N of M" text) and
  `showClearAll`/`onClearAll`/`clearAllLabel` (a "Clear all" action, visible
  only when the caller says something is active).
- References the new `@dbp/design-tokens` `--color-neutral-*` CSS variables
  (added in that package's `0.2.0`) for the locked-card wash and the
  due-date/unassigned-avatar neutral text — no hardcoded hex.

## [0.1.0] - 2026-07-10
Initial documented baseline.
