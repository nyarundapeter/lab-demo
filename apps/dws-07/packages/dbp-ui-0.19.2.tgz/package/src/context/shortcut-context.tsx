"use client";
import * as React from "react";
import { ShortcutHelp } from "../components/shortcut-help.js";
import type { ShortcutHelpConfig } from "../components/shortcut-help.js";

/**
 * Deliverable A of `capability-keyboard-shortcuts-spec-2026-07-10.md` — the
 * scoped shortcut manager. One `<ShortcutProvider>` per shell owns the single
 * window keydown listener, the registry, and the input-focus guard, so
 * consumers never install their own `window.addEventListener("keydown", …)`.
 */

export type ShortcutScope = "global" | "page" | "surface";

export interface ShortcutBinding {
  /**
   * Key combo, e.g. "mod+k", "j", "[", "shift+z", "esc", "?" ("mod" = platform
   * meta/ctrl), OR a two-key sequence — two space-separated bare keys, e.g.
   * "g h" — matching the reference's "press g, then h" chords. Sequences never
   * carry modifiers; use a combo for that.
   */
  keys: string;
  handler: () => void;
  /** Required — powers the self-documenting ShortcutHelp registry. */
  description: string;
  /** Groups this binding in the help overlay. Defaults to "General". */
  group?: string;
}

export interface UseShortcutsOptions {
  /** Precedence when the same combo is bound in multiple scopes: surface > page > global. */
  scope?: ShortcutScope;
  enabled?: boolean;
}

interface RegistryEntry extends ShortcutBinding {
  scope: ShortcutScope;
  registrationId: string;
  /** Parsed [first, second] when `keys` is a two-key sequence; undefined for combos. */
  sequence?: [string, string];
}

/** Sequence keys must land within this window of the first keypress (reference: ~1s). */
const SEQUENCE_TIMEOUT_MS = 1000;

/**
 * A "g h"-style two-key sequence: exactly two space-separated bare keys, no
 * "+" (combos aren't valid inside a sequence — chord one key at a time).
 */
function parseSequenceKeys(keys: string): [string, string] | undefined {
  const parts = keys.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (parts.length !== 2) return undefined;
  if (parts.some((p) => p.includes("+"))) return undefined;
  return [parts[0]!, parts[1]!];
}

const SCOPE_PRIORITY: Record<ShortcutScope, number> = { global: 0, page: 1, surface: 2 };

interface ShortcutContextValue {
  register: (entry: RegistryEntry) => void;
  unregister: (registrationId: string) => void;
}

const ShortcutContext = React.createContext<ShortcutContextValue | null>(null);

export function useShortcutContext(): ShortcutContextValue {
  const ctx = React.useContext(ShortcutContext);
  if (!ctx) {
    throw new Error("useShortcuts must be used within a <ShortcutProvider>");
  }
  return ctx;
}

// ─── Key-combo parsing/matching ────────────────────────────────────────────────

interface ParsedCombo {
  mod: boolean;
  shift: boolean;
  alt: boolean;
  key: string;
}

function parseKeyCombo(keys: string): ParsedCombo {
  const parts = keys.toLowerCase().split("+").map((p) => p.trim()).filter(Boolean);
  const key = parts[parts.length - 1] ?? "";
  return {
    mod: parts.includes("mod"),
    shift: parts.includes("shift"),
    alt: parts.includes("alt"),
    key,
  };
}

const KEY_ALIASES: Record<string, string> = {
  esc: "escape",
  enter: "enter",
  up: "arrowup",
  down: "arrowdown",
  left: "arrowleft",
  right: "arrowright",
  space: " ",
};

function comboKeysEqual(a: ParsedCombo, b: ParsedCombo): boolean {
  return a.mod === b.mod && a.shift === b.shift && a.alt === b.alt && a.key === b.key;
}

/** Only "mod" (⌘/Ctrl) combos bypass the input-focus guard — matches the
 * reference's split exactly (`mod+k`/`mod+shift+L` fire from inputs; bare
 * keys and shift-only combos do not). */
function hasModifier(keys: string): boolean {
  return parseKeyCombo(keys).mod;
}

function isEditableTarget(target: EventTarget | null): boolean {
  const el = target as HTMLElement | null;
  if (!el) return false;
  const tag = el.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable;
}

function matchesBinding(e: KeyboardEvent, keys: string): boolean {
  const parsed = parseKeyCombo(keys);
  const mod = e.metaKey || e.ctrlKey;
  if (parsed.mod !== mod) return false;
  if (parsed.alt !== e.altKey) return false;
  const target = KEY_ALIASES[parsed.key] ?? parsed.key;
  const eventKey = e.key.toLowerCase();
  if (target !== eventKey) return false;
  // Shift is only significant for single letters (distinguishes "z" from
  // "shift+z"); symbol keys like "?" already encode shift in e.key.
  if (/^[a-z]$/.test(parsed.key) && parsed.shift !== e.shiftKey) return false;
  return true;
}

// ─── Registry → ShortcutHelp config ─────────────────────────────────────────────

function buildHelpConfig(entries: RegistryEntry[]): ShortcutHelpConfig {
  const byGroup = new Map<string, RegistryEntry[]>();
  for (const entry of entries) {
    const group = entry.group ?? "General";
    const list = byGroup.get(group) ?? [];
    list.push(entry);
    byGroup.set(group, list);
  }
  return {
    groups: Array.from(byGroup.entries()).map(([title, bindings]) => ({
      id: title,
      title,
      bindings: bindings.map((b) => ({
        id: b.registrationId,
        keys: b.sequence ? [...b.sequence] : b.keys.split("+").map((k) => k.trim()),
        description: b.description,
        ...(b.sequence ? { separator: "sequence" as const } : {}),
      })),
    })),
  };
}

// ─── Provider ────────────────────────────────────────────────────────────────

export interface ShortcutProviderProps {
  children: React.ReactNode;
  /** Disable the built-in `?` → ShortcutHelp binding. Default: false. */
  disableHelp?: boolean;
}

export function ShortcutProvider({ children, disableHelp = false }: ShortcutProviderProps) {
  const registryRef = React.useRef<Map<string, RegistryEntry>>(new Map());
  const [helpOpen, setHelpOpen] = React.useState(false);
  const [helpConfig, setHelpConfig] = React.useState<ShortcutHelpConfig>({ groups: [] });

  const register = React.useCallback((entry: RegistryEntry) => {
    const sequence = parseSequenceKeys(entry.keys);
    const resolved: RegistryEntry = sequence ? { ...entry, sequence } : entry;
    if (process.env.NODE_ENV !== "production") {
      const clash = Array.from(registryRef.current.values()).find((existing) => {
        if (existing.scope !== resolved.scope || existing.registrationId === resolved.registrationId) return false;
        if (resolved.sequence) {
          return (
            existing.sequence !== undefined &&
            existing.sequence[0] === resolved.sequence[0] &&
            existing.sequence[1] === resolved.sequence[1]
          );
        }
        if (existing.sequence) return false;
        return comboKeysEqual(parseKeyCombo(existing.keys), parseKeyCombo(resolved.keys));
      });
      if (clash) {
        console.error(
          `[ShortcutProvider] conflicting binding "${resolved.keys}" in scope "${resolved.scope}": ` +
            `"${clash.description}" already claims this combo (new: "${resolved.description}"). ` +
            `Registrations must be unique per scope — rebind one of them.`,
        );
      }
    }
    registryRef.current.set(resolved.registrationId, resolved);
  }, []);

  const unregister = React.useCallback((registrationId: string) => {
    registryRef.current.delete(registrationId);
  }, []);

  // Built-in "?" → help overlay binding (registered like any other consumer,
  // at global scope, so a genuine conflict is still reported loudly).
  React.useEffect(() => {
    if (disableHelp) return;
    const registrationId = "__shortcut-help__";
    register({
      keys: "?",
      description: "Show keyboard shortcuts",
      group: "General",
      scope: "global",
      registrationId,
      handler: () => {
        setHelpConfig(buildHelpConfig(Array.from(registryRef.current.values())));
        setHelpOpen(true);
      },
    });
    return () => unregister(registrationId);
  }, [disableHelp, register, unregister]);

  // Sequence buffer — the first key of a pending "g h"-style chord, and when it
  // was pressed. A ref (not state) so it never triggers a re-render.
  const pendingSequenceRef = React.useRef<{ key: string; at: number } | null>(null);

  React.useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      const inInput = isEditableTarget(e.target);
      const hasMod = e.metaKey || e.ctrlKey || e.altKey;
      const eventKey = e.key.toLowerCase();

      // Sequences never fire while typing in a field, and any modifier or
      // input-focus keydown resets a pending chord — matches the reference's
      // "j"/"k"-guard split (bare keys only, no combos mid-sequence).
      if (inInput || hasMod) {
        pendingSequenceRef.current = null;
      } else {
        const pending = pendingSequenceRef.current;
        if (pending && Date.now() - pending.at < SEQUENCE_TIMEOUT_MS) {
          pendingSequenceRef.current = null;
          const seqMatches = Array.from(registryRef.current.values()).filter(
            (entry) => entry.sequence && entry.sequence[0] === pending.key && entry.sequence[1] === eventKey,
          );
          if (seqMatches.length > 0) {
            seqMatches.sort((a, b) => SCOPE_PRIORITY[b.scope] - SCOPE_PRIORITY[a.scope]);
            e.preventDefault();
            seqMatches[0]!.handler();
            return;
          }
          // Fall through — the second key may still be a combo/single binding,
          // or the start of a brand-new sequence, handled below.
        } else if (pending) {
          pendingSequenceRef.current = null;
        }
      }

      const matches = Array.from(registryRef.current.values()).filter(
        (entry) => !entry.sequence && matchesBinding(e, entry.keys),
      );
      if (matches.length > 0) {
        const usable = matches.filter((entry) => !inInput || hasModifier(entry.keys));
        if (usable.length > 0) {
          usable.sort((a, b) => SCOPE_PRIORITY[b.scope] - SCOPE_PRIORITY[a.scope]);
          e.preventDefault();
          usable[0]!.handler();
          return;
        }
      }

      // No combo/single fired — start a new pending chord if this key opens one.
      if (!inInput && !hasMod) {
        const startsSequence = Array.from(registryRef.current.values()).some(
          (entry) => entry.sequence && entry.sequence[0] === eventKey,
        );
        if (startsSequence) {
          pendingSequenceRef.current = { key: eventKey, at: Date.now() };
        }
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <ShortcutContext.Provider value={{ register, unregister }}>
      {children}
      {!disableHelp && (
        <ShortcutHelp open={helpOpen} onClose={() => setHelpOpen(false)} config={helpConfig} />
      )}
    </ShortcutContext.Provider>
  );
}
