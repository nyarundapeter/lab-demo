'use client'
import * as React from 'react'

interface BreadcrumbCtx {
  dynamicLabel: string | null
  setDynamicLabel: (label: string | null) => void
}

const BreadcrumbContext = React.createContext<BreadcrumbCtx>({
  dynamicLabel: null,
  setDynamicLabel: () => {},
})

export function BreadcrumbProvider({ children }: { children: React.ReactNode }) {
  const [dynamicLabel, setDynamicLabel] = React.useState<string | null>(null)
  return (
    <BreadcrumbContext.Provider value={{ dynamicLabel, setDynamicLabel }}>
      {children}
    </BreadcrumbContext.Provider>
  )
}

export function useBreadcrumb() {
  return React.useContext(BreadcrumbContext)
}

/**
 * useBreadcrumbOverride — N36 seam. Detail pages call this with the loaded
 * record's display name once it resolves; the top-bar breadcrumb's terminal
 * crumb is replaced with that name instead of the static route label. Pass
 * `undefined` (or omit) while the record is still loading — the static trail
 * is shown until then, avoiding a flicker/placeholder label. Clears itself on
 * unmount so navigating away restores the static trail for the next route.
 */
export function useBreadcrumbOverride(name: string | undefined) {
  const { setDynamicLabel } = useBreadcrumb()
  React.useEffect(() => {
    setDynamicLabel(name ?? null)
    return () => setDynamicLabel(null)
  }, [name, setDynamicLabel])
}
