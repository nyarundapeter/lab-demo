export { Button, buttonVariants } from "./components/button.js";
export type { ButtonProps } from "./components/button.js";

export { Input } from "./components/input.js";
export type { InputProps } from "./components/input.js";

export { FieldLabel } from "./components/field-label.js";
export type { FieldLabelProps } from "./components/field-label.js";

export { SectionLabel, sectionLabelVariants } from "./components/section-label.js";
export type { SectionLabelProps } from "./components/section-label.js";

export { Tabs, TabsList, TabsTrigger, TabsContent } from "./components/tabs.js";

export {
  Sheet,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "./components/sheet.js";
export type { SheetDetent } from "./components/sheet.js";

export { Skeleton } from "./components/skeleton.js";

export {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  CardClickable,
} from "./components/card.js";

export { Breadcrumb } from "./components/breadcrumb.js";
export type { BreadcrumbProps, BreadcrumbItem } from "./components/breadcrumb.js";

export { Grid, Col } from "./components/grid.js";
export type { GridProps, ColProps, ColSpan } from "./components/grid.js";

export { PageHeader } from "./components/page-header.js";
export type { PageHeaderProps, PageHeaderAction, PageHeaderSpan } from "./components/page-header.js";

export { Badge, badgeVariants } from "./components/badge.js";
export type { BadgeProps } from "./components/badge.js";

export { AiMark } from "./components/ai-mark.js";
export type { AiMarkProps } from "./components/ai-mark.js";

export { ProvTag, provTagVariants, PROV_LABEL } from "./components/prov-tag.js";
export type { ProvTagProps } from "./components/prov-tag.js";

export { CtrlBadge, CTRL_LABEL } from "./components/ctrl-badge.js";
export type { CtrlBadgeProps } from "./components/ctrl-badge.js";
export { EnvPill, envPillVariants } from "./components/env-pill.js";
export type { EnvPillProps } from "./components/env-pill.js";

export { SevChip } from "./components/sev-chip.js";
export type { SevChipProps } from "./components/sev-chip.js";
export { PriorityPill } from "./components/priority-pill.js";
export type { PriorityPillProps } from "./components/priority-pill.js";
export { TypeTag } from "./components/type-tag.js";
export type { TypeTagProps } from "./components/type-tag.js";

export { CriticalCard, CRITICAL_STATUS_STEPS } from "./components/critical-card.js";
export type { CriticalCardProps, CriticalCardField, CriticalStatusStep } from "./components/critical-card.js";

export { EscalationTimeline } from "./components/escalation-timeline.js";
export type { EscalationTimelineProps, EscalationStep } from "./components/escalation-timeline.js";

export { AiConfidence, CONF_LABEL } from "./components/ai-confidence.js";
export type { AiConfidenceProps } from "./components/ai-confidence.js";

export { CiteRef } from "./components/cite-ref.js";
export type { CiteRefProps } from "./components/cite-ref.js";

export { SourceRow, sourceIcon, REL_LABEL } from "./components/source-row.js";
export type { SourceRowProps, AiSource, AiSourceType, AiSourceRelevance } from "./components/source-row.js";

export { SourceList } from "./components/source-list.js";
export type { SourceListProps } from "./components/source-list.js";

export { SourcePreview } from "./components/source-preview.js";
export type { SourcePreviewProps } from "./components/source-preview.js";

export { AcceptEditReject } from "./components/accept-edit-reject.js";
export type { AcceptEditRejectProps } from "./components/accept-edit-reject.js";

export { ConfirmationPreview } from "./components/confirmation-preview.js";
export type { ConfirmationPreviewProps, ConfirmationPreviewField } from "./components/confirmation-preview.js";

export { AiLabel, AI_LABEL } from "./components/ai-label.js";
export type { AiLabelProps, AiLabelKind } from "./components/ai-label.js";

export { AiSurface, AiSurfaceFacet, CategoryTag, INSIGHT_CATEGORY } from "./components/ai-surface.js";
export type { AiSurfaceProps, AiSurfaceFacetProps, CategoryTagProps, InsightCategory } from "./components/ai-surface.js";

export { InfoCard } from "./components/info-card.js";
export type { InfoCardProps, InfoCardTone, InfoCardRow } from "./components/info-card.js";

export { AiActionCard } from "./components/ai-action-card.js";
export type { AiActionCardProps, AiActionCardField } from "./components/ai-action-card.js";

export { LifecycleBar, CONFIG_LIFECYCLE_STAGES, deriveConfigLifecycleStages } from "./components/lifecycle-bar.js";
export type { LifecycleBarProps, LifecycleBarVariant, ConfigLifecycleStage } from "./components/lifecycle-bar.js";

export { Advisory } from "./components/advisory.js";
export type { AdvisoryProps } from "./components/advisory.js";

export { FeedbackControl } from "./components/feedback-control.js";
export type { FeedbackControlProps } from "./components/feedback-control.js";

export { GovState, GOV_STATE } from "./components/gov-state.js";
export type { GovStateProps, GovStateKind } from "./components/gov-state.js";

/* ─── Wave 3 Family 1 — AI-governance base, remaining NEW atoms/molecules (2026-07-21) ─── */

export { AssistTrigger } from "./components/assist-trigger.js";
export type { AssistTriggerProps, AssistTriggerState } from "./components/assist-trigger.js";

export { AiFieldFrame } from "./components/ai-field-frame.js";
export type { AiFieldFrameProps } from "./components/ai-field-frame.js";

export { SuggestionChip } from "./components/suggestion-chip.js";
export type { SuggestionChipProps } from "./components/suggestion-chip.js";

export { CompletenessCheck } from "./components/completeness-check.js";
export type { CompletenessCheckProps, CompletenessCheckItem } from "./components/completeness-check.js";

export { AutofillLauncher } from "./components/autofill-launcher.js";
export type { AutofillLauncherProps } from "./components/autofill-launcher.js";

export { AutofillPreview } from "./components/autofill-preview.js";
export type { AutofillPreviewProps, AutofillPreviewData, AutofillPreviewField } from "./components/autofill-preview.js";

export { RefineButton, REFINE_LENGTH_OPTIONS, REFINE_TONE_OPTIONS } from "./components/refine-button.js";
export type { RefineButtonProps, RefineAxis } from "./components/refine-button.js";

export { ActivityStrip } from "./components/activity-strip.js";
export type { ActivityStripProps, ActivityStripEvent, ActivityStripEventKind, ActivityStripEventStatus } from "./components/activity-strip.js";

export { SuggestedAction } from "./components/suggested-action.js";
export type { SuggestedActionProps, SuggestedActionRisk } from "./components/suggested-action.js";

export { RootCauseCard } from "./components/root-cause-card.js";
export type { RootCauseCardProps, RootCauseCardData, RootCauseHypothesis } from "./components/root-cause-card.js";

export { SummaryCard } from "./components/summary-card.js";
export type { SummaryCardProps, SummaryCardData } from "./components/summary-card.js";

export { AnomalyInsightCard } from "./components/anomaly-insight-card.js";
export type { AnomalyInsightCardProps, AnomalyInsightCardData } from "./components/anomaly-insight-card.js";

export { AiExecSummary } from "./components/ai-exec-summary.js";
export type { AiExecSummaryProps, AiExecSummaryPoint, AiExecSummaryTone } from "./components/ai-exec-summary.js";

export { DataQualityCard } from "./components/data-quality-card.js";
export type { DataQualityCardProps, DataQualityCardItem, DataQualitySeverity } from "./components/data-quality-card.js";

export { ForecastInline } from "./components/forecast-inline.js";
export type { ForecastInlineProps } from "./components/forecast-inline.js";

export { AiThinking, AiSteps } from "./components/ai-steps.js";
export type { AiThinkingProps, AiStepsProps, AiStep, AiStepState } from "./components/ai-steps.js";

export { CatalogCard } from "./components/catalog-card.js";
export type { CatalogCardProps } from "./components/catalog-card.js";

export { Separator } from "./components/separator.js";

export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuGroup,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuRadioGroup,
} from "./components/dropdown-menu.js";

export { ScrollArea, ScrollBar } from "./components/scroll-area.js";

export { SlotFrame } from "./components/slot-frame.js";
export type { SlotFrameProps } from "./components/slot-frame.js";

export { AppTopBar } from "./components/app-top-bar.js";
export type { AppTopBarProps } from "./components/app-top-bar.js";

export { AppChrome } from "./components/app-chrome.js";
export type {
  AppChromeProps,
  AppChromeSession,
} from "./components/app-chrome.js";

export { AppFooter } from "./components/app-footer.js";
export type {
  AppFooterProps,
  AppFooterShortcut,
  AppFooterLink,
} from "./components/app-footer.js";

export { useKeyboardShortcuts } from "./hooks/use-keyboard-shortcuts.js";
export type { KeyboardShortcut } from "./hooks/use-keyboard-shortcuts.js";
export { useDebounce } from "./hooks/use-debounce.js";
export { useChartReady } from "./hooks/use-chart-ready.js";

/* ─── Wave 3 Family 4c — Notification, remaining NEW flat molecules (2026-07-22) ─── */

export { NotifPopover } from "./components/notif-popover.js";
export type { NotifPopoverProps, NotifPopoverItem, NotifPopoverTab } from "./components/notif-popover.js";

export { AiAlert } from "./components/ai-alert.js";
export type { AiAlertProps, AiAlertData } from "./components/ai-alert.js";

export { AppSidebar, SidebarIdentity } from "./components/app-sidebar.js";
export type { AppSidebarProps, SidebarIdentityProps } from "./components/app-sidebar.js";

export { LoginPage } from "./components/login-page.js";
export type { LoginPageProps } from "./components/login-page.js";
export { LoginCredentialsForm } from "./components/login-credentials-form.js";
export type { LoginCredentialsFormProps, LoginSeedUser } from "./components/login-credentials-form.js";
export { MicrosoftSignInButton } from "./components/microsoft-sign-in-button.js";
export type { MicrosoftSignInButtonProps } from "./components/microsoft-sign-in-button.js";

export { StatTile } from "./components/stat-tile.js";
export type {
  StatTileProps,
  StatTileTone,
  StatTileTrend,
  StatTileAttainmentColorMode,
  StatTileStatus,
  StatTileErrorDetail,
} from "./components/stat-tile.js";

export { StatusBadge } from "./components/status-badge.js";
export type { StatusBadgeProps, AdminLifecycleStatus } from "./components/status-badge.js";

export { DashboardDensityProvider, useDashboardDensity } from "./components/dashboard-density.js";
export type { DashboardDensity, DashboardDensityProviderProps } from "./components/dashboard-density.js";

export { WorkflowStatusSummary } from "./components/workflow-status-summary.js";
export type { WorkflowStatusSummaryProps, WorkflowStatusSummaryVariant } from "./components/workflow-status-summary.js";

export { VerticalStageTracker, deriveStagesFromWorkflowInstance } from "./components/vertical-stage-tracker.js";
export type { VerticalStageTrackerProps, StageRow, StageStatus } from "./components/vertical-stage-tracker.js";

/* ─── New P0 components ───────────────────────────────────────────────── */

export {
  Dialog,
  DialogTrigger,
  DialogClose,
  DialogPortal,
  DialogOverlay,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogBody,
  DialogTitle,
  DialogDescription,
} from "./components/dialog.js";

export {
  FullScreenModal,
  FullScreenModalTrigger,
  FullScreenModalClose,
  FullScreenModalPortal,
  FullScreenModalContent,
  FullScreenModalBar,
  FullScreenModalTitle,
  FullScreenModalDescription,
  FullScreenModalBody,
  FullScreenModalMain,
  FullScreenModalRail,
  FullScreenModalFooter,
} from "./components/fullscreen-modal.js";

export {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
  ConfirmDialog,
  DestructiveConfirmDialog,
  HighImpactConfirmDialog,
  BulkConfirmDialog,
  ProductionConfirmDialog,
  UnsavedChangesConfirmDialog,
} from "./components/alert-dialog.js";
export type {
  ConfirmDialogProps,
  DestructiveConfirmDialogProps,
  HighImpactConfirmDialogProps,
  BulkConfirmDialogProps,
  ProductionConfirmDialogProps,
  UnsavedChangesConfirmDialogProps,
} from "./components/alert-dialog.js";

export {
  Toast,
  ToastTitle,
  ToastDescription,
  ToastAction,
  ToastProvider,
  ToastViewport,
  Toaster,
  toast,
  useToast,
} from "./components/toast.js";
export type { ToastOptions, ToastProps } from "./components/toast.js";

export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton,
} from "./components/select.js";

export { FormField } from "./components/form-field.js";
export type { FormFieldProps } from "./components/form-field.js";

export { AdminSettingsForm } from "./components/admin-settings-form.js";
export type { AdminSettingsFormProps, AdminSettingsFormField, AdminSettingsFormSection, AdminSettingsFieldType } from "./components/admin-settings-form.js";

export { AdminAuditLog } from "./components/admin-audit-log.js";
export { SettingsNav } from "./components/settings-nav.js";
export type { SettingsNavLink } from "./components/settings-nav.js";

// Wave 3 Family 2 (Config-governance) molecules
export { ChangeImpactPanel } from "./components/change-impact-panel.js";
export type { ChangeImpactPanelProps, ImpactItem, ImpactRiskLevel } from "./components/change-impact-panel.js";
export { DependencyView } from "./components/dependency-view.js";
export type { DependencyViewProps, DependencyNode } from "./components/dependency-view.js";
export { VersionCompare } from "./components/version-compare.js";
export type { VersionCompareProps, DiffLine, DiffLineType, CompareVersionOption } from "./components/version-compare.js";
export { VersionHistory } from "./components/version-history.js";
export type { VersionHistoryProps, VersionRecord, VersionStatus } from "./components/version-history.js";
export { MappingRowList } from "./components/mapping-row-list.js";
export type { MappingRowListProps, MappingRowListItem } from "./components/mapping-row-list.js";
export { PersonaSwitcher } from "./components/persona-switcher.js";
export type { PersonaSwitcherProps, Persona } from "./components/persona-switcher.js";

export { FormSection } from "./components/form-section.js";
export type { FormSectionProps } from "./components/form-section.js";

export { Textarea } from "./components/textarea.js";
export type { TextareaProps } from "./components/textarea.js";

export { FileDropzone } from "./components/file-dropzone.js";
export type { FileDropzoneProps } from "./components/file-dropzone.js";

export { Alert } from "./components/alert.js";
export type { AlertProps } from "./components/alert.js";
export { ConflictBanner } from "./components/conflict-banner.js";
export type {
  ConflictBannerProps,
  ConflictFieldDiff,
  ConflictResolveAction,
} from "./components/conflict-banner.js";

/* ─── New P1 components ───────────────────────────────────────────────── */

export { Checkbox } from "./components/checkbox.js";
export type { CheckboxProps } from "./components/checkbox.js";

export { Switch } from "./components/switch.js";

export { ThemeToggle } from "./components/theme-toggle.js";
export type { ThemeToggleProps } from "./components/theme-toggle.js";


export { RadioGroup } from "./components/radio-group.js";
export type { RadioGroupProps, RadioGroupOption } from "./components/radio-group.js";

export { SearchSelect } from "./components/search-select.js";
export type { SearchSelectProps, SearchSelectOption } from "./components/search-select.js";

export { StepNav } from "./components/step-nav.js";
export type { StepNavProps, StepNavItem, StepNavState } from "./components/step-nav.js";

export { TagsField } from "./components/tags-field.js";
export type { TagsFieldProps } from "./components/tags-field.js";

export { TimeField } from "./components/time-field.js";
export type { TimeFieldProps } from "./components/time-field.js";

export { DateRangeField } from "./components/date-range-field.js";
export type { DateRangeFieldProps, DateRangeValue } from "./components/date-range-field.js";

export { RichTextField } from "./components/rich-text-field.js";
export type { RichTextFieldProps } from "./components/rich-text-field.js";

export { PwField } from "./components/pw-field.js";
export type { PwFieldProps } from "./components/pw-field.js";

export { StrengthMeter } from "./components/strength-meter.js";
export type { StrengthMeterProps } from "./components/strength-meter.js";

export { PolicyList } from "./components/policy-list.js";
export type { PolicyListProps, PolicyListItem } from "./components/policy-list.js";

export { CodeInput } from "./components/code-input.js";
export type { CodeInputProps } from "./components/code-input.js";

export { OrgIdentityRow } from "./components/org-identity-row.js";
export type { OrgIdentityRowProps } from "./components/org-identity-row.js";
/** @deprecated Use `OrgIdentityRow`. */
export { OrgBadge } from "./components/org-badge.js";
/** @deprecated Use `OrgIdentityRowProps`. */
export type { OrgBadgeProps } from "./components/org-badge.js";

export { RepeatableGroup } from "./components/repeatable-group.js";
export type { RepeatableGroupProps } from "./components/repeatable-group.js";

export { ReadOnlyValue } from "./components/read-only-value.js";
export type { ReadOnlyValueProps } from "./components/read-only-value.js";

export { FieldValue } from "./components/field-value.js";
export type { FieldValueProps, FieldFormat } from "./components/field-value.js";

export { SaveStatus } from "./components/save-status.js";
export type { SaveStatusProps, SaveStatusState } from "./components/save-status.js";

export { ActionFooter } from "./components/action-footer.js";
export type { ActionFooterProps, ActionFooterAction } from "./components/action-footer.js";

export { ValidationSummary } from "./components/validation-summary.js";
export type { ValidationSummaryProps, ValidationSummaryItem, ValidationSeverity } from "./components/validation-summary.js";

export { InlineEditable } from "./components/inline-editable.js";
export type { InlineEditableProps } from "./components/inline-editable.js";

export {
  TooltipProvider,
  Tooltip,
  TooltipTrigger,
  TooltipContent,
  SimpleTooltip,
} from "./components/tooltip.js";
export type { SimpleTooltipProps } from "./components/tooltip.js";

export { Avatar, AvatarLockup, AvatarStack } from "./components/avatar.js";
export type { AvatarProps, AvatarLockupProps, AvatarPresence, AvatarStackItem, AvatarStackProps } from "./components/avatar.js";

export { EmptyState } from "./components/empty-state.js";
export type { EmptyStateProps } from "./components/empty-state.js";

export { LoadingSkeleton } from "./components/loading-skeleton.js";
export type { LoadingSkeletonProps } from "./components/loading-skeleton.js";

export { ErrorCard } from "./components/error-card.js";
export type { ErrorCardProps } from "./components/error-card.js";

export { ErrorState } from "./components/error-state.js";
export type { ErrorStateProps } from "./components/error-state.js";

export { CenteredNotice } from "./components/centered-notice.js";
export type { CenteredNoticeProps, CenteredNoticeTone } from "./components/centered-notice.js";

export { Pagination } from "./components/pagination.js";
export type { PaginationProps } from "./components/pagination.js";

export { Progress } from "./components/progress.js";
export type { ProgressProps } from "./components/progress.js";

export { SegmentedControl } from "./components/segmented-control.js";
export type { SegmentedControlProps, SegmentOption } from "./components/segmented-control.js";

export { Sparkline } from "./components/sparkline.js";
export type { SparklineProps } from "./components/sparkline.js";

export { Gauge } from "./components/gauge.js";
export type { GaugeProps, GaugeThreshold } from "./components/gauge.js";

export { BulletChart } from "./components/bullet-chart.js";
export type { BulletChartProps } from "./components/bullet-chart.js";

export { Heatmap } from "./components/heatmap.js";
export type { HeatmapProps, HeatmapCellColor } from "./components/heatmap.js";

export { Funnel } from "./components/funnel.js";
export type { FunnelProps, FunnelStage } from "./components/funnel.js";

export { StatusDot, STATUS } from "./components/status-dot.js";
export type { StatusDotProps, StatusDotStatus, StatusToken } from "./components/status-dot.js";

export { Delta } from "./components/delta.js";
export type { DeltaProps, DeltaPolarity } from "./components/delta.js";

export { DashSection } from "./components/dash-section.js";
export type { DashSectionProps } from "./components/dash-section.js";

export { HealthStatusCard } from "./components/health-status-card.js";
export type { HealthStatusCardProps, HealthStatusCardSubMetric } from "./components/health-status-card.js";

export { MilestoneRow } from "./components/milestone-row.js";
export type { MilestoneRowProps } from "./components/milestone-row.js";

export { Ranking } from "./components/ranking.js";
export type { RankingProps, RankingItem } from "./components/ranking.js";

export { ProvenanceKey } from "./components/provenance-key.js";
export type { ProvenanceKeyProps } from "./components/provenance-key.js";

export { IntentStrip } from "./components/intent-strip.js";
export type { IntentStripProps } from "./components/intent-strip.js";

export { AssistantFab } from "./components/assistant-fab.js";
export type { AssistantFabProps } from "./components/assistant-fab.js";

export { ForecastCard } from "./components/forecast-card.js";
export type { ForecastCardProps, ForecastCardData } from "./components/forecast-card.js";

export { AnomalyCard } from "./components/anomaly-card.js";
export type { AnomalyCardProps, AnomalySeverity } from "./components/anomaly-card.js";

/* ─── Workflow-system design-audit gap resolution (W6a, 2026-07-18) ─────── */

export { AssigneeCard } from "./components/assignee-card.js";
export type { AssigneeCardProps, AssigneeKind } from "./components/assignee-card.js";

export { EscalationCard } from "./components/escalation-card.js";
export type { EscalationCardProps, EscalationVariant } from "./components/escalation-card.js";

export { DependencyCard } from "./components/dependency-card.js";
export type { DependencyCardProps, DependencyDirection } from "./components/dependency-card.js";

export { ExceptionCard } from "./components/exception-card.js";
export type { ExceptionCardProps, ExceptionVariant } from "./components/exception-card.js";

export { TaskChecklist } from "./components/task-checklist.js";
export type { TaskChecklistProps, ChecklistItem, ChecklistItemStatus } from "./components/task-checklist.js";

/* ─── Public Landing Page components ─────────────────────────────────── */

export { PublicNavHeader } from "./components/public-nav-header.js"
export type { PublicNavHeaderProps, PublicNavHeaderNavLink, PublicNavHeaderSignIn } from "./components/public-nav-header.js"

export { LandingHero } from "./components/landing-hero.js"
export type { LandingHeroProps, LandingHeroTrustBullet, LandingHeroCta } from "./components/landing-hero.js"

export { LandingFeatures, LandingHowItWorks, LandingCta } from "./components/landing-sections.js"

export { WorkspaceGreetingCard } from "./components/workspace-greeting-card.js"
export type {
  WorkspaceGreetingCardProps,
  WorkspaceGreetingQuickLink,
  WorkspaceGreetingUpdate,
} from "./components/workspace-greeting-card.js"
export type {
  LandingFeaturesProps,
  LandingFeatureItem,
  LandingHowItWorksProps,
  LandingHowItWorksStep,
  LandingCtaProps,
  LandingCtaFeatureTile,
} from "./components/landing-sections.js"

export { LandingFooter } from "./components/landing-footer.js"
export type { LandingFooterProps, LandingFooterColumn, LandingFooterLinkItem } from "./components/landing-footer.js"

export { WorkspaceHomeHero } from "./components/workspace-home-hero.js"
export type { WorkspaceHomeHeroProps, WorkspaceHomeHeroAction } from "./components/workspace-home-hero.js"

export { WorkspaceHomeClosing } from "./components/workspace-home-closing.js"
export type {
  WorkspaceHomeClosingProps,
  WorkspaceHomeClosingAction,
  WorkspaceHomeClosingOutcome,
} from "./components/workspace-home-closing.js"

export { PublicPageHeader } from "./components/public-page-header.js"
export type { PublicPageHeaderProps } from "./components/public-page-header.js"

export { MeshSection } from "./components/mesh-section.js"
export type { MeshSectionProps, MeshVariant } from "./components/mesh-section.js"

export { SectionHeading } from "./components/section-heading.js"
export type { SectionHeadingProps } from "./components/section-heading.js"

export { FeaturedCarousel } from "./components/featured-carousel.js"
export type { FeaturedCarouselProps } from "./components/featured-carousel.js"

/* ─── Detail page layout primitives ──────────────────────────────────── */

export { DetailPageGrid } from "./components/detail-page-grid.js"
export type { DetailPageGridProps } from "./components/detail-page-grid.js"

export { RailSection, RailActionButton, SectionCard } from "./components/detail-rail.js"
export type {
  RailSectionProps,
  RailActionButtonProps,
  RailActionTone,
  SectionCardProps,
} from "./components/detail-rail.js"

/* ─── App Home primitives ─────────────────────────────────────────────── */

export { AISearchBar } from "./components/ai-search-bar.js";
export type { AISearchBarProps } from "./components/ai-search-bar.js";

export { FilterBar } from "./components/filter-bar.js";
export type { FilterBarProps, FilterChip } from "./components/filter-bar.js";

export { CollectionToolbar } from "./components/collection-toolbar.js";
export type {
  CollectionToolbarProps,
  CollectionToolbarFilter,
  CollectionToolbarChip,
} from "./components/collection-toolbar.js";

export { BoardCard } from "./components/board-card.js";
export type { BoardCardProps } from "./components/board-card.js";

/* ─── Wave 3 Family 4e — Search (search-system) ──────────────────────── */

export { Highlight, TypePill, StatusChip, MetaLine } from "./components/search-result-row.js";
export type { HighlightProps, TypePillProps, StatusChipProps, MetaLineProps, MetaLineItem } from "./components/search-result-row.js";

export { FindInRecord } from "./components/find-in-record.js";
export type { FindInRecordProps, FindInRecordEntry } from "./components/find-in-record.js";

export { AlertConfig } from "./components/alert-config.js";
export type { AlertConfigProps, AlertFrequency } from "./components/alert-config.js";

export { SaveSearchModal } from "./components/save-search-modal.js";
export type { SaveSearchModalProps, SaveSearchQueryChip, SaveSearchInput } from "./components/save-search-modal.js";

export { SlowSearch } from "./components/slow-search.js";
export type { SlowSearchProps, SlowSearchSource, SearchSourceStatus } from "./components/slow-search.js";

/* ─── Utilities ───────────────────────────────────────────────────────── */

export { cn } from "./lib/cn.js";

export { buildSidebarConfig, deriveActivePath } from "./lib/build-sidebar-config.js";

export {
  PASSWORD_POLICY,
  passwordScore,
  passwordPolicyItems,
  type PasswordPolicyItem,
} from "./lib/password-policy.js";

export {
  formatNumber,
  formatCurrency,
  formatPercent,
  formatDate,
  formatRelativeTime,
  relativeTimeCompact,
  isIsoDateString,
  isYearMonthString,
  type FormatNumberOptions,
  type FormatCurrencyOptions,
  type DateStyle,
} from "./lib/format.js";

export { PermissionGate } from "./bindings/index.js";
export type { PermissionGateProps } from "./bindings/index.js";

export { BreadcrumbProvider, useBreadcrumb, useBreadcrumbOverride } from './context/breadcrumb-context.js'

export { LegalPageLayout } from "./components/legal-page-layout.js"
export type { LegalPageLayoutProps, LegalSection } from "./components/legal-page-layout.js"

export { PublicContactForm } from "./components/public-contact-form.js"
export type { PublicContactFormProps } from "./components/public-contact-form.js"

export {
  Popover,
  PopoverTrigger,
  PopoverAnchor,
  PopoverClose,
  PopoverContent,
} from "./components/popover.js"

export { ShortcutProvider } from "./context/shortcut-context.js"
export type {
  ShortcutScope,
  ShortcutBinding,
  UseShortcutsOptions,
  ShortcutProviderProps,
} from "./context/shortcut-context.js"

export { useShortcuts } from "./hooks/use-shortcuts.js"

export { ShortcutHelp } from "./components/shortcut-help.js"
export type {
  ShortcutHelpProps,
  ShortcutHelpConfig,
  ShortcutGroupConfig,
  ShortcutBindingConfig,
  ShortcutHelpDataState,
  KeyToken,
} from "./components/shortcut-help.js"

export { ActivityTimeline } from "./components/activity-timeline.js"
export type { ActivityTimelineProps } from "./components/activity-timeline.js"

export { ActivityComposer } from "./components/activity-composer.js"
export type { ActivityComposerProps } from "./components/activity-composer.js"

export { AnnouncementBanner } from "./components/announcement-banner.js"
export type { AnnouncementBannerProps } from "./components/announcement-banner.js"

export {
  ActivityToneSchema,
  ActivityIconNameSchema,
  ActivityTypeConfigSchema,
  ActivityAttachmentSchema,
  ActivityEntrySchema,
  ActivityDataStateSchema,
  ActivityMentionUserSchema,
  ActivityTimelineConfigSchema,
  ActivityDraftSchema,
} from "./schemas/activity.js"
export type {
  ActivityTone,
  ActivityIconName,
  ActivityTypeConfig,
  ActivityAttachment,
  ActivityEntry,
  ActivityDataState,
  ActivityMentionUser,
  ActivityTimelineConfig,
  ActivityDraft,
} from "./schemas/activity.js"

export { DetailDrawer, useContainerWidth } from "./components/detail-drawer.js";
export type { DetailDrawerProps, DetailDrawerPill, DetailDrawerTab } from "./components/detail-drawer.js";

export { DetailTabStrip } from "./components/detail-tab-strip.js";
export type { DetailTabStripProps } from "./components/detail-tab-strip.js";

export { DetailFilterRow } from "./components/detail-filter-row.js";
export type {
  DetailFilterRowProps,
  DetailFilterRowMapping,
  DetailFilterRowMappingOption,
  DetailFilterRowSelectFilter,
  DetailFilterRowSearch,
} from "./components/detail-filter-row.js";

export {
  DetailStatusText,
  DetailChip,
  DetailLinkedRecordsList,
  standardLinkedRecordColumns,
} from "./components/detail-linked-records-list.js";
export type {
  DetailChipProps,
  DetailLinkedRecord,
  DetailLinkedRecordsListFilter,
  DetailLinkedRecordsListColumn,
  DetailLinkedRecordsListProps,
} from "./components/detail-linked-records-list.js";

/* ─── Wave 3 Family 3 — Workflow ownership/risk cards, remaining NEW molecules (2026-07-22) ─── */

export { ParallelTracker } from "./components/parallel-tracker.js"
export type { ParallelTrackerProps, ParallelBranch, ParallelBranchStatus } from "./components/parallel-tracker.js"

export { ConditionalTracker } from "./components/conditional-tracker.js"
export type { ConditionalTrackerProps, ConditionalAlternative } from "./components/conditional-tracker.js"

export { CompactTracker } from "./components/compact-tracker.js"
export type { CompactTrackerProps } from "./components/compact-tracker.js"

export { MilestoneTracker } from "./components/milestone-tracker.js"
export type { MilestoneTrackerProps } from "./components/milestone-tracker.js"

export { CommitteeDecision } from "./components/committee-decision.js"
export type { CommitteeDecisionProps, CommitteeMemberVote, CommitteeVote } from "./components/committee-decision.js"

export { EvidencePanel } from "./components/evidence-panel.js"
export type { EvidencePanelProps, EvidenceItem } from "./components/evidence-panel.js"

/* ─── Wave 3 Family 4d — Overlay (2026-07-22) ─── */

export { SaveDraftButton } from "./components/save-draft-button.js"
export type { SaveDraftButtonProps } from "./components/save-draft-button.js"

export { useUnsavedGuard } from "./hooks/use-unsaved-guard.js"
export type { UseUnsavedGuardOptions, UseUnsavedGuardResult } from "./hooks/use-unsaved-guard.js"

export { SaveStateIndicator, SAVE_STATE } from "./components/save-state-indicator.js"
export type { SaveStateIndicatorProps, SaveState } from "./components/save-state-indicator.js"

export { SidePanelExtension } from "./components/side-panel-extension.js"
export type { SidePanelExtensionProps, SidePanelExtensionTab } from "./components/side-panel-extension.js"

export { StatusPickerPopover } from "./components/status-picker-popover.js"
export type { StatusPickerPopoverProps, StatusPickerOption } from "./components/status-picker-popover.js"

export { ChecklistFilterMenu } from "./components/checklist-filter-menu.js"
export type { ChecklistFilterMenuProps, ChecklistFilterOption } from "./components/checklist-filter-menu.js"

export { FilterPillPopover } from "./components/filter-pill-popover.js"
export type { FilterPillPopoverProps } from "./components/filter-pill-popover.js"

/* ─── App Home — Platform / Journey sections (PR #65 rebuild, 2026-07-27) ─── */

export { WorkspaceHomePlatform } from "./components/workspace-home-platform.js"
export type {
  WorkspaceHomePlatformProps,
  PlatformIconKind,
  PlatformFeature,
  PlatformCapability,
} from "./components/workspace-home-platform.js"

export { WorkspaceHomeJourney } from "./components/workspace-home-journey.js"
export type { WorkspaceHomeJourneyProps, JourneyStep } from "./components/workspace-home-journey.js"

export { useWorkspaceHomeJourneyStack } from "./components/use-workspace-home-journey-stack.js"
