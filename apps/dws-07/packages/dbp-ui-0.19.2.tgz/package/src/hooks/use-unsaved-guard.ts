import { useCallback, useState } from "react";

export interface UseUnsavedGuardOptions {
  /** Whether there is currently unsaved data (e.g. react-hook-form's `formState.isDirty`). */
  isDirty: boolean;
  /** Called once the user has explicitly chosen to discard (or immediately, if not dirty). */
  onDiscard: () => void;
  /** Optional third path — save the draft, then leave. Omit to offer only discard/keep-editing. */
  onSaveAndLeave?: () => void;
}

export interface UseUnsavedGuardResult {
  /** Wire to the close/cancel affordance — opens the confirm dialog only when dirty (OVL-05 "unsaved" tier / overlay-modals.jsx `tryClose`). */
  requestClose: () => void;
  /** Wire directly to `UnsavedChangesConfirmDialog`'s `open` prop. */
  confirmOpen: boolean;
  /** Wire directly to `UnsavedChangesConfirmDialog`'s `onOpenChange` prop. */
  setConfirmOpen: (open: boolean) => void;
  /** Wire directly to `UnsavedChangesConfirmDialog`'s `onDiscard` prop. */
  confirmDiscard: () => void;
  /** Wire directly to `UnsavedChangesConfirmDialog`'s `onSaveAndLeave` prop — `undefined` when `onSaveAndLeave` was not supplied. */
  confirmSaveAndLeave: (() => void) | undefined;
}

/**
 * Shared unsaved-changes guard (OVL-05/overlay-modals.jsx `CreateRequestModal`,
 * overlay-drawers.jsx `DrawerForm`): closing a dirty form asks first, closing
 * a clean one closes immediately. Extracted from `record-form`'s
 * `FormBody.handleCancel` — pair with `UnsavedChangesConfirmDialog` from
 * `alert-dialog.tsx`.
 */
export function useUnsavedGuard({
  isDirty,
  onDiscard,
  onSaveAndLeave,
}: UseUnsavedGuardOptions): UseUnsavedGuardResult {
  const [confirmOpen, setConfirmOpen] = useState(false);

  const requestClose = useCallback(() => {
    if (isDirty) {
      setConfirmOpen(true);
      return;
    }
    onDiscard();
  }, [isDirty, onDiscard]);

  const confirmDiscard = useCallback(() => {
    setConfirmOpen(false);
    onDiscard();
  }, [onDiscard]);

  const confirmSaveAndLeave = onSaveAndLeave
    ? () => {
        setConfirmOpen(false);
        onSaveAndLeave();
      }
    : undefined;

  return { requestClose, confirmOpen, setConfirmOpen, confirmDiscard, confirmSaveAndLeave };
}
