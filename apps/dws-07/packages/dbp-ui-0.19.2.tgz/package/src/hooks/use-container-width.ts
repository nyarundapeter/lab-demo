import * as React from "react";

/**
 * Measures a container's own rendered width via ResizeObserver — used for
 * column-shedding decisions that must key off an element's actual box
 * (e.g. a drawer panel that can be narrow or expanded to full width) rather
 * than a viewport media query. Ported from the STCB GRC solution's shared
 * detail-drawer kit (WS-6.2).
 */
export function useContainerWidth<T extends HTMLElement>(): [React.RefObject<T | null>, number] {
  const ref = React.useRef<T | null>(null);
  const [width, setWidth] = React.useState(0);
  React.useEffect(() => {
    const el = ref.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    setWidth(el.getBoundingClientRect().width);
    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) setWidth(entry.contentRect.width);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, width];
}
