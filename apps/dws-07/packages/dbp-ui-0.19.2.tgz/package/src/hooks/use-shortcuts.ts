"use client";
import * as React from "react";
import { useShortcutContext } from "../context/shortcut-context.js";
import type { ShortcutBinding, UseShortcutsOptions } from "../context/shortcut-context.js";

let registrationCounter = 0;

/**
 * Registers `bindings` with the nearest `<ShortcutProvider>` for as long as
 * the calling component is mounted and `enabled` is true. Handlers receive no
 * DOM event details beyond the manager's own `preventDefault` — navigation
 * models (e.g. j/k focus walking) stay in the consuming organism; this hook
 * only routes keys to handlers.
 *
 * `scope` defaults to `"page"`. Pass `"surface"` for a component that should
 * win over page/global bindings on the same combo while mounted (e.g. a
 * record-drawer's local Esc), or `"global"` for a shell-level binding.
 */
export function useShortcuts(bindings: ShortcutBinding[], options: UseShortcutsOptions = {}): void {
  const { scope = "page", enabled = true } = options;
  const { register, unregister } = useShortcutContext();
  const latestBindings = React.useRef(bindings);
  latestBindings.current = bindings;

  const signature = bindings.map((b) => `${b.keys}::${b.description}::${b.group ?? ""}`).join("|");

  React.useEffect(() => {
    if (!enabled) return;
    const registrationIds = bindings.map((binding, index) => {
      const registrationId = `shortcut-${++registrationCounter}`;
      register({
        keys: binding.keys,
        description: binding.description,
        ...(binding.group !== undefined ? { group: binding.group } : {}),
        scope,
        registrationId,
        handler: () => latestBindings.current[index]?.handler(),
      });
      return registrationId;
    });
    return () => {
      registrationIds.forEach(unregister);
    };
    // `signature` captures every field that should trigger re-registration;
    // handler identity changes are read from latestBindings instead.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signature, scope, enabled]);
}
