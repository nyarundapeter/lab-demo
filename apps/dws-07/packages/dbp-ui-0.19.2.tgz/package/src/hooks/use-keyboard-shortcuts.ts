"use client";
import * as React from "react";

/**
 * A single global keyboard shortcut. `keys` is the human display string also
 * shown in the footer (e.g. "⌘K", "Ctrl+K", "G then H"); the handler parses it:
 *   - "<mod>K" (⌘/Ctrl + K)  → treated as the global-search shortcut (focuses the
 *     top-bar search input) unless an explicit `action`/`href` is given.
 *   - "X then Y" or "X Y"     → a two-key sequence (both forms accepted — the
 *     manifest emits "G H", the footer may display "G then H"); fires `href`
 *     navigation.
 *   - a single letter/key     → fires `href` navigation.
 */
export interface KeyboardShortcut {
  keys: string;
  /** Navigate here when the shortcut fires (sequence / single-key shortcuts). */
  href?: string;
  /** Force a behaviour regardless of `keys` parsing. */
  action?: "search" | "navigate";
}

interface UseKeyboardShortcutsOptions {
  /** Called with an href to navigate (pass router.push). */
  onNavigate?: (href: string) => void;
  /** Override how the search shortcut is satisfied. Default: focus the first
   *  input inside the page <header> (the top-bar global search). */
  onSearch?: () => void;
}

function isEditableTarget(t: EventTarget | null): boolean {
  const el = t as HTMLElement | null;
  if (!el) return false;
  const tag = el.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable;
}

function defaultFocusSearch() {
  if (typeof document === "undefined") return;
  const input = document.querySelector<HTMLElement>(
    'header input, header [role="searchbox"], header [aria-label*="search" i]',
  );
  if (input) {
    input.focus();
    if (input instanceof HTMLInputElement) input.select();
  }
}

interface ParsedShortcut {
  kind: "search" | "sequence" | "single";
  first?: string;
  second?: string;
  key?: string;
  href?: string;
}

function parse(s: KeyboardShortcut): ParsedShortcut {
  const raw = s.keys.trim();
  const isMod = /[⌘]|ctrl|cmd|meta/i.test(raw);
  const bare = raw.replace(/[⌘⌥⇧^]|ctrl\+?|cmd\+?|meta\+?|alt\+?|shift\+?/gi, "").trim();
  if (s.action === "search" || (isMod && /^k$/i.test(bare))) {
    return { kind: "search" };
  }
  // Two-key sequences: the display string is either the explicit "X then Y"
  // form, or two bare single-character keys separated by whitespace (e.g. the
  // manifest-emitted "G H") — both parse to the same sequence match.
  const thenSeq = raw.split(/\s+then\s+/i);
  const bareSeq = bare.split(/\s+/).filter(Boolean);
  if (thenSeq.length === 2) {
    return { kind: "sequence", first: thenSeq[0]!.trim().toLowerCase(), second: thenSeq[1]!.trim().toLowerCase(), ...(s.href ? { href: s.href } : {}) };
  }
  if (!isMod && bareSeq.length === 2 && bareSeq.every((k) => k.length === 1)) {
    return { kind: "sequence", first: bareSeq[0]!.toLowerCase(), second: bareSeq[1]!.toLowerCase(), ...(s.href ? { href: s.href } : {}) };
  }
  return { kind: "single", key: bare.toLowerCase(), ...(s.href ? { href: s.href } : {}) };
}

/**
 * Installs a global keydown handler for the given shortcuts. Sequence shortcuts
 * ("G then H") require the two keys within ~1s and are ignored while typing in a
 * field. Mounted once (e.g. by the app footer) so every page inherits them.
 */
export function useKeyboardShortcuts(
  shortcuts: KeyboardShortcut[] | undefined,
  { onNavigate, onSearch }: UseKeyboardShortcutsOptions = {},
): void {
  const parsed = React.useMemo(() => (shortcuts ?? []).map(parse), [shortcuts]);
  const pendingRef = React.useRef<{ key: string; at: number } | null>(null);

  React.useEffect(() => {
    if (parsed.length === 0) return;
    function onKeyDown(e: KeyboardEvent) {
      const mod = e.metaKey || e.ctrlKey;

      // Search shortcut (⌘/Ctrl+K) works even from within a field.
      if (mod && e.key.toLowerCase() === "k" && parsed.some((p) => p.kind === "search")) {
        e.preventDefault();
        (onSearch ?? defaultFocusSearch)();
        return;
      }

      if (isEditableTarget(e.target) || mod || e.altKey) return;
      const key = e.key.toLowerCase();

      // Continue a pending sequence (e.g. "g" already pressed → now "h").
      const pending = pendingRef.current;
      if (pending && Date.now() - pending.at < 1000) {
        const match = parsed.find(
          (p) => p.kind === "sequence" && p.first === pending.key && p.second === key,
        );
        pendingRef.current = null;
        if (match?.href) {
          e.preventDefault();
          onNavigate?.(match.href);
          return;
        }
      }

      // Single-key shortcut.
      const single = parsed.find((p) => p.kind === "single" && p.key === key);
      if (single?.href) {
        e.preventDefault();
        onNavigate?.(single.href);
        return;
      }

      // Start a sequence if this key is a known first key.
      if (parsed.some((p) => p.kind === "sequence" && p.first === key)) {
        pendingRef.current = { key, at: Date.now() };
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [parsed, onNavigate, onSearch]);
}
