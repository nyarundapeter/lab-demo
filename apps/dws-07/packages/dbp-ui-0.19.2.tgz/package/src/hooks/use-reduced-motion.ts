import * as React from "react";

/**
 * Tracks the user's `prefers-reduced-motion` OS setting. Ported from the
 * STCB GRC solution's shared detail-drawer kit (WS-6.2) — used to disable
 * Sheet/Drawer open/close transitions for users who have reduced motion set.
 */
export function useReducedMotion(): boolean {
  const ref = React.useRef(false);
  const [, force] = React.useReducer((c: number) => c + 1, 0);
  React.useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mql = window.matchMedia("(prefers-reduced-motion: reduce)");
    ref.current = mql.matches;
    force();
    const handler = (e: MediaQueryListEvent) => {
      ref.current = e.matches;
      force();
    };
    mql.addEventListener("change", handler);
    return () => mql.removeEventListener("change", handler);
  }, []);
  return ref.current;
}
