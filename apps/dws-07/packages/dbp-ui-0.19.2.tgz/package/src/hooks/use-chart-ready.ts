import { useState, useEffect } from "react";

/**
 * SSR/hydration gate for chart libraries that measure their container on mount
 * (recharts' `ResponsiveContainer` in particular): rendering the chart on the
 * server, or on the very first client render, hands it a zero-size container
 * before layout has happened, which either throws or renders a collapsed
 * chart until the next resize. `useChartReady()` returns `false` until after
 * the first client-side effect has run, so callers can render a fixed-height
 * placeholder (matching the eventual chart's height, to avoid layout shift)
 * until it's safe to mount the real chart.
 *
 * Chart-library-agnostic — @dbp/ui does not depend on recharts. Pair it with
 * `minWidth={0}` on recharts' `ResponsiveContainer` so it doesn't refuse to
 * shrink below its default 200px minimum inside narrow layouts.
 *
 * @example
 * ```tsx
 * function MyChart({ data }: { data: Point[] }) {
 *   const ready = useChartReady();
 *   if (!ready) return <div style={{ height: 150 }} />;
 *   return (
 *     <ResponsiveContainer width="100%" height={150} minWidth={0}>
 *       <BarChart data={data}>...</BarChart>
 *     </ResponsiveContainer>
 *   );
 * }
 * ```
 *
 * DS-INTEGRATION(0.16.0): the Design System Finalisation stream's chart-atom
 * consolidation (StatTile, StatusBadge, chart atoms landing on their branch)
 * should adopt this hook as its SSR gate post-merge, instead of reintroducing
 * a local copy — see docs/plans/consumer-app-audit-2026-07-25/factory-improvement-plan.md
 * (WS-4.4/6).
 */
export function useChartReady(): boolean {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    setReady(true);
  }, []);
  return ready;
}
