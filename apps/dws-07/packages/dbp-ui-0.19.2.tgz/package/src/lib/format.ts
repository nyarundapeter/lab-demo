/**
 * Value formatting utilities for @dbp/ui.
 *
 * All functions are Intl-based and SSR-safe (no `window` or DOM access).
 * Default locale is "en" for consistent server/client output.
 */

const DEFAULT_LOCALE = "en";

// ─── Number ───────────────────────────────────────────────────────────────────

export interface FormatNumberOptions {
  /**
   * When true, abbreviates large numbers:
   *   1 000 → "1K", 1 000 000 → "1M", 1 000 000 000 → "1B".
   * Defaults to false.
   */
  compact?: boolean;
  /** Maximum fraction digits. Defaults to 2. */
  maximumFractionDigits?: number;
  /** Minimum fraction digits. Defaults to 0. */
  minimumFractionDigits?: number;
}

/**
 * Formats a numeric value as a locale-aware number string.
 *
 * @example
 * formatNumber(38000)              // "38,000"
 * formatNumber(38000, { compact: true }) // "38K"
 * formatNumber(1234.56)            // "1,234.56"
 */
export function formatNumber(value: number, options: FormatNumberOptions = {}): string {
  const { compact = false, maximumFractionDigits = 2, minimumFractionDigits = 0 } = options;
  return new Intl.NumberFormat(DEFAULT_LOCALE, {
    notation: compact ? "compact" : "standard",
    compactDisplay: "short",
    maximumFractionDigits: compact ? 1 : maximumFractionDigits,
    minimumFractionDigits: compact ? 0 : minimumFractionDigits,
  }).format(value);
}

// ─── Currency ─────────────────────────────────────────────────────────────────

export interface FormatCurrencyOptions {
  /**
   * When true, abbreviates large amounts:
   *   1 575 800 → "$1.6M".
   * Defaults to false.
   */
  compact?: boolean;
  /** Maximum fraction digits. Defaults to 0 for compact, 2 otherwise. */
  maximumFractionDigits?: number;
}

/**
 * Formats a numeric value as a locale-aware currency string.
 *
 * @example
 * formatCurrency(1575800)                     // "$1,575,800"
 * formatCurrency(1575800, 'USD', { compact: true }) // "$1.6M"
 * formatCurrency(99.9, 'GBP')                 // "£99.90"
 */
export function formatCurrency(
  value: number,
  currency = "USD",
  options: FormatCurrencyOptions = {},
): string {
  const { compact = false } = options;
  const maxFraction = options.maximumFractionDigits ?? (compact ? 1 : 0);
  return new Intl.NumberFormat(DEFAULT_LOCALE, {
    style: "currency",
    currency,
    notation: compact ? "compact" : "standard",
    compactDisplay: "short",
    maximumFractionDigits: maxFraction,
    minimumFractionDigits: compact ? 0 : maxFraction,
  }).format(value);
}

// ─── Percent ──────────────────────────────────────────────────────────────────

/**
 * Formats a decimal ratio (0–1) as a percentage string.
 *
 * @example
 * formatPercent(0.856)  // "85.6%"
 * formatPercent(1)      // "100%"
 */
export function formatPercent(value: number, maximumFractionDigits = 1): string {
  return new Intl.NumberFormat(DEFAULT_LOCALE, {
    style: "percent",
    maximumFractionDigits,
    minimumFractionDigits: 0,
  }).format(value);
}

// ─── Date ─────────────────────────────────────────────────────────────────────

export type DateStyle = "short" | "medium" | "long" | "year-month" | "iso-date";

/**
 * Formats a Date (or ISO date string) using the given style preset.
 *
 * Styles:
 *   "short"      → "6/12/2026"  (M/D/YYYY)
 *   "medium"     → "Jun 12, 2026"
 *   "long"       → "June 12, 2026"
 *   "year-month" → "Jun 2026"
 *   "iso-date"   → "2026-06-12"
 *
 * @example
 * formatDate("2026-01-15", "medium") // "Jan 15, 2026"
 * formatDate(new Date(), "short")    // "6/12/2026"
 */
export function formatDate(value: Date | string | number, style: DateStyle = "medium"): string {
  const date = value instanceof Date ? value : new Date(value);
  if (isNaN(date.getTime())) return String(value);

  if (style === "iso-date") {
    // YYYY-MM-DD in UTC to avoid timezone shift on date-only values
    return date.toISOString().slice(0, 10);
  }

  if (style === "year-month") {
    return new Intl.DateTimeFormat(DEFAULT_LOCALE, {
      year: "numeric",
      month: "short",
      timeZone: "UTC",
    }).format(date);
  }

  const formatMap: Record<Exclude<DateStyle, "iso-date" | "year-month">, Intl.DateTimeFormatOptions> = {
    short: { month: "numeric", day: "numeric", year: "numeric", timeZone: "UTC" },
    medium: { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" },
    long: { month: "long", day: "numeric", year: "numeric", timeZone: "UTC" },
  };

  return new Intl.DateTimeFormat(DEFAULT_LOCALE, formatMap[style]).format(date);
}

// ─── Relative Time ────────────────────────────────────────────────────────────

/**
 * Formats a Date (or ISO date string) as a relative time string.
 *
 * @example
 * formatRelativeTime(new Date(Date.now() - 5 * 60 * 1000)) // "5 minutes ago"
 * formatRelativeTime(new Date(Date.now() + 2 * 86400 * 1000)) // "in 2 days"
 */
export function formatRelativeTime(value: Date | string | number): string {
  const date = value instanceof Date ? value : new Date(value);
  if (isNaN(date.getTime())) return String(value);

  const rtf = new Intl.RelativeTimeFormat(DEFAULT_LOCALE, { numeric: "auto" });
  const diffMs = date.getTime() - Date.now();
  const absDiffMs = Math.abs(diffMs);

  const MINUTE = 60 * 1000;
  const HOUR = 60 * MINUTE;
  const DAY = 24 * HOUR;
  const WEEK = 7 * DAY;
  const MONTH = 30 * DAY;
  const YEAR = 365 * DAY;

  if (absDiffMs < MINUTE) {
    return rtf.format(Math.round(diffMs / 1000), "second");
  } else if (absDiffMs < HOUR) {
    return rtf.format(Math.round(diffMs / MINUTE), "minute");
  } else if (absDiffMs < DAY) {
    return rtf.format(Math.round(diffMs / HOUR), "hour");
  } else if (absDiffMs < WEEK) {
    return rtf.format(Math.round(diffMs / DAY), "day");
  } else if (absDiffMs < MONTH) {
    return rtf.format(Math.round(diffMs / WEEK), "week");
  } else if (absDiffMs < YEAR) {
    return rtf.format(Math.round(diffMs / MONTH), "month");
  } else {
    return rtf.format(Math.round(diffMs / YEAR), "year");
  }
}

// ─── Compact relative time (e.g. "5m ago") ───────────────────────────────────

/** Formats an ISO timestamp as a compact relative string: "5s ago", "3m ago", "2h ago", "1d ago". */
export function relativeTimeCompact(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  const secs = Math.floor(diff / 1000);
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

// ─── Convenience: detect ISO date strings ────────────────────────────────────

/**
 * Returns true if the string looks like an ISO 8601 date (date-only or datetime).
 * Used by entity-list cell rendering to auto-format date fields.
 */
export function isIsoDateString(value: unknown): value is string {
  if (typeof value !== "string") return false;
  return /^\d{4}-\d{2}(-\d{2}(T[\d:.]+Z?)?)?$/.test(value);
}

/**
 * Returns true if the value looks like a year-month string (YYYY-MM).
 */
export function isYearMonthString(value: unknown): value is string {
  if (typeof value !== "string") return false;
  return /^\d{4}-\d{2}$/.test(value);
}
