/**
 * Password policy for the identity-onboarding organism family
 * (identity-core.jsx `PW_POLICY`). Single shared home for the 4-rule set —
 * previously duplicated verbatim across `accept-card` and `reset-request-form`
 * (`app-scaffolds/features/*\/lib/password-policy.ts`); both now import this.
 */

export interface PasswordPolicyItem {
  id: string;
  label: string;
  test: (value: string) => boolean;
}

export const PASSWORD_POLICY: PasswordPolicyItem[] = [
  { id: "len", label: "At least 12 characters", test: (v) => v.length >= 12 },
  { id: "case", label: "Upper and lower case letters", test: (v) => /[a-z]/.test(v) && /[A-Z]/.test(v) },
  { id: "num", label: "A number", test: (v) => /[0-9]/.test(v) },
  { id: "sym", label: "A symbol (!@#$…)", test: (v) => /[^A-Za-z0-9]/.test(v) },
];

export function passwordScore(value: string): 0 | 1 | 2 | 3 | 4 {
  return PASSWORD_POLICY.reduce<number>((n, p) => n + (p.test(value) ? 1 : 0), 0) as 0 | 1 | 2 | 3 | 4;
}

export function passwordPolicyItems(value: string): { label: string; met: boolean }[] {
  return PASSWORD_POLICY.map((p) => ({ label: p.label, met: !!value && p.test(value) }));
}
