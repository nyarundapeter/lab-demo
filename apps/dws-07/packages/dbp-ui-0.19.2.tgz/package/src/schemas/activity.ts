import { z } from "zod";

/**
 * Event model for the ActivityTimeline / ActivityComposer molecules
 * (activity-timeline-spec-2026-07-10.md §7). Zod is the source of truth —
 * component prop types derive from these via `z.infer`, never hand-authored.
 */

/** Tone vocabulary shared with Badge/Alert — design-token driven, never hex. */
export const ActivityToneSchema = z.enum(["neutral", "success", "warning", "danger", "info"]);
export type ActivityTone = z.infer<typeof ActivityToneSchema>;

/** Curated lucide-react icon keys a builder may reference from `activityTypes[type].icon`. */
export const ActivityIconNameSchema = z.enum(["mail", "phone", "note", "calendar", "arrowRight"]);
export type ActivityIconName = z.infer<typeof ActivityIconNameSchema>;

export const ActivityTypeConfigSchema = z.object({
  icon: ActivityIconNameSchema,
  tone: ActivityToneSchema,
  label: z.string(),
});
export type ActivityTypeConfig = z.infer<typeof ActivityTypeConfigSchema>;

export const ActivityAttachmentSchema = z.object({
  id: z.string(),
  name: z.string(),
  sizeKb: z.number().nonnegative(),
});
export type ActivityAttachment = z.infer<typeof ActivityAttachmentSchema>;

/**
 * A single rendered timeline entry. `bodyText` is the note's derived plain text
 * (`ActivityDraft.plainText`) — the timeline renders plain text; rich-body read-only
 * rendering is a follow-up, out of scope for this lane.
 */
export const ActivityEntrySchema = z.object({
  id: z.string(),
  type: z.string(),
  actorName: z.string(),
  /** ISO 8601 timestamp — formatted locale-aware at render time, never a preformatted string. */
  timestamp: z.string(),
  bodyText: z.string(),
  tags: z.array(z.string()).optional(),
  attachments: z.array(ActivityAttachmentSchema).optional(),
});
export type ActivityEntry = z.infer<typeof ActivityEntrySchema>;

export const ActivityDataStateSchema = z.enum(["loading", "empty", "error", "populated"]);
export type ActivityDataState = z.infer<typeof ActivityDataStateSchema>;

/** Candidate fed to the composer's `@mention` picker. */
export const ActivityMentionUserSchema = z.object({
  id: z.string(),
  name: z.string(),
});
export type ActivityMentionUser = z.infer<typeof ActivityMentionUserSchema>;

/** Builder-authored config — the factory-ization contract (spec §2/§7). */
export const ActivityTimelineConfigSchema = z.object({
  entityType: z.string().optional(),
  activityTypes: z.record(z.string(), ActivityTypeConfigSchema),
  /** Config-gated: unlocks the `@mention` picker in the composer. */
  mentions: z.boolean().default(false),
  /** Config-gated: unlocks tag entry on the composer and the tag filter row on the timeline. */
  tags: z.boolean().default(false),
  /**
   * Config-gated: shows the attachment affordance. Per spec §7 this lane ships a stub
   * (disabled affordance + `onAttachFiles` prop seam) — real upload lands with `@dbp/ps-storage`.
   */
  attachments: z.boolean().default(false),
  labels: z.record(z.string(), z.string()).optional(),
});
export type ActivityTimelineConfig = z.infer<typeof ActivityTimelineConfigSchema>;

/**
 * Draft payload the composer hands back on Save (ADR-0048: Tiptap rich text).
 * `body` is the Tiptap document serialized as JSON; `plainText` is derived via
 * `editor.getText()` for search/preview/notifications (spec §6.1). `mentionedUserIds`
 * lists the `@mention` node ids present in `body` so the host can notify them (spec §6.2).
 */
export const ActivityDraftSchema = z.object({
  body: z.string(),
  plainText: z.string(),
  tags: z.array(z.string()),
  mentionedUserIds: z.array(z.string()).default([]),
});
export type ActivityDraft = z.infer<typeof ActivityDraftSchema>;
