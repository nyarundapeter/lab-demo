import * as React from "react";
import { ChevronDown, Check } from "lucide-react";
import { AppTopBar } from "./app-top-bar.js";
import { Avatar } from "./avatar.js";
import { Breadcrumb, type BreadcrumbItem } from "./breadcrumb.js";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "./dropdown-menu.js";
import { useBreadcrumb } from "../context/breadcrumb-context.js";
import type { TopBarConfig } from "@dbp/contracts";

/**
 * AppChromeSession — the authenticated identity the top bar renders from.
 *
 * Structurally identical to PS.AUTH's `SessionIdentity` (see
 * @dbp/ps-auth/client). It is re-declared here, rather than imported, so that
 * @dbp/ui never takes a hard dependency on @dbp/ps-auth: the session is *passed
 * in* by the app page (which already calls `useSessionIdentity()`), keeping the
 * layer split clean. The avatar/role/tenant on the bar are ALWAYS derived from
 * this object — never hardcoded.
 */
export interface AppChromeSession {
  userId: string;
  email: string;
  /** Display name for the avatar lockup. */
  displayName: string;
  /** Humanised primary role for the avatar sub-label. */
  primaryRole: string;
  /** All roles in the active tenant — feeds the optional role switcher. */
  roles: ReadonlyArray<string>;
  /** Active tenant id (config-driven via IAM). */
  tenantId: string;
}

export interface AppChromeProps {
  /** Solution code shown bold in the lockup (e.g. "DIA.02"). From the manifest. */
  productCode: string;
  /** Product name shown muted after the code (e.g. "AnalyticsOps"). From the manifest. */
  productName?: string;
  /** Logo image URL shown left of the product code lockup. */
  logoSrc?: string;
  /** Alt text for the logo image. Defaults to productCode. */
  logoAlt?: string;
  /**
   * Breadcrumb trail, rendered in the top bar immediately after the sidebar
   * toggle (Amendment D-2, component-architecture-standard.md §7b: the app
   * identity lockup lives in the sidebar header, not the top bar — see
   * SidebarIdentity). Pages using this shell should not render a page-level
   * PageHeader title; the breadcrumb's terminal crumb is the page identity.
   */
  breadcrumb?: BreadcrumbItem[];
  /** The active authenticated identity, or null while loading / unauthenticated. */
  session: AppChromeSession | null;
  /**
   * Pre-built global-search element (e.g. `<SearchBar/>` from
   * `@dbp/organisms/search-bar`), rendered only when provided — presence IS
   * the capability flag. `@dbp/ui` never imports the search organism itself
   * (it fetches from PS.SEARCH, which is an organism-tier concern per the
   * Layer 06/07 boundary); the caller (typically a generated `SolutionChrome`
   * wrapper) constructs it and passes the whole element in. AppChrome only
   * owns the responsive collapse/expand chrome around it.
   */
  search?: React.ReactNode;
  /**
   * Pre-built notifications element (e.g. `<NotificationBell/>` from
   * `@dbp/organisms/notification-bell`), rendered only when provided — same
   * organism-boundary reasoning as `search`.
   */
  notifications?: React.ReactNode;
  /** Called when the active role changes (only used when the session has 2+ roles). */
  onRoleChange?: (role: string) => void;
  /** Called when the settings affordance is activated. Omit ⇒ inert default. */
  onSettings?: () => void;
  /** Suppress the role-switcher even when the session carries 2+ roles. */
  hideRoleSwitcher?: boolean;
  /** Suppress the settings affordance even when onSettings is provided. */
  hideSettings?: boolean;
  /** Lockup variant. Defaults to light. */
  variant?: "light" | "dark";
  className?: string;
}

/**
 * AppChrome — the ONE connected top-bar composition inherited by every app.
 *
 * Renders the DQ-prototype-standard {@link AppTopBar}, fully config + session
 * driven:
 *   • product lockup  ← manifest `productCode` / `productName`
 *   • global search   ← the `search` slot (caller-supplied `SearchBar`
 *                       organism element), rendered only when provided. Uses
 *                       the bar's built-in ⌘K pill when absent.
 *   • notifications   ← the `notifications` slot (caller-supplied
 *                       `NotificationBell` organism element), rendered only
 *                       when provided.
 *   • settings        ← always present (icon button).
 *   • user chip       ← avatar + name/role from `session`. Doubles as the role
 *                       switcher (N33 ruling): a clickable popover when the
 *                       session carries 2+ roles, a static chip otherwise.
 *                       Nothing while the session is loading / unauthenticated.
 *
 * Nothing is hardcoded: the same component drives all four apps and any future
 * clone. `@dbp/ui` stays free of any Layer-06-fetching organism import — the
 * `search`/`notifications` slots keep the Layer 06/07 boundary intact while
 * still letting a solution light up both affordances with zero layout code of
 * its own (only the organism import + element, per the `SolutionChrome`
 * pattern the generator emits). Tokens / dq-classes only, a11y from the
 * underlying bar + whatever's passed into the slots.
 */
export function AppChrome({
  productCode,
  productName,
  logoSrc,
  logoAlt,
  breadcrumb,
  session,
  search,
  notifications,
  onRoleChange,
  onSettings,
  hideRoleSwitcher = false,
  hideSettings = false,
  variant = "light",
  className,
}: AppChromeProps) {
  const showSearch = search !== undefined;
  const showNotifications = notifications !== undefined;
  const showUser = session !== null;
  const dark = variant === "dark";

  const config: TopBarConfig = {
    appName: productName ? `${productCode} / ${productName}` : productCode,
    logoAlt: logoAlt ?? productCode,
    ...(logoSrc !== undefined && { logoSrc }),
    actions: [],
    showSearch,
    showNotifications,
    showUser,
  };

  // ── Search slot (PS.SEARCH) ────────────────────────────────────────────
  // Below xl the pill has no room next to the switchers/avatar, so it
  // collapses to a 32px icon button that expands into the full input on
  // click/focus (reference pattern: search collapses to icon, expands on
  // focus). At xl+ there's room for the pill outright.
  const [searchExpanded, setSearchExpanded] = React.useState(false);
  const searchContainerRef = React.useRef<HTMLDivElement>(null);
  const handleSearchContainerBlur = React.useCallback(() => {
    window.setTimeout(() => {
      if (!searchContainerRef.current?.contains(document.activeElement)) {
        setSearchExpanded(false);
      }
    }, 150);
  }, []);
  const searchSlot = showSearch ? (
    <div
      ref={searchContainerRef}
      onBlur={handleSearchContainerBlur}
      className="relative flex items-center"
    >
      <div className="hidden xl:block xl:w-64">{search}</div>
      <div className="xl:hidden">
        {searchExpanded ? (
          <div className="absolute right-0 top-1/2 w-64 -translate-y-1/2 sm:w-72">{search}</div>
        ) : (
          <button
            type="button"
            onClick={() => setSearchExpanded(true)}
            aria-label="Open search"
            className={[
              "flex h-[var(--shell-control-h)] w-[var(--shell-control-h)] shrink-0 items-center justify-center rounded-button transition-colors",
              "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
              dark ? "text-white hover:bg-white/10" : "text-[var(--color-text-primary)] hover:bg-surface",
            ].join(" ")}
          >
            <SearchGlyph />
          </button>
        )}
      </div>
    </div>
  ) : undefined;

  // ── Notification slot (PS.NOTIF) ─────────────────────────────────────────
  const notificationSlot = showNotifications ? notifications : undefined;

  // ── Role switcher (optional — only with 2+ roles) ────────────────────────
  const roles = React.useMemo(() => session?.roles ?? [], [session?.roles]);
  const [activeRole, setActiveRole] = React.useState<string | undefined>(
    roles.length > 0 ? roles[0] : undefined,
  );
  React.useEffect(() => {
    if (roles.length > 0 && (activeRole === undefined || !roles.includes(activeRole))) {
      setActiveRole(roles[0]);
    }
  }, [roles, activeRole]);

  const handleRoleChange = React.useCallback(
    (role: string) => {
      setActiveRole(role);
      onRoleChange?.(role);
    },
    [onRoleChange],
  );

  // ── Settings affordance ──────────────────────────────────────────────────
  // The default AppTopBar settings button is inert; when an onSettings handler
  // is supplied we render a wired button in its place (same visual treatment).
  const settingsSlot = !hideSettings && onSettings ? (
    <button
      type="button"
      onClick={onSettings}
      aria-label="Settings"
      className={[
        "flex h-[var(--shell-control-h)] w-[var(--shell-control-h)] shrink-0 items-center justify-center rounded-button transition-colors",
        "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
        dark ? "text-white hover:bg-white/10" : "text-[var(--color-text-primary)] hover:bg-surface",
      ].join(" ")}
    >
      <SettingsGlyph />
    </button>
  ) : undefined;

  // ── User slot (PS.AUTH — avatar + role, doubles as the role switcher) ────
  // N33 ruling: the user chip IS the role switcher (reference: admin-shell.jsx
  // PersonaSwitcher). Multi-role sessions get a clickable chip that opens a
  // popover listing roles (current one checked); selecting calls onRoleChange
  // via the same activeRole state the old top-bar Select used. Single-role /
  // no-role sessions render the identical chip as a static, non-interactive block.
  const activeRoleLabel =
    roles.length > 0 ? humanise(activeRole ?? session?.primaryRole ?? "") : "No roles in this workspace";
  const canSwitchRole = !hideRoleSwitcher && roles.length > 1;

  const chipContent = session ? (
    <>
      <Avatar name={session.displayName || session.email} size="sm" />
      <span className="hidden min-w-0 flex-col items-start lg:flex">
        <span
          className={["max-w-36 truncate text-xs font-bold", dark ? "text-white" : "text-[var(--color-text-primary)]"].join(" ")}
        >
          {session.displayName || session.email}
        </span>
        <span
          className={[
            "max-w-36 truncate text-xs",
            dark ? "text-[var(--color-navy-200)]" : "text-[var(--color-text-muted)]",
          ].join(" ")}
        >
          {activeRoleLabel}
        </span>
      </span>
    </>
  ) : null;

  const userSlot = session ? (
    canSwitchRole ? (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            aria-label="Switch role"
            className={[
              "flex items-center gap-2.5 border-l pl-3 transition-colors",
              dark ? "border-white/15 hover:bg-white/10" : "border-[var(--color-border-subtle)] hover:bg-surface",
            ].join(" ")}
          >
            {chipContent}
            <ChevronDown
              size={14}
              strokeWidth={1.5}
              aria-hidden="true"
              className={dark ? "shrink-0 text-white/60" : "shrink-0 text-[var(--color-text-muted)]"}
            />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          {roles.map((r) => (
            <DropdownMenuItem key={r} onSelect={() => handleRoleChange(r)}>
              <span className="min-w-0 flex-1 truncate">{humanise(r)}</span>
              {r === activeRole && <Check size={14} strokeWidth={1.5} className="ml-2 shrink-0" aria-hidden="true" />}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    ) : (
      <div
        className={[
          "flex items-center gap-2.5 border-l pl-3",
          dark ? "border-white/15" : "border-[var(--color-border-subtle)]",
        ].join(" ")}
      >
        {chipContent}
      </div>
    )
  ) : undefined;

  // N36: a detail page may override the terminal crumb with the loaded
  // record's display name (useBreadcrumbOverride), so e.g.
  // "Marketplace / Catalogue / Design" becomes "… / <offering name>" once the
  // record resolves. The static trail renders unchanged while loading.
  const { dynamicLabel } = useBreadcrumb();
  const resolvedBreadcrumb =
    breadcrumb && breadcrumb.length > 0 && dynamicLabel
      ? [...breadcrumb.slice(0, -1), { label: dynamicLabel }]
      : breadcrumb;

  const breadcrumbSlot =
    resolvedBreadcrumb && resolvedBreadcrumb.length > 0 ? (
      <Breadcrumb items={resolvedBreadcrumb} nowrap {...(dark && { className: "text-white/70" })} />
    ) : undefined;

  return (
    <AppTopBar
      config={config}
      productCode={productCode}
      {...(productName !== undefined && { productName })}
      variant={variant}
      {...(className !== undefined && { className })}
      breadcrumbSlot={breadcrumbSlot}
      searchSlot={searchSlot}
      notificationSlot={notificationSlot}
      settingsSlot={settingsSlot}
      userSlot={userSlot}
    />
  );
}

/** Local humaniser (mirror of PS.AUTH's humaniseRole) so @dbp/ui stays auth-free. */
function humanise(role: string): string {
  return role
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

/** Inline magnifier glyph (lucide Search at stroke 1.5) for the collapsed search icon button. */
function SearchGlyph() {
  return (
    <svg
      width={17}
      height={17}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
}


/** Inline settings glyph (lucide Settings at stroke 1.5). */
function SettingsGlyph() {
  return (
    <svg
      width={17}
      height={17}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}
