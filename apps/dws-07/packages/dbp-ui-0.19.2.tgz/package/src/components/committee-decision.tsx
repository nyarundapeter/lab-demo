import * as React from "react"
import { Users, Scale } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Avatar } from "./avatar.js"
import { Badge } from "./badge.js"

/**
 * CommitteeDecision — Wave 3 Family 3 molecule (no registry id, flat @dbp/ui component). Reference: wf-approval.jsx
 * `CommitteeDecision` — a committee decision is not a simple approve/reject:
 * quorum, per-member votes, abstentions and a chair-recorded outcome are all
 * first-class. Genuinely new — no existing component renders a vote grid.
 */
export type CommitteeVote = "approve" | "reject" | "abstain" | "pending"

export interface CommitteeMemberVote {
  id: string
  name: string
  vote: CommitteeVote
  /** e.g. "Chair" */
  tag?: string | undefined
}

export interface CommitteeDecisionProps {
  title: string
  subtitle: string
  members: CommitteeMemberVote[]
  /** e.g. "4/5" — required quorum vs total members. */
  quorum: string
  quorumMet: boolean
  /** e.g. "Decision recorded by Chair after quorum". */
  outcomeNote?: string | undefined
  className?: string
}

const VOTE_LABEL: Record<CommitteeVote, string> = {
  approve: "For",
  reject: "Against",
  abstain: "Abstain",
  pending: "Not voted",
}

const VOTE_COLOR_CLASS: Record<CommitteeVote, string> = {
  approve: "text-[var(--color-success)]",
  reject: "text-[var(--color-danger)]",
  abstain: "text-[var(--color-text-muted)]",
  pending: "text-[var(--color-text-muted)]",
}

export function CommitteeDecision({
  title,
  subtitle,
  members,
  quorum,
  quorumMet,
  outcomeNote,
  className,
}: CommitteeDecisionProps) {
  const forCount = members.filter((m) => m.vote === "approve").length
  const againstCount = members.filter((m) => m.vote === "reject").length
  const abstainCount = members.filter((m) => m.vote === "abstain").length

  return (
    <div
      className={cn("rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] p-4", className)}
      data-testid="committee-decision"
    >
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <div className="text-sm font-semibold text-[var(--color-text-primary)]">{title}</div>
          <div className="text-xs text-[var(--color-text-muted)]">{subtitle}</div>
        </div>
        <Badge tone={quorumMet ? "success" : "warning"} size="sm">
          <Users size={11} aria-hidden="true" />
          Quorum {quorum}
        </Badge>
      </div>

      <div className="mb-3.5 grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-2">
        {members.map((m) => (
          <div
            key={m.id}
            className="flex items-center gap-2 rounded-[var(--radius-card)] border border-[var(--color-border-default)] p-2"
            data-testid="committee-member-vote"
            data-vote={m.vote}
          >
            <Avatar name={m.name} size="sm" />
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-medium text-[var(--color-text-primary)]">
                {m.name.split(" ")[0]}
                {m.tag && <span className="text-xs text-[var(--color-text-muted)]"> · {m.tag}</span>}
              </div>
              <span className={cn("text-xs", VOTE_COLOR_CLASS[m.vote])}>{VOTE_LABEL[m.vote]}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Badge tone="gray" size="sm">
          <Scale size={11} aria-hidden="true" />
          {forCount} for · {againstCount} against · {abstainCount} abstain
        </Badge>
        {outcomeNote && <span className="text-xs text-[var(--color-text-muted)]">{outcomeNote}</span>}
      </div>
    </div>
  )
}
