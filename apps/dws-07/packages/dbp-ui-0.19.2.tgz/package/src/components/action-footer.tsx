import * as React from "react"
import { cn } from "../lib/cn.js"
import { Button } from "./button.js"
import { SaveStatus } from "./save-status.js"
import type { SaveStatusState } from "./save-status.js"

export interface ActionFooterAction {
  label: string
  onClick: () => void
  disabled?: boolean
  loading?: boolean
}

export interface ActionFooterProps {
  primary?: ActionFooterAction
  secondary?: ActionFooterAction
  tertiary?: ActionFooterAction
  destructive?: ActionFooterAction
  /** Renders a `SaveStatus` indicator to the left of the actions. Omit to hide it entirely. */
  saveStatus?: SaveStatusState
  savedAt?: string
  /** Sticks the footer to the bottom of its scroll container with a top border + surface background. Defaults false. */
  sticky?: boolean
  className?: string
}

/**
 * ActionFooter — the enterprise form footer bar (forms-blocks.jsx:123-141):
 * up to 4 actions (destructive/tertiary/secondary/primary) plus an optional
 * `SaveStatus` indicator. Only one concrete impl existed before this build,
 * inlined in `multi-step-form/index.tsx:307-346` (a wizard-specific
 * "Save & exit / Previous / Continue" shape) — this is a fresh, generic
 * component design, not an extraction of that call site; the wizard keeps
 * its own footer unchanged.
 */
function ActionFooter({
  primary,
  secondary,
  tertiary,
  destructive,
  saveStatus,
  savedAt,
  sticky = false,
  className,
}: ActionFooterProps) {
  return (
    <div
      className={cn(
        "flex items-center gap-4",
        sticky && "sticky bottom-0 border-t border-[var(--color-border)] bg-[var(--color-surface)] px-1 py-3",
        className,
      )}
    >
      {destructive && (
        <Button
          type="button"
          variant="ghost"
          className="text-[var(--color-danger-text)] hover:text-[var(--color-danger-text)]"
          onClick={destructive.onClick}
          disabled={destructive.disabled}
        >
          {destructive.label}
        </Button>
      )}

      {saveStatus && <SaveStatus status={saveStatus} {...(savedAt ? { savedAt } : {})} />}

      <div className="flex-1" />

      {tertiary && (
        <Button type="button" variant="ghost" size="sm" onClick={tertiary.onClick} disabled={tertiary.disabled}>
          {tertiary.label}
        </Button>
      )}
      {secondary && (
        <Button type="button" variant="outline" size="sm" onClick={secondary.onClick} disabled={secondary.disabled}>
          {secondary.label}
        </Button>
      )}
      {primary && (
        <Button
          type="button"
          variant="navy"
          size="sm"
          loading={primary.loading ?? false}
          disabled={primary.disabled}
          onClick={primary.onClick}
        >
          {primary.label}
        </Button>
      )}
    </div>
  )
}

export { ActionFooter }
