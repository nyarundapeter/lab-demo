import * as React from "react"
import type { LucideProps } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Card } from "./card.js"

export type InfoCardTone = "neutral" | "success" | "warning" | "danger" | "info"

const TONE: Record<InfoCardTone, { surface: string; text: string }> = {
  neutral: { surface: "var(--color-neutral-surface)", text: "var(--color-neutral-text)" },
  success: { surface: "var(--color-success-surface)", text: "var(--color-success-text)" },
  warning: { surface: "var(--color-warning-surface)", text: "var(--color-warning-text)" },
  danger: { surface: "var(--color-danger-surface)", text: "var(--color-danger-text)" },
  info: { surface: "var(--color-info-surface)", text: "var(--color-info-text)" },
}

export interface InfoCardRow {
  label: string
  value: React.ReactNode
}

export interface InfoCardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "title"> {
  /** @default "neutral" */
  tone?: InfoCardTone
  icon?: React.FC<LucideProps>
  title: React.ReactNode
  /** Rendered flush-right of the title, e.g. a severity badge. */
  badge?: React.ReactNode
  /** 2-column key/value grid rendered above `children`. */
  rows?: InfoCardRow[]
  children?: React.ReactNode
  /** Footer action row, separated by a top border. */
  actions?: React.ReactNode
}

/**
 * Toned card base for Escalation/Dependency/Exception cards (wf-status.jsx:
 * 236-250) — toned header (icon+title+badge), optional key/value row grid,
 * body, and an optional footer action row.
 */
function InfoCard({ tone = "neutral", icon: Icon, title, badge, rows, children, actions, className, style, ...rest }: InfoCardProps) {
  const token = TONE[tone]

  return (
    <Card
      className={cn("overflow-hidden shadow-none", className)}
      style={{ borderColor: `color-mix(in srgb, ${token.text} 35%, transparent)`, ...style }}
      {...rest}
    >
      <div
        className="flex items-center gap-2 border-b px-3.5 py-2.5"
        style={{
          background: token.surface,
          borderBottomColor: `color-mix(in srgb, ${token.text} 20%, transparent)`,
        }}
      >
        {Icon && <Icon size={15} strokeWidth={2} aria-hidden="true" style={{ color: token.text }} />}
        <h3 className="text-sm font-semibold" style={{ color: token.text }}>
          {title}
        </h3>
        {badge && <div className="ml-auto">{badge}</div>}
      </div>
      <div className="p-3.5">
        {rows && rows.length > 0 && (
          <div
            className={cn("grid grid-cols-2 gap-x-4 gap-y-3", (children || actions) && "mb-3.5")}
          >
            {rows.map((r, i) => (
              <div key={i}>
                <dt className="text-xs text-[var(--color-text-muted)]">{r.label}</dt>
                <dd className="mt-0.5 text-sm text-[var(--color-text)]">{r.value}</dd>
              </div>
            ))}
          </div>
        )}
        {children}
        {actions && (
          <div className="mt-3.5 flex items-center gap-2 border-t border-[var(--color-border-subtle)] pt-3.5">
            {actions}
          </div>
        )}
      </div>
    </Card>
  )
}

export { InfoCard }
