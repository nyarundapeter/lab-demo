import * as React from "react"
import { Megaphone, X } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Button } from "./button.js"

/**
 * AnnouncementBanner — collaboration-system/forums.jsx `AnnouncementBanner`.
 * Molecule: fully prop-driven, no owned fetch/state.
 *
 * **Not wired anywhere yet** — the app shell (`AppChrome`) has no banner slot
 * to mount this into (Wave 3 Family 4f, "Blocked-row build policy" Amendment
 * A). Built here against a typed prop interface so the eventual shell slot is
 * a drop-in mount, not a rewrite. See this package's Storybook docs page for
 * the full service-readiness declaration.
 *
 * **Dedup note (Wave 1.C, `docs/plans/design-system-dedup-2026-07-25/
 * strategy.md` §3):** NOT re-implemented over `Alert`. `Alert`'s API is a
 * single title + body + optional single dismiss — it has no slot for a
 * pill-badge next to the title, a CTA-row with two buttons (primary +
 * "don't show again"), or the brand-gradient fill (`Alert variant="solid"`
 * only offers a flat `--color-*` background, not a gradient). Forcing this
 * layout through `Alert` would mean passing the whole row as `children` and
 * fighting the component's own icon/title/dismiss slots. Since this
 * component is unmounted anywhere in the app (confirmed above), the
 * accepted approach is: keep the hand-rolled layout, but this pass does NOT
 * touch its visuals — the brand-gradient fill was already deliberate (not a
 * token-drift bug) and every color already routes through `--color-primary`/
 * `white` role tokens, so there is no token-hygiene delta to fix here.
 */
export interface AnnouncementBannerProps {
  title: string
  body: string
  ctaLabel?: string
  onCtaClick?: () => void
  onDismiss?: () => void
  onDontShowAgain?: () => void
  className?: string
}

export function AnnouncementBanner({
  title,
  body,
  ctaLabel,
  onCtaClick,
  onDismiss,
  onDontShowAgain,
  className,
}: AnnouncementBannerProps) {
  return (
    <div
      role="status"
      data-testid="announcement-banner"
      className={cn(
        "flex items-start gap-3 rounded-[var(--radius-card)] p-3.5 text-white shadow-[var(--shadow-md)]",
        "bg-[linear-gradient(var(--color-primary),color-mix(in_srgb,var(--color-primary)_85%,black))]",
        className,
      )}
    >
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-white/15">
        <Megaphone size={17} aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold">{title}</span>
          <span className="rounded-pill bg-white/16 px-2 py-0.5 text-xs font-semibold">Announcement</span>
        </div>
        <p className="mt-0.5 max-w-[640px] text-xs text-white/85">{body}</p>
        <div className="mt-2.5 flex gap-2">
          {ctaLabel && (
            <Button
              type="button"
              size="sm"
              className="h-7 bg-[var(--color-surface-content)] text-[var(--color-text-primary)] hover:opacity-90"
              onClick={onCtaClick}
            >
              {ctaLabel}
            </Button>
          )}
          {onDontShowAgain && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-7 text-white/85 hover:bg-white/10 hover:text-white"
              onClick={onDontShowAgain}
            >
              Don&apos;t show again
            </Button>
          )}
        </div>
      </div>
      {onDismiss && (
        <button
          type="button"
          aria-label="Dismiss"
          title="Dismiss"
          onClick={onDismiss}
          className="shrink-0 rounded-[6px] p-1 text-white/80 transition-colors hover:text-white"
        >
          <X size={16} aria-hidden="true" />
        </button>
      )}
    </div>
  )
}
