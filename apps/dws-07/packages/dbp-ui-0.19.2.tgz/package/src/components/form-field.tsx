import * as React from "react"
import { AlertTriangle, CheckCircle } from "lucide-react"
import { FieldLabel } from "./input.js"
import { cn } from "../lib/cn.js"

/* Message icon per state — text + icon, never color alone (WCAG). Matches
 * the form-system design reference: triangle for error/warning, check for
 * success. */
function StateIcon({ state }: { state: "error" | "warning" | "success" }) {
  const className = "mt-0.5 h-3.5 w-3.5 shrink-0"
  if (state === "success") return <CheckCircle className={cn(className, "text-success")} aria-hidden="true" />
  return (
    <AlertTriangle
      className={cn(className, state === "error" ? "text-danger" : "text-warning")}
      aria-hidden="true"
    />
  )
}

/* ─── FormField ────────────────────────────────────────────────────────────
 * Composes FieldLabel + control slot + HelperText + ErrorMessage.
 * Automatically threads htmlFor/id/aria-describedby using React.useId.
 * ─────────────────────────────────────────────────────────────────────── */

export interface FormFieldProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Label text shown above the control */
  label?: string
  /** Override the generated id (also sets htmlFor on the label) */
  id?: string
  /** Helper text shown below the control when no error is present */
  helperText?: string
  /** Error message — shows instead of helperText, marks the control as invalid */
  error?: string
  /**
   * Warning/success validation message — shown instead of helperText when
   * `state` is `"warning"` or `"success"` and no `error` is set. `error`
   * always wins. Pixel-matched to the form-system design reference
   * (FG2, 2026-07-17): amber/green border + icon + message text.
   */
  message?: string
  /**
   * Whether the field is required — adds a visible asterisk (`aria-hidden`)
   * plus a screen-reader-only "(required)" suffix (Sharavi ruling 2026-07-12,
   * NN/g convention).
   */
  required?: boolean
  /**
   * Explicit "(optional)" label suffix — the other half of the same ruling.
   * Every field should set exactly one of `required`/`optional`; callers
   * (e.g. `FieldRenderer`) set this for every non-required field so no field
   * is left unmarked.
   */
  optional?: boolean
  /**
   * Validation-state seam. `error` (string) always wins and resolves to
   * `"error"` regardless of this prop. `"warning"`/`"success"` render with
   * amber/green border + icon + message (FG2 ruling, 2026-07-17). Threaded
   * onto the control child as `state` and exposed as `data-field-state` on
   * the wrapper.
   */
  state?: "default" | "error" | "warning" | "success"
}

export function FormField({
  label,
  id: externalId,
  helperText,
  error,
  message,
  required,
  optional,
  state,
  className,
  children,
  ...rest
}: FormFieldProps) {
  const autoId = React.useId()
  const fieldId = externalId ?? autoId
  const descId = `${fieldId}-desc`
  const resolvedState = error ? "error" : (state ?? "default")
  const displayMessage = error ?? (resolvedState !== "default" ? message : undefined)
  const hasDesc = Boolean(displayMessage ?? helperText)

  /* Clone the first React element child to inject id + aria-describedby */
  const control = React.Children.map(children, (child, i) => {
    if (i === 0 && React.isValidElement(child)) {
      return React.cloneElement(child as React.ReactElement<Record<string, unknown>>, {
        id: fieldId,
        "aria-describedby": hasDesc ? descId : undefined,
        "aria-invalid": error ? "true" : undefined,
        "aria-required": required ? "true" : undefined,
        state: resolvedState,
      })
    }
    return child
  })

  return (
    <div className={cn("flex flex-col gap-[var(--form-label-gap)]", className)} data-field-state={resolvedState} {...rest}>
      {label && (
        <FieldLabel htmlFor={fieldId}>
          {label}
          {required && (
            <>
              <span className="ml-0.5 text-[var(--color-danger)]" aria-hidden="true">
                *
              </span>
              <span className="sr-only">(required)</span>
            </>
          )}
          {optional && !required && (
            <span className="ml-1 normal-case text-xs font-normal tracking-normal text-[var(--color-text-muted)]">
              (optional)
            </span>
          )}
        </FieldLabel>
      )}

      {control}

      {displayMessage ? (
        <p
          id={descId}
          role={error ? "alert" : undefined}
          className={cn(
            "flex items-start gap-1 text-xs leading-snug",
            resolvedState === "error" && "text-[var(--color-danger)]",
            resolvedState === "warning" && "text-[var(--color-warning-text)]",
            resolvedState === "success" && "text-[var(--color-success-text)]"
          )}
        >
          {resolvedState !== "default" && <StateIcon state={resolvedState} />}
          <span>{displayMessage}</span>
        </p>
      ) : (
        helperText && (
          <p id={descId} className="text-xs leading-snug text-[var(--color-text-muted)]">
            {helperText}
          </p>
        )
      )}
    </div>
  )
}
