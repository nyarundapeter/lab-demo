"use client";

import * as React from "react";
import { Mail, Phone, StickyNote, Calendar, ArrowRight, HelpCircle, Paperclip, Download, Tag as TagIcon, Inbox } from "lucide-react";
import { cn } from "../lib/cn.js";
import { Avatar } from "./avatar.js";
import { Badge } from "./badge.js";
import { Button } from "./button.js";
import { EmptyState } from "./empty-state.js";
import { ErrorState } from "./error-state.js";
import { LoadingSkeleton } from "./loading-skeleton.js";
import { formatRelativeTime } from "../lib/format.js";
import type {
  ActivityDataState,
  ActivityEntry,
  ActivityTimelineConfig,
  ActivityTone,
  ActivityTypeConfig,
} from "../schemas/activity.js";

/**
 * ActivityTimeline — typed, connector-lined activity feed (activity-timeline-spec-2026-07-10.md
 * §7). Presentational: data arrives via props, no fetch calls — the host organism (lve-workspace's
 * `useActivityFeed`, record-drawer's record context) owns data fetching.
 */

const ICON_MAP = {
  mail: Mail,
  phone: Phone,
  note: StickyNote,
  calendar: Calendar,
  arrowRight: ArrowRight,
} as const;

const TONE_CLASSES: Record<ActivityTone, string> = {
  neutral: "bg-[var(--color-surface)] text-[var(--color-text-muted)] border-[var(--color-border-default)]",
  success: "bg-[var(--color-success-surface)] text-[var(--color-success-text)] border-[var(--color-success-border)]",
  warning: "bg-[var(--color-warning-surface)] text-[var(--color-warning-text)] border-[var(--color-warning-border)]",
  danger: "bg-[var(--color-danger-surface)] text-[var(--color-danger-text)] border-[var(--color-danger-border)]",
  info: "bg-[var(--color-info-surface)] text-[var(--color-info-text)] border-[var(--color-info-border)]",
};

function typeMeta(config: ActivityTimelineConfig, type: string): ActivityTypeConfig {
  return (
    config.activityTypes[type] ?? {
      icon: "note",
      tone: "neutral",
      label: type.replace(/_/g, " ") || "Activity",
    }
  );
}

function ActivityRow({
  entry,
  meta,
  isLast,
  isUnknownType,
  onDownloadAttachment,
}: {
  entry: ActivityEntry;
  meta: ActivityTypeConfig;
  isLast: boolean;
  isUnknownType: boolean;
  onDownloadAttachment?: ((attachmentId: string) => void) | undefined;
}) {
  const Icon = isUnknownType ? HelpCircle : ICON_MAP[meta.icon];

  return (
    <li className="relative flex gap-3 pb-5">
      {!isLast && (
        <span
          data-activity-connector
          className="absolute left-[11px] top-6 bottom-0 w-px bg-[var(--color-border)]"
          aria-hidden="true"
        />
      )}
      <span
        className={cn(
          "relative z-[1] flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-[6px] border",
          TONE_CLASSES[isUnknownType ? "neutral" : meta.tone],
        )}
        title={isUnknownType ? "Unrecognised activity type" : meta.label}
      >
        <Icon className="h-3 w-3" aria-hidden="true" />
      </span>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
          <Avatar name={entry.actorName} size="sm" className="h-5 w-5 text-xs" />
          <span className="font-medium text-[var(--color-text)]">{entry.actorName}</span>
          <span aria-hidden="true">·</span>
          <time dateTime={entry.timestamp}>{formatRelativeTime(entry.timestamp)}</time>
          {isUnknownType && (
            <span className="ml-1 text-xs italic text-[var(--color-text-disabled)]">
              (unrecognised type &ldquo;{entry.type}&rdquo;)
            </span>
          )}
        </div>

        <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-[var(--color-text)]">
          {entry.bodyText}
        </p>

        {entry.tags && entry.tags.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {entry.tags.map((t) => (
              <Badge key={t} tone="gray" size="sm">
                <TagIcon className="h-2.5 w-2.5" aria-hidden="true" />
                {t}
              </Badge>
            ))}
          </div>
        )}

        {entry.attachments && entry.attachments.length > 0 && (
          <div className="mt-2 flex flex-col gap-1">
            {entry.attachments.map((a) => (
              <button
                key={a.id}
                type="button"
                onClick={() => onDownloadAttachment?.(a.id)}
                className={cn(
                  "flex w-fit items-center gap-1.5 rounded-[6px] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-2 py-1 text-xs text-[var(--color-text)] transition-colors",
                  "hover:border-[var(--color-border-strong)] hover:bg-[var(--color-surface)]",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
                )}
              >
                <Paperclip className="h-3 w-3 text-[var(--color-text-muted)]" aria-hidden="true" />
                {a.name}
                <span className="text-[var(--color-text-disabled)]">{a.sizeKb} KB</span>
                <Download className="h-3 w-3 text-[var(--color-text-muted)]" aria-hidden="true" />
              </button>
            ))}
          </div>
        )}
      </div>
    </li>
  );
}

export interface ActivityTimelineProps {
  config: ActivityTimelineConfig;
  state: ActivityDataState;
  entries?: ActivityEntry[];
  onRetry?: () => void;
  onDownloadAttachment?: (attachmentId: string) => void;
  className?: string;
}

export function ActivityTimeline({
  config,
  state,
  entries = [],
  onRetry,
  onDownloadAttachment,
  className,
}: ActivityTimelineProps) {
  const labels = config.labels ?? {};
  const [activeTagFilters, setActiveTagFilters] = React.useState<string[]>([]);

  const allTags = React.useMemo(() => {
    const set = new Set<string>();
    entries.forEach((e) => e.tags?.forEach((t) => set.add(t)));
    return Array.from(set);
  }, [entries]);

  function toggleTagFilter(tag: string) {
    setActiveTagFilters((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  }

  const visibleEntries =
    activeTagFilters.length === 0 ? entries : entries.filter((e) => activeTagFilters.every((t) => e.tags?.includes(t)));

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      {config.tags && state === "populated" && allTags.length > 0 && (
        <div className="-mb-1 flex flex-wrap items-center gap-1.5">
          {allTags.map((t) => {
            const active = activeTagFilters.includes(t);
            return (
              <button
                key={t}
                type="button"
                aria-pressed={active}
                onClick={() => toggleTagFilter(t)}
                className={cn(
                  "inline-flex items-center gap-1 rounded-pill border px-2 py-0.5 text-xs font-medium transition-colors",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
                  active
                    ? "border-[var(--color-secondary)] bg-[var(--color-secondary)]/10 text-[var(--color-secondary)]"
                    : "border-[var(--color-border-default)] bg-[var(--color-surface-content)] text-[var(--color-text-muted)] hover:border-[var(--color-border-strong)]",
                )}
              >
                <TagIcon className="h-2.5 w-2.5" aria-hidden="true" />
                {t}
              </button>
            );
          })}
          {activeTagFilters.length > 0 && (
            <button
              type="button"
              onClick={() => setActiveTagFilters([])}
              className="text-xs font-medium text-[var(--color-text-muted)] underline decoration-[var(--color-border-strong)] underline-offset-2 hover:text-[var(--color-text)]"
            >
              {labels.clearFilters ?? "Clear"}
            </button>
          )}
        </div>
      )}

      {state === "loading" && <LoadingSkeleton variant="list" rows={3} />}

      {state === "error" && (
        <ErrorState
          title={labels.errorTitle ?? "Couldn't load activity"}
          description={labels.errorBody ?? "Try again."}
          action={onRetry && <Button variant="outline" size="sm" onClick={onRetry}>{labels.retry ?? "Retry"}</Button>}
        />
      )}

      {state === "empty" && (
        <EmptyState icon={<Inbox className="h-5 w-5" aria-hidden="true" />} headline={labels.emptyTitle ?? "No activity yet"} description={labels.emptyBody ?? "Notes, calls, and updates will show up here."} />
      )}

      {state === "populated" &&
        (visibleEntries.length === 0 ? (
          <p className="py-8 text-center text-sm text-[var(--color-text-muted)]">
            {labels.noFilterMatches ?? "No activity matches the selected tags."}
          </p>
        ) : (
          <ol className="flex flex-col">
            {visibleEntries.map((entry, i) => {
              const meta = typeMeta(config, entry.type);
              const isUnknown = !config.activityTypes[entry.type];
              return (
                <ActivityRow
                  key={entry.id}
                  entry={entry}
                  meta={meta}
                  isLast={i === visibleEntries.length - 1}
                  isUnknownType={isUnknown}
                  onDownloadAttachment={onDownloadAttachment}
                />
              );
            })}
          </ol>
        ))}
    </div>
  );
}
