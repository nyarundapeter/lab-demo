import * as React from "react"
import { Check, ChevronRight } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Badge, type BadgeProps } from "./badge.js"
import type { StageRow, StageStatus } from "./vertical-stage-tracker.js"

/**
 * CompactTracker — Wave 3 Family 3 molecule (no registry id, flat @dbp/ui
 * component). Reference: docs/03-features/specs/claude-design-briefs/
 * design-run-pack-2026-07-12/_outputs/workflow-system/wf-trackers.jsx
 * `CompactTracker` — a single-row "workbench" tracker for dense list/table
 * contexts, where VerticalStageTracker's own multi-line rows would be too
 * tall: one small pill per stage, chevron-separated, done stages get a
 * check glyph, the active stage a pulse dot, upcoming stages fade. Takes
 * `StageRow[]` directly (only `id`/`label`/`status` are read) so it composes
 * from the same data VerticalStageTracker/ConditionalTracker/MilestoneTracker
 * consume — no parallel stage-shape to keep in sync.
 */
export interface CompactTrackerProps {
  stages: Pick<StageRow, "id" | "label" | "status">[]
  className?: string
}

const STATUS_TONE: Record<StageStatus, NonNullable<BadgeProps["tone"]>> = {
  done: "success",
  active: "active",
  upcoming: "gray",
  error: "danger",
  blocked: "warning",
  skipped: "gray",
  returned: "warning",
}

export function CompactTracker({ stages, className }: CompactTrackerProps) {
  return (
    <div className={cn("flex flex-wrap items-center gap-1", className)}>
      {stages.map((st, i) => (
        <React.Fragment key={st.id}>
          <Badge
            tone={STATUS_TONE[st.status]}
            size="sm"
            dot={st.status === "active"}
            title={st.label}
            className={st.status === "upcoming" ? "opacity-65" : undefined}
            data-testid="compact-tracker-stage"
            data-status={st.status}
          >
            {st.status === "done" && <Check size={11} aria-hidden="true" />}
            {st.label}
          </Badge>
          {i < stages.length - 1 && (
            <ChevronRight size={12} className="shrink-0 text-[var(--color-text-muted)]" aria-hidden="true" />
          )}
        </React.Fragment>
      ))}
    </div>
  )
}
