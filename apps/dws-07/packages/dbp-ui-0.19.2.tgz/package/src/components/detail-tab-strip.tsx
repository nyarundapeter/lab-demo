"use client";

// Ported from the STCB GRC solution's shared detail-drawer kit (WS-6.2) —
// horizontal scrollable tab strip with overflow chevrons + a "…" menu for
// tabs that don't fit. Generic: no domain naming.

import * as React from "react";
import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react";
import { cn } from "../lib/cn.js";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "./dropdown-menu.js";
import type { DetailDrawerTab } from "./detail-drawer.js";

// DS-INTEGRATION(0.16.0): the scroll-chevron buttons, the "more tabs"
// trigger, and the horizontally-scrolling underline tab items below are raw
// <button> elements, not @dbp/ui's <Button>. Button's variants (padding /
// border / fixed height) don't express a borderless icon-chevron affordance
// or an underline-tab item; no existing variant fits without visual
// regression. If 0.16.0 ships a Button "ghost-icon" / "tab" variant (or an
// equivalent unstyled-trigger primitive), swap these in.

export interface DetailTabStripProps {
  tabs: DetailDrawerTab[];
  activeTab: string;
  onActiveTabChange: (key: string) => void;
}

/** Horizontal tab strip with overflow chevrons + a "…" menu for hidden tabs. */
export function DetailTabStrip({ tabs, activeTab, onActiveTabChange }: DetailTabStripProps) {
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const tabRefs = React.useRef<Map<string, HTMLButtonElement>>(new Map());
  const [overflowing, setOverflowing] = React.useState(false);
  const [hiddenKeys, setHiddenKeys] = React.useState<string[]>([]);

  const measure = React.useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const hasOverflow = el.scrollWidth > el.clientWidth + 1;
    setOverflowing(hasOverflow);
    if (!hasOverflow) {
      setHiddenKeys([]);
      return;
    }
    const containerRect = el.getBoundingClientRect();
    const hidden: string[] = [];
    for (const tab of tabs) {
      const node = tabRefs.current.get(tab.key);
      if (!node) continue;
      const r = node.getBoundingClientRect();
      if (r.left < containerRect.left - 1 || r.right > containerRect.right + 1) {
        hidden.push(tab.key);
      }
    }
    setHiddenKeys(hidden);
  }, [tabs]);

  React.useEffect(() => {
    measure();
    const el = scrollRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => measure());
    ro.observe(el);
    el.addEventListener("scroll", measure, { passive: true });
    return () => {
      ro.disconnect();
      el.removeEventListener("scroll", measure);
    };
  }, [measure]);

  React.useEffect(() => {
    const node = tabRefs.current.get(activeTab);
    node?.scrollIntoView({ block: "nearest", inline: "nearest" });
  }, [activeTab]);

  const scrollBy = (dir: -1 | 1) => {
    scrollRef.current?.scrollBy({ left: dir * 160, behavior: "smooth" });
  };

  return (
    <div className="flex items-center border-b border-[var(--color-border-default)]">
      {overflowing && (
        <button
          type="button"
          aria-label="Scroll tabs left"
          className="shrink-0 px-1 py-2 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          onClick={() => scrollBy(-1)}
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
      )}
      <div ref={scrollRef} className="flex flex-1 gap-1 overflow-x-auto scroll-smooth [scrollbar-width:none]">
        {tabs.map((tab) => {
          const isActive = tab.key === activeTab;
          return (
            <button
              key={tab.key}
              ref={(node) => {
                if (node) tabRefs.current.set(tab.key, node);
                else tabRefs.current.delete(tab.key);
              }}
              type="button"
              onClick={() => onActiveTabChange(tab.key)}
              className={cn(
                "shrink-0 whitespace-nowrap border-b-2 px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "border-[var(--color-secondary)] text-[var(--color-text)]"
                  : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]",
              )}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
      {overflowing && (
        <>
          <button
            type="button"
            aria-label="Scroll tabs right"
            className="shrink-0 px-1 py-2 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
            onClick={() => scrollBy(1)}
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          {hiddenKeys.length > 0 && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  aria-label="More tabs"
                  className="shrink-0 px-2 py-2 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                >
                  <MoreHorizontal className="h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {tabs
                  .filter((t) => hiddenKeys.includes(t.key))
                  .map((t) => (
                    <DropdownMenuItem
                      key={t.key}
                      onSelect={() => onActiveTabChange(t.key)}
                      className={t.key === activeTab ? "font-semibold text-[var(--color-secondary)]" : undefined}
                    >
                      {t.label}
                    </DropdownMenuItem>
                  ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </>
      )}
    </div>
  );
}
