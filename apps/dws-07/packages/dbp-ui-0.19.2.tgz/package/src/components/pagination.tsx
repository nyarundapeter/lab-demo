import * as React from "react"
import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./select.js"

/* ─── Pagination utilities ──────────────────────────────────────────────── */

/** Produces an array of page numbers + "ellipsis" markers for windowing. */
function getPageWindow(current: number, total: number): Array<number | "ellipsis"> {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1)

  const window: Array<number | "ellipsis"> = [1]

  if (current > 3) window.push("ellipsis")
  for (let p = Math.max(2, current - 1); p <= Math.min(total - 1, current + 1); p++) {
    window.push(p)
  }
  if (current < total - 2) window.push("ellipsis")

  window.push(total)
  return window
}

/* ─── Sub-components ────────────────────────────────────────────────────── */

const sharedPageBtn = cn(
  "flex h-8 min-w-[32px] items-center justify-center rounded-[var(--radius-button)]",
  "border border-[var(--color-border-default)]",
  "text-xs font-semibold",
  "transition-colors motion-safe:transition-all",
  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
  "disabled:pointer-events-none disabled:opacity-50"
)

interface PageButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  active?: boolean
}

function PageButton({ active, className, ...props }: PageButtonProps) {
  return (
    <button
      aria-current={active ? "page" : undefined}
      className={cn(
        sharedPageBtn,
        active
          ? "bg-primary text-white border-primary"
          : "bg-[var(--color-surface-content)] text-[var(--color-text-secondary)] hover:bg-[var(--color-navy-50)] hover:text-[var(--color-text-primary)] hover:border-primary",
        className
      )}
      {...props}
    />
  )
}

function Ellipsis({ className }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        "flex h-8 min-w-[32px] items-center justify-center",
        "text-[var(--color-text-muted)]",
        className
      )}
    >
      <MoreHorizontal size={14} strokeWidth={1.5} />
    </span>
  )
}

/* ─── Main Pagination component ────────────────────────────────────────── */

export interface PaginationProps {
  page: number
  pageSize: number
  total: number
  onPageChange: (page: number) => void
  onPageSizeChange?: (pageSize: number) => void
  pageSizeOptions?: number[]
  /** Show "Page X of Y" caption */
  showCaption?: boolean
  className?: string
}

export function Pagination({
  page,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 25, 50, 100],
  showCaption = false,
  className,
}: PaginationProps) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const pages = getPageWindow(page, totalPages)
  const hasPrev = page > 1
  const hasNext = page < totalPages

  return (
    <div
      className={cn("flex flex-wrap items-center gap-2", className)}
      aria-label="Pagination"
    >
      {/* Page-size selector */}
      {onPageSizeChange && (
        <div className="flex items-center gap-2 mr-2">
          <span className="text-xs text-[var(--color-text-muted)] whitespace-nowrap">
            Rows per page
          </span>
          <Select
            value={String(pageSize)}
            onValueChange={(v) => onPageSizeChange(Number(v))}
          >
            <SelectTrigger className="h-8 w-[72px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {pageSizeOptions.map((opt) => (
                <SelectItem key={opt} value={String(opt)}>
                  {opt}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Previous */}
      <PageButton
        onClick={() => onPageChange(page - 1)}
        disabled={!hasPrev}
        aria-label="Previous page"
      >
        <ChevronLeft size={14} strokeWidth={1.5} />
      </PageButton>

      {/* Page numbers */}
      {pages.map((p, i) =>
        p === "ellipsis" ? (
          <Ellipsis key={`ellipsis-${i}`} />
        ) : (
          <PageButton
            key={p}
            active={p === page}
            onClick={() => p !== page && onPageChange(p)}
          >
            {p}
          </PageButton>
        )
      )}

      {/* Next */}
      <PageButton
        onClick={() => onPageChange(page + 1)}
        disabled={!hasNext}
        aria-label="Next page"
      >
        <ChevronRight size={14} strokeWidth={1.5} />
      </PageButton>

      {/* Caption */}
      {showCaption && (
        <span
          className="ml-2 font-mono text-xs uppercase tracking-[0.18em] text-[var(--color-text-muted)]"
          aria-live="polite"
        >
          PAGE {page} OF {totalPages}
        </span>
      )}
    </div>
  )
}
