import * as React from "react"
import { Info, CheckCircle, AlertTriangle, XCircle, ShieldAlert } from "lucide-react"
import type { NotificationSeverity } from "@dbp/contracts"
import { Badge, type BadgeProps } from "./badge.js"

/**
 * Typed severity chip for the notification taxonomy (NOT-24). Named by
 * `notification-taxonomy.ts` as a consumer of `NotificationSeveritySchema` —
 * built to close that gap. Icon + label (never colour alone, a11y).
 */
const SEV_LABEL: Record<NotificationSeverity, string> = {
  info: "Info",
  success: "Success",
  warning: "Warning",
  error: "Error",
  critical: "Critical",
}

const SEV_ICON: Record<NotificationSeverity, React.ComponentType<{ size?: number; strokeWidth?: number; "aria-hidden"?: boolean }>> = {
  info: Info,
  success: CheckCircle,
  warning: AlertTriangle,
  error: XCircle,
  critical: ShieldAlert,
}

const SEV_TONE: Record<NotificationSeverity, BadgeProps["tone"]> = {
  info: "info",
  success: "success",
  warning: "warning",
  error: "danger",
  critical: "critical",
}

export interface SevChipProps extends Omit<BadgeProps, "tone" | "children"> {
  severity: NotificationSeverity
  /** Override the default label for the severity. */
  label?: string
}

export function SevChip({ severity, label, size, className, ...props }: SevChipProps) {
  const Icon = SEV_ICON[severity]
  return (
    <Badge tone={SEV_TONE[severity]} size={size} className={className} {...props}>
      <Icon size={size === "sm" ? 10 : 12} strokeWidth={2} aria-hidden />
      {label ?? SEV_LABEL[severity]}
    </Badge>
  )
}
