import * as React from "react"
import {
  AlertTriangle,
  Ban,
  Clock,
  Database,
  Gauge,
  HelpCircle,
  Lock,
  Pause,
  Shield,
  ShieldCheck,
  ToggleLeft,
  User,
  type LucideIcon,
} from "lucide-react"
import { cn } from "../lib/cn.js"

export type GovStateKind =
  | "unavailable"
  | "disabled"
  | "restricted"
  | "insufficient"
  | "lowconf"
  | "conflict"
  | "approval"
  | "review"
  | "stale"
  | "paused"
  | "error"
  | "timeout"
  | "blocked"
  | "unsupported"

type GovKindTone = "default" | "warn" | "review" | "error"

const GOV_STATE: Record<GovStateKind, { icon: LucideIcon; title: string; tone: GovKindTone }> = {
  unavailable: { icon: Ban, title: "Currently unavailable", tone: "default" },
  disabled: { icon: ToggleLeft, title: "Feature not enabled", tone: "default" },
  restricted: { icon: Lock, title: "Permission restricted", tone: "default" },
  insufficient: { icon: Database, title: "Insufficient data", tone: "warn" },
  lowconf: { icon: Gauge, title: "Low confidence", tone: "warn" },
  conflict: { icon: AlertTriangle, title: "Conflicting data", tone: "warn" },
  approval: { icon: ShieldCheck, title: "Action requires approval", tone: "review" },
  review: { icon: User, title: "Human review required", tone: "review" },
  stale: { icon: Clock, title: "Source may be stale", tone: "warn" },
  paused: { icon: Pause, title: "Automation paused", tone: "default" },
  error: { icon: AlertTriangle, title: "Something went wrong", tone: "error" },
  timeout: { icon: Clock, title: "Request timed out", tone: "error" },
  blocked: { icon: Shield, title: "Output blocked by policy", tone: "error" },
  unsupported: { icon: HelpCircle, title: "Unsupported request", tone: "default" },
}

/**
 * Tone -> class maps, one token triad per tone (border/bg, icon text) — the
 * same role-token families Badge's tones use (`default`/`gray` ~= Badge's
 * neutral tone, `warn` ~= Badge's warning tone, `review` ~= Badge's ai tone,
 * `error` ~= Badge's danger tone). Kept as a small local map rather than
 * literally importing Badge (GovState is a block, not a chip), per
 * design-system de-dup Wave 1.A (DS-R2/R3).
 */
const TONE_CLASS: Record<GovKindTone, string> = {
  default: "border-[var(--color-border-default)] bg-[var(--color-surface)]",
  warn: "border-[var(--color-warning-border)] bg-[var(--color-warning-surface)]",
  review: "border-[hsl(var(--ai-border))] bg-[hsl(var(--ai-soft))]",
  error: "border-[var(--color-danger-border)] bg-[var(--color-danger-surface)]",
}

const TONE_ICON_CLASS: Record<GovKindTone, string> = {
  default: "text-[var(--color-text-muted)]",
  warn: "text-[var(--color-warning-text)]",
  review: "text-[hsl(var(--ai-strong))]",
  error: "text-[var(--color-danger-text)]",
}

export interface GovStateProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "title"> {
  /** Which governance state this block represents. Defaults to "unavailable". */
  state?: GovStateKind
  /** Override the default title. */
  title?: React.ReactNode
  /** Why this state occurred. */
  why?: React.ReactNode
  /** What the user can do next. */
  next?: React.ReactNode
  /** Show the "You can still complete this manually" fallback line. */
  manual?: boolean
  /** Action buttons (e.g. Retry, Request access). */
  actions?: React.ReactNode
}

/**
 * Governance / gated-state block — the standard way to explain why a feature,
 * action, or output isn't available: unavailable, restricted, insufficient
 * data, low confidence, requires approval, error, etc. Genuinely a Badge +
 * InfoCard composition, not an AI-specific component — AI is the most common
 * caller (hence the default `manual` fallback line), but any gated/blocked
 * flow (permissions, feature flags, policy, workflow approval) can use it.
 * `role="alert"` for the error/review tones so assistive tech announces it.
 */
function GovState({
  className,
  state = "unavailable",
  title,
  why,
  next,
  manual = true,
  actions,
  ...props
}: GovStateProps) {
  const g = GOV_STATE[state] ?? GOV_STATE.unavailable
  const Icon = g.icon
  const isAlert = g.tone === "error" || g.tone === "review"

  return (
    <div
      role={isAlert ? "alert" : "status"}
      className={cn("flex items-start gap-3 rounded-[var(--radius-card,8px)] border p-3", TONE_CLASS[g.tone], className)}
      {...props}
    >
      <span className={cn("mt-0.5 shrink-0", TONE_ICON_CLASS[g.tone])}>
        <Icon size={16} aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-semibold text-[var(--color-text-primary)]">{title ?? g.title}</div>
        {(why || next) && (
          <div className="mt-0.5 text-xs text-[var(--color-text-muted)]">
            {why}
            {next && <> <span className="font-medium text-[var(--color-text-primary)]">{next}</span></>}
          </div>
        )}
        {manual && (
          <div className="mt-1.5 inline-flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
            <ShieldCheck size={12} className="text-[hsl(var(--prov-human))]" aria-hidden="true" />
            You can still complete this manually.
          </div>
        )}
        {actions && <div className="mt-2.5 flex items-center gap-2">{actions}</div>}
      </div>
    </div>
  )
}

export { GovState, GOV_STATE }
