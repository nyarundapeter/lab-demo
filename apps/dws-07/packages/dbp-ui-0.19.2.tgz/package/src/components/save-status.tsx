import * as React from "react"
import { Check, AlertCircle, Loader2 } from "lucide-react"
import { cn } from "../lib/cn.js"

/** Named `SaveStatusState` (not `SaveState`) to avoid colliding with
 * `save-state-indicator.tsx`'s own `SaveState` — a different 6-state
 * vocabulary (`overlay-guidance.jsx`'s `UnsavedView`), not this component's
 * 4-state `forms-blocks.jsx` shape. */
export type SaveStatusState = "idle" | "saving" | "saved" | "error"

export interface SaveStatusProps {
  status: SaveStatusState
  /** Human-readable time shown after "Saved" (e.g. "just now"). Omit for a bare "All changes saved". */
  savedAt?: string
  /** Overrides the default "Save failed — retry" text for the error state. */
  errorLabel?: string
  className?: string
}

/**
 * SaveStatus — the save-state text/icon strip (forms-blocks.jsx:147-162
 * `SaveStatus`). Renders nothing for `"idle"` (matches the reference and
 * `multi-step-form/index.tsx`'s own inline usage). Consumes the same 4-state
 * shape as `lve-workspace`'s `useSaveStatus` store
 * (`packages/stack/app-scaffolds/features/lve-workspace/hooks/use-save-status.ts`)
 * without depending on it — this is a presentational molecule any feature's
 * own save-state store (or `ActionFooter`'s `saveStatus` prop) can drive.
 */
function SaveStatus({ status, savedAt, errorLabel, className }: SaveStatusProps) {
  if (status === "idle") return null

  const config = {
    saved: {
      icon: <Check size={13} strokeWidth={2.5} aria-hidden="true" />,
      text: savedAt ? `Saved ${savedAt}` : "All changes saved",
      tone: "text-[var(--color-success-text)]",
    },
    saving: {
      icon: <Loader2 size={13} strokeWidth={2.5} className="motion-safe:animate-spin" aria-hidden="true" />,
      text: "Saving…",
      tone: "text-[var(--color-text-muted)]",
    },
    error: {
      icon: <AlertCircle size={13} strokeWidth={2.5} aria-hidden="true" />,
      text: errorLabel ?? "Save failed — retry",
      tone: "text-[var(--color-danger-text)]",
    },
  }[status]

  return (
    <span
      role="status"
      aria-live="polite"
      className={cn("inline-flex items-center gap-1.5 text-xs font-medium", config.tone, className)}
    >
      {config.icon}
      {config.text}
    </span>
  )
}

export { SaveStatus }
