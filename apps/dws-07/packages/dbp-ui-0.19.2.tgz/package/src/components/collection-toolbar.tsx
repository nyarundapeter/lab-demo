"use client"
import * as React from "react"
import { X } from "lucide-react"
import { cn } from "../lib/cn.js"
import { SegmentedControl, type SegmentOption } from "./segmented-control.js"
import { Input } from "./input.js"
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "./select.js"
import { Button } from "./button.js"

/**
 * Reusable filter toolbar: status tabs + search + N independently-configurable
 * filter dropdowns + multiple simultaneously-active, individually-removable
 * chips + result count + actions. Genuinely reusable across collection-board,
 * collection-grid, and collection-table — not a one-off for any single
 * layout. For a single-active-chip + one-sort-dropdown pattern, use
 * `FilterBar` instead — different interaction model, not a redundant pair.
 */

export interface CollectionToolbarFilter {
  key: string
  label: string
  options: Array<{ label: string; value: string }>
  value: string
  onChange: (value: string) => void
}

export interface CollectionToolbarChip {
  key: string
  label: string
  onRemove: () => void
}

export interface CollectionToolbarProps {
  /** Status tabs (e.g. All / Open / In Progress), reusing SegmentedControl. */
  statusOptions?: SegmentOption[]
  statusValue?: string
  onStatusChange?: (value: string) => void

  searchValue?: string
  onSearchChange?: (value: string) => void
  searchPlaceholder?: string

  /** Configurable filter dropdowns — as many as the feature needs. */
  filters?: CollectionToolbarFilter[]

  /** Active filter chips, each independently removable. */
  chips?: CollectionToolbarChip[]
  onClearAll?: () => void

  /** e.g. "128 results" — rendered as a plain text slot. */
  resultCount?: React.ReactNode

  /** e.g. Filters/Export buttons, rendered at the end of the toolbar. */
  actions?: React.ReactNode

  className?: string
}

export function CollectionToolbar({
  statusOptions,
  statusValue,
  onStatusChange,
  searchValue,
  onSearchChange,
  searchPlaceholder = "Search…",
  filters,
  chips,
  onClearAll,
  resultCount,
  actions,
  className,
}: CollectionToolbarProps) {
  const [filtersOpen, setFiltersOpen] = React.useState(false)
  const hasFilters = filters !== undefined && filters.length > 0

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <div className="flex flex-wrap items-center gap-3">
        {statusOptions && statusOptions.length > 0 && onStatusChange && (
          <SegmentedControl
            options={statusOptions}
            value={statusValue ?? ""}
            onChange={onStatusChange}
            name="Filter by status"
          />
        )}

        {onSearchChange !== undefined && (
          <Input
            type="text"
            value={searchValue ?? ""}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={searchPlaceholder}
            className="w-full sm:w-56"
          />
        )}

        {hasFilters && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="sm:hidden"
            aria-expanded={filtersOpen}
            onClick={() => setFiltersOpen((open) => !open)}
          >
            Filters
          </Button>
        )}

        {resultCount !== undefined && (
          <span className="text-sm text-[var(--color-text-muted)] sm:ml-auto">{resultCount}</span>
        )}

        {actions !== undefined && <div className="flex items-center gap-2">{actions}</div>}
      </div>

      {hasFilters && (
        <div
          className={cn(
            "flex-wrap items-center gap-3",
            filtersOpen ? "flex" : "hidden sm:flex"
          )}
        >
          {filters.map((filter) => (
            <div key={filter.key} className="flex items-center gap-1.5">
              <Select value={filter.value} onValueChange={filter.onChange}>
                <SelectTrigger className="w-auto min-w-[140px]" aria-label={filter.label}>
                  <SelectValue placeholder={filter.label} />
                </SelectTrigger>
                <SelectContent>
                  {filter.options.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ))}
        </div>
      )}

      {chips && chips.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          {chips.map((chip) => (
            <span
              key={chip.key}
              className={cn(
                "inline-flex items-center gap-1 rounded-pill pl-2.5 pr-1 h-7 text-xs font-medium",
                "bg-[var(--color-navy-50)] text-[var(--color-text-primary)] border border-[color-mix(in_srgb,var(--color-primary)_20%,transparent)]"
              )}
            >
              {chip.label}
              <button
                type="button"
                onClick={chip.onRemove}
                aria-label={`Remove filter: ${chip.label}`}
                className={cn(
                  "inline-flex items-center justify-center rounded-full w-5 h-5",
                  "hover:bg-[color-mix(in_srgb,var(--color-primary)_15%,transparent)]",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
                )}
              >
                <X size={12} strokeWidth={2} />
              </button>
            </span>
          ))}
          {onClearAll && (
            <button
              type="button"
              onClick={onClearAll}
              className="text-xs font-semibold text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] underline-offset-4 hover:underline"
            >
              Clear all
            </button>
          )}
        </div>
      )}
    </div>
  )
}
