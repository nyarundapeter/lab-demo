import * as React from "react"
import { cn } from "../lib/cn.js"

/* ─── FormSection ──────────────────────────────────────────────────────────
 * Groups related FormFields under a titled heading inside a settings/config form.
 * Renders a semantic <section aria-labelledby> with a heading + optional description
 * over a hairline divider — NO card surface (avoids card-in-card per ADR-0035).
 * Separate sections with the parent form's vertical gap (e.g. `gap-8`).
 * ─────────────────────────────────────────────────────────────────────── */

export interface FormSectionProps extends React.HTMLAttributes<HTMLElement> {
  /** Section heading. When omitted, the section renders its children with no header. */
  title?: string
  /** Optional one-line description shown under the heading. */
  description?: string
  /** Optional icon rendered in a small circular badge to the left of the heading. */
  icon?: React.ReactNode
  /** Heading element level. Default "h3" (preserves prior behavior). */
  headingLevel?: "h2" | "h3"
}

export function FormSection({
  title,
  description,
  icon,
  headingLevel = "h3",
  className,
  children,
  ...rest
}: FormSectionProps) {
  const headingId = React.useId()
  const Heading = headingLevel
  return (
    <section
      aria-labelledby={title ? headingId : undefined}
      className={cn("flex flex-col gap-4", className)}
      {...rest}
    >
      {title && (
        <div className="flex flex-col gap-1 border-b border-[var(--color-border)] pb-2">
          <div className="flex items-center gap-2.5">
            {icon && (
              <div
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[var(--color-navy-50)] text-[var(--color-text-primary)]"
                aria-hidden="true"
              >
                {icon}
              </div>
            )}
            <Heading id={headingId} className="text-sm font-semibold text-[var(--color-text)]">
              {title}
            </Heading>
          </div>
          {description && (
            <p className="text-xs text-[var(--color-text-muted)]">{description}</p>
          )}
        </div>
      )}
      {children}
    </section>
  )
}
