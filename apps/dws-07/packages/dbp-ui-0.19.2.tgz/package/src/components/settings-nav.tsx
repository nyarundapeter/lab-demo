import * as React from "react"

/* ─── SettingsNav ────────────────────────────────────────────────────────
 * Sibling-settings navigation rail for admin config pages. Extracted from
 * the generator's inline <nav> emission (GATE.06: pages must not carry raw
 * chrome elements or design-class internals — 2026-07-17 admin pass).
 * ─────────────────────────────────────────────────────────────────────── */

export interface SettingsNavLink {
  href: string
  label: string
}

export function SettingsNav({ links }: { links: SettingsNavLink[] }) {
  return (
    <nav aria-label="Settings navigation" className="flex flex-col gap-0.5">
      {links.map((link) => (
        <a
          key={link.href}
          href={link.href}
          className="block py-1.5 px-2 rounded text-sm font-medium hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)] text-[var(--color-text)]"
        >
          {link.label}
        </a>
      ))}
    </nav>
  )
}
