import * as React from "react";
import { ChevronDown, Search, icons as lucideIcons } from "lucide-react";
import * as LucideIcons from "lucide-react";
import { SidebarConfig, NavItem, NavSection } from "@dbp/contracts";
import { cn } from "../lib/cn.js";

type LucideGlyph = React.ComponentType<{
  size?: number;
  strokeWidth?: number;
  className?: string;
}>;

/**
 * Resolves a lucide icon by PascalCase name. Prefers the named module export
 * (covers deprecated aliases like "Home") and falls back to the `icons` map.
 * Returns null for unknown names so the sidebar degrades gracefully.
 */
function resolveIcon(name: string): LucideGlyph | null {
  const named = (LucideIcons as Record<string, unknown>)[name];
  if (typeof named === "object" && named !== null && "$$typeof" in named) {
    return named as LucideGlyph;
  }
  const mapped = (lucideIcons as Record<string, LucideGlyph | undefined>)[name];
  return mapped ?? null;
}

/** Derives up-to-two-letter initials from a display name/code for the identity square. */
function squareInitials(name: string): string {
  const parts = name.trim().split(/[\s./]+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return (parts[0]![0]! + parts[1]![0]!).toUpperCase();
}

export interface SidebarIdentityProps {
  /** Solution code shown bold, e.g. "DWS.01". */
  code: string;
  /** Product name shown muted beneath the code, e.g. "Work.Space4.0". */
  name?: string;
  /** Logo image URL. Falls back to a colored initials square. */
  logoSrc?: string;
  /** Alt text for the logo image. Defaults to `code`. */
  logoAlt?: string;
  /** Icon-only mode: hides the text block and centers the square. */
  collapsed?: boolean;
  className?: string;
}

/**
 * SidebarIdentity — the app/solution identity block anchored at the top of
 * {@link AppSidebar} (shell v3 anatomy, see N27 ruling). Replaces the lockup
 * that previously lived in {@link AppTopBar}'s left section: a small colored
 * logo/initials square + two-line "code / name" text, collapsing to just the
 * square when the sidebar is icon-only (mirrors the design-run-pack
 * TenantSwitcher's collapsed behavior).
 */
export function SidebarIdentity({ code, name, logoSrc, logoAlt, collapsed, className }: SidebarIdentityProps) {
  return (
    <div
      className={cn(
        "flex h-[var(--shell-header-h)] shrink-0 items-center gap-2.5 border-b border-[var(--color-border-subtle)] px-3",
        collapsed && "justify-center px-0",
        className
      )}
    >
      {logoSrc ? (
        <img src={logoSrc} alt={logoAlt ?? code} className="h-6 w-6 shrink-0 rounded object-contain" />
      ) : (
        <span
          aria-hidden
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-[6px] bg-primary text-xs font-bold text-white"
        >
          {squareInitials(code)}
        </span>
      )}
      {!collapsed && (
        <span className="flex min-w-0 flex-col overflow-hidden">
          {/* Identity TEXT uses the text role, not the brand-action role: in dark
              mode `--color-primary` rebinds to the light-blue action color, which
              made the wordmark unreadable-blue on black (Sharavi 2026-07-26).
              `--color-text-primary` reads identically near-black in light and
              flips to near-white in dark. */}
          <span className="truncate text-sm font-bold leading-tight text-[var(--color-text-primary)]">{code}</span>
          {name && (
            <span className="truncate text-xs leading-tight text-[var(--color-text-muted)]">{name}</span>
          )}
        </span>
      )}
    </div>
  );
}

export interface AppSidebarProps {
  config: SidebarConfig;
  /** Current pathname for active state detection */
  activePath: string;
  /** Called when a nav item is clicked */
  onNavigate?: (href: string) => void;
  className?: string;
  /** Persist nav open/close state to localStorage under this key */
  storageKey?: string;
  /** Render icon-only mode (no labels, no children) */
  iconOnly?: boolean;
  /**
   * Flat mode for the mobile drawer: groups are always expanded (no chevron,
   * no collapse toggle), section eyebrow labels are hidden. Reduces the
   * 3-level hierarchy to a plain scrollable list with group dividers.
   */
  flatGroups?: boolean;
  /**
   * Shows a nav-filter search input under the sidebar identity header
   * (N27b ruling). Live-filters section items by label, case-insensitive;
   * sections with no matches are hidden. Hidden when `iconOnly` (collapsed).
   * Distinct from the global ⌘K search — this only filters the nav tree.
   */
  showSearch?: boolean;
}

const INITIAL_NAV_STATE = { collapsedSections: {} as Record<string, boolean>, collapsedItems: {} as Record<string, boolean> }

function loadNavState(storageKey?: string): typeof INITIAL_NAV_STATE {
  if (!storageKey || typeof window === 'undefined') return INITIAL_NAV_STATE
  try {
    return JSON.parse(localStorage.getItem(storageKey) ?? 'null') ?? INITIAL_NAV_STATE
  } catch { return INITIAL_NAV_STATE }
}

function saveNavState(storageKey: string | undefined, state: typeof INITIAL_NAV_STATE): void {
  if (!storageKey || typeof window === 'undefined') return
  localStorage.setItem(storageKey, JSON.stringify(state))
}

function defaultNavState(config: SidebarConfig, activePath?: string): typeof INITIAL_NAV_STATE {
  const collapsedItems: Record<string, boolean> = {}
  config.sections.forEach(section => {
    section.items.forEach((item, idx) => {
      if (item.children && item.children.length > 0) {
        const descendantActive = activePath ? groupIsActive(item, activePath) : false
        collapsedItems[item.id] = !descendantActive && idx !== 0
      }
    })
  })
  return { collapsedSections: {}, collapsedItems }
}

const focusRing =
  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]";

/** Resolves a lucide icon name (PascalCase) to a rendered glyph at stroke 1.5. */
function NavIcon({ name }: { name?: string }) {
  if (!name) return null;
  const Icon = resolveIcon(name);
  if (!Icon) return null;
  return <Icon size={17} strokeWidth={1.5} className="shrink-0" />;
}

/**
 * Filters sidebar sections by a nav-search query (case-insensitive substring
 * match on item label). Sections with no matching items are dropped entirely
 * (N27b ruling). An empty/whitespace query returns `sections` unchanged.
 */
export function filterNavGroups(sections: NavSection[], query: string): NavSection[] {
  const q = query.trim().toLowerCase();
  if (!q) return sections;
  return sections
    .map((section) => ({
      ...section,
      items: section.items.filter((item) => item.label.toLowerCase().includes(q)),
    }))
    .filter((section) => section.items.length > 0);
}

function isActive(item: NavItem, activePath: string): boolean {
  return activePath === item.href || activePath.startsWith(item.href + "/");
}

/**
 * True for a plain, unmodified left click — the only click a nav anchor
 * should intercept for client-side routing. Ctrl/Cmd/Shift/Alt/middle-click
 * must fall through to the browser's native anchor behaviour (open in new
 * tab, etc.) — D2 ruling.
 */
function isPlainLeftClick(e: React.MouseEvent): boolean {
  return e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey;
}

function groupIsActive(item: NavItem, activePath: string): boolean {
  if (isActive(item, activePath)) return true;
  return Boolean(item.children?.some((c) => groupIsActive(c, activePath)));
}

/** Nested child row (level 3) — sits inside the .sidebar-child-line rail. */
function ChildRow({
  item,
  activePath,
  onNavigate,
}: {
  item: NavItem;
  activePath: string;
  onNavigate?: (href: string) => void;
}) {
  const active = isActive(item, activePath);
  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (!isPlainLeftClick(e)) return;
    e.preventDefault();
    if (item.href) onNavigate?.(item.href);
  };
  return (
    <a
      href={item.href}
      onClick={handleClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "sidebar-feature-item w-full",
        active && "sidebar-feature-item-active",
        focusRing
      )}
    >
      {active && (
        <span
          aria-hidden
          className="absolute bottom-1.5 left-[-13px] top-1.5 w-0.5 rounded-r bg-[var(--color-nav-accent)]"
        />
      )}
      <span className="min-w-0 flex-1 truncate text-left">{item.label}</span>
      {item.badge && (
        <span className="ml-2 shrink-0 rounded-pill bg-primary px-1.5 py-0.5 text-xs font-bold text-white">
          {item.badge}
        </span>
      )}
    </a>
  );
}

/** Top-level group row (level 2) with optional expandable children. */
function GroupRow({
  item,
  activePath,
  onNavigate,
  iconOnly,
  isItemCollapsed,
  onToggleItem,
  flatGroups,
}: {
  item: NavItem;
  activePath: string;
  onNavigate?: (href: string) => void;
  iconOnly?: boolean;
  isItemCollapsed?: boolean;
  onToggleItem?: (id: string) => void;
  flatGroups?: boolean;
}) {
  const hasChildren = Boolean(item.children && item.children.length > 0);
  const active = groupIsActive(item, activePath);
  const selfActive = isActive(item, activePath);

  // In flat mode groups are always open — no collapse toggle.
  const open = flatGroups ? hasChildren : (hasChildren ? !isItemCollapsed : false);

  const handleToggleClick = () => {
    if (hasChildren && onToggleItem && !flatGroups) {
      onToggleItem(item.id);
    }
  };

  const handleNavigateClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (!isPlainLeftClick(e)) return;
    e.preventDefault();
    if (item.href) onNavigate?.(item.href);
  };

  if (iconOnly) {
    return (
      <div>
        <a
          href={item.href}
          aria-current={selfActive ? "page" : undefined}
          className={cn(
            "relative sidebar-feature-group whitespace-nowrap",
            (selfActive || active) && "sidebar-feature-group-active",
            focusRing
          )}
          title={item.label}
        >
          {(selfActive || active) && (
            <span
              aria-hidden
              className="absolute bottom-1.5 left-0 top-1.5 w-0.5 rounded-r bg-[var(--color-nav-accent)]"
            />
          )}
          <NavIcon {...(item.icon !== undefined && { name: item.icon })} />
        </a>
      </div>
    );
  }

  const rowClassName = cn(
    "relative sidebar-feature-group",
    (selfActive || active) && "sidebar-feature-group-active",
    focusRing
  );

  const rowContent = (
    <>
      {(selfActive || active) && (
        <span
          aria-hidden
          className="absolute bottom-1.5 left-0 top-1.5 w-0.5 rounded-r bg-[var(--color-nav-accent)]"
        />
      )}
      <NavIcon {...(item.icon !== undefined && { name: item.icon })} />
      <span className="min-w-0 flex-1 truncate text-left">{item.label}</span>
      {item.badge && (
        <span className="shrink-0 rounded-pill bg-primary px-1.5 py-0.5 text-xs font-bold text-white">
          {item.badge}
        </span>
      )}
      {hasChildren && !flatGroups && (
        <ChevronDown
          size={14}
          strokeWidth={1.5}
          aria-hidden
          className={cn(
            "shrink-0 motion-safe:transition-transform",
            open && "rotate-180"
          )}
        />
      )}
    </>
  );

  return (
    <div>
      {/* A group with children only EXPANDS/COLLAPSES — that's not navigation,
          so it stays a <button>. A group with no children IS a navigation
          target — it must be a real <a href> (D2 ruling). */}
      {hasChildren ? (
        <button
          type="button"
          onClick={handleToggleClick}
          aria-current={selfActive ? "page" : undefined}
          aria-expanded={open}
          className={rowClassName}
        >
          {rowContent}
        </button>
      ) : (
        <a
          href={item.href}
          onClick={handleNavigateClick}
          aria-current={selfActive ? "page" : undefined}
          className={rowClassName}
        >
          {rowContent}
        </a>
      )}

      {hasChildren && open && (
        <div className="sidebar-child-line">
          {item.children!.map((child) => (
            <ChildRow
              key={child.id}
              item={child}
              activePath={activePath}
              {...(onNavigate !== undefined && { onNavigate })}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * AppSidebar — DQ prototype three-level navigation (280px white surface).
 *
 * Hierarchy: section eyebrow (mono/bold uppercase orange) → group rows
 * (icon + label + chevron, navy-50 active with orange w-0.5 accent) → nested
 * children inside a left border-line rail (.sidebar-child-line), each with its
 * own orange active accent. Icons resolve from lucide names; aria-current marks
 * the active route; hover/focus-visible states follow the token system.
 */
export function AppSidebar({ config, activePath, onNavigate, className, storageKey, iconOnly, flatGroups, showSearch }: AppSidebarProps) {
  const [navQuery, setNavQuery] = React.useState("");
  const visibleSections = showSearch ? filterNavGroups(config.sections, navQuery) : config.sections;

  const [navState, setNavState] = React.useState(() => {
    if (!storageKey || typeof window === 'undefined') return defaultNavState(config, activePath)
    const stored = loadNavState(storageKey)
    const hasStoredSections = Object.keys(stored.collapsedSections).length > 0 || Object.keys(stored.collapsedItems).length > 0
    return hasStoredSections ? stored : defaultNavState(config, activePath)
  })

  const _toggleSection = (id: string) =>
    setNavState(prev => {
      const next = { ...prev, collapsedSections: { ...prev.collapsedSections, [id]: !prev.collapsedSections[id] } }
      saveNavState(storageKey, next)
      return next
    })

  const toggleItem = (id: string) =>
    setNavState(prev => {
      const next = { ...prev, collapsedItems: { ...prev.collapsedItems, [id]: !prev.collapsedItems[id] } }
      saveNavState(storageKey, next)
      return next
    })

  return (
    <nav
      className={cn(
        "flex flex-1 min-h-0 flex-col overflow-y-auto shell-scroll-thin bg-[var(--color-surface-content)] px-3 py-4",
        className
      )}
      aria-label="Sidebar navigation"
    >
      {showSearch && !iconOnly && (
        <div className="relative mb-3 shrink-0">
          <Search
            aria-hidden
            size={13}
            strokeWidth={1.5}
            className="pointer-events-none absolute left-2 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]"
          />
          <input
            type="text"
            value={navQuery}
            onChange={(e) => setNavQuery(e.target.value)}
            placeholder="Search navigation…"
            aria-label="Search navigation"
            className={cn(
              "w-full rounded-md border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] py-1.5 pl-7 pr-2 text-xs",
              focusRing
            )}
          />
        </div>
      )}
      <div className="space-y-5">
        {visibleSections.map((section) => (
          <section key={section.id} className="space-y-1">
            {section.label && (
              <div className="sidebar-feature-area">{section.label}</div>
            )}
            <div className="mt-1 space-y-1">
              {section.items.map((item) => (
                <GroupRow
                  key={item.id}
                  item={item}
                  activePath={activePath}
                  {...(onNavigate !== undefined && { onNavigate })}
                  iconOnly={iconOnly ?? false}
                  isItemCollapsed={Boolean(navState.collapsedItems[item.id])}
                  onToggleItem={toggleItem}
                  flatGroups={flatGroups ?? false}
                />
              ))}
            </div>
          </section>
        ))}
      </div>
    </nav>
  );
}
