import * as React from "react"
import { cn } from "../lib/cn"

export interface BreadcrumbItem {
  label: string
  href?: string
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[]
  className?: string
  /** Force a single line, truncating overflow instead of wrapping. Use inside fixed-height chrome (e.g. the 44px top bar). Default false (wraps). */
  nowrap?: boolean
  /**
   * Called with an ancestor crumb's `href` on click, instead of navigating via
   * a real `<a>`. Use when the caller owns routing (e.g. a client-side
   * `onNavigate` callback) rather than plain link navigation — renders
   * ancestor crumbs as buttons instead of anchors.
   */
  onNavigate?: (href: string) => void
}

/**
 * Breadcrumb — a real wayfinding breadcrumb (not an accented eyebrow).
 *
 * Typical product/admin practice: a quiet, neutral, sentence-case trail of the
 * ancestor path ending in the current page. It is a navigation utility, so it
 * stays MUTED and is never brand-accented — the page H1 is the focal point, the
 * breadcrumb just says "you are here". Ancestors with an href are links; the
 * final crumb is the current page (muted, aria-current, non-link). It is fine for
 * the final crumb to repeat the H1 because it is de-emphasised.
 */
export function Breadcrumb({ items, className, nowrap = false, onNavigate }: BreadcrumbProps) {
  return (
    <nav aria-label="Breadcrumb" className={cn("flex min-w-0", className)}>
      <ol
        className={cn(
          "flex items-center gap-0.5 text-xs font-medium",
          nowrap ? "min-w-0 flex-nowrap overflow-hidden whitespace-nowrap" : "flex-wrap"
        )}
      >
        {items.map((item, index) => {
          const isLast = index === items.length - 1
          return (
            <li
              key={index}
              className={cn(
                "flex items-center",
                nowrap &&
                  (isLast
                    ? // D5 fix: the terminal crumb IS the page identity (ADR-0052 /
                      // Amendment D-2 — the top bar's breadcrumb replaced the
                      // page-level PageHeader title). It must win the space, not
                      // shrink to a 3-char floor. `flex-1 min-w-0` lets it claim
                      // whatever room the ancestors don't take, only truncating
                      // (with ellipsis) if the label itself is genuinely too long.
                      "min-w-0 flex-1"
                    : // Ancestors shrink/truncate individually rather than being
                      // protected at full width — they are the first thing to
                      // give up space (dropped below `sm` entirely; see below).
                      "hidden min-w-0 max-w-[12ch] shrink truncate sm:flex"),
              )}
            >
              {index > 0 && (
                <span
                  aria-hidden
                  className={cn(
                    "mx-1.5 select-none text-[var(--color-text-disabled)]",
                    // The separator before the terminal crumb only makes sense
                    // once at least one ancestor is visible — hide it at the
                    // same breakpoint the ancestors themselves are hidden at.
                    nowrap && isLast && "hidden shrink-0 sm:inline",
                  )}
                >
                  /
                </span>
              )}
              {isLast ? (
                <span
                  className={cn("text-[var(--color-text-secondary)]", nowrap && "min-w-0 flex-1 truncate")}
                  aria-current="page"
                >
                  {item.label}
                </span>
              ) : item.href && onNavigate ? (
                <button
                  type="button"
                  onClick={() => onNavigate(item.href!)}
                  className={cn(
                    "rounded-sm text-[var(--color-text-muted)] transition-colors hover:text-[var(--color-text-primary)]",
                    "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                    nowrap && "truncate"
                  )}
                >
                  {item.label}
                </button>
              ) : item.href ? (
                <a
                  href={item.href}
                  className={cn(
                    "rounded-sm text-[var(--color-text-muted)] transition-colors hover:text-[var(--color-text-primary)]",
                    "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                    nowrap && "truncate"
                  )}
                >
                  {item.label}
                </a>
              ) : (
                <span className={cn("text-[var(--color-text-muted)]", nowrap && "truncate")}>{item.label}</span>
              )}
            </li>
          )
        })}
      </ol>
    </nav>
  )
}
