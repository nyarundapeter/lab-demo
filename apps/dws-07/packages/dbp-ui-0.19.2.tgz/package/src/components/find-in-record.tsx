import * as React from "react"
import { Search, ChevronUp, ChevronDown, X } from "lucide-react"
import type { LucideProps } from "lucide-react"
import { Highlight } from "./search-result-row.js"
import { cn } from "../lib/cn.js"

/**
 * Find-in-record (⌘F) — port of search-system/search-incontext.jsx's
 * `FindInRecord`. Distinct from global search: scoped to the text already
 * loaded in `entries` (an activity log, a document, a case thread), counts
 * matches, and steps through them with the keyboard. Never leaves the page.
 */

export interface FindInRecordEntry {
  id: string
  /** Author/actor display name. */
  who: string
  text: string
  /** Pre-formatted timestamp label (e.g. "2h ago"). */
  timeLabel: string
  icon?: React.ComponentType<LucideProps>
}

export interface FindInRecordProps {
  entries: FindInRecordEntry[]
  /** Label announced for the scope badge, e.g. "Searching this record only". */
  scopeLabel?: string
  className?: string
}

export function FindInRecord({ entries, scopeLabel = "Searching this record only", className }: FindInRecordProps) {
  const [open, setOpen] = React.useState(false)
  const [query, setQuery] = React.useState("")
  const [current, setCurrent] = React.useState(0)
  const inputRef = React.useRef<HTMLInputElement>(null)
  const logRef = React.useRef<HTMLDivElement>(null)
  const rowRefs = React.useRef<Array<HTMLDivElement | null>>([])

  const matches = React.useMemo(() => {
    const m: Array<{ rowIndex: number; localIndex: number }> = []
    const trimmed = query.trim()
    if (trimmed) {
      const re = new RegExp(trimmed.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "ig")
      entries.forEach((row, rowIndex) => {
        const count = (row.text.match(re) ?? []).length
        for (let localIndex = 0; localIndex < count; localIndex++) m.push({ rowIndex, localIndex })
      })
    }
    return m
  }, [entries, query])

  React.useEffect(() => {
    setCurrent(0)
  }, [query])

  const total = matches.length
  const currentMatch = matches[current]

  React.useEffect(() => {
    if (!currentMatch || !logRef.current) return
    const el = rowRefs.current[currentMatch.rowIndex]
    if (el) logRef.current.scrollTop = Math.max(0, el.offsetTop - 48)
  }, [current, currentMatch])

  const step = (direction: 1 | -1) => {
    if (total === 0) return
    setCurrent((c) => (c + direction + total) % total)
  }

  const onFindKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault()
      step(e.shiftKey ? -1 : 1)
    } else if (e.key === "Escape") {
      e.preventDefault()
      setOpen(false)
    }
  }

  // Cmd/Ctrl+F opens the in-record find, scoped to this component's lifetime.
  React.useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "f") {
        e.preventDefault()
        setOpen(true)
        setTimeout(() => inputRef.current?.select(), 30)
      }
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [])

  const currentIndexFor = (rowIndex: number) => (currentMatch && currentMatch.rowIndex === rowIndex ? currentMatch.localIndex : -1)

  return (
    <div className={cn("flex flex-col", className)}>
      <div className="flex flex-wrap items-center gap-2 border-b border-[var(--color-border-default)] px-3 py-2">
        <button
          type="button"
          onClick={() => {
            setOpen(true)
            setTimeout(() => inputRef.current?.select(), 30)
          }}
          className="inline-flex items-center gap-1.5 rounded-input border border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-2.5 py-1 text-xs font-medium text-[var(--color-text-primary)] hover:bg-[var(--color-surface)]"
        >
          <Search size={12} aria-hidden="true" />
          Find in page
          <span className="ml-1 rounded border border-[var(--color-border-default)] px-1 text-xs">{"⌘"}F</span>
        </button>
        <span className="text-xs text-[var(--color-text-muted)]">{scopeLabel}</span>
      </div>

      <div ref={logRef} className="max-h-72 overflow-y-auto">
        {entries.map((row, rowIndex) => (
          <div
            key={row.id}
            ref={(el) => {
              rowRefs.current[rowIndex] = el
            }}
            className="flex items-start gap-2 border-b border-[var(--color-border-default)] px-3 py-2 text-sm"
          >
            <span className="mt-0.5 w-16 shrink-0 text-xs text-[var(--color-text-muted)]">{row.timeLabel}</span>
            {row.icon && <row.icon size={13} className="mt-0.5 shrink-0 text-[var(--color-text-muted)]" aria-hidden="true" />}
            <span className="min-w-0">
              <span className="mr-1.5 font-semibold">{row.who}</span>
              <Highlight text={row.text} terms={query.trim() ? [query.trim()] : []} currentIndex={currentIndexFor(rowIndex)} />
            </span>
          </div>
        ))}
      </div>

      {open && (
        <div role="search" className="flex items-center gap-2 border-t border-[var(--color-border-default)] bg-[var(--color-surface)] px-3 py-2">
          <Search size={13} className="shrink-0 text-[var(--color-text-muted)]" aria-hidden="true" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onFindKeyDown}
            placeholder="Find in record…"
            aria-label="Find in record"
            autoFocus
            className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[var(--color-text-disabled)]"
          />
          <span className="shrink-0 text-xs text-[var(--color-text-muted)]" aria-live="polite">
            {total > 0 ? `${current + 1} / ${total}` : query.trim() ? "0 / 0" : ""}
          </span>
          <button
            type="button"
            onClick={() => step(-1)}
            disabled={total === 0}
            title="Previous (Shift+Enter)"
            aria-label="Previous match"
            className="rounded p-1 text-[var(--color-text-muted)] hover:bg-[var(--color-border-default)]/40 disabled:opacity-40"
          >
            <ChevronUp size={14} />
          </button>
          <button
            type="button"
            onClick={() => step(1)}
            disabled={total === 0}
            title="Next (Enter)"
            aria-label="Next match"
            className="rounded p-1 text-[var(--color-text-muted)] hover:bg-[var(--color-border-default)]/40 disabled:opacity-40"
          >
            <ChevronDown size={14} />
          </button>
          <button
            type="button"
            onClick={() => setOpen(false)}
            title="Close (Esc)"
            aria-label="Close find"
            className="rounded p-1 text-[var(--color-text-muted)] hover:bg-[var(--color-border-default)]/40"
          >
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  )
}
