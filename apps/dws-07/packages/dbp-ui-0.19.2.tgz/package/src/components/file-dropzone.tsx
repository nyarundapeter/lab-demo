import * as React from "react"
import { UploadCloud } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface FileDropzoneProps {
  /** Comma-separated accept string passed to the underlying <input type="file">, e.g. ".pdf,.docx". */
  accept?: string
  /** Whether multiple files may be selected/dropped. Default true. */
  multiple?: boolean
  /** Called with the FileList when files are selected via browse or drop. */
  onFilesSelected?: (files: FileList) => void
  /** Visible helper copy describing accepted types / size limits (also wired via aria-describedby). */
  helperText?: string
  /** Label for the clickable "browse" affordance. Default "browse". */
  browseLabel?: string
  /** Leading copy before the browse link. Default "Drag and drop files here, or". */
  promptText?: string
  id?: string
  className?: string
}

/**
 * FileDropzone — a dashed-border drag-and-drop target with a REAL, always-present
 * <input type="file"> so keyboard and screen-reader users have a working fallback
 * (drag-and-drop is progressive enhancement only, never the only way to attach files).
 */
export function FileDropzone({
  accept,
  multiple = true,
  onFilesSelected,
  helperText,
  browseLabel = "browse",
  promptText = "Drag and drop files here, or",
  id: externalId,
  className,
}: FileDropzoneProps) {
  const autoId = React.useId()
  const inputId = externalId ?? autoId
  const descId = `${inputId}-desc`
  const inputRef = React.useRef<HTMLInputElement>(null)
  const [isDragOver, setIsDragOver] = React.useState(false)

  const handleFiles = (files: FileList | null) => {
    if (files && files.length > 0) {
      onFilesSelected?.(files)
    }
  }

  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <div
        onDragOver={(e) => {
          e.preventDefault()
          setIsDragOver(true)
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={(e) => {
          e.preventDefault()
          setIsDragOver(false)
          handleFiles(e.dataTransfer.files)
        }}
        className={cn(
          "flex items-center justify-center gap-2 rounded-input border-[1.5px] border-dashed px-4 py-6 text-sm",
          "text-[var(--color-text-muted)] transition-colors motion-safe:transition-all",
          "has-[:focus-visible]:[box-shadow:var(--focus-ring-primary)]",
          isDragOver
            ? "border-primary bg-[var(--color-navy-50)]"
            : "border-[var(--color-border-default)] bg-[var(--color-surface-content)]"
        )}
      >
        <UploadCloud size={16} strokeWidth={1.5} aria-hidden="true" className="shrink-0" />
        <span>
          {promptText}{" "}
          <label
            htmlFor={inputId}
            className="cursor-pointer font-medium text-[var(--color-text-primary)] underline-offset-2 hover:underline"
          >
            {browseLabel}
          </label>
        </span>
      </div>

      <input
        ref={inputRef}
        id={inputId}
        type="file"
        accept={accept}
        multiple={multiple}
        aria-describedby={helperText ? descId : undefined}
        className="sr-only"
        onChange={(e) => handleFiles(e.target.files)}
      />

      {helperText && (
        <p id={descId} className="text-xs leading-snug text-[var(--color-text-muted)]">
          {helperText}
        </p>
      )}
    </div>
  )
}
