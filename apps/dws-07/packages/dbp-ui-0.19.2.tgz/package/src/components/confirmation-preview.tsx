import * as React from "react"
import { ArrowRight } from "lucide-react"
import { AiMark } from "./ai-mark.js"
import { Button } from "./button.js"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "./dialog.js"

export interface ConfirmationPreviewField {
  label: string
  before: React.ReactNode
  after: React.ReactNode
}

export interface ConfirmationPreviewProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title?: React.ReactNode
  description?: React.ReactNode
  fields: ConfirmationPreviewField[]
  onConfirm: () => void
  onCancel?: () => void
  confirmLabel?: string
  /** Confirm button shows a spinner and disables while the apply is in flight. */
  confirming?: boolean
}

/**
 * Confirm-before-apply gate for any AI-proposed data mutation. Renders a
 * field-level before/after diff and requires an explicit "Confirm & apply"
 * — no AI action changes data without this step.
 */
function ConfirmationPreview({
  open,
  onOpenChange,
  title = "Review AI-suggested change",
  description,
  fields,
  onConfirm,
  onCancel,
  confirmLabel = "Confirm & apply",
  confirming = false,
}: ConfirmationPreviewProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="default" aria-label="Confirm AI-suggested change">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AiMark size={16} />
            {title}
          </DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <DialogBody>
          <div className="flex flex-col gap-3" role="table" aria-label="Proposed field changes">
            {fields.map((f, i) => (
              <div key={i} role="row" className="rounded border border-[var(--color-border-subtle)] p-3">
                <div className="mb-1.5 text-xs font-semibold uppercase tracking-[0.04em] text-[hsl(var(--muted-foreground))]">
                  {f.label}
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span
                    role="cell"
                    aria-label={`Before: ${typeof f.before === "string" ? f.before : ""}`}
                    className="min-w-0 flex-1 truncate rounded bg-[var(--color-danger-surface)] px-2 py-1 text-[var(--color-danger-text)] line-through"
                  >
                    {f.before}
                  </span>
                  <ArrowRight size={14} className="shrink-0 text-[hsl(var(--muted-foreground))]" aria-hidden="true" />
                  <span
                    role="cell"
                    aria-label={`After: ${typeof f.after === "string" ? f.after : ""}`}
                    className="min-w-0 flex-1 truncate rounded bg-[var(--color-success-surface)] px-2 py-1 font-medium text-[var(--color-success-text)]"
                  >
                    {f.after}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </DialogBody>
        <DialogFooter>
          <Button
            variant="ghost"
            onClick={() => {
              onCancel?.()
              onOpenChange(false)
            }}
          >
            Cancel
          </Button>
          <Button variant="orange" loading={confirming} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export { ConfirmationPreview }
