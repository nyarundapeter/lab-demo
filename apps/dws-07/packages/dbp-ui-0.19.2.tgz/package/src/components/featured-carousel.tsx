"use client";
import * as React from "react";
import { ChevronLeft, ChevronRight, TrendingUp } from "lucide-react";
import { CatalogCard } from "./catalog-card";
import { cn } from "../lib/cn";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface FeaturedCarouselProps {
  entityType: string;
  /** Small overline above the section title (e.g. "CURATED SELECTION"). */
  kicker?: string;
  title: string;
  lede?: string;
  /** Maximum number of featured items to fetch (default: 6). */
  limit?: number;
  /** Name of the entity field that equals `true` for featured items. */
  featuredField: string;
  cardFields: {
    title: string;
    description?: string;
    typeLabel?: string;
    status?: string;
    footerId?: string;
  };
  onCardClick?: (id: string) => void;
}

// ─── Internal helpers ─────────────────────────────────────────────────────────

function readField(data: Record<string, unknown>, field: string | undefined): string {
  if (!field) return "";
  const v = data[field];
  if (v === null || v === undefined) return "";
  return String(v);
}

// ─── Component ────────────────────────────────────────────────────────────────

export function FeaturedCarousel({
  entityType,
  kicker,
  title,
  lede,
  limit = 6,
  featuredField,
  cardFields,
  onCardClick,
}: FeaturedCarouselProps) {
  const [items, setItems] = React.useState<Array<{ id: string; data: Record<string, unknown> }>>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = React.useState(false);
  const [canScrollRight, setCanScrollRight] = React.useState(false);

  // ── Fetch featured items ──────────────────────────────────────────────────
  React.useEffect(() => {
    let cancelled = false;
    setIsLoading(true);

    const params = new URLSearchParams({
      [`filter[${featuredField}]`]: "true",
      limit: String(limit),
    });

    fetch(`/api/platform/data/entities/${encodeURIComponent(entityType)}?${params.toString()}`)
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error(`HTTP ${res.status}`))))
      .then((json) => {
        if (cancelled) return;
        const rows: Array<{ id: string; data: Record<string, unknown> }> =
          Array.isArray(json?.rows) ? json.rows : [];
        setItems(rows);
      })
      .catch(() => {
        if (!cancelled) setItems([]);
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [entityType, featuredField, limit]);

  // ── Scroll state tracking ─────────────────────────────────────────────────
  const updateScrollState = React.useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 4);
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  }, []);

  React.useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    updateScrollState();
    el.addEventListener("scroll", updateScrollState, { passive: true });
    const ro = new ResizeObserver(updateScrollState);
    ro.observe(el);
    return () => {
      el.removeEventListener("scroll", updateScrollState);
      ro.disconnect();
    };
  }, [updateScrollState, items]);

  const scrollBy = (direction: "left" | "right") => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollBy({ left: direction === "left" ? -360 : 360, behavior: "smooth" });
  };

  // ── Don't render if no items and not loading ──────────────────────────────
  if (!isLoading && items.length === 0) return null;

  return (
    <section
      className="bg-[var(--color-surface-content)] py-14 lg:py-20"
      aria-label={title}
    >
      <div className="mx-auto max-w-[1200px] px-5 md:px-8 lg:px-10">
        {/* Header row: kicker + title/lede on left, nav arrows on right */}
        <div className="mb-8 flex items-start justify-between gap-6">
          <div>
            {kicker && (
              <p className="dq-overline mb-3 text-[var(--color-secondary)]">{kicker}</p>
            )}
            <h2 className="text-[1.875rem] font-bold leading-tight tracking-tight text-[var(--color-text)] md:text-[2.25rem]">
              {title}
            </h2>
            {lede && (
              <p className="mt-2 text-[var(--color-text-secondary)]">{lede}</p>
            )}
          </div>
          <div className="flex shrink-0 items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => scrollBy("left")}
              disabled={!canScrollLeft}
              aria-label="Scroll left"
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-full border",
                "border-[var(--color-border)] transition-opacity",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
                canScrollLeft
                  ? "text-[var(--color-text)] hover:bg-[var(--color-surface-secondary)]"
                  : "cursor-not-allowed opacity-30",
              )}
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => scrollBy("right")}
              disabled={!canScrollRight}
              aria-label="Scroll right"
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-full border",
                "border-[var(--color-border)] transition-opacity",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
                canScrollRight
                  ? "text-[var(--color-text)] hover:bg-[var(--color-surface-secondary)]"
                  : "cursor-not-allowed opacity-30",
              )}
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Scroll container */}
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-2"
          style={{
            scrollSnapType: "x mandatory",
            scrollbarWidth: "none",
            msOverflowStyle: "none",
          }}
        >
          {isLoading
            ? Array.from({ length: 3 }).map((_, i) => (
                <div
                  key={i}
                  className="h-[220px] min-w-[320px] max-w-[360px] shrink-0 animate-pulse rounded-xl bg-[var(--color-border)]"
                  style={{ scrollSnapAlign: "start" }}
                />
              ))
            : items.map((item) => {
                const data = item.data as Record<string, unknown>;
                return (
                  <div
                    key={item.id}
                    className="relative min-w-[320px] max-w-[360px] shrink-0"
                    style={{ scrollSnapAlign: "start" }}
                  >
                    {/* TOP PICK badge — orange pill with trend icon */}
                    <span className="absolute left-3 top-3 z-10 inline-flex items-center gap-1 rounded-full bg-[var(--color-secondary)] px-2.5 py-1 text-xs font-bold uppercase tracking-[0.08em] text-white shadow-sm">
                      <TrendingUp className="h-3 w-3 shrink-0" aria-hidden="true" />
                      Top Pick
                    </span>
                    <CatalogCard
                      variant="catalog"
                      title={readField(data, cardFields.title)}
                      {...(readField(data, cardFields.description) ? { description: readField(data, cardFields.description) } : {})}
                      {...(readField(data, cardFields.typeLabel) ? { typeLabel: readField(data, cardFields.typeLabel) } : {})}
                      {...(readField(data, cardFields.status) ? { statusLabel: readField(data, cardFields.status) } : {})}
                      {...(readField(data, cardFields.footerId) ? { footerId: readField(data, cardFields.footerId) } : {})}
                      onClick={() => onCardClick?.(item.id)}
                      className="h-full"
                    />
                  </div>
                );
              })}
        </div>
      </div>
    </section>
  );
}
