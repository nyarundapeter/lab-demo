import * as React from "react"
import { cn } from "../lib/cn.js"

export interface PublicPageHeaderProps {
  /** Small overline above the title (e.g. "Contact"). */
  eyebrow?: string
  /** H1 title. */
  title: React.ReactNode
  /**
   * Inline meta row rendered directly under the title (plain text + separators —
   * NO pill badges; that pattern reads as AI slop). Use for category • tier lines.
   */
  meta?: React.ReactNode
  /** Lead paragraph under the meta row. */
  subtitle?: React.ReactNode
  /** Extra left-column content below the subtitle (e.g. an "Ideal for" line). */
  children?: React.ReactNode
  /**
   * Optional right-hand column (e.g. a price/benefit card). When present the band
   * becomes a 2-column grid on large screens.
   */
  aside?: React.ReactNode
  /** Render the faint blueprint grid backdrop. Default true. */
  grid?: boolean
  className?: string
}

/**
 * PublicPageHeader — archetype **A1**: the gray header band for public content /
 * detail / form pages (NOT the marketing landing hero, which is A2). It owns the
 * consistent surface (`--color-surface-secondary`), an optional faint blueprint
 * grid, the title scale, and the optional 2-column (title + aside) layout.
 *
 * Locked rules this component enforces by construction:
 *  - one consistent header scale across every public page;
 *  - never a back-link inside the header band (the shell nav owns navigation);
 *  - meta is plain text, never pill badges.
 *
 * Body sections rendered AFTER this band must use white (archetype A3) so the two
 * surfaces never blend. See docs/plans/2026-06-24-public-shell-layout-archetypes.md.
 */
export function PublicPageHeader({
  eyebrow,
  title,
  meta,
  subtitle,
  children,
  aside,
  grid = true,
  className,
}: PublicPageHeaderProps): React.ReactElement {
  const titleBlock = (
    <div className="min-w-0">
      {eyebrow && <p className="dq-overline text-[var(--color-secondary)]">{eyebrow}</p>}
      <h1
        className={cn(
          "text-[2.25rem] font-bold leading-[1.05] tracking-[-0.02em] text-[var(--color-primary)] md:text-[3rem]",
          eyebrow && "mt-4",
        )}
        data-testid="public-page-title"
      >
        {title}
      </h1>
      {meta && <div className="mt-4">{meta}</div>}
      {subtitle && (
        <p className="mt-5 max-w-[600px] text-lg leading-relaxed text-[var(--color-text-secondary)]">{subtitle}</p>
      )}
      {children}
    </div>
  )

  return (
    <section
      className={cn(
        "relative isolate overflow-hidden bg-[var(--color-surface-secondary)] px-5 pb-14 pt-14 md:px-8 lg:px-10",
        className,
      )}
      data-testid="public-page-header"
    >
      {grid && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 -z-10 [background-image:linear-gradient(to_right,rgba(3,15,53,0.035)_1px,transparent_1px),linear-gradient(to_bottom,rgba(3,15,53,0.035)_1px,transparent_1px)] [background-size:48px_48px] [mask-image:radial-gradient(120%_90%_at_15%_0%,black,transparent_75%)]"
        />
      )}
      <div className="mx-auto max-w-[1200px]">
        {aside ? (
          <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_380px]">
            {titleBlock}
            <div className="min-w-0">{aside}</div>
          </div>
        ) : (
          titleBlock
        )}
      </div>
    </section>
  )
}
