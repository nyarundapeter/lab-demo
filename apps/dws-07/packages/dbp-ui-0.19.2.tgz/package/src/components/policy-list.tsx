import * as React from "react"
import { Check } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface PolicyListItem {
  label: string
  met: boolean
}

export interface PolicyListProps extends React.HTMLAttributes<HTMLDivElement> {
  items: PolicyListItem[]
}

/**
 * PolicyList — password/policy checklist (identity-core.jsx:108-120).
 * Fully prop-driven `{label, met}[]` — no test/scoring logic owned here,
 * matching `StrengthMeter`'s split of that same rule set.
 */
function PolicyList({ items, className, ...props }: PolicyListProps) {
  return (
    <div className={cn("grid gap-1.5", className)} {...props}>
      {items.map((item, i) => (
        <div
          key={i}
          className={cn(
            "flex items-center gap-1.5 text-xs",
            item.met ? "text-[var(--color-success-text)]" : "text-[var(--color-text-muted)]",
          )}
        >
          <span
            className={cn(
              "flex h-[15px] w-[15px] shrink-0 items-center justify-center rounded-full border",
              item.met
                ? "border-[var(--color-success)] bg-[var(--color-success)]"
                : "border-[var(--color-border-default)]",
            )}
            aria-hidden="true"
          >
            {item.met && <Check className="h-2 w-2 text-white" strokeWidth={3} />}
          </span>
          {item.label}
        </div>
      ))}
    </div>
  )
}

export { PolicyList }
