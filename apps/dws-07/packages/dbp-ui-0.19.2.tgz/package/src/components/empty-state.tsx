import * as React from 'react'
import { Inbox, AlertTriangle } from 'lucide-react'
import { cn } from '../lib/cn.js'

interface EmptyStateActionObj {
  label: string
  onClick: () => void
}

function isActionObj(v: unknown): v is EmptyStateActionObj {
  return typeof v === 'object' && v !== null && 'label' in v && 'onClick' in v
}

export interface EmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Primary display text — takes precedence over `title` */
  headline?: string
  /** Legacy display text — kept for backward compatibility */
  title?: string
  description?: string
  /**
   * CTA slot. Accepts either:
   *  - An object `{ label, onClick }` which renders a styled button
   *  - Any ReactNode (backward-compatible slot)
   */
  action?: EmptyStateActionObj | React.ReactNode
  /** Icon node from lucide-react or any SVG */
  icon?: React.ReactNode
  /**
   * Visual tone. `"danger"` absorbs the former `ErrorState` component
   * (design-system de-dup strategy, `docs/plans/design-system-dedup-2026-07-25/
   * strategy.md` §3): danger icon-square tokens, danger-toned headline text,
   * `role="alert"`, and an `AlertTriangle` default icon instead of `Inbox`.
   * Defaults to `"neutral"` — the original `EmptyState` look, unchanged.
   */
  tone?: 'neutral' | 'danger'
}

export function EmptyState({
  headline,
  title,
  description,
  action,
  icon,
  tone = 'neutral',
  className,
  role,
  ...props
}: EmptyStateProps) {
  const isDanger = tone === 'danger'
  const displayText = headline ?? title ?? (isDanger ? 'Something went wrong' : 'Nothing here yet')

  return (
    <div
      role={role ?? (isDanger ? 'alert' : undefined)}
      className={cn(
        'flex flex-col items-center justify-center gap-3 py-16 px-6 text-center',
        className
      )}
      {...props}
    >
      <span
        className={cn(
          'flex h-12 w-12 items-center justify-center rounded-[var(--radius-card)]',
          isDanger
            ? 'bg-[var(--color-danger-surface)] text-[var(--color-danger-text)]'
            : 'bg-[var(--color-navy-50)] text-[var(--color-text-muted)]'
        )}
        aria-hidden="true"
      >
        {icon ?? (isDanger ? <AlertTriangle size={22} strokeWidth={1.5} /> : <Inbox size={22} strokeWidth={1.5} />)}
      </span>

      <div className="max-w-[260px]">
        <p
          className={cn(
            'text-sm font-semibold',
            isDanger ? 'text-[var(--color-danger-text)]' : 'text-[var(--color-text-primary)]'
          )}
        >
          {displayText}
        </p>
        {description && (
          <p className="mt-1 text-xs text-[var(--color-text-muted)] leading-relaxed">
            {description}
          </p>
        )}
      </div>

      {action && isActionObj(action) ? (
        <button
          type="button"
          onClick={action.onClick}
          className="mt-1 px-4 py-2 rounded-[var(--radius)] bg-[var(--color-primary)] text-white text-xs font-medium hover:opacity-90 focus-visible:outline-none"
        >
          {action.label}
        </button>
      ) : action ? (
        <div className="mt-1">{action as React.ReactNode}</div>
      ) : null}
    </div>
  )
}
