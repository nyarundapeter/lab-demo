"use client"
import * as React from "react"
import { Bold, Italic, Link2, List } from "lucide-react"
import { EditorContent, useEditor, type Editor } from "@tiptap/react"
import StarterKit from "@tiptap/starter-kit"
import Link from "@tiptap/extension-link"
import Placeholder from "@tiptap/extension-placeholder"
import { cn } from "../lib/cn.js"
import type { FieldState } from "./input.js"

/**
 * RichTextField — small toolbar (bold/italic/bullet-list/link), forms-fields.jsx:377-391.
 * Reuses `ActivityComposer`'s Tiptap v3 setup (`activity-composer.tsx`, ADR-0048's minimal
 * extension profile) rather than standing up a second editor integration — same
 * StarterKit-minus-headings/blockquote/codeBlock/horizontalRule + Link.configure profile,
 * without ActivityComposer's mention/tags/attachment chrome (form-builder's `rich-text` field
 * type is a plain description/notes control, not the activity-timeline composer). Value is the
 * editor's HTML string; a consumer wraps this in `@dbp/ui` `FormField` for label/helper/error.
 */
const toolbarButtonBase = cn(
  "inline-flex h-6 w-6 items-center justify-center rounded-[4px] transition-colors",
  "text-[var(--color-text-muted)] hover:bg-[var(--color-surface)] hover:text-[var(--color-text)]",
  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
)

function Toolbar({ editor }: { editor: Editor | null }) {
  if (!editor) return null
  return (
    <div className="flex items-center gap-0.5 border-b border-[var(--color-border)] bg-[var(--color-surface)]/40 p-1">
      <button
        type="button"
        aria-label="Bold"
        aria-pressed={editor.isActive("bold")}
        onClick={() => editor.chain().focus().toggleBold().run()}
        className={cn(toolbarButtonBase, editor.isActive("bold") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <Bold className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label="Italic"
        aria-pressed={editor.isActive("italic")}
        onClick={() => editor.chain().focus().toggleItalic().run()}
        className={cn(toolbarButtonBase, editor.isActive("italic") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <Italic className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label="Bullet list"
        aria-pressed={editor.isActive("bulletList")}
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        className={cn(toolbarButtonBase, editor.isActive("bulletList") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <List className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label="Link"
        aria-pressed={editor.isActive("link")}
        onClick={() => {
          const url = window.prompt("URL")
          if (url) editor.chain().focus().setLink({ href: url }).run()
          else editor.chain().focus().unsetLink().run()
        }}
        className={cn(toolbarButtonBase, editor.isActive("link") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <Link2 className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
    </div>
  )
}

export interface RichTextFieldProps {
  id?: string
  /** HTML string — the editor's `getHTML()` output. */
  value?: string | undefined
  onChange?: ((html: string) => void) | undefined
  placeholder?: string | undefined
  disabled?: boolean | undefined
  state?: FieldState | undefined
  "aria-invalid"?: boolean | undefined
  className?: string | undefined
}

const RichTextField = React.forwardRef<HTMLDivElement, RichTextFieldProps>(
  ({ id, value, onChange, placeholder = "Write a detailed description…", disabled, state = "default", "aria-invalid": ariaInvalid, className }, ref) => {
    // Set synchronously inside `onUpdate`, before `onChange` triggers the parent's
    // re-render — flags the resulting `value` prop change below as an echo of the
    // editor's own edit, not a genuinely external one.
    const isInternalUpdate = React.useRef(false)

    const editor = useEditor({
      extensions: [
        StarterKit.configure({ heading: false, blockquote: false, codeBlock: false, horizontalRule: false, link: false }),
        Link.configure({ openOnClick: false, autolink: true }),
        Placeholder.configure({ placeholder }),
      ],
      content: value ?? "",
      immediatelyRender: false,
      editable: !disabled,
      editorProps: {
        attributes: {
          id: id ?? "",
          role: "textbox",
          "aria-invalid": ariaInvalid || state === "error" ? "true" : "false",
          class: "min-h-[96px] px-3 py-2 text-sm text-[var(--color-text-primary)] outline-none [&_p]:m-0",
        },
      },
      onUpdate: ({ editor: ed }) => {
        isInternalUpdate.current = true
        onChange?.(ed.getHTML())
      },
    })

    React.useEffect(() => {
      if (!editor) return
      // An `onUpdate` echoes back here as a `value` prop change (parent's onChange
      // → its own re-render), but React's state update is async relative to
      // Tiptap's synchronous keystroke handling — mid-typing, `value` can be a
      // stale snapshot that lags the editor's live content by a keystroke or two.
      // Resyncing it back via `setContent` then stomps the newer content and
      // resets the cursor, dropping/reordering characters. Skip the resync when
      // this render was caused by the editor's own edit; only apply genuinely
      // external value changes (initial load, programmatic reset).
      if (isInternalUpdate.current) {
        isInternalUpdate.current = false
        return
      }
      if (value !== undefined && value !== editor.getHTML()) editor.commands.setContent(value, { emitUpdate: false })
      // eslint-disable-next-line react-hooks/exhaustive-deps -- only re-sync on external value changes, not every editor identity change
    }, [value])

    React.useEffect(() => {
      editor?.setEditable(!disabled)
    }, [disabled, editor])

    return (
      <div
        ref={ref}
        data-state={state !== "default" ? state : undefined}
        className={cn(
          "rounded-input border border-border-default bg-[var(--color-surface-content)] transition-colors",
          "focus-within:border-primary focus-within:[box-shadow:var(--focus-ring-primary)]",
          state === "error" && "border-danger focus-within:[box-shadow:var(--focus-ring-error)]",
          state === "warning" && "border-warning focus-within:[box-shadow:var(--focus-ring-warning)]",
          state === "success" && "border-success focus-within:[box-shadow:var(--focus-ring-success)]",
          disabled && "cursor-not-allowed opacity-50",
          className,
        )}
      >
        <Toolbar editor={editor} />
        <EditorContent editor={editor} />
      </div>
    )
  },
)
RichTextField.displayName = "RichTextField"

export { RichTextField }
