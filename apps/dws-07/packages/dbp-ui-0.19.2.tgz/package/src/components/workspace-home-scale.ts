/**
 * APP.F12 home section shared contract — type-scale rungs and vertical
 * rhythm shared by `workspace-home-hero.tsx`, `workspace-home-platform.tsx`,
 * `workspace-home-journey.tsx`, `workspace-home-closing.tsx`
 * (`docs/09-plans/app-f12-home-redo-2026-07-27/design-spec.md`).
 *
 * The four sections were originally built by two parallel lanes with no
 * shared contract, producing four different values for what should have
 * been one "card title" rung. This module is the single source of truth —
 * every section resolves a role to the same class string.
 *
 * | Role                | Rung                          | Used by                                   |
 * |----------------------|-------------------------------|--------------------------------------------|
 * | Eyebrow              | `SectionLabel size="2xs" tone="muted"` (12px/600, all-caps, letter-tracked) | Hero overline, Platform/Journey/Closing labels — identical props everywhere; Closing's coral variant is a `className` color override on the same component, never a different primitive. |
 * | Section heading (h2) | `text-3xl font-bold leading-tight tracking-tight` (30px/700) | Platform, Journey, Closing h2 |
 * | Lead card title      | `text-2xl font-semibold leading-[1.22] tracking-[-0.025em]` (24px/600) | Platform's single wide lead-feature card only — legitimately larger; it is the one "hero card" on the page, not a peer of the grid cards below it. |
 * | Card title           | `text-lg font-semibold leading-[1.22] tracking-[-0.025em]` (18px/600) | Platform capability cards, Journey step cards |
 * | Sub-card title       | `text-sm font-semibold leading-tight` (14px/600) | Closing outcome tiles — deliberately smaller than `cardTitleClass` (compact 4-up tile row) but always at least one rung above `eyebrowClass`/meta-label text (12px), never equal to it. |
 * | Body                 | `text-sm leading-[1.65]` (14px/400) | Card/tile descriptions |
 * | Meta label           | `font-mono text-xs uppercase tracking-[0.1em]` (12px) | Journey metric labels |
 * | Metric value          | `text-xl font-normal leading-none` (20px/400) | Journey stage/metric numerals — deliberately lighter than card titles (quieter "data readout" feel, design-spec §3) |
 * | Orb numeral          | `text-lg font-semibold` (18px/600), non-mono | Journey glass-orb stage digit (`01`–`04`) — 2026-07-28 ruling: `font-mono` at display scale read as off-system; mono stays reserved for small uppercase meta (chips, the `metaLabelClass` row above), never for a large standalone numeral. Sits on the `cardTitleClass` rung since it plays the same "headline digit" role. |
 *
 * Vertical rhythm: all four sections share one `sectionVerticalRhythm` step
 * (`py-10 sm:py-12 lg:py-14`, i.e. 40px/48px/56px). Each section contributes
 * one edge of the gap to its neighbour, so two adjacent sections stack to
 * one rhythm step, not two (2026-07-28 ruling — the previous 3-tier scale,
 * `py-16 sm:py-20 lg:py-24`, doubled to ~192px of dead space at the
 * boundary between two sections). Hero now consumes the same
 * `sectionVerticalRhythm` constant on its inner flex wrapper (rather than
 * inlining its own copy) so there is exactly one declared value — the
 * outer `<section>` still stays unpadded there so the absolutely-positioned
 * artwork/wash/glow layers (`inset-0` relative to the section) can bleed
 * full-width; every other section has no such full-bleed background layer,
 * so their padding lives directly on the outer `<section>`. The padding
 * *values* are identical in both cases — this is a structural necessity,
 * not a rhythm inconsistency.
 *
 * Shape/shadow/width consolidation (2026-07-27 polish pass): the four
 * sections previously carried five different radius systems, three
 * different shadow systems, two different content-width values (1240px vs
 * the shell's actual 1200px content box — see `landing-sections.tsx`), and
 * ~20 scattered arbitrary-pixel values. This module is now also the single
 * source of truth for those — every "genuine art-direction dimension"
 * (decorative wash/glow/orb sizing, section min-heights, card content
 * widths) is declared once below instead of repeated inline. Radii and
 * shadows use the token scale (`rounded-card`, `rounded-pill`, `shadow-sm`)
 * everywhere except the journey orb's organic-blob motif, which is a
 * deliberate, declared divergence (see `journeyOrbShapeClasses`).
 */

export const sectionVerticalRhythm = "px-5 py-10 sm:px-8 sm:py-12 lg:px-12 lg:py-14"

/** Content box width, matched to the shell's actual 1200px `main` measure
 * and to sibling public sections (`landing-sections.tsx`) — NOT the 1240px
 * previously used ad hoc by hero/closing. */
export const contentMaxWidthClass = "max-w-[1200px]"

/** Elevated hover-card shadow, built from tokens via `color-mix` (no raw
 * `rgba()`). Used by any card that lifts on hover. */
export const elevatedCardShadowClass =
  "shadow-[0_22px_46px_color-mix(in_srgb,var(--color-primary)_8%,transparent)]"

/** Same value as `elevatedCardShadowClass`, pre-fixed with the `hover:`
 * variant. Tailwind's JIT scanner needs the full `hover:shadow-[...]`
 * string present literally somewhere in scanned source — a runtime
 * string-concat of the variant + the base class would not be detected —
 * so this is declared as its own literal rather than composed. */
export const elevatedCardHoverShadowClass =
  "hover:shadow-[0_22px_46px_color-mix(in_srgb,var(--color-primary)_8%,transparent)]"

/** Same recipe as `elevatedCardShadowClass`, parameterised for the journey
 * card stack's scroll-driven depth (can't be a static class since the
 * opacity grows with scroll offset). */
export function journeyCardElevationShadow(depthPercent: number) {
  return `0 22px 46px color-mix(in srgb, var(--color-primary) ${3 + depthPercent}%, transparent)`
}

// ---- Hero ----
export const heroMinHeightClass = "min-h-[420px] sm:min-h-[480px] lg:min-h-[560px]"
export const heroContentMaxWidthClass = "max-w-[820px]"
export const heroGlowSizeClass = "size-[24vw] max-h-[420px] max-w-[420px]"
export const heroGlowPositionClass = "left-[41%] top-[21%]"

// ---- Platform ----
export const platformHeaderMaxWidthClass = "max-w-[720px]"
export const platformFeatureMinHeightClass = "min-h-[240px] sm:min-h-[240px]"
export const platformFeatureContentWidthClass = "sm:w-[59%]"
export const platformFeatureBodyMaxWidthClass = "max-w-[560px]"
export const platformCapabilityMinHeightClass = "min-h-[190px] sm:min-h-[210px]"
export const platformIconHoverLiftClass = "group-hover:-translate-y-[3px]"
export const platformCardHoverLiftClass = "hover:-translate-y-[5px]"

// ---- Journey ----
export const journeyCardMinHeightClass = "min-h-[307px]"
/** Soft pill around step badges (`STEP 01 · ALIGN`). */
export const journeySoftPillClass =
  "w-fit rounded-pill border border-[color-mix(in_srgb,var(--color-primary)_4%,transparent)] bg-[color-mix(in_srgb,var(--color-primary)_4%,transparent)] px-2.5 py-1"
/** Left content column — padding + min-height match the live card shell. */
export const journeyContentClass =
  "relative z-[4] flex w-full min-h-[307px] flex-col justify-start p-8"
/** Step title measure — `min(60%, 30rem)` keeps copy clear of the right orb. */
export const journeyCardTitleMaxWidthClass = "max-w-[min(60%,30rem)]"
/** Step body measure — `min(58%, 29rem)` pairs with the title measure above. */
export const journeyCardBodyMaxWidthClass = "max-w-[min(58%,29rem)]"
export const journeyOrbSizeClass = "h-[98px] w-[98px]"
export const journeyOrbFinalSizeClass = "h-[108px] w-[108px]"

/** Orb shape ladder — one shape per journey step (1-indexed). Steps 1 and 4
 * are literal circles (`rounded-full`); step 3 is a rotated square. Step 2's
 * organic-blob radius is a DELIBERATE divergence from the `rounded-card`
 * scale — it is decorative motif, not a card/panel, so it is declared here
 * rather than added to the radius token scale. */
export const journeyOrbShapeClasses: Record<1 | 2 | 3 | 4, string> = {
  1: "rounded-full",
  /* Discover (step 02) — organic blob + 18deg core rotation via --core-rotation */
  2: "rounded-[28%_72%_64%_36%/40%_36%_64%_60%]",
  3: "rounded-[22px] rotate-45",
  4: "rounded-full",
}

export const journeyOrbCoreRotation: Record<1 | 2 | 3 | 4, string> = {
  1: "0deg",
  2: "18deg",
  3: "0deg",
  4: "0deg",
}

export const journeyVisualKindClass: Record<1 | 2 | 3 | 4, string> = {
  1: "align-visual",
  2: "discover-visual",
  3: "deliver-visual",
  4: "improve-visual",
}

/** Orb "glass" inset highlight — built from tokens via `color-mix` (no raw
 * `rgba()`); the highlight uses the white content-surface role. */
export const journeyOrbInsetShadowClass =
  "shadow-[inset_0_2px_6px_color-mix(in_srgb,var(--color-surface-content)_60%,transparent),inset_0_-6px_10px_color-mix(in_srgb,var(--color-primary)_10%,transparent)]"

// ---- Closing ----
export const closingMinHeightClass = "min-h-[420px]"
export const closingHeadingMaxWidthClass = "max-w-[890px]"
export const closingBodyMaxWidthClass = "max-w-[720px]"
export const closingOutcomesMaxWidthClass = "max-w-[920px]"
export const closingOutcomeMinHeightClass = "min-h-[140px]"
/** Mono stage numeral above outcome title (`01`–`04`). */
export const closingOutcomeNumClass =
  "mb-3 font-mono text-xl font-semibold text-[var(--color-secondary)]"
/** Outcome card title — 16px/600, quieter than section headings. */
export const closingOutcomeTitleClass =
  "mb-2 text-base font-semibold leading-tight text-[var(--color-text-primary)]"

export const sectionHeadingClass =
  "text-3xl font-bold leading-tight tracking-tight text-[var(--color-text-primary)]"

export const leadCardTitleClass =
  "text-2xl font-semibold leading-[1.22] tracking-[-0.025em] text-[var(--color-text-primary)]"

export const cardTitleClass =
  "text-lg font-semibold leading-[1.22] tracking-[-0.025em] text-[var(--color-text-primary)]"

export const subCardTitleClass = "text-sm font-semibold leading-tight text-[var(--color-text-primary)]"

export const cardBodyClass = "text-sm leading-[1.65] text-[var(--color-text-muted)]"

export const metaLabelClass = "font-mono text-xs uppercase tracking-[0.1em] text-[var(--color-text-muted)]"

export const metricValueClass = "text-xl font-normal leading-none text-[var(--color-text-primary)]"

/** Journey glass-orb stage digit (`01`–`04`). Non-mono display numeral — see
 * the "Orb numeral" row above for the 2026-07-28 ruling that moved it off
 * `font-mono` (mono stays reserved for small uppercase meta text). */
export const orbNumeralClass = "text-lg font-semibold text-[var(--color-primary)]"
