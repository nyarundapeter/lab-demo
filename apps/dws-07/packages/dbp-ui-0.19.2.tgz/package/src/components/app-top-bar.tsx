import * as React from "react";
import { Bell, Settings, MoreVertical } from "lucide-react";
import { TopBarConfig } from "@dbp/contracts";
import { cn } from "../lib/cn";
import { ThemeToggle } from "./theme-toggle";
import { Popover, PopoverTrigger, PopoverContent } from "./popover";

export interface AppTopBarProps {
  config: TopBarConfig;
  /**
   * @deprecated The app lockup moved to the sidebar header (SidebarIdentity,
   * shell v3 anatomy, N27 ruling). No longer rendered by AppTopBar — kept
   * on the prop signature only for source compatibility with existing
   * callers. Pass `nav.identity` to the shell instead.
   */
  productCode?: string;
  /** @deprecated See `productCode`. */
  productName?: string;
  /** Dark variant (e.g. on a navy header). Defaults to light. */
  variant?: "light" | "dark";
  /**
   * Breadcrumb trail rendered in the bar's left section, immediately after
   * the sidebar toggle (shell v3 anatomy: toggle · breadcrumb, no app
   * identity lockup — that lives in the sidebar header now). Owns the
   * "where am I" wayfinding job that `PageHeader` previously duplicated as
   * its own row — pass this instead of a page-level breadcrumb, not in
   * addition to it.
   */
  breadcrumbSlot?: React.ReactNode;
  /** Slot for global search (e.g. <SearchBar />). Replaces the default search pill. */
  searchSlot?: React.ReactNode;
  /** Slot for a role / context selector rendered before the divider. */
  roleSlot?: React.ReactNode;
  /** Slot for the notification bell (e.g. <NotificationBell />). Replaces the default bell. */
  notificationSlot?: React.ReactNode;
  /** Slot for a settings affordance. Replaces the default settings icon button. */
  settingsSlot?: React.ReactNode;
  /** Slot for the user menu (e.g. avatar + name dropdown). Replaces the default avatar block. */
  userSlot?: React.ReactNode;
  /** User display name for the default avatar block (when no userSlot). */
  userName?: string;
  /** User role/sub-label for the default avatar block (when no userSlot). */
  userRole?: string;
  className?: string;
}

/** Derives up-to-two-letter initials from a display name. */
function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return (parts[0]![0]! + parts[parts.length - 1]![0]!).toUpperCase();
}

/**
 * AppTopBar — DQ prototype top bar (var(--shell-header-h), 52px).
 *
 * Anatomy (shell v3, N27 ruling): sidebar toggle (rendered by the shell,
 * outside this component) · breadcrumb on the left; on the right a search
 * pill (with ⌘K hint), optional role selector, a vertical divider, bell +
 * settings icon buttons, and a two-line avatar block. The app identity
 * lockup no longer lives here — see SidebarIdentity in the sidebar header.
 *
 * Controls stay 32px (icon buttons/inputs, matching the design-run-pack
 * reference); the 52px bar gives them 10px of breathing room top and bottom
 * (raised from 44px on Sharavi's 2026-07-17 "squished" feedback).
 *
 * Slot-driven and backward compatible: pass `searchSlot` / `notificationSlot` /
 * `userSlot` to override the corresponding default; `config.showSearch` /
 * `showNotifications` / `showUser` gate each region as before.
 */
export function AppTopBar({
  config,
  productCode,
  productName,
  variant = "light",
  breadcrumbSlot,
  searchSlot,
  roleSlot,
  notificationSlot,
  settingsSlot,
  userSlot,
  userName,
  userRole,
  className,
}: AppTopBarProps) {
  void productCode;
  void productName;
  const dark = variant === "dark";

  const iconBtn = cn(
    "flex h-[var(--shell-control-h)] w-[var(--shell-control-h)] shrink-0 items-center justify-center rounded-button transition-colors",
    "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
    dark
      ? "text-white hover:bg-white/10"
      : "text-[var(--color-text-primary)] hover:bg-surface"
  );

  return (
    <header
      style={{ height: "var(--shell-header-h)" }}
      className={cn(
        "flex w-full items-center justify-between gap-3 overflow-hidden px-4 md:px-6",
        dark
          ? "bg-transparent"
          : "bg-[var(--color-surface-content)] border-b border-[var(--color-border-subtle)]",
        className
      )}
    >
      {/* LEFT: breadcrumb only — the app identity lockup moved to the sidebar
          header (SidebarIdentity, shell v3 anatomy, N27 ruling). Shrinks
          freely so right-side controls always fit; the `gap-3` on the header
          guarantees breathing room between the truncated trail and the
          controls cluster even when the bar is fully cramped (DR-4). */}
      <div className="flex min-w-0 shrink items-center gap-3">
        {breadcrumbSlot && (
          <span className="flex min-w-0 items-center">{breadcrumbSlot}</span>
        )}
      </div>

      {/* RIGHT: controls */}
      <div className="flex min-w-0 shrink-0 items-center gap-3">
        {config.showSearch &&
          (searchSlot ?? (
            <button
              type="button"
              className={cn(
                "hidden h-[var(--shell-control-h)] w-52 items-center gap-2 rounded-button border-[1.5px] px-3 text-sm transition-colors md:flex xl:w-64",
                "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                dark
                  ? "border-white/15 bg-white/5 text-white/70 hover:bg-white/10"
                  : "border-[var(--color-border-default)] bg-[var(--color-surface-content)] text-[var(--color-text-muted)] hover:bg-[var(--color-navy-50)]"
              )}
              aria-label="Open global search"
            >
              <SearchGlyph className="h-4 w-4 shrink-0" />
              <span className="flex-1 text-left">Global search…</span>
              <kbd className="hidden h-5 items-center gap-0.5 rounded border border-[var(--color-border-strong)] bg-[var(--color-surface-content)] px-1.5 font-mono text-xs font-medium text-[var(--color-text-muted)] sm:inline-flex">
                <span className="text-xs">⌘</span>K
              </kbd>
            </button>
          ))}

        {roleSlot}

        {(config.showNotifications || config.showUser || settingsSlot) && (
          <div
            aria-hidden
            className={cn(
              "mx-1 h-6 w-px",
              dark ? "bg-white/15" : "bg-[var(--color-border-subtle)]"
            )}
          />
        )}

        {/* D5 — below `sm` there is no room for identity + hamburger + 3
            icon controls + avatar; the page title is the one thing that
            cannot be recovered from anywhere else on the page (ADR-0052 /
            Amendment D-2 removed the page-level PageHeader on the strength
            of the top bar owning that job), so it wins the space. Theme,
            notifications, and settings collapse into a single overflow
            trigger; the hamburger (rendered by the shell, outside this
            component) and the avatar/account chip below always stay
            inline — they're either irreplaceable navigation or the identity
            control users look for first. Search already collapses to its
            own icon below `xl` (see searchSlot above) and needs no further
            change here. */}
        <div className="hidden items-center gap-3 sm:flex">
          <ThemeToggle />

          {config.showNotifications &&
            (notificationSlot ?? (
              <button type="button" className={iconBtn} aria-label="Notifications">
                <Bell size={17} strokeWidth={1.5} />
              </button>
            ))}

          {settingsSlot ?? (
            <button type="button" className={iconBtn} aria-label="Settings">
              <Settings size={17} strokeWidth={1.5} />
            </button>
          )}
        </div>

        {(config.showNotifications || settingsSlot) && (
          <div className="sm:hidden">
            <Popover>
              <PopoverTrigger asChild>
                <button type="button" className={iconBtn} aria-label="More actions">
                  <MoreVertical size={17} strokeWidth={1.5} />
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="flex w-auto min-w-40 flex-col gap-1 p-1">
                <ThemeToggle className="h-auto w-full justify-start gap-2 rounded-[var(--radius-button)] px-2 py-1.5" />
                {config.showNotifications &&
                  (notificationSlot ?? (
                    <button
                      type="button"
                      className="flex w-full items-center gap-2 rounded-[var(--radius-button)] px-2 py-1.5 text-sm text-[var(--color-text-primary)] transition-colors hover:bg-surface"
                      aria-label="Notifications"
                    >
                      <Bell size={17} strokeWidth={1.5} />
                      <span>Notifications</span>
                    </button>
                  ))}
                {settingsSlot ?? (
                  <button
                    type="button"
                    className="flex w-full items-center gap-2 rounded-[var(--radius-button)] px-2 py-1.5 text-sm text-[var(--color-text-primary)] transition-colors hover:bg-surface"
                    aria-label="Settings"
                  >
                    <Settings size={17} strokeWidth={1.5} />
                    <span>Settings</span>
                  </button>
                )}
              </PopoverContent>
            </Popover>
          </div>
        )}

        {config.showUser &&
          (userSlot ?? (
            <div
              className={cn(
                "flex items-center gap-2.5 border-l pl-3",
                dark ? "border-white/15" : "border-[var(--color-border-subtle)]"
              )}
            >
              <div
                className={cn(
                  "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold",
                  // keep: dark-mode branch is a light surface + brand-accent
                  // monogram (deliberate colored text), not a label — mirrors
                  // the light branch's brand-bg/white-text avatar treatment.
                  dark ? "bg-[var(--color-surface-content)] text-primary" : "bg-primary text-white"
                )}
                aria-hidden
              >
                {initials(userName ?? config.appName)}
              </div>
              {(userName || userRole) && (
                <div className="hidden min-w-0 lg:block">
                  {userName && (
                    <div
                      className={cn(
                        "max-w-36 truncate text-xs font-bold",
                        dark ? "text-white" : "text-[var(--color-text-primary)]"
                      )}
                    >
                      {userName}
                    </div>
                  )}
                  {userRole && (
                    <div
                      className={cn(
                        "max-w-36 truncate text-xs",
                        dark ? "text-[var(--color-navy-200)]" : "text-[var(--color-text-muted)]"
                      )}
                    >
                      {userRole}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
      </div>
    </header>
  );
}

/** Inline magnifier glyph (lucide Search at stroke 1.5). */
function SearchGlyph({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
}
