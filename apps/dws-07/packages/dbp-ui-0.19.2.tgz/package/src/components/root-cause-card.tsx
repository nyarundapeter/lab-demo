import * as React from "react"
import { Check, FolderPlus, Star } from "lucide-react"
import type { AiConfidenceLevel } from "@dbp/contracts"
import { AiSurface, AiSurfaceFacet } from "./ai-surface.js"
import { AiConfidence } from "./ai-confidence.js"
import { Advisory } from "./advisory.js"
import { FeedbackControl } from "./feedback-control.js"
import type { AiSource } from "./source-row.js"
import { Button } from "./button.js"
import { SectionLabel } from "./section-label.js"
import { cn } from "../lib/cn.js"

export interface RootCauseHypothesis {
  cause: React.ReactNode
  confidence: AiConfidenceLevel
  support: React.ReactNode[]
  contradicting: React.ReactNode[]
  validate: React.ReactNode
  sources?: AiSource[]
}

export interface RootCauseCardData {
  problem: React.ReactNode
  hypotheses: RootCauseHypothesis[]
}

export interface RootCauseCardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  data: RootCauseCardData
  onCreateInvestigation?: (index: number) => void
}

/**
 * AI root-cause hypotheses card — fully prop-driven, no internal state
 * (ai-example-dashboard/ai/cards.jsx:355-390). Hypotheses are ranked
 * candidates, never a confirmed cause (`Advisory` footer).
 */
function RootCauseCard({ data, onCreateInvestigation, className, ...props }: RootCauseCardProps) {
  return (
    <AiSurface
      label="generated"
      title="Root-cause analysis"
      meta={<span>{data.problem}</span>}
      foot={
        <>
          <Advisory>Hypotheses — not a confirmed cause</Advisory>
          <span className="ml-auto" />
          <FeedbackControl compact />
        </>
      }
      className={cn(className)}
      {...props}
    >
      <div className="flex flex-col gap-2.5">
        {data.hypotheses.map((h, i) => (
          <div
            key={i}
            className={cn(
              "rounded-[var(--radius-card)] border bg-[var(--color-surface-content)] p-3.5",
              i === 0 ? "border-[hsl(var(--ai))]" : "border-[var(--color-border-default)]",
            )}
          >
            <div className="mb-2 flex items-center gap-2">
              <SectionLabel tone="muted" className="text-xs">
                Hypothesis {i + 1}
              </SectionLabel>
              <AiConfidence level={h.confidence} inline />
              {i === 0 && (
                <span className="ml-auto inline-flex items-center gap-1 rounded-pill bg-[hsl(var(--ai-soft))] px-2 py-0.5 text-xs font-medium text-[hsl(var(--ai-strong))]">
                  <Star size={11} className="fill-current" aria-hidden="true" />
                  Most supported
                </span>
              )}
            </div>
            <div className="mb-2 text-sm font-semibold text-[var(--color-text)]">{h.cause}</div>
            <AiSurfaceFacet label="Supporting patterns">
              <ul className="m-0 flex list-disc flex-col gap-1 pl-4 marker:text-[hsl(var(--ai))]">
                {h.support.map((s, j) => (
                  <li key={j}>{s}</li>
                ))}
              </ul>
            </AiSurfaceFacet>
            <div className="my-2 border-t border-[var(--color-border-subtle)]" />
            <AiSurfaceFacet label="Contradicting evidence" tone="var(--color-text-muted)">
              <ul className="m-0 flex list-disc flex-col gap-1 pl-4 text-[hsl(var(--muted-foreground))] marker:text-[var(--color-text-muted)]">
                {h.contradicting.map((s, j) => (
                  <li key={j}>{s}</li>
                ))}
              </ul>
            </AiSurfaceFacet>
            <div className="mb-2.5 flex items-center gap-2 rounded-[8px] bg-[hsl(var(--ai-soft)/0.6)] px-2.5 py-2 text-xs">
              <Check size={13} className="text-[hsl(var(--ai))]" aria-hidden="true" />
              <span>
                <strong>Suggested validation:</strong> {h.validate}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {h.sources && h.sources.length > 0 && (
                <p className="m-0 text-xs leading-snug text-[var(--color-text-muted)]">
                  <span className="font-medium">Sources: </span>
                  {h.sources.map((s) => s.title).join(" · ")}
                </p>
              )}
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="ml-auto h-6 gap-1 px-2 text-xs"
                onClick={() => onCreateInvestigation?.(i)}
              >
                <FolderPlus size={12} aria-hidden="true" />
                Create investigation
              </Button>
            </div>
          </div>
        ))}
      </div>
    </AiSurface>
  )
}

export { RootCauseCard }
