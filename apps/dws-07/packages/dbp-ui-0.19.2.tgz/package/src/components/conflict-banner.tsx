import * as React from "react";
import { Users, RefreshCw, Copy } from "lucide-react";
import { Alert } from "./alert.js";
import { Button } from "./button.js";

/**
 * ConflictBanner — SP-DATA-PATTERNS / spec-ps-data-revisions-2026-07-17.md §5.
 *
 * Renders the "someone else changed this record" conflict surface: who
 * changed it, when, a field-level diff of `mine` vs `theirs`, and the three
 * named resolution actions (refresh / overwrite / saveAsNew). Component seam
 * only — no auto-merge, no CRDT; the consumer picks one action.
 *
 * Anatomy per the overlay reference
 * (`docs/03-features/specs/claude-design-briefs/design-run-pack-2026-07-12/_outputs/overlay-system/overlay-states.jsx`
 * `ConflictView`).
 */

export type ConflictResolveAction = "refresh" | "overwrite" | "saveAsNew";

export type ConflictFieldDiff = {
  field: string;
  label: string;
  mine: string;
  theirs: string;
};

export interface ConflictBannerProps {
  /** Who changed the record, e.g. "Priya Shah". */
  updatedByLabel: string;
  /** When the conflicting change happened, e.g. "12s ago" or an ISO string. */
  updatedAtLabel: string;
  /** Field-level diff rows — which fields differ between `mine` and `theirs`. */
  fields: ConflictFieldDiff[];
  /** Whether the current user holds the update ability needed to overwrite. */
  canOverwrite?: boolean;
  /** Whether "save as new" is a valid domain concept for this entity type. Off by default (spec §5). */
  allowSaveAsNew?: boolean;
  onResolve: (action: ConflictResolveAction) => void;
}

export function ConflictBanner({
  updatedByLabel,
  updatedAtLabel,
  fields,
  canOverwrite = false,
  allowSaveAsNew = false,
  onResolve,
}: ConflictBannerProps) {
  return (
    <div
      data-testid="conflict-banner"
      className="overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-warning-border)]"
    >
      <Alert
        tone="warning"
        icon={<Users size={16} strokeWidth={1.5} aria-hidden="true" />}
        className="rounded-none border-0 border-b border-[var(--color-warning-border)]"
      >
        <strong>{updatedByLabel} changed this record {updatedAtLabel}</strong>, while you were
        editing. {fields.length} field{fields.length === 1 ? "" : "s"} differ from what you have.
      </Alert>

      {fields.length > 0 && (
        <div className="divide-y divide-[var(--color-border-subtle)] px-3.5">
          {fields.map((f) => (
            <div key={f.field} className="flex items-center justify-between gap-3 py-2 text-xs" data-testid={`conflict-field-${f.field}`}>
              <span className="font-medium text-[var(--color-text-primary)]">{f.label}</span>
              <span className="flex items-center gap-2 text-[var(--color-text-secondary)]">
                <span>yours: <strong>{f.mine}</strong></span>
                <span aria-hidden="true">→</span>
                <span className="text-[var(--color-warning-text)]">theirs: <strong>{f.theirs}</strong></span>
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="flex flex-wrap gap-2 border-t border-[var(--color-warning-border)] px-3.5 py-2.5">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onResolve("refresh")}
          data-testid="conflict-resolve-refresh"
        >
          <RefreshCw size={12} strokeWidth={1.5} aria-hidden="true" />
          Refresh with theirs
        </Button>
        <Button
          variant="outline"
          size="sm"
          disabled={!canOverwrite}
          title={canOverwrite ? undefined : "You don't have permission to overwrite this record"}
          onClick={() => onResolve("overwrite")}
          data-testid="conflict-resolve-overwrite"
        >
          Overwrite with mine
        </Button>
        {allowSaveAsNew && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => onResolve("saveAsNew")}
            data-testid="conflict-resolve-save-as-new"
          >
            <Copy size={12} strokeWidth={1.5} aria-hidden="true" />
            Save as new
          </Button>
        )}
      </div>
    </div>
  );
}
