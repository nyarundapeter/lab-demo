import * as React from "react"
import type { AiControlLevel } from "@dbp/contracts"
import { Badge, type BadgeProps } from "./badge.js"
import { cn } from "../lib/cn.js"

const CTRL_LABEL: Record<AiControlLevel, string> = {
  1: "Inform",
  2: "Recommend",
  3: "Prepare",
  4: "Automate",
}

/**
 * Control-level -> Badge tone mapping (design-system de-dup Wave 1.A,
 * DS-R2/R3, strategy.md §5 W1.A). CtrlBadge used to carry its own bespoke cva
 * with 6 literal numeric-triple colour values; every level now resolves to
 * an existing Badge tone instead of minting new colours. Level 2 ("Recommend")
 * keeps the exact former AI-provenance hue (Badge's `ai` tone already wires
 * the same `--ai-soft`/`--ai-strong`/`--ai-border` vars this component used
 * directly). Levels 1/3/4 are mapped onto the closest existing tone rather
 * than the former one-off literals — accepted visual delta: level 3
 * ("Prepare") moves from a bespoke amber to Badge's `warning` tone (near-
 * identical amber family) and level 4 ("Automate") moves from a bespoke
 * violet to Badge's `testing` tone (closest existing purple family); level 1
 * ("Inform") moves from a bespoke light-grey to Badge's `neutral` tone.
 */
const CTRL_TONE: Record<AiControlLevel, NonNullable<BadgeProps["tone"]>> = {
  1: "neutral",
  2: "ai",
  3: "warning",
  4: "testing",
}

export interface CtrlBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** 4-rung control ladder: 1=Inform, 2=Recommend, 3=Prepare, 4=Automate. */
  level?: AiControlLevel
  /** Show the "L1".."L4" numeric prefix. Defaults to true. */
  showNum?: boolean
  /**
   * Orthogonal "human decision only" flag (NOT a 5th ladder rung — see
   * AiHumanDecisionOnlySchema in @dbp/contracts). When true, renders an
   * additional "Human decision only" qualifier alongside the control level.
   */
  humanDecisionOnly?: boolean
}

/** Control-level badge — Inform / Recommend / Prepare / Automate. */
function CtrlBadge({
  className,
  level = 1,
  showNum = true,
  humanDecisionOnly = false,
  children,
  ...props
}: CtrlBadgeProps) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <Badge
        tone={CTRL_TONE[level]}
        size="sm"
        className={cn("h-5 gap-1.5 tracking-[0.02em]", className)}
        title={`Control level ${level}: ${CTRL_LABEL[level]}`}
        {...props}
      >
        {showNum && <span className="text-xs opacity-75">L{level}</span>}
        {children ?? CTRL_LABEL[level]}
      </Badge>
      {humanDecisionOnly && (
        // Renders pill-shaped (Badge's default radius) rather than the
        // former bespoke rounded-rect chip — accepted delta, see file-level
        // comment above.
        <Badge tone="danger" size="sm" className="h-5 font-semibold">
          Human decision only
        </Badge>
      )}
    </span>
  )
}

export { CtrlBadge, CTRL_LABEL, CTRL_TONE }
