import * as React from "react";
import { ChevronDown } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Popover, PopoverTrigger, PopoverContent } from "./popover.js";
import { cn } from "../lib/cn.js";

export interface FilterPillPopoverProps {
  label: string;
  icon?: LucideIcon;
  /** Marks the trigger pill as active, mirroring `FilterBar`'s chip active style. */
  active?: boolean;
  width?: number;
  align?: "start" | "end";
  children: React.ReactNode;
  className?: string;
}

/**
 * Pill-triggered popover (overlay-popovers.jsx "Mini form" variant, e.g.
 * "Assign owner") — extends `filter-bar.tsx`'s chip visual language
 * (rounded-pill, active border-primary/bg-navy-50) into a popover-anchored
 * control. `FilterBar` itself only supports a single-active radio chip; this
 * is the popover-driven complement for a control that needs more than a
 * label toggle (a search+list, a short field, etc.) inline in a filter row.
 */
export function FilterPillPopover({
  label,
  icon: Icon,
  active = false,
  width = 260,
  align = "start",
  children,
  className,
}: FilterPillPopoverProps) {
  const [open, setOpen] = React.useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-pressed={active}
          className={cn(
            "inline-flex h-8 items-center gap-1.5 rounded-pill border px-3 text-xs font-semibold whitespace-nowrap transition-colors",
            active
              ? "border-primary bg-[var(--color-navy-50)] text-[var(--color-text-primary)]"
              : "border-[var(--color-border-default)] bg-[var(--color-surface-content)] text-[var(--color-text-secondary)] hover:border-primary hover:text-[var(--color-text-primary)]",
            className,
          )}
        >
          {Icon && <Icon size={13} aria-hidden="true" />}
          {label}
          <ChevronDown size={12} aria-hidden="true" />
        </button>
      </PopoverTrigger>
      <PopoverContent align={align} style={{ width }} className="p-3">
        {children}
      </PopoverContent>
    </Popover>
  );
}
