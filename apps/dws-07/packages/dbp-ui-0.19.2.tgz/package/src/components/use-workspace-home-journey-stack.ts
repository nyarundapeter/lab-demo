"use client";

import * as React from "react"

/**
 * useWorkspaceHomeJourneyStack — sticky card-stack scroll choreography for
 * `WorkspaceHomeJourney` (design-spec §3 "Distinctive features"). Ports the
 * original `use-home-motion.ts` `useWorkspaceHomeJourneyStack` hook's covered-depth math
 * onto CSS custom properties, reading the current shell's real sticky-offset
 * token (`--shell-header-h`, `packages/shared/design-tokens/base.css`)
 * instead of the original's hardcoded `|| 68` fallback, and setting styles
 * via React state (re-render) rather than raw `element.style.setProperty`
 * writes in the scroll listener.
 *
 * Desktop-only (`min-width: 761px`) and fully disabled under
 * `prefers-reduced-motion: reduce` — in both cases every card's transform
 * vars are cleared and depth is 0.
 */
export interface JourneyStackOffsets {
  /** CSS transform/shadow vars for a single stack card, index-keyed. */
  scale: number
  shiftPx: number
  depth: number
}

const STICKY_GAP_PX = 16

function isEligible(): boolean {
  if (typeof window === "undefined") return false
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
  const desktop = window.matchMedia("(min-width: 761px)").matches
  return desktop && !reducedMotion
}

export function useWorkspaceHomeJourneyStack(count: number): {
  refs: React.RefObject<HTMLLIElement | null>[]
  offsets: JourneyStackOffsets[]
} {
  const refs = React.useRef(
    Array.from({ length: count }, () => React.createRef<HTMLLIElement | null>())
  ).current
  const [offsets, setOffsets] = React.useState<JourneyStackOffsets[]>(
    Array.from({ length: count }, () => ({ scale: 1, shiftPx: 0, depth: 0 }))
  )

  React.useEffect(() => {
    if (!isEligible()) return

    let rafId = 0
    const compute = () => {
      const shellHeaderH =
        parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--shell-header-h")) || 52

      const next = refs.map((_, index) => {
        let covered = 0
        for (let later = index + 1; later < refs.length; later++) {
          const laterEl = refs[later]?.current
          if (!laterEl) continue
          const laterStickyTop = shellHeaderH + STICKY_GAP_PX * (later + 1)
          const rect = laterEl.getBoundingClientRect()
          if (Math.abs(rect.top - laterStickyTop) <= 2 || rect.top <= laterStickyTop) {
            covered += 1
          }
        }
        return {
          scale: 1 - 0.04 * covered,
          shiftPx: 8 * covered,
          depth: covered,
        }
      })
      setOffsets(next)
    }

    const onScrollOrResize = () => {
      cancelAnimationFrame(rafId)
      rafId = requestAnimationFrame(compute)
    }

    compute()
    window.addEventListener("scroll", onScrollOrResize, { passive: true })
    window.addEventListener("resize", onScrollOrResize, { passive: true })
    return () => {
      cancelAnimationFrame(rafId)
      window.removeEventListener("scroll", onScrollOrResize)
      window.removeEventListener("resize", onScrollOrResize)
    }
    // refs array identity is stable for the component's lifetime (count is fixed)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [count])

  return { refs, offsets }
}