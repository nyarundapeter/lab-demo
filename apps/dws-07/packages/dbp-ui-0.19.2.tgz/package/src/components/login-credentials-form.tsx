"use client"
import * as React from "react"
import { cn } from "../lib/cn"
import { FieldLabel } from "./field-label"

export interface LoginSeedUser {
  label: string
  email: string
}

export interface LoginCredentialsFormProps {
  /** Called with the entered credentials on submit. */
  onSubmit: (credentials: { email: string; password: string }) => void
  /** Submission in flight — disables the submit button. */
  loading?: boolean
  /** Error message rendered above the submit button. */
  error?: string | null
  /** Demo/seed accounts — clicking one prefills the form. Omit to hide the section. */
  seedUsers?: readonly LoginSeedUser[]
  /** Password prefilled when a seed user is selected; shown in the demo-accounts hint. */
  seedPassword?: string
  className?: string
}

/**
 * Email + password credentials form for (public)/login pages — owns the form
 * chrome (labels, inputs, error alert, submit, optional demo-account
 * prefill) so page files stay pure declarations per ADR-0035 (raw <form>
 * belongs in @dbp/ui, not in a page file). Pairs with `LoginPage` +
 * `MicrosoftSignInButton`.
 */
export function LoginCredentialsForm({
  onSubmit,
  loading = false,
  error,
  seedUsers,
  seedPassword,
  className,
}: LoginCredentialsFormProps) {
  const [email, setEmail] = React.useState("")
  const [password, setPassword] = React.useState("")

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    onSubmit({ email, password })
  }

  function selectSeedUser(seedEmail: string) {
    setEmail(seedEmail)
    if (seedPassword) setPassword(seedPassword)
  }

  const inputStyle: React.CSSProperties = {
    borderRadius: "var(--radius-input)",
    border: "1px solid var(--color-border)",
    backgroundColor: "var(--color-background)",
    color: "var(--color-text)",
  }

  return (
    <div className={cn(className)}>
      <form onSubmit={handleSubmit} className="space-y-4" data-testid="login-form">
        <div>
          <FieldLabel htmlFor="email" className="normal-case text-sm font-medium tracking-normal mb-1">
            Email
          </FieldLabel>
          <input
            id="email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2 text-sm focus:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
            style={inputStyle}
            placeholder="your@email.example"
            data-testid="login-email"
          />
        </div>
        <div>
          <FieldLabel htmlFor="password" className="normal-case text-sm font-medium tracking-normal mb-1">
            Password
          </FieldLabel>
          <input
            id="password"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-3 py-2 text-sm focus:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
            style={inputStyle}
            placeholder="••••••••"
            data-testid="login-password"
          />
        </div>
        {error && (
          <div
            role="alert"
            className="rounded px-3 py-2 text-sm"
            style={{
              border: "1px solid var(--color-danger-border)",
              backgroundColor: "var(--color-danger-surface)",
              color: "var(--color-danger-text)",
            }}
            data-testid="login-error"
          >
            {error}
          </div>
        )}
        <button
          type="submit"
          disabled={loading}
          className="w-full px-4 py-2 text-sm font-medium text-white transition hover:opacity-90 focus:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)] disabled:cursor-not-allowed disabled:opacity-60"
          style={{ borderRadius: "var(--radius-button)", backgroundColor: "var(--color-primary)" }}
          data-testid="login-submit"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>

      {seedUsers && seedUsers.length > 0 && (
        <div className="mt-6 border-t pt-4" style={{ borderColor: "var(--color-border)" }}>
          <p
            className="mb-2 font-mono uppercase tracking-[0.16em]"
            style={{ fontSize: "10px", color: "var(--color-text-disabled)" }}
          >
            Demo accounts{seedPassword ? ` · password: ${seedPassword}` : ""}
          </p>
          <div className="space-y-1">
            {seedUsers.map((u) => (
              <button
                key={u.email}
                type="button"
                onClick={() => selectSeedUser(u.email)}
                className="w-full rounded px-2 py-1.5 text-left text-xs font-medium focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
                style={{ color: "var(--color-primary)" }}
                data-testid={`seed-user-${u.email}`}
              >
                {u.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
