import * as React from "react"
import { Clock, UserCog } from "lucide-react"
import { Button } from "./button.js"
import { Badge } from "./badge.js"
import { InfoCard } from "./info-card.js"

/**
 * Escalation card (WFL-10). Reference: wf-status.jsx:252-263 — SLA-triggered
 * vs manually-raised escalations, composed from InfoCard (tone="warning")
 * exactly as the reference does. Previously "escalation" was only a nav item
 * (manage-work/escalations → generic entity-list); this is the missing
 * record-level pattern surfacing *why* an item escalated and to whom.
 */
export type EscalationVariant = "sla" | "manual"

export interface EscalationCardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant: EscalationVariant
  title: string
  detail: string
  escalatedTo?: string
  when: string
  onResolve?: () => void
}

const VARIANT_LABEL: Record<EscalationVariant, string> = {
  sla: "SLA escalation",
  manual: "Manual escalation",
}

export function EscalationCard({
  variant,
  title,
  detail,
  escalatedTo,
  when,
  onResolve,
  className,
  ...props
}: EscalationCardProps) {
  const Icon = variant === "sla" ? Clock : UserCog
  return (
    <InfoCard
      tone="warning"
      icon={Icon}
      title={VARIANT_LABEL[variant]}
      badge={<span className="text-xs text-[var(--color-text-muted)]">{when}</span>}
      {...(onResolve
        ? {
            actions: (
              <Button type="button" variant="outline" size="sm" onClick={onResolve} data-testid="escalation-resolve-button">
                Resolve
              </Button>
            ),
          }
        : {})}
      className={className}
      data-testid="escalation-card"
      data-variant={variant}
      {...props}
    >
      <p className="text-sm font-medium text-[var(--color-text)]">{title}</p>
      <p className="mt-0.5 text-xs leading-relaxed text-[var(--color-text-muted)]">{detail}</p>
      {escalatedTo && (
        <Badge tone="warning" size="sm" className="mt-2.5 w-fit">
          Escalated to {escalatedTo}
        </Badge>
      )}
    </InfoCard>
  )
}
