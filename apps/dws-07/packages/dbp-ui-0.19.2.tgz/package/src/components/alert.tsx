import * as React from "react"
import { Info, CheckCircle, AlertTriangle, XCircle, X } from "lucide-react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn.js"

const alertVariants = cva(
  [
    "relative flex items-start gap-3",
    "rounded-[var(--radius-card)]",
    "border px-4 py-3.5",
    "text-sm",
  ].join(" "),
  {
    variants: {
      tone: {
        info:    "border-[var(--color-info-border)]    bg-[var(--color-info-surface)]    text-[var(--color-info-text)]",
        success: "border-[var(--color-success-border)] bg-[var(--color-success-surface)] text-[var(--color-success-text)]",
        warning: "border-[var(--color-warning-border)] bg-[var(--color-warning-surface)] text-[var(--color-warning-text)]",
        danger:  "border-[var(--color-danger-border)]  bg-[var(--color-danger-surface)]  text-[var(--color-danger-text)]",
        /* Consolidated tone family (2026-07-17) — notification ledger's "critical"
         * (distinct from danger). See
         * docs/03-features/specs/tone-family-consolidation-2026-07-17.md. */
        critical: "border-[var(--color-critical-border)] bg-[var(--color-critical-surface)] text-[var(--color-critical-text)]",
      },
      variant: {
        /* Banner's filled/critical style — solid tone color as the background,
         * white text/icon. */
        solid: "",
        compact: "",
      },
    },
    compoundVariants: [
      {
        variant: "solid",
        tone: "info",
        class: "border-transparent bg-[var(--color-info)] text-white",
      },
      {
        variant: "solid",
        tone: "success",
        class: "border-transparent bg-[var(--color-success)] text-white",
      },
      {
        variant: "solid",
        tone: "warning",
        class: "border-transparent bg-[var(--color-warning)] text-white",
      },
      {
        variant: "solid",
        tone: "danger",
        class: "border-transparent bg-[var(--color-danger)] text-white",
      },
      {
        variant: "solid",
        tone: "critical",
        class: "border-transparent bg-[var(--color-critical)] text-white",
      },
      {
        variant: "compact",
        class: "items-center gap-2 px-3 py-1.5 text-xs",
      },
    ],
    defaultVariants: {
      tone: "info",
    },
  }
)

const toneIconMap = {
  info:     Info,
  success:  CheckCircle,
  warning:  AlertTriangle,
  danger:   XCircle,
  critical: XCircle,
} as const

export interface AlertProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof alertVariants> {
  title?: string
  dismissible?: boolean
  onDismiss?: () => void
  /** Override the automatic icon, or pass false to suppress it */
  icon?: React.ReactNode | false
}

export function Alert({
  tone = "info",
  variant,
  title,
  dismissible = false,
  onDismiss,
  icon,
  className,
  children,
  ...props
}: AlertProps) {
  const [dismissed, setDismissed] = React.useState(false)

  if (dismissed) return null

  const resolvedTone = tone ?? "info"
  const compact = variant === "compact"
  const DefaultIcon = toneIconMap[resolvedTone]
  const showIcon = icon !== false
  const iconNode =
    icon !== undefined && icon !== false
      ? icon
      : (
        <DefaultIcon
          size={compact ? 14 : 16}
          strokeWidth={1.5}
          aria-hidden="true"
          className={compact ? "shrink-0" : "mt-0.5 shrink-0"}
        />
      )

  function handleDismiss() {
    setDismissed(true)
    onDismiss?.()
  }

  return (
    <div
      role="alert"
      className={cn(alertVariants({ tone, variant }), className)}
      {...props}
    >
      {showIcon && iconNode}

      <div className={compact ? "min-w-0 flex-1 truncate" : "min-w-0 flex-1"}>
        {title && (
          <p className={compact ? "font-semibold leading-snug inline" : "font-semibold leading-snug mb-1"}>{title}</p>
        )}
        {children && (
          <div className={cn(compact ? "inline" : "leading-relaxed", !compact && title ? "text-xs opacity-90" : "")}>
            {compact && title ? " — " : ""}
            {children}
          </div>
        )}
      </div>

      {dismissible && (
        <button
          onClick={handleDismiss}
          aria-label="Dismiss alert"
          className={cn(
            "shrink-0 ml-auto -mr-1 -mt-0.5",
            "flex h-6 w-6 items-center justify-center rounded-[var(--radius-button)]",
            "opacity-60 transition-opacity hover:opacity-100",
            "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
          )}
        >
          <X size={14} strokeWidth={1.5} />
        </button>
      )}
    </div>
  )
}
