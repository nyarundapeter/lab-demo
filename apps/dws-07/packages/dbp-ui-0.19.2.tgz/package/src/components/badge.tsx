import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn"

/**
 * Badge's base shell mechanics — layout/typography, deliberately WITHOUT a
 * radius so consumers that need Badge-like chip mechanics but a different
 * shape (e.g. EnvPill's rounded-rect identity marker, ProvTag's rounded-rect
 * provenance tag) can add their own `rounded-*` without colliding with
 * `rounded-pill` in a `cn()`/tailwind-merge pass (this repo's `rounded-pill`
 * utility isn't in tailwind-merge's known radius suffix list, so two radius
 * classes on one element would both survive the merge instead of the later
 * one winning). Exported for reuse (design-system de-dup Wave 1.A, DS-R2/R3).
 */
const badgeShellClass =
  // `[&_svg]:shrink-0` + explicit icon sizing keeps any icon child (e.g. a
  // status checkmark) a normal spaced-out flex sibling of the label text —
  // never sized/positioned so it visually overlaps the label (craft
  // checklist §6 spacing).
  "inline-flex items-center gap-1.5 border font-semibold transition-colors select-none whitespace-nowrap [&_svg]:size-3 [&_svg]:shrink-0"

const badgeVariants = cva(
  cn(badgeShellClass, "rounded-pill"),
  {
    variants: {
      tone: {
        /* Default neutral */
        default: "bg-[var(--color-surface)] text-[var(--color-text-primary)] border-[var(--color-border-default)]",
        /* Alias: several call sites pass "neutral"; without this CVA silently applies NO tone class */
        neutral: "bg-[var(--color-surface)] text-[var(--color-text-primary)] border-[var(--color-border-default)]",
        /* Status triads — bg = -surface, text = -text, border = -border token */
        success: "bg-[var(--color-success-surface)] text-[var(--color-success-text)] border-[var(--color-success-border)]",
        warning: "bg-[var(--color-warning-surface)] text-[var(--color-warning-text)] border-[var(--color-warning-border)]",
        danger:  "bg-[var(--color-danger-surface)]  text-[var(--color-danger-text)]  border-[var(--color-danger-border)]",
        info:    "bg-[var(--color-info-surface)]    text-[var(--color-info-text)]    border-[var(--color-info-border)]",
        /* Consolidated tone family (2026-07-17) — workflow "in progress"/"paused",
         * notification "critical" (distinct from danger), admin "testing". See
         * docs/03-features/specs/tone-family-consolidation-2026-07-17.md. */
        active:   "bg-[var(--color-active-surface)]   text-[var(--color-active-text)]   border-[var(--color-active-border)]",
        paused:   "bg-[var(--color-paused-surface)]   text-[var(--color-paused-text)]   border-[var(--color-paused-border)]",
        critical: "bg-[var(--color-critical-surface)] text-[var(--color-critical-text)] border-[var(--color-critical-border)]",
        testing:  "bg-[var(--color-testing-surface)]  text-[var(--color-testing-text)]  border-[var(--color-testing-border)]",
        /* Neutral / brand tones */
        gray:    "bg-[var(--color-surface)] text-[var(--color-text-muted)] border-[var(--color-border-default)]",
        orange:  "bg-[var(--color-orange-50)] text-secondary border-[color-mix(in_srgb,var(--color-secondary)_30%,transparent)]",
        navy:    "bg-[var(--color-navy-50)] text-[var(--color-text-primary)] border-[color-mix(in_srgb,var(--color-primary)_20%,transparent)]",
        /* AI-governance tone — the AI-provenance token family (base.css),
         * consolidated from the former standalone ContextChip component. */
        ai:      "bg-[hsl(var(--ai-soft))] text-[hsl(var(--ai-strong))] border-[hsl(var(--ai-border))]",
      },
      size: {
        default: "px-2.5 py-1 text-xs leading-none",
        sm:      "px-2 py-0.5 text-xs leading-none",
      },
    },
    defaultVariants: {
      tone: "default",
      size: "default",
    },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {
  dot?: boolean
}

function Badge({ className, tone, size, dot = false, children, ...props }: BadgeProps) {
  return (
    <span className={cn(badgeVariants({ tone, size }), className)} {...props}>
      {dot && (
        <span
          aria-hidden
          className={cn(
            "rounded-full bg-current shrink-0",
            size === "sm" ? "w-1 h-1" : "w-1.5 h-1.5"
          )}
        />
      )}
      {children}
    </span>
  )
}

export { Badge, badgeVariants, badgeShellClass }
