import * as React from "react"
import { cn } from "../lib/cn"
import { Breadcrumb, BreadcrumbItem } from "./breadcrumb"

export interface PageHeaderAction {
  label: string
  onClick: () => void
}

/**
 * @deprecated No longer affects layout (Amendment D-2 — the header no longer
 * has a title column competing for grid space). Kept only so existing call
 * sites passing `titleSpan` still type-check during migration; accepted and
 * ignored.
 */
export type PageHeaderSpan = 1 | 2 | 3

export interface PageHeaderProps {
  /**
   * Not visually rendered (Amendment D-2 — `component-architecture-
   * standard.md` §7b — the shell's breadcrumb trail is the sole visible
   * page-identity surface). Still required: rendered as an `sr-only`
   * `<h1>` so the page keeps exactly one accessible heading landmark
   * (§7b guardrail 2, unchanged by D-2).
   */
  title: string
  /** @deprecated No longer rendered (Amendment D-2). Accepted and ignored. */
  subtitle?: string
  /**
   * Breadcrumb items — rendered ONLY when `showBreadcrumb` is also true.
   * Default off (Amendment D-2): `AppChrome`'s top bar already renders this
   * trail whenever the shell is wired, so showing it again here would be the
   * "two wayfinding trails" duplication the standard has always ruled out.
   * The one legitimate caller is the legacy no-chrome layout path
   * (`buildModuleNav()`'s `!useChrome` branch) — there is no shell
   * breadcrumb to defer to in that mode.
   */
  breadcrumb?: BreadcrumbItem[]
  /** Opt-in: render `breadcrumb` (legacy no-chrome layouts only — see `breadcrumb`'s doc). Default false. */
  showBreadcrumb?: boolean
  /** @deprecated Breadcrumb is now off by default; this flag is redundant. Accepted and ignored. */
  hideBreadcrumb?: boolean
  /** @deprecated No longer affects layout (Amendment D-2). Accepted and ignored. */
  titleSpan?: PageHeaderSpan
  /**
   * Actions/search/filters/date-range — the header's entire visible content.
   * Typically a `CollectionToolbar` or `FilterBar` (§7b's content-pattern
   * rule) — don't hand-roll a bespoke toolbar per page. Right-aligned when
   * it doesn't fill the row on its own.
   */
  aside?: React.ReactNode
  /** Convenience: a primary button rendered in the aside region (when `aside` is not given). */
  action?: PageHeaderAction
  /** @deprecated alias for `aside`. */
  actions?: React.ReactNode
  className?: string
}

/**
 * PageHeader — the ONE factory page header (ARCHETYPE-REFERENCE-SPEC §8,
 * component-architecture-standard.md §7b Amendment D-2).
 *
 * Visible content is `aside` only (actions/search/filters/date-range) — no
 * visible title, no visible breadcrumb by default. Page identity lives in the
 * shell's top bar, which already renders the breadcrumb trail (with a live
 * terminal-crumb override for record names, `useBreadcrumbOverride`) — this
 * component repeating it was the duplication D-2 removed (D-1's own
 * anti-duplication guardrail existed in prose but was never implemented in
 * code; D-2 closes the gap structurally instead). `title` stays a required
 * prop, rendered `sr-only`, so the page keeps a real `<h1>` heading landmark
 * — a breadcrumb crumb is a nav item, not a heading, so it can't substitute
 * for one.
 */
export function PageHeader({
  title,
  breadcrumb,
  showBreadcrumb = false,
  aside,
  action,
  actions,
  className,
}: PageHeaderProps) {
  const asideContent = aside ?? actions ?? (action ? (
    <button
      type="button"
      onClick={action.onClick}
      className="shrink-0 px-4 py-2 rounded-[var(--radius)] bg-[var(--color-primary)] text-white text-sm font-medium hover:opacity-90 focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
    >
      {action.label}
    </button>
  ) : null)

  return (
    <div data-page-title className={cn("py-2", className)}>
      <h1 className="sr-only">{title}</h1>
      {showBreadcrumb && breadcrumb && breadcrumb.length > 0 && (
        <Breadcrumb items={breadcrumb} className="mb-1 hidden md:flex" />
      )}
      {asideContent && (
        <div className="flex flex-wrap items-start gap-2 md:justify-end">{asideContent}</div>
      )}
    </div>
  )
}
