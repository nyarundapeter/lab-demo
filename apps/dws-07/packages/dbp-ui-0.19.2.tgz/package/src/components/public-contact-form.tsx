"use client"

import * as React from "react"
import { useState } from "react"
import { Check, Clock, ArrowRight, Loader2, MapPin, Phone, Mail } from "lucide-react"
import { cn } from "../lib/cn.js"

const MAX_ROLE_LEN = 150
const PHONE_REGEX = /^\+?[\d\s\-(). ]{7,20}$/
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

type FormState = {
  firstName: string
  lastName: string
  email: string
  phone: string
  organisation: string
  role: string
  interest: string
  need: string
  message: string
  consent: boolean
}

const INITIAL: FormState = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  organisation: "",
  role: "",
  interest: "",
  need: "",
  message: "",
  consent: false,
}

export interface PublicContactFormProps {
  /** H1 above the form. */
  headline: string
  /** Lead paragraph under the headline. */
  body: string
  /** Contact email shown in the sidebar + mailto. */
  email: string
  /** Optional phone shown in the sidebar. */
  phone?: string
  /** Optional address line shown in the sidebar. */
  address?: string
  /** Options for the "What are you exploring?" select. */
  interestOptions?: string[]
  /** Options for the "What do you need?" select. */
  needOptions?: string[]
  /** Endpoint the form POSTs to. Defaults to /api/platform/notify/contact. */
  action?: string
  /** Href the privacy-consent link points to. Defaults to /legal/privacy. */
  privacyHref?: string
  /** When false, the in-component headline/body block is not rendered — the page
   *  template owns the header. Defaults to true. */
  showHeader?: boolean
  /** Background/section utility classes for the form band. Defaults to the gray
   *  surface; pass e.g. "bg-[var(--color-surface-content)] border-t border-[var(--color-border-subtle)]" so
   *  the form reads as a distinct white section beneath a gray page header
   *  (avoids hero/section blend). */
  surfaceClassName?: string
  className?: string
}

function inputClass(hasError?: string): string {
  return cn(
    "w-full border-0 border-b bg-transparent px-0 py-2.5 text-sm text-[var(--color-text-primary)] outline-none transition-colors focus:ring-0",
    hasError ? "border-red-600" : "border-[var(--color-border-subtle)] focus:border-primary",
  )
}

function Field({
  id,
  label,
  required,
  optional,
  error,
  hint,
  children,
}: {
  id: string
  label: string
  required?: boolean
  optional?: boolean
  error?: string | undefined
  hint?: string | undefined
  children: React.ReactNode
}): React.ReactElement {
  return (
    <div>
      {/* label-recipe: deliberate — composite label + right-aligned "Optional" badge
          (justify-between) isn't expressible via FieldLabel's inline suffix layout */}
      <label
        htmlFor={id}
        className="mb-2 flex items-center justify-between text-xs font-semibold uppercase tracking-[0.12em] text-[var(--color-text-secondary)]"
      >
        <span>
          {label}
          {required && (
            <span aria-hidden="true" className="ml-0.5 text-red-600">
              *
            </span>
          )}
        </span>
        {optional && (
          <span className="text-xs font-normal normal-case tracking-normal text-[var(--color-text-secondary)] opacity-70">
            Optional
          </span>
        )}
      </label>
      {children}
      {hint && !error && (
        <p id={`${id}-hint`} className="mt-1.5 text-xs text-[var(--color-text-secondary)]">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${id}-error`} className="mt-1.5 text-xs text-red-600" role="alert">
          {error}
        </p>
      )}
    </div>
  )
}

/**
 * PublicContactForm — props-driven public contact form extracted from TMaaS
 * app/contact/_client.tsx. Posts JSON (with a honeypot) to `action`. On success
 * shows a confirmation panel. All copy + option lists are props (manifest-fed).
 */
export function PublicContactForm({
  headline,
  body,
  email,
  phone,
  address,
  interestOptions = [],
  needOptions = [],
  action = "/api/platform/notify/contact",
  privacyHref = "/legal/privacy",
  showHeader = true,
  surfaceClassName = "bg-[var(--color-surface-secondary)]",
  className,
}: PublicContactFormProps): React.ReactElement {
  const [form, setForm] = useState<FormState>(INITIAL)
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({})
  const [submitError, setSubmitError] = useState<string | null>(null)
  const [status, setStatus] = useState<"idle" | "loading" | "success">("idle")
  const [honeypot, setHoneypot] = useState("")

  const showSelects = interestOptions.length > 0 || needOptions.length > 0

  const setField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }))
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }))
    if (submitError) setSubmitError(null)
  }

  const validate = (): boolean => {
    const next: Partial<Record<keyof FormState, string>> = {}
    if (!form.firstName.trim()) next.firstName = "First name is required"
    if (!form.lastName.trim()) next.lastName = "Last name is required"
    if (!form.email.trim()) next.email = "Work email is required"
    else if (!EMAIL_REGEX.test(form.email)) next.email = "Enter a valid work email"
    if (form.phone.trim() && !PHONE_REGEX.test(form.phone.trim()))
      next.phone = "Enter a valid phone number"
    if (!form.organisation.trim()) next.organisation = "Organisation is required"
    if (form.role.trim().length > MAX_ROLE_LEN) next.role = "Role must be 150 characters or fewer"
    if (showSelects) {
      if (interestOptions.length > 0 && !form.interest) next.interest = "Select an area of interest"
      if (needOptions.length > 0 && !form.need) next.need = "Select what you need"
    }
    if (!form.message.trim()) next.message = "A short context message is required"
    if (!form.consent) next.consent = "Consent is required to submit"
    setErrors(next)
    return Object.keys(next).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return
    setStatus("loading")
    setSubmitError(null)
    try {
      const res = await fetch(action, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, website: honeypot }),
      })
      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as { error?: string } | null
        throw new Error(data?.error ?? "Submission failed, please try again or email us directly.")
      }
      setStatus("success")
    } catch (error) {
      setStatus("idle")
      setSubmitError(
        error instanceof Error
          ? error.message
          : "Submission failed, please try again or email us directly.",
      )
    }
  }

  const resetForm = () => {
    setForm(INITIAL)
    setErrors({})
    setSubmitError(null)
    setStatus("idle")
    setHoneypot("")
  }

  if (status === "success") {
    return (
      <section className={cn("bg-[var(--color-surface)] px-5 pb-12 pt-20 md:px-8 md:pb-16 md:pt-24", className)}>
        <div className="mx-auto max-w-[1120px]">
          <div className="mx-auto max-w-2xl rounded-2xl border border-[var(--color-border-subtle)] bg-[var(--color-surface)] p-8 text-center shadow-sm md:p-12">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50">
              <Check size={32} className="text-green-600" strokeWidth={2.5} />
            </div>
            <h1 className="mb-3 text-2xl font-semibold tracking-tight text-[var(--color-text-primary)] md:text-3xl">
              We&apos;ve got your request
            </h1>
            <p className="mx-auto mb-8 max-w-md text-base leading-relaxed text-[var(--color-text-secondary)]">
              An advisor will review your message and get back to you within 2 business days.
            </p>
            <button
              type="button"
              onClick={resetForm}
              className="rounded-pill border border-[var(--color-border-subtle)] px-6 py-2.5 text-base font-semibold text-[var(--color-text-primary)] outline-none transition-colors hover:border-primary"
            >
              Submit another request
            </button>
          </div>
        </div>
      </section>
    )
  }

  return (
    <div className={className}>
      <section className={cn("px-5 py-10 md:px-8 md:py-14 lg:px-10 lg:py-16", surfaceClassName)}>
        <div className="mx-auto max-w-[1120px]">
          {showHeader && (
            <div className="mb-8 max-w-2xl">
              <h1 className="mb-5 text-balance text-4xl font-semibold tracking-tight text-[var(--color-text-primary)] md:text-5xl">
                {headline}
              </h1>
              <p className="text-base leading-relaxed text-[var(--color-text-secondary)] md:text-base">
                {body}
              </p>
            </div>
          )}
          <div className="grid gap-8 lg:grid-cols-12">
            <div className="lg:col-span-8">
              <form
                onSubmit={handleSubmit}
                noValidate
                className="rounded-xl border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] p-5 shadow-sm sm:p-6 md:p-8 lg:p-10"
              >
                <div className="space-y-7">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field id="firstName" label="First Name" required error={errors.firstName}>
                      <input
                        id="firstName"
                        type="text"
                        autoComplete="given-name"
                        value={form.firstName}
                        onChange={(e) => setField("firstName", e.target.value)}
                        className={inputClass(errors.firstName)}
                      />
                    </Field>
                    <Field id="lastName" label="Last Name" required error={errors.lastName}>
                      <input
                        id="lastName"
                        type="text"
                        autoComplete="family-name"
                        value={form.lastName}
                        onChange={(e) => setField("lastName", e.target.value)}
                        className={inputClass(errors.lastName)}
                      />
                    </Field>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field id="email" label="Work Email" required error={errors.email}>
                      <input
                        id="email"
                        type="email"
                        autoComplete="email"
                        placeholder="you@company.com"
                        value={form.email}
                        onChange={(e) => setField("email", e.target.value)}
                        className={inputClass(errors.email)}
                      />
                    </Field>
                    <Field id="phone" label="Phone Number" optional error={errors.phone}>
                      <input
                        id="phone"
                        type="tel"
                        autoComplete="tel"
                        placeholder="+971 XX XXX XXXX"
                        maxLength={20}
                        value={form.phone}
                        onChange={(e) => setField("phone", e.target.value)}
                        className={inputClass(errors.phone)}
                      />
                    </Field>
                  </div>

                  <Field id="organisation" label="Organisation" required error={errors.organisation}>
                    <input
                      id="organisation"
                      type="text"
                      autoComplete="organization"
                      value={form.organisation}
                      onChange={(e) => setField("organisation", e.target.value)}
                      className={inputClass(errors.organisation)}
                    />
                  </Field>

                  <Field id="role" label="Role / Title" optional error={errors.role}>
                    <input
                      id="role"
                      type="text"
                      autoComplete="organization-title"
                      placeholder="e.g. Director of Digital Transformation"
                      maxLength={MAX_ROLE_LEN}
                      value={form.role}
                      onChange={(e) => setField("role", e.target.value)}
                      className={inputClass(errors.role)}
                    />
                  </Field>

                  {showSelects && (
                    <div className="grid gap-4 sm:grid-cols-2">
                      {interestOptions.length > 0 && (
                        <Field id="interest" label="What are you exploring?" required error={errors.interest}>
                          <select
                            id="interest"
                            value={form.interest}
                            onChange={(e) => setField("interest", e.target.value)}
                            className={inputClass(errors.interest)}
                          >
                            <option value="">Select an area…</option>
                            {interestOptions.map((opt) => (
                              <option key={opt} value={opt}>
                                {opt}
                              </option>
                            ))}
                          </select>
                        </Field>
                      )}
                      {needOptions.length > 0 && (
                        <Field id="need" label="What do you need?" required error={errors.need}>
                          <select
                            id="need"
                            value={form.need}
                            onChange={(e) => setField("need", e.target.value)}
                            className={inputClass(errors.need)}
                          >
                            <option value="">Select a need…</option>
                            {needOptions.map((opt) => (
                              <option key={opt} value={opt}>
                                {opt}
                              </option>
                            ))}
                          </select>
                        </Field>
                      )}
                    </div>
                  )}

                  <Field
                    id="message"
                    label="Your Message"
                    required
                    error={errors.message}
                    hint="Share your goals, challenges, or timeline so we can help faster."
                  >
                    <textarea
                      id="message"
                      rows={5}
                      value={form.message}
                      onChange={(e) => setField("message", e.target.value)}
                      className={cn(inputClass(errors.message), "min-h-[120px] resize-y")}
                    />
                  </Field>

                  <div>
                    <label htmlFor="consent" className="flex cursor-pointer items-start gap-3">
                      <input
                        id="consent"
                        type="checkbox"
                        checked={form.consent}
                        onChange={(e) => setField("consent", e.target.checked)}
                        className="mt-0.5 h-4 w-4 shrink-0 rounded border-[var(--color-border-subtle)] text-[var(--color-text-primary)] focus:ring-secondary"
                      />
                      <span
                        className={cn(
                          "text-sm leading-relaxed transition-colors",
                          errors.consent ? "text-red-600" : "text-[var(--color-text-secondary)]",
                        )}
                      >
                        I agree to the processing of my data for this request, in accordance with the{" "}
                        <a href={privacyHref} className="underline transition-colors hover:text-secondary">
                          Privacy Policy
                        </a>
                        .
                      </span>
                    </label>
                    {errors.consent && (
                      <p className="ml-1 mt-1.5 text-xs text-red-600" role="alert">
                        {errors.consent}
                      </p>
                    )}
                  </div>

                  {/* Honeypot — hidden from real users, bots fill it. */}
                  <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
                    <label htmlFor="website">Website</label>
                    <input
                      id="website"
                      type="text"
                      name="website"
                      tabIndex={-1}
                      autoComplete="off"
                      value={honeypot}
                      onChange={(e) => setHoneypot(e.target.value)}
                    />
                  </div>

                  {submitError && (
                    <p
                      className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
                      role="alert"
                    >
                      {submitError}
                    </p>
                  )}

                  <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <p className="text-center text-xs text-[var(--color-text-secondary)] sm:text-left">
                      <span className="text-red-600">*</span> Required fields.
                    </p>
                    <button
                      type="submit"
                      disabled={status === "loading"}
                      className="inline-flex w-full items-center justify-center gap-2 rounded-pill bg-secondary px-6 py-3 text-base font-semibold text-white outline-none transition-colors hover:bg-[var(--color-orange-600)] disabled:cursor-not-allowed disabled:opacity-80 sm:w-auto"
                    >
                      {status === "loading" ? (
                        <>
                          <Loader2 size={16} className="animate-spin" />
                          Submitting…
                        </>
                      ) : (
                        <>
                          Send request
                          <ArrowRight size={16} />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </form>
            </div>

            <aside className="border-t border-[var(--color-border-subtle)] px-1 pt-8 lg:col-span-4 lg:border-t-0 lg:pt-0">
              <p className="dq-overline mb-4 text-[var(--color-text-secondary)] opacity-70">What happens next</p>
              <p className="mb-5 text-sm leading-relaxed text-[var(--color-text-secondary)]">
                An advisor reads every message and connects you to the right services.
              </p>
              <div className="flex items-center gap-1.5 text-sm text-[var(--color-text-secondary)]">
                <Clock size={13} className="shrink-0 opacity-70" />
                Expect a response within 2 business days.
              </div>
              <div className="mt-6 border-t border-[var(--color-border-subtle)] pt-5">
                <p className="dq-overline mb-4 text-[var(--color-text-secondary)] opacity-70">Reach us</p>
                {address && (
                  <div className="mb-4 flex items-start gap-2.5">
                    <MapPin size={13} className="mt-0.5 shrink-0 text-[var(--color-text-primary)]" />
                    <p className="text-sm leading-snug text-[var(--color-text-secondary)]">{address}</p>
                  </div>
                )}
                {phone && (
                  <a href={`tel:${phone.replace(/[^\d+]/g, "")}`} className="flex items-center gap-2.5 py-1">
                    <Phone size={13} className="shrink-0 opacity-70" />
                    <span className="text-sm text-[var(--color-text-secondary)]">{phone}</span>
                  </a>
                )}
                <a href={`mailto:${email}`} className="mt-0.5 flex items-center gap-2.5 py-1">
                  <Mail size={13} className="shrink-0 opacity-70" />
                  <span className="text-sm text-[var(--color-text-secondary)]">{email}</span>
                </a>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  )
}
