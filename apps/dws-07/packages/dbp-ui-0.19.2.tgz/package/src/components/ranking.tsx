import * as React from "react"
import { cn } from "../lib/cn.js"
import { Avatar } from "./avatar.js"
import { Delta } from "./delta.js"

export interface RankingItem {
  name: string
  value: number
  /** Shows an Avatar when present. */
  avatar?: boolean
  delta?: number
}

export interface RankingProps extends React.HTMLAttributes<HTMLDivElement> {
  items: RankingItem[]
  /** Formats the trailing metric value. Defaults to the raw value. */
  format?: (value: number) => React.ReactNode
}

/**
 * Ranked leaderboard — position, optional avatar, name, optional delta, and
 * the formatted metric value (dash-components.jsx:202-214).
 */
export function Ranking({ items, format = (v) => v, className, ...props }: RankingProps) {
  return (
    <div className={cn("flex flex-col", className)} {...props}>
      {items.map((item, i) => (
        <div
          key={item.name}
          className="flex items-center gap-2.5 border-b border-[var(--color-border-subtle)] py-2 last:border-b-0"
        >
          <span className="w-[18px] text-xs font-semibold tabular-nums text-[var(--color-text-muted)]">
            {i + 1}
          </span>
          {item.avatar && <Avatar name={item.name} size="sm" />}
          <span className="min-w-0 flex-1 truncate text-sm text-[var(--color-text)]">{item.name}</span>
          {item.delta !== undefined && <Delta value={item.delta} suffix="" />}
          <span className="min-w-[54px] text-right text-sm font-semibold tabular-nums text-[var(--color-text)]">
            {format(item.value)}
          </span>
        </div>
      ))}
    </div>
  )
}
