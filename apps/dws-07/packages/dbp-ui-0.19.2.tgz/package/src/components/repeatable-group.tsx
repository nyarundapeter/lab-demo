import * as React from "react"
import { Plus, Trash2 } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Button } from "./button.js"

export interface RepeatableGroupProps<T> {
  items: T[]
  onAdd: () => void
  onRemove: (index: number) => void
  renderItem: (item: T, index: number) => React.ReactNode
  addLabel?: string
  /** Minimum row count — below this, the remove button is hidden (forms-blocks.jsx keeps at least one row). Defaults to 1. */
  minItems?: number
  className?: string
}

/**
 * RepeatableGroup — array-of-a-sub-field-set with add/remove rows, the
 * line-items pattern (forms-blocks.jsx:104-120). Bare layout primitive —
 * `renderItem` supplies each row's controls (form-builder's `repeatable-group`
 * field type calls this with `FieldRenderer` per sub-field); this component
 * only owns the add/remove chrome and row separators.
 */
function RepeatableGroup<T>({
  items,
  onAdd,
  onRemove,
  renderItem,
  addLabel = "Add another",
  minItems = 1,
  className,
}: RepeatableGroupProps<T>) {
  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <div className="flex flex-col gap-3">
        {items.map((item, i) => (
          <div
            key={i}
            className={cn(
              "flex items-start gap-2.5",
              i < items.length - 1 && "border-b border-[var(--color-border)] pb-3",
            )}
          >
            <div className="min-w-0 flex-1">{renderItem(item, i)}</div>
            {items.length > minItems && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="mt-6 h-8 w-8"
                aria-label={`Remove item ${i + 1}`}
                onClick={() => onRemove(i)}
              >
                <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
              </Button>
            )}
          </div>
        ))}
      </div>
      <Button type="button" variant="link" size="sm" className="self-start" onClick={onAdd}>
        <Plus className="h-3.5 w-3.5" aria-hidden="true" />
        {addLabel}
      </Button>
    </div>
  )
}

export { RepeatableGroup }
