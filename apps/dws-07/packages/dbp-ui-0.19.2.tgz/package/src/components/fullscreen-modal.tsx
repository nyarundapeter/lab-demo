"use client"
import * as React from "react"
import * as DialogPrimitive from "@radix-ui/react-dialog"
import { X } from "lucide-react"
import { cn } from "../lib/cn.js"

/**
 * FullScreenModal — overlay ledger item 15 (Phase-2 primitive, deferral row
 * 8). A route-like full-viewport surface for a task too complex for a
 * standard modal but still temporary — distinct from `DialogContent
 * size="full"`, which is still a centered card at a capped max-width.
 * Anatomy sourced from docs/03-features/specs/claude-design-briefs/
 * design-run-pack-2026-07-12/_outputs/overlay-system/overlay-fullscreen.jsx
 * + overlay.css `.ov-fs*`: full-viewport surface (no scrim — it covers
 * everything), a 56px header bar (back/close + title + actions), a
 * scrollable body with an optional side rail, and a sticky 60px action
 * footer. Built on Radix Dialog for focus-trap/Escape/aria, following
 * dialog.tsx's primitive-wrapping conventions.
 */

const FullScreenModal = DialogPrimitive.Root
const FullScreenModalTrigger = DialogPrimitive.Trigger
const FullScreenModalClose = DialogPrimitive.Close
const FullScreenModalPortal = DialogPrimitive.Portal

interface FullScreenModalContentProps
  extends React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content> {
  /** Hide the default top-right close button — use when the bar supplies its own back/close affordance. */
  hideClose?: boolean
}

const FullScreenModalContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  FullScreenModalContentProps
>(({ hideClose = false, className, children, ...props }, ref) => (
  <FullScreenModalPortal>
    <DialogPrimitive.Content
      ref={ref}
      className={cn(
        "fixed inset-0 z-[var(--z-modal)]",
        "flex flex-col",
        "bg-[var(--color-background,white)]",
        "focus-visible:outline-none",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "duration-150",
        className
      )}
      {...props}
    >
      {children}
      {!hideClose && (
        <DialogPrimitive.Close
          className={cn(
            "absolute right-4 top-4",
            "flex h-8 w-8 items-center justify-center rounded-[var(--radius-button)]",
            "text-[var(--color-text-muted)]",
            "transition-colors",
            "hover:bg-[var(--color-navy-50)] hover:text-[var(--color-text-primary)]",
            "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
            "disabled:pointer-events-none"
          )}
        >
          <X size={17} strokeWidth={1.5} aria-hidden="true" />
          <span className="sr-only">Close</span>
        </DialogPrimitive.Close>
      )}
    </DialogPrimitive.Content>
  </FullScreenModalPortal>
))
FullScreenModalContent.displayName = "FullScreenModalContent"

/** 56px header bar — back/close affordance, eyebrow + title, trailing actions. */
const FullScreenModalBar = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex h-14 shrink-0 items-center gap-3",
      "border-b border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-4",
      className
    )}
    {...props}
  />
)
FullScreenModalBar.displayName = "FullScreenModalBar"

const FullScreenModalTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn("truncate text-sm font-semibold text-[var(--color-text-primary)]", className)}
    {...props}
  />
))
FullScreenModalTitle.displayName = DialogPrimitive.Title.displayName

const FullScreenModalDescription = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn(
      "text-xs font-semibold uppercase tracking-[0.08em] text-[var(--color-text-muted)]",
      className
    )}
    {...props}
  />
))
FullScreenModalDescription.displayName = DialogPrimitive.Description.displayName

/** Body row: flex-1, min-h-0, houses the scrollable main pane + optional rail. */
const FullScreenModalBody = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex min-h-0 flex-1 overflow-hidden", className)} {...props} />
)
FullScreenModalBody.displayName = "FullScreenModalBody"

const FullScreenModalMain = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("min-w-0 flex-1 overflow-y-auto", className)} {...props} />
)
FullScreenModalMain.displayName = "FullScreenModalMain"

const FullScreenModalRail = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "w-[280px] shrink-0 overflow-y-auto border-l border-[var(--color-border-subtle)] bg-[var(--color-surface)] p-4",
      className
    )}
    {...props}
  />
)
FullScreenModalRail.displayName = "FullScreenModalRail"

/** Sticky 60px action footer. */
const FullScreenModalFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex h-[60px] shrink-0 items-center gap-2.5 border-t border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-4",
      className
    )}
    {...props}
  />
)
FullScreenModalFooter.displayName = "FullScreenModalFooter"

export {
  FullScreenModal,
  FullScreenModalTrigger,
  FullScreenModalClose,
  FullScreenModalPortal,
  FullScreenModalContent,
  FullScreenModalBar,
  FullScreenModalTitle,
  FullScreenModalDescription,
  FullScreenModalBody,
  FullScreenModalMain,
  FullScreenModalRail,
  FullScreenModalFooter,
}
