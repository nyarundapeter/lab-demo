import * as React from "react"
import { Check, AlertTriangle, Ban, Undo2, Minus, ChevronRight } from "lucide-react"
import type { StageRow, StageStatus } from "./vertical-stage-tracker.js"
import { cn } from "../lib/cn.js"

export type LifecycleBarVariant = "chip" | "stepper"

const STAGE_COLOR: Record<StageStatus, string> = {
  done: "var(--color-success)",
  active: "var(--color-active)",
  upcoming: "var(--color-text-muted)",
  error: "var(--color-danger)",
  blocked: "var(--color-warning)",
  returned: "var(--color-warning)",
  skipped: "var(--color-text-muted)",
}

function nodeGlyph(status: StageStatus, position: number): React.ReactNode {
  switch (status) {
    case "done":
      return <Check size={12} strokeWidth={2.5} aria-hidden="true" />
    case "error":
      return <AlertTriangle size={11} strokeWidth={2.5} aria-hidden="true" />
    case "blocked":
      return <Ban size={11} strokeWidth={2.5} aria-hidden="true" />
    case "returned":
      return <Undo2 size={11} strokeWidth={2.5} aria-hidden="true" />
    case "skipped":
      return <Minus size={11} strokeWidth={2.5} aria-hidden="true" />
    default:
      return position
  }
}

export interface LifecycleBarProps {
  stages: StageRow[]
  /**
   * "chip" — compact pill row, chevron-separated, current stage highlighted
   * (admin config-lifecycle: admin-panels.jsx:161-182). "stepper" — numbered/
   * checked node row with a connecting line (case/request trackers:
   * wf-trackers.jsx:239-255). @default "stepper"
   */
  variant?: LifecycleBarVariant
  className?: string
}

/**
 * Horizontal lifecycle/stage bar — one component, two reference-driven
 * render styles, sharing @dbp/ui's StageStatus/StageRow vocabulary
 * (VerticalStageTracker) rather than a second status enum. Compact/
 * non-expandable by design; use VerticalStageTracker when rows need
 * owner/date detail.
 */
function LifecycleBar({ stages, variant = "stepper", className }: LifecycleBarProps) {
  return variant === "chip" ? (
    <ChipRow stages={stages} className={className} />
  ) : (
    <StepperRow stages={stages} className={className} />
  )
}

/**
 * Chip background/text per status (wf-trackers.jsx CompactTracker: done→
 * success, active→active, blocked→warning, error→danger, upcoming/skipped/
 * returned→neutral). Extends the original active/done-only treatment so the
 * chip variant reads blocked/error stages without relying on a 5th tracker
 * component (wave3-family3-tier-audit.md row 13).
 */
const CHIP_TONE: Partial<Record<StageStatus, { bg: string; fg: string }>> = {
  blocked: { bg: "color-mix(in srgb, var(--color-warning) 12%, transparent)", fg: "var(--color-warning)" },
  error: { bg: "color-mix(in srgb, var(--color-danger) 12%, transparent)", fg: "var(--color-danger)" },
}

function ChipRow({ stages, className }: { stages: StageRow[]; className?: string | undefined }) {
  return (
    <div className={cn("flex flex-wrap items-center gap-0", className)}>
      {stages.map((stage, i) => {
        const isActive = stage.status === "active"
        const isDone = stage.status === "done"
        const isUpcoming = stage.status === "upcoming" || stage.status === "skipped"
        const tone = CHIP_TONE[stage.status]
        return (
          <React.Fragment key={stage.id}>
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded-[6px] px-2.5 py-1 text-xs",
                isActive ? "font-semibold" : "font-normal",
              )}
              style={{
                background: tone ? tone.bg : isActive ? "color-mix(in srgb, var(--color-primary) 10%, transparent)" : "transparent",
                color: tone
                  ? tone.fg
                  : isActive
                    ? "var(--color-primary)"
                    : isDone
                      ? "var(--color-text)"
                      : "var(--color-text-muted)",
                opacity: isUpcoming ? 0.65 : 1,
              }}
            >
              {isDone && <Check size={12} strokeWidth={2.5} style={{ color: "var(--color-success)" }} aria-hidden="true" />}
              {isActive && (
                <span
                  className="h-1.5 w-1.5 shrink-0 rounded-full"
                  style={{ background: "var(--color-primary)" }}
                  aria-hidden="true"
                />
              )}
              {stage.status === "blocked" && <Ban size={11} strokeWidth={2.5} aria-hidden="true" />}
              {stage.status === "error" && <AlertTriangle size={11} strokeWidth={2.5} aria-hidden="true" />}
              {stage.label}
            </span>
            {i < stages.length - 1 && (
              <ChevronRight size={12} className="text-[var(--color-border-default)]" aria-hidden="true" />
            )}
          </React.Fragment>
        )
      })}
    </div>
  )
}

function StepperRow({ stages, className }: { stages: StageRow[]; className?: string | undefined }) {
  return (
    <div className={cn("flex w-full items-start overflow-x-auto", className)}>
      {stages.map((stage, i) => {
        const isLast = i === stages.length - 1
        const color = STAGE_COLOR[stage.status]
        const filled = stage.status === "done" || stage.status === "active"

        return (
          <div key={stage.id} className="flex min-w-[88px] flex-1 flex-col items-center">
            <div className="flex w-full items-center">
              <div
                className={cn("h-px flex-1", i === 0 && "invisible")}
                style={{ background: i > 0 && stages[i - 1]?.status === "done" ? STAGE_COLOR.done : "var(--color-border-default)" }}
                aria-hidden="true"
              />
              <div
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-[1.5px] text-xs font-semibold"
                style={
                  filled
                    ? { borderColor: color, background: color, color: "white" }
                    : { borderColor: "var(--color-border-default)", color: "var(--color-text-muted)" }
                }
              >
                {nodeGlyph(stage.status, i + 1)}
              </div>
              <div
                className={cn("h-px flex-1", isLast && "invisible")}
                style={{ background: stage.status === "done" ? STAGE_COLOR.done : "var(--color-border-default)" }}
                aria-hidden="true"
              />
            </div>
            <span
              className="mt-1.5 text-center text-xs leading-tight"
              style={{ color: stage.status === "upcoming" ? "var(--color-text-muted)" : "var(--color-text)" }}
            >
              {stage.label}
            </span>
          </div>
        )
      })}
    </div>
  )
}

/**
 * Fixed 6-stage config-content lifecycle (admin-panels.jsx:160) — used for
 * the "chip" variant. `current` derives done/active/upcoming by position.
 */
export const CONFIG_LIFECYCLE_STAGES = [
  "Draft",
  "In review",
  "Approved",
  "Published",
  "Deprecated",
  "Archived",
] as const

export type ConfigLifecycleStage = (typeof CONFIG_LIFECYCLE_STAGES)[number]

export function deriveConfigLifecycleStages(current: ConfigLifecycleStage): StageRow[] {
  const idx = CONFIG_LIFECYCLE_STAGES.indexOf(current)
  return CONFIG_LIFECYCLE_STAGES.map((label, i) => ({
    id: label,
    label,
    status: i < idx ? "done" : i === idx ? "active" : "upcoming",
  }))
}

export { LifecycleBar }
