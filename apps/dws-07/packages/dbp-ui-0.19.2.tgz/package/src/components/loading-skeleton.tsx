import * as React from 'react'
import { cn } from '../lib/cn.js'
import { Skeleton } from './skeleton.js'

type SkeletonVariant = 'list' | 'card' | 'form' | 'chart'

export interface LoadingSkeletonProps {
  variant?: SkeletonVariant
  rows?: number
  className?: string
}

/**
 * Composite loading layouts (list/card/form/chart), built on the `Skeleton`
 * atom rather than a duplicated shimmer style — the atom is the single
 * source of truth for the shimmer look.
 */
export function LoadingSkeleton({ variant = 'list', rows = 5, className }: LoadingSkeletonProps) {
  if (variant === 'card') {
    return (
      <div
        data-skeleton-card
        className={cn('rounded-[var(--radius)] border border-[var(--color-border)] p-4 space-y-3', className)}
      >
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-2/3" />
      </div>
    )
  }

  if (variant === 'form') {
    return (
      <div className={cn('space-y-4', className)}>
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="space-y-1">
            <Skeleton className="h-3 w-24" />
            <Skeleton className="h-9 w-full" />
          </div>
        ))}
      </div>
    )
  }

  if (variant === 'chart') {
    return (
      <div className={cn('space-y-2', className)}>
        <Skeleton className="h-[200px] w-full" />
        <Skeleton className="h-3 w-1/3 mx-auto" />
      </div>
    )
  }

  // Default: list
  return (
    <div className={cn('space-y-2', className)}>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} data-skeleton-row className="flex items-center gap-3 px-3 py-2 rounded">
          <Skeleton className="h-4 w-4 rounded-full shrink-0" />
          <div className="flex-1 space-y-1">
            <Skeleton className="h-3 w-1/2" />
            <Skeleton className="h-2 w-3/4" />
          </div>
        </div>
      ))}
    </div>
  )
}
