import * as React from "react"
import { ArrowRight, ArrowLeft } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Badge } from "./badge.js"
import { Card } from "./card.js"

/**
 * Dependency card (WFL-11). Reference: wf-status.jsx:265-285 — "blocking"
 * (this record blocks another) vs "blocked-by" (this record waits on
 * another). No factory equivalent previously existed.
 */
export type DependencyDirection = "blocking" | "blocked-by"

export interface DependencyCardProps extends React.HTMLAttributes<HTMLDivElement> {
  direction: DependencyDirection
  /** The related record's display label, e.g. "PR-1042 Vendor onboarding". */
  recordLabel: string
  /** The related record's status label, e.g. "In review". */
  statusLabel?: string
  onNavigate?: () => void
}

export function DependencyCard({
  direction,
  recordLabel,
  statusLabel,
  onNavigate,
  className,
  ...props
}: DependencyCardProps) {
  const Icon = direction === "blocking" ? ArrowRight : ArrowLeft
  const label = direction === "blocking" ? "Blocking" : "Blocked by"
  return (
    <Card
      className={cn(
        "flex items-center gap-2.5 px-3.5 py-2.5",
        className,
      )}
      data-testid="dependency-card"
      data-direction={direction}
      {...props}
    >
      <Icon size={14} strokeWidth={1.5} className="shrink-0 text-[var(--color-text-muted)]" aria-hidden />
      <div className="min-w-0 flex-1">
        <span className="mr-1.5 text-xs font-semibold uppercase tracking-[0.04em] text-[var(--color-text-muted)]">
          {label}
        </span>
        {onNavigate ? (
          <button
            type="button"
            onClick={onNavigate}
            className="truncate text-sm font-medium text-[var(--color-text-primary)] hover:underline focus-visible:outline-none"
            data-testid="dependency-navigate-button"
          >
            {recordLabel}
          </button>
        ) : (
          <span className="truncate text-sm font-medium text-[var(--color-text-primary)]">{recordLabel}</span>
        )}
      </div>
      {statusLabel && (
        <Badge tone="gray" size="sm" className="shrink-0">
          {statusLabel}
        </Badge>
      )}
    </Card>
  )
}
