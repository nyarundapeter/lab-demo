"use client";

// Ported from the STCB GRC solution's shared detail-drawer kit (WS-6.2),
// generalised for @dbp/ui: all GRC/domain naming (Control/Policy/Risk/
// Obligation) stripped — this is a generic status-text primitive plus a
// linked-records list/table for any record-detail drawer.

import * as React from "react";
import { cn } from "../lib/cn.js";
import { Button } from "./button.js";
import type { BadgeProps } from "./badge.js";

function capitalize(value: string): string {
  return value.length === 0 ? value : value.charAt(0).toUpperCase() + value.slice(1);
}

/** Turns a stored status key like "partially-effective" into "Partially
 * effective" for display. */
function humanizeStatus(value: string): string {
  return capitalize(value.replace(/[-_]+/g, " "));
}

// No filled pills/badges here — every place that would render a filled
// Badge instead renders plain text, coloured via a text-colour token keyed
// off the same `tone` vocabulary Badge uses (borrowed via BadgeProps["tone"],
// not a new vocabulary), so callers pass `tone` exactly as they would to
// Badge.
const TONE_TEXT_CLASS: Record<NonNullable<BadgeProps["tone"]>, string> = {
  default: "text-[var(--color-text-primary)]",
  neutral: "text-[var(--color-text-primary)]",
  success: "text-[var(--color-success-text)]",
  warning: "text-[var(--color-warning-text)]",
  danger: "text-[var(--color-danger-text)]",
  orange: "text-[var(--color-warning-text)]",
  info: "text-[var(--color-info-text)]",
  gray: "text-[var(--color-text-muted)]",
  navy: "text-[var(--color-text-primary)]",
  active: "text-[var(--color-active-text)]",
  paused: "text-[var(--color-paused-text)]",
  critical: "text-[var(--color-critical-text)]",
  testing: "text-[var(--color-testing-text)]",
  ai: "text-[hsl(var(--ai-strong))]",
};

export function DetailStatusText({
  children,
  tone = "gray",
}: {
  children: React.ReactNode;
  tone?: BadgeProps["tone"];
}) {
  const toneClass = (tone && TONE_TEXT_CLASS[tone]) ?? TONE_TEXT_CLASS.gray;
  return <span className={cn("text-sm font-medium", toneClass)}>{children}</span>;
}

export interface DetailChipProps {
  children: React.ReactNode;
  tone?: BadgeProps["tone"];
}

/** Plain-text taxonomy chip (e.g. a category value) — no pill background. */
export function DetailChip({ children, tone = "gray" }: DetailChipProps) {
  return <DetailStatusText tone={tone}>{children}</DetailStatusText>;
}

/** One row rendered by DetailLinkedRecordsList's preview and expanded views. */
export interface DetailLinkedRecord {
  id: string;
  primary: React.ReactNode;
  secondary?: React.ReactNode;
  href?: string;
  /** Optional trailing badge (e.g. a status label). */
  badge?: { label: string; tone?: BadgeProps["tone"] };
  /** Optional group key — when any row carries one, rows render under group headings. */
  groupKey?: string;
}

export interface DetailLinkedRecordsListFilter<F extends string> {
  value: F;
  label: string;
}

/** One column of the `variant="table"` presentation. */
export interface DetailLinkedRecordsListColumn {
  header: string;
  render: (r: DetailLinkedRecord) => React.ReactNode;
  /** Omit this column when the container is measured as narrow. */
  hideWhenNarrow?: boolean;
}

export interface DetailLinkedRecordsListProps<F extends string = string> {
  records: DetailLinkedRecord[];
  isLoading?: boolean;
  emptyTitle?: string;
  emptyDescription?: string;
  /** Preview-mode cap ("View all N"). Ignored when `paged` is set. */
  previewCount?: number;
  /**
   * Opt into full pagination ("View more (N remaining)") instead of the
   * default preview + "View all N" toggle — for long lists.
   */
  paged?: { pageSize: number };
  /**
   * Filter pills rendered above the list. `records` should already reflect
   * the caller's own filtered set for the active value — this component
   * only renders the pills and reports clicks.
   */
  filters?: {
    options: DetailLinkedRecordsListFilter<F>[];
    active: F;
    onChange: (value: F) => void;
    /** Unfiltered total shown next to the pills, e.g. "12 of 513". */
    totalCount: number;
  };
  /**
   * "table" renders a row-table treatment instead of the bordered-row card
   * list, so multiple linked-record tabs can read as one component family.
   * `columns` is required in this mode.
   */
  variant?: "list" | "table";
  columns?: DetailLinkedRecordsListColumn[];
  /** Only used by `variant="table"` — sheds `hideWhenNarrow` columns. */
  isNarrow?: boolean;
  /** Suppress the "N" count line above the list — for callers that already
   * show the count in their own card title (e.g. "Previous assessments (2)"). */
  hideCount?: boolean;
  /** Noun appended to the count line so it reads as a count (e.g. "controls"
   * -> "24 controls") instead of a bare, unlabeled number. */
  countNoun?: string;
}

/**
 * Standard two-column `variant="table"` layout (Record: primary + secondary
 * code; Status: the row's badge) for a plain linked-record tab, so callers
 * don't each re-derive the same columns.
 */
export function standardLinkedRecordColumns(): DetailLinkedRecordsListColumn[] {
  return [
    {
      header: "Record",
      render: (r) => {
        const content = (
          <div className="min-w-0">
            <div className="truncate text-[var(--color-text-secondary)]">{r.primary}</div>
            {r.secondary && (
              <div className="truncate font-mono text-xs text-[var(--color-text-muted)]">{r.secondary}</div>
            )}
          </div>
        );
        return r.href ? (
          <a href={r.href} className="block hover:underline">
            {content}
          </a>
        ) : (
          content
        );
      },
    },
    {
      header: "Status",
      render: (r) =>
        r.badge ? (
          <DetailStatusText tone={r.badge.tone ?? "gray"}>{humanizeStatus(r.badge.label)}</DetailStatusText>
        ) : (
          <span className="text-[var(--color-text-muted)]">—</span>
        ),
    },
  ];
}

/**
 * Linked-records list for a detail drawer tab. Covers both a plain preview
 * ("View all N") and richer needs (optional filter pills, optional group
 * headings from `groupKey`, optional full pagination via `paged`, and an
 * optional per-row trailing `badge`). All extra capabilities are opt-in via
 * props so plain callers are unaffected.
 */
export function DetailLinkedRecordsList<F extends string = string>({
  records,
  isLoading,
  emptyTitle = "No linked records",
  emptyDescription = "Nothing is linked yet.",
  previewCount = 4,
  paged,
  filters,
  variant = "list",
  columns,
  isNarrow,
  hideCount,
  countNoun = "records",
}: DetailLinkedRecordsListProps<F>) {
  const [expanded, setExpanded] = React.useState(false);
  const [visibleCount, setVisibleCount] = React.useState(paged?.pageSize ?? records.length);

  const pageSize = paged?.pageSize;
  React.useEffect(() => {
    if (pageSize) setVisibleCount(pageSize);
  }, [filters?.active, pageSize]);

  if (isLoading) {
    return <p className="text-sm text-[var(--color-text-muted)]">Loading…</p>;
  }

  const isEmpty = records.length === 0;

  const visible = paged ? records.slice(0, visibleCount) : expanded ? records : records.slice(0, previewCount);
  const hiddenCount = paged ? records.length - visibleCount : records.length - previewCount;

  const grouped: [string | undefined, DetailLinkedRecord[]][] = [];
  if (visible.some((r) => r.groupKey !== undefined)) {
    const map = new Map<string, DetailLinkedRecord[]>();
    for (const r of visible) {
      const key = r.groupKey ?? "Ungrouped";
      const list = map.get(key) ?? [];
      list.push(r);
      map.set(key, list);
    }
    grouped.push(...map.entries());
  } else {
    grouped.push([undefined, visible]);
  }

  const visibleColumns = (columns ?? []).filter((c) => !(isNarrow && c.hideWhenNarrow));

  function renderTable() {
    return (
      <>
        {/* Plain CSS, not Tailwind utilities — table-layout: fixed with a
            fixed px floor on the last column (not width: 1%, which would
            ignore content/min-width as a floor and squeeze status text). */}
        <style>{`
          .detail-linked-records-table { width: 100%; table-layout: fixed; border-collapse: collapse; font-size: 0.8125rem; }
          .detail-linked-records-table th {
            text-align: left; padding: 6px 8px; font-weight: 600;
            color: var(--color-text-muted); border-bottom: 1px solid var(--color-border-default);
            white-space: nowrap;
          }
          .detail-linked-records-table td {
            padding: 6px 8px; border-bottom: 1px solid var(--color-border-subtle); vertical-align: top;
            overflow: hidden;
          }
          .detail-linked-records-table th:last-child, .detail-linked-records-table td:last-child { width: 130px; white-space: nowrap; }
          .detail-linked-records-table tbody tr:hover { background: var(--color-surface); }
        `}</style>
        <div className="overflow-x-auto">
          <table className="detail-linked-records-table">
            <thead>
              <tr>
                {visibleColumns.map((c) => (
                  <th key={c.header}>{c.header}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {visible.map((r) => (
                <tr key={r.id}>
                  {visibleColumns.map((c) => (
                    <td key={c.header}>{c.render(r)}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    );
  }

  // Equal-height siblings: every row shares the same padding/border/line-height
  // regardless of whether it has a secondary line or trailing badge, so a list
  // of these rows reads as uniform height (project layout rule).
  function renderRow(r: DetailLinkedRecord) {
    const row = (
      <div className="flex items-center justify-between gap-2 rounded-md border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-3 py-1.5 text-sm hover:bg-[var(--color-surface)]">
        <div className="flex min-w-0 flex-1 items-baseline gap-2">
          <span className="min-w-0 truncate text-[var(--color-text-secondary)]">{r.primary}</span>
          {r.secondary && (
            <span className="shrink-0 whitespace-nowrap text-xs text-[var(--color-text-muted)]">{r.secondary}</span>
          )}
        </div>
        {r.badge && (
          <span className="shrink-0 whitespace-nowrap">
            <DetailStatusText tone={r.badge.tone ?? "gray"}>{humanizeStatus(r.badge.label)}</DetailStatusText>
          </span>
        )}
      </div>
    );
    return r.href ? (
      <a key={r.id} href={r.href}>
        {row}
      </a>
    ) : (
      <div key={r.id}>{row}</div>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      {filters ? (
        <div className="flex items-center justify-between gap-2">
          <div className="flex gap-1">
            {filters.options.map((f) => (
              <Button
                key={f.value}
                variant={filters.active === f.value ? "outline" : "ghost"}
                size="sm"
                className="text-xs capitalize"
                onClick={() => filters.onChange(f.value)}
              >
                {f.label}
              </Button>
            ))}
          </div>
          <span className="text-xs text-[var(--color-text-muted)]">
            {records.length} of {filters.totalCount}
          </span>
        </div>
      ) : (
        !isEmpty && (
          <div className="flex items-center justify-between">
            {!hideCount && (
              <span className="text-xs text-[var(--color-text-muted)]">
                {records.length} {countNoun}
              </span>
            )}
            {expanded && (
              <Button variant="ghost" size="sm" className="text-xs" onClick={() => setExpanded(false)}>
                Show less
              </Button>
            )}
          </div>
        )
      )}

      {isEmpty ? (
        <div className="text-sm text-[var(--color-text-muted)]">
          {emptyTitle && <p className="font-medium text-[var(--color-text)]">{emptyTitle}</p>}
          <p>{emptyDescription}</p>
        </div>
      ) : variant === "table" ? (
        renderTable()
      ) : (
        <div className="flex flex-col gap-3">
          {grouped.map(([group, rows]) => (
            <div key={group ?? "__all"} className="flex flex-col gap-1">
              {group !== undefined && <p className="text-xs font-semibold text-[var(--color-text-muted)]">{group}</p>}
              {rows.map(renderRow)}
            </div>
          ))}
        </div>
      )}

      {!isEmpty && !paged && !expanded && hiddenCount > 0 && (
        <Button variant="link" size="sm" className="self-start text-xs" onClick={() => setExpanded(true)}>
          View all {records.length} →
        </Button>
      )}
      {!isEmpty && paged && hiddenCount > 0 && (
        <Button
          variant="link"
          size="sm"
          className="self-start text-xs"
          onClick={() => setVisibleCount((c) => c + paged.pageSize)}
        >
          View more ({hiddenCount} remaining) →
        </Button>
      )}
    </div>
  );
}
