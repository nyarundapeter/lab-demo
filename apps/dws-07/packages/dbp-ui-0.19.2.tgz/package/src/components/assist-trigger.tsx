import * as React from "react"
import { Ban } from "lucide-react"
import { AiMark } from "./ai-mark.js"
import { Button } from "./button.js"
import { cn } from "../lib/cn.js"

export type AssistTriggerState = "ready" | "loading" | "unavailable"

export interface AssistTriggerProps extends Omit<React.HTMLAttributes<HTMLElement>, "onClick"> {
  /** Button label when ready. Defaults to "Suggest". */
  label?: string
  onClick?: () => void
  /** Current state — passed in by the parent field, never owned here. Defaults to "ready". */
  state?: AssistTriggerState
  /** Alias for `state === "loading"`, kept for source-parity with field.jsx's `busy` prop. */
  busy?: boolean
}

/**
 * Small "AI" affordance button that sits at the end of a field label
 * (ai-example-dashboard/ai/field.jsx:23-31). Its `state` is a prop, never
 * owned state — the parent field drives loading/unavailable/ready.
 */
function AssistTrigger({ label = "Suggest", onClick, state = "ready", busy = false, className, ...props }: AssistTriggerProps) {
  if (state === "loading" || busy) {
    return (
      <span
        role="status"
        aria-live="polite"
        className={cn("inline-flex items-center gap-1.5 text-xs text-[hsl(var(--ai-strong))]", className)}
        {...props}
      >
        <AiMark size={11} className="motion-safe:animate-pulse" />
        Suggesting
      </span>
    )
  }

  if (state === "unavailable") {
    return (
      <span
        className={cn("inline-flex items-center gap-1 text-xs text-[hsl(var(--muted-foreground))]", className)}
        {...props}
      >
        <Ban size={11} aria-hidden="true" />
        AI unavailable
      </span>
    )
  }

  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      onClick={onClick}
      className={cn(
        "h-[22px] gap-1.5 rounded-[6px] border border-[hsl(var(--ai-border))] bg-[hsl(var(--ai-soft))] px-2 text-xs font-semibold text-[hsl(var(--ai-strong))] hover:bg-[hsl(var(--ai-soft)/0.7)] hover:text-[hsl(var(--ai-strong))] focus-visible:[box-shadow:var(--focus-ring-primary)]",
        className,
      )}
      {...(props as React.ButtonHTMLAttributes<HTMLButtonElement>)}
    >
      <AiMark size={11} />
      {label}
    </Button>
  )
}

export { AssistTrigger }
