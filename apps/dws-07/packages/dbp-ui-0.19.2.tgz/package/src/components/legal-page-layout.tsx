"use client"

import * as React from "react"
import { useEffect, useRef, useState } from "react"
import { PublicPageHeader } from "./public-page-header.js"

export interface LegalSection {
  id: string
  heading: string
  body: string[]
}

export interface LegalPageLayoutProps {
  eyebrow: string
  title: string
  subtitle: string
  lastUpdated: string
  sections: LegalSection[]
  /**
   * Optional email; any paragraph containing this string gets it linkified to a
   * `mailto:` anchor. When omitted, paragraphs render as plain text.
   */
  contactEmail?: string
}

function renderParagraph(para: string, key: number, contactEmail?: string): React.ReactElement {
  if (!contactEmail || !para.includes(contactEmail)) {
    return (
      <p key={key} className="text-base leading-relaxed text-[var(--color-text-secondary)]">
        {para}
      </p>
    )
  }
  const parts = para.split(contactEmail)
  return (
    <p key={key} className="text-base leading-relaxed text-[var(--color-text-secondary)]">
      {parts.map((part, j) =>
        j < parts.length - 1 ? (
          <span key={j}>
            {part}
            <a href={`mailto:${contactEmail}`} className="text-secondary hover:underline">
              {contactEmail}
            </a>
          </span>
        ) : (
          <span key={j}>{part}</span>
        ),
      )}
    </p>
  )
}

/**
 * LegalPageLayout — mesh header + two-column legal body with a sticky TOC that
 * highlights the section currently in view. Lifted from TMaaS LegalPageLayout,
 * token-aliased (text-dq-navy → text-[var(--color-text-primary)], the old TMaaS body-copy gray →
 * text-[var(--color-text-secondary)], text-dq-orange → text-secondary) and the
 * header band swapped to MeshSection.
 */
export function LegalPageLayout({
  eyebrow,
  title,
  subtitle,
  lastUpdated,
  sections,
  contactEmail,
}: LegalPageLayoutProps): React.ReactElement {
  const [activeId, setActiveId] = useState(sections[0]?.id ?? "")
  const intersectingRef = useRef<Map<string, boolean>>(new Map())

  useEffect(() => {
    const map = intersectingRef.current
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          map.set(entry.target.id, entry.isIntersecting)
        })
        const active = sections.find((s) => map.get(s.id))
        if (active) setActiveId(active.id)
      },
      { rootMargin: "0px 0px -70% 0px", threshold: 0 },
    )
    sections.forEach((s) => {
      const el = document.getElementById(s.id)
      if (el) observer.observe(el)
    })
    return () => observer.disconnect()
  }, [sections])

  return (
    <div className="flex flex-col">
      {/* A1 PublicPageHeader (gray band) → A3 white body */}
      <PublicPageHeader eyebrow={eyebrow} title={title} subtitle={subtitle}>
        <p className="mt-5 text-sm text-[var(--color-text-secondary)] opacity-70">
          Last updated: {lastUpdated}
        </p>
      </PublicPageHeader>

      <section className="border-t border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] px-5 py-14 md:px-8 md:py-20 lg:px-10">
        <div className="mx-auto max-w-[1200px] lg:grid lg:grid-cols-[220px_1fr] lg:gap-16 xl:gap-20">
          <nav className="hidden lg:block">
            <div className="sticky top-8">
              <p className="dq-overline mb-4 text-[var(--color-text-secondary)] opacity-70">Contents</p>
              <ol className="space-y-0.5">
                {sections.map((s) => {
                  const isActive = activeId === s.id
                  return (
                    <li key={s.id}>
                      <a
                        href={`#${s.id}`}
                        className={`block border-l-2 py-1.5 pl-3 text-xs leading-snug transition-all duration-150 ${
                          isActive
                            ? "border-secondary font-semibold text-[var(--color-text-primary)]"
                            : "border-transparent text-[var(--color-text-secondary)] opacity-70 hover:opacity-100"
                        }`}
                      >
                        {s.heading}
                      </a>
                    </li>
                  )
                })}
              </ol>
            </div>
          </nav>

          <div className="min-w-0">
            <nav className="mb-10 rounded-xl border border-[var(--color-border-subtle)] bg-[var(--color-surface)] p-5 lg:hidden">
              <p className="dq-overline mb-3 text-[var(--color-text-secondary)] opacity-70">Contents</p>
              <ol className="space-y-1.5">
                {sections.map((s) => (
                  <li key={s.id}>
                    <a
                      href={`#${s.id}`}
                      className="text-sm text-[var(--color-text-secondary)] transition-colors hover:text-secondary"
                    >
                      {s.heading}
                    </a>
                  </li>
                ))}
              </ol>
            </nav>

            <div className="space-y-12">
              {sections.map((s) => (
                <div key={s.id} id={s.id} className="scroll-mt-8">
                  <h2 className="mb-4 text-xl font-semibold tracking-tight text-[var(--color-text-primary)]">{s.heading}</h2>
                  <div className="space-y-3">
                    {s.body.map((para, i) => renderParagraph(para, i, contactEmail))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
