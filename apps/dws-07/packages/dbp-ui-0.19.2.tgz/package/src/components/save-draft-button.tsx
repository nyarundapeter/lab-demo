import * as React from "react";
import { Save } from "lucide-react";
import { Button, type ButtonProps } from "./button.js";

export interface SaveDraftButtonProps extends Omit<ButtonProps, "variant" | "children"> {
  label?: string;
  savingLabel?: string;
  saving?: boolean;
}

/**
 * "Save draft" footer action (overlay-modals.jsx `ModalFormView`,
 * overlay-drawers.jsx `DrawerForm`) — a quiet secondary path alongside
 * Cancel/Primary that preserves entered data without committing. Pairs with
 * `useUnsavedGuard`.
 */
export const SaveDraftButton = React.forwardRef<HTMLButtonElement, SaveDraftButtonProps>(
  ({ label = "Save draft", savingLabel = "Saving draft…", saving = false, disabled, ...props }, ref) => (
    <Button ref={ref} type="button" variant="ghost" disabled={disabled || saving} {...props}>
      <Save size={14} aria-hidden="true" />
      {saving ? savingLabel : label}
    </Button>
  ),
);
SaveDraftButton.displayName = "SaveDraftButton";
