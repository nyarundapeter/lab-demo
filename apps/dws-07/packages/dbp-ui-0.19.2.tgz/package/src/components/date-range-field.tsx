"use client"
import * as React from "react"
import { Calendar } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Input } from "./input.js"
import type { FieldState } from "./input.js"

export interface DateRangeValue {
  from?: string | undefined
  to?: string | undefined
}

export interface DateRangeFieldProps {
  id?: string
  value: DateRangeValue
  onChange: (value: DateRangeValue) => void
  disabled?: boolean | undefined
  state?: FieldState | undefined
  "aria-invalid"?: boolean | undefined
  /** Accessible label prefix for the two native date inputs, e.g. "Effective period" → "Effective period start"/"Effective period end". */
  label?: string | undefined
  className?: string | undefined
}

/**
 * DateRangeField — from/to date pair, `to` min-constrained by `from`
 * (forms-fields.jsx:277-294). Bare control (like RadioGroup/Switch) — a
 * consumer wraps it in `@dbp/ui` `FormField` for the label/helper/error
 * treatment; `label` here is only used to build the two inputs' aria-labels.
 */
const DateRangeField = React.forwardRef<HTMLDivElement, DateRangeFieldProps>(
  ({ id, value, onChange, disabled, state = "default", "aria-invalid": ariaInvalid, label, className }, ref) => {
    const invalid = ariaInvalid ?? (state === "error" ? "true" : undefined)
    return (
      <div ref={ref} id={id} className={cn("flex items-center gap-2", className)}>
        <div className="relative flex-1">
          <Calendar
            className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[var(--color-text-muted)]"
            aria-hidden="true"
          />
          <Input
            type="date"
            className="pl-9"
            value={value.from ?? ""}
            disabled={disabled}
            state={state}
            aria-invalid={invalid}
            aria-label={label ? `${label} start` : "Start date"}
            onChange={(e) => onChange({ from: e.target.value, to: value.to })}
          />
        </div>
        <span className="shrink-0 text-sm text-[var(--color-text-muted)]">to</span>
        <div className="relative flex-1">
          <Calendar
            className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[var(--color-text-muted)]"
            aria-hidden="true"
          />
          <Input
            type="date"
            className="pl-9"
            value={value.to ?? ""}
            disabled={disabled}
            min={value.from}
            state={state}
            aria-invalid={invalid}
            aria-label={label ? `${label} end` : "End date"}
            onChange={(e) => onChange({ from: value.from, to: e.target.value })}
          />
        </div>
      </div>
    )
  },
)
DateRangeField.displayName = "DateRangeField"

export { DateRangeField }
