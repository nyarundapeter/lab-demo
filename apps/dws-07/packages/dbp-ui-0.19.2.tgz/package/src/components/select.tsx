"use client"
import * as React from "react"
import * as SelectPrimitive from "@radix-ui/react-select"
import { Check, ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "../lib/cn.js"
import type { FieldState } from "./input.js"
import { sectionLabelVariants } from "./section-label.js"

const Select = SelectPrimitive.Root
const SelectGroup = SelectPrimitive.Group
const SelectValue = SelectPrimitive.Value

const selectStateBorderClasses: Record<Exclude<FieldState, "default">, string> = {
  error: "border-danger focus-visible:[box-shadow:var(--focus-ring-error)]",
  warning: "border-warning focus-visible:[box-shadow:var(--focus-ring-warning)]",
  success: "border-success focus-visible:[box-shadow:var(--focus-ring-success)]",
}

const SelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Trigger> & { error?: boolean; state?: FieldState }
>(({ className, error, state, children, ...props }, ref) => {
  const resolvedState: FieldState = error ? "error" : (state ?? "default")
  return (
  <SelectPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex h-[var(--form-field-h)] w-full items-center justify-between gap-2",
      "rounded-input px-3 text-sm",
      "[&>span:first-child]:min-w-0 [&>span:first-child]:truncate [&>span:first-child]:whitespace-nowrap",
      "bg-surface text-[var(--color-text-primary)]",
      "border",
      "transition-colors motion-safe:transition-all",
      "placeholder:text-[var(--color-text-disabled)]",
      "disabled:cursor-not-allowed disabled:opacity-50",
      "focus-visible:outline-none",
      "select-none",
      resolvedState === "default"
        ? [
            "border-[var(--color-border-default)]",
            "hover:border-[var(--color-border-strong)]",
            "focus-visible:border-primary focus-visible:[box-shadow:var(--focus-ring-navy)]",
            "data-[state=open]:border-primary data-[state=open]:[box-shadow:var(--focus-ring-navy)]",
          ]
        : selectStateBorderClasses[resolvedState],
      className
    )}
    {...props}
  >
    {children}
    <SelectPrimitive.Icon asChild>
      <ChevronDown
        size={15}
        strokeWidth={1.5}
        className="shrink-0 text-[var(--color-text-muted)] transition-transform duration-200 group-data-[state=open]:rotate-180"
      />
    </SelectPrimitive.Icon>
  </SelectPrimitive.Trigger>
  )
})
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName

const SelectScrollUpButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollUpButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollUpButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollUpButton
    ref={ref}
    className={cn(
      "flex cursor-pointer items-center justify-center py-1",
      "text-[var(--color-text-muted)]",
      className
    )}
    {...props}
  >
    <ChevronUp size={14} strokeWidth={1.5} />
  </SelectPrimitive.ScrollUpButton>
))
SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName

const SelectScrollDownButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollDownButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollDownButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollDownButton
    ref={ref}
    className={cn(
      "flex cursor-pointer items-center justify-center py-1",
      "text-[var(--color-text-muted)]",
      className
    )}
    {...props}
  >
    <ChevronDown size={14} strokeWidth={1.5} />
  </SelectPrimitive.ScrollDownButton>
))
SelectScrollDownButton.displayName = SelectPrimitive.ScrollDownButton.displayName

const SelectContent = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Content>
>(({ className, children, position = "popper", ...props }, ref) => (
  <SelectPrimitive.Portal>
    <SelectPrimitive.Content
      ref={ref}
      position={position}
      sideOffset={4}
      className={cn(
        "relative z-[var(--z-dropdown)]",
        "min-w-[8rem] overflow-hidden",
        "rounded-[var(--radius-card)]",
        "border border-[var(--color-border-default)]",
        "bg-[var(--color-surface-content)] shadow-[var(--shadow-lg)]",
        "data-[state=open]:animate-in data-[state=closed]:animate-out",
        "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
        "data-[side=bottom]:slide-in-from-top-2 data-[side=top]:slide-in-from-bottom-2",
        position === "popper" && "w-[var(--radix-select-trigger-width)]",
        className
      )}
      {...props}
    >
      <SelectScrollUpButton />
      <SelectPrimitive.Viewport
        className={cn(
          "p-1",
          position === "popper" && "max-h-60"
        )}
      >
        {children}
      </SelectPrimitive.Viewport>
      <SelectScrollDownButton />
    </SelectPrimitive.Content>
  </SelectPrimitive.Portal>
))
SelectContent.displayName = SelectPrimitive.Content.displayName

const SelectLabel = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Label>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Label
    ref={ref}
    className={cn("px-3 py-1.5", sectionLabelVariants(), className)}
    {...props}
  />
))
SelectLabel.displayName = SelectPrimitive.Label.displayName

const SelectItem = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Item>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-pointer select-none items-center",
      "rounded-[var(--radius-button)]",
      "py-2 pl-3 pr-8",
      "text-sm text-[var(--color-text-secondary)]",
      "outline-none",
      "transition-colors",
      "hover:bg-[var(--color-navy-50)] hover:text-[var(--color-text-primary)]",
      "focus:bg-[var(--color-navy-50)] focus:text-[var(--color-text-primary)]",
      "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      "data-[state=checked]:font-semibold data-[state=checked]:text-[var(--color-text-primary)]",
      className
    )}
    {...props}
  >
    <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
    <SelectPrimitive.ItemIndicator className="absolute right-3 flex items-center">
      <Check size={14} strokeWidth={2} className="text-[var(--color-text-primary)]" />
    </SelectPrimitive.ItemIndicator>
  </SelectPrimitive.Item>
))
SelectItem.displayName = SelectPrimitive.Item.displayName

const SelectSeparator = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-[var(--color-border-subtle)]", className)}
    {...props}
  />
))
SelectSeparator.displayName = SelectPrimitive.Separator.displayName

export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton,
}
