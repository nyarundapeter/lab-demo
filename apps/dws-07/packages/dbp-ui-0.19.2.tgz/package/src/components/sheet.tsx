import * as React from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn.js";

const Sheet = DialogPrimitive.Root;
const SheetTrigger = DialogPrimitive.Trigger;
const SheetClose = DialogPrimitive.Close;
const SheetPortal = DialogPrimitive.Portal;

const SheetOverlay = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    className={cn(
      "fixed inset-0 z-[var(--z-overlay)] bg-[color-mix(in_srgb,var(--color-primary)_55%,transparent)] backdrop-blur-[2px] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className,
    )}
    {...props}
    ref={ref}
  />
));
SheetOverlay.displayName = DialogPrimitive.Overlay.displayName;

const sheetVariants = cva(
  "fixed z-[var(--z-modal)] flex flex-col gap-4 bg-[var(--color-surface)] p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out",
  {
    variants: {
      side: {
        right:
          "inset-y-0 right-0 h-full w-[var(--shell-panel-w)] border-l border-[var(--color-border)] data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right",
        left: "inset-y-0 left-0 h-full w-[var(--shell-panel-w)] border-r border-[var(--color-border)] data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left",
        top: "inset-x-0 top-0 border-b border-[var(--color-border)] data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
        bottom:
          "inset-x-0 bottom-0 rounded-t-[var(--radius-modal)] border-t border-[var(--color-border)] data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
      },
      size: {
        narrow: "w-[360px]",
        standard: "w-[460px]",
        wide: "w-[640px]",
        xwide: "w-[860px]",
      },
    },
    defaultVariants: {
      side: "right",
    },
  },
);

/**
 * Bottom-sheet detents (overlay ruling N9 — Sharavi 2026-07-17, closing
 * deferral row 7). Values per docs/03-features/specs/claude-design-briefs/
 * design-run-pack-2026-07-12/_outputs/overlay-system/overlay-mobile.jsx's
 * `MobileSheet` reference: compact/half/full as viewport-relative heights,
 * not px. `detent` only applies when `side="bottom"` — additive, ignored
 * for the other three sides.
 */
export type SheetDetent = "compact" | "half" | "full";

const DETENT_HEIGHT: Record<SheetDetent, string> = {
  compact: "32vh",
  half: "55vh",
  full: "92vh",
};

/** Merge a forwarded ref with a locally-owned one (resize handle needs the DOM node). */
function mergeRefs<T>(...refs: Array<React.Ref<T> | undefined>): React.RefCallback<T> {
  return (node) => {
    for (const ref of refs) {
      if (!ref) continue;
      if (typeof ref === "function") ref(node);
      else (ref as React.MutableRefObject<T | null>).current = node;
    }
  };
}

interface SheetContentProps
  extends React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content>,
    VariantProps<typeof sheetVariants> {
  /** Set to true when the consumer supplies its own header close control, to avoid two stacked X buttons. Defaults to false (unchanged behaviour). */
  hideClose?: boolean;
  /** Only meaningful when `side="bottom"`. @default "half" */
  detent?: SheetDetent;
  /** Shows the drag-handle grip above the header, per the bottom-sheet reference. @default true when side="bottom" && detent is set */
  showGrip?: boolean;
  /**
   * Drag-to-resize handle (OVL-07 — `overlay-core.jsx:139-149,162`). Only
   * meaningful for `side="left"`/`"right"`. Renders a grab handle on the
   * drawer's inner edge; drag or Left/Right arrow keys (when focused) adjust
   * width between `minWidth`/`maxWidth`.
   */
  resizable?: boolean;
  /** @default 320 */
  minWidth?: number;
  /** @default 960 */
  maxWidth?: number;
  /** Fires once, on drag end / keyboard commit — the width to persist. */
  onResizeEnd?: (width: number) => void;
  /**
   * Swipe-to-dismiss (OVL-11 — `overlay-mobile.jsx`'s `MobileSheet`). Only
   * meaningful for `side="bottom"`. Dragging the grip handle down past a
   * threshold closes the sheet, matching a native bottom-sheet gesture.
   * @default false
   */
  swipeToDismiss?: boolean;
  /**
   * Whether the sheet can be dismissed at all — Escape, outside-click, and
   * swipe (`overlay-mobile.jsx`: "disabled when there are unsaved changes or
   * a high-risk action" — e.g. a bottom-sheet form holding unsaved input).
   * @default true
   */
  dismissable?: boolean;
}

const SheetContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  SheetContentProps
>(({ side = "right", size, detent, showGrip, resizable, minWidth = 320, maxWidth = 960, onResizeEnd, swipeToDismiss = false, dismissable = true, hideClose = false, className, style, children, onEscapeKeyDown, onPointerDownOutside, onInteractOutside, ...props }, ref) => {
  const isBottomDetent = side === "bottom" && detent != null;
  const isResizableDrawer = resizable === true && (side === "left" || side === "right");
  const isSwipeableSheet = swipeToDismiss === true && side === "bottom";
  const contentRef = React.useRef<HTMLDivElement>(null);
  const closeRef = React.useRef<HTMLButtonElement>(null);
  const [width, setWidth] = React.useState<number | undefined>(undefined);
  const [dragY, setDragY] = React.useState(0);
  const [dragging, setDragging] = React.useState(false);

  const handleSwipeDown = React.useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if (!dismissable) return;
      e.preventDefault();
      const startY = e.clientY;
      const startHeight = contentRef.current?.getBoundingClientRect().height ?? 1;
      setDragging(true);
      function onMove(ev: PointerEvent) {
        setDragY(Math.max(0, ev.clientY - startY));
      }
      function onUp(ev: PointerEvent) {
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
        setDragging(false);
        const delta = Math.max(0, ev.clientY - startY);
        if (delta > startHeight * 0.25 || delta > 120) {
          closeRef.current?.click();
        }
        setDragY(0);
      }
      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup", onUp);
    },
    [dismissable],
  );

  const handlePointerDown = React.useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      e.preventDefault();
      const startX = e.clientX;
      const startWidth = contentRef.current?.getBoundingClientRect().width ?? minWidth;

      function clamp(next: number) {
        return Math.min(maxWidth, Math.max(minWidth, next));
      }
      function onMove(ev: PointerEvent) {
        const delta = side === "right" ? startX - ev.clientX : ev.clientX - startX;
        setWidth(clamp(startWidth + delta));
      }
      function onUp() {
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
        const finalWidth = contentRef.current?.getBoundingClientRect().width;
        if (finalWidth != null) onResizeEnd?.(finalWidth);
      }
      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup", onUp);
    },
    [side, minWidth, maxWidth, onResizeEnd],
  );

  const handleKeyDown = React.useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      const step = 16;
      const grow = side === "right" ? "ArrowLeft" : "ArrowRight";
      const shrink = side === "right" ? "ArrowRight" : "ArrowLeft";
      if (e.key !== grow && e.key !== shrink) return;
      e.preventDefault();
      const current = width ?? contentRef.current?.getBoundingClientRect().width ?? minWidth;
      const next = Math.min(maxWidth, Math.max(minWidth, current + (e.key === grow ? step : -step)));
      setWidth(next);
      onResizeEnd?.(next);
    },
    [side, width, minWidth, maxWidth, onResizeEnd],
  );

  return (
    <SheetPortal>
      <SheetOverlay />
      <DialogPrimitive.Content
        ref={mergeRefs(ref, contentRef)}
        className={cn(sheetVariants({ side, size }), className)}
        style={{
          ...style,
          ...(isBottomDetent ? { height: DETENT_HEIGHT[detent] } : {}),
          ...(isResizableDrawer && width != null ? { width } : {}),
          ...(isSwipeableSheet
            ? { transform: `translateY(${dragY}px)`, transition: dragging ? "none" : undefined }
            : {}),
        }}
        onEscapeKeyDown={(e) => {
          if (!dismissable) e.preventDefault();
          onEscapeKeyDown?.(e);
        }}
        onPointerDownOutside={(e) => {
          if (!dismissable) e.preventDefault();
          onPointerDownOutside?.(e);
        }}
        onInteractOutside={(e) => {
          if (!dismissable) e.preventDefault();
          onInteractOutside?.(e);
        }}
        {...props}
      >
        {isBottomDetent && (showGrip ?? true) && (
          <div
            className={cn(
              "-mx-6 -mt-6 mb-2 flex shrink-0 justify-center pb-1 pt-2",
              isSwipeableSheet && "touch-none cursor-grab active:cursor-grabbing",
            )}
            aria-hidden="true"
            {...(isSwipeableSheet ? { onPointerDown: handleSwipeDown } : {})}
          >
            <span className="h-1 w-9 rounded-full bg-[var(--color-border)]" />
          </div>
        )}
        {children}
        {!hideClose && (
          <DialogPrimitive.Close
            ref={closeRef}
            className={cn(
              "absolute right-4 top-4",
              "flex h-7 w-7 items-center justify-center rounded-[var(--radius-button)]",
              "text-[var(--color-text-muted)]",
              "transition-colors",
              "hover:bg-[var(--color-navy-50)] hover:text-[var(--color-text-primary)]",
              "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
              "disabled:pointer-events-none",
            )}
          >
            <X size={16} strokeWidth={1.5} aria-hidden="true" />
            <span className="sr-only">Close</span>
          </DialogPrimitive.Close>
        )}
        {isResizableDrawer && (
          <div
            role="separator"
            aria-orientation="vertical"
            aria-label="Resize panel"
            tabIndex={0}
            onPointerDown={handlePointerDown}
            onKeyDown={handleKeyDown}
            className={cn(
              "absolute inset-y-0 z-[1] w-1.5 cursor-col-resize touch-none select-none",
              "hover:bg-[color-mix(in_srgb,var(--color-primary)_25%,transparent)]",
              "focus-visible:outline-none focus-visible:bg-[color-mix(in_srgb,var(--color-primary)_35%,transparent)]",
              side === "right" ? "left-0 -translate-x-1/2" : "right-0 translate-x-1/2",
            )}
          />
        )}
      </DialogPrimitive.Content>
    </SheetPortal>
  );
});
SheetContent.displayName = DialogPrimitive.Content.displayName;

const SheetHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("flex flex-col space-y-2 text-left", className)}
    {...props}
  />
);
SheetHeader.displayName = "SheetHeader";

const SheetTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold leading-snug text-[var(--color-text-primary)] pr-8", className)}
    {...props}
  />
));
SheetTitle.displayName = DialogPrimitive.Title.displayName;

const SheetDescription = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-[var(--color-text-muted)]", className)}
    {...props}
  />
));
SheetDescription.displayName = DialogPrimitive.Description.displayName;

export {
  Sheet,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
};
