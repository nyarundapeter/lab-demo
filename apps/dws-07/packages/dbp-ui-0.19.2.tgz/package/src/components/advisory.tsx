import * as React from "react"
import { Scale } from "lucide-react"
import { cn } from "../lib/cn.js"

export type AdvisoryProps = React.HTMLAttributes<HTMLSpanElement>

/**
 * Governance vocabulary marker — flags that an AI output is advisory only and
 * a human must decide. Never conveyed by colour alone: icon + explicit text.
 */
function Advisory({ className, children, ...props }: AdvisoryProps) {
  return (
    <span
      role="note"
      className={cn(
        "inline-flex items-center gap-1.5 text-xs font-medium text-[hsl(var(--muted-foreground))]",
        className,
      )}
      {...props}
    >
      <Scale size={12} aria-hidden="true" />
      {children ?? "Advisory only — human decision required"}
    </span>
  )
}

export { Advisory }
