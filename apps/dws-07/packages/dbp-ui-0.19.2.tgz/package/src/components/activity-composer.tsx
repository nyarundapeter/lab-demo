"use client";

import * as React from "react";
import { Bold, Italic, Link2, List, ListOrdered, Paperclip, Send, X, Tag as TagIcon } from "lucide-react";
import { EditorContent, ReactRenderer, useEditor, type Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import Mention from "@tiptap/extension-mention";
import Placeholder from "@tiptap/extension-placeholder";
import type { SuggestionOptions } from "@tiptap/suggestion";
import { cn } from "../lib/cn.js";
import { Avatar } from "./avatar.js";
import { Badge } from "./badge.js";
import { Button } from "./button.js";
import type { ActivityDraft, ActivityMentionUser, ActivityTimelineConfig } from "../schemas/activity.js";

/**
 * ActivityComposer — note entry for the activity timeline (activity-timeline-spec-2026-07-10.md
 * §7). Presentational: no fetch/persist calls, `onSave` hands the draft to the host organism
 * (which owns PS.DATA persistence and PS.NOTIF mention wiring).
 *
 * ── ADR-0048 ───────────────────────────────────────────────────────────────────────────────
 * Rich text via Tiptap v3, minimal extension profile per the ADR: bold/italic/lists/links + a
 * Mention node — no track-changes/grammar-check/kitchen-sink extensions. `@dbp/doc-editor`
 * (ADR-0045) does not exist on this branch yet, so this is the ADR's named escape hatch: a
 * direct, narrowly-scoped Tiptap instance inside `@dbp/ui`, not a fork of doc-editor. When
 * `@dbp/doc-editor` lands with a minimal-profile config surface, this mount point converges on
 * it (do not build a second independent integration alongside that one).
 *
 * Stored format (spec §6.1): Tiptap JSON in `ActivityDraft.body`, derived plain text in
 * `plainText` (search/preview/notifications) via `editor.getText()`. `#tag` stays a separate,
 * non-inline control (chips below the editor) — the spec's Tag node is deferred; the existing
 * chip UI already satisfies §6.3 without adding a second inline-node dialect to the minimal
 * profile the ADR asks for.
 */

const iconButtonBase = cn(
  "inline-flex h-7 w-7 items-center justify-center rounded-[6px] transition-colors",
  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
);

const toolbarButtonBase = cn(
  "inline-flex h-6 w-6 items-center justify-center rounded-[4px] transition-colors",
  "text-[var(--color-text-muted)] hover:bg-[var(--color-surface)] hover:text-[var(--color-text)]",
  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
);

export interface ActivityComposerProps {
  config: ActivityTimelineConfig;
  /** Candidates for the `@mention` picker — only consulted when `config.mentions` is true. */
  mentionCandidates?: ActivityMentionUser[];
  onSave: (draft: ActivityDraft) => void;
  /**
   * Prop seam for future attachment upload wiring (spec §7 / §6.4, `@dbp/ps-storage` — not built
   * in this lane, see docs/03-features/specs/spec-ps-storage-requirements-2026-07-17.md). The
   * attach affordance below stays a disabled stub regardless; this prop only reserves the
   * interface shape so a later lane can wire it without a breaking type change.
   */
  onAttachFiles?: (files: FileList) => void;
  className?: string;
}

/** Extracts `{id, name}` mention nodes from a Tiptap JSON doc, in document order, de-duplicated. */
function extractMentionIds(json: Record<string, unknown>): string[] {
  const seen = new Set<string>();
  const ids: string[] = [];
  function walk(node: unknown): void {
    if (!node || typeof node !== "object") return;
    const n = node as { type?: string; attrs?: { id?: string }; content?: unknown[] };
    if (n.type === "mention" && n.attrs?.id && !seen.has(n.attrs.id)) {
      seen.add(n.attrs.id);
      ids.push(n.attrs.id);
    }
    if (Array.isArray(n.content)) n.content.forEach(walk);
  }
  walk(json);
  return ids;
}

interface MentionListProps {
  items: ActivityMentionUser[];
  command: (item: { id: string; label: string }) => void;
}

interface MentionListHandle {
  onKeyDown: (props: { event: KeyboardEvent }) => boolean;
}

const MentionList = React.forwardRef<MentionListHandle, MentionListProps>(function MentionList(
  { items, command },
  ref,
) {
  const [selected, setSelected] = React.useState(0);

  React.useEffect(() => setSelected(0), [items]);

  const select = React.useCallback(
    (index: number) => {
      const item = items[index];
      if (item) command({ id: item.id, label: item.name });
    },
    [items, command],
  );

  React.useImperativeHandle(ref, () => ({
    onKeyDown: ({ event }) => {
      if (event.key === "ArrowDown") {
        setSelected((i) => (i + 1) % Math.max(items.length, 1));
        return true;
      }
      if (event.key === "ArrowUp") {
        setSelected((i) => (i - 1 + Math.max(items.length, 1)) % Math.max(items.length, 1));
        return true;
      }
      if (event.key === "Enter" || event.key === "Tab") {
        select(selected);
        return true;
      }
      return false;
    },
  }));

  return (
    <div
      role="listbox"
      aria-label="Mention a teammate"
      className="w-56 overflow-hidden rounded-[6px] border border-[var(--color-border-default)] bg-[var(--color-surface-content)] shadow-lg"
    >
      {items.length === 0 ? (
        <p className="px-3 py-2.5 text-sm text-[var(--color-text-muted)]">No matching teammates</p>
      ) : (
        items.map((u, i) => (
          <button
            key={u.id}
            type="button"
            role="option"
            aria-selected={i === selected}
            onMouseDown={(e) => {
              e.preventDefault();
              select(i);
            }}
            className={cn(
              "flex w-full items-center gap-2 px-3 py-2 text-left text-sm",
              i === selected ? "bg-[var(--color-surface)]" : "hover:bg-[var(--color-surface)]",
            )}
          >
            <Avatar name={u.name} size="sm" className="h-6 w-6 text-xs" />
            <span className="text-[var(--color-text)]">{u.name}</span>
          </button>
        ))
      )}
    </div>
  );
});

/** Builds the Tiptap Mention `suggestion` option against a live candidate list (via a ref, so
 *  updates to `mentionCandidates` don't require reconfiguring the extension). */
function buildMentionSuggestion(
  candidatesRef: React.RefObject<ActivityMentionUser[]>,
): Omit<SuggestionOptions, "editor"> {
  return {
    char: "@",
    items: ({ query }) =>
      candidatesRef.current.filter((u) => u.name.toLowerCase().includes(query.toLowerCase())).slice(0, 8),
    render: () => {
      let component: ReactRenderer<MentionListHandle, MentionListProps>;
      let popup: HTMLDivElement;

      return {
        onStart: (props) => {
          component = new ReactRenderer(MentionList, { props, editor: props.editor });
          popup = document.createElement("div");
          popup.style.position = "absolute";
          popup.style.zIndex = "50";
          popup.appendChild(component.element);
          document.body.appendChild(popup);
          const rect = props.clientRect?.();
          if (rect) {
            popup.style.left = `${rect.left + window.scrollX}px`;
            popup.style.top = `${rect.bottom + window.scrollY + 4}px`;
          }
        },
        onUpdate: (props) => {
          component.updateProps(props);
          const rect = props.clientRect?.();
          if (rect) {
            popup.style.left = `${rect.left + window.scrollX}px`;
            popup.style.top = `${rect.bottom + window.scrollY + 4}px`;
          }
        },
        onKeyDown: (props) => {
          if (props.event.key === "Escape") {
            popup.remove();
            component.destroy();
            return true;
          }
          return component.ref?.onKeyDown(props) ?? false;
        },
        onExit: () => {
          popup.remove();
          component.destroy();
        },
      };
    },
  };
}

function Toolbar({ editor }: { editor: Editor | null }) {
  if (!editor) return null;
  return (
    <div className="mb-1.5 flex items-center gap-0.5 border-b border-[var(--color-border)] pb-1.5">
      <button
        type="button"
        aria-label="Bold"
        aria-pressed={editor.isActive("bold")}
        onClick={() => editor.chain().focus().toggleBold().run()}
        className={cn(toolbarButtonBase, editor.isActive("bold") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <Bold className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label="Italic"
        aria-pressed={editor.isActive("italic")}
        onClick={() => editor.chain().focus().toggleItalic().run()}
        className={cn(toolbarButtonBase, editor.isActive("italic") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <Italic className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label="Bullet list"
        aria-pressed={editor.isActive("bulletList")}
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        className={cn(toolbarButtonBase, editor.isActive("bulletList") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <List className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label="Numbered list"
        aria-pressed={editor.isActive("orderedList")}
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
        className={cn(toolbarButtonBase, editor.isActive("orderedList") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <ListOrdered className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label="Link"
        aria-pressed={editor.isActive("link")}
        onClick={() => {
          const url = window.prompt("URL");
          if (url) editor.chain().focus().setLink({ href: url }).run();
          else editor.chain().focus().unsetLink().run();
        }}
        className={cn(toolbarButtonBase, editor.isActive("link") && "bg-[var(--color-surface)] text-[var(--color-text)]")}
      >
        <Link2 className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
    </div>
  );
}

export function ActivityComposer({ config, mentionCandidates = [], onSave, className }: ActivityComposerProps) {
  const labels = config.labels ?? {};
  const candidatesRef = React.useRef(mentionCandidates);
  candidatesRef.current = mentionCandidates;

  const [tagDraft, setTagDraft] = React.useState("");
  const [tags, setTags] = React.useState<string[]>([]);
  const [isEmpty, setIsEmpty] = React.useState(true);

  const placeholder = labels.composerPlaceholder ?? (config.mentions ? "Add a note… use @ to mention teammates" : "Add a note…");

  const extensions = React.useMemo(
    () => [
      StarterKit.configure({
        heading: false,
        blockquote: false,
        codeBlock: false,
        horizontalRule: false,
        link: false,
      }),
      Link.configure({ openOnClick: false, autolink: true }),
      Placeholder.configure({ placeholder }),
      ...(config.mentions
        ? [
            Mention.configure({
              HTMLAttributes: { class: "activity-mention" },
              suggestion: buildMentionSuggestion(candidatesRef),
            }),
          ]
        : []),
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps -- extensions are static per mount; mentions toggle re-mounts the editor via key
    [config.mentions],
  );

  const editor = useEditor({
    extensions,
    immediatelyRender: false,
    editorProps: {
      attributes: {
        role: "textbox",
        "aria-label": labels.composerLabel ?? "Activity note",
        class: "min-h-[64px] text-sm text-[var(--color-text)] outline-none [&_p]:m-0",
      },
    },
    onUpdate: ({ editor: ed }) => setIsEmpty(ed.isEmpty),
  });

  function addTagFromDraft() {
    const val = tagDraft.trim().replace(/^#/, "");
    if (!val || tags.includes(val)) {
      setTagDraft("");
      return;
    }
    setTags((prev) => [...prev, val]);
    setTagDraft("");
  }

  function onTagKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTagFromDraft();
    } else if (e.key === "Backspace" && tagDraft === "" && tags.length > 0) {
      setTags((prev) => prev.slice(0, -1));
    }
  }

  const dirty = !isEmpty || tags.length > 0;

  function handleSave() {
    if (!editor) return;
    const json = editor.getJSON() as Record<string, unknown>;
    const draft: ActivityDraft = {
      body: JSON.stringify(json),
      plainText: editor.getText().trim(),
      tags,
      mentionedUserIds: extractMentionIds(json),
    };
    onSave(draft);
    editor.commands.clearContent(true);
    setTags([]);
    setTagDraft("");
    setIsEmpty(true);
  }

  return (
    <div
      className={cn(
        "flex flex-col gap-2 rounded-[6px] border-[1.5px] border-[var(--color-border-default)] bg-[var(--color-surface-content)] p-3 transition-colors",
        "focus-within:border-primary focus-within:[box-shadow:var(--focus-ring-primary)]",
        className,
      )}
    >
      <div className="activity-composer-editor">
        <style>{`
          .activity-composer-editor .is-editor-empty:first-child::before {
            content: attr(data-placeholder);
            float: left;
            height: 0;
            pointer-events: none;
            color: var(--color-text-disabled);
          }
        `}</style>
        <Toolbar editor={editor} />
        <EditorContent editor={editor} />
      </div>

      {config.tags && (
        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
          {tags.map((t) => (
            <Badge key={t} tone="gray" size="sm">
              <TagIcon className="h-2.5 w-2.5" aria-hidden="true" />
              {t}
              <button
                type="button"
                aria-label={`Remove tag ${t}`}
                onClick={() => setTags((prev) => prev.filter((x) => x !== t))}
                className="ml-0.5 rounded-full text-[var(--color-text-disabled)] hover:text-[var(--color-danger-text)]"
              >
                <X className="h-2.5 w-2.5" aria-hidden="true" />
              </button>
            </Badge>
          ))}
          <input
            value={tagDraft}
            onChange={(e) => setTagDraft(e.target.value)}
            onKeyDown={onTagKeyDown}
            onBlur={addTagFromDraft}
            placeholder={tags.length === 0 ? (labels.tagsPlaceholder ?? "#tag and press Enter") : ""}
            aria-label="Add tag"
            className="min-w-[100px] flex-1 bg-transparent text-xs text-[var(--color-text)] outline-none placeholder:text-[var(--color-text-disabled)]"
          />
        </div>
      )}

      <div className="flex items-center gap-1 border-t border-[var(--color-border)] pt-2">
        {config.attachments && (
          <button
            type="button"
            disabled
            aria-disabled="true"
            aria-label="Attach a file"
            title="Attachments coming soon"
            className={cn(iconButtonBase, "cursor-not-allowed text-[var(--color-text-disabled)] opacity-60")}
          >
            <Paperclip className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        )}
        <div className="flex-1" />
        <Button variant="navy" size="sm" disabled={!dirty} onClick={handleSave}>
          <Send className="h-3.5 w-3.5" aria-hidden="true" />
          {labels.save ?? "Save note"}
        </Button>
      </div>
    </div>
  );
}
