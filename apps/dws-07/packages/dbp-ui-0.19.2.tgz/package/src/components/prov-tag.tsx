import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import type { AiProvenance } from "@dbp/contracts"
import { badgeShellClass } from "./badge.js"
import { cn } from "../lib/cn"

const PROV_LABEL: Record<AiProvenance, string> = {
  source: "Source data",
  calc: "Calculated",
  ai: "AI interpretation",
  predict: "AI prediction",
  human: "Human-confirmed",
  auto: "Automated",
}

/**
 * ProvTag folds its outer pill shell onto Badge's shared shell mechanics
 * (`badgeShellClass` — inline-flex/items-center/border/font-semibold/
 * select-none/whitespace-nowrap), the same de-dup applied to EnvPill. It does
 * NOT compose `<Badge tone>` itself: the 6-way provenance taxonomy
 * (source/calc/ai/predict/human/auto) is coloured from a distinct
 * `--prov-*` token family, not Badge's status/severity tone set — `ai` is
 * the one provenance that already reuses Badge's own `ai` tone tokens
 * (`--ai-*`), the rest have no equivalent Badge tone to map onto without
 * misrepresenting the source/calc/predict/human/auto distinction. Per-
 * provenance size (18px/10.5px), inner gap (5px) and radius (4px) also
 * differ from Badge's own scale, kept here rather than forced onto Badge's
 * gap-1.5/px-2.5/rounded-pill — this whole shell string is a deliberate,
 * self-contained micro-recipe (Wave 2.F keep).
 */
const provTagVariants = cva(
  cn(badgeShellClass, "gap-[5px] h-[18px] px-[6px] rounded-[4px] text-[10.5px]"),
  {
    variants: {
      provenance: {
        source: "text-[hsl(var(--prov-source))] bg-[hsl(var(--background))] border-[hsl(var(--border))]",
        calc: "text-[hsl(var(--prov-calc))] bg-[hsl(var(--background))] border-[hsl(var(--prov-calc)/0.3)]",
        ai: "text-[hsl(var(--ai-strong))] bg-[hsl(var(--ai-soft))] border-[hsl(var(--ai-border))]",
        predict: "text-[hsl(var(--prov-predict))] bg-[hsl(var(--background))] border-[hsl(var(--prov-predict)/0.3)]",
        human: "text-[hsl(var(--prov-human))] bg-[hsl(var(--background))] border-[hsl(var(--prov-human)/0.3)]",
        auto: "text-[hsl(var(--prov-auto))] bg-[hsl(var(--background))] border-[hsl(var(--prov-auto)/0.3)]",
      },
    },
    defaultVariants: {
      provenance: "source",
    },
  }
)

const provDotVariants = cva("w-[6px] h-[6px] shrink-0 bg-current", {
  variants: {
    provenance: {
      source: "rounded-[2px]",
      calc: "rounded-[2px]",
      ai: "rounded-[2px] bg-[hsl(var(--ai))]",
      predict: "rounded-[1px] rotate-45",
      human: "rounded-full",
      auto: "rounded-full",
    },
  },
  defaultVariants: {
    provenance: "source",
  },
})

export interface ProvTagProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof provTagVariants> {
  /** 6-way provenance taxonomy — where a value on screen came from. Defaults to "source". */
  provenance?: AiProvenance
}

/** Provenance tag — source / calc / ai / predict / human / auto. */
function ProvTag({ className, provenance = "source", children, ...props }: ProvTagProps) {
  return (
    <span className={cn(provTagVariants({ provenance }), className)} {...props}>
      <span aria-hidden className={cn(provDotVariants({ provenance }))} />
      {children ?? PROV_LABEL[provenance]}
    </span>
  )
}

export { ProvTag, provTagVariants, PROV_LABEL }
