import * as React from "react"
import { GitBranch, ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Badge } from "./badge.js"
import { Button } from "./button.js"
import { VerticalStageTracker, type StageRow } from "./vertical-stage-tracker.js"

/**
 * ConditionalTracker — Wave 3 Family 3 molecule (no registry id, flat @dbp/ui component). Reference:
 * wf-trackers.jsx `ConditionalTracker` — shows the active path (via the
 * existing VerticalStageTracker, non-expandable) with the decision that
 * produced it, and keeps not-taken alternative paths collapsed until asked
 * for. A thin composition/wrapper, not a ground-up renderer — the alt-path
 * toggle is the only genuinely new behaviour VerticalStageTracker lacks.
 */
export interface ConditionalAlternative {
  id: string
  label: string
  description: string
}

export interface ConditionalTrackerProps {
  /** The active path's stages, rendered via VerticalStageTracker. */
  stages: StageRow[]
  /** The decision that produced the active path, e.g. "Amount ≥ €25,000". */
  decision: string
  /** Paths not taken for this instance. */
  alternatives: ConditionalAlternative[]
  className?: string
}

export function ConditionalTracker({ stages, decision, alternatives, className }: ConditionalTrackerProps) {
  const [showAlt, setShowAlt] = React.useState(false)

  return (
    <div className={cn("flex flex-col", className)}>
      <div className="mb-3 flex items-center gap-2">
        <Badge tone="info" size="sm">
          <GitBranch size={11} aria-hidden="true" />
          Active path
        </Badge>
        <span className="text-xs text-[var(--color-text-muted)]">{decision}</span>
      </div>

      <VerticalStageTracker stages={stages} expandable={false} />

      <Button
        type="button"
        variant="outline"
        size="sm"
        className="mt-3.5 w-fit"
        onClick={() => setShowAlt((v) => !v)}
        data-testid="conditional-tracker-toggle-alternatives"
      >
        {showAlt ? <ChevronUp size={13} aria-hidden="true" /> : <ChevronDown size={13} aria-hidden="true" />}
        {showAlt ? "Hide" : "Show"} alternative paths ({alternatives.length})
      </Button>

      {showAlt && (
        <div className="mt-3 flex flex-col gap-2">
          {alternatives.map((a) => (
            <div
              key={a.id}
              className="flex items-center gap-2.5 rounded-[var(--radius-card)] border border-dashed border-[var(--color-border-default)] bg-[var(--color-surface-content)] p-3"
              data-testid="conditional-tracker-alternative"
            >
              <GitBranch size={14} className="shrink-0 text-[var(--color-text-muted)]" aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium text-[var(--color-text-primary)]">{a.label}</div>
                <div className="text-xs text-[var(--color-text-muted)]">{a.description}</div>
              </div>
              <Badge tone="gray" size="sm">Not taken</Badge>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
