import * as React from "react"
import { Switch } from "./switch.js"
import { RadioGroup } from "./radio-group.js"
import { cn } from "../lib/cn.js"

/**
 * Alert notify-on-new-matches toggle + frequency picker — port of
 * search-system/search-saved.jsx's `AlertConfig`. Fully controlled, no
 * fetch — reused by `SaveSearchModal` (inline, at save time) and by the
 * `saved-search` organism (per saved search, after the fact).
 */

export type AlertFrequency = "realtime" | "daily" | "weekly"

const FREQUENCY_OPTIONS: { value: AlertFrequency; label: string; description: string }[] = [
  { value: "realtime", label: "Real-time", description: "Notify immediately when a new record matches." },
  { value: "daily", label: "Daily digest", description: "Bundle new matches into one email each morning." },
  { value: "weekly", label: "Weekly digest", description: "Bundle new matches into one email each week." },
]

export interface AlertConfigProps {
  enabled: boolean
  frequency: AlertFrequency
  onEnabledChange: (enabled: boolean) => void
  onFrequencyChange: (frequency: AlertFrequency) => void
  label?: string
  description?: string
  className?: string
}

export function AlertConfig({
  enabled,
  frequency,
  onEnabledChange,
  onFrequencyChange,
  label = "Notify me on new matches",
  description,
  className,
}: AlertConfigProps) {
  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <div className="flex items-center gap-2.5">
        <Switch checked={enabled} onCheckedChange={onEnabledChange} aria-label={label} />
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium text-[var(--color-text-primary)]">{label}</div>
          {description && <div className="text-xs text-[var(--color-text-muted)]">{description}</div>}
        </div>
      </div>
      {enabled && (
        <RadioGroup
          name="alert-frequency"
          value={frequency}
          onValueChange={(v) => onFrequencyChange(v as AlertFrequency)}
          options={FREQUENCY_OPTIONS}
        />
      )}
    </div>
  )
}
