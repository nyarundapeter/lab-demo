import * as React from "react"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"
import { cn } from "../lib/cn.js"

export type DeltaPolarity = "up-good" | "down-good"

export interface DeltaProps extends React.HTMLAttributes<HTMLSpanElement> {
  value: number
  /** Appended after the number. Default "%". Pass "" to suppress. */
  suffix?: string
  /** Which direction counts as "good" for colouring. Default "up-good". */
  polarity?: DeltaPolarity
  showIcon?: boolean
}

/**
 * Polarity-aware delta indicator — colours and arrows the value based on
 * whether "up" or "down" is the desired direction for this metric
 * (dash-components.jsx:21-32). Reusable in place of ad hoc per-consumer
 * delta markup (KPI tiles, Ranking rows, etc).
 */
export function Delta({ value, suffix = "%", polarity = "up-good", showIcon = true, className, ...props }: DeltaProps) {
  const dir = value > 0 ? "up" : value < 0 ? "down" : "flat"
  const isGood = dir === "flat" ? null : polarity === "up-good" ? dir === "up" : dir === "down"
  const Icon = dir === "up" ? TrendingUp : dir === "down" ? TrendingDown : Minus

  const colorClass =
    isGood === null
      ? "text-[var(--color-text-muted)]"
      : isGood
        ? "text-[var(--color-success)]"
        : "text-[var(--color-danger)]"

  return (
    <span
      className={cn("inline-flex items-center gap-0.5 text-xs font-semibold tabular-nums", colorClass, className)}
      data-direction={dir}
      data-good={isGood === null ? undefined : String(isGood)}
      {...props}
    >
      {showIcon && <Icon size={13} strokeWidth={2} aria-hidden="true" />}
      {value > 0 ? "+" : ""}
      {value}
      {suffix}
    </span>
  )
}
