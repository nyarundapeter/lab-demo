import * as React from "react"
import { cn } from "../lib/cn.js"
import { AiMark } from "./ai-mark.js"

export interface AssistantFabProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  /** Destination for the assistant surface. Defaults to "/copilot". */
  href?: string
  label?: string
}

/**
 * Floating "Ask AI" launcher, present on every data dashboard
 * (dash-ai.jsx:245-249). Routes to the existing Copilot surface rather
 * than opening a separate dockable panel — one conversation engine, reused.
 * Renders as a plain anchor so host apps can swap in their router's Link.
 */
export function AssistantFab({ href = "/copilot", label = "Ask AI", className, ...props }: AssistantFabProps) {
  return (
    <a
      href={href}
      className={cn(
        "fixed bottom-4 right-4 z-[1300] inline-flex h-11 items-center gap-2 rounded-pill",
        "bg-primary px-4 text-sm font-semibold text-white shadow-lg",
        "transition-transform hover:scale-[1.03]",
        "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
        className,
      )}
      {...props}
    >
      <AiMark size={16} className="text-white" />
      {label}
    </a>
  )
}
