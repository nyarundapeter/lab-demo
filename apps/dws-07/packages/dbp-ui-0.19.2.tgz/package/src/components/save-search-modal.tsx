import * as React from "react"
import { Star } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogBody,
  DialogFooter,
} from "./dialog.js"
import { Button } from "./button.js"
import { Input, FieldLabel } from "./input.js"
import { Checkbox } from "./checkbox.js"
import { AlertConfig, type AlertFrequency } from "./alert-config.js"
import { Badge } from "./badge.js"

/**
 * Save-search dialog — port of search-system/search-saved.jsx's
 * `SaveSearchModal`. Captures a name for the current query + active filter
 * chips, an optional pin-to-sidebar flag, and (composing `AlertConfig`
 * rather than re-implementing it) an optional new-matches alert.
 */

export interface SaveSearchQueryChip {
  label: string
  kind?: "scope" | "filter"
}

export interface SaveSearchInput {
  name: string
  pinToSidebar: boolean
  alertOn: boolean
  alertFrequency: AlertFrequency
}

export interface SaveSearchModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Query + active filter chips shown read-only as "what will be saved". */
  queryChips: SaveSearchQueryChip[]
  defaultName?: string
  onSave: (input: SaveSearchInput) => void
}

export function SaveSearchModal({ open, onOpenChange, queryChips, defaultName = "", onSave }: SaveSearchModalProps) {
  const [name, setName] = React.useState(defaultName)
  const [pinToSidebar, setPinToSidebar] = React.useState(true)
  const [alertOn, setAlertOn] = React.useState(true)
  const [alertFrequency, setAlertFrequency] = React.useState<AlertFrequency>("realtime")

  React.useEffect(() => {
    if (open) setName(defaultName)
  }, [open, defaultName])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Star size={15} aria-hidden="true" />
            Save this search
          </DialogTitle>
        </DialogHeader>
        <DialogBody className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <FieldLabel htmlFor="save-search-name">Name</FieldLabel>
            <Input id="save-search-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name this search" autoFocus />
          </div>

          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-medium text-[var(--color-text-primary)]">Captured query &amp; filters</span>
            <div className="flex flex-wrap gap-1.5 rounded-input border border-[var(--color-border-default)] bg-[var(--color-surface)] p-2.5">
              {queryChips.map((chip, i) => (
                <Badge key={i} tone={chip.kind === "filter" ? "info" : "gray"} size="sm">
                  {chip.label}
                </Badge>
              ))}
            </div>
          </div>

          <label className="flex cursor-pointer items-center gap-2.5">
            <Checkbox checked={pinToSidebar} onCheckedChange={(v) => setPinToSidebar(v === true)} />
            <span className="text-sm">
              Pin to sidebar under <span className="font-semibold">Views</span>
            </span>
          </label>

          <div className="border-t border-[var(--color-border-default)] pt-3.5">
            <AlertConfig
              enabled={alertOn}
              frequency={alertFrequency}
              onEnabledChange={setAlertOn}
              onFrequencyChange={setAlertFrequency}
              description="Get alerted when a record starts matching this search."
            />
          </div>
        </DialogBody>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            type="button"
            disabled={!name.trim()}
            onClick={() => onSave({ name: name.trim(), pinToSidebar, alertOn, alertFrequency })}
          >
            <Star size={13} aria-hidden="true" />
            Save search
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
