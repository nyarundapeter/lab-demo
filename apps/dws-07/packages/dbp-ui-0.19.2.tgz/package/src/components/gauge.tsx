import * as React from "react"
import { cn } from "../lib/cn.js"

export interface GaugeThreshold {
  /** Values <= this bound render in `color`. Bounds are checked in order. */
  upTo: number
  /** Any CSS color, including `var(--token)`. */
  color: string
}

export interface GaugeProps {
  value: number
  /** Scale maximum. Default 100. */
  max?: number
  /**
   * Threshold bands driving the arc color, e.g.
   * `[{ upTo: 60, color: "var(--color-danger)" }, { upTo: 85, color: "var(--color-warning)" }, { upTo: 100, color: "var(--color-success)" }]`.
   * Required and must be non-empty — a gauge with no thresholds can't
   * communicate status at a glance.
   */
  thresholds: GaugeThreshold[]
  label?: string
  /** Unit suffix appended to the value. Default "%". */
  unit?: string
  className?: string
}

/**
 * Semicircular gauge with threshold-driven color, for "system health" style
 * single-value indicators (e.g. licence usage, uptime). Hand-rolled SVG per
 * the dashboard-system chart-library ruling (2026-07-16) — recharts has no
 * native gauge primitive.
 */
export function Gauge({ value, max = 100, thresholds, label, unit = "%", className }: GaugeProps) {
  const pct = Math.min(1, Math.max(0, value / max))
  const r = 52
  const cx = 70
  const cy = 66
  const circumference = Math.PI * r
  const arc = `M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`
  const color = (thresholds.find((t) => value <= t.upTo) ?? thresholds[thresholds.length - 1])?.color
    ?? "var(--color-primary)"

  return (
    <div className={cn("flex flex-col items-center", className)}>
      <svg
        viewBox="0 0 140 78"
        width="140"
        height="78"
        role="img"
        aria-label={`${label ? `${label}: ` : ""}${value}${unit}`}
      >
        <path d={arc} fill="none" stroke="var(--color-border-subtle)" strokeWidth="11" strokeLinecap="round" />
        <path
          d={arc}
          fill="none"
          stroke={color}
          strokeWidth="11"
          strokeLinecap="round"
          strokeDasharray={`${pct * circumference} ${circumference}`}
        />
        <text
          x={cx}
          y={cy - 8}
          textAnchor="middle"
          fontSize="22"
          fontWeight="600"
          fill="var(--color-text)"
          className="tabular-nums"
        >
          {value}
          {unit}
        </text>
      </svg>
      {label && <div className="-mt-1 text-xs text-[var(--color-text-muted)]">{label}</div>}
    </div>
  )
}
