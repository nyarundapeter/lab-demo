import * as React from "react"
import { badgeShellClass } from "./badge.js"
import { cn } from "../lib/cn.js"

export interface CiteRefProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "onClick"> {
  /** Citation number, as printed inline in AI-generated text (e.g. "…grew 12%[1]"). */
  n: number
  onOpen?: (n: number) => void
}

/**
 * Inline numbered citation marker — opens the referenced source on click.
 * Shares Badge's shell mechanics (`badgeShellClass`) and Badge's `ai` tone
 * colours (the same `--ai-soft`/`--ai-strong`/`--ai-border` triad), but
 * can't compose `<Badge>` directly: CiteRef must itself be the interactive/
 * focusable element (a `<button>`), where Badge renders a `<span>`, and its
 * radius/size are smaller than Badge's own scale — hence building on the
 * shape-agnostic shell rather than `badgeVariants()`.
 */
function CiteRef({ className, n, onOpen, ...props }: CiteRefProps) {
  return (
    <button
      type="button"
      onClick={() => onOpen?.(n)}
      aria-label={`Source ${n}`}
      className={cn(
        badgeShellClass,
        // keep: 15px circular hit-target math (h/min-w/px/text all sized off
        // the 15px badge, below the named scale floor) — snapping text-[10px]
        // to text-xs (12px) would overflow the 15px circle.
        "h-[15px] min-w-[15px] justify-center rounded-[3px] px-[3px] py-0 text-[10px] font-bold leading-none align-super",
        "text-[hsl(var(--ai-strong))] bg-[hsl(var(--ai-soft))] border-[hsl(var(--ai-border))]",
        "hover:bg-[hsl(var(--ai-soft-2))]",
        className,
      )}
      {...props}
    >
      {n}
    </button>
  )
}

export { CiteRef }
