import * as React from "react"
import { GitBranch } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Avatar } from "./avatar.js"
import { Badge, type BadgeProps } from "./badge.js"
import { Progress } from "./progress.js"

/**
 * ParallelTracker — Wave 3 Family 3 molecule (no registry id, flat @dbp/ui component). Reference:
 * docs/03-features/specs/claude-design-briefs/design-run-pack-2026-07-12/
 * _outputs/workflow-system/wf-trackers.jsx `ParallelTracker` — a grid of
 * independently-progressing branches sharing one merge rule, each carrying
 * an owner, a progress bar and a due date. Genuinely new: no existing
 * tracker renders concurrent branches (VerticalStageTracker/LifecycleBar
 * are both single-sequence renderers).
 */
export type ParallelBranchStatus = "done" | "active" | "blocked"

export interface ParallelBranch {
  id: string
  label: string
  status: ParallelBranchStatus
  /** 0–100 */
  percent: number
  ownerLabel: string
  dueLabel: string
  note?: string | undefined
}

export interface ParallelTrackerProps {
  branches: ParallelBranch[]
  /** e.g. "2 of 3 branches must complete before merge". */
  rule?: string | undefined
  className?: string
}

const STATUS_TONE: Record<ParallelBranchStatus, NonNullable<BadgeProps["tone"]>> = {
  done: "success",
  active: "active",
  blocked: "warning",
}

const STATUS_LABEL: Record<ParallelBranchStatus, string> = {
  done: "Completed",
  active: "In progress",
  blocked: "Blocked",
}

const PROGRESS_TONE: Record<ParallelBranchStatus, "success" | "primary" | "warning"> = {
  done: "success",
  active: "primary",
  blocked: "warning",
}

export function ParallelTracker({ branches, rule, className }: ParallelTrackerProps) {
  const doneCount = branches.filter((b) => b.status === "done").length

  return (
    <div className={cn("flex flex-col gap-3.5", className)}>
      <div className="flex flex-wrap items-center gap-2.5">
        <Badge tone="info" size="sm">
          <GitBranch size={11} aria-hidden="true" />
          {branches.length} parallel branches
        </Badge>
        {rule && <span className="text-xs text-[var(--color-text-muted)]">{rule}</span>}
        <span className="ml-auto text-xs text-[var(--color-text-muted)]">
          {doneCount}/{branches.length} complete
        </span>
      </div>

      <div className="grid grid-cols-[repeat(auto-fill,minmax(240px,1fr))] gap-3">
        {branches.map((b) => (
          <div
            key={b.id}
            className={cn(
              "rounded-[var(--radius-card)] border bg-[var(--color-surface-content)] p-3",
              b.status === "blocked" ? "border-[var(--color-warning)]/40" : "border-[var(--color-border-default)]",
            )}
            data-testid="parallel-branch"
            data-status={b.status}
          >
            <div className="mb-2 flex items-center justify-between gap-2">
              <span className="text-sm font-semibold text-[var(--color-text-primary)]">{b.label}</span>
              <Badge tone={STATUS_TONE[b.status]} size="sm">
                {STATUS_LABEL[b.status]}
              </Badge>
            </div>
            <Progress value={b.percent} tone={PROGRESS_TONE[b.status]} size="sm" className="mb-2" />
            <div className="flex items-center justify-between gap-2">
              <span className="inline-flex items-center gap-1.5">
                <Avatar name={b.ownerLabel} size="sm" />
                <span className="text-xs">{b.ownerLabel.split(" ")[0]}</span>
              </span>
              <span className="text-xs text-[var(--color-text-muted)]">Due {b.dueLabel}</span>
            </div>
            {b.note && <p className="mt-2 text-xs text-[var(--color-warning)]">{b.note}</p>}
          </div>
        ))}
      </div>
    </div>
  )
}
