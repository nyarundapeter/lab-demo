import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn.js"

const sectionLabelVariants = cva("uppercase tracking-wide font-semibold", {
  variants: {
    size: {
      xs: "text-xs",
      /**
       * No named type-scale token smaller than `--text-xs` (12px,
       * `packages/shared/design-tokens/base.css`) exists yet. Rather than
       * reach for one of the arbitrary `text-[10px]`/`text-[10.5px]`/
       * `text-[11px]` values the de-dup inventory found scattered across
       * ~30 hand-rolled eyebrow recipes — which the component-architecture
       * standard (§1a) forbids for new components — `2xs` resolves
       * identically to `xs` until a smaller step is added to the scale.
       */
      "2xs": "text-xs",
    },
    tone: {
      muted: "text-[var(--color-text-muted)]",
      primary: "text-[var(--color-text-primary)]",
      secondary: "text-[var(--color-text-secondary)]",
    },
  },
  defaultVariants: {
    size: "xs",
    tone: "muted",
  },
})

export interface SectionLabelProps
  extends React.HTMLAttributes<HTMLElement>,
    VariantProps<typeof sectionLabelVariants> {
  /** Element to render as. Defaults to `span`. */
  as?: React.ElementType
}

/**
 * SectionLabel — THE eyebrow/section-label primitive (design-system de-dup
 * strategy, `docs/plans/design-system-dedup-2026-07-25/strategy.md` §3,
 * ruling DS-R2). Consolidates the "uppercase tracking-wide" eyebrow-recipe
 * family — ~108 hand-rolled sites across ~53 files (inventory-b §1),
 * ~22 of them inside `@dbp/ui` itself — onto the dominant observed variant
 * (`text-xs font-semibold uppercase tracking-wide` + a muted text-role
 * token). Not for form `<label>` elements — see `FieldLabel` for that.
 */
const SectionLabel = React.forwardRef<HTMLElement, SectionLabelProps>(
  ({ className, size, tone, as: Comp = "span", ...props }, ref) => {
    return (
      <Comp
        ref={ref}
        className={cn(sectionLabelVariants({ size, tone }), className)}
        {...props}
      />
    )
  }
)
SectionLabel.displayName = "SectionLabel"

export { SectionLabel, sectionLabelVariants }
