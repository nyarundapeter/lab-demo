import * as React from "react"
import { cn } from "../lib/cn"

/* ─── Card ──────────────────────────────────────────────────────────────── */

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /**
   * Semantic density marker. No visual delta today — `compact` adds no
   * padding/gap classes (Card itself sets no padding; that lives in
   * CardHeader/Content/Footer). Exposed as `data-density` for downstream
   * consumers (e.g. AiSurface) without altering existing consumers' output.
   *
   * For dashboard tiles/sections specifically, use the real
   * `executive`/`standard`/`operational` density system instead
   * (`DashboardDensityProvider` + `useDashboardDensity()` in
   * `dashboard-density.tsx`, consumed by `StatTile`/`DashSection`) — this
   * `compact` marker is a separate, still-decorative mechanism scoped to
   * `Card` itself and is not wired to it.
   */
  density?: "default" | "compact"
}

const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ className, density = "default", ...props }, ref) => (
    <div
      ref={ref}
      data-density={density}
      className={cn(
        "rounded-card border border-border-default bg-surface-content shadow-sm",
        className
      )}
      {...props}
    />
  )
)
Card.displayName = "Card"

/* ─── CardHeader ────────────────────────────────────────────────────────── */

const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        "flex flex-col gap-1.5 px-6 pt-6 pb-4",
        "border-b border-[var(--color-border-subtle)]",
        className
      )}
      {...props}
    />
  )
)
CardHeader.displayName = "CardHeader"

/* ─── CardTitle ─────────────────────────────────────────────────────────── */

const CardTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3
      ref={ref}
      className={cn("text-base font-semibold leading-snug text-[var(--color-text-primary)]", className)}
      {...props}
    />
  )
)
CardTitle.displayName = "CardTitle"

/* ─── CardDescription ───────────────────────────────────────────────────── */

const CardDescription = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, ...props }, ref) => (
    <p
      ref={ref}
      className={cn("text-sm text-[var(--color-text-muted)]", className)}
      {...props}
    />
  )
)
CardDescription.displayName = "CardDescription"

/* ─── CardContent ───────────────────────────────────────────────────────── */

const CardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("px-6 py-5", className)}
      {...props}
    />
  )
)
CardContent.displayName = "CardContent"

/* ─── CardFooter ────────────────────────────────────────────────────────── */

const CardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        "flex items-center gap-2 px-6 py-4",
        "border-t border-[var(--color-border-subtle)]",
        className
      )}
      {...props}
    />
  )
)
CardFooter.displayName = "CardFooter"

/* ─── CardClickable (backward-compat) ───────────────────────────────────── */

const CardClickable = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <Card
      ref={ref}
      className={cn(
        "cursor-pointer motion-safe:transition-all",
        "hover:-translate-y-0.5 hover:shadow-lg",
        className
      )}
      {...props}
    />
  )
)
CardClickable.displayName = "CardClickable"

export { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter, CardClickable }
