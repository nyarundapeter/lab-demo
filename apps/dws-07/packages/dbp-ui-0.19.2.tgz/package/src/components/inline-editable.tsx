import * as React from "react"
import { Pencil } from "lucide-react"
import { cn } from "../lib/cn.js"
import { FieldLabel, Input } from "./input.js"

export interface InlineEditableProps {
  label?: string
  value: string
  onSave: (value: string) => void
  placeholder?: string
  helper?: string
  disabled?: boolean
  multiline?: boolean
  className?: string
}

/**
 * InlineEditable — click-to-edit text row: read-mode shows the value with a
 * hover Edit affordance; click/Enter/Space switches to an input, Enter
 * commits (Cmd/Ctrl+Enter for `multiline`), Escape cancels, blur commits
 * (forms-fields.jsx:355-374 `InlineEditable`). Extracted as a standalone
 * `@dbp/ui` molecule from the record-form-local pattern duplicated per-value-
 * type in `lve-workspace`'s `components/list-detail/EditableField.tsx`
 * (`EditableText`) — that file's DIVERGED lve-specific tokens
 * (`var(--bone)`, `var(--ink)`, `var(--hair)`) stay local to LVE; this
 * version renders on standard `--color-*` tokens for any other consumer.
 */
function InlineEditable({
  label,
  value,
  onSave,
  placeholder = "Not set",
  helper,
  disabled = false,
  multiline = false,
  className,
}: InlineEditableProps) {
  const [editing, setEditing] = React.useState(false)
  const [draft, setDraft] = React.useState(value)
  const inputRef = React.useRef<HTMLInputElement>(null)
  const textareaRef = React.useRef<HTMLTextAreaElement>(null)
  const id = React.useId()

  React.useEffect(() => setDraft(value), [value])
  React.useEffect(() => {
    if (!editing) return
    const el = multiline ? textareaRef.current : inputRef.current
    el?.focus()
    el?.select()
  }, [editing, multiline])

  function commit() {
    if (draft !== value) onSave(draft)
    setEditing(false)
  }

  function cancel() {
    setDraft(value)
    setEditing(false)
  }

  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label && <FieldLabel htmlFor={id}>{label}</FieldLabel>}

      {editing ? (
        multiline ? (
          <textarea
            ref={textareaRef}
            id={id}
            value={draft}
            rows={3}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                e.preventDefault()
                commit()
              }
              if (e.key === "Escape") cancel()
            }}
            className="flex w-full rounded-input border border-border-default bg-[var(--color-surface-content)] px-3 py-2 text-sm text-[var(--color-text-primary)] focus-visible:border-primary focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
          />
        ) : (
          <Input
            ref={inputRef}
            id={id}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault()
                commit()
              }
              if (e.key === "Escape") cancel()
            }}
          />
        )
      ) : (
        <div
          data-testid="inline-editable-display"
          role="button"
          tabIndex={disabled ? -1 : 0}
          aria-disabled={disabled}
          onClick={() => !disabled && setEditing(true)}
          onKeyDown={(e) => {
            if (disabled) return
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault()
              setEditing(true)
            }
          }}
          className={cn(
            "group flex min-h-9 items-center justify-between gap-2 rounded-input px-1 py-1 text-sm",
            !disabled && "cursor-text hover:bg-[var(--color-surface)]",
            "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
          )}
        >
          <span
            className={cn(
              value ? "text-[var(--color-text-primary)]" : "italic text-[var(--color-text-muted)]",
              multiline && "whitespace-pre-wrap",
            )}
          >
            {value || placeholder}
          </span>
          {!disabled && (
            <Pencil
              size={12}
              strokeWidth={2}
              aria-hidden="true"
              className="shrink-0 text-[var(--color-text-muted)] opacity-0 transition-opacity group-hover:opacity-100"
            />
          )}
        </div>
      )}

      {helper && !editing && <p className="text-xs text-[var(--color-text-muted)]">{helper}</p>}
    </div>
  )
}

export { InlineEditable }
