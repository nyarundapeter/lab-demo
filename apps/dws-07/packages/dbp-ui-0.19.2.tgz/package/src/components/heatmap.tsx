import * as React from "react"
import { cn } from "../lib/cn.js"

export interface HeatmapCellColor {
  bg: string
  fg: string
}

export interface HeatmapProps {
  /** Row labels, top to bottom. */
  rows: string[]
  /** Column labels, left to right. */
  cols: string[]
  /** Cell values — `data[rowIndex][colIndex]`. Must match `rows.length` x `cols.length`. */
  data: number[][]
  /** Maps a cell value to background/foreground colour. */
  colorFor: (value: number) => HeatmapCellColor
  /** Formats the text shown inside a cell. Defaults to the raw value. */
  cellText?: (value: number) => React.ReactNode
  /** Accessible label for the table (e.g. "Risk heatmap — likelihood by impact"). */
  ariaLabel?: string
  className?: string
}

/**
 * Grid heatmap for likelihood×impact risk matrices and cohort-retention
 * tables. Hand-rolled table per the dashboard-system chart-library ruling
 * (2026-07-16) — recharts has no native heatmap primitive. Cell colour is
 * never the only signal: the numeric value is always rendered as text.
 */
export function Heatmap({ rows, cols, data, colorFor, cellText, ariaLabel, className }: HeatmapProps) {
  return (
    <div className={cn("overflow-x-auto", className)} data-testid="heatmap">
      <table
        role="img"
        aria-label={ariaLabel ?? "Heatmap"}
        className="w-full border-separate"
        style={{ borderSpacing: 3 }}
      >
        <thead>
          <tr>
            <th />
            {cols.map((c) => (
              <th
                key={c}
                className="px-0.5 pb-1 text-center text-xs font-medium text-[var(--color-text-muted)]"
              >
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, ri) => (
            <tr key={r}>
              <td className="whitespace-nowrap pr-2 text-right text-xs text-[var(--color-text)]">
                {r}
              </td>
              {cols.map((c, ci) => {
                const value = data[ri]?.[ci] ?? 0
                const { bg, fg } = colorFor(value)
                return (
                  <td
                    key={c}
                    data-testid={`heatmap-cell-${ri}-${ci}`}
                    title={`${r} · ${c}: ${cellText ? cellText(value) : value}`}
                    className="h-[30px] min-w-[40px] rounded text-center text-xs font-semibold"
                    style={{ background: bg, color: fg }}
                  >
                    {cellText ? cellText(value) : value}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
