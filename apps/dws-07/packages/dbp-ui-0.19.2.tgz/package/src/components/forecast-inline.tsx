import * as React from "react"
import { TrendingUp } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface ForecastInlineProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  /** The forecast statement, e.g. "Backlog reaches ~290 in 2 weeks without added capacity." */
  text: React.ReactNode
  /** Leading eyebrow label. Defaults to "Forecast". */
  label?: string
}

/**
 * Static single-purpose forecast strip — one icon + label + statement, no
 * composition or state (dashboard-system/dash-views-2.jsx:197-202). Ref
 * `--brand` aliases to `--color-secondary` per the token-alias table (§A3).
 */
function ForecastInline({ text, label = "Forecast", className, ...props }: ForecastInlineProps) {
  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-[7px] border border-[color-mix(in_srgb,var(--color-secondary)_20%,transparent)] bg-[color-mix(in_srgb,var(--color-secondary)_5%,transparent)] px-2.5 py-2 text-xs",
        className,
      )}
      {...props}
    >
      <span className="inline-flex items-center gap-1 font-semibold text-secondary">
        <TrendingUp size={9} aria-hidden="true" />
        {label}
      </span>
      <span>{text}</span>
    </div>
  )
}

export { ForecastInline }
