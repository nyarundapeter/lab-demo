import * as React from "react"
import { FileText, Zap, Bot, Pencil, AlertTriangle, Circle, CircleCheck, CircleX, Clock, AlertCircle, type LucideIcon } from "lucide-react"
import { Badge, type BadgeProps } from "./badge.js"
import { Button } from "./button.js"
import { cn } from "../lib/cn.js"

export type ActivityStripEventKind = "summary" | "auto" | "reco" | "draft" | "anomaly" | "error"

const KIND_ICON: Record<ActivityStripEventKind, LucideIcon> = {
  summary: FileText,
  auto: Zap,
  reco: Bot,
  draft: Pencil,
  anomaly: AlertTriangle,
  error: AlertTriangle,
}

export type ActivityStripEventStatus =
  | "accepted"
  | "rejected"
  | "pending"
  | "automated"
  | "edited"
  | "confirmed"
  | "error"

interface StatusToken {
  label: string
  tone: NonNullable<BadgeProps["tone"]>
  icon: LucideIcon
}

/**
 * AI activity/audit status vocabulary (ai-example-dashboard/ai/activity.jsx:7-15),
 * now expressed as Badge tones (D19 — the former standalone status-chip
 * component was consolidated into Badge).
 */
const STATUS: Record<ActivityStripEventStatus, StatusToken> = {
  accepted: { label: "Accepted", tone: "success", icon: CircleCheck },
  confirmed: { label: "Confirmed", tone: "success", icon: CircleCheck },
  rejected: { label: "Rejected", tone: "gray", icon: CircleX },
  pending: { label: "Pending review", tone: "warning", icon: Clock },
  error: { label: "Failed", tone: "danger", icon: AlertCircle },
  automated: { label: "Automated", tone: "ai", icon: Zap },
  edited: { label: "Edited & accepted", tone: "ai", icon: Pencil },
}

export interface ActivityStripEvent {
  id: string
  label: React.ReactNode
  kind: ActivityStripEventKind
  status: ActivityStripEventStatus
}

export interface ActivityStripProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  events: ActivityStripEvent[]
  /** Max rows shown before truncating. Defaults to 3. */
  limit?: number
  onViewAll?: () => void
}

/**
 * Compact recent-AI-activity strip for record side panels
 * (ai-example-dashboard/ai/activity.jsx:100-111) — receives `events` via
 * props, renders no fetch. Distinct from `activity-composer.tsx`/
 * `activity-timeline.tsx` (a different, full-timeline pattern).
 */
function ActivityStrip({ events, limit = 3, onViewAll, className, ...props }: ActivityStripProps) {
  return (
    <div className={cn("flex flex-col gap-0.5", className)} {...props}>
      {events.slice(0, limit).map((ev) => {
        const Icon = KIND_ICON[ev.kind] ?? Circle
        const token = STATUS[ev.status] ?? STATUS.pending
        const StatusIcon = token.icon
        return (
          <div key={ev.id} className="flex items-center gap-2 py-1.5 text-xs">
            <Icon size={12} className="text-[hsl(var(--ai))]" aria-hidden="true" />
            <span className="min-w-0 flex-1 truncate">{ev.label}</span>
            <Badge tone={token.tone} size="sm">
              <StatusIcon size={11} strokeWidth={2} aria-hidden="true" />
              {token.label}
            </Badge>
          </div>
        )
      })}
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="mt-1 h-auto self-start p-0 text-[hsl(var(--ai-strong))]"
        onClick={onViewAll}
      >
        View full AI activity
      </Button>
    </div>
  )
}

export { ActivityStrip }
