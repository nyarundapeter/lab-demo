"use client"
import * as React from "react"
import { Check, ChevronDown, Search } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Popover, PopoverTrigger, PopoverContent } from "./popover.js"
import type { FieldState } from "./input.js"

/* Mirrors input.tsx's fieldStateBorderClasses for the trigger button. */
const triggerStateClasses: Record<Exclude<FieldState, "default">, string> = {
  error: "border-danger focus-visible:[box-shadow:var(--focus-ring-error)]",
  warning: "border-warning focus-visible:[box-shadow:var(--focus-ring-warning)]",
  success: "border-success focus-visible:[box-shadow:var(--focus-ring-success)]",
}

export interface SearchSelectOption {
  value: string
  label: string
  description?: string | undefined
  /** Rendered before the label — e.g. an @dbp/ui Avatar for a user-picker option row. */
  icon?: React.ReactNode
}

export interface SearchSelectProps {
  id?: string
  value?: string | undefined
  onValueChange?: ((value: string) => void) | undefined
  options: SearchSelectOption[]
  placeholder?: string | undefined
  searchPlaceholder?: string | undefined
  emptyText?: string | undefined
  disabled?: boolean | undefined
  state?: FieldState | undefined
  "aria-invalid"?: boolean | undefined
}

/**
 * SearchSelect — options-driven searchable select (multi-step-form spec §3:
 * "GAP — PROMOTE to @dbp/ui, now REQUIRED"). Doubles as a user-picker per the
 * spec's "a user is an option list, not a new field kind" ruling — pass
 * `icon` (an `@dbp/ui Avatar`) per option for the user-picker look.
 * Hand-rolled combobox (filter input + listbox) on top of Popover, matching
 * Select/RadioGroup's no-extra-Radix-dependency posture.
 */
const SearchSelect = React.forwardRef<HTMLButtonElement, SearchSelectProps>(
  (
    {
      id,
      value,
      onValueChange,
      options,
      placeholder = "Select…",
      searchPlaceholder = "Search…",
      emptyText = "No results.",
      disabled,
      state = "default",
      "aria-invalid": ariaInvalid,
    },
    ref,
  ) => {
    const [open, setOpen] = React.useState(false)
    const [query, setQuery] = React.useState("")
    const selected = options.find((o) => o.value === value)
    const filtered = React.useMemo(() => {
      const q = query.trim().toLowerCase()
      if (!q) return options
      return options.filter((o) => o.label.toLowerCase().includes(q))
    }, [options, query])

    return (
      <Popover
        open={open}
        onOpenChange={(next) => {
          setOpen(next)
          if (!next) setQuery("")
        }}
      >
        <PopoverTrigger asChild>
          <button
            ref={ref}
            id={id}
            type="button"
            disabled={disabled}
            aria-invalid={ariaInvalid ?? (state === "error" ? "true" : undefined)}
            className={cn(
              "flex h-9 w-full items-center justify-between gap-2 rounded-[var(--radius-input)]",
              "border-[1.5px] border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-3 text-sm",
              "text-[var(--color-text-primary)] transition-colors",
              "hover:border-[var(--color-border-strong)]",
              "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
              "disabled:cursor-not-allowed disabled:opacity-50",
              !selected && "text-[var(--color-text-muted)]",
              state !== "default" && triggerStateClasses[state],
            )}
          >
            <span className="flex min-w-0 items-center gap-2 truncate">
              {selected?.icon}
              <span className="truncate">{selected ? selected.label : placeholder}</span>
            </span>
            <ChevronDown size={14} className="shrink-0 opacity-60" aria-hidden="true" />
          </button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-[--radix-popover-trigger-width] p-0">
          <div className="flex items-center gap-2 border-b border-[var(--color-border-default)] px-3 py-2">
            <Search size={14} className="shrink-0 opacity-60" aria-hidden="true" />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={searchPlaceholder}
              className="w-full bg-transparent text-sm outline-none placeholder:text-[var(--color-text-muted)]"
            />
          </div>
          <ul role="listbox" className="max-h-64 overflow-auto p-1">
            {filtered.length === 0 && (
              <li className="px-3 py-2 text-xs text-[var(--color-text-muted)]">{emptyText}</li>
            )}
            {filtered.map((opt) => {
              const isSelected = opt.value === value
              return (
                <li key={opt.value}>
                  <button
                    type="button"
                    role="option"
                    aria-selected={isSelected}
                    onClick={() => {
                      onValueChange?.(opt.value)
                      setOpen(false)
                      setQuery("")
                    }}
                    className={cn(
                      "flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm",
                      "hover:bg-[var(--color-navy-50)]",
                      isSelected && "bg-[var(--color-navy-50)]",
                    )}
                  >
                    {opt.icon}
                    <span className="flex min-w-0 flex-col">
                      <span className="truncate text-[var(--color-text-primary)]">{opt.label}</span>
                      {opt.description && (
                        <span className="truncate text-xs text-[var(--color-text-muted)]">{opt.description}</span>
                      )}
                    </span>
                    {isSelected && <Check size={14} className="ml-auto shrink-0 text-[var(--color-text-primary)]" aria-hidden="true" />}
                  </button>
                </li>
              )
            })}
          </ul>
        </PopoverContent>
      </Popover>
    )
  },
)
SearchSelect.displayName = "SearchSelect"

export { SearchSelect }
