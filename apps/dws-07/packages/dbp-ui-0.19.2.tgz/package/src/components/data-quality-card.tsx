import * as React from "react"
import { AlertTriangle, CircleCheck, Database, Undo2 } from "lucide-react"
import { AiLabel } from "./ai-label.js"
import { AiActionCard } from "./ai-action-card.js"
import { Badge, type BadgeProps } from "./badge.js"
import { Button } from "./button.js"
import { cn } from "../lib/cn.js"

export type DataQualitySeverity = "low" | "medium" | "high"

const SEVERITY: Record<DataQualitySeverity, { label: string; tone: BadgeProps["tone"]; text: string }> = {
  low: { label: "Low risk", tone: "success", text: "text-[var(--color-success-text)]" },
  medium: { label: "Medium risk", tone: "warning", text: "text-[var(--color-warning-text)]" },
  high: { label: "High risk", tone: "danger", text: "text-[var(--color-danger-text)]" },
}

export interface DataQualityCardItem {
  issue: React.ReactNode
  severity: DataQualitySeverity
  records: React.ReactNode
  impact: React.ReactNode
  fix: React.ReactNode
  owner: React.ReactNode
}

export interface DataQualityCardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  item: DataQualityCardItem
  onAssignOwner?: () => void
  onDismiss?: () => void
}

/**
 * Data-quality warning card — `state` (idle/done) is a local apply/undo
 * toggle on the injected `item` prop, no fetch (ai-example-dashboard/
 * ai/cards.jsx:395-429). Shares the `gov`-block visual family with `GovState`.
 * Composes the shared `AiActionCard` shell (see that file for the
 * `SuggestedAction` sibling using the same pattern).
 */
function DataQualityCard({ item, onAssignOwner, onDismiss, className, ...props }: DataQualityCardProps) {
  const [state, setState] = React.useState<"idle" | "done">("idle")
  const sev = SEVERITY[item.severity] ?? SEVERITY.medium

  return (
    <AiActionCard
      role="status"
      className={cn(
        "rounded-[var(--radius-card,8px)] border border-[hsl(var(--ai-border))] bg-[var(--color-surface-content)] p-3",
        className,
      )}
      icon={
        <span className={cn("mt-0.5 shrink-0", sev.text)}>
          <Database size={16} aria-hidden="true" />
        </span>
      }
      label={<AiLabel kind="generated" text="Data-quality issue" />}
      badge={<Badge tone={sev.tone}>{sev.label}</Badge>}
      title={item.issue}
      fields={[
        { label: "Records affected", value: item.records },
        { label: "Impact on insights", value: item.impact },
        { label: "Suggested correction", value: item.fix },
        { label: "Ownership", value: item.owner },
      ]}
      note={
        <div className="mb-2.5 flex items-center gap-1.5 text-xs text-[var(--color-warning-text)]">
          <AlertTriangle size={12} aria-hidden="true" />
          Insights using this data may be unreliable until resolved.
        </div>
      }
      footer={
        state === "idle" ? (
          <div className="flex items-center gap-2">
            <Button type="button" variant="orange" size="sm" onClick={() => setState("done")}>
              <CircleCheck size={13} aria-hidden="true" />
              Apply suggested fix
            </Button>
            <Button type="button" variant="outline" size="sm" onClick={onAssignOwner}>
              Assign owner
            </Button>
            <Button type="button" variant="ghost" size="sm" onClick={onDismiss}>
              Dismiss
            </Button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-xs text-[hsl(var(--prov-human))]">
            <CircleCheck size={14} aria-hidden="true" />
            Correction queued for review.
            <Button type="button" variant="ghost" size="sm" className="h-auto gap-1 p-0 text-xs" onClick={() => setState("idle")}>
              <Undo2 size={12} aria-hidden="true" />
              Undo
            </Button>
          </div>
        )
      }
      {...props}
    />
  )
}

export { DataQualityCard }
