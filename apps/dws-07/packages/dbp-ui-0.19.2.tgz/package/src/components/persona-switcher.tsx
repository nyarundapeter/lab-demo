"use client"
import * as React from "react"
import { ChevronDown, Check } from "lucide-react"
import { Button } from "./button.js"
import { Avatar } from "./avatar.js"
import { cn } from "../lib/cn.js"
import { Popover, PopoverTrigger, PopoverContent } from "./popover.js"
import { SectionLabel } from "./section-label.js"

/**
 * Ported from the accepted admin-shell design reference
 * (`docs/03-features/specs/claude-design-briefs/design-run-pack-2026-07-12/_outputs/admin-system/admin-shell.jsx`,
 * `PersonaSwitcher`). Lift-and-shift of the visual/interaction structure only.
 *
 * **Open architecture question — intentionally NOT resolved here.** What
 * "persona" means is undecided; see
 * `docs/03-features/specs/admin-system-ingestion-ledger-2026-07-13.md#d-persona-switcher-vs-real-delegated-administration--ruling-4`
 * (RULING #4) for the full writeup. Three options are on the table:
 * (a) a demo-only mock toggle matching the reference exactly, with no real
 *     auth tie-in;
 * (b) a display-preference layer over the admin's own real, resolved RBAC
 *     roles (PS.RBAC's `useAbility()`/`getUserAbilities()`) — the audit's
 *     recommendation, since it keeps the reference's "reframe my own view"
 *     behavior while grounding it in real data instead of a fictional array;
 * (c) alias the existing `TenantSwitcher` component, if "persona" is later
 *     redefined to mean genuine identity/tenant switching rather than a
 *     role-preview toggle.
 *
 * This component is built **prop-driven and backend-agnostic** so it can
 * serve any of the three options without rework: it takes a list of
 * personas and a change callback, with zero wiring to any specific
 * auth/RBAC backend. Same posture as `@dbp/organism-schema-builder`'s
 * "Zod stays source of truth" caveat — the UI is built, the underlying
 * data-source decision is deliberately deferred.
 */
export interface Persona {
  /** Stable identifier for this persona (e.g. a role key). */
  id: string
  /** Primary label shown in the trigger and menu (e.g. a role name). */
  label: string
  /** Secondary text shown under the label (e.g. a role description). */
  description?: string
}

export interface PersonaSwitcherProps {
  /** The available personas to switch between. */
  personas: Persona[]
  /** The currently active persona id. */
  value: string
  /** Called with the newly selected persona id. */
  onChange: (id: string) => void
  className?: string
}

function PersonaSwitcher({ personas, value, onChange, className }: PersonaSwitcherProps) {
  const [open, setOpen] = React.useState(false)
  const active = personas.find((p) => p.id === value)

  if (!active) return null

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className={cn("gap-2", className)}
          title="Switch admin persona"
        >
          <Avatar name={active.label} size="sm" />
          <span className="flex flex-col text-left leading-tight">
            <span className="text-xs font-medium">{active.label}</span>
            {active.description && (
              <span className="text-xs text-[var(--color-text-muted)]">
                {active.description}
              </span>
            )}
          </span>
          <ChevronDown size={13} className="text-[var(--color-text-muted)]" aria-hidden="true" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[260px] p-1.5">
        <SectionLabel as="div" className="px-2 py-1.5">
          View as persona
        </SectionLabel>
        {personas.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => {
              onChange(p.id)
              setOpen(false)
            }}
            className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left hover:bg-[var(--color-navy-50)]"
          >
            <Avatar name={p.label} size="sm" />
            <span className="flex flex-1 flex-col">
              <span className="text-xs">{p.label}</span>
              {p.description && (
                <span className="text-xs text-[var(--color-text-muted)]">{p.description}</span>
              )}
            </span>
            {p.id === value && <Check size={14} className="text-secondary" aria-hidden="true" />}
          </button>
        ))}
      </PopoverContent>
    </Popover>
  )
}

export { PersonaSwitcher }
