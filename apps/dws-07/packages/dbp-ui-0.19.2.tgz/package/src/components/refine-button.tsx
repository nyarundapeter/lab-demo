"use client"
import * as React from "react"
import { SlidersHorizontal } from "lucide-react"
import { Popover, PopoverTrigger, PopoverContent } from "./popover.js"
import { Button } from "./button.js"

export const REFINE_LENGTH_OPTIONS = ["Brief", "Standard", "Detailed"] as const
export const REFINE_TONE_OPTIONS = ["Neutral", "Formal", "Direct"] as const

export type RefineAxis = "length" | "tone"

export interface RefineButtonProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "onChange"> {
  /** Called with the axis picked (`"length"` or `"tone"`) and its chosen value. */
  onRefine?: (axis: RefineAxis, value: string) => void
}

/**
 * Refine popover — length + tone axes for an AI-generated output
 * (ai-example-dashboard/ai/primitives.jsx:229-247). Popover-open is the only
 * state owned here; the pick itself is dispatched via `onRefine`.
 */
function RefineButton({ onRefine, ...props }: RefineButtonProps) {
  const [open, setOpen] = React.useState(false)

  const pick = (axis: RefineAxis, value: string) => {
    setOpen(false)
    onRefine?.(axis, value)
  }

  return (
    <span className="relative inline-flex" {...props}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button type="button" variant="ghost" size="sm" className="h-6 gap-1 px-2 text-xs text-[hsl(var(--muted-foreground))]">
            <SlidersHorizontal size={13} aria-hidden="true" />
            Refine
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[230px] p-2.5">
          <div className="mb-2 text-xs font-bold uppercase tracking-[0.4px] text-[hsl(var(--muted-foreground))]">
            Refine output
          </div>
          <div className="mb-1 text-xs text-[hsl(var(--muted-foreground))]">Length</div>
          <div className="mb-2.5 flex gap-1">
            {REFINE_LENGTH_OPTIONS.map((x) => (
              <Button key={x} type="button" variant="outline" size="sm" className="h-7 flex-1 px-1 text-xs" onClick={() => pick("length", x)}>
                {x}
              </Button>
            ))}
          </div>
          <div className="mb-1 text-xs text-[hsl(var(--muted-foreground))]">Tone</div>
          <div className="flex gap-1">
            {REFINE_TONE_OPTIONS.map((x) => (
              <Button key={x} type="button" variant="outline" size="sm" className="h-7 flex-1 px-1 text-xs" onClick={() => pick("tone", x)}>
                {x}
              </Button>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </span>
  )
}

export { RefineButton }
