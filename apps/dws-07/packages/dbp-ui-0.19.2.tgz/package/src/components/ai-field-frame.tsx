import * as React from "react"
import { cn } from "../lib/cn.js"
import { FieldLabel } from "./field-label.js"

export interface AiFieldFrameProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  label: React.ReactNode
  required?: boolean
  /** Small inline hint next to the label. */
  hint?: React.ReactNode
  /** AI-assist affordance slot, right-aligned in the label row (typically an `AssistTrigger`). */
  assist?: React.ReactNode
  /** The actual form control. */
  children: React.ReactNode
  /** Provenance note rendered below the control (e.g. a `ProvTag` + explanation). */
  provNote?: React.ReactNode
}

/**
 * Generic AI-aware form field frame — label stays visible, the assist
 * affordance sits beside it, never replacing it (ai-example-dashboard/
 * ai/field.jsx:10-20). Distinct from `@dbp/ui`'s `form-field.tsx`, which has
 * no AI-assist slot.
 */
function AiFieldFrame({ label, required = false, hint, assist, children, provNote, className, ...props }: AiFieldFrameProps) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)} {...props}>
      <div className="flex items-center gap-1.5">
        <FieldLabel className="inline normal-case text-xs font-medium tracking-normal mb-0">
          {label}
          {required && <span className="text-[var(--color-danger)]"> *</span>}
        </FieldLabel>
        {hint && <span className="text-xs text-[hsl(var(--muted-foreground))]">{hint}</span>}
        {assist && <div className="ml-auto">{assist}</div>}
      </div>
      {children}
      {provNote && (
        <div className="flex items-center gap-1.5 text-xs text-[hsl(var(--muted-foreground))]">{provNote}</div>
      )}
    </div>
  )
}

export { AiFieldFrame }
