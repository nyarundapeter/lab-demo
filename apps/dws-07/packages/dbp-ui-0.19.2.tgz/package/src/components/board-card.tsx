import * as React from "react"
import { User, Calendar, Lock } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Badge, type BadgeProps } from "./badge.js"
import { Avatar } from "./avatar.js"

export interface BoardCardProps {
  title: string
  subtitle?: string
  /** Small metadata line rendered below the subtitle (e.g. "Category · Date"). */
  meta?: React.ReactNode
  /** Priority/status pill tone — pass an existing valid Badge tone (never "neutral"). */
  badgeTone?: BadgeProps["tone"]
  badgeLabel?: React.ReactNode
  /** Second chip alongside `badgeLabel` — e.g. a status chip next to a risk chip. */
  secondaryBadgeTone?: BadgeProps["tone"]
  secondaryBadgeLabel?: React.ReactNode
  /** Assignee display name. Renders an initials `Avatar`; omitted/empty renders
   *  an "Unassigned" dashed placeholder (per the kanban vendor-pipeline design ref). */
  assigneeName?: string
  /** Due-date slot rendered at the end of the assignee row. */
  dueLabel?: React.ReactNode
  /** When true, `dueLabel` renders in the danger tone with bold weight. Superseded by `dueTier` when both are given. */
  overdue?: boolean
  /** Graded due-date tone — "overdue" (danger+bold), "today"/"soon" (warning), "none" (italic muted "no date"), "normal" (default). Takes precedence over `overdue`. */
  dueTier?: "overdue" | "today" | "soon" | "normal" | "none"
  /** `#tag` chips rendered below the title/subtitle row. */
  tags?: string[]
  /** Locked/compliance-hold state — swaps the card surface to the neutral wash
   *  and shows a lock chip next to `badgeLabel`. */
  locked?: boolean
  /** Label shown in the lock chip. Defaults to "Hold". */
  lockLabel?: string
  /** If provided, the card becomes a clickable, keyboard-operable button. */
  onClick?: () => void
  className?: string
}

/**
 * BoardCard — a single kanban-card primitive for use inside CollectionBoardLayout
 * columns. Sets `role="listitem"` so it is structurally correct when rendered
 * inside the layout's `role="list"` column wrapper.
 */
export function BoardCard({
  title,
  subtitle,
  meta,
  badgeTone,
  badgeLabel,
  secondaryBadgeTone,
  secondaryBadgeLabel,
  assigneeName,
  dueLabel,
  overdue = false,
  dueTier,
  tags,
  locked = false,
  lockLabel = "Hold",
  onClick,
  className,
}: BoardCardProps) {
  const isInteractive = onClick !== undefined
  const hasAssigneeRow = assigneeName !== undefined || dueLabel !== undefined
  const resolvedDueTier = dueTier ?? (overdue ? "overdue" : "normal")
  const dueClassName =
    resolvedDueTier === "overdue"
      ? "font-bold text-[var(--color-danger-text)]"
      : resolvedDueTier === "today" || resolvedDueTier === "soon"
        ? "font-semibold text-[var(--color-warning-text)]"
        : resolvedDueTier === "none"
          ? "italic text-[var(--color-text-muted)]"
          : "font-medium text-[var(--color-neutral-text)]"
  // The dual-chip top row only replaces the original single-badge/meta row
  // layout when a secondary chip or the locked state is actually used — this
  // keeps existing single-badge consumers pixel/DOM-identical.
  const hasChipRow = secondaryBadgeLabel !== undefined || locked

  const content = (
    <>
      {hasChipRow && (badgeLabel !== undefined || secondaryBadgeLabel !== undefined || locked) && (
        <div className="flex items-center gap-1.5">
          {badgeLabel !== undefined && (
            <Badge tone={badgeTone} size="sm">
              {badgeLabel}
            </Badge>
          )}
          {secondaryBadgeLabel !== undefined && (
            <Badge tone={secondaryBadgeTone} size="sm">
              {secondaryBadgeLabel}
            </Badge>
          )}
          {locked && (
            <span className="ml-auto inline-flex shrink-0 items-center gap-1 rounded-pill bg-[var(--color-danger-surface)] px-2 py-0.5 text-xs font-bold text-[var(--color-danger-text)]">
              <Lock size={11} strokeWidth={2.2} className="shrink-0" />
              {lockLabel}
            </span>
          )}
        </div>
      )}
      <p className="m-0 text-sm font-semibold leading-snug text-[var(--color-text)] line-clamp-2">{title}</p>
      {subtitle && (
        <p className="m-0 flex items-center gap-1 text-xs text-[var(--color-text-muted)]">
          <User size={12} strokeWidth={2} className="shrink-0" />
          {subtitle}
        </p>
      )}
      {tags && tags.length > 0 && (
        <div className="flex flex-wrap items-center gap-1">
          {tags.map((tag) => (
            <span
              key={tag}
              className="rounded-pill border border-[var(--color-border-default)] px-1.5 py-0.5 text-xs font-medium text-[var(--color-text-muted)]"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}
      {(meta !== undefined || (!hasChipRow && badgeLabel !== undefined)) && (
        <div className="flex items-center justify-between mt-0.5">
          {meta !== undefined && (
            <span className="flex items-center gap-1 text-xs text-[var(--color-text-muted)]">
              <Calendar size={12} strokeWidth={2} className="shrink-0" />
              {meta}
            </span>
          )}
          {!hasChipRow && badgeLabel !== undefined && (
            <Badge tone={badgeTone} size="sm">
              {badgeLabel}
            </Badge>
          )}
        </div>
      )}
      {hasAssigneeRow && (
        <div className="flex items-center gap-2 mt-0.5">
          {assigneeName ? (
            <Avatar name={assigneeName} size="sm" className="h-6 w-6 text-xs" />
          ) : (
            <div
              aria-label="Unassigned"
              role="img"
              className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-[1.5px] border-dashed border-[var(--color-neutral-border)] text-xs text-[var(--color-neutral-text)]"
            >
              ?
            </div>
          )}
          <span className="flex-1 truncate text-xs font-medium text-[var(--color-text-secondary)]">
            {assigneeName || "Unassigned"}
          </span>
          {dueLabel !== undefined && (
            <span
              className={cn(
                "ml-auto inline-flex shrink-0 items-center gap-1 whitespace-nowrap text-xs",
                dueClassName
              )}
            >
              <Calendar size={12} strokeWidth={2} className="shrink-0" />
              {dueLabel}
            </span>
          )}
        </div>
      )}
    </>
  )

  const sharedClassName = cn(
    "flex flex-col gap-1.5 min-h-[44px] p-3",
    "rounded-[var(--radius)] border bg-[var(--color-surface)]",
    locked
      ? "border-[var(--color-neutral-border)] bg-[var(--color-neutral-surface)]"
      : "border-[var(--color-border)]",
    isInteractive &&
      "text-left cursor-pointer transition-colors motion-safe:transition-all hover:border-primary focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
    className
  )

  if (isInteractive) {
    return (
      <button type="button" role="listitem" onClick={onClick} className={sharedClassName}>
        {content}
      </button>
    )
  }

  return (
    <div role="listitem" className={sharedClassName}>
      {content}
    </div>
  )
}
