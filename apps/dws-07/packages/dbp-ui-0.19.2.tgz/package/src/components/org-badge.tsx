import { OrgIdentityRow, type OrgIdentityRowProps } from "./org-identity-row.js"

/**
 * @deprecated Renamed to `OrgIdentityRow` — "badge" collided with the
 * chip-family `Badge` component naming (this is an identity row, not a
 * chip). Use `OrgIdentityRow` in new code; this re-export exists only for
 * backward compatibility with existing import sites.
 */
export type OrgBadgeProps = OrgIdentityRowProps

/** @deprecated Use `OrgIdentityRow`. */
const OrgBadge = OrgIdentityRow

export { OrgBadge }
