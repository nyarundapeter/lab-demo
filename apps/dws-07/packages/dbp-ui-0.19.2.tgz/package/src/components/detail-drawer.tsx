"use client";

// Ported from the STCB GRC solution's shared detail-drawer kit (WS-6.2) —
// the generic detail-drawer shell any record-detail drawer composes on top
// of (tab strip + scrollable body + optional footer actions). Generalised
// for @dbp/ui: no domain naming, no deep-imports into other packages'
// internals, styled exclusively with CSS custom properties.
//
// Unlike the STCB original, this version uses SheetContent's `hideClose`
// prop (added in @dbp/ui 0.7.1, GG-14) instead of a CSS rule that hides
// SheetContent's built-in close button — that prop didn't exist yet when
// STCB's copy was written.

import * as React from "react";
import { Maximize2, Minimize2, X, Link2 } from "lucide-react";
import { Sheet, SheetContent } from "./sheet.js";
import { Button } from "./button.js";
import { toast } from "./toast.js";
import { cn } from "../lib/cn.js";
import type { BadgeProps } from "./badge.js";
import { useReducedMotion } from "../hooks/use-reduced-motion.js";
import { DetailTabStrip } from "./detail-tab-strip.js";
import { DetailStatusText } from "./detail-linked-records-list.js";

export { useContainerWidth } from "../hooks/use-container-width.js";

export interface DetailDrawerPill {
  label: string;
  tone?: BadgeProps["tone"];
}

export interface DetailDrawerTab {
  key: string;
  label: string;
  content: React.ReactNode;
}

export interface DetailDrawerProps {
  open: boolean;
  onClose: () => void;
  /** Controlled expand state — lifted so callers can reflect it in the URL. */
  expanded: boolean;
  onExpandedChange: (expanded: boolean) => void;
  title: string;
  pills?: DetailDrawerPill[] | undefined;
  subtitle?: string | undefined;
  tabs: DetailDrawerTab[];
  activeTab: string;
  onActiveTabChange: (key: string) => void;
  /** Primary action button(s), rendered right-aligned in the footer. */
  footerActions?: React.ReactNode;
  /** Absolute URL to copy when "Copy link" is used. Omit to hide the button. */
  copyUrl?: string | undefined;
  testId?: string | undefined;
}

export function DetailDrawer({
  open,
  onClose,
  expanded,
  onExpandedChange,
  title,
  pills,
  subtitle,
  tabs,
  activeTab,
  onActiveTabChange,
  footerActions,
  copyUrl,
  testId,
}: DetailDrawerProps) {
  const reducedMotion = useReducedMotion();

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && e.shiftKey) {
      e.preventDefault();
      onExpandedChange(!expanded);
    }
  };

  const handleCopyLink = React.useCallback(() => {
    if (!copyUrl) return;
    void navigator.clipboard.writeText(copyUrl).then(() => {
      toast({ title: "Link copied", description: "Shareable link copied to clipboard." });
    });
  }, [copyUrl]);

  const activeContent = tabs.find((t) => t.key === activeTab)?.content ?? null;

  return (
    <Sheet
      open={open}
      onOpenChange={(o) => {
        if (!o) onClose();
      }}
    >
      <SheetContent
        side="right"
        hideClose
        data-testid={testId}
        onKeyDown={handleKeyDown}
        onEscapeKeyDown={(e) => {
          e.preventDefault();
          if (expanded) onExpandedChange(false);
          else onClose();
        }}
        className={cn(
          "detail-drawer-panel flex flex-col gap-0 p-0",
          reducedMotion && "!duration-0",
          expanded && "is-expanded",
        )}
      >
        {/* Plain CSS, not Tailwind utilities: a consuming solution's `app/`
            tree may not scan this package's content globs for novel
            responsive utility classes (e.g. md:w-[...]), so real @media
            rules are used instead — they always work regardless of that
            gap. */}
        <style>{`
          .detail-drawer-panel { width: 100%; }
          @media (min-width: 640px) {
            .detail-drawer-panel:not(.is-expanded) { width: min(90vw, 480px); }
          }
          @media (min-width: 768px) {
            .detail-drawer-panel:not(.is-expanded) { width: min(90vw, 560px); }
          }
          .detail-drawer-panel.is-expanded { width: 100%; }
          /* One consistent vertical rhythm between drawer sections/cards. Tab
             content roots use this class (instead of ad-hoc margins on
             individual sections) so the gap between cards/sections is
             uniform everywhere in the drawer. */
          .detail-drawer-stack {
            display: flex;
            flex-direction: column;
            gap: 16px;
          }
        `}</style>
        <div className="flex min-h-0 flex-1 flex-col">
          {/* Header */}
          <div className="shrink-0 border-b border-[var(--color-border-default)] px-6 pb-3 pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h2 className="truncate text-lg font-semibold text-[var(--color-text)]">{title}</h2>
                {pills && pills.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap items-center gap-3">
                    {pills.map((p) => (
                      <DetailStatusText key={p.label} tone={p.tone ?? "gray"}>
                        {p.label}
                      </DetailStatusText>
                    ))}
                  </div>
                )}
                {subtitle && <p className="mt-1 text-sm text-[var(--color-text-muted)]">{subtitle}</p>}
              </div>
              <div className="flex shrink-0 items-center gap-1">
                {expanded && copyUrl && (
                  <Button variant="ghost" size="icon" aria-label="Copy link" onClick={handleCopyLink}>
                    <Link2 className="h-4 w-4" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={expanded ? "Collapse" : "Expand"}
                  onClick={() => onExpandedChange(!expanded)}
                >
                  {expanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                </Button>
                <Button variant="ghost" size="icon" aria-label="Close" onClick={onClose}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="shrink-0 px-6">
            <DetailTabStrip tabs={tabs} activeTab={activeTab} onActiveTabChange={onActiveTabChange} />
          </div>

          {/* Body */}
          <div className="min-h-0 flex-1 overflow-y-auto bg-[var(--color-surface)] px-6 py-4">
            <div style={expanded ? { marginLeft: "auto", marginRight: "auto", maxWidth: "72rem" } : undefined}>
              {activeContent}
            </div>
          </div>

          {/* Footer — actions only. The header X closes the drawer and the
              header expand/collapse icon toggles full view, so this bar
              doesn't duplicate either as a text button; it exists solely for
              the caller's primary record actions. */}
          {footerActions && (
            <div className="shrink-0 border-t border-[var(--color-border-default)] px-6 py-3">
              <div className="flex items-center justify-end gap-2">{footerActions}</div>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

export default DetailDrawer;
