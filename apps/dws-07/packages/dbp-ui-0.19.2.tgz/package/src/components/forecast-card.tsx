import * as React from "react"
import { RefreshCw, Layers, ExternalLink } from "lucide-react"
import type { AiConfidenceLevel } from "@dbp/contracts"
import { cn } from "../lib/cn.js"
import { AiSurface, AiSurfaceFacet } from "./ai-surface.js"
import { AiConfidence } from "./ai-confidence.js"
import { FeedbackControl } from "./feedback-control.js"
import { ProvTag } from "./prov-tag.js"
import { Button } from "./button.js"

export interface ForecastCardData {
  /** Muted subject line above the big value — oracle `d.label`. */
  label: string
  /** Big predicted outcome, pre-formatted. */
  value: string
  period: string
  updated: string
  confidence: AiConfidenceLevel
  confidenceNote?: string
  /** e.g. "3–7 cases (80% interval)". */
  range: string
  /** e.g. "Target: ≤ 2 breaches / week". */
  target: string
  drivers: string[]
  /** Historical basis blurb. */
  basis: string
  /** Optional chart slot; defaults to the oracle actual-vs-forecast mini chart. */
  chart?: React.ReactNode
}

export interface ForecastCardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  data: ForecastCardData
  onRegenerate?: () => void
  onScenarioOptions?: () => void
  onOpenDetail?: () => void
}

/** Quiet secondary action — oracle IconTextBtn (cursor + 150ms hover). */
const secondaryActionClass =
  "inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-[var(--radius-button)] px-1.5 text-xs font-medium text-[var(--color-text-muted)] transition-colors duration-150 hover:bg-[var(--color-surface)] hover:text-[var(--color-text)] focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"

/**
 * Tiny actual-vs-forecast chart (oracle MiniChart + ux chart guidance):
 * solid = actual, dashed = forecast, soft predict band = uncertainty.
 * Differentiates by line style, not colour alone (a11y).
 * Labels sit in the top corners with a soft surface scrim so they never
 * collide with the stroke (oracle put ACTUAL at bottom-left on the line).
 */
function ForecastMiniChart() {
  const legendClass =
    "pointer-events-none absolute top-1 rounded-[3px] bg-[var(--color-surface-content)]/90 px-1 py-px text-xs font-semibold uppercase tracking-[0.04em]"

  return (
    <div
      className="relative mb-3 h-[var(--forecast-chart-h)] border-b border-l border-[var(--color-border-subtle)]"
      data-om-raster="true"
      role="img"
      aria-label="Actual trend as a solid line, then forecast as a dashed line with a soft confidence band"
    >
      <svg
        width="100%"
        height="74"
        viewBox="0 0 320 74"
        preserveAspectRatio="none"
        className="block"
        aria-hidden="true"
      >
        <path
          d="M0 58 L60 50 L120 54 L180 40"
          fill="none"
          stroke="var(--color-text)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M180 40 L240 30 L320 14"
          fill="none"
          stroke="hsl(var(--prov-predict))"
          strokeWidth="2"
          strokeDasharray="4 4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M180 40 L240 22 L320 4 L320 26 L240 40 L180 40 Z"
          fill="hsl(var(--prov-predict) / 0.15)"
          stroke="none"
        />
        <line
          x1="180"
          y1="0"
          x2="180"
          y2="74"
          stroke="var(--color-border-subtle)"
          strokeWidth="1"
          strokeDasharray="2 3"
        />
      </svg>
      <span className={cn(legendClass, "left-1.5 text-[var(--color-text-muted)]")}>
        Actual
      </span>
      <span className={cn(legendClass, "right-1.5 text-[hsl(var(--prov-predict))]")}>
        Forecast
      </span>
    </div>
  )
}

/**
 * AI forecast investigation card — predicted value, confidence band, drivers,
 * and historical basis (ai-example-dashboard/ai/cards.jsx:310-336).
 * White fill + purple AI accents (no wash). Prediction hue only on the
 * forecast chart stroke/band and ProvTag.
 */
function ForecastCard({
  data,
  onRegenerate,
  onScenarioOptions,
  onOpenDetail,
  className,
  ...props
}: ForecastCardProps) {
  const low = data.confidence === "low"

  return (
    <AiSurface
      label="prediction"
      labelText="AI forecast"
      low={low}
      meta={
        <>
          <span>{data.period}</span>
          <span
            aria-hidden="true"
            className="inline-block size-[3px] shrink-0 rounded-full bg-[var(--color-text-muted)]/50"
          />
          <span>Updated {data.updated}</span>
        </>
      }
      actions={
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="size-7 cursor-pointer"
          aria-label="Regenerate"
          onClick={onRegenerate}
        >
          <RefreshCw size={14} aria-hidden="true" />
        </Button>
      }
      foot={
        <>
          <ProvTag provenance="predict" />
          <FeedbackControl compact className="ml-auto" />
        </>
      }
      className={cn(className)}
      {...props}
    >
      {/* Single wrapper so AiSurface body `gap-3` does not inflate every block (oracle densify). */}
      <div>
        <p className="m-0 mb-1 text-sm leading-snug text-[var(--color-text-muted)]">{data.label}</p>

        <div className="mb-0.5 flex items-baseline gap-2.5">
          <h3 className="m-0 min-w-0 flex-1 text-2xl font-bold leading-[1.15] tracking-[-0.02em] text-[var(--color-text)]">
            {data.value}
          </h3>
          <AiConfidence
            className="shrink-0"
            level={data.confidence}
            {...(data.confidenceNote !== undefined ? { note: data.confidenceNote } : {})}
          />
        </div>

        <p className="m-0 mb-3 text-xs leading-snug text-[var(--color-text-muted)]">
          Confidence range: {data.range} · {data.target}
        </p>

        {data.chart ?? <ForecastMiniChart />}

        <AiSurfaceFacet label="Main assumptions & key drivers" prov="predict">
          <ul className="m-0.5 mb-0 flex list-disc flex-col gap-1 pl-4 text-sm leading-[1.55]">
            {data.drivers.map((driver) => (
              <li key={driver}>{driver}</li>
            ))}
          </ul>
        </AiSurfaceFacet>

        <p className="m-0 text-xs leading-snug text-[var(--color-text-muted)]">
          Historical basis: {data.basis}
        </p>

        <div className="mt-3.5 flex flex-wrap items-center gap-2 border-t border-[hsl(var(--ai-border)/0.35)] pt-3">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onScenarioOptions}
            className="h-8 cursor-pointer border border-[hsl(var(--ai-border))] bg-[hsl(var(--ai-soft))] px-3 text-[hsl(var(--ai-strong))] transition-colors duration-150 hover:bg-[hsl(var(--ai-soft-2))] hover:text-[hsl(var(--ai-strong))]"
            data-testid="forecast-scenario-options"
          >
            <Layers size={13} aria-hidden="true" />
            Scenario options
          </Button>
          <Button type="button" variant="ghost" size="sm" className={secondaryActionClass} onClick={onOpenDetail}>
            <ExternalLink size={12} aria-hidden="true" />
            Open forecast detail
          </Button>
        </div>
      </div>
    </AiSurface>
  )
}

export { ForecastCard }
