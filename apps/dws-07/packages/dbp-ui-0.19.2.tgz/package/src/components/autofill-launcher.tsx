import * as React from "react"
import { Paperclip, Mail, Database, User, History, Layers, type LucideIcon } from "lucide-react"
import { AiSurface } from "./ai-surface.js"
import { CtrlBadge } from "./ctrl-badge.js"
import { Button } from "./button.js"
import { cn } from "../lib/cn.js"

const SOURCES: { icon: LucideIcon; label: string }[] = [
  { icon: Paperclip, label: "Upload a document" },
  { icon: Mail, label: "From email / message" },
  { icon: Database, label: "From existing record" },
  { icon: User, label: "From profile data" },
  { icon: History, label: "From previous submission" },
  { icon: Layers, label: "From selected source data" },
]

export interface AutofillLauncherProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  onStart?: () => void
}

/**
 * Autofill entry point — a static grid of source pickers, each starting the
 * same review-before-apply flow (ai-example-dashboard/ai/field.jsx:205-217).
 */
function AutofillLauncher({ onStart, className, ...props }: AutofillLauncherProps) {
  return (
    <AiSurface
      label="assisted"
      labelText="Autofill this request"
      flat
      className={cn(className)}
      actions={<CtrlBadge level={3} />}
      {...props}
    >
      <p className="m-0 mb-3 text-xs leading-normal text-[hsl(var(--muted-foreground))]">
        Extract known details from a source. You&apos;ll review every value before anything is applied.
      </p>
      <div className="grid grid-cols-2 gap-2">
        {SOURCES.map(({ icon: Icon, label }) => (
          <Button
            key={label}
            type="button"
            variant="outline"
            size="sm"
            className="justify-start gap-2"
            onClick={onStart}
          >
            <Icon size={14} aria-hidden="true" />
            {label}
          </Button>
        ))}
      </div>
    </AiSurface>
  )
}

export { AutofillLauncher }
