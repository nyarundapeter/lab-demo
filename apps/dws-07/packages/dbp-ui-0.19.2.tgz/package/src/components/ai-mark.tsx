import * as React from "react"
import { Bot } from "lucide-react"
import { cn } from "../lib/cn"

export interface AiMarkProps extends React.HTMLAttributes<HTMLSpanElement> {
  size?: number
}

/**
 * The one consistent AI glyph — lucide `Bot`. Per the 2026-07-16 AI ruling,
 * a sparkles/sparkle icon must NEVER be used to indicate AI-touched content.
 */
function AiMark({ size = 12, className, ...props }: AiMarkProps) {
  return (
    <span
      aria-hidden
      className={cn("inline-flex items-center justify-center shrink-0 text-[hsl(var(--ai))]", className)}
      {...props}
    >
      <Bot size={size} />
    </span>
  )
}

export { AiMark }
