import * as React from "react"
import { useForm, Controller } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./card.js"
import { FormField } from "./form-field.js"
import { Input } from "./input.js"
import { SectionLabel } from "./section-label.js"
import { Switch } from "./switch.js"
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "./select.js"
import { toast } from "./toast.js"

/* ─── AdminSettingsForm ────────────────────────────────────────────────────
 * Drop-in replacement for the generator's inline admin config-form JSX.
 * Renders a config-driven field list wired to real react-hook-form + Zod
 * validation. Renders its own <form id={formId}> but NOT a submit button —
 * the surrounding layout (SettingsLayout / ConfigTabsLayout) owns the Save
 * button via <Button type="submit" form={formId}>, which triggers this
 * form's real onSubmit through the HTML `form` attribute.
 *
 * On valid submit: calls onSubmit (if provided), dispatches a real
 * "dbp:admin-settings:submit" CustomEvent on document, and shows a toast
 * confirmation — the generic "real event, stub handler" contract used by
 * marketplace-item-detail's dispatchAction. Persisting to a backend is out
 * of scope: these are generic config forms with no backing PS.DATA entity.
 * ─────────────────────────────────────────────────────────────────────── */

export type AdminSettingsFieldType =
  | "text"
  | "password"
  | "url"
  | "email"
  | "number"
  | "select"
  | "switch"

export interface AdminSettingsFormField {
  name: string
  label: string
  fieldType: AdminSettingsFieldType
  defaultValue?: string
  defaultChecked?: boolean
  placeholder?: string
  /** Options for fieldType "select". */
  options?: Array<{ value: string; label: string }>
  required?: boolean
}

export interface AdminSettingsFormSection {
  title: string
  fields: AdminSettingsFormField[]
}

export interface AdminSettingsFormProps {
  /** id applied to the <form> element — the layout's Save button targets this via `form={formId}`. */
  formId: string
  /** Flat field list. Mutually exclusive with `sections` — provide exactly one. */
  fields?: AdminSettingsFormField[]
  /** Fields grouped under bordered section cards. Mutually exclusive with `fields`. */
  sections?: AdminSettingsFormSection[]
  /** Optional heading rendered above the fields card when using `fields` (flat) mode. */
  title?: string
  /** Optional one-line description under `title`. */
  description?: string
  onSubmit?: (values: Record<string, string | boolean>) => void
  className?: string
}

type FormValues = Record<string, string | boolean>

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const URL_RE = /^https?:\/\/.+/i

function buildFieldSchema(field: AdminSettingsFormField): z.ZodTypeAny {
  if (field.fieldType === "switch") return z.boolean()

  let schema: z.ZodTypeAny = field.required
    ? z.string().min(1, `${field.label} is required`)
    : z.string()
  if (field.fieldType === "email") {
    schema = schema.refine((v) => (v as string).length === 0 || EMAIL_RE.test(v as string), `Enter a valid email address`)
  }
  if (field.fieldType === "url") {
    schema = schema.refine((v) => (v as string).length === 0 || URL_RE.test(v as string), `Enter a valid URL`)
  }
  return schema
}

function buildSchema(fields: AdminSettingsFormField[]) {
  const shape: Record<string, z.ZodTypeAny> = {}
  for (const field of fields) {
    shape[field.name] = buildFieldSchema(field)
  }
  return z.object(shape)
}

function buildDefaultValues(fields: AdminSettingsFormField[]): FormValues {
  const values: FormValues = {}
  for (const field of fields) {
    values[field.name] = field.fieldType === "switch" ? Boolean(field.defaultChecked) : (field.defaultValue ?? "")
  }
  return values
}

export function AdminSettingsForm({ formId, fields, sections, title, description, onSubmit, className }: AdminSettingsFormProps) {
  const allFields = React.useMemo(
    () => fields ?? (sections ?? []).flatMap((s) => s.fields),
    [fields, sections],
  )
  const schema = React.useMemo(() => buildSchema(allFields), [allFields])
  const defaultValues = React.useMemo(() => buildDefaultValues(allFields), [allFields])

  const {
    register,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues,
  })

  function onValid(values: FormValues) {
    onSubmit?.(values)
    document.dispatchEvent(
      new CustomEvent("dbp:admin-settings:submit", {
        detail: { formId, values },
        bubbles: true,
      }),
    )
    toast({ title: "Settings saved", description: "Your changes have been applied." })
  }

  function renderField(field: AdminSettingsFormField) {
    const error = errors[field.name]?.message as string | undefined

    // FormField's auto-id-injection clones only its immediate child; a
    // <Controller> render-prop isn't a real DOM element for that to attach
    // to, so switch/select fields pass a matching `id` through explicitly.
    if (field.fieldType === "switch") {
      return (
        <FormField key={field.name} id={field.name} label={field.label} {...(error ? { error } : {})}>
          <Controller
            name={field.name}
            control={control}
            render={({ field: { value, onChange, ...rest } }) => (
              <Switch id={field.name} checked={Boolean(value)} onCheckedChange={onChange} {...rest} />
            )}
          />
        </FormField>
      )
    }

    if (field.fieldType === "select") {
      return (
        <FormField key={field.name} id={field.name} label={field.label} {...(field.required ? { required: true } : {})} {...(error ? { error } : {})}>
          <Controller
            name={field.name}
            control={control}
            render={({ field: { value, onChange } }) => (
              <Select value={String(value)} onValueChange={onChange}>
                <SelectTrigger id={field.name} error={Boolean(error)}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(field.options ?? []).map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
        </FormField>
      )
    }

    return (
      <FormField key={field.name} label={field.label} {...(field.required ? { required: true } : {})} {...(error ? { error } : {})}>
        <Input
          type={field.fieldType}
          placeholder={field.placeholder}
          {...register(field.name)}
        />
      </FormField>
    )
  }

  return (
    <form id={formId} onSubmit={handleSubmit(onValid)} noValidate className={className}>
      <div className="flex flex-col gap-8">
        {sections
          ? sections.map((section) => (
              <div key={section.title} className="flex flex-col gap-3">
                <SectionLabel as="h3">{section.title}</SectionLabel>
                <Card>
                  <CardContent className="flex flex-col gap-6">
                    {section.fields.map(renderField)}
                  </CardContent>
                </Card>
              </div>
            ))
          : (
              <Card>
                {(title || description) && (
                  <CardHeader>
                    {title && <CardTitle>{title}</CardTitle>}
                    {description && <CardDescription>{description}</CardDescription>}
                  </CardHeader>
                )}
                <CardContent className="flex flex-col gap-6">{allFields.map(renderField)}</CardContent>
              </Card>
            )}
      </div>
    </form>
  )
}
