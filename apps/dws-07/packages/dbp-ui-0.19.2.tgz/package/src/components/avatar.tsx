import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn.js"

/* ─── Deterministic background palette from DQ tokens ──────────────────── */
const PALETTE: string[] = [
  "bg-primary text-white",
  "bg-secondary text-white",
  "bg-[var(--color-info)] text-white",
  "bg-[var(--color-success)] text-white",
  "bg-[var(--color-navy-200)] text-[var(--color-text-primary)]",
  "bg-[var(--color-orange-100)] text-secondary",
]

function pickColor(name: string): string {
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = ((hash << 5) - hash + name.charCodeAt(i)) | 0
  }
  return PALETTE[Math.abs(hash) % PALETTE.length] ?? PALETTE[0]!
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/)
  if (parts.length === 0) return "?"
  const first = parts[0]
  if (!first) return "?"
  if (parts.length === 1) return first.slice(0, 2).toUpperCase()
  const last = parts[parts.length - 1]
  return ((first[0] ?? "") + (last ? (last[0] ?? "") : "")).toUpperCase()
}

/* ─── Size variants ─────────────────────────────────────────────────────── */
const avatarVariants = cva(
  "relative flex shrink-0 items-center justify-center overflow-hidden rounded-full select-none",
  {
    variants: {
      size: {
        sm: "h-7 w-7 text-xs font-bold",
        md: "h-9 w-9 text-xs font-bold",
        lg: "h-12 w-12 text-sm font-bold",
      },
    },
    defaultVariants: {
      size: "md",
    },
  }
)

/**
 * Availability status shown as a small dot on the avatar's edge
 * (collaboration-system/presence.jsx `Avatar` `presence` prop, DR reference
 * "Presence status dots"). Purely a visual variant driven by a prop — wiring
 * to a live status source is a separate, service-dependent concern (Wave 3
 * Family 4f scope note).
 */
export type AvatarPresence = "online" | "away" | "offline"

const presenceDotClasses: Record<AvatarPresence, string> = {
  online: "bg-[var(--color-success)]",
  away: "bg-[var(--color-warning)]",
  offline: "bg-[var(--color-text-disabled)]",
}

const presenceDotSizeClasses: Record<NonNullable<AvatarProps["size"]>, string> = {
  sm: "h-1.5 w-1.5",
  md: "h-2 w-2",
  lg: "h-2.5 w-2.5",
}

function PresenceDot({ presence, size }: { presence: AvatarPresence; size: NonNullable<AvatarProps["size"]> }) {
  return (
    <span
      aria-hidden="true"
      data-testid="avatar-presence-dot"
      data-presence={presence}
      className={cn(
        "absolute right-0 bottom-0 rounded-full ring-2 ring-white",
        presenceDotClasses[presence],
        presenceDotSizeClasses[size],
      )}
    />
  )
}

export interface AvatarProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof avatarVariants> {
  /** Full display name — used to derive initials and deterministic bg color */
  name: string
  /** Optional image src; falls back to initials if not provided or fails to load */
  src?: string
  /** Alt text for the image */
  alt?: string
  /** Availability status dot rendered on the avatar's edge. Omit for no dot. */
  presence?: AvatarPresence
}

export function Avatar({ name, src, alt, size, presence, className, ...props }: AvatarProps) {
  const [imgError, setImgError] = React.useState(false)
  const colorClass = pickColor(name)
  const initials = getInitials(name)
  const resolvedSize = size ?? "md"

  return (
    <div
      className={cn(avatarVariants({ size }), colorClass, className)}
      aria-label={alt ?? name}
      role="img"
      {...props}
    >
      {src && !imgError ? (
        <img
          src={src}
          alt={alt ?? name}
          className="h-full w-full object-cover"
          onError={() => setImgError(true)}
        />
      ) : (
        <span aria-hidden="true">{initials}</span>
      )}
      {presence && <PresenceDot presence={presence} size={resolvedSize} />}
    </div>
  )
}

/* ─── Avatar stack (overlapping "viewing now" cluster) ──────────────────── */

export interface AvatarStackItem {
  /** Stable identity for the React key — falls back to `name` when omitted. */
  id?: string
  name: string
  src?: string
  alt?: string
  presence?: AvatarPresence
}

export interface AvatarStackProps extends React.HTMLAttributes<HTMLDivElement> {
  items: AvatarStackItem[]
  /** How many avatars render before collapsing the rest into a "+N" chip. Default 4. */
  max?: number
  size?: AvatarProps["size"]
}

/**
 * Overlapping avatar cluster (collaboration-system/presence.jsx `AvatarStack`
 * — "viewing now" pattern). Caps at `max` and collapses the remainder into a
 * "+N" chip rather than growing unbounded.
 */
export function AvatarStack({ items, max = 4, size = "sm", className, ...props }: AvatarStackProps) {
  const shown = items.slice(0, max)
  const overflow = items.length - shown.length

  return (
    <div className={cn("flex items-center -space-x-2", className)} {...props}>
      {shown.map((item, i) => (
        <Avatar
          key={item.id ?? item.name}
          name={item.name}
          size={size}
          className="ring-2 ring-white"
          style={{ zIndex: shown.length - i }}
          {...(item.src !== undefined && { src: item.src })}
          {...(item.alt !== undefined && { alt: item.alt })}
          {...(item.presence !== undefined && { presence: item.presence })}
        />
      ))}
      {overflow > 0 && (
        <div
          className={cn(avatarVariants({ size }), "bg-[var(--color-surface)] text-[var(--color-text-muted)] ring-2 ring-white")}
          aria-label={`${overflow} more`}
          data-testid="avatar-stack-overflow"
        >
          +{overflow}
        </div>
      )}
    </div>
  )
}

/* ─── Name + role lockup variant (matches top-bar UserIdentity) ─────────── */
export interface AvatarLockupProps extends AvatarProps {
  /** Secondary text (role/email) shown below the name */
  role?: string
}

export function AvatarLockup({ name, role, size = "md", src, alt, className, ...props }: AvatarLockupProps) {
  return (
    <div className={cn("flex items-center gap-2.5", className)} {...props}>
      <Avatar name={name} size={size} {...(src !== undefined && { src })} {...(alt !== undefined && { alt })} />
      <div className="min-w-0">
        <p className="max-w-[9rem] truncate text-xs font-bold text-[var(--color-text-primary)] leading-snug">
          {name}
        </p>
        {role && (
          <p className="max-w-[9rem] truncate text-xs text-[var(--color-text-muted)] leading-snug">
            {role}
          </p>
        )}
      </div>
    </div>
  )
}
