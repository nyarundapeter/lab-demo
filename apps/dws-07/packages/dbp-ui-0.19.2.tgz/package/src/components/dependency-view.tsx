import * as React from "react";
import { GitBranch, ArrowRight } from "lucide-react";
import { cn } from "../lib/cn.js";
import { Card, CardHeader, CardTitle, CardContent } from "./card.js";
import { Alert } from "./alert.js";

export interface DependencyNode {
  /** Primary label, e.g. "Tier 1 routing". */
  label: string;
  /** Secondary caption, e.g. "This rule · v7". */
  sub?: string | undefined;
  /** Optional navigation target for this node's click action. */
  to?: string | undefined;
}

export interface DependencyViewProps {
  /** Nodes that trigger the current config (left column). */
  upstream: DependencyNode[];
  /** The config being inspected (center node). */
  current: DependencyNode;
  /** Nodes that depend on the current config (right column). */
  downstream: DependencyNode[];
  /** Called with a node's `to` target when a downstream/upstream node is clicked. */
  onNavigate?: (to: string) => void;
  className?: string;
}

function DependencyBox({
  node,
  tone = "default",
  onNavigate,
}: {
  node: DependencyNode;
  tone?: "default" | "current";
  onNavigate?: ((to: string) => void) | undefined;
}) {
  const clickable = Boolean(node.to);
  return (
    <div
      onClick={clickable ? () => onNavigate?.(node.to!) : undefined}
      role={clickable ? "button" : undefined}
      tabIndex={clickable ? 0 : undefined}
      className={cn(
        "min-w-[150px] rounded-button border px-3 py-2.5",
        tone === "current"
          ? "border-primary/40 bg-[color-mix(in_srgb,var(--color-primary)_6%,white)]"
          : "border-border-default bg-[var(--color-surface-content)]",
        clickable && "cursor-pointer hover:border-primary/60"
      )}
    >
      <div className="text-xs font-medium">{node.label}</div>
      {node.sub && <div className="mt-0.5 text-xs text-text-muted">{node.sub}</div>}
    </div>
  );
}

function Arrow() {
  return (
    <div className="flex items-center px-1 text-text-muted" aria-hidden="true">
      <ArrowRight size={16} strokeWidth={1.5} />
    </div>
  );
}

/**
 * DependencyView — hand-laid box/arrow graph showing what triggers the
 * current config (upstream) and what depends on it (downstream).
 *
 * Not a real graph engine — flex columns, consistent with the design
 * reference. Pure render; `onNavigate` is the only callback.
 */
export function DependencyView({
  upstream,
  current,
  downstream,
  onNavigate,
  className,
}: DependencyViewProps) {
  return (
    <Card className={cn("shadow-none", className)}>
      <CardHeader className="flex-row items-center gap-2 border-b-0 pb-0">
        <GitBranch size={16} strokeWidth={1.5} className="text-text-muted" aria-hidden="true" />
        <CardTitle>Dependencies</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-2 text-xs text-text-muted">
          Upstream (triggers this) → <strong className="text-text-[var(--color-text-primary)]">this config</strong> →
          downstream (depends on this)
        </div>

        <div className="flex items-center overflow-x-auto py-3">
          <div className="flex flex-col gap-2.5">
            {upstream.map((node) => (
              <DependencyBox key={node.label} node={node} />
            ))}
          </div>
          <Arrow />
          <DependencyBox node={current} tone="current" />
          <Arrow />
          <div className="flex flex-col gap-2.5">
            {downstream.map((node) => (
              <DependencyBox key={node.label} node={node} onNavigate={onNavigate} />
            ))}
          </div>
        </div>

        <Alert tone="info" title="Circular dependency check passed">
          No circular references detected in this configuration&rsquo;s dependency chain.
        </Alert>
      </CardContent>
    </Card>
  );
}
