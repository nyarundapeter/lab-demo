import * as React from "react"
import { cn } from "../lib/cn.js"
import { VerticalStageTracker, type StageRow } from "./vertical-stage-tracker.js"

/**
 * MilestoneTracker — Wave 3 Family 3 molecule (no registry id, flat @dbp/ui
 * component). Reference: docs/03-features/specs/claude-design-briefs/
 * design-run-pack-2026-07-12/_outputs/workflow-system/wf-trackers.jsx
 * `MilestoneTracker` — progress organised around major checkpoints (target
 * date, actual date, owner, slippage risk) rather than fine-grained steps.
 * A thin semantic wrapper, not a ground-up renderer: VerticalStageTracker's
 * existing `variant="milestone"` rail (flag nodes, Target/Actual labelling,
 * risk badge + note tint — wave3-family3-tier-audit.md row 16) already
 * renders the oracle's exact anatomy; this only names the milestone-specific
 * entry point non-expandable, matching the reference (no click-to-open rows).
 */
export interface MilestoneTrackerProps {
  milestones: StageRow[]
  className?: string
}

export function MilestoneTracker({ milestones, className }: MilestoneTrackerProps) {
  return (
    <VerticalStageTracker
      stages={milestones}
      variant="milestone"
      expandable={false}
      className={cn(className)}
    />
  )
}
