import * as React from "react"
import { AlertTriangle, Check, Info, X } from "lucide-react"
import type { AiConfidenceLevel } from "@dbp/contracts"
import { AiLabel } from "./ai-label.js"
import { AiConfidence } from "./ai-confidence.js"
import { Badge } from "./badge.js"
import { Checkbox } from "./checkbox.js"
import { Button } from "./button.js"
import { FeedbackControl } from "./feedback-control.js"
import { cn } from "../lib/cn.js"

export interface AutofillPreviewField {
  field: React.ReactNode
  value: React.ReactNode
  note: React.ReactNode
  conf: AiConfidenceLevel
  /** Whether this value conflicts with the record's current value. Conflicts default unchecked. */
  conflict?: boolean
  existing?: React.ReactNode
}

export interface AutofillPreviewData {
  sourceName: React.ReactNode
  fields: AutofillPreviewField[]
}

export interface AutofillPreviewProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children" | "onClick"> {
  data: AutofillPreviewData
  /** Called with the indexes of the currently-selected fields. */
  onApply?: (selectedIndexes: number[]) => void
  onClose?: () => void
}

/**
 * Autofill preview-before-apply flow (ai-example-dashboard/ai/field.jsx:138-
 * 202). Receives resolved `data.fields` via props; local state is just the
 * per-row checkbox selection and the idle/applied step toggle — no fetch.
 */
function AutofillPreview({ data, onApply, onClose, className, ...props }: AutofillPreviewProps) {
  const [sel, setSel] = React.useState<Record<number, boolean>>(() =>
    Object.fromEntries(data.fields.map((f, i) => [i, !f.conflict])),
  )
  const [applied, setApplied] = React.useState(false)

  const chosen = Object.values(sel).filter(Boolean).length
  const conflicts = data.fields.filter((f) => f.conflict).length
  const lowConf = data.fields.filter((f) => f.conf === "low").length

  if (applied) {
    return (
      <div className={cn("rounded-[var(--radius-card)] border border-[hsl(var(--ai-border))] bg-[hsl(var(--ai-soft)/0.35)]", className)} {...props}>
        <div className="px-5 py-7 text-center">
          <div className="mb-2.5 inline-flex h-10 w-10 items-center justify-center rounded-full bg-[hsl(var(--prov-human)/0.12)]">
            <Check size={20} className="text-[hsl(var(--prov-human))]" aria-hidden="true" />
          </div>
          <div className="text-sm font-semibold text-[var(--color-text)]">{chosen} fields populated</div>
          <div className="mx-0 my-1 mb-3.5 text-xs text-[hsl(var(--muted-foreground))]">
            Each value is marked AI-suggested and can be edited. Nothing you&apos;d typed was overwritten.
          </div>
          <div className="flex items-center justify-center gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setApplied(false)}>
              Undo autofill
            </Button>
            <Button type="button" variant="orange" size="sm" onClick={onClose}>
              Done
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={cn("flex flex-col gap-3 rounded-[var(--radius-card)] border border-[hsl(var(--ai-border))] bg-[hsl(var(--ai-soft)/0.35)] p-[var(--space-card)]", className)} {...props}>
      <div className="flex items-center gap-2">
        <AiLabel kind="assisted" text="AI autofill — review before applying" />
        <Button type="button" variant="ghost" size="icon" className="ml-auto h-7 w-7" title="Close" aria-label="Close" onClick={onClose}>
          <X size={14} aria-hidden="true" />
        </Button>
      </div>

      <div className="flex items-center gap-2 text-xs text-[hsl(var(--muted-foreground))]">
        <Badge tone="ai">Source: {data.sourceName}</Badge>
        <span aria-hidden="true">·</span>
        <span>{data.fields.length} fields found</span>
        {conflicts > 0 && (
          <>
            <span aria-hidden="true">·</span>
            <span className="text-[var(--color-warning-text)]">
              {conflicts} conflict{conflicts > 1 ? "s" : ""}
            </span>
          </>
        )}
        {lowConf > 0 && (
          <>
            <span aria-hidden="true">·</span>
            <span>{lowConf} need review</span>
          </>
        )}
      </div>

      <div className="flex flex-col gap-1.5">
        {data.fields.map((f, i) => (
          <div
            key={i}
            className={cn(
              "flex items-start gap-2.5 rounded-[8px] border px-2.5 py-2.5",
              f.conflict ? "border-[var(--color-warning-border)]" : "border-[var(--color-border-default)]",
              sel[i] ? "bg-[hsl(var(--ai-soft)/0.4)]" : "bg-[var(--color-surface)]",
            )}
          >
            <Checkbox
              checked={!!sel[i]}
              onCheckedChange={(checked) => setSel((s) => ({ ...s, [i]: checked === true }))}
              aria-label={`Include ${typeof f.field === "string" ? f.field : `field ${i + 1}`}`}
              className="mt-0.5"
            />
            <div className="min-w-0 flex-1">
              <div className="mb-0.5 flex items-center gap-2">
                <span className="min-w-[92px] text-xs text-[hsl(var(--muted-foreground))]">{f.field}</span>
                <span className="text-sm font-semibold text-[hsl(var(--ai-strong))]">{f.value}</span>
                <span className="ml-auto">
                  <AiConfidence level={f.conf} inline />
                </span>
              </div>
              {/* keep: the left offset below structurally aligns this row under the
                  label column + its gap above (min-w-[92px] + gap-2), not a scale value */}
              <div className="flex items-center gap-2 pl-[100px] text-xs text-[hsl(var(--muted-foreground))]">
                <span>Source: {f.note}</span>
                {f.conflict && (
                  <span className="inline-flex items-center gap-1 text-[var(--color-warning-text)]">
                    <AlertTriangle size={11} aria-hidden="true" />
                    Conflicts with current &ldquo;{f.existing}&rdquo;
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {conflicts > 0 && (
        <div className="flex items-center gap-1.5 text-xs text-[hsl(var(--muted-foreground))]">
          <Info size={13} className="text-[var(--color-warning-text)]" aria-hidden="true" />
          Conflicting values are unchecked by default — your existing entries are never overwritten silently.
        </div>
      )}

      <div className="flex items-center gap-2 border-t border-[var(--color-border-subtle)] pt-2.5">
        <Button type="button" variant="orange" size="sm" onClick={() => { setApplied(true); onApply?.(Object.entries(sel).filter(([, v]) => v).map(([k]) => Number(k))) }}>
          <Check size={13} aria-hidden="true" />
          Apply {chosen} selected
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setSel(Object.fromEntries(data.fields.map((_, i) => [i, true])))}
        >
          Select all
        </Button>
        <Button type="button" variant="ghost" size="sm">
          Compare values
        </Button>
        <span className="ml-auto">
          <FeedbackControl compact />
        </span>
      </div>
    </div>
  )
}

export { AutofillPreview }
