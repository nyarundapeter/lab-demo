import * as React from "react"
import { ShieldAlert, Check } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Button } from "./button.js"
import { PriorityPill } from "./priority-pill.js"
import { Card } from "./card.js"
import { SectionLabel } from "./section-label.js"

/**
 * Highest-severity notification surface (NOT-14). Reference:
 * `notif-critical.jsx:5-60` (`CriticalCard`). Has had zero factory presence —
 * ledger said "promote to @dbp/ui", never built. Always answers: what's the
 * impact, who owns it, what response is required.
 *
 * Ack / mark-false-positive are logged, audit-trail actions in the reference
 * (distinct from reading/resolving). PS.NOTIF has no verb to persist an
 * acknowledgement or false-positive flag yet — this component fires
 * `onAck`/`onMarkFalsePositive` callbacks and leaves persistence to the
 * caller. Missing PS.NOTIF verb for W5b: `POST /notifications/:id/ack`
 * (and a false-positive equivalent) plus the `ack`/`resolved` states from
 * the 6-state model (audit row A11).
 */
export const CRITICAL_STATUS_STEPS = ["acknowledged", "investigating", "mitigated", "resolved"] as const
export type CriticalStatusStep = (typeof CRITICAL_STATUS_STEPS)[number]

const STATUS_LABEL: Record<CriticalStatusStep, string> = {
  acknowledged: "Acknowledged",
  investigating: "Investigating",
  mitigated: "Mitigated",
  resolved: "Resolved",
}

export interface CriticalCardField {
  label: string
  value: React.ReactNode
}

export interface CriticalCardProps {
  /** Record/scope context shown in the eyebrow, e.g. "Sync Service". */
  record: string
  title: string
  message: string
  /** Impact / detected / owner / required-response grid (order preserved). */
  fields: CriticalCardField[]
  /** Current step in the 4-step lifecycle. Uncontrolled if omitted (starts at "investigating"). */
  status?: CriticalStatusStep
  /** Called when the user clicks a lifecycle step. */
  onStatusChange?: (status: CriticalStatusStep) => void
  /** Acknowledge action — a distinct, logged action from reading (persistence is W5b). */
  onAck?: () => void
  /** Mark-false-positive action (persistence is W5b). */
  onMarkFalsePositive?: () => void
  /** Optional primary "open incident" action. */
  onOpenIncident?: () => void
  className?: string
}

export function CriticalCard({
  record,
  title,
  message,
  fields,
  status,
  onStatusChange,
  onAck,
  onMarkFalsePositive,
  onOpenIncident,
  className,
}: CriticalCardProps) {
  const [uncontrolledStatus, setUncontrolledStatus] = React.useState<CriticalStatusStep>("investigating")
  const activeStatus = status ?? uncontrolledStatus
  const activeIdx = CRITICAL_STATUS_STEPS.indexOf(activeStatus)

  function handleStepClick(step: CriticalStatusStep) {
    setUncontrolledStatus(step)
    onStatusChange?.(step)
  }

  return (
    <Card
      className={cn(
        "overflow-hidden border-[var(--color-critical-border)]",
        className,
      )}
    >
      <div
        role="alert"
        className="flex items-center gap-3 px-4 py-2.5 bg-[var(--color-critical)] text-white"
      >
        <ShieldAlert size={16} strokeWidth={1.5} aria-hidden />
        <div className="min-w-0 flex-1">
          <SectionLabel as="div" className="text-xs font-bold text-white/70">
            Critical alert &middot; {record}
          </SectionLabel>
          <div className="text-sm font-semibold leading-snug">{title}</div>
        </div>
        <PriorityPill
          priority="urgent"
          className="border-white/30 bg-white/15 text-white"
        />
      </div>

      <div className="px-4 py-3.5">
        <p className="text-sm leading-relaxed mb-3.5">{message}</p>

        <div className="grid grid-cols-[repeat(auto-fit,minmax(150px,1fr))] gap-x-5 gap-y-3 mb-4">
          {fields.map((f) => (
            <div key={f.label}>
              <SectionLabel as="div" tone="muted" className="text-xs mb-0.5">
                {f.label}
              </SectionLabel>
              <div className="text-xs font-medium">{f.value}</div>
            </div>
          ))}
        </div>

        {/* 4-step status lifecycle */}
        <div className="flex items-center mb-4" role="group" aria-label="Incident status">
          {CRITICAL_STATUS_STEPS.map((step, i) => (
            <React.Fragment key={step}>
              <button
                type="button"
                onClick={() => handleStepClick(step)}
                aria-current={i === activeIdx ? "step" : undefined}
                className="inline-flex items-center gap-1.5 bg-transparent border-0 cursor-pointer focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)] rounded"
              >
                <span
                  className={cn(
                    "inline-flex h-4 w-4 items-center justify-center rounded-full text-xs font-bold text-white",
                    i <= activeIdx ? "bg-[var(--color-critical)]" : "bg-[var(--color-border)] text-[var(--color-text-muted)]",
                  )}
                  aria-hidden
                >
                  {i < activeIdx ? <Check size={9} strokeWidth={3} /> : i + 1}
                </span>
                <span
                  className={cn(
                    "text-xs",
                    i === activeIdx ? "font-semibold" : "font-medium",
                    i <= activeIdx ? "text-[var(--color-text)]" : "text-[var(--color-text-muted)]",
                  )}
                >
                  {STATUS_LABEL[step]}
                </span>
              </button>
              {i < CRITICAL_STATUS_STEPS.length - 1 && (
                <div
                  aria-hidden
                  className={cn(
                    "flex-1 h-0.5 mx-2",
                    i < activeIdx ? "bg-[var(--color-critical)]" : "bg-[var(--color-border)]",
                  )}
                />
              )}
            </React.Fragment>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onOpenIncident && (
            <Button variant="destructive" size="sm" onClick={onOpenIncident}>
              Open incident
            </Button>
          )}
          {onAck && (
            <Button variant="outline" size="sm" onClick={onAck}>
              Acknowledge
            </Button>
          )}
          <div className="flex-1" />
          {onMarkFalsePositive && (
            <Button variant="ghost" size="sm" onClick={onMarkFalsePositive}>
              Mark false positive
            </Button>
          )}
        </div>
      </div>
    </Card>
  )
}
