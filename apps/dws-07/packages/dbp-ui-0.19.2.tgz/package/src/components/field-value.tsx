import * as React from "react"
import { Badge } from "./badge.js"
import { formatNumber, formatDate } from "../lib/format.js"
import { cn } from "../lib/cn.js"

export type FieldFormat = "text" | "number" | "date" | "badge" | undefined

export interface FieldValueProps {
  value: unknown
  format: FieldFormat
  className?: string
}

function formatFieldNumber(raw: unknown): string {
  if (raw === null || raw === undefined || raw === "") return "—"
  const n = Number(raw)
  if (isNaN(n)) return String(raw)
  return formatNumber(n)
}

function formatFieldDate(raw: unknown): string {
  if (raw === null || raw === undefined || raw === "") return "—"
  const d = new Date(String(raw))
  if (isNaN(d.getTime())) return String(raw)
  return formatDate(d, "medium")
}

/**
 * FieldValue — the shared field-value renderer, extracted from the
 * byte-identical triplicate at
 * `packages/stack/app-scaffolds/features/case-workspace/components/case-field-value.tsx`,
 * `entity-detail/components/field-value.tsx`, and
 * `workbench-surface/components/record-summary.tsx`'s inline copy
 * (design-system de-dup strategy, `docs/plans/design-system-dedup-2026-07-25/
 * strategy.md` §3, inventory-c §2). Number/date formatting delegate to this
 * package's existing `formatNumber`/`formatDate` (`lib/format.ts`, both
 * already `@dbp/ui` exports) rather than re-implementing
 * `toLocaleString`/`toLocaleDateString` a fourth time. Badge tone defaults
 * to `"gray"` — the majority (2 of 3) of the triplicate sites; the
 * `workbench-surface` copy's `"navy"` tone was the outlier.
 */
export function FieldValue({ value, format, className }: FieldValueProps) {
  if (value === null || value === undefined || value === "") {
    return <span className={cn("text-[var(--color-text-disabled)]", className)}>—</span>
  }

  switch (format) {
    case "date":
      return <span className={className}>{formatFieldDate(value)}</span>
    case "number":
      return <span className={className}>{formatFieldNumber(value)}</span>
    case "badge":
      return (
        <Badge tone="gray" className={className}>
          {String(value)}
        </Badge>
      )
    default:
      return <span className={className}>{String(value)}</span>
  }
}

export { formatDate }
