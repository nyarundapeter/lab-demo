import * as React from "react"
import { FileText, AlertTriangle, Check, Eye, type LucideIcon } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Badge } from "./badge.js"
import { Button } from "./button.js"

/**
 * EvidencePanel — Wave 3 Family 3 molecule (no registry id, flat @dbp/ui component). Reference: wf-approval.jsx
 * `EvidencePanel` — documents, linked records and submitted values backing
 * a decision, each verified or missing. Tier-audited as a Molecule, not the
 * Organism the plan guessed (wave3-family3-tier-audit.md row 21): the
 * reference is a pure `items` prop renderer with no fetch of its own. A
 * PS.DATA/PS.AUDIT-bound adapter (mirroring
 * `deriveStagesFromWorkflowInstance`) is a separate, service-dependent
 * concern left to the calling feature — no such evidence-record service
 * exists yet in this repo to adapt from.
 */
export interface EvidenceItem {
  id: string
  name: string
  /** e.g. "PDF · 2.4 MB" or "Linked record · PO-2207". */
  meta: string
  icon: LucideIcon
  verified: boolean
  onPreview?: () => void
}

export interface EvidencePanelProps {
  items: EvidenceItem[]
  className?: string
}

export function EvidencePanel({ items, className }: EvidencePanelProps) {
  const verifiedCount = items.filter((i) => i.verified).length

  return (
    <div
      className={cn("overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border-default)] bg-[var(--color-surface-content)]", className)}
      data-testid="evidence-panel"
    >
      <div className="flex items-center gap-2 border-b border-[var(--color-border-subtle)] px-3.5 py-2.5">
        <FileText size={15} className="text-[var(--color-text-muted)]" aria-hidden="true" />
        <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">Supporting evidence</h3>
        <span className="ml-auto text-xs text-[var(--color-text-muted)]">
          {verifiedCount}/{items.length} verified
        </span>
      </div>
      <div>
        {items.map((item, i) => {
          const ItemIcon = item.icon
          return (
            <div
              key={item.id}
              className={cn(
                "flex items-center gap-2.5 px-3.5 py-2.5",
                i < items.length - 1 && "border-b border-[var(--color-border-subtle)]",
              )}
              data-testid="evidence-item"
              data-verified={item.verified}
            >
              <span
                className={cn(
                  "flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-[7px]",
                  item.verified ? "bg-[var(--color-surface)]" : "bg-[var(--color-danger-surface)]",
                )}
                aria-hidden="true"
              >
                <ItemIcon size={15} className={item.verified ? "text-[var(--color-text-muted)]" : "text-[var(--color-danger)]"} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium text-[var(--color-text-primary)]">{item.name}</div>
                <div className="text-xs text-[var(--color-text-muted)]">{item.meta}</div>
              </div>
              {item.verified ? (
                <>
                  <Badge tone="success" size="sm">
                    <Check size={11} aria-hidden="true" />
                    Verified
                  </Badge>
                  {item.onPreview && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 shrink-0"
                      onClick={item.onPreview}
                      aria-label={`Preview ${item.name}`}
                      data-testid="evidence-preview-button"
                    >
                      <Eye size={13} />
                    </Button>
                  )}
                </>
              ) : (
                <Badge tone="danger" size="sm">
                  <AlertTriangle size={11} aria-hidden="true" />
                  Missing
                </Badge>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
