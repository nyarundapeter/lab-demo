import * as React from "react"
import { cn } from "../lib/cn.js"

export type MeshVariant = "heroLight" | "heroDark" | "ctaOrange"

function meshVar(variant: MeshVariant): string {
  switch (variant) {
    case "heroDark":
      return "var(--mesh-hero-dark)"
    case "ctaOrange":
      return "var(--mesh-cta-orange)"
    case "heroLight":
    default:
      return "var(--mesh-hero-light)"
  }
}

export interface MeshSectionProps {
  /** Mesh background variant. Defaults to "heroLight". */
  variant?: MeshVariant
  /** Overlay the faint hero grid (`.hero-grid`) at 40% opacity. */
  grid?: boolean
  className?: string
  children: React.ReactNode
  /** Anchor id for in-page navigation. */
  id?: string
}

/**
 * MeshSection — canonical full-bleed band with a mesh gradient background.
 * The mesh + optional grid render in absolutely-positioned `-z-10` layers so
 * children sit above them. Lifted from TMaaS MeshSection, token-aliased.
 */
export function MeshSection({
  variant = "heroLight",
  grid = false,
  className,
  children,
  id,
}: MeshSectionProps): React.ReactElement {
  return (
    <section id={id} className={cn("relative isolate overflow-hidden", className)}>
      <div aria-hidden className="absolute inset-0 -z-10" style={{ background: meshVar(variant) }} />
      {grid ? <div aria-hidden className="absolute inset-0 -z-10 hero-grid opacity-40" /> : null}
      {children}
    </section>
  )
}
