"use client"
import * as React from "react"
import { cn } from "../lib/cn.js"

export interface CodeInputProps {
  /** Number of digit boxes. @default 6 */
  length?: number
  /** Called once every box is filled, with the full code string. */
  onComplete?: (code: string) => void
  error?: boolean
  autoFocus?: boolean
  disabled?: boolean
  className?: string
}

/**
 * CodeInput — segmented OTP / verification-code input
 * (identity-core.jsx:146-177): per-digit boxes with auto-advance, backspace
 * back-navigation, arrow-key navigation and full-code paste. Owns only its
 * own digit-box UI state (like `TagsField`'s `draft`) — no verification
 * logic, `onComplete` just reports the assembled code to the caller.
 */
const CodeInput = React.forwardRef<HTMLDivElement, CodeInputProps>(
  ({ length = 6, onComplete, error, autoFocus, disabled, className }, ref) => {
    const [values, setValues] = React.useState<string[]>(() => Array(length).fill(""))
    const inputRefs = React.useRef<Array<HTMLInputElement | null>>([])

    React.useEffect(() => {
      if (autoFocus) inputRefs.current[0]?.focus()
    }, [autoFocus])

    function setDigit(index: number, raw: string) {
      const v = raw.replace(/[^0-9a-zA-Z]/g, "").slice(-1)
      const next = [...values]
      next[index] = v
      setValues(next)
      if (v && index < length - 1) inputRefs.current[index + 1]?.focus()
      if (next.every((d) => d) && onComplete) onComplete(next.join(""))
    }

    function onKeyDown(index: number, e: React.KeyboardEvent<HTMLInputElement>) {
      if (e.key === "Backspace" && !values[index] && index > 0) inputRefs.current[index - 1]?.focus()
      if (e.key === "ArrowLeft" && index > 0) inputRefs.current[index - 1]?.focus()
      if (e.key === "ArrowRight" && index < length - 1) inputRefs.current[index + 1]?.focus()
    }

    function onPaste(e: React.ClipboardEvent<HTMLDivElement>) {
      const text = (e.clipboardData.getData("text") || "").replace(/[^0-9a-zA-Z]/g, "").slice(0, length)
      if (!text) return
      e.preventDefault()
      const next = Array(length).fill("")
      text.split("").forEach((c, i) => {
        next[i] = c
      })
      setValues(next)
      inputRefs.current[Math.min(text.length, length - 1)]?.focus()
      if (text.length === length && onComplete) onComplete(text)
    }

    return (
      <div
        ref={ref}
        data-testid="code-input"
        data-err={!!error}
        className={cn("flex gap-2", className)}
        onPaste={onPaste}
      >
        {values.map((v, i) => (
          <input
            key={i}
            ref={(el) => {
              inputRefs.current[i] = el
            }}
            inputMode="numeric"
            maxLength={1}
            value={v}
            disabled={disabled}
            aria-label={`Digit ${i + 1}`}
            onChange={(e) => setDigit(i, e.target.value)}
            onKeyDown={(e) => onKeyDown(i, e)}
            className={cn(
              "h-[54px] w-[46px] rounded-[var(--radius-input)] border text-center font-mono text-lg font-semibold text-[var(--color-text-primary)]",
              "bg-[var(--color-surface-content)] transition-colors focus-visible:outline-none focus-visible:border-primary focus-visible:[box-shadow:var(--focus-ring-primary)]",
              v
                ? "border-[color-mix(in_srgb,var(--color-primary)_50%,var(--color-border-default))]"
                : "border-[var(--color-border-default)]",
              error && "border-danger",
              disabled && "cursor-not-allowed opacity-50",
            )}
          />
        ))}
      </div>
    )
  },
)
CodeInput.displayName = "CodeInput"

export { CodeInput }
