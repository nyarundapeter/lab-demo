import * as React from "react"
import { cn } from "../lib/cn"

/**
 * The 3-mode dashboard density system (design-system de-dup Wave 1.F,
 * `docs/plans/design-system-dedup-2026-07-25/strategy.md` §4 R5/R7 final
 * shape item 3). Per the oracle dashboard-system's DensityView: "same
 * components, grid, colours — only rhythm and count change".
 *
 * - `executive` — most breathing room, fewer/larger figures.
 * - `standard` — the current default rhythm (zero visual delta for existing
 *   consumers that don't opt in — no provider means `useDashboardDensity()`
 *   resolves to `"standard"`).
 * - `operational` — tightest rhythm, more figures per screen.
 *
 * Consumers (`StatTile`, `DashSection`) read `useDashboardDensity()` and
 * apply spacing/type-scale deltas via existing named Tailwind scale steps
 * only — never arbitrary values, per the standard's token-consumption rule.
 */
export type DashboardDensity = "executive" | "standard" | "operational"

const DashboardDensityContext = React.createContext<DashboardDensity>("standard")

export function useDashboardDensity(): DashboardDensity {
  return React.useContext(DashboardDensityContext)
}

export interface DashboardDensityProviderProps extends React.HTMLAttributes<HTMLDivElement> {
  density: DashboardDensity
}

/**
 * Wraps a dashboard subtree in a density context AND stamps the `data-density`
 * DOM attribute the ported `dashboard.css` `.dash[data-density]` rules key off
 * (`packages/shared/design-tokens/dashboard.css`) — so this is a drop-in
 * replacement for a bare `<div className="dash" data-density="executive">`,
 * not just an internal React mechanism. `dashboard.css` only declares
 * `executive`/`operational` rules; `standard` intentionally has no `.dash[…]`
 * CSS counterpart since it's the Card-based default used outside the
 * verbatim-port `.dash` system — only `StatTile`/`DashSection` read it via
 * the context.
 */
export function DashboardDensityProvider({
  density,
  children,
  className,
  ...props
}: DashboardDensityProviderProps) {
  return (
    <DashboardDensityContext.Provider value={density}>
      <div data-density={density} className={cn(className)} {...props}>
        {children}
      </div>
    </DashboardDensityContext.Provider>
  )
}
