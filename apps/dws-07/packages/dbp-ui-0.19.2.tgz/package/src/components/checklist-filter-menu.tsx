import * as React from "react";
import { ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuSeparator,
} from "./dropdown-menu.js";
import { Button } from "./button.js";
import { cn } from "../lib/cn.js";

export interface ChecklistFilterOption {
  value: string;
  label: string;
}

export interface ChecklistFilterMenuProps {
  triggerLabel: string;
  options: ChecklistFilterOption[];
  values: string[];
  onValuesChange: (values: string[]) => void;
  /**
   * When supplied, an Apply/Clear footer is shown ("Quick filter" reference
   * variant — changes are staged until Apply). Omit for a live-toggle menu
   * ("Column config" reference variant — changes apply immediately).
   */
  onApply?: () => void;
  align?: "start" | "end";
  className?: string;
}

/**
 * Multi-select checklist menu (overlay-popovers.jsx "Quick filter" +
 * "Column config" variants — same checkbox-list shape, different apply
 * semantics) — extends `dropdown-menu.tsx`'s `DropdownMenuCheckboxItem`.
 */
export function ChecklistFilterMenu({
  triggerLabel,
  options,
  values,
  onValuesChange,
  onApply,
  align = "start",
  className,
}: ChecklistFilterMenuProps) {
  const [open, setOpen] = React.useState(false);

  function toggle(value: string) {
    onValuesChange(values.includes(value) ? values.filter((v) => v !== value) : [...values, value]);
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-pressed={values.length > 0}
          className={cn(
            "inline-flex h-8 items-center gap-1.5 rounded-pill border border-[var(--color-border-default)] bg-[var(--color-surface-content)] px-3 text-xs font-semibold text-[var(--color-text-secondary)] hover:border-primary hover:text-[var(--color-text-primary)]",
            className,
          )}
        >
          {triggerLabel}
          {values.length > 0 && ` · ${values.length}`}
          <ChevronDown size={12} aria-hidden="true" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align={align} className="w-56" onCloseAutoFocus={(e) => e.preventDefault()}>
        {options.map((o) => (
          <DropdownMenuCheckboxItem
            key={o.value}
            checked={values.includes(o.value)}
            onCheckedChange={() => toggle(o.value)}
            onSelect={(e) => e.preventDefault()}
          >
            {o.label}
          </DropdownMenuCheckboxItem>
        ))}
        {onApply && (
          <>
            <DropdownMenuSeparator />
            <div className="flex items-center gap-2 px-1 py-1">
              <Button type="button" variant="ghost" size="sm" onClick={() => onValuesChange([])}>
                Clear
              </Button>
              <div className="flex-1" />
              <Button
                type="button"
                size="sm"
                onClick={() => {
                  onApply();
                  setOpen(false);
                }}
              >
                Apply
              </Button>
            </div>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
