import * as React from "react"
import { FieldLabel } from "./input.js"
import { cn } from "../lib/cn.js"

export interface ReadOnlyValueProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Label shown above the value, styled identically to FormField's label. */
  label?: string
  value?: React.ReactNode
  /** Helper text shown below the value. */
  helperText?: string
  /** Shown in place of `value` when it is empty/undefined/null. Defaults to "Not set". */
  emptyText?: string
  /**
   * System-value badge (e.g. "Auto") — folds the reference's `SystemValue`
   * variant into this one primitive rather than shipping a second component
   * for the same "labeled read-only row" job (record-form spec §3).
   */
  badge?: string
}

/**
 * ReadOnlyValue — the field-primitive layer's READ-mode counterpart to
 * `FormField` (Sharavi ruling 2026-07-12: the Form System field components
 * are the field rendering layer everywhere a field is displayed, editable
 * OR read-only — record forms, wizards, drawers, LVE, entity-detail rails,
 * admin forms). Matches the ingested reference's `.ro-value`/`.ro-empty`
 * pattern (forms.css) mapped to DBP tokens: no input chrome, just the
 * resolved value at the same 36px control-height rhythm as an editable field,
 * so a form can mix editable and read-only rows without a visual seam.
 */
function ReadOnlyValue({
  label,
  value,
  helperText,
  emptyText = "Not set",
  badge,
  className,
  ...rest
}: ReadOnlyValueProps) {
  const hasValue = value !== undefined && value !== null && value !== ""

  return (
    <div className={cn("flex flex-col gap-1.5", className)} {...rest}>
      {label && <FieldLabel>{label}</FieldLabel>}
      <div className="flex min-h-9 items-center gap-2 py-1 text-sm text-[var(--color-text-primary)]">
        {hasValue ? (
          <>
            <span>{value}</span>
            {badge && (
              // label-recipe: deliberate — badge-internal text-[10px] (below SectionLabel's smallest step), not a section eyebrow
              <span className="rounded-[4px] border border-[var(--color-border-default)] px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[var(--color-text-muted)]">
                {badge}
              </span>
            )}
          </>
        ) : (
          <span className="italic text-[var(--color-text-muted)]">{emptyText}</span>
        )}
      </div>
      {helperText && <p className="text-xs text-[var(--color-text-muted)]">{helperText}</p>}
    </div>
  )
}

export { ReadOnlyValue }
