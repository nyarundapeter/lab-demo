"use client"
import * as React from "react"
import * as CheckboxPrimitive from "@radix-ui/react-checkbox"
import { Check, Minus } from "lucide-react"
import { cn } from "../lib/cn.js"
import type { FieldState } from "./input.js"

/* Error/warning/success border + checked-fill + focus ring, mirroring
 * input.tsx's fieldStateBorderClasses. `data-[state=checked]` variants are
 * required because Radix's own checked-state selector has equal specificity
 * to a plain state class and would otherwise win. */
const checkboxStateClasses: Record<Exclude<FieldState, "default">, string> = {
  error:
    "border-danger data-[state=checked]:border-danger data-[state=checked]:bg-danger data-[state=indeterminate]:border-danger data-[state=indeterminate]:bg-danger focus-visible:[box-shadow:var(--focus-ring-error)]",
  warning:
    "border-warning data-[state=checked]:border-warning data-[state=checked]:bg-warning data-[state=indeterminate]:border-warning data-[state=indeterminate]:bg-warning focus-visible:[box-shadow:var(--focus-ring-warning)]",
  success:
    "border-success data-[state=checked]:border-success data-[state=checked]:bg-success data-[state=indeterminate]:border-success data-[state=indeterminate]:bg-success focus-visible:[box-shadow:var(--focus-ring-success)]",
}

export interface CheckboxProps
  extends React.ComponentPropsWithoutRef<typeof CheckboxPrimitive.Root> {
  /** Shows a minus indicator for indeterminate state */
  indeterminate?: boolean
  /** Validation state — mirrors Input/Select/Textarea's `state` prop. */
  state?: FieldState
}

const Checkbox = React.forwardRef<
  React.ElementRef<typeof CheckboxPrimitive.Root>,
  CheckboxProps
>(({ className, indeterminate, state = "default", ...props }, ref) => (
  <CheckboxPrimitive.Root
    ref={ref}
    aria-invalid={state === "error" ? "true" : undefined}
    className={cn(
      "flex h-4 w-4 shrink-0 items-center justify-center",
      "rounded-[4px] border-[1.5px]",
      "transition-colors motion-safe:transition-all",
      /* Unchecked */
      "border-[var(--color-border-default)] bg-[var(--color-surface-content)]",
      "hover:border-primary",
      /* Checked */
      "data-[state=checked]:border-primary data-[state=checked]:bg-primary",
      "data-[state=indeterminate]:border-primary data-[state=indeterminate]:bg-primary",
      /* Focus */
      "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
      /* Disabled */
      "disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50",
      state !== "default" && checkboxStateClasses[state],
      className
    )}
    {...(indeterminate ? { checked: "indeterminate" as const } : props.checked !== undefined ? { checked: props.checked } : {})}
    {...props}
  >
    <CheckboxPrimitive.Indicator className="text-white">
      {indeterminate
        ? <Minus size={10} strokeWidth={3} aria-hidden="true" />
        : <Check size={10} strokeWidth={3} aria-hidden="true" />
      }
    </CheckboxPrimitive.Indicator>
  </CheckboxPrimitive.Root>
))
Checkbox.displayName = CheckboxPrimitive.Root.displayName

export { Checkbox }
