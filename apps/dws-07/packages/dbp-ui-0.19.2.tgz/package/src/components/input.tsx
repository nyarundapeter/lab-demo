import * as React from "react"
import { cn } from "../lib/cn"
import { FieldLabel } from "./field-label.js"

export type FieldState = "default" | "error" | "warning" | "success"

export const fieldStateBorderClasses: Record<Exclude<FieldState, "default">, string> = {
  error: "border border-danger focus-visible:[box-shadow:var(--focus-ring-error)]",
  warning: "border border-warning focus-visible:[box-shadow:var(--focus-ring-warning)]",
  success: "border border-success focus-visible:[box-shadow:var(--focus-ring-success)]",
}

export const defaultFieldStateClasses =
  "border border-border-default hover:border-[var(--color-border-strong)] focus-visible:border-primary focus-visible:[box-shadow:var(--focus-ring-primary)] disabled:hover:border-border-default"

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** @deprecated use `state="error"` instead */
  error?: boolean
  /** Validation state — `error` (boolean prop) wins if both are set. */
  state?: FieldState
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, error, state, ...props }, ref) => {
    const resolvedState: FieldState = error ? "error" : (state ?? "default")
    return (
      <input
        type={type}
        className={cn(
          "flex h-[var(--form-field-h)] w-full rounded-input px-3 text-sm bg-[var(--color-surface-content)] text-[var(--color-text-primary)]",
          "placeholder:text-[var(--color-text-disabled)]",
          "transition-colors motion-safe:transition-all",
          "disabled:cursor-not-allowed disabled:opacity-50",
          "focus-visible:outline-none",
          resolvedState === "default" ? defaultFieldStateClasses : fieldStateBorderClasses[resolvedState],
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

/**
 * @deprecated Import `FieldLabel` directly from `./field-label.js` (or the
 * package barrel). Re-exported here for backward compatibility — this file
 * used to declare `FieldLabel` inline; it now lives in its own canonical
 * file per the design-system de-dup strategy (DS-R2).
 */
export { Input, FieldLabel }
