import * as React from "react"
import { cn } from "../lib/cn"

export interface MicrosoftSignInButtonProps {
  /** URL to redirect to (defaults to /api/platform/auth/authorize). */
  authorizeUrl?: string
  /** Button label. Defaults to "Sign in with Microsoft". */
  label?: string
  /** Whether the button is in a loading state. */
  loading?: boolean
  className?: string
}

/** Microsoft logo SVG per Microsoft brand guidelines. */
function MicrosoftLogo({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 21 21"
      className={className}
      aria-hidden="true"
    >
      <rect x="1" y="1" width="9" height="9" fill="rgb(242,80,34)" />
      <rect x="11" y="1" width="9" height="9" fill="rgb(127,186,0)" />
      <rect x="1" y="11" width="9" height="9" fill="rgb(0,164,239)" />
      <rect x="11" y="11" width="9" height="9" fill="rgb(255,185,0)" />
    </svg>
  )
}

/**
 * Microsoft Sign-In button following Microsoft's branding guidelines.
 * Redirects to the PS.AUTH OIDC authorize endpoint (or a custom URL).
 *
 * Used on the login page when DBP_IDP_PROVIDER=entra or entra-external.
 */
export function MicrosoftSignInButton({
  authorizeUrl = "/api/platform/auth/authorize",
  label = "Sign in with Microsoft",
  loading = false,
  className,
}: MicrosoftSignInButtonProps) {
  function handleClick() {
    window.location.href = authorizeUrl
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={loading}
      data-testid="microsoft-sign-in-button"
      className={cn(
        "flex w-full items-center justify-center gap-3 rounded px-4 py-2.5 text-sm font-semibold transition",
        "border border-[rgb(140,140,140)] bg-[var(--color-surface-content)] text-[rgb(94,94,94)] hover:bg-[rgb(243,243,243)]",
        "focus:outline-none focus-visible:ring-2 focus-visible:ring-[rgb(0,103,184)]",
        "disabled:cursor-not-allowed disabled:opacity-60",
        className,
      )}
      aria-busy={loading}
    >
      {loading ? (
        <span className="h-5 w-5 animate-spin rounded-full border-2 border-[rgb(140,140,140)] border-t-transparent" aria-hidden="true" />
      ) : (
        <MicrosoftLogo className="h-5 w-5 shrink-0" />
      )}
      <span>{loading ? "Redirecting…" : label}</span>
    </button>
  )
}
