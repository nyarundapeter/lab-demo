import * as React from "react"
import { cn } from "../lib/cn.js"
import type { FieldState } from "./input.js"

/* Error/warning/success ring color, mirroring input.tsx's
 * fieldStateBorderClasses. Applies to every option's mark in the group. */
const radioStateClasses: Record<Exclude<FieldState, "default">, string> = {
  error: "border-danger peer-focus-visible:[box-shadow:var(--focus-ring-error)]",
  warning: "border-warning peer-focus-visible:[box-shadow:var(--focus-ring-warning)]",
  success: "border-success peer-focus-visible:[box-shadow:var(--focus-ring-success)]",
}

export interface RadioGroupOption {
  value: string
  label: string
  description?: string | undefined
  disabled?: boolean | undefined
}

export interface RadioGroupProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  name: string
  value?: string | undefined
  onValueChange?: ((value: string) => void) | undefined
  options: RadioGroupOption[]
  /**
   * `list` (default) — compact rows, no border.
   * `card` — bordered choice cards with room for a per-option description
   * (record-form spec §3: "card-style choice group for ≤5 options").
   */
  variant?: "list" | "card" | undefined
  disabled?: boolean | undefined
  /** Validation state — mirrors Input/Select/Textarea's `state` prop; applies to every option. */
  state?: FieldState | undefined
}

/**
 * RadioGroup — native `<input type="radio">` + custom mark, matching the
 * ingested Form System reference's `.choice-radio`/`.choice-card` geometry
 * (forms.css) mapped to DBP tokens. Hand-rolled (no Radix dependency) since
 * no `@radix-ui/react-radio-group` is installed in this workspace and the
 * reference itself hand-rolls the same pattern — consistent with `Checkbox`'s
 * visual language (17px mark, navy "on" state) but keeps the radio's
 * ring-plus-dot treatment instead of a solid fill.
 */
const RadioGroup = React.forwardRef<HTMLDivElement, RadioGroupProps>(
  ({ name, value, onValueChange, options, variant = "list", disabled, state = "default", className, ...rest }, ref) => {
    return (
      <div
        ref={ref}
        role="radiogroup"
        aria-invalid={state === "error" ? "true" : undefined}
        className={cn("flex flex-col gap-2", className)}
        {...rest}
      >
        {options.map((option) => {
          const checked = option.value === value
          const optionDisabled = disabled || option.disabled
          return (
            <label
              key={option.value}
              data-state={checked ? "checked" : "unchecked"}
              className={cn(
                "group flex items-start gap-2.5 cursor-pointer",
                optionDisabled && "cursor-not-allowed opacity-55",
                variant === "card" && [
                  "rounded-[var(--radius-card)] border-[1.5px] p-3 transition-colors",
                  checked
                    ? "border-primary bg-[var(--color-navy-50)]"
                    : "border-[var(--color-border-default)]",
                  !checked && !optionDisabled && "hover:border-[var(--color-border-strong)]",
                ],
                variant === "list" && "py-1"
              )}
            >
              <input
                type="radio"
                name={name}
                value={option.value}
                checked={checked}
                disabled={optionDisabled}
                onChange={() => onValueChange?.(option.value)}
                className="peer sr-only"
              />
              <span
                aria-hidden="true"
                className={cn(
                  "mt-0.5 flex h-[17px] w-[17px] shrink-0 items-center justify-center",
                  "rounded-full border-[1.5px] bg-[var(--color-surface-content)] transition-colors",
                  checked ? "border-primary" : "border-[var(--color-border-default)]",
                  !checked && !optionDisabled && "group-hover:border-primary",
                  "peer-focus-visible:outline-none peer-focus-visible:[box-shadow:var(--focus-ring-navy)]",
                  state !== "default" && radioStateClasses[state]
                )}
              >
                {checked && <span className="h-2 w-2 rounded-full bg-primary" />}
              </span>
              <span className="flex min-w-0 flex-col gap-0.5">
                <span className="text-sm text-[var(--color-text-primary)]">{option.label}</span>
                {option.description && (
                  <span className="text-xs text-[var(--color-text-muted)]">{option.description}</span>
                )}
              </span>
            </label>
          )
        })}
      </div>
    )
  }
)
RadioGroup.displayName = "RadioGroup"

export { RadioGroup }
