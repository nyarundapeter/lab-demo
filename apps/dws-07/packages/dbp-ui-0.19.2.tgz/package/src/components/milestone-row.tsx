import * as React from "react"
import { Calendar } from "lucide-react"
import { cn } from "../lib/cn.js"
import { StatusDot, type StatusDotStatus } from "./status-dot.js"
import { Progress, type ProgressProps } from "./progress.js"

const STATUS_TONE: Record<StatusDotStatus, NonNullable<ProgressProps["tone"]>> = {
  good: "success",
  warn: "warning",
  bad: "danger",
  neutral: "primary",
  info: "info",
}

export interface MilestoneRowProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string
  phase?: string
  owner?: string
  date?: string
  status: StatusDotStatus
  /** Completion percentage 0–100. */
  pct?: number
  late?: boolean
}

/**
 * Milestone / project-phase progress row — phase, owner, date, a compact
 * progress bar, and a status dot; flags overdue milestones with a "Late"
 * chip (dash-components.jsx:158-174).
 */
export function MilestoneRow({
  title,
  phase,
  owner,
  date,
  status,
  pct,
  late = false,
  className,
  ...props
}: MilestoneRowProps) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 border-b border-[var(--color-border-subtle)] py-2.5 last:border-b-0",
        className,
      )}
      {...props}
    >
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-sm font-medium text-[var(--color-text)]">{title}</span>
          {late && (
            <span className="rounded-pill bg-[var(--color-danger-surface)] px-1.5 py-0.5 text-xs font-semibold text-[var(--color-danger-text)]">
              Late
            </span>
          )}
        </div>
        <div className="mt-0.5 flex gap-2.5 text-xs text-[var(--color-text-muted)]">
          {phase && <span>{phase}</span>}
          {owner && <span>{owner}</span>}
          {date && (
            <span className="inline-flex items-center gap-0.5">
              <Calendar size={10} aria-hidden="true" />
              {date}
            </span>
          )}
        </div>
      </div>

      {pct !== undefined && (
        <div className="w-[90px]">
          <Progress value={pct} showLabel tone={STATUS_TONE[status]} />
        </div>
      )}

      <StatusDot status={status} />
    </div>
  )
}
