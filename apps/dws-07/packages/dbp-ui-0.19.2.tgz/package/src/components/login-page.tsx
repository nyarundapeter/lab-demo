import * as React from "react"
import { ShieldCheck } from "lucide-react"
import { cn } from "../lib/cn"

export interface LoginFeatureItem {
  /** Lucide icon node (e.g. <ShieldCheck />). Rendered orange at the card's left. */
  icon?: React.ReactNode
  title: string
  description?: string
}

export interface LoginPageProps {
  /** Product/brand name — rendered as the left-panel headline (h1, accessible name). */
  productName: string
  /** Solution code used in the left overline ("AUTHENTICATED ACCESS · {code}"). */
  productCode?: string
  /** Optional tagline rendered below the headline in the left panel. */
  tagline?: string
  /** Logo / brand lockup element shown at the top of the left panel. */
  logo?: React.ReactNode
  /** Left-panel overline. Defaults to "AUTHENTICATED ACCESS · {productCode}". */
  leftOverline?: string
  /** Stacked translucent feature/trust cards in the left panel's lower zone. */
  features?: LoginFeatureItem[]
  /** Right-panel overline. Defaults to "STAFF ACCESS". */
  rightOverline?: string
  /** Right-panel form title (h2). */
  title?: string
  /** Right-panel form subtitle. */
  subtitle?: string
  /** Mono caption rendered under the form (e.g. "Prototype · SSO simulation"). */
  footerCaption?: string
  /** The login form content (right panel). */
  children: React.ReactNode
  className?: string
}

/**
 * LoginPage — DQ prototype split-panel.
 *
 * Left: dark mesh-gradient panel with hero-grid overlay, brand lockup, mono
 * overline, large white headline, subtitle, and stacked translucent feature
 * cards. Right: light panel with mono overline, headline, subtitle, the form
 * (SSO button slot), and a mono caption footer.
 *
 * Backward compatible — `productName` is still the left headline (h1) and
 * `title` the right heading (h2). New content is opt-in via `features`,
 * `productCode`, overlines, and `footerCaption`.
 */
export function LoginPage({
  productName,
  productCode,
  tagline,
  logo,
  leftOverline,
  features,
  rightOverline = "Staff access",
  title = "Sign in",
  subtitle,
  footerCaption,
  children,
  className,
}: LoginPageProps) {
  const computedLeftOverline =
    leftOverline ??
    (productCode ? `Authenticated access · ${productCode}` : "Authenticated access")

  return (
    <div className={cn("flex min-h-screen flex-col bg-[var(--color-surface-content)]", className)}>
      <div className="grid min-h-screen flex-1 lg:grid-cols-2">
        {/* LEFT — dark mesh panel */}
        <div
          className="relative hidden flex-col justify-between overflow-hidden p-10 text-white lg:flex xl:p-12"
          style={{ background: "var(--mesh-hero-dark)" }}
        >
          <div aria-hidden className="hero-grid absolute inset-0 opacity-30" />

          {/* top: brand lockup */}
          {logo && <div className="relative">{logo}</div>}

          {/* middle: brand copy */}
          <div className="relative">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-secondary">
              {computedLeftOverline}
            </p>
            <h1 className="mt-5 max-w-md text-4xl font-semibold leading-tight tracking-[-0.03em] text-white">
              {productName}
            </h1>
            {tagline && (
              <p className="mt-4 max-w-md text-base leading-relaxed text-white/70">
                {tagline}
              </p>
            )}
          </div>

          {/* bottom: stacked feature cards */}
          {features && features.length > 0 ? (
            <div className="relative space-y-3">
              {features.map((item, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.04] p-4"
                >
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center text-secondary">
                    {item.icon ?? <ShieldCheck size={20} strokeWidth={1.5} />}
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold">{item.title}</p>
                    {item.description && (
                      <p className="mt-0.5 text-sm text-white/60">{item.description}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : null}
        </div>

        {/* RIGHT — light form panel */}
        <div className="flex items-center justify-center bg-[var(--color-surface)] px-6 py-12 sm:px-10">
          <div className="w-full max-w-md">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-secondary">
              {rightOverline}
            </p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight text-[var(--color-text-primary)]">
              {title}
            </h2>
            {subtitle && (
              <p className="mt-2 text-sm text-[var(--color-text-muted)]">{subtitle}</p>
            )}
            <div className="mt-8">{children}</div>
            {footerCaption && (
              <p className="mt-8 text-center font-mono text-xs uppercase tracking-[0.18em] text-[var(--color-text-disabled)]">
                {footerCaption}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
