import * as React from "react"
import type { NotificationSeverity } from "@dbp/contracts"
import { cn } from "../lib/cn.js"
import { Badge } from "./badge.js"

/**
 * Stepped reminder-escalation progression (NOT-19). Reference:
 * `notif-actionable.jsx:63-93` (`EscalationTimeline`). One thread, not
 * repeated identical pings — each step must add new context (time left,
 * consequence, new owner, or changed priority; see `notif-actionable.jsx`'s
 * DoDont). Presentational only, same contract as `ActivityTimeline` — data
 * arrives via props, no fetch calls.
 *
 * The reducer verb that would drive a live "manual escalate" action (advance
 * to the next step from the UI) is still absent — workflow ledger item 14,
 * unresolved (see audit row A19 gap note). This component renders a given
 * step list; wiring "advance" to a real backend action is a follow-on.
 */
export interface EscalationStep {
  id: string
  label: string
  /** Timestamp label, e.g. "Wed 17:30". */
  time: string
  severity: NotificationSeverity
  /** Added context — what's new about this step (time left, consequence, new owner...). */
  note: string
  done?: boolean
  /** The step currently in progress. */
  current?: boolean
}

const SEV_DOT: Record<NotificationSeverity, string> = {
  info: "bg-[var(--color-info)] border-[var(--color-info)]",
  success: "bg-[var(--color-success)] border-[var(--color-success)]",
  warning: "bg-[var(--color-warning)] border-[var(--color-warning)]",
  error: "bg-[var(--color-danger)] border-[var(--color-danger)]",
  critical: "bg-[var(--color-critical)] border-[var(--color-critical)]",
}

const SEV_CONNECTOR: Record<NotificationSeverity, string> = {
  info: "bg-[var(--color-info)]",
  success: "bg-[var(--color-success)]",
  warning: "bg-[var(--color-warning)]",
  error: "bg-[var(--color-danger)]",
  critical: "bg-[var(--color-critical)]",
}

export interface EscalationTimelineProps {
  steps: EscalationStep[]
  className?: string
}

export function EscalationTimeline({ steps, className }: EscalationTimelineProps) {
  return (
    <ol className={cn("flex flex-col rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] p-5", className)}>
      {steps.map((s, i) => {
        const active = Boolean(s.done || s.current)
        return (
          <li key={s.id} className={cn("relative flex gap-3", active ? "opacity-100" : "opacity-50")}>
            <div className="flex flex-col items-center">
              <span
                className={cn(
                  "relative z-[1] flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-full border-2",
                  active ? SEV_DOT[s.severity] : "bg-[var(--color-surface-content)] border-[var(--color-border)]",
                  s.current && "ring-2 ring-offset-1",
                )}
                aria-hidden="true"
              >
                <span className="h-2 w-2 rounded-full bg-[var(--color-surface-content)]" />
              </span>
              {i < steps.length - 1 && (
                <div
                  aria-hidden="true"
                  className={cn("w-0.5 flex-1 min-h-[22px] my-0.5", s.done ? SEV_CONNECTOR[s.severity] : "bg-[var(--color-border)]")}
                />
              )}
            </div>

            <div className="min-w-0 flex-1 pb-4">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-[var(--color-text)]">{s.label}</span>
                {s.current && (
                  <Badge tone="danger" size="sm">
                    Now
                  </Badge>
                )}
                <time className="ml-auto text-xs text-[var(--color-text-muted)] font-mono">{s.time}</time>
              </div>
              <p className="mt-0.5 text-xs leading-relaxed text-[var(--color-text-muted)]">{s.note}</p>
            </div>
          </li>
        )
      })}
    </ol>
  )
}
