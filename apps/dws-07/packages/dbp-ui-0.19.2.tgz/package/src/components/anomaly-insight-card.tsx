import * as React from "react"
import { Check, FolderPlus, Clock, X, MoreHorizontal } from "lucide-react"
import type { AiConfidenceLevel } from "@dbp/contracts"
import { AiSurface, AiSurfaceFacet, CategoryTag } from "./ai-surface.js"
import { AiConfidence } from "./ai-confidence.js"
import { Badge } from "./badge.js"
import { FeedbackControl } from "./feedback-control.js"
import { ProvTag } from "./prov-tag.js"
import { SourceList } from "./source-list.js"
import type { AiSource } from "./source-row.js"
import { Button } from "./button.js"
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "./dropdown-menu.js"
import { cn } from "../lib/cn.js"

export interface AnomalyInsightCardData {
  detected: string
  title: React.ReactNode
  confidence: AiConfidenceLevel
  confidenceNote?: string
  expected: React.ReactNode
  observed: React.ReactNode
  causes: React.ReactNode
  /** Context chip — oracle “Using Error rate · EU-West”. */
  metric?: string
  sources?: AiSource[]
}

export interface AnomalyInsightCardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  data: AnomalyInsightCardData
  onConfirm?: () => void
  onMarkExpected?: () => void
  onCreateInvestigation?: () => void
  onSnooze?: () => void
  onDismiss?: () => void
}

/**
 * Expected / Observed inset tiles (oracle Stat).
 * Soft grey fill on white card — neutral inset, not an AI wash.
 * Equal min-height keeps values on a shared visual baseline.
 */
function Stat({ label, value, danger }: { label: string; value: React.ReactNode; danger?: boolean }) {
  return (
    <div className="flex min-h-14 flex-col justify-center rounded-[8px] border border-[var(--color-border-subtle)] bg-[var(--color-surface)] px-2.5 py-2">
      <div className="text-xs font-bold uppercase tracking-[0.06em] text-[var(--color-text-muted)]">
        {label}
      </div>
      <div
        className={cn(
          "mt-1 text-base font-semibold leading-none tracking-tight text-[var(--color-text)]",
          danger && "text-[var(--color-danger)]",
        )}
      >
        {value}
      </div>
    </div>
  )
}

/** Quiet secondary action — oracle IconTextBtn row under primary CTAs (single line). */
const secondaryActionClass =
  "inline-flex h-7 shrink-0 cursor-pointer items-center gap-1 rounded-[var(--radius-button)] px-1 text-xs font-medium text-[var(--color-text-muted)] transition-colors duration-150 hover:bg-[var(--color-surface)] hover:text-[var(--color-text)] focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"

/**
 * AI anomaly investigation card — expected/observed comparison, confidence,
 * possible causes, and supporting evidence (ai-example-dashboard/ai/
 * cards.jsx:165-199). Distinct from the compact `AnomalyCard` dashboard widget.
 * White fill + purple AI accents (no wash).
 */
function AnomalyInsightCard({
  data,
  onConfirm,
  onMarkExpected,
  onCreateInvestigation,
  onSnooze,
  onDismiss,
  className,
  ...props
}: AnomalyInsightCardProps) {
  const [resolved, setResolved] = React.useState<string | null>(null)
  const low = data.confidence === "low"

  const resolve = (label: string, fire?: () => void) => {
    setResolved(label)
    fire?.()
  }

  return (
    <AiSurface
      label="anomaly"
      low={low}
      meta={
        <>
          <span>Detected {data.detected}</span>
          {data.metric && (
            <>
              <span
                aria-hidden="true"
                className="inline-block size-[3px] shrink-0 rounded-full bg-[var(--color-text-muted)]/50"
              />
              <Badge tone="ai" size="sm" className="h-[22px] gap-1 rounded-[6px] px-2 font-medium">
                Using {data.metric}
              </Badge>
            </>
          )}
        </>
      }
      actions={
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button type="button" variant="ghost" size="icon" className="size-7" aria-label="More actions">
              <MoreHorizontal size={14} aria-hidden="true" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onSelect={() => onSnooze?.()}>
              <Clock size={13} aria-hidden="true" />
              Snooze
            </DropdownMenuItem>
            <DropdownMenuItem onSelect={() => resolve("Dismissed", onDismiss)}>
              <X size={13} aria-hidden="true" />
              Dismiss
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      }
      foot={
        <>
          <ProvTag provenance="calc" />
          <FeedbackControl compact className="ml-auto" />
        </>
      }
      className={cn(className)}
      {...props}
    >
      <div className="mb-2.5 flex flex-wrap items-center gap-2">
        <CategoryTag category="Anomaly" />
        <AiConfidence
          level={data.confidence}
          {...(data.confidenceNote !== undefined ? { note: data.confidenceNote } : {})}
        />
        {resolved && (
          <span className="ml-auto rounded-[var(--radius-pill)] bg-[hsl(var(--prov-human)/0.12)] px-2 py-0.5 text-xs font-medium text-[hsl(var(--prov-human))]">
            {resolved}
          </span>
        )}
      </div>

      <h3 className="m-0 mb-3 text-base font-semibold leading-[1.35] tracking-tight text-[var(--color-text)]">
        {data.title}
      </h3>

      <div className="mb-3 grid grid-cols-2 gap-2">
        <Stat label="Expected range" value={data.expected} />
        <Stat label="Observed" value={data.observed} danger={!low} />
      </div>

      <AiSurfaceFacet label="Possible causes" prov="ai">
        {data.causes}
      </AiSurfaceFacet>

      {data.sources && data.sources.length > 0 && (
        <div className="mt-2">
          <SourceList sources={data.sources} label="Supporting data" />
        </div>
      )}

      {!resolved && (
        <div className="mt-3.5 flex flex-col gap-2 border-t border-[hsl(var(--ai-border)/0.35)] pt-3">
          {/* Oracle: primary pair on one row */}
          <div className="flex flex-wrap items-center gap-2">
            <Button
              type="button"
              variant="orange"
              size="sm"
              onClick={() => resolve("Confirmed", onConfirm)}
              data-testid="anomaly-insight-confirm"
            >
              <Check size={13} aria-hidden="true" />
              Confirm anomaly
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => resolve("Marked expected", onMarkExpected)}
            >
              Mark as expected
            </Button>
          </div>
          {/* Oracle: secondary IconTextBtn row — one line, no wrap */}
          <div className="flex flex-nowrap items-center gap-0.5 overflow-x-auto">
            <Button type="button" variant="ghost" size="sm" className={secondaryActionClass} onClick={onCreateInvestigation}>
              <FolderPlus size={12} aria-hidden="true" />
              Create investigation
            </Button>
            <Button type="button" variant="ghost" size="sm" className={secondaryActionClass} onClick={onSnooze}>
              <Clock size={12} aria-hidden="true" />
              Snooze
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className={secondaryActionClass}
              onClick={() => resolve("Dismissed", onDismiss)}
            >
              <X size={12} aria-hidden="true" />
              Dismiss
            </Button>
          </div>
        </div>
      )}
    </AiSurface>
  )
}

export { AnomalyInsightCard }
