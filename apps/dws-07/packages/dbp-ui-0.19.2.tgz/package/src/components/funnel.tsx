import * as React from "react"
import { cn } from "../lib/cn.js"
import { formatNumber } from "../lib/format.js"

export interface FunnelStage {
  label: string
  value: number
  /** Bar colour. Defaults to the chart palette in rotation. */
  color?: string | undefined
}

export interface FunnelProps {
  stages: FunnelStage[]
  className?: string
}

const DEFAULT_PALETTE = [
  "var(--color-primary)",
  "var(--color-info)",
  "var(--color-success)",
  "var(--color-warning)",
]

/**
 * Adoption/activation funnel — one horizontal bar per stage, scaled to the
 * largest stage, with stage-over-stage conversion % shown alongside the
 * value. Hand-rolled per the dashboard-system chart-library ruling
 * (2026-07-16) — recharts has no native funnel primitive.
 */
export function Funnel({ stages, className }: FunnelProps) {
  const max = Math.max(...stages.map((s) => s.value)) || 1

  return (
    <div className={cn("flex flex-col gap-1.5", className)} data-testid="funnel">
      {stages.map((s, i) => {
        const pct = (s.value / max) * 100
        const prev = stages[i - 1]
        const conversionPct =
          i > 0 && prev && prev.value > 0 ? Math.round((s.value / prev.value) * 100) : null
        const color = s.color ?? DEFAULT_PALETTE[i % DEFAULT_PALETTE.length]

        return (
          <div key={s.label} data-testid={`funnel-stage-${i}`}>
            <div className="mb-0.5 flex items-center justify-between text-xs">
              <span>{s.label}</span>
              <span className="tabular-nums">
                <strong>{formatNumber(s.value)}</strong>
                {conversionPct !== null && (
                  <span className="text-[var(--color-text-muted)]"> · {conversionPct}%</span>
                )}
              </span>
            </div>
            <div className="h-[22px] overflow-hidden rounded-[5px] bg-[var(--color-border-subtle)]">
              <div
                className="h-full rounded-[5px] transition-[width] duration-300"
                style={{ width: `${pct}%`, background: color }}
              />
            </div>
          </div>
        )
      })}
    </div>
  )
}
