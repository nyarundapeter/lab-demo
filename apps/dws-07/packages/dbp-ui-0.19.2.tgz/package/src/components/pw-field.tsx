"use client"
import * as React from "react"
import { Eye, EyeOff } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Input } from "./input.js"
import type { FieldState } from "./input.js"

export interface PwFieldProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type" | "size"> {
  state?: FieldState | undefined
  "aria-invalid"?: boolean | undefined
}

/**
 * PwField — password input with a show/hide toggle
 * (identity-core.jsx:71-81). Bare control (like DateRangeField/TagsField) —
 * a consumer wraps it in `@dbp/ui` `FormField` for the label/helper/error
 * treatment. Built on the existing `Input`, so it inherits the standard
 * `FieldState` border/focus treatment.
 */
const PwField = React.forwardRef<HTMLInputElement, PwFieldProps>(
  ({ state = "default", "aria-invalid": ariaInvalid, placeholder = "••••••••", className, ...props }, ref) => {
    const [show, setShow] = React.useState(false)
    return (
      <div className="relative">
        <Input
          ref={ref}
          type={show ? "text" : "password"}
          state={state}
          aria-invalid={ariaInvalid ?? (state === "error" ? "true" : undefined)}
          placeholder={placeholder}
          className={cn("pr-10", className)}
          {...props}
        />
        <button
          type="button"
          onClick={() => setShow((s) => !s)}
          aria-label={show ? "Hide password" : "Show password"}
          title={show ? "Hide" : "Show"}
          className="absolute right-1 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-[var(--radius-input)] text-[var(--color-text-muted)] transition-colors hover:text-[var(--color-text-primary)] focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
        >
          {show ? (
            <EyeOff className="h-3.5 w-3.5" aria-hidden="true" />
          ) : (
            <Eye className="h-3.5 w-3.5" aria-hidden="true" />
          )}
        </button>
      </div>
    )
  },
)
PwField.displayName = "PwField"

export { PwField }
