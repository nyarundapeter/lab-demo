import * as React from "react"
import { ShieldAlert, AlertOctagon } from "lucide-react"
import { Button } from "./button.js"
import { InfoCard } from "./info-card.js"

/**
 * Exception card (WFL-12). Reference: wf-status.jsx:286-297 — policy
 * exceptions (a rule was deliberately overridden) vs system exceptions (an
 * unexpected engine/integration failure), composed from InfoCard
 * (tone="danger") exactly as the reference does. `ErrorCard` covers generic
 * errors only; this adds the policy/system distinction and a resolve action
 * the reference calls for.
 */
export type ExceptionVariant = "policy" | "system"

export interface ExceptionCardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant: ExceptionVariant
  title: string
  detail: string
  onResolve?: () => void
}

const VARIANT_META: Record<ExceptionVariant, { label: string; icon: typeof ShieldAlert }> = {
  policy: { label: "Policy exception", icon: ShieldAlert },
  system: { label: "System exception", icon: AlertOctagon },
}

export function ExceptionCard({
  variant,
  title,
  detail,
  onResolve,
  className,
  ...props
}: ExceptionCardProps) {
  const { label, icon: Icon } = VARIANT_META[variant]
  return (
    <InfoCard
      tone="danger"
      icon={Icon}
      title={label}
      {...(onResolve
        ? {
            actions: (
              <Button type="button" variant="outline" size="sm" onClick={onResolve} data-testid="exception-resolve-button">
                Resolve
              </Button>
            ),
          }
        : {})}
      className={className}
      data-testid="exception-card"
      data-variant={variant}
      {...props}
    >
      <p className="text-sm font-medium text-[var(--color-text)]">{title}</p>
      <p className="mt-0.5 text-xs leading-relaxed text-[var(--color-text-muted)]">{detail}</p>
    </InfoCard>
  )
}
