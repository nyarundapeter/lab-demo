import * as React from "react"
import { Users, Target, HelpCircle, Eye } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface IntentStripProps extends React.HTMLAttributes<HTMLDivElement> {
  audience: string
  decisions: string
  questions: string
  mode: string
}

const FIELDS = [
  { key: "audience", label: "Audience", icon: Users },
  { key: "decisions", label: "Decisions supported", icon: Target },
  { key: "questions", label: "Questions answered", icon: HelpCircle },
  { key: "mode", label: "Mode", icon: Eye },
] as const

/**
 * Self-documenting banner shown atop a dashboard — who it's for, what
 * decisions/questions it supports, and its display mode
 * (dash-views-1.jsx:7-16).
 */
export function IntentStrip({ audience, decisions, questions, mode, className, ...props }: IntentStripProps) {
  const values: Record<(typeof FIELDS)[number]["key"], string> = { audience, decisions, questions, mode }

  return (
    <div
      className={cn(
        "grid overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border-subtle)]",
        className,
      )}
      style={{ gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}
      {...props}
    >
      {FIELDS.map((f, i) => {
        const Icon = f.icon
        return (
          <div
            key={f.key}
            className={cn(
              "bg-[var(--color-surface)] px-3.5 py-2.5",
              i < FIELDS.length - 1 && "border-r border-[var(--color-border-subtle)]",
            )}
          >
            <div className="mb-1 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.04em] text-[var(--color-text-muted)]">
              <Icon size={11} aria-hidden="true" />
              {f.label}
            </div>
            <div className="text-xs leading-snug text-[var(--color-text)]">{values[f.key]}</div>
          </div>
        )
      })}
    </div>
  )
}
