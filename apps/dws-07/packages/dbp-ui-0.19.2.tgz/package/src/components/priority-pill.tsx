import * as React from "react"
import { ChevronDown, Minus, ChevronUp, ChevronsUp } from "lucide-react"
import type { NotificationPriority } from "@dbp/contracts"
import { Badge, type BadgeProps } from "./badge.js"

/**
 * Typed priority chip for the notification taxonomy (NOT-24). Named by
 * `notification-taxonomy.ts` as a consumer of `NotificationPrioritySchema` —
 * built to close that gap. Icon + label (never colour alone, a11y).
 */
const PRIORITY_LABEL: Record<NotificationPriority, string> = {
  low: "Low",
  normal: "Normal",
  high: "High",
  urgent: "Urgent",
}

const PRIORITY_ICON: Record<NotificationPriority, React.ComponentType<{ size?: number; strokeWidth?: number; "aria-hidden"?: boolean }>> = {
  low: ChevronDown,
  normal: Minus,
  high: ChevronUp,
  urgent: ChevronsUp,
}

const PRIORITY_TONE: Record<NotificationPriority, BadgeProps["tone"]> = {
  low: "gray",
  normal: "info",
  high: "warning",
  urgent: "danger",
}

export interface PriorityPillProps extends Omit<BadgeProps, "tone" | "children"> {
  priority: NotificationPriority
  /** Override the default label for the priority. */
  label?: string
}

export function PriorityPill({ priority, label, size, className, ...props }: PriorityPillProps) {
  const Icon = PRIORITY_ICON[priority]
  return (
    <Badge tone={PRIORITY_TONE[priority]} size={size} className={className} {...props}>
      <Icon size={size === "sm" ? 10 : 12} strokeWidth={2} aria-hidden />
      {label ?? PRIORITY_LABEL[priority]}
    </Badge>
  )
}
