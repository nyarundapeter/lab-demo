import * as React from "react"
import { cn } from "../lib/cn.js"
import { Grid, Col } from "./grid.js"

/**
 * DetailPageGrid — the 8/4 detail split, built on the canonical 12-column grid
 * (`Grid`/`Col`). Columns stack until `lg`, then split 8 / 4. The right rail
 * receives an extra `lg:pt-[3.5rem]` top offset that aligns it visually below
 * the tab bar on wide viewports, matching the prototype anatomy.
 *
 * Usage:
 *   <DetailPageGrid
 *     content={<TabsRegion />}
 *     rail={<KnowledgeDetailRail />}
 *   />
 */

export interface DetailPageGridProps {
  /** The left 8-column content region (tabs + section cards). */
  content: React.ReactNode
  /** The right 4-column sticky rail. */
  rail: React.ReactNode
  /** Additional className on the outer grid wrapper. */
  className?: string
}

function DetailPageGrid({ content, rail, className }: DetailPageGridProps) {
  return (
    <Grid className={cn("lg:items-start", className)}>
      {/* ── content: full-width until lg, then 8 cols ─────────────── */}
      <Col span={12} lg={8} className="min-w-0">{content}</Col>

      {/* ── rail: full-width until lg, then 4 cols; offset aligns below tab bar */}
      <Col span={12} lg={4} className="min-w-0">
        <div className="lg:pt-[3.5rem]">{rail}</div>
      </Col>
    </Grid>
  )
}

DetailPageGrid.displayName = "DetailPageGrid"

export { DetailPageGrid }
