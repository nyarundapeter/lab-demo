import * as React from "react";
import { cn } from "../lib/cn";
import { SectionLabel } from "./section-label";

/** A keyboard shortcut / command hint shown in the footer's command zone. */
export interface AppFooterShortcut {
  /** Key combo to render in a <kbd>, e.g. "⌘K" or "G then H". */
  keys: string;
  /** What the shortcut does, e.g. "Search" / "Home". */
  label: string;
  /** Navigation target for the shortcut (sequence / single-key shortcuts). */
  href?: string;
}

/** A footer link (legal / support). */
export interface AppFooterLink {
  label: string;
  href: string;
}

export interface AppFooterProps {
  /** Product name shown in the copyright lockup, e.g. "Digital Workspace". */
  productName?: string;
  /**
   * Full copyright string. When omitted but `productName` + `year` are present,
   * a default "© {year} {productName}" is composed.
   */
  copyright?: string;
  /** Year used for the default copyright string. */
  year?: string | number;
  /** Version / build marker shown muted on the right, e.g. "v1.4.2". */
  version?: string;
  /** Command / shortcut hints rendered as the central command zone. */
  shortcuts?: AppFooterShortcut[];
  /** Legal / support links rendered before the version marker. */
  links?: AppFooterLink[];
  /**
   * Environment marker, e.g. "Staging" / "Demo". Render a subtle badge.
   * Omit in production so no badge shows.
   */
  env?: string;
  className?: string;
}

/**
 * AppFooter — slim, full-width application status bar.
 *
 * Designed to sit at the very bottom of the SH.02 Transaction Shell (height
 * `--shell-footer-h`). Three guarded zones: copyright lockup (left),
 * command/shortcut hints (center), links + env badge + version (right). Every
 * zone renders nothing when its prop is absent — no empty styled elements.
 *
 * This is workspace chrome, not a marketing footer: keep it compact and muted.
 */
export function AppFooter({
  productName,
  copyright,
  year,
  version,
  shortcuts,
  links,
  env,
  className,
}: AppFooterProps) {
  const copyText =
    copyright ??
    (productName && year ? `© ${year} ${productName}` : productName ? productName : null);

  const hasShortcuts = Array.isArray(shortcuts) && shortcuts.length > 0;
  const hasLinks = Array.isArray(links) && links.length > 0;

  return (
    <div
      className={cn(
        "flex w-full items-center gap-4 px-[var(--shell-gutter)] text-xs text-[var(--color-text-muted)]",
        className,
      )}
      style={{ height: "var(--shell-footer-h)" }}
    >
      {/* Left — copyright lockup (hidden on mobile — too long to fit) */}
      {copyText ? <span className="hidden shrink-0 whitespace-nowrap sm:inline">{copyText}</span> : null}

      {/* Center — command / shortcut hints (hidden on mobile) */}
      {hasShortcuts ? (
        <ul className="hidden min-w-0 flex-1 items-center gap-3 overflow-hidden sm:flex" aria-label="Keyboard shortcuts">
          {shortcuts!.map((s) => (
            <li key={`${s.keys}-${s.label}`} className="flex shrink-0 items-center gap-1.5">
              <kbd className="rounded border border-[var(--color-border-subtle)] bg-[var(--color-surface)] px-1.5 py-0.5 font-mono text-xs font-medium text-[var(--color-text)]">
                {s.keys}
              </kbd>
              <span className="whitespace-nowrap">{s.label}</span>
            </li>
          ))}
        </ul>
      ) : null}

      {/* Spacer — always present so links stay right-aligned on mobile */}
      <span className="min-w-0 flex-1" aria-hidden="true" />

      {/* Right — links + env badge + version */}
      <div className="flex shrink-0 items-center gap-3">
        {hasLinks
          ? links!.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="whitespace-nowrap hover:text-[var(--color-text)] hover:underline focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
              >
                {l.label}
              </a>
            ))
          : null}
        {env ? (
          <SectionLabel
            as="span"
            tone="secondary"
            className="rounded-full border border-[var(--color-border-subtle)] px-2 py-0.5"
          >
            {env}
          </SectionLabel>
        ) : null}
        {version ? <span className="whitespace-nowrap font-mono">{version}</span> : null}
      </div>
    </div>
  );
}
