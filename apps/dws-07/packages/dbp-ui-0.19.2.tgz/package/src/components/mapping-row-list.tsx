import * as React from "react"
import { ArrowRight, Pencil, Plus } from "lucide-react"
import { cn } from "../lib/cn"
import { Button } from "./button.js"

export interface MappingRowListItem {
  /** Left-hand value (source field name, or the "from" entity of a relationship) */
  source: string
  /** Right-hand value (target field name, or the "to" entity of a relationship) */
  target: string
  /** Table variant: transform description. Connector variant: relationship type (e.g. "Many-to-one") */
  meta?: string
  /** Connector variant only: caption shown above the connector (e.g. "belongs to") */
  label?: string
  /** Connector variant only: shows a row-level edit action when provided */
  onEdit?: () => void
}

export interface MappingRowListProps {
  rows: MappingRowListItem[]
  /**
   * "table" (default) — dense table for field-to-field mappings, e.g. integration data mapping.
   * "connector" — pill-and-line row list for entity relationships.
   */
  variant?: "table" | "connector"
  sourceHeader?: string
  targetHeader?: string
  metaHeader?: string
  /** Connector variant only: shows a trailing "add row" action when provided */
  onAddRow?: () => void
  addRowLabel?: string
  className?: string
}

export function MappingRowList({
  rows,
  variant = "table",
  sourceHeader = "Source field",
  targetHeader = "Target field",
  metaHeader = "Transform",
  onAddRow,
  addRowLabel = "Add relationship",
  className,
}: MappingRowListProps) {
  if (variant === "connector") {
    return (
      <div className={cn("rounded-card border border-border-default bg-[var(--color-surface-content)]", className)}>
        {rows.map((row, i) => (
          <div
            key={i}
            className={cn(
              "flex items-center gap-3 px-3.5 py-3.5",
              i < rows.length - 1 && "border-b border-border-default"
            )}
          >
            <span className="inline-flex items-center rounded-pill bg-orange-50 px-2.5 py-1 text-xs font-semibold text-secondary">
              {row.source}
            </span>
            <div className="flex flex-1 flex-col items-center gap-0.5">
              {row.label && <span className="text-xs text-text-muted">{row.label}</span>}
              <div className="flex w-full items-center gap-1">
                <div className="h-px flex-1 bg-border-default" />
                {row.meta && (
                  <span className="whitespace-nowrap rounded-pill border border-border-default px-2 py-0.5 text-xs text-text-secondary">
                    {row.meta}
                  </span>
                )}
                <div className="h-px flex-1 bg-border-default" />
                <ArrowRight size={14} className="shrink-0 text-text-muted" />
              </div>
            </div>
            <span className="rounded-pill border border-border-default px-2.5 py-1 text-xs font-semibold text-text-secondary">
              {row.target}
            </span>
            {row.onEdit && (
              <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={row.onEdit} aria-label={`Edit ${row.source} to ${row.target}`}>
                <Pencil size={14} />
              </Button>
            )}
          </div>
        ))}
        {onAddRow && (
          <div className="p-3">
            <Button variant="outline" size="sm" onClick={onAddRow}>
              <Plus size={14} />
              {addRowLabel}
            </Button>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className={cn("overflow-x-auto rounded-card border border-border-default bg-[var(--color-surface-content)]", className)}>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border-default text-left text-xs text-text-muted">
            <th className="px-3.5 py-2.5 font-medium">{sourceHeader}</th>
            <th className="w-10" />
            <th className="px-3.5 py-2.5 font-medium">{targetHeader}</th>
            <th className="px-3.5 py-2.5 font-medium">{metaHeader}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} className={cn(i < rows.length - 1 && "border-b border-border-default")}>
              <td className="px-3.5 py-2.5 font-mono text-xs">{row.source}</td>
              <td className="px-1">
                <ArrowRight size={13} className="text-text-muted" />
              </td>
              <td className="px-3.5 py-2.5 font-mono text-xs">{row.target}</td>
              <td className="px-3.5 py-2.5 text-xs text-text-muted">{row.meta}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
