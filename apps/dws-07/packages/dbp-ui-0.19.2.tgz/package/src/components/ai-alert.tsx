import * as React from "react"
import { ChevronDown, ChevronUp, ExternalLink } from "lucide-react"
import type { AiConfidenceLevel } from "@dbp/contracts"
import { AiSurface } from "./ai-surface.js"
import { AiConfidence } from "./ai-confidence.js"
import { FeedbackControl } from "./feedback-control.js"
import { Button } from "./button.js"
import { SectionLabel } from "./section-label.js"
import { cn } from "../lib/cn.js"

export interface AiAlertData {
  title: React.ReactNode
  detected: React.ReactNode
  confidence?: AiConfidenceLevel
  confidenceNote?: string
  evidence: React.ReactNode[]
  action?: React.ReactNode
  /** Label for a link to the record/data the alert is about. */
  related?: React.ReactNode
}

export interface AiAlertProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  data: AiAlertData
  defaultExpanded?: boolean
  onAction?: () => void
  onDismiss?: () => void
  onOpenRelated?: () => void
  onFeedback?: (rating: "up" | "down", reason?: string) => void
}

/**
 * AI-generated alert — proactive predictions/anomaly notices delivered
 * through the notification channel (notif-ai.jsx:3-49 `AiAlert`). Composes
 * the shared `AiSurface` shell + `AiConfidence` + `FeedbackControl` rather
 * than hand-rolling a card: label, what was detected, evidence (collapsed by
 * default), confidence, a recommended action, and a feedback loop. AI never
 * hides mandatory alerts, downgrades severity, or resolves the notification
 * itself — it only proposes an action for the user to take.
 */
function AiAlert({
  data,
  defaultExpanded = false,
  onAction,
  onDismiss,
  onOpenRelated,
  onFeedback,
  className,
  ...props
}: AiAlertProps) {
  const [expanded, setExpanded] = React.useState(defaultExpanded)

  return (
    <AiSurface
      className={cn(className)}
      meta={
        data.confidence && (
          <AiConfidence
            level={data.confidence}
            {...(data.confidenceNote !== undefined ? { note: data.confidenceNote } : {})}
          />
        )
      }
      foot={
        <>
          {data.action && (
            <Button type="button" variant="orange" size="sm" onClick={onAction}>
              {data.action}
            </Button>
          )}
          <Button type="button" variant="ghost" size="sm" onClick={onDismiss}>
            Dismiss
          </Button>
          <span className="ml-auto" />
          <FeedbackControl
            compact
            onChange={(rating, reason) => (reason !== undefined ? onFeedback?.(rating, reason) : onFeedback?.(rating))}
          />
        </>
      }
      {...props}
    >
      <div className="text-sm font-semibold leading-snug text-[var(--color-text)]">{data.title}</div>
      <p className="text-xs leading-relaxed text-[var(--color-text-muted)]">{data.detected}</p>

      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="inline-flex w-fit items-center gap-1 text-xs font-medium text-[hsl(var(--ai-strong))] hover:underline focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)] rounded"
      >
        {expanded ? <ChevronUp size={12} aria-hidden="true" /> : <ChevronDown size={12} aria-hidden="true" />}
        {expanded ? "Hide evidence" : "Show evidence"}
      </button>

      {expanded && (
        <div className="rounded-[var(--radius-card,8px)] border border-[var(--color-border-subtle)] bg-[hsl(var(--ai-soft)/0.4)] px-3 py-2.5">
          <SectionLabel as="div" className="mb-1.5">
            Evidence
          </SectionLabel>
          <ul className="m-0 flex list-none flex-col gap-1.5 p-0">
            {data.evidence.map((e, i) => (
              <li key={i} className="flex gap-2 text-xs leading-relaxed text-[var(--color-text)]">
                <span aria-hidden className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-[hsl(var(--ai-strong))]" />
                {e}
              </li>
            ))}
          </ul>
          {data.related && (
            <button
              type="button"
              onClick={onOpenRelated}
              className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-[var(--color-primary)] hover:underline focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)] rounded"
            >
              Open supporting data
              <ExternalLink size={11} aria-hidden="true" />
              {data.related}
            </button>
          )}
        </div>
      )}
    </AiSurface>
  )
}

export { AiAlert }
