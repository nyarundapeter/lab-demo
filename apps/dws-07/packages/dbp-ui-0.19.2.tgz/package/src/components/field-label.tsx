import * as React from "react"
import { cn } from "../lib/cn.js"

/**
 * FieldLabel — THE canonical form-`<label>` primitive (design-system de-dup
 * strategy, `docs/plans/design-system-dedup-2026-07-25/strategy.md` §3,
 * ruling DS-R2). Recipe (`text-xs font-bold uppercase tracking-wide`) is
 * `input.tsx`'s pre-existing label recipe, kept verbatim — it was already
 * the de-facto standard (7 use sites route through it via `input.tsx`);
 * this extraction just gives it its own file as the canonical source.
 *
 * State coverage vs. the oracle form-system's declared field states
 * (`docs/03-features/specs/claude-design-briefs/design-run-pack-2026-07-12/
 * _outputs/form-system/forms-reference.jsx` + `forms-reference2.jsx`,
 * `FieldStatesView`): covers `required` (asterisk + sr-only suffix),
 * `optional` ("(optional)" suffix — the pattern `form-field.tsx` already
 * hand-rolled inline, now available directly on the label), `disabled`
 * (dimmed), and `error` (danger tone). `readOnly` and the `warning`/
 * `success` validation tones are control-level states (see `Input`'s
 * `state` prop and `FormField`'s message row), not label-level, so they are
 * intentionally not props here.
 */
export interface FieldLabelProps extends React.LabelHTMLAttributes<HTMLLabelElement> {
  /** Adds a visible danger-toned asterisk plus an sr-only "(required)" suffix. */
  required?: boolean
  /** Adds a muted "(optional)" suffix. Ignored when `required` is also set. */
  optional?: boolean
  /** Dims the label to match a disabled control. */
  disabled?: boolean
  /** Renders the label in the danger tone, paired with an invalid control. */
  error?: boolean
}

const FieldLabel = React.forwardRef<HTMLLabelElement, FieldLabelProps>(
  ({ className, children, required, optional, disabled, error, ...props }, ref) => {
    return (
      <label
        ref={ref}
        className={cn(
          "block text-xs font-bold uppercase tracking-wide mb-1.5",
          // `text-primary` (the recipe input.tsx carried) is an unresolved
          // utility that falls back to inherited black — swapped for the
          // text-role token at mint time (visually near-identical to black).
          error ? "text-[var(--color-danger)]" : "text-[var(--color-text-primary)]",
          disabled && "opacity-50",
          className
        )}
        {...props}
      >
        {children}
        {required && (
          <>
            <span className="ml-0.5 text-[var(--color-danger)]" aria-hidden="true">
              *
            </span>
            <span className="sr-only">(required)</span>
          </>
        )}
        {optional && !required && (
          <span className="ml-1 normal-case text-[10px] font-normal tracking-normal text-[var(--color-text-muted)]">
            (optional)
          </span>
        )}
      </label>
    )
  }
)
FieldLabel.displayName = "FieldLabel"

export { FieldLabel }
