import * as React from "react"
import { AlertTriangle } from "lucide-react"
import { cn } from "../lib/cn.js"
import { AiSurface } from "./ai-surface.js"
import { Button } from "./button.js"

export type AnomalySeverity = "crit" | "high" | "med" | "low"

export interface AnomalyCardProps extends React.HTMLAttributes<HTMLDivElement> {
  metric: string
  detail: string
  when: string
  severity?: AnomalySeverity
  onConfirm?: () => void
  onDismiss?: () => void
  onCreateAction?: () => void
}

const SEVERITY_COLOR: Record<AnomalySeverity, string> = {
  crit: "var(--color-danger)",
  high: "var(--color-danger)",
  med: "var(--color-warning)",
  low: "var(--color-text-muted)",
}

const SEVERITY_BORDER: Record<AnomalySeverity, string> = {
  crit: "border-l-[var(--color-danger)]",
  high: "border-l-[var(--color-danger)]",
  med: "border-l-[var(--color-warning)]",
  low: "border-l-[var(--color-text-muted)]",
}

/**
 * Presentational anomaly alert (dash-ai.jsx:175-198) — confirm / dismiss /
 * create-action affordances on an AI-flagged deviation. NOTE: no anomaly
 * detection model exists in the factory yet — this component renders
 * whatever anomaly a caller supplies; it does not detect anomalies itself.
 */
export function AnomalyCard({
  metric,
  detail,
  when,
  severity = "high",
  onConfirm,
  onDismiss,
  onCreateAction,
  className,
  ...props
}: AnomalyCardProps) {
  const [resolution, setResolution] = React.useState<"confirmed" | "dismissed" | "action-created" | null>(null)

  return (
    <AiSurface
      label="anomaly"
      title={
        <span
          className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.04em]"
          style={{ color: SEVERITY_COLOR[severity] }}
        >
          <AlertTriangle size={13} aria-hidden="true" />
          Anomaly detected
        </span>
      }
      meta={<span>{when}</span>}
      className={cn("border-l-4", SEVERITY_BORDER[severity], className)}
      {...props}
    >
      <div>
        <p className="text-sm font-medium text-[var(--color-text)]">{metric}</p>
        <p className="mt-0.5 text-xs leading-relaxed text-[var(--color-text-muted)]">{detail}</p>
      </div>

      {resolution ? (
        <p className="text-xs font-medium text-[var(--color-success)]">
          {resolution === "confirmed" && "Confirmed"}
          {resolution === "dismissed" && "Dismissed"}
          {resolution === "action-created" && "Action created"}
        </p>
      ) : (
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="orange"
            size="sm"
            onClick={() => {
              setResolution("confirmed")
              onConfirm?.()
            }}
          >
            Confirm
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => {
              setResolution("dismissed")
              onDismiss?.()
            }}
          >
            Dismiss
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="ml-auto"
            onClick={() => {
              setResolution("action-created")
              onCreateAction?.()
            }}
          >
            Create action
          </Button>
        </div>
      )}
    </AiSurface>
  )
}
