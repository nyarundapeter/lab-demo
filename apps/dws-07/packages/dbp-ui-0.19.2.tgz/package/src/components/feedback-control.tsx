"use client"
import * as React from "react"
import { Check, ThumbsDown, ThumbsUp } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Popover, PopoverTrigger, PopoverContent } from "./popover.js"

const REASONS = ["Incorrect", "Outdated", "Missing context", "Unsafe recommendation", "Poor source", "Other"] as const

export interface FeedbackControlProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "onChange"> {
  /** Hide the "Helpful?" leading label — icon-only. */
  compact?: boolean
  /** Called when the user rates the AI output. `reason` is set only for a "down" rating. */
  onChange?: (rating: "up" | "down", reason?: string) => void
}

/** Helpful / not-helpful feedback control with an optional reason picker. */
function FeedbackControl({ className, compact = false, onChange, ...props }: FeedbackControlProps) {
  const [rating, setRating] = React.useState<"up" | "down" | null>(null)
  const [open, setOpen] = React.useState(false)

  if (rating === "up") {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1 text-xs font-medium text-[hsl(var(--prov-human))]",
          className,
        )}
        {...props}
      >
        <Check size={12} aria-hidden="true" />
        Thanks for the feedback
      </span>
    )
  }

  const handleUp = () => {
    setRating("up")
    onChange?.("up")
  }

  const handleDown = (reason?: string) => {
    setRating("down")
    setOpen(false)
    onChange?.("down", reason)
  }

  return (
    <span className={cn("inline-flex items-center gap-1", className)} {...props}>
      {!compact && (
        <span className="mr-1 text-xs text-[hsl(var(--muted-foreground))]">Helpful?</span>
      )}
      <button
        type="button"
        aria-label="Helpful"
        onClick={handleUp}
        className="inline-flex h-6 w-6 items-center justify-center rounded text-[hsl(var(--muted-foreground))] hover:bg-[var(--color-navy-50)] hover:text-[var(--color-text-primary)]"
      >
        <ThumbsUp size={13} aria-hidden="true" />
      </button>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            aria-label="Not helpful"
            onClick={() => setOpen(true)}
            className={cn(
              "inline-flex h-6 w-6 items-center justify-center rounded hover:bg-[var(--color-navy-50)]",
              rating === "down" ? "text-[hsl(var(--destructive))]" : "text-[hsl(var(--muted-foreground))]",
            )}
          >
            <ThumbsDown size={13} aria-hidden="true" />
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-[230px] p-2.5">
          <div className="mb-2 text-xs font-semibold">What was wrong?</div>
          <div className="flex flex-col">
            {REASONS.map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => handleDown(r)}
                className="rounded px-2 py-1.5 text-left text-xs hover:bg-[var(--color-navy-50)]"
              >
                {r}
              </button>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </span>
  )
}

export { FeedbackControl }
