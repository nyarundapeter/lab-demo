import * as React from 'react'
import { Alert } from './alert.js'

export interface ErrorCardProps {
  message: string
  onRetry?: () => void
}

/**
 * @deprecated Structurally `Alert tone="danger"` — use `Alert` directly for
 * new call sites. Kept as a thin wrapper for existing consumers (design-system
 * de-dup, `docs/plans/design-system-dedup-2026-07-25/strategy.md` §3,
 * inventory-a-primitives.md §2).
 */
export function ErrorCard({ message, onRetry }: ErrorCardProps) {
  return (
    <Alert tone="danger">
      <div className="flex items-center gap-3">
        <span className="flex-1 min-w-0">{message}</span>
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="shrink-0 font-medium hover:underline focus-visible:outline-none"
          >
            Retry
          </button>
        )}
      </div>
    </Alert>
  )
}
