import * as React from "react"
import { TrendingUp, TrendingDown, CircleAlert, RefreshCw, Copy } from "lucide-react"
import { AiSurface } from "./ai-surface.js"
import { Badge } from "./badge.js"
import { FeedbackControl } from "./feedback-control.js"
import { Button } from "./button.js"
import { ProvTag } from "./prov-tag.js"
import { SectionLabel } from "./section-label.js"
import { cn } from "../lib/cn.js"

export type AiExecSummaryTone = "good" | "warn" | "bad"

export interface AiExecSummaryPoint {
  text: React.ReactNode
  tone: AiExecSummaryTone
  /** Inline citation label (e.g. "Revenue vs target") — a text link, not a numbered footnote. */
  cite?: string
}

export interface AiExecSummaryProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  period: string
  points: AiExecSummaryPoint[]
  outlook?: string
  /** Optional scope chip in the meta row (oracle “Using dashboard scope”). */
  scope?: string
  onRefresh?: () => void
  onCopy?: () => void
  onCiteOpen?: (cite: string) => void
}

const TONE_ICON: Record<
  AiExecSummaryTone,
  React.FC<{ size?: number; className?: string; style?: React.CSSProperties; "aria-hidden"?: boolean }>
> = {
  good: TrendingUp,
  warn: CircleAlert,
  bad: TrendingDown,
}
const TONE_COLOR: Record<AiExecSummaryTone, string> = {
  good: "var(--color-success)",
  warn: "var(--color-warning)",
  bad: "var(--color-danger)",
}

/**
 * AI executive brief — bulleted, cited findings plus a forecast callout
 * (dash-ai.jsx:52-77 / page-dashboard ExecSummary structure). White fill +
 * purple AI accents (no wash). Fully prop-driven; refresh/copy owned by caller.
 */
function AiExecSummary({
  period,
  points,
  outlook,
  scope,
  onRefresh,
  onCopy,
  onCiteOpen,
  className,
  ...props
}: AiExecSummaryProps) {
  return (
    <AiSurface
      label="summary"
      title="Executive summary"
      meta={
        <>
          <span>{period}</span>
          {scope && (
            <>
              <span
                aria-hidden="true"
                className="inline-block size-[3px] shrink-0 rounded-full bg-[var(--color-text-muted)]/50"
              />
              <Badge tone="ai" size="sm" className="h-[22px] gap-1 rounded-[6px] px-2 font-medium">
                {scope}
              </Badge>
            </>
          )}
        </>
      }
      actions={
        <>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="size-7"
            aria-label="Regenerate"
            onClick={onRefresh}
          >
            <RefreshCw size={14} aria-hidden="true" />
          </Button>
          <Button type="button" variant="ghost" size="icon" className="size-7" aria-label="Copy" onClick={onCopy}>
            <Copy size={14} aria-hidden="true" />
          </Button>
        </>
      }
      foot={
        <>
          <ProvTag provenance="ai" />
          <FeedbackControl compact className="ml-auto" />
        </>
      }
      className={cn(className)}
      {...props}
    >
      <ul className="m-0 flex flex-col gap-2 p-0" style={{ listStyle: "none" }}>
        {points.map((p, i) => {
          const Icon = TONE_ICON[p.tone]
          return (
            <li key={i} className="flex items-start gap-2.5 text-sm leading-snug">
              <Icon size={14} className="mt-0.5 shrink-0" style={{ color: TONE_COLOR[p.tone] }} aria-hidden={true} />
              <span className="min-w-0 flex-1">
                {p.text}{" "}
                {p.cite && (
                  <button
                    type="button"
                    onClick={() => onCiteOpen?.(p.cite!)}
                    className="text-xs font-medium text-[hsl(var(--ai-strong))] underline-offset-2 hover:underline"
                  >
                    {p.cite}
                  </button>
                )}
              </span>
            </li>
          )
        })}
      </ul>
      {outlook && (
        <div className="mt-3 flex items-start gap-2 rounded-[var(--radius-card,8px)] border border-[var(--color-border-subtle)] bg-[var(--color-surface)] p-3 text-xs">
          <SectionLabel as="span" className="mt-0.5 shrink-0">
            Forecast
          </SectionLabel>
          <span className="text-[var(--color-text)]">{outlook}</span>
        </div>
      )}
    </AiSurface>
  )
}

export { AiExecSummary }
