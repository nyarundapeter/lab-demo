"use client"
import * as React from "react"
import { Check, Pencil, X } from "lucide-react"
import { Button, type ButtonProps } from "./button.js"
import { cn } from "../lib/cn.js"
import { Popover, PopoverTrigger, PopoverContent } from "./popover.js"

const REJECT_REASONS = ["Incorrect", "Missing context", "Outdated", "Not relevant"] as const

export interface AcceptEditRejectProps extends React.HTMLAttributes<HTMLDivElement> {
  onAccept?: () => void
  onEdit?: () => void
  /** Called with the picked reason, or `undefined` for "Reject without reason". */
  onReject?: (reason?: string) => void
  acceptLabel?: string
  size?: ButtonProps["size"]
  /** Renders Accept as the primary (navy) button vs. a soft AI-accent style. */
  primary?: boolean
}

/**
 * Accept / Edit / Reject controls for AI-produced content — never icon-only
 * for high-impact actions; every control carries a text label.
 */
function AcceptEditReject({
  className,
  onAccept,
  onEdit,
  onReject,
  acceptLabel = "Accept",
  size = "sm",
  primary = true,
  ...props
}: AcceptEditRejectProps) {
  const [open, setOpen] = React.useState(false)

  const handleReject = (reason?: string) => {
    setOpen(false)
    onReject?.(reason)
  }

  return (
    <div className={cn("flex items-center gap-2", className)} {...props}>
      <Button variant={primary ? "orange" : "outline"} size={size} onClick={onAccept}>
        <Check size={14} aria-hidden="true" />
        {acceptLabel}
      </Button>
      {onEdit && (
        <Button variant="outline" size={size} onClick={onEdit}>
          <Pencil size={13} aria-hidden="true" />
          Edit
        </Button>
      )}
      {onReject && (
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="ghost" size={size} onClick={() => setOpen(true)}>
              <X size={14} aria-hidden="true" />
              Reject
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[220px] p-2.5">
            <div className="mb-2 text-xs font-semibold">Reject — reason (optional)</div>
            <div className="flex flex-col">
              {REJECT_REASONS.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => handleReject(r)}
                  className="rounded px-2 py-1.5 text-left text-xs hover:bg-[var(--color-navy-50)]"
                >
                  {r}
                </button>
              ))}
            </div>
            <div className="my-1.5 border-t border-[var(--color-border-subtle)]" />
            <button
              type="button"
              onClick={() => handleReject(undefined)}
              className="w-full rounded px-2 py-1.5 text-left text-xs text-[hsl(var(--muted-foreground))] hover:bg-[var(--color-navy-50)]"
            >
              Reject without reason
            </button>
          </PopoverContent>
        </Popover>
      )}
    </div>
  )
}

export { AcceptEditReject }
