import * as React from "react"
import { Check } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface AuthLayoutQuote {
  text: string
  attribution: string
}

export interface AuthLayoutProps {
  /** Brand lockup shown at the top of the dark value panel. */
  logo?: React.ReactNode
  /** Left-panel headline (h1). */
  headline?: string
  /** Left-panel subtitle under the headline. */
  subtitle?: string
  /** Left-panel trust/value bullets, each rendered with a check tick. */
  features?: string[]
  /** Left-panel bottom quote block. */
  quote?: AuthLayoutQuote
  /** The credential card content (right panel) — owns its own heading. */
  children: React.ReactNode
  className?: string
}

const DEFAULT_HEADLINE = "The operations platform for modern teams."
const DEFAULT_SUBTITLE =
  "Manage deals, contacts and accounts in one secure workspace your whole team can trust."

/**
 * AuthLayout — public split layout for the sign-in-adjacent page family
 * (invite accept, SSO pick, password reset, session-expired), NOT the staff
 * `LoginPage` template. Port of `identity-core.jsx`'s `AuthLayout`
 * (`.auth`/`.auth-value`/`.auth-card-wrap`): dark mesh-gradient value panel
 * (headline, subtitle, tick-mark feature list, quote) + a right panel that
 * only centers a rounded credential card — unlike `LoginPage`, the right
 * side owns no overline/title chrome of its own, because every card in this
 * family (`AcceptCard`, `SsoPick`, `ResetRequestForm`) renders its own
 * heading. Visually consistent with `LoginPage` (same `--mesh-hero-dark`
 * background token) but a lighter composition, not a wrapper around it —
 * not itself reusable beyond this page family.
 */
export function AuthLayout({
  logo,
  headline = DEFAULT_HEADLINE,
  subtitle = DEFAULT_SUBTITLE,
  features,
  quote,
  children,
  className,
}: AuthLayoutProps) {
  return (
    <div className={cn("flex min-h-screen flex-col bg-[var(--color-surface-content)] lg:flex-row", className)}>
      {/* LEFT — dark mesh value panel */}
      <div
        className="relative hidden w-full flex-col justify-between overflow-hidden p-10 text-white lg:flex lg:w-1/2 xl:p-12"
        style={{ background: "var(--mesh-hero-dark)" }}
      >
        <div aria-hidden className="hero-grid absolute inset-0 opacity-30" />

        {logo && <div className="relative">{logo}</div>}

        <div className="relative flex flex-1 flex-col justify-center py-8">
          <h1 className="max-w-md text-3xl font-semibold leading-tight tracking-[-0.03em] text-white">
            {headline}
          </h1>
          {subtitle && (
            <p className="mt-4 max-w-md text-base leading-relaxed text-white/70">{subtitle}</p>
          )}
          {features && features.length > 0 && (
            <div className="mt-8 flex flex-col gap-3">
              {features.map((feature) => (
                <div key={feature} className="flex items-center gap-3">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-white/15">
                    <Check size={12} strokeWidth={2.5} aria-hidden="true" />
                  </span>
                  <span className="text-sm text-white/90">{feature}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {quote && (
          <blockquote className="relative border-t border-white/10 pt-6 text-sm leading-relaxed text-white/70">
            &ldquo;{quote.text}&rdquo;
            <footer className="mt-2 text-xs text-white/50">{quote.attribution}</footer>
          </blockquote>
        )}
      </div>

      {/* RIGHT — centered credential card */}
      <div className="flex w-full flex-1 items-center justify-center bg-[var(--color-surface)] px-6 py-12 sm:px-10 lg:w-1/2">
        <div
          className="w-full max-w-[400px] rounded-[var(--radius-modal)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] p-8 shadow-[var(--shadow-lg)]"
          data-testid="auth-card"
        >
          {children}
        </div>
      </div>
    </div>
  )
}
