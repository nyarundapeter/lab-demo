import * as React from "react"
import type { NotificationSeverity, NotificationType } from "@dbp/contracts"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./tabs.js"
import { Badge } from "./badge.js"
import { SevChip } from "./sev-chip.js"
import { TypeTag } from "./type-tag.js"
import { Button } from "./button.js"
import { CheckCircle2 } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface NotifPopoverItem {
  id: string
  title: React.ReactNode
  message: React.ReactNode
  type: NotificationType
  /** Renders a `SevChip` next to the title — reserved for critical/urgent items. */
  severity?: NotificationSeverity
  unread?: boolean
  actionRequired?: boolean
  time: React.ReactNode
  /** Linked record label, e.g. "CS-2093". */
  record?: React.ReactNode
}

export interface NotifPopoverTab {
  id: string
  label: string
}

export interface NotifPopoverProps {
  items: NotifPopoverItem[]
  tabs?: NotifPopoverTab[]
  activeTab?: string
  defaultTab?: string
  onTabChange?: (tab: string) => void
  unreadCount?: number
  onMarkAllRead?: () => void
  onItemClick?: (item: NotifPopoverItem) => void
  onViewAll?: () => void
  emptyMessage?: React.ReactNode
  className?: string
}

const DEFAULT_TABS: NotifPopoverTab[] = [
  { id: "all", label: "All" },
  { id: "unread", label: "Unread" },
  { id: "action", label: "Action required" },
]

function filterByTab(items: NotifPopoverItem[], tab: string): NotifPopoverItem[] {
  if (tab === "unread") return items.filter((n) => n.unread)
  if (tab === "action") return items.filter((n) => n.actionRequired)
  return items
}

function PopoverRow({ item, onClick }: { item: NotifPopoverItem; onClick?: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={`${item.unread ? "Unread: " : ""}${typeof item.title === "string" ? item.title : ""}`}
      className={cn(
        "flex w-full flex-col items-start gap-1 border-t border-[var(--color-border-subtle)] px-3 py-2 text-left first:border-t-0",
        "hover:bg-[color-mix(in_srgb,var(--color-border)_35%,transparent)]",
        "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
        item.unread && "bg-[color-mix(in_srgb,var(--color-primary)_5%,transparent)]",
      )}
    >
      <div className="flex w-full items-start gap-2">
        <span
          aria-hidden
          className={cn(
            "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full",
            item.unread ? "bg-[var(--color-primary)]" : "bg-transparent",
          )}
        />
        <span
          className={cn(
            "min-w-0 flex-1 text-sm leading-snug",
            item.unread ? "font-medium text-[var(--color-text)]" : "text-[var(--color-text)] opacity-70",
          )}
        >
          {item.title}
        </span>
        {item.severity && (item.severity === "critical" || item.severity === "error") && (
          <SevChip severity={item.severity} size="sm" className="shrink-0" />
        )}
      </div>
      <p className="ml-3.5 line-clamp-2 text-xs leading-relaxed text-[var(--color-text-muted)]">{item.message}</p>
      <div className="ml-3.5 flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
        <TypeTag type={item.type} size="sm" />
        {item.record && <span className="opacity-70">{item.record}</span>}
        <span aria-hidden>·</span>
        <span>{item.time}</span>
      </div>
    </button>
  )
}

function EmptyPopover({ message }: { message?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 px-5 py-10 text-center">
      <CheckCircle2 size={22} className="text-[var(--color-success)]" aria-hidden="true" />
      <div className="text-sm font-semibold text-[var(--color-text)]">You&rsquo;re all caught up</div>
      <p className="m-0 max-w-[220px] text-xs leading-relaxed text-[var(--color-text-muted)]">
        {message ?? "New notifications will appear here."}
      </p>
    </div>
  )
}

/**
 * Tabbed triage popover — quick scan, mark read, jump to a record
 * (notif-centre.jsx:109-123 `NotifPopover`). Presentational: `items` arrive
 * fully resolved via props, tab state is local UI only. The bell's own
 * dropdown (`notification-bell` organism) hand-rolls an equivalent tabbed
 * list inline; this is the same triage shape extracted as a standalone,
 * reusable `@dbp/ui` molecule for any other popover/panel that needs it.
 */
function NotifPopover({
  items,
  tabs = DEFAULT_TABS,
  activeTab,
  defaultTab = "all",
  onTabChange,
  unreadCount,
  onMarkAllRead,
  onItemClick,
  onViewAll,
  emptyMessage,
  className,
}: NotifPopoverProps) {
  const [uncontrolledTab, setUncontrolledTab] = React.useState(defaultTab)
  const tab = activeTab ?? uncontrolledTab

  function handleTabChange(next: string) {
    setUncontrolledTab(next)
    onTabChange?.(next)
  }

  return (
    <div
      className={cn(
        "flex w-[380px] max-h-[420px] flex-col overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface-content)] shadow-[var(--shadow-md,0_12px_34px_rgba(0,0,0,0.14))]",
        className,
      )}
    >
      <div className="flex items-center gap-2 px-3 pb-1.5 pt-2.5">
        <span className="text-sm font-semibold text-[var(--color-text)]">Notifications</span>
        {Boolean(unreadCount) && (
          <Badge tone="danger" size="sm">
            {unreadCount}
          </Badge>
        )}
        <div className="ml-auto" />
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-auto px-1.5 py-0.5 text-xs"
          onClick={onMarkAllRead}
          disabled={!unreadCount}
        >
          Mark all read
        </Button>
      </div>

      <Tabs value={tab} onValueChange={handleTabChange} className="flex min-h-0 flex-col">
        <TabsList className="shrink-0 px-1">
          {tabs.map((t) => (
            <TabsTrigger key={t.id} value={t.id} className="min-h-9 px-2.5 text-xs">
              {t.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {tabs.map((t) => {
          const shown = filterByTab(items, t.id)
          return (
            <TabsContent key={t.id} value={t.id} className="max-h-[300px] overflow-y-auto">
              {shown.length === 0 ? (
                <EmptyPopover message={emptyMessage} />
              ) : (
                shown.map((item) => (
                  <PopoverRow key={item.id} item={item} onClick={() => onItemClick?.(item)} />
                ))
              )}
            </TabsContent>
          )
        })}
      </Tabs>

      <div className="border-t border-[var(--color-border-subtle)] p-1.5">
        <Button type="button" variant="ghost" size="sm" className="w-full" onClick={onViewAll}>
          View all notifications
        </Button>
      </div>
    </div>
  )
}

export { NotifPopover }
