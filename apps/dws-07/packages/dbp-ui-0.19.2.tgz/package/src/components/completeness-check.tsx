import * as React from "react"
import { AlertTriangle, CircleCheck, Info } from "lucide-react"
import { AiSurface } from "./ai-surface.js"
import { CtrlBadge } from "./ctrl-badge.js"
import { FeedbackControl } from "./feedback-control.js"
import { Button } from "./button.js"
import { cn } from "../lib/cn.js"

export interface CompletenessCheckItem {
  text: React.ReactNode
  detail?: React.ReactNode
  /** Renders a success check icon. */
  ok?: boolean
  /** Renders a warning icon (ignored when `ok` is true). */
  warn?: boolean
  /** Optional inline action label for this row. */
  action?: string
  onAction?: () => void
}

export interface CompletenessCheckProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  items: CompletenessCheckItem[]
}

/**
 * Completeness / consistency check surface — advisory only, submission is
 * never blocked (ai-example-dashboard/ai/field.jsx:119-133).
 */
function CompletenessCheck({ items, className, ...props }: CompletenessCheckProps) {
  return (
    <AiSurface
      label="generated"
      labelText="Completeness check"
      flat
      className={cn(className)}
      actions={
        <>
          <CtrlBadge level={1} />
          <FeedbackControl compact />
        </>
      }
      foot={<>Advisory — you can submit without resolving these.</>}
      {...props}
    >
      <div className="flex flex-col gap-2">
        {items.map((it, i) => {
          const Icon = it.ok ? CircleCheck : it.warn ? AlertTriangle : Info
          const iconClass = it.ok
            ? "text-[hsl(var(--prov-human))]"
            : it.warn
              ? "text-[var(--color-warning-text)]"
              : "text-[hsl(var(--muted-foreground))]"
          return (
            <div key={i} className="flex items-start gap-2 text-xs">
              <Icon size={14} className={cn("mt-px shrink-0", iconClass)} aria-hidden="true" />
              <span className="flex-1">
                {it.text}
                {it.detail && <span className="text-[hsl(var(--muted-foreground))]"> — {it.detail}</span>}
              </span>
              {it.action && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-auto p-0 text-[hsl(var(--ai-strong))]"
                  onClick={it.onAction}
                >
                  {it.action}
                </Button>
              )}
            </div>
          )
        })}
      </div>
    </AiSurface>
  )
}

export { CompletenessCheck }
