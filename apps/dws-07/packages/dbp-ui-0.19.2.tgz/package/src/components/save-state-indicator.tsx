import * as React from "react";
import { Loader2, Check, RefreshCw, XCircle } from "lucide-react";
import { cn } from "../lib/cn.js";
import { Badge } from "./badge.js";

export const SAVE_STATE = ["clean", "dirty", "saving", "saved", "autosaved", "failed"] as const;
export type SaveState = (typeof SAVE_STATE)[number];

export interface SaveStateIndicatorProps {
  state: SaveState;
  className?: string;
}

/**
 * The 6-state save-status badge (overlay-guidance.jsx `UnsavedView`) shown
 * beside an overlay's title or in its footer — one consistent vocabulary for
 * where a form stands: clean (nothing shown), dirty, saving, saved,
 * autosaved, failed.
 */
export function SaveStateIndicator({ state, className }: SaveStateIndicatorProps) {
  if (state === "clean") return null;

  if (state === "dirty") {
    return (
      <Badge tone="warning" className={className}>
        Unsaved changes
      </Badge>
    );
  }

  const noteClassName = cn(
    "inline-flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]",
    state === "failed" && "text-[var(--color-danger-text)]",
    className,
  );

  if (state === "saving") {
    return (
      <span className={noteClassName}>
        <Loader2 size={13} className="animate-spin" aria-hidden="true" />
        Saving…
      </span>
    );
  }

  if (state === "saved") {
    return (
      <span className={noteClassName}>
        <Check size={13} className="text-[var(--color-success-text)]" aria-hidden="true" />
        Saved · just now
      </span>
    );
  }

  if (state === "autosaved") {
    return (
      <span className={noteClassName}>
        <RefreshCw size={13} aria-hidden="true" />
        Draft autosaved
      </span>
    );
  }

  return (
    <span className={noteClassName}>
      <XCircle size={13} aria-hidden="true" />
      Save failed
    </span>
  );
}
