import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { badgeShellClass } from "./badge.js"
import { cn } from "../lib/cn"

/**
 * EnvPill — environment identity marker (dev/test/stage/prod).
 *
 * Deliberately NOT a Badge tone. The tone-family consolidation
 * (2026-07-17, docs/03-features/specs/tone-family-consolidation-2026-07-17.md
 * line 101) excluded `--env-*` from Badge on its own reasoning: environment
 * is a fixed 4-value identity marker (which deployment target), not a
 * status/severity gradation — folding it into Badge's tone system would
 * force an unrelated semantic onto a system built for status/severity.
 * This is the purpose-built component that ruling recommended.
 *
 * Anatomy and tokens lifted from the accepted admin-system design ref
 * (admin-primitives.jsx `EnvPill` + admin.css `.env-pill`/`.env-*`).
 *
 * Still shares Badge's shell mechanics (`badgeShellClass`) instead of
 * re-declaring inline-flex/border/font-semibold/etc a second time
 * (design-system de-dup Wave 1.A, DS-R2/R3) — only the tone system and
 * rounded-rect shape stay EnvPill-specific.
 */
const envPillVariants = cva(
  cn(badgeShellClass, "rounded tracking-wide h-6 px-2.5 text-xs"),
  {
    variants: {
      env: {
        dev:   "bg-[var(--color-env-dev-surface)] text-[var(--color-env-dev-text)] border-[var(--color-env-dev-border)]",
        test:  "bg-[var(--color-env-test-surface)] text-[var(--color-env-test-text)] border-[var(--color-env-test-border)]",
        stage: "bg-[var(--color-env-stage-surface)] text-[var(--color-env-stage-text)] border-[var(--color-env-stage-border)]",
        prod:  "bg-[var(--color-env-prod-surface)] text-[var(--color-env-prod-text)] border-[var(--color-env-prod-border)]",
      },
    },
    defaultVariants: {
      env: "dev",
    },
  }
)

const ENV_LABELS: Record<NonNullable<EnvPillProps["env"]>, { name: string; mark: string }> = {
  dev:   { name: "Development", mark: "DEV" },
  test:  { name: "Test",        mark: "TEST" },
  stage: { name: "Staging",     mark: "STG" },
  prod:  { name: "Production",  mark: "PROD" },
}

export interface EnvPillProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof envPillVariants> {
  /** Optional region label, shown after the environment mark (e.g. "eu-west-1"). */
  region?: string
}

function EnvPill({ className, env, region, ...props }: EnvPillProps) {
  const resolvedEnv = env ?? "dev"
  const { name, mark } = ENV_LABELS[resolvedEnv]
  return (
    <span className={cn(envPillVariants({ env }), className)} title={`${name} environment`} {...props}>
      <span className="text-xs font-bold">{mark}</span>
      {region && <span className="font-normal opacity-80">· {region}</span>}
    </span>
  )
}

export { EnvPill, envPillVariants }
