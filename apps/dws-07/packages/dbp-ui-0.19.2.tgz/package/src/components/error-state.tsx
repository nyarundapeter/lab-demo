import * as React from "react"
import { EmptyState } from "./empty-state.js"

export interface ErrorStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Optional custom icon (defaults to AlertTriangle in danger tone) */
  icon?: React.ReactNode
  title?: string
  description?: string
  error?: Error | string
  /** Optional CTA slot (e.g. a retry button) */
  action?: React.ReactNode
}

/**
 * @deprecated Use `EmptyState` with `tone="danger"` instead. Kept as a thin
 * backward-compatible wrapper (17+10 existing import sites) — design-system
 * de-dup strategy, `docs/plans/design-system-dedup-2026-07-25/strategy.md`
 * §3. `EmptyState`'s danger tone already reproduces this component's exact
 * behavior: `AlertTriangle` icon, danger-toned icon square + headline,
 * `role="alert"`.
 */
export function ErrorState({
  icon,
  title = "Something went wrong",
  description,
  error,
  action,
  className,
  ...props
}: ErrorStateProps) {
  const message =
    description ??
    (error instanceof Error ? error.message : typeof error === "string" ? error : undefined)

  return (
    <EmptyState
      tone="danger"
      icon={icon}
      headline={title}
      action={action}
      className={className}
      {...(message !== undefined ? { description: message } : {})}
      {...props}
    />
  )
}
