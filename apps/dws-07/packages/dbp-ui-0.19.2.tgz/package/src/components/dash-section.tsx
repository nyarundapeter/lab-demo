import * as React from "react"
import { cn } from "../lib/cn.js"
import { useDashboardDensity } from "./dashboard-density.js"

export interface DashSectionProps extends React.HTMLAttributes<HTMLElement> {
  title?: string
  sub?: string
  action?: React.ReactNode
  children?: React.ReactNode
}

// Density → spacing/type-scale deltas (Wave 1.F, same rhythm-only rule as
// StatTile — see dashboard-density.tsx).
const densityGap: Record<"executive" | "standard" | "operational", string> = {
  executive: "gap-4",
  standard: "gap-3",
  operational: "gap-2",
}
const densityTitleSize: Record<"executive" | "standard" | "operational", string> = {
  executive: "text-base",
  standard: "text-sm",
  operational: "text-xs",
}

/**
 * Named, reusable dashboard section wrapper — title, optional sub-label, a
 * trailing rule, and an optional action slot (dash-components.jsx:233-238).
 * Replaces ad hoc `<div className="flex flex-col gap-6">` sectioning in
 * generated dashboard pages. Reads `useDashboardDensity()` for its rhythm.
 */
export function DashSection({ title, sub, action, children, className, ...props }: DashSectionProps) {
  const density = useDashboardDensity()
  return (
    <section className={cn("flex flex-col", densityGap[density], className)} {...props}>
      {(title || action) && (
        <div className="flex items-center gap-3">
          {title && (
            <h2 className={cn("font-semibold text-[var(--color-text)]", densityTitleSize[density])}>{title}</h2>
          )}
          {sub && <span className="text-xs text-[var(--color-text-muted)]">{sub}</span>}
          <span className="h-px flex-1 bg-[var(--color-border-subtle)]" aria-hidden="true" />
          {action}
        </div>
      )}
      {children}
    </section>
  )
}
