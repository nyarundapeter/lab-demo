"use client"
import * as React from "react"
import { Info } from "lucide-react"
import type { AiConfidence as AiConfidenceValue, AiConfidenceLevel } from "@dbp/contracts"
import { cn } from "../lib/cn"
import { Popover, PopoverTrigger, PopoverContent } from "./popover.js"

const CONF_LABEL: Record<AiConfidenceLevel, string> = {
  high: "High confidence",
  medium: "Medium confidence",
  low: "Low confidence",
  insufficient: "Insufficient information",
}

const CONF_BARS: Record<AiConfidenceLevel, number> = {
  high: 3,
  medium: 2,
  low: 1,
  insufficient: 0,
}

const CONF_TEXT_CLASS: Record<AiConfidenceLevel, string> = {
  high: "text-[hsl(var(--prov-human))]",
  medium: "text-[hsl(38_80%_40%)]",
  low: "text-[hsl(var(--muted-foreground))]",
  insufficient: "text-[hsl(var(--muted-foreground))]",
}

function barClass(level: AiConfidenceLevel, bar: number, filled: boolean) {
  if (!filled) return "bg-[hsl(var(--border))]"
  if (level === "high") return "bg-[hsl(var(--prov-human))]"
  if (level === "medium") return "bg-[hsl(38_85%_45%)]"
  if (level === "low" && bar === 1) return "bg-[hsl(var(--muted-foreground))]"
  return "bg-[hsl(var(--border))]"
}

const BAR_HEIGHT = ["h-[6px]", "h-[9px]", "h-3"]

function ConfidenceMeter({ level }: { level: AiConfidenceLevel }) {
  const bars = CONF_BARS[level]
  return (
    <span
      aria-hidden
      className={cn("inline-flex items-end gap-0.5 h-3", level === "insufficient" && "opacity-50")}
    >
      {[1, 2, 3].map((bar) => (
        <span
          key={bar}
          className={cn("w-1 rounded-[1px]", BAR_HEIGHT[bar - 1], barClass(level, bar, bar <= bars))}
        />
      ))}
    </span>
  )
}

export interface AiConfidenceProps extends Omit<React.HTMLAttributes<HTMLElement>, "children"> {
  /** Confidence level + optional "why this confidence" note, from @dbp/contracts. */
  level: AiConfidenceLevel
  note?: AiConfidenceValue["note"]
  /** Render as plain inline text with no bar meter and no note popover. */
  inline?: boolean
}

/** Confidence indicator — bars + label, with an optional "why this confidence" popover. */
function AiConfidence({ className, level, note, inline = false, ...props }: AiConfidenceProps) {
  const label = CONF_LABEL[level]
  const textClass = CONF_TEXT_CLASS[level]

  if (inline) {
    return (
      <span
        className={cn("inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap", textClass, className)}
        aria-label={label}
        {...props}
      >
        {level !== "insufficient" && <ConfidenceMeter level={level} />}
        {label}
      </span>
    )
  }

  const content = (
    <span
      className={cn("inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap", textClass, className)}
      {...props}
    >
      {level !== "insufficient" && <ConfidenceMeter level={level} />}
      {label}
      {note && <Info size={12} className="shrink-0" />}
    </span>
  )

  if (!note) return content

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="rounded border-0 bg-transparent p-0 font-inherit cursor-pointer focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
        >
          {content}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[260px] p-2.5">
        <div className="mb-1.5 text-xs font-bold uppercase tracking-[0.4px] text-[hsl(var(--muted-foreground))]">
          Why this confidence
        </div>
        <div className="text-xs leading-[1.55]">{note}</div>
      </PopoverContent>
    </Popover>
  )
}

export { AiConfidence, CONF_LABEL }
