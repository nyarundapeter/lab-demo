import * as React from "react"
import {
  TrendingUp,
  AlertCircle,
  AlertTriangle,
  Lightbulb,
  Target,
  Database,
  Flag,
  Activity,
  type LucideProps,
} from "lucide-react"
import type { AiProvenance } from "@dbp/contracts"
import { cn } from "../lib/cn.js"
import { AiLabel, type AiLabelKind } from "./ai-label.js"
import { ProvTag } from "./prov-tag.js"
import { Card } from "./card.js"
import { SectionLabel } from "./section-label.js"

// ─── AiSurface — shared card wrapper for every AI-generated card ──────────────

export interface AiSurfaceProps {
  /** AILabel vocabulary entry for the card's provenance banner. Defaults to "generated". */
  label?: AiLabelKind
  /** Override AILabel's default text. */
  labelText?: string
  title?: React.ReactNode
  meta?: React.ReactNode
  actions?: React.ReactNode
  children: React.ReactNode
  foot?: React.ReactNode
  /** Compact density — smaller gaps/padding. */
  low?: boolean
  /** No border/shadow/background — bare content, used when nested inside another surface. */
  flat?: boolean
  /** Streaming/in-progress state — pulses the AI-tinted border. */
  live?: boolean
  className?: string
}

/**
 * Shared card wrapper for every AI-generated surface (ai-example-dashboard/
 * ai/cards.jsx:8-21 + ai.css `.ai-surface`) — header (AILabel + optional title +
 * actions), body (optional meta row + children), optional footer.
 *
 * Craft rules (Sharavi / handoff):
 * - Oracle **structure**: head / body / foot bands + 3px left accent rail
 * - White content fill (`--color-surface-content`) — never a purple wash
 * - Purple as AI signal: soft outer border + left rail + `AiLabel` (not every divider at full strength)
 */
function AiSurface({
  label = "generated",
  labelText,
  title,
  meta,
  actions,
  children,
  foot,
  low = false,
  flat = false,
  live = false,
  className,
}: AiSurfaceProps) {
  // --ai-surface-pad-l clears the 3px rail (oracle body/head pad: 12px + rail offset).
  const headPad = low ? "px-3 py-2 pl-[var(--ai-surface-pad-l)]" : "px-3 py-2.5 pl-[var(--ai-surface-pad-l)]"
  const bodyPad = low ? "px-3 py-2.5 pl-[var(--ai-surface-pad-l)]" : "px-3 py-3 pl-[var(--ai-surface-pad-l)]"
  const footPad = low ? "px-3 py-2 pl-[var(--ai-surface-pad-l)]" : "px-3 py-2.5 pl-[var(--ai-surface-pad-l)]"
  // Oracle uses `hsl(var(--ai-border) / 0.6)` for band rules — soft cohesion, not a second purple frame.
  const bandRule = "border-[hsl(var(--ai-border)/0.45)]"

  return (
    <Card
      density="compact"
      className={cn(
        "relative flex flex-col overflow-hidden rounded-[var(--radius-card)] p-0 gap-0",
        flat
          ? "border-0 bg-transparent shadow-none"
          : "border bg-[var(--color-surface-content)] shadow-[var(--shadow-sm)]",
        // Soft purple frame (oracle's border is pastel, not neon) — full strength only when live.
        !flat &&
          (live
            ? "border-[hsl(var(--ai-strong))] shadow-[0_0_0_1px_hsl(var(--ai-strong)/0.12)]"
            : "border-[hsl(var(--ai-border)/0.55)]"),
        className,
      )}
    >
      {/* Oracle `.ai-surface::before` — left accent rail (accent, not wash). */}
      {!flat && (
        <span
          aria-hidden="true"
          className={cn(
            "pointer-events-none absolute inset-y-0 left-0 w-[3px]",
            low ? "bg-[var(--color-text-muted)]" : "bg-[hsl(var(--ai))]",
          )}
        />
      )}

      <div
        className={cn(
          "flex min-h-9 items-center gap-2",
          headPad,
          !flat && cn("border-b", bandRule),
        )}
      >
        <AiLabel kind={label} {...(labelText !== undefined ? { text: labelText } : {})} />
        {title && (
          <span className="min-w-0 flex-1 truncate text-sm font-semibold tracking-tight text-[var(--color-text)]">
            {title}
          </span>
        )}
        {actions && (
          <div className="ml-auto flex shrink-0 items-center gap-0.5 text-[var(--color-text-muted)]">
            {actions}
          </div>
        )}
      </div>

      <div className={cn("flex flex-col gap-3", bodyPad)}>
        {meta && (
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1.5 text-xs leading-none text-[var(--color-text-muted)]">
            {meta}
          </div>
        )}
        {children}
      </div>

      {foot && (
        <div
          className={cn(
            "flex flex-wrap items-center gap-1.5 text-xs text-[var(--color-text-muted)]",
            footPad,
            !flat && cn("border-t", bandRule),
          )}
        >
          {foot}
        </div>
      )}
    </Card>
  )
}

// ─── AiSurfaceFacet — labeled section within an AiSurface body ────────────────

export interface AiSurfaceFacetProps {
  icon?: React.FC<LucideProps>
  label: string
  /** Provenance tag rendered flush-right of the label. */
  prov?: AiProvenance
  /** Override the icon/label color (any valid CSS color). */
  tone?: string
  children: React.ReactNode
  className?: string
}

/** Labeled section heading inside an AiSurface body (cards.jsx:29-38). */
function AiSurfaceFacet({ icon: Icon, label, prov, tone, children, className }: AiSurfaceFacetProps) {
  // Oracle colours both icon + eyebrow when `tone` is set (e.g. Risks → warning).
  const accent = tone ?? "var(--color-text-muted)"

  return (
    <div className={cn("mb-3 space-y-1.5 last:mb-0", className)}>
      <div className="flex items-center gap-1.5">
        {Icon && (
          <Icon size={13} strokeWidth={2} aria-hidden="true" style={{ color: accent }} />
        )}
        <SectionLabel
          as="span"
          size="2xs"
          className="whitespace-nowrap font-bold tracking-[0.06em]"
          style={{ color: accent }}
        >
          {label}
        </SectionLabel>
        {prov && (
          <span className="ml-auto shrink-0">
            <ProvTag provenance={prov} />
          </span>
        )}
      </div>
      <div className="text-sm leading-relaxed text-[var(--color-text)]">{children}</div>
    </div>
  )
}

// ─── CategoryTag — AI insight category badge ───────────────────────────────────

export type InsightCategory =
  | "Trend"
  | "Anomaly"
  | "Risk"
  | "Opportunity"
  | "Root cause"
  | "Forecast"
  | "Data quality"
  | "Exception"
  | "Driver"

interface InsightCategoryToken {
  color: string
  icon: React.FC<LucideProps>
}

/**
 * AI insight category vocabulary (cards.jsx:105-115). Reuses the AI-governance
 * provenance tokens (--prov-calc/--prov-human/--prov-predict/--ai, base.css)
 * plus the shared --color-warning/--color-danger role tokens — no new tokens.
 */
const INSIGHT_CATEGORY: Record<InsightCategory, InsightCategoryToken> = {
  Trend: { color: "hsl(var(--prov-calc))", icon: TrendingUp },
  Anomaly: { color: "var(--color-warning)", icon: AlertCircle },
  Risk: { color: "var(--color-danger)", icon: AlertTriangle },
  Opportunity: { color: "hsl(var(--prov-human))", icon: Lightbulb },
  "Root cause": { color: "hsl(var(--ai))", icon: Target },
  Forecast: { color: "hsl(var(--prov-predict))", icon: TrendingUp },
  "Data quality": { color: "var(--color-warning)", icon: Database },
  Exception: { color: "var(--color-danger)", icon: Flag },
  Driver: { color: "hsl(var(--prov-calc))", icon: Activity },
}

export interface CategoryTagProps extends React.HTMLAttributes<HTMLSpanElement> {
  category: InsightCategory
}

/** Tinted badge naming an AI insight's category — icon + label. */
function CategoryTag({ category, className, style, ...props }: CategoryTagProps) {
  const token = INSIGHT_CATEGORY[category] ?? INSIGHT_CATEGORY.Trend
  const Icon = token.icon

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-pill px-2 py-0.5 text-xs font-medium whitespace-nowrap",
        className,
      )}
      style={{
        background: `color-mix(in srgb, ${token.color} 12%, transparent)`,
        color: token.color,
        ...style,
      }}
      {...props}
    >
      <Icon size={11} strokeWidth={2} aria-hidden="true" />
      {category}
    </span>
  )
}

export { AiSurface, AiSurfaceFacet, CategoryTag, INSIGHT_CATEGORY }
