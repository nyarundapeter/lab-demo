import * as React from "react"
import { Inbox, Users, UserX } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Avatar, AvatarStack } from "./avatar.js"
import { Button } from "./button.js"
import { Badge } from "./badge.js"
import { Card } from "./card.js"

/**
 * Assignee card (WFL-08). Reference: wf-status.jsx:146-194 — 6 declared
 * variants (individual/team/unassigned/queue/delegation/multiple) with a
 * workload hint and a reassign action. No factory component covered this;
 * approvals/tasks previously showed a plain assignee roles string (see
 * approval-surface's "assignee-roles" testid and WorkflowStatusSummary's
 * ownerLabel field, both left untouched).
 */
export type AssigneeKind = "individual" | "team" | "unassigned" | "queue" | "delegation" | "multiple"

export interface AssigneeCardProps extends React.HTMLAttributes<HTMLDivElement> {
  kind: AssigneeKind
  /** Display name — person/team/queue name. Ignored for "unassigned" and "multiple". */
  name?: string
  /**
   * Secondary text — role/title for individuals, member count for teams,
   * wait-count for queues, delegation provenance for "delegation" (e.g.
   * "Delegated by Nadia Ahmadi · until Jul 20"), co-owner count for "multiple"
   * (e.g. "3 co-owners").
   */
  subtitle?: string
  /** Workload hint, e.g. "6 open items" or "82% capacity". */
  workload?: string
  /** Co-owners rendered as a stacked avatar cluster. Only used when kind is "multiple". */
  coOwners?: { name: string }[]
  onReassign?: () => void
}

export function AssigneeCard({
  kind,
  name,
  subtitle,
  workload,
  coOwners,
  onReassign,
  className,
  ...props
}: AssigneeCardProps) {
  return (
    <Card
      className={cn(
        "flex items-center gap-3 px-3.5 py-3",
        className,
      )}
      data-testid="assignee-card"
      data-kind={kind}
      {...props}
    >
      {kind === "unassigned" ? (
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-dashed border-[var(--color-border-strong)] text-[var(--color-text-muted)]"
          aria-hidden
        >
          <UserX size={16} strokeWidth={1.5} />
        </span>
      ) : kind === "team" ? (
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--color-navy-200)] text-[var(--color-text-primary)]"
          aria-hidden
        >
          <Users size={16} strokeWidth={1.5} />
        </span>
      ) : kind === "queue" ? (
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-card)] bg-[var(--color-surface)] text-[var(--color-text-muted)]"
          aria-hidden
        >
          <Inbox size={16} strokeWidth={1.5} />
        </span>
      ) : kind === "multiple" ? (
        <AvatarStack items={coOwners ?? []} max={3} size="sm" />
      ) : (
        <Avatar name={name ?? "?"} size="md" />
      )}

      <div className="min-w-0 flex-1">
        {kind === "unassigned" ? (
          <p className="text-sm font-medium text-[var(--color-text-muted)]">Unassigned</p>
        ) : kind === "multiple" ? (
          subtitle && <p className="truncate text-xs text-[var(--color-text-muted)]">{subtitle}</p>
        ) : (
          <>
            <p className="truncate text-sm font-semibold text-[var(--color-text-primary)]">{name}</p>
            {subtitle && (
              <p className="truncate text-xs text-[var(--color-text-muted)]">{subtitle}</p>
            )}
          </>
        )}
        {workload && kind !== "unassigned" && kind !== "multiple" && (
          <Badge tone="gray" size="sm" className="mt-1">
            {workload}
          </Badge>
        )}
      </div>

      {onReassign && (
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="shrink-0"
          onClick={onReassign}
          data-testid="assignee-reassign-button"
        >
          {kind === "unassigned" ? "Assign" : "Reassign"}
        </Button>
      )}
    </Card>
  )
}
