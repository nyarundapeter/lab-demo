import * as React from "react"
import type { LucideProps } from "lucide-react"
import { Badge } from "./badge.js"
import { StatusDot, type StatusDotStatus } from "./status-dot.js"
import { cn } from "../lib/cn.js"

/**
 * Search result row anatomy — port of search-system/search-core.jsx's
 * Highlight/TypePill/StatusChip/MetaLine. Generic (no hardcoded entity-type
 * or status vocabulary) so any `@dbp/organisms` consumer — not just the
 * search-results organism — can compose a scannable "record row" out of
 * these four pieces.
 */

/* ─── Highlight ────────────────────────────────────────────────────────── */

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}

export interface HighlightProps {
  text: string
  /** Query term(s) to mark within `text`. Empty/blank terms are ignored. */
  terms: string | string[]
  /** Index (within this text's own matches) to render as the "current" match. */
  currentIndex?: number
  className?: string
}

/** Marks every occurrence of `terms` inside `text`, emphasising `currentIndex`. */
export function Highlight({ text, terms, currentIndex = -1, className }: HighlightProps) {
  const list = (Array.isArray(terms) ? terms : [terms]).map((t) => t.trim()).filter(Boolean)
  if (list.length === 0 || !text) return <>{text}</>

  const re = new RegExp(`(${list.map(escapeRegExp).join("|")})`, "ig")
  const parts = text.split(re)
  let hitIndex = -1

  return (
    <span className={className}>
      {parts.map((part, i) => {
        if (i % 2 === 1) {
          hitIndex++
          const isCurrent = hitIndex === currentIndex
          return (
            <mark
              key={i}
              className={cn(
                "rounded-[2px] bg-[var(--color-warning-surface)] text-[var(--color-text-primary)] px-0.5",
                isCurrent && "bg-primary text-white",
              )}
            >
              {part}
            </mark>
          )
        }
        return <React.Fragment key={i}>{part}</React.Fragment>
      })}
    </span>
  )
}

/* ─── TypePill ─────────────────────────────────────────────────────────── */

export interface TypePillProps {
  /** Lucide icon component identifying the record type. */
  icon: React.ComponentType<LucideProps>
  label: string
  className?: string
}

/** Small icon + label pill identifying a result's record type. Wraps `Badge`. */
export function TypePill({ icon: Icon, label, className }: TypePillProps) {
  return (
    <Badge tone="gray" size="sm" className={className}>
      <Icon size={11} strokeWidth={2} aria-hidden="true" />
      {label}
    </Badge>
  )
}

/* ─── StatusChip ───────────────────────────────────────────────────────── */

export interface StatusChipProps {
  status: StatusDotStatus
  /** Override the default label text for the status. */
  label?: string
  className?: string
}

/** Inline status indicator for a result row's meta line. Wraps `StatusDot`. */
export function StatusChip({ status, label, className }: StatusChipProps) {
  return (
    <StatusDot status={status} className={cn("text-xs", className)}>
      {label}
    </StatusDot>
  )
}

/* ─── MetaLine ─────────────────────────────────────────────────────────── */

export interface MetaLineItem {
  icon?: React.ComponentType<LucideProps>
  label: React.ReactNode
  mono?: boolean
}

export interface MetaLineProps {
  items: MetaLineItem[]
  className?: string
}

/**
 * Secondary detail line under a result row's title — owner, status, value,
 * recency, record id: whatever the caller has, joined by "·" separators.
 * Deliberately generic (an `items` list, not fixed owner/status/amount
 * fields) since PS.SEARCH's `SearchHit` only guarantees id/entityType/
 * title/score/highlights — callers with richer per-record data can still
 * feed MetaLine as many items as they have.
 */
export function MetaLine({ items, className }: MetaLineProps) {
  if (items.length === 0) return null
  return (
    <div className={cn("flex flex-wrap items-center gap-1.5 text-xs text-[var(--color-text-muted)]", className)}>
      {items.map((item, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span aria-hidden="true">&middot;</span>}
          <span className={cn("inline-flex items-center gap-1", item.mono && "font-mono")}>
            {item.icon && <item.icon size={11} strokeWidth={2} aria-hidden="true" />}
            {item.label}
          </span>
        </React.Fragment>
      ))}
    </div>
  )
}
