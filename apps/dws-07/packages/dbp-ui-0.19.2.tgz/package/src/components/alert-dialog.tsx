"use client"
import * as React from "react"
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog"
import { cva, type VariantProps } from "class-variance-authority"
import { AlertTriangle, Clock } from "lucide-react"
import { cn } from "../lib/cn.js"
import { Button } from "./button.js"
import { Checkbox } from "./checkbox.js"
import { Input } from "./input.js"
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "./select.js"
import { Badge } from "./badge.js"

const AlertDialog = AlertDialogPrimitive.Root
const AlertDialogTrigger = AlertDialogPrimitive.Trigger
const AlertDialogPortal = AlertDialogPrimitive.Portal

const AlertDialogOverlay = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Overlay
    ref={ref}
    className={cn(
      "fixed inset-0 z-[var(--z-overlay)]",
      "bg-[color-mix(in_srgb,var(--color-primary)_55%,transparent)]",
      "backdrop-blur-[2px]",
      "data-[state=open]:animate-in data-[state=closed]:animate-out",
      "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    )}
    {...props}
  />
))
AlertDialogOverlay.displayName = AlertDialogPrimitive.Overlay.displayName

const alertDialogContentVariants = cva(
  [
    "fixed left-[50%] top-[50%] z-[var(--z-modal)]",
    "translate-x-[-50%] translate-y-[-50%]",
    "flex flex-col",
    "bg-[var(--color-surface-content)]",
    "rounded-[var(--radius-modal)]",
    "shadow-[var(--shadow-xl)]",
    "border border-[var(--color-border-subtle)]",
    "focus-visible:outline-none",
    "data-[state=open]:animate-in data-[state=closed]:animate-out",
    "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
    "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95",
    "data-[state=closed]:slide-out-to-left-1/2 data-[state=open]:slide-in-from-left-1/2",
    "data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-top-[48%]",
    "duration-200",
    "w-full",
  ].join(" "),
  {
    variants: {
      size: {
        sm:      "max-w-[400px]",
        default: "max-w-[520px]",
        lg:      "max-w-[720px]",
        xl:      "max-w-[960px]",
        full:    "max-w-[calc(100vw-2rem)]",
      },
    },
    defaultVariants: {
      size: "default",
    },
  }
)

interface AlertDialogContentProps
  extends React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Content>,
    VariantProps<typeof alertDialogContentVariants> {}

const AlertDialogContent = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Content>,
  AlertDialogContentProps
>(({ size, className, children, ...props }, ref) => (
  <AlertDialogPortal>
    <AlertDialogOverlay />
    <AlertDialogPrimitive.Content
      ref={ref}
      className={cn(alertDialogContentVariants({ size }), className)}
      {...props}
    >
      {children}
    </AlertDialogPrimitive.Content>
  </AlertDialogPortal>
))
AlertDialogContent.displayName = AlertDialogPrimitive.Content.displayName

const AlertDialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex flex-col gap-1.5 px-6 pt-6 pb-4",
      "border-b border-[var(--color-border-subtle)]",
      className
    )}
    {...props}
  />
)
AlertDialogHeader.displayName = "AlertDialogHeader"

const AlertDialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end gap-2",
      "px-6 py-4",
      "border-t border-[var(--color-border-subtle)]",
      className
    )}
    {...props}
  />
)
AlertDialogFooter.displayName = "AlertDialogFooter"

const AlertDialogTitle = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold leading-snug text-[var(--color-text-primary)]", className)}
    {...props}
  />
))
AlertDialogTitle.displayName = AlertDialogPrimitive.Title.displayName

const AlertDialogDescription = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-[var(--color-text-muted)]", className)}
    {...props}
  />
))
AlertDialogDescription.displayName = AlertDialogPrimitive.Description.displayName

const AlertDialogAction = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Action>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Action>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Action ref={ref} className={className} {...props} />
))
AlertDialogAction.displayName = AlertDialogPrimitive.Action.displayName

const AlertDialogCancel = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Cancel>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Cancel>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Cancel ref={ref} className={className} {...props} />
))
AlertDialogCancel.displayName = AlertDialogPrimitive.Cancel.displayName

/* ─── ConfirmDialog (composed convenience component) ───────────────────── */

export interface ConfirmDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description?: string
  confirmLabel?: string
  cancelLabel?: string
  onConfirm: () => void
  /** Uses the destructive Button variant and danger-tinted title when true */
  destructive?: boolean
}

const ConfirmDialog = ({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  onConfirm,
  destructive = false,
}: ConfirmDialogProps) => (
  <AlertDialog open={open} onOpenChange={onOpenChange}>
    <AlertDialogContent size="sm">
      <AlertDialogHeader>
        <AlertDialogTitle>{title}</AlertDialogTitle>
        {description && <AlertDialogDescription>{description}</AlertDialogDescription>}
      </AlertDialogHeader>
      <AlertDialogFooter>
        <AlertDialogCancel asChild>
          <Button variant="ghost">{cancelLabel}</Button>
        </AlertDialogCancel>
        <AlertDialogAction asChild>
          <Button variant={destructive ? "destructive" : "orange"} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
)
ConfirmDialog.displayName = "ConfirmDialog"

/* ─── Risk-tier confirm variants (OVL-05) ───────────────────────────────
 * Friction scales with risk (overlay-confirm.jsx). Base ConfirmDialog covers
 * low-risk + generic destructive; these four compose the higher-friction
 * tiers the reference gallery calls out: destructive (with impact detail),
 * high-impact (required-reason select), bulk (count + affected preview),
 * production (typed-phrase arm-to-confirm + ack checkbox). */

/** Shared key/value impact row grid used by the destructive/high-impact tiers. */
function ImpactSummary({ rows }: { rows: { label: string; value: React.ReactNode }[] }) {
  return (
    <div className="rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface)] p-3 text-xs">
      {rows.map((r) => (
        <div key={r.label} className="flex items-center justify-between gap-3 py-0.5">
          <span className="text-[var(--color-text-muted)]">{r.label}</span>
          <span className="font-medium text-right">{r.value}</span>
        </div>
      ))}
    </div>
  )
}

/** Warning-tone callout used to surface a consequence inline (linked records, sub-tasks…). */
function ImpactCallout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 rounded-[var(--radius-card)] border border-[var(--color-danger-border)] bg-[var(--color-danger-surface)] p-3 text-xs text-[var(--color-danger-text)]">
      <AlertTriangle size={15} strokeWidth={1.5} className="mt-0.5 shrink-0" aria-hidden />
      <div>{children}</div>
    </div>
  )
}

export interface DestructiveConfirmDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** e.g. "Delete request SR-4815?" */
  title: string
  /** e.g. "\"Offboard contractor — revoke all access\" will be permanently deleted from Meridian Foods." */
  description: string
  /** What else this action removes/cancels — rendered in a warning callout. */
  impact?: React.ReactNode
  /** e.g. "Recoverable for 30 days" — shown left of the actions. */
  recoveryNote?: string
  confirmLabel: string
  cancelLabel?: string
  onConfirm: () => void
  busy?: boolean
}

/** Destructive tier — names the object, states permanence, surfaces dependencies. */
export const DestructiveConfirmDialog = ({
  open,
  onOpenChange,
  title,
  description,
  impact,
  recoveryNote,
  confirmLabel,
  cancelLabel = "Cancel",
  onConfirm,
  busy = false,
}: DestructiveConfirmDialogProps) => (
  <AlertDialog open={open} onOpenChange={onOpenChange}>
    <AlertDialogContent size="sm">
      <AlertDialogHeader>
        <AlertDialogTitle className="text-danger">{title}</AlertDialogTitle>
        <AlertDialogDescription>{description}</AlertDialogDescription>
      </AlertDialogHeader>
      {impact && <div className="px-6 py-4">{impact}</div>}
      <AlertDialogFooter>
        {recoveryNote && (
          <span className="mr-auto flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
            <Clock size={13} strokeWidth={1.5} aria-hidden />
            {recoveryNote}
          </span>
        )}
        <AlertDialogCancel asChild>
          <Button variant="ghost">{cancelLabel}</Button>
        </AlertDialogCancel>
        <AlertDialogAction asChild>
          <Button variant="destructive" disabled={busy} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
)
DestructiveConfirmDialog.displayName = "DestructiveConfirmDialog"

export interface HighImpactConfirmDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description: string
  impactRows: { label: string; value: React.ReactNode }[]
  reasonOptions: { value: string; label: string }[]
  reason: string
  onReasonChange: (reason: string) => void
  confirmLabel: string
  cancelLabel?: string
  onConfirm: () => void
  busy?: boolean
}

/** High-impact tier — affects other people/systems; requires a reason before the confirm button arms. */
export const HighImpactConfirmDialog = ({
  open,
  onOpenChange,
  title,
  description,
  impactRows,
  reasonOptions,
  reason,
  onReasonChange,
  confirmLabel,
  cancelLabel = "Cancel",
  onConfirm,
  busy = false,
}: HighImpactConfirmDialogProps) => (
  <AlertDialog open={open} onOpenChange={onOpenChange}>
    <AlertDialogContent size="sm">
      <AlertDialogHeader>
        <AlertDialogTitle className="text-danger">{title}</AlertDialogTitle>
        <AlertDialogDescription>{description}</AlertDialogDescription>
      </AlertDialogHeader>
      <div className="flex flex-col gap-3 px-6 py-4">
        <ImpactSummary rows={impactRows} />
        <label className="flex flex-col gap-1.5 text-sm">
          <span className="font-medium">
            Reason <span className="text-danger">*</span>
          </span>
          <Select value={reason} onValueChange={onReasonChange}>
            <SelectTrigger aria-label="Reason">
              <SelectValue placeholder="Select a reason…" />
            </SelectTrigger>
            <SelectContent>
              {reasonOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>
                  {o.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </label>
      </div>
      <AlertDialogFooter>
        <AlertDialogCancel asChild>
          <Button variant="ghost">{cancelLabel}</Button>
        </AlertDialogCancel>
        <AlertDialogAction asChild>
          <Button variant="destructive" disabled={busy || !reason} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
)
HighImpactConfirmDialog.displayName = "HighImpactConfirmDialog"

export interface BulkConfirmDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description: string
  /** e.g. "3 of 12 have open sub-tasks that will be cancelled." */
  affectedPreview?: React.ReactNode
  confirmLabel: string
  cancelLabel?: string
  onConfirm: () => void
  busy?: boolean
}

/** Bulk tier — acts on many records at once; states the exact count and previews what changes. */
export const BulkConfirmDialog = ({
  open,
  onOpenChange,
  title,
  description,
  affectedPreview,
  confirmLabel,
  cancelLabel = "Cancel",
  onConfirm,
  busy = false,
}: BulkConfirmDialogProps) => (
  <AlertDialog open={open} onOpenChange={onOpenChange}>
    <AlertDialogContent size="sm">
      <AlertDialogHeader>
        <AlertDialogTitle>{title}</AlertDialogTitle>
        <AlertDialogDescription>{description}</AlertDialogDescription>
      </AlertDialogHeader>
      {affectedPreview && <div className="px-6 py-4">{<ImpactCallout>{affectedPreview}</ImpactCallout>}</div>}
      <AlertDialogFooter>
        <AlertDialogCancel asChild>
          <Button variant="ghost">{cancelLabel}</Button>
        </AlertDialogCancel>
        <AlertDialogAction asChild>
          <Button variant="orange" disabled={busy} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
)
BulkConfirmDialog.displayName = "BulkConfirmDialog"

export interface ProductionConfirmDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description: string
  /** Environment badge label, e.g. "Production". */
  envLabel?: string
  /** Extra environment context, e.g. "Northwind Labs · eu-central-1". */
  envContext?: string
  /** The exact phrase the user must type to arm the confirm button, e.g. "PRODUCTION". */
  armPhrase: string
  ackLabel: string
  confirmLabel: string
  cancelLabel?: string
  onConfirm: () => void
  busy?: boolean
}

/** Production tier — typed-phrase arm-to-confirm + logged acknowledgement checkbox. */
export const ProductionConfirmDialog = ({
  open,
  onOpenChange,
  title,
  description,
  envLabel = "Production",
  envContext,
  armPhrase,
  ackLabel,
  confirmLabel,
  cancelLabel = "Cancel",
  onConfirm,
  busy = false,
}: ProductionConfirmDialogProps) => {
  const [phrase, setPhrase] = React.useState("")
  const [ack, setAck] = React.useState(false)
  const armed = phrase === armPhrase && ack

  React.useEffect(() => {
    if (!open) {
      setPhrase("")
      setAck(false)
    }
  }, [open])

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent size="sm">
        <AlertDialogHeader>
          <div className="flex items-center gap-2 mb-1">
            <Badge tone="danger">{envLabel}</Badge>
            {envContext && <span className="text-xs text-[var(--color-text-muted)]">{envContext}</span>}
          </div>
          <AlertDialogTitle className="text-danger">{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <div className="flex flex-col gap-3 px-6 py-4">
          <label className="flex flex-col gap-1.5 text-sm">
            <span>
              Type <span className="font-mono font-bold">{armPhrase}</span> to confirm
            </span>
            <Input
              value={phrase}
              onChange={(e) => setPhrase(e.target.value)}
              placeholder={armPhrase}
              autoFocus
              aria-label={`Type ${armPhrase} to confirm`}
            />
          </label>
          <label className="flex items-start gap-2 text-xs text-[var(--color-text-muted)]">
            <Checkbox checked={ack} onCheckedChange={(v) => setAck(v === true)} className="mt-0.5" />
            {ackLabel}
          </label>
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel asChild>
            <Button variant="ghost">{cancelLabel}</Button>
          </AlertDialogCancel>
          <AlertDialogAction asChild>
            <Button variant="destructive" disabled={busy || !armed} onClick={onConfirm}>
              {confirmLabel}
            </Button>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
ProductionConfirmDialog.displayName = "ProductionConfirmDialog"

export interface UnsavedChangesConfirmDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** e.g. "Leave without saving?" */
  title?: string
  /** e.g. "You've made changes to SR-4820 that haven't been saved. Leaving now will discard them." */
  description: string
  discardLabel?: string
  keepEditingLabel?: string
  onDiscard: () => void
  /** Optional third path — save the draft, then leave. Omit to offer only discard/keep-editing. */
  onSaveAndLeave?: () => void
  saveAndLeaveLabel?: string
  busy?: boolean
}

/**
 * Unsaved-changes tier (OVL-05, 6th risk tier — `overlay-confirm.jsx`'s
 * `which === 'unsaved'` variant). Distinct from the other 5 tiers: it isn't
 * about risk to a record, it's about protecting entered data, so it offers a
 * third "Save & leave" path alongside discard/keep-editing rather than a
 * single confirm action. Pairs with `useUnsavedGuard`.
 */
export const UnsavedChangesConfirmDialog = ({
  open,
  onOpenChange,
  title = "Leave without saving?",
  description,
  discardLabel = "Leave without saving",
  keepEditingLabel = "Keep editing",
  onDiscard,
  onSaveAndLeave,
  saveAndLeaveLabel = "Save & leave",
  busy = false,
}: UnsavedChangesConfirmDialogProps) => (
  <AlertDialog open={open} onOpenChange={onOpenChange}>
    <AlertDialogContent size="sm">
      <AlertDialogHeader>
        <AlertDialogTitle>{title}</AlertDialogTitle>
        <AlertDialogDescription>{description}</AlertDialogDescription>
      </AlertDialogHeader>
      <AlertDialogFooter>
        {onSaveAndLeave && (
          <Button variant="outline" disabled={busy} onClick={onSaveAndLeave} className="sm:mr-auto">
            {saveAndLeaveLabel}
          </Button>
        )}
        <AlertDialogCancel asChild>
          <Button variant="ghost">{keepEditingLabel}</Button>
        </AlertDialogCancel>
        <AlertDialogAction asChild>
          <Button variant="orange" disabled={busy} onClick={onDiscard}>
            {discardLabel}
          </Button>
        </AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
)
UnsavedChangesConfirmDialog.displayName = "UnsavedChangesConfirmDialog"

export {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
  ConfirmDialog,
}
