import * as React from "react"
import { CircleCheck, User } from "lucide-react"
import { AiMark } from "./ai-mark.js"
import { Badge } from "./badge.js"
import { cn } from "../lib/cn.js"

export type AiLabelKind =
  | "generated"
  | "assisted"
  | "recommendation"
  | "prediction"
  | "anomaly"
  | "summary"
  | "suggested"
  | "automated"
  | "confirmed"
  | "reviewed"

const AI_LABEL: Record<AiLabelKind, { text: string; mark: boolean }> = {
  generated: { text: "AI-generated", mark: true },
  assisted: { text: "AI-assisted", mark: true },
  recommendation: { text: "AI recommendation", mark: true },
  prediction: { text: "AI prediction", mark: true },
  anomaly: { text: "AI-detected anomaly", mark: true },
  summary: { text: "AI-generated summary", mark: true },
  suggested: { text: "AI-suggested value", mark: true },
  automated: { text: "Automated by AI", mark: true },
  confirmed: { text: "User-confirmed", mark: false },
  reviewed: { text: "Human-reviewed", mark: false },
}

export interface AiLabelProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "children"> {
  /** Which vocabulary entry to render. Defaults to "generated". */
  kind?: AiLabelKind
  /** Override the default label text. */
  text?: string
}

/**
 * AI governance vocabulary label — always text, with the one consistent mark
 * (`AiMark`, never a sparkle). `confirmed`/`reviewed` kinds render a
 * human-provenance icon instead of the AI mark.
 */
const LABEL_SHAPE = "rounded-[4px] px-1.5 py-0.5 text-xs font-semibold whitespace-nowrap select-none"

function AiLabel({ className, kind = "generated", text, ...props }: AiLabelProps) {
  const entry = AI_LABEL[kind] ?? AI_LABEL.generated
  const isHuman = !entry.mark
  const icon = entry.mark ? (
    <AiMark size={11} />
  ) : kind === "confirmed" ? (
    <CircleCheck size={11} aria-hidden="true" />
  ) : (
    <User size={11} aria-hidden="true" />
  )

  if (isHuman) {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1.5 whitespace-nowrap select-none",
          LABEL_SHAPE,
          "text-[hsl(var(--prov-human))] border border-[hsl(var(--prov-human)/0.3)] bg-transparent",
          className,
        )}
        {...props}
      >
        {icon}
        {text ?? entry.text}
      </span>
    )
  }

  return (
    <Badge tone="ai" className={cn(LABEL_SHAPE, className)} {...props}>
      {icon}
      {text ?? entry.text}
    </Badge>
  )
}

export { AiLabel, AI_LABEL }
