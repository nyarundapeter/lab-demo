import * as React from "react"
import type { LucideProps } from "lucide-react"
import { cn } from "../lib/cn.js"

export type CenteredNoticeTone = "brand" | "warning" | "danger" | "neutral"

const TONE: Record<CenteredNoticeTone, { surface: string; text: string }> = {
  brand: { surface: "var(--color-primary-surface)", text: "var(--color-primary)" },
  warning: { surface: "var(--color-warning-surface)", text: "var(--color-warning-text)" },
  danger: { surface: "var(--color-danger-surface)", text: "var(--color-danger-text)" },
  neutral: { surface: "var(--color-neutral-surface)", text: "var(--color-neutral-text)" },
}

export interface CenteredNoticeProps {
  icon: React.FC<LucideProps>
  /** @default "neutral" */
  tone?: CenteredNoticeTone
  /** Optional workspace lockup rendered above the icon (mark + name). Omit for no brand row. */
  brand?: { name: string; mark?: React.ReactNode }
  kicker?: string
  title: string
  children: React.ReactNode
  actions?: React.ReactNode
  footer?: React.ReactNode
  className?: string
}

/**
 * Branded, no-app-shell centered card — the standalone variant used for
 * whole-app interstitials (maintenance, unsupported browser/viewport) where
 * no sidebar/topbar chrome is available to anchor the message.
 * Port of `identity-errors.jsx`'s `CenteredNotice`.
 */
function CenteredNotice({
  icon: Icon,
  tone = "neutral",
  brand,
  kicker,
  title,
  children,
  actions,
  footer,
  className,
}: CenteredNoticeProps) {
  const token = TONE[tone]

  return (
    <div
      className={cn(
        "flex min-h-full items-center justify-center bg-[var(--color-surface)] p-6",
        className
      )}
    >
      <div className="w-full max-w-[460px] rounded-[var(--radius-card)] border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] p-9 text-center shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
        {brand && (
          <div className="mb-6 flex items-center justify-center gap-2 text-sm font-semibold text-[var(--color-text)]">
            {brand.mark}
            {brand.name}
          </div>
        )}
        <span
          className="mx-auto mb-5 flex h-[56px] w-[56px] items-center justify-center rounded-full"
          style={{ background: token.surface }}
          aria-hidden="true"
        >
          <Icon size={26} strokeWidth={1.75} style={{ color: token.text }} />
        </span>
        {kicker && (
          <div className="mb-1.5 text-xs font-semibold tracking-[0.05em] text-[var(--color-text-muted)]">
            {kicker}
          </div>
        )}
        <h1 className="mb-2.5 text-xl font-semibold text-[var(--color-text)]">{title}</h1>
        <div
          className={cn(
            "text-sm leading-relaxed text-[var(--color-text-muted)]",
            actions && "mb-6"
          )}
        >
          {children}
        </div>
        {actions && <div className="flex justify-center gap-2.5">{actions}</div>}
        {footer && (
          <div className="mt-6 border-t border-[var(--color-border-subtle)] pt-5 text-xs text-[var(--color-text-muted)]">
            {footer}
          </div>
        )}
      </div>
    </div>
  )
}

export { CenteredNotice }
