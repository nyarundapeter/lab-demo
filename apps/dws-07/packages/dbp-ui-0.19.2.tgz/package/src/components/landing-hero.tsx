import * as React from "react"
import { ArrowRight, Play, CheckCircle } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface LandingHeroTrustBullet {
  /** Lucide icon element — rendered inside an h-8 w-8 navy-50 tile. */
  icon?: React.ReactNode
  label: string
}

export interface LandingHeroCta {
  label: string
  href: string
}

export interface LandingHeroProps {
  /** Mono overline text (dq-overline style). */
  overline?: string
  /** Main headline text (navy, left column). */
  headline?: string
  /** Orange accent span appended to the headline. */
  headlineAccent?: string
  /** Body paragraph beneath the headline. */
  body?: string
  /** Primary CTA (navy pill with orange hover gradient). */
  primaryCta?: LandingHeroCta
  /** Secondary CTA (outline pill). */
  secondaryCta?: LandingHeroCta
  /** Trust bullet items row — icon tile + label. */
  trustBullets?: LandingHeroTrustBullet[]
  /** Right column content. If absent a tasteful placeholder card is rendered. */
  preview?: React.ReactNode
  className?: string
}

/**
 * LandingHero — full-bleed marketing hero with two-tone headline, CTA row,
 * trust bullets, and an optional right-column preview slot.
 *
 * Background: --mesh-hero-light gradient + .hero-grid low-opacity overlay.
 * Layout:    max-w-[1280px] mx-auto, lg:grid-cols-[1fr_1.05fr].
 * Server-component safe (no client state).
 */
export function LandingHero({
  overline = "Digital Workspace for Every Employee",
  headline = "Everything you need.",
  headlineAccent = "One workspace.",
  body = "A unified platform for governed daily work — tasks, knowledge, services, and performance visibility in one place.",
  primaryCta = { label: "Get Started", href: "#" },
  secondaryCta = { label: "Take a Tour", href: "#" },
  trustBullets = [],
  preview,
  className,
}: LandingHeroProps) {
  return (
    <section
      className={cn("relative isolate overflow-hidden", className)}
      aria-label="Hero"
    >
      {/* Background mesh */}
      <div
        aria-hidden
        className="absolute inset-0 -z-10"
        style={{ background: "var(--mesh-hero-light)" }}
      />
      {/* Grid overlay */}
      <div
        aria-hidden
        className="hero-grid absolute inset-0 -z-10 opacity-40"
      />

      <div className="relative mx-auto max-w-[1200px] px-5 pb-16 pt-12 md:px-8 lg:px-10 lg:pb-24 lg:pt-16">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-[1fr_1.05fr] lg:gap-14">

          {/* LEFT: copy block */}
          <div className="max-w-xl">
            {/* Overline */}
            <p className="dq-overline animate-fade-in-up">
              {overline}
            </p>

            {/* Headline */}
            <h1
              className={cn(
                "animate-fade-in-up animation-delay-100",
                "mt-4 text-balance text-[2.75rem] font-semibold leading-[1.02]",
                "tracking-[-0.03em] text-[var(--color-text-primary)] sm:text-[3.5rem] lg:text-[4rem]"
              )}
            >
              {headline}{" "}
              <span className="text-secondary">{headlineAccent}</span>
            </h1>

            {/* Body */}
            {body && (
              <p
                className={cn(
                  "animate-fade-in-up animation-delay-200",
                  "mt-5 max-w-2xl text-base leading-7 text-[var(--color-text-muted)] sm:text-lg"
                )}
              >
                {body}
              </p>
            )}

            {/* CTA row */}
            <div
              className={cn(
                "animate-fade-in-up animation-delay-300",
                "mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"
              )}
            >
              {/* Primary CTA — navy pill with orange slide-in hover */}
              <a
                href={primaryCta.href}
                className={cn(
                  "group relative inline-flex h-12 w-full items-center justify-center",
                  "gap-2 overflow-hidden rounded-pill bg-primary px-6 text-sm",
                  "font-semibold text-white sm:w-auto",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                  "motion-safe:transition-colors"
                )}
                style={{ boxShadow: "var(--glow-navy-md)" }}
              >
                <span
                  aria-hidden
                  className={cn(
                    "absolute inset-0 -translate-x-full",
                    "bg-gradient-to-r from-secondary to-[var(--color-orange-600)]",
                    "motion-safe:transition-transform motion-safe:duration-500",
                    "group-hover:translate-x-0"
                  )}
                />
                <span className="relative">{primaryCta.label}</span>
                <ArrowRight size={16} strokeWidth={1.5} className="relative shrink-0" aria-hidden="true" />
              </a>

              {/* Secondary CTA — outline pill */}
              <a
                href={secondaryCta.href}
                className={cn(
                  "inline-flex h-12 w-full items-center justify-center gap-2",
                  "rounded-pill border border-[var(--color-border-default)] bg-white/60 px-6",
                  "text-sm font-semibold text-[var(--color-text-primary)] backdrop-blur-sm sm:w-auto",
                  "hover:border-[var(--color-border-strong)] hover:bg-[var(--color-surface-content)]",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                  "motion-safe:transition-colors"
                )}
              >
                {secondaryCta.label}
                <Play size={14} strokeWidth={1.5} fill="currentColor" aria-hidden="true" />
              </a>
            </div>

            {/* Trust bullets */}
            {trustBullets.length > 0 && (
              <div className="mt-10 flex flex-col flex-wrap gap-4 sm:flex-row sm:gap-5 lg:gap-7">
                {trustBullets.map((bullet, i) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <div
                      className={cn(
                        "flex h-8 w-8 shrink-0 items-center justify-center",
                        "rounded-xl bg-[var(--color-navy-50)] text-[var(--color-text-primary)]"
                      )}
                      aria-hidden="true"
                    >
                      {bullet.icon ?? <CheckCircle size={16} strokeWidth={1.5} />}
                    </div>
                    <span className="text-sm font-medium text-[var(--color-text-secondary)] whitespace-nowrap">
                      {bullet.label}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* RIGHT: preview slot or placeholder */}
          <div className="animate-fade-in-up animation-delay-200">
            {preview ?? <HeroPreviewPlaceholder />}
          </div>
        </div>
      </div>
    </section>
  )
}

/** Tasteful static placeholder card rendered when no preview prop is provided. */
function HeroPreviewPlaceholder() {
  return (
    <div
      className={cn(
        "relative aspect-[4/3] w-full max-w-[580px] mx-auto lg:mx-0",
        "rounded-[20px] border border-[var(--color-border-subtle)]",
        "bg-[var(--color-surface-content)] shadow-[0_24px_48px_rgba(3,15,53,0.10)]",
        "overflow-hidden"
      )}
      role="img"
      aria-label="Platform preview"
    >
      {/* Decorative top bar */}
      <div className="flex h-10 items-center gap-2 border-b border-[var(--color-border-subtle)] px-4">
        <div className="h-3 w-3 rounded-full bg-[var(--color-danger-surface)]" aria-hidden />
        <div className="h-3 w-3 rounded-full bg-[var(--color-warning-surface)]" aria-hidden />
        <div className="h-3 w-3 rounded-full bg-[var(--color-success-surface)]" aria-hidden />
        <div className="ml-auto h-4 w-24 rounded bg-[var(--color-navy-50)]" aria-hidden />
      </div>

      {/* Content skeleton */}
      <div className="p-5 space-y-3">
        {/* KPI row */}
        <div className="grid grid-cols-3 gap-3">
          {["bg-[var(--color-navy-50)]", "bg-[var(--color-orange-50)]", "bg-[var(--color-navy-50)]"].map((bg, i) => (
            <div key={i} className={cn("rounded-[10px] p-3 h-16", bg)} aria-hidden>
              <div className="h-2 w-8 rounded bg-current opacity-20 mb-2" />
              <div className="h-4 w-10 rounded bg-current opacity-30" />
            </div>
          ))}
        </div>

        {/* Content rows */}
        {Array.from({ length: 4 }).map((_, i) => (
          <div
            key={i}
            className="flex items-center gap-3 rounded-[8px] border border-[var(--color-border-subtle)] bg-[var(--color-surface-content)] p-3"
            aria-hidden
          >
            <div className="h-7 w-7 shrink-0 rounded-lg bg-[var(--color-navy-50)]" />
            <div className="flex-1 space-y-1.5">
              <div className="h-2.5 w-3/4 rounded bg-[var(--color-navy-100)]" />
              <div className="h-2 w-1/2 rounded bg-[var(--color-border-subtle)]" />
            </div>
            <div className="h-5 w-14 shrink-0 rounded-pill bg-[var(--color-success-surface)]" />
          </div>
        ))}
      </div>
    </div>
  )
}
