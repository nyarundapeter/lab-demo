"use client";

// Ported from the STCB GRC solution's shared detail-drawer kit (WS-6.2).
// Filter row for a drawer tab with a filterable table: mapping chips, then
// up to two selects sized to their own content (never stretched to a fixed
// width), then an optional search box — with the result count pinned to the
// row's trailing edge so it holds position across every filter state.

import * as React from "react";
import { Badge } from "./badge.js";
import { Button } from "./button.js";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "./select.js";

export interface DetailFilterRowMappingOption<M extends string> {
  value: M;
  label: string;
}

export interface DetailFilterRowMapping<M extends string> {
  options: DetailFilterRowMappingOption<M>[];
  active: M;
  onChange: (value: M) => void;
}

export interface DetailFilterRowSelectFilter {
  value: string;
  onChange: (value: string) => void;
  allValue: string;
  allLabel: string;
  options: string[];
}

export interface DetailFilterRowSearch {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
}

export interface DetailFilterRowProps<M extends string> {
  mapping?: DetailFilterRowMapping<M>;
  select?: DetailFilterRowSelectFilter;
  secondarySelect?: DetailFilterRowSelectFilter;
  search?: DetailFilterRowSearch;
  /** e.g. "12 of 513" */
  countLabel: string;
}

export function DetailFilterRow<M extends string>({
  mapping,
  select,
  secondarySelect,
  search,
  countLabel,
}: DetailFilterRowProps<M>) {
  return (
    <div className="flex flex-wrap items-center gap-2 py-1">
      {mapping && (
        <div className="flex shrink-0 gap-1">
          {mapping.options.map((f) => (
            <Button
              key={f.value}
              variant={mapping.active === f.value ? "outline" : "ghost"}
              size="sm"
              className="text-xs capitalize"
              onClick={() => mapping.onChange(f.value)}
            >
              {f.label}
            </Button>
          ))}
        </div>
      )}
      {select && (
        <Select value={select.value} onValueChange={select.onChange}>
          <SelectTrigger className="h-8 w-auto shrink-0 text-xs">
            <SelectValue placeholder={select.allLabel} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={select.allValue}>{select.allLabel}</SelectItem>
            {select.options.map((d) => (
              <SelectItem key={d} value={d}>
                {d}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
      {secondarySelect && (
        <Select value={secondarySelect.value} onValueChange={secondarySelect.onChange}>
          <SelectTrigger className="h-8 w-auto shrink-0 text-xs">
            <SelectValue placeholder={secondarySelect.allLabel} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={secondarySelect.allValue}>{secondarySelect.allLabel}</SelectItem>
            {secondarySelect.options.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
      {search && (
        <input
          value={search.value}
          onChange={(e) => search.onChange(e.target.value)}
          placeholder={search.placeholder}
          className="h-8 w-40 shrink-0 rounded-md border border-[var(--color-border-default)] bg-transparent px-2 text-xs text-[var(--color-text)] outline-none placeholder:text-[var(--color-text-muted)]"
        />
      )}
      <Badge tone="gray" size="sm" className="ml-auto shrink-0">
        {countLabel}
      </Badge>
    </div>
  );
}

export default DetailFilterRow;
