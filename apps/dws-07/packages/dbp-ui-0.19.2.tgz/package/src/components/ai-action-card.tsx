import * as React from "react"
import { cn } from "../lib/cn.js"
import { Card } from "./card.js"

export interface AiActionCardField {
  label: string
  value: React.ReactNode
}

export interface AiActionCardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children" | "title"> {
  /** Optional leading icon, rendered in its own column left of the content (e.g. `DataQualityCard`'s severity icon). */
  icon?: React.ReactNode
  /** AiLabel (or similar) rendered first in the header row. */
  label: React.ReactNode
  /** Rendered between `label` and `badge` in the header row, e.g. a `CtrlBadge`. */
  headerExtra?: React.ReactNode
  /** Risk/severity badge, rendered last in the header row. */
  badge?: React.ReactNode
  title: React.ReactNode
  /** `dl`-style field list rendered under the title. */
  fields: AiActionCardField[]
  /** Optional note/banner rendered under the fields list. */
  note?: React.ReactNode
  /** Action row. When `footerFullWidth` is false (default) it is rendered inline, fully owned
   * by the caller (including its own wrapper). When true, `AiActionCard` renders it as a
   * full-width section below the body with a top border, matching `SuggestedAction`'s footer. */
  footer?: React.ReactNode
  footerFullWidth?: boolean
  headerClassName?: string
  titleClassName?: string
  fieldsClassName?: string
  bodyClassName?: string
}

/**
 * Shared shell for AI-surfaced action cards — icon+label header, `dl` field
 * list, risk/severity badge, and an action row. Extracted from `DataQualityCard`
 * and `SuggestedAction`, which applied the same structural pattern to two
 * different domains (a data-quality issue vs. a generic suggested action).
 * Follows the `InfoCard` base+variant precedent: this owns the shared shell,
 * callers own their own state machine, skin, and footer content.
 */
function AiActionCard({
  icon,
  label,
  headerExtra,
  badge,
  title,
  fields,
  note,
  footer,
  footerFullWidth = false,
  headerClassName,
  titleClassName,
  fieldsClassName,
  bodyClassName,
  className,
  ...rest
}: AiActionCardProps) {
  return (
    <Card density="compact" className={cn("shadow-none", icon && "flex items-start gap-3", className)} {...rest}>
      {icon}
      <div className={cn(icon && "min-w-0 flex-1", bodyClassName)}>
        <div className={cn("mb-1 flex items-center gap-2", headerClassName)}>
          {label}
          {headerExtra}
          {badge}
        </div>
        <div className={cn("mb-1.5 text-sm font-semibold text-[var(--color-text)]", titleClassName)}>{title}</div>
        <dl className={cn("mb-2 flex flex-col gap-1 text-xs", fieldsClassName)}>
          {fields.map((field, i) => (
            <div className="flex gap-2" key={i}>
              <dt className="min-w-[128px] shrink-0 text-[hsl(var(--muted-foreground))]">{field.label}</dt>
              <dd className="m-0">{field.value}</dd>
            </div>
          ))}
        </dl>
        {note}
        {!footerFullWidth && footer}
      </div>
      {footerFullWidth && footer && (
        <div className="flex items-center gap-2 border-t border-[var(--color-border-subtle)] px-3 py-2">{footer}</div>
      )}
    </Card>
  )
}

export { AiActionCard }
