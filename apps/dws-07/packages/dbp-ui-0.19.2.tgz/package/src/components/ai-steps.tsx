import * as React from "react"
import { Check } from "lucide-react"
import { AiMark } from "./ai-mark.js"
import { cn } from "../lib/cn.js"

export interface AiThinkingProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "children"> {
  label?: string
}

/** Simple "AI is thinking" indicator — mark + animated dots + label. */
function AiThinking({ className, label = "Thinking", ...props }: AiThinkingProps) {
  return (
    <span
      role="status"
      aria-live="polite"
      className={cn("inline-flex items-center gap-2 text-xs text-[hsl(var(--muted-foreground))]", className)}
      {...props}
    >
      <AiMark size={13} />
      <span className="inline-flex items-center gap-0.5" aria-hidden="true">
        <span className="h-1 w-1 animate-bounce rounded-full bg-current [animation-delay:0ms]" />
        <span className="h-1 w-1 animate-bounce rounded-full bg-current [animation-delay:150ms]" />
        <span className="h-1 w-1 animate-bounce rounded-full bg-current [animation-delay:300ms]" />
      </span>
      {label}…
    </span>
  )
}

export type AiStepState = "done" | "active" | "pending"

export interface AiStep {
  label: string
  state: AiStepState
}

export interface AiStepsProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  steps: AiStep[]
}

/**
 * Labelled reasoning-step indicator — replaces the generic dot spinner when
 * the assistant hook exposes discrete stages (e.g. "Reading… Querying…
 * Composing…").
 */
function AiSteps({ className, steps, ...props }: AiStepsProps) {
  return (
    <div role="status" aria-live="polite" className={cn("flex flex-col gap-1", className)} {...props}>
      {steps.map((s, i) => (
        <div
          key={i}
          className={cn(
            "flex items-center gap-2 text-xs",
            s.state === "pending" ? "text-[hsl(var(--muted-foreground))] opacity-60" : "text-[var(--color-text-primary)]",
          )}
        >
          <span className="flex h-3.5 w-3.5 shrink-0 items-center justify-center">
            {s.state === "done" ? (
              <Check size={11} className="text-[hsl(var(--prov-human))]" aria-hidden="true" />
            ) : s.state === "active" ? (
              <AiMark size={11} />
            ) : null}
          </span>
          {s.label}
        </div>
      ))}
    </div>
  )
}

export { AiThinking, AiSteps }
