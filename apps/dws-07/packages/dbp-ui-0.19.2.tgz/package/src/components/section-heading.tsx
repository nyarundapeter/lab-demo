import * as React from "react"
import { cn } from "../lib/cn.js"

export interface SectionHeadingProps {
  /** Mono overline above the title (rendered via `.dq-overline`). */
  kicker?: string
  title: React.ReactNode
  description?: React.ReactNode
  align?: "left" | "center"
  className?: string
}

/**
 * SectionHeading — kicker + title + description block.
 * Lifted from TMaaS SectionHeading, token-aliased:
 *   text-dq-navy → text-[var(--color-text-primary)], the old TMaaS body-copy gray → text-[var(--color-text-secondary)],
 *   .dq-eyebrow → .dq-overline.
 */
export function SectionHeading({
  kicker,
  title,
  description,
  align = "center",
  className,
}: SectionHeadingProps): React.ReactElement {
  return (
    <div
      className={cn(
        "mx-auto max-w-2xl",
        align === "center" ? "text-center" : "text-left",
        className,
      )}
    >
      {kicker ? <p className="dq-overline mb-4">{kicker}</p> : null}
      <div className="text-4xl font-semibold tracking-tight text-[var(--color-text-primary)] md:text-5xl">{title}</div>
      {description ? (
        <div className="mt-4 text-base leading-relaxed text-[var(--color-text-secondary)]">
          {description}
        </div>
      ) : null}
    </div>
  )
}
