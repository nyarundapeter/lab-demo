import * as React from "react";
import { Gauge, ExternalLink } from "lucide-react";
import { cn } from "../lib/cn.js";
import { Card, CardHeader, CardTitle, CardContent } from "./card.js";
import { Badge } from "./badge.js";
import { Alert } from "./alert.js";
import { Button } from "./button.js";

export type ImpactRiskLevel = "low" | "medium" | "high";

export interface ImpactItem {
  /** Surface type label, e.g. "Workflows", "Rules". */
  type: string;
  /** Icon rendered in the leading tile. */
  icon?: React.ReactNode | undefined;
  /** Count of affected records/items of this type. */
  count: number;
  /** Human-readable list of affected item names. */
  items: string[];
  /** Optional navigation target — when set, items become clickable links. */
  to?: string | undefined;
  /** Marks this row as having a conflict, shown with a badge + tinted tile. */
  conflict?: boolean | undefined;
}

export interface ChangeImpactPanelProps {
  /** Affected surfaces produced by the pending change. */
  items: ImpactItem[];
  /** Overall risk level for the change — drives the header indicator. */
  riskLevel?: ImpactRiskLevel;
  /** Called with an item's `to` target when the item or its open action is clicked. */
  onNavigate?: (to: string) => void;
  className?: string;
}

const RISK_LABEL: Record<ImpactRiskLevel, string> = {
  low: "Low risk",
  medium: "Medium risk",
  high: "High risk",
};

const RISK_TONE: Record<ImpactRiskLevel, "success" | "warning" | "danger"> = {
  low: "success",
  medium: "warning",
  high: "danger",
};

/**
 * ChangeImpactPanel — shows the surfaces (workflows, rules, forms, records,
 * users, …) a pending publish/change will affect, plus an approval callout.
 *
 * Pure render — all data comes in via `items`; `onNavigate` is a callback,
 * no internal navigation.
 */
export function ChangeImpactPanel({
  items,
  riskLevel = "medium",
  onNavigate,
  className,
}: ChangeImpactPanelProps) {
  const riskTone = RISK_TONE[riskLevel];

  return (
    <Card className={cn("shadow-none", className)}>
      <CardHeader className="flex-row items-center gap-2 border-b-0 pb-0">
        <Gauge size={16} strokeWidth={1.5} className="text-text-muted" aria-hidden="true" />
        <CardTitle>Change impact analysis</CardTitle>
        <span className="ml-auto">
          <Badge tone={riskTone} dot>
            {RISK_LABEL[riskLevel]}
          </Badge>
        </span>
      </CardHeader>
      <CardContent>
        <p className="mb-3.5 text-xs text-text-muted">
          Publishing this change will affect the following. Review dependencies and downstream
          impact before continuing.
        </p>

        <div className="flex flex-col gap-2">
          {items.map((item, i) => (
            <div
              key={item.type}
              className={cn(
                "flex items-start gap-2.5 py-2",
                i < items.length - 1 && "border-b border-border-subtle"
              )}
            >
              <span
                aria-hidden="true"
                className={cn(
                  "flex h-[26px] w-[26px] shrink-0 items-center justify-center rounded-button",
                  item.conflict
                    ? "bg-danger-surface text-danger-text"
                    : "bg-surface text-text-muted"
                )}
              >
                {item.icon}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 text-xs font-medium">
                  {item.type}
                  <span className="font-normal text-text-muted">· {item.count}</span>
                  {item.conflict && <Badge tone="danger" size="sm">Conflict</Badge>}
                </div>
                <div className="mt-0.5 text-xs text-text-muted">
                  {item.items.map((x, j) => (
                    <span key={x}>
                      {item.to ? (
                        <button
                          type="button"
                          onClick={() => onNavigate?.(item.to!)}
                          className="text-[var(--color-text-primary)] underline-offset-2 hover:underline"
                        >
                          {x}
                        </button>
                      ) : (
                        x
                      )}
                      {j < item.items.length - 1 ? ", " : ""}
                    </span>
                  ))}
                </div>
              </div>
              {item.to && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0"
                  aria-label={`Open ${item.type}`}
                  onClick={() => onNavigate?.(item.to!)}
                >
                  <ExternalLink size={14} strokeWidth={1.5} />
                </Button>
              )}
            </div>
          ))}
        </div>

        <Alert tone="warning" title="1 approval required" className="mt-3.5">
          Changes to production rules require sign-off from a Platform administrator before they
          take effect.
        </Alert>
      </CardContent>
    </Card>
  );
}
