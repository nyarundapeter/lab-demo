import * as React from "react"
import { cn } from "../lib/cn.js"
import { Avatar } from "./avatar.js"
import { Card } from "./card.js"

export interface OrgIdentityRowProps extends React.HTMLAttributes<HTMLDivElement> {
  name: string
  /** Secondary line — typically the org's domain. */
  domain?: string | undefined
}

/**
 * OrgIdentityRow (formerly `OrgBadge`, renamed — "badge" collided with the
 * chip-family `Badge` component; this is an identity row, not a chip)
 * — small org/tenant identity row for the top of a credential card
 * (identity-core.jsx:238-246, `.auth-org`). Reference builds its own tile
 * (`LetterMark`); this composes the existing `Avatar` (initials + deterministic
 * color) instead of a second tile implementation, per the plan's "already
 * covered" ruling on `LetterMark`. Composes `Card` for its outer shell
 * (card-drift consolidation, design-system de-dup Wave 1.A) — this also
 * fixes the shell's surface from the grey `--color-surface` to Card's
 * default white `--color-surface-content` (component-surface-default-white
 * rule).
 */
function OrgIdentityRow({ name, domain, className, ...props }: OrgIdentityRowProps) {
  return (
    <Card
      className={cn("flex items-center gap-2.5 px-3 py-2.5 shadow-none", className)}
      {...props}
    >
      <Avatar name={name} size="md" />
      <div className="min-w-0">
        <p className="truncate text-sm font-semibold text-[var(--color-text-primary)]">{name}</p>
        {domain && <p className="truncate text-xs text-[var(--color-text-muted)]">{domain}</p>}
      </div>
    </Card>
  )
}

export { OrgIdentityRow }
