import * as React from "react"
import { Search } from "lucide-react"
import { cn } from "../lib/cn"
import { Input } from "./input"

/**
 * Search + a single active filter chip (radio-like: one active at a time) +
 * one sort dropdown + trailing action buttons. For N independently-toggleable
 * filter dropdowns with multiple simultaneously-active, individually-removable
 * chips plus status tabs, use `CollectionToolbar` instead — different
 * interaction model, not a redundant pair.
 */
export interface FilterChip {
  key: string
  label: string
  count?: number
}

export interface FilterBarProps {
  searchValue?: string
  onSearchChange?: (value: string) => void
  searchPlaceholder?: string
  chips?: FilterChip[]
  activeChip?: string
  onChipChange?: (key: string) => void
  sortOptions?: Array<{ value: string; label: string }>
  sortValue?: string
  onSortChange?: (value: string) => void
  /** Result-summary text, e.g. "12 of 42 cases". Always visible when provided. */
  resultSummary?: React.ReactNode
  /** Shown only when true — e.g. gate it on "search or a non-default chip/filter is active". */
  showClearAll?: boolean
  onClearAll?: () => void
  clearAllLabel?: string
  /** Trailing action buttons (e.g. "New", "Export"), rendered at the end of the bar. Matches `CollectionToolbar`'s `actions` slot for parity between the two toolbar shapes. */
  actions?: React.ReactNode
  className?: string
}

export function FilterBar({
  searchValue,
  onSearchChange,
  searchPlaceholder = "Search…",
  chips,
  activeChip,
  onChipChange,
  sortOptions,
  sortValue,
  onSortChange,
  resultSummary,
  showClearAll = false,
  onClearAll,
  clearAllLabel = "Clear all",
  actions,
  className,
}: FilterBarProps) {
  return (
    <div
      className={cn(
        "flex flex-col sm:flex-row sm:items-center gap-3",
        className
      )}
    >
      {/* Search */}
      {onSearchChange !== undefined && (
        <div className="relative shrink-0">
          <Search
            size={15}
            strokeWidth={1.5}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)] pointer-events-none"
          />
          <Input
            type="text"
            value={searchValue ?? ""}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={searchPlaceholder}
            className="pl-9 w-full sm:w-56 text-sm"
          />
        </div>
      )}

      {/* Chips */}
      {chips && chips.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto hide-scrollbar flex-1 min-w-0">
          {chips.map((chip) => {
            const isActive = activeChip === chip.key
            return (
              <button
                key={chip.key}
                type="button"
                onClick={() => onChipChange?.(chip.key)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-pill px-3 h-8 text-xs font-semibold whitespace-nowrap transition-colors select-none",
                  "border focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
                  isActive
                    ? "bg-primary text-white border-primary"
                    : "bg-[var(--color-surface)] text-[var(--color-text-secondary)] border-[var(--color-border-default)] hover:border-primary hover:text-[var(--color-text-primary)]"
                )}
                aria-pressed={isActive}
              >
                {chip.label}
                {chip.count !== undefined && (
                  <span
                    className={cn(
                      "inline-flex items-center justify-center rounded-full min-w-[18px] h-[18px] px-1 text-xs font-bold leading-none",
                      isActive
                        ? "bg-white/20 text-white"
                        : "bg-[var(--color-surface-raised)] text-[var(--color-text-muted)]"
                    )}
                  >
                    {chip.count}
                  </span>
                )}
              </button>
            )
          })}
        </div>
      )}

      {/* Sort */}
      {sortOptions && sortOptions.length > 0 && onSortChange && (
        <div className="shrink-0 sm:ml-auto">
          <select
            value={sortValue ?? ""}
            onChange={(e) => onSortChange(e.target.value)}
            className={cn(
              "h-9 rounded-input px-3 pr-8 text-sm",
              "bg-[var(--color-surface)] text-[var(--color-text-primary)]",
              "border-[1.5px] border-[var(--color-border-default)]",
              "focus:outline-none focus:border-primary focus:[box-shadow:var(--focus-ring-primary)]",
              "cursor-pointer appearance-none",
              "bg-[image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E\")] bg-no-repeat bg-[right_10px_center]"
            )}
          >
            {sortOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Clear all */}
      {showClearAll && onClearAll && (
        <button
          type="button"
          onClick={onClearAll}
          className={cn(
            "shrink-0 text-xs font-semibold text-[var(--color-text-muted)] underline decoration-dotted underline-offset-2",
            "hover:text-[var(--color-text-primary)] focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
            !sortOptions?.length && "sm:ml-auto"
          )}
        >
          {clearAllLabel}
        </button>
      )}

      {/* Result summary */}
      {resultSummary !== undefined && (
        <span className="shrink-0 whitespace-nowrap text-xs text-[var(--color-text-muted)]">
          {resultSummary}
        </span>
      )}

      {/* Actions */}
      {actions !== undefined && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  )
}
