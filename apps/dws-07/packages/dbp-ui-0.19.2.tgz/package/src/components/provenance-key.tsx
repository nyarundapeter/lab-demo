import * as React from "react"
import { cn } from "../lib/cn.js"
import { ProvTag, PROV_LABEL } from "./prov-tag.js"
import type { AiProvenance } from "@dbp/contracts"

const ALL_PROVENANCE: AiProvenance[] = ["source", "calc", "ai", "predict", "human", "auto"]

export type ProvenanceKeyProps = React.HTMLAttributes<HTMLDivElement>

/**
 * Legend of the full 6-item provenance taxonomy (dash-ai.jsx:6-19) — where a
 * value on screen came from: source data, calculated, AI interpretation, AI
 * prediction, human-confirmed, or automated. Reuses ProvTag/PROV_LABEL
 * rather than a separate divergent vocabulary.
 */
export function ProvenanceKey({ className, ...props }: ProvenanceKeyProps) {
  return (
    <div className={cn("flex flex-wrap items-center gap-x-3.5 gap-y-1.5", className)} {...props}>
      {ALL_PROVENANCE.map((p) => (
        <ProvTag key={p} provenance={p}>
          {PROV_LABEL[p]}
        </ProvTag>
      ))}
    </div>
  )
}
