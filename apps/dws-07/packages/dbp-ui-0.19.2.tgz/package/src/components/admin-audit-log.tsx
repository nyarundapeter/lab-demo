"use client"

import * as React from "react"
import { useActivityFeed } from "@dbp/ps-audit/client"
import { Badge } from "./badge.js"
import { EmptyState } from "./empty-state.js"
import { ErrorState } from "./error-state.js"
import { SegmentedControl } from "./segmented-control.js"

/* ─── AdminAuditLog ──────────────────────────────────────────────────────
 * Security Logs (admin/security-logs) — real PS.AUDIT data (useActivityFeed,
 * all-tenant view), replacing the generic KpiScorecard+ChartPanel analytics
 * placeholder (design-audit-2026-07-17 P1c item 2: that page was mislabeled
 * "security logs" while rendering fake capability-status charts). A
 * reverse-chronological table — actor, action, target, timestamp, plus a
 * derived severity tone — with an action-type filter and a time-window filter.
 * Honest-empty state when the feed is sparse; no fabricated rows.
 * ─────────────────────────────────────────────────────────────────────── */

const TIME_WINDOWS = [
  { value: "all", label: "All time" },
  { value: "24h", label: "24h" },
  { value: "7d", label: "7d" },
  { value: "30d", label: "30d" },
]

/** Derives a Badge tone from the action verb — AuditEvent carries no severity field. */
function actionTone(action: string): "danger" | "warning" | "info" | "gray" {
  if (/fail|denied|reject|error/.test(action)) return "danger"
  if (/role|permission|settings|sso|assign/.test(action)) return "warning"
  if (/login|logout|session/.test(action)) return "info"
  return "gray"
}

function withinWindow(ts: string, window: string): boolean {
  if (window === "all") return true
  const ms = Date.now() - new Date(ts).getTime()
  const days = { "24h": 1, "7d": 7, "30d": 30 }[window] ?? 0
  return ms <= days * 24 * 60 * 60 * 1000
}

export function AdminAuditLog() {
  const { events, isLoading, error } = useActivityFeed(undefined, { limit: 100 })
  const [actionFilter, setActionFilter] = React.useState("all")
  const [windowFilter, setWindowFilter] = React.useState("all")

  const actionOptions = React.useMemo(() => {
    const actions = Array.from(new Set(events.map((e) => e.action))).sort()
    return [{ value: "all", label: "All actions" }, ...actions.map((a) => ({ value: a, label: a }))]
  }, [events])

  const filtered = events
    .filter((e) => actionFilter === "all" || e.action === actionFilter)
    .filter((e) => withinWindow(e.ts, windowFilter))
    .sort((a, b) => new Date(b.ts).getTime() - new Date(a.ts).getTime())

  if (isLoading) {
    return <p className="text-sm text-[var(--color-text-secondary)] py-6">Loading audit log…</p>
  }
  if (error) {
    return <ErrorState title="Failed to load audit log" error={error instanceof Error ? error : new Error(String(error))} />
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <SegmentedControl name="audit-window" options={TIME_WINDOWS} value={windowFilter} onChange={setWindowFilter} />
        <select
          aria-label="Filter by action"
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="h-10 rounded-[var(--radius-pill)] border border-[var(--color-border-subtle)] bg-[var(--color-surface)] px-3 text-sm text-[var(--color-text-primary)]"
        >
          {actionOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="No audit events" description="No matching audit events were recorded for this tenant yet." />
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[var(--color-border-subtle)]">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[var(--color-border-subtle)] bg-[var(--color-surface)]">
                <th className="text-left font-medium px-4 py-2.5 text-[var(--color-text-secondary)]">Actor</th>
                <th className="text-left font-medium px-4 py-2.5 text-[var(--color-text-secondary)]">Action</th>
                <th className="text-left font-medium px-4 py-2.5 text-[var(--color-text-secondary)]">Target</th>
                <th className="text-left font-medium px-4 py-2.5 text-[var(--color-text-secondary)]">Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((event) => (
                <tr key={event.id} className="border-b border-[var(--color-border-subtle)] last:border-0">
                  <td className="px-4 py-2.5 font-medium text-[var(--color-text-primary)]">{event.actor.displayName}</td>
                  <td className="px-4 py-2.5">
                    <Badge tone={actionTone(event.action)}>{event.action}</Badge>
                  </td>
                  <td className="px-4 py-2.5 text-[var(--color-text-secondary)]">
                    {event.target.entityType} · {event.target.entityId}
                  </td>
                  <td className="px-4 py-2.5 text-[var(--color-text-secondary)]">
                    {new Date(event.ts).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
