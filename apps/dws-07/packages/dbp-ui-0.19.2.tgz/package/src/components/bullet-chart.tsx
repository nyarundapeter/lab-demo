import * as React from "react"
import { cn } from "../lib/cn.js"

export interface BulletChartProps {
  value: number
  target: number
  max: number
  /** Bar fill color. Accepts any CSS color, including `var(--token)`. */
  color?: string
  label?: string
  /** Pre-formatted value shown at the right of the label row (e.g. "$42K / $50K"). */
  valueLabel?: string
  className?: string
}

/**
 * Actual-vs-target indicator: a single bar with a target tick mark. Hand-rolled
 * SVG/DOM per the dashboard-system chart-library ruling (2026-07-16) — recharts
 * has no native bullet-chart primitive.
 */
export function BulletChart({
  value,
  target,
  max,
  color = "var(--color-primary)",
  label,
  valueLabel,
  className,
}: BulletChartProps) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100))
  const targetPct = Math.min(100, Math.max(0, (target / max) * 100))

  return (
    <div className={cn("w-full", className)}>
      {(label || valueLabel) && (
        <div className="mb-1 flex items-center justify-between gap-2 text-xs">
          {label && <span>{label}</span>}
          {valueLabel && <span className="tabular-nums">{valueLabel}</span>}
        </div>
      )}
      <div className="relative h-2.5 rounded-[3px] bg-[var(--color-border-subtle)]">
        <div
          className="h-full rounded-[3px]"
          style={{ width: `${pct}%`, background: color }}
        />
        <div
          className="absolute -top-[3px] -bottom-[3px] w-0.5 bg-[var(--color-text)]"
          style={{ left: `${targetPct}%` }}
          title="Target"
        />
      </div>
    </div>
  )
}
