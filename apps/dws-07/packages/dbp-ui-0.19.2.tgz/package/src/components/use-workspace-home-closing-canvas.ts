"use client"

import * as React from "react"

type Particle = {
  x: number
  y: number
  vx: number
  vy: number
  r: number
  alpha: number
  pulse: number
}

function readSecondaryRgb(host: HTMLElement): [number, number, number] {
  const probe = document.createElement("span")
  probe.style.color = "var(--color-secondary)"
  probe.style.position = "absolute"
  probe.style.visibility = "hidden"
  host.appendChild(probe)
  const rgb = getComputedStyle(probe).color
  host.removeChild(probe)
  const parts = rgb.match(/\d+/g)?.map(Number) ?? [0, 0, 0]
  return [parts[0] ?? 0, parts[1] ?? 0, parts[2] ?? 0]
}

/**
 * Decorative particle field for `WorkspaceHomeClosing`.
 * Color comes from `--color-secondary` (never a hardcoded client green).
 * No-ops under `prefers-reduced-motion: reduce`.
 */
export function useWorkspaceHomeClosingCanvas(
  canvasRef: React.RefObject<HTMLCanvasElement | null>
) {
  React.useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    if (reduced) {
      canvas.style.display = "none"
      return
    }

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const parent = canvas.parentElement
    if (!parent) return

    let raf = 0
    let disposed = false
    let particles: Particle[] = []
    let width = 0
    let height = 0
    let dpr = 1
    let rgb: [number, number, number] = [0, 0, 0]

    const seed = () => {
      const count = Math.min(120, Math.max(40, Math.floor((width * height) / 18000)))
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        r: 1 + Math.random() * 1.6,
        alpha: 0.15 + Math.random() * 0.35,
        pulse: Math.random() * Math.PI * 2,
      }))
    }

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      width = parent.clientWidth
      height = parent.clientHeight
      canvas.width = Math.max(1, Math.floor(width * dpr))
      canvas.height = Math.max(1, Math.floor(height * dpr))
      canvas.style.width = `${width}px`
      canvas.style.height = `${height}px`
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      rgb = readSecondaryRgb(parent)
      seed()
    }

    const tick = () => {
      if (disposed) return
      ctx.clearRect(0, 0, width, height)
      const [r, g, b] = rgb
      const linkDist = 130

      for (const p of particles) {
        p.x += p.vx
        p.y += p.vy
        if (p.x < 0 || p.x > width) p.vx *= -1
        if (p.y < 0 || p.y > height) p.vy *= -1
        p.x = Math.max(0, Math.min(width, p.x))
        p.y = Math.max(0, Math.min(height, p.y))
        p.pulse += 0.02
        const a = p.alpha * (0.65 + 0.35 * Math.sin(p.pulse))
        ctx.beginPath()
        ctx.fillStyle = `rgba(${r},${g},${b},${a})`
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fill()
      }

      for (let i = 0; i < particles.length; i++) {
        const a = particles[i]!
        for (let j = i + 1; j < particles.length; j++) {
          const bPart = particles[j]!
          const dx = a.x - bPart.x
          const dy = a.y - bPart.y
          const dist = Math.hypot(dx, dy)
          if (dist < linkDist) {
            const lineAlpha = (1 - dist / linkDist) * 0.12
            ctx.beginPath()
            ctx.strokeStyle = `rgba(${r},${g},${b},${lineAlpha})`
            ctx.lineWidth = 1
            ctx.moveTo(a.x, a.y)
            ctx.lineTo(bPart.x, bPart.y)
            ctx.stroke()
          }
        }
      }

      raf = window.requestAnimationFrame(tick)
    }

    const observer = new ResizeObserver(() => resize())
    observer.observe(parent)
    resize()
    raf = window.requestAnimationFrame(tick)

    return () => {
      disposed = true
      window.cancelAnimationFrame(raf)
      observer.disconnect()
    }
  }, [canvasRef])
}
