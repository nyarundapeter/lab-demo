import * as React from "react"
import { ChevronRight } from "lucide-react"
import { cn } from "../lib/cn.js"
import { StatusDot, type StatusDotStatus } from "./status-dot.js"
import { Card } from "./card.js"

export interface HealthStatusCardSubMetric {
  label: string
  value: string | number
}

export interface HealthStatusCardProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string
  status: StatusDotStatus
  headline: string | number
  subMetrics?: HealthStatusCardSubMetric[]
  action?: string
  onClick?: () => void
}

/**
 * Status card for "the health of a thing" — title + status pill, a headline value,
 * an optional row of sub-metrics, and an optional drill-in action
 * (dash-components.jsx:110-131).
 */
export function HealthStatusCard({
  title,
  status,
  headline,
  subMetrics,
  action,
  onClick,
  className,
  ...props
}: HealthStatusCardProps) {
  return (
    <Card
      className={cn("p-[var(--space-card)] flex flex-col gap-2.5", onClick && "cursor-pointer", className)}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      {...props}
    >
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold text-[var(--color-text)]">{title}</span>
        <span className="ml-auto">
          <StatusDot status={status} pill />
        </span>
      </div>

      <div className="font-mono text-2xl font-bold tabular-nums tracking-tight text-[var(--color-text)]">
        {headline}
      </div>

      {subMetrics && subMetrics.length > 0 && (
        <div
          className="grid gap-2 border-t border-[var(--color-border-subtle)] pt-2.5"
          style={{ gridTemplateColumns: `repeat(${subMetrics.length}, 1fr)` }}
        >
          {subMetrics.map((m) => (
            <div key={m.label}>
              <div className="font-mono text-base font-semibold tabular-nums text-[var(--color-text)]">
                {m.value}
              </div>
              <div className="text-xs text-[var(--color-text-muted)]">{m.label}</div>
            </div>
          ))}
        </div>
      )}

      {action && (
        <button type="button" className="inline-flex items-center gap-0.5 self-start text-xs font-medium text-[var(--color-text-primary)]">
          {action}
          <ChevronRight size={12} aria-hidden="true" />
        </button>
      )}
    </Card>
  )
}
