import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { CodeInput } from "../components/code-input.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/CodeInput",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => <CodeInput autoFocus />,
};

export const FourDigits: Story = {
  name: "4 digits",
  render: () => <CodeInput length={4} />,
};

export const ErrorState: Story = {
  name: "Error state",
  render: () => <CodeInput error />,
};

export const Disabled: Story = {
  render: () => <CodeInput disabled />,
};

export const Interactive: Story = {
  render: () => {
    function Demo() {
      const [code, setCode] = React.useState<string | null>(null);
      return (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <CodeInput autoFocus onComplete={setCode} />
          <p style={{ fontSize: 12, color: "var(--color-text-muted)" }}>
            {code ? `Submitted: ${code}` : "Type or paste a 6-digit code…"}
          </p>
        </div>
      );
    }
    return <Demo />;
  },
};
