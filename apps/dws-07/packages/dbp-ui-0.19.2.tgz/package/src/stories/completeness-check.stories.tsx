import type { Meta, StoryObj } from "@storybook/react";
import { CompletenessCheck } from "../components/completeness-check.js";

const meta: Meta<typeof CompletenessCheck> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/CompletenessCheck",
  component: CompletenessCheck,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof CompletenessCheck>;

export const Default: Story = {
  args: {
    items: [
      { ok: true, text: "Customer contact confirmed" },
      { warn: true, text: "SLA date missing", detail: "Required for enterprise accounts", action: "Set date" },
      { text: "Owner not yet assigned", action: "Assign" },
    ],
  },
  render: (args) => (
    <div style={{ maxWidth: 420 }}>
      <CompletenessCheck {...args} />
    </div>
  ),
};
