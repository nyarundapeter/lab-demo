import type { Meta, StoryObj } from "@storybook/react";
import { AiActionCard } from "../components/ai-action-card.js";
import { AiLabel } from "../components/ai-label.js";
import { Badge } from "../components/badge.js";
import { Button } from "../components/button.js";

const meta: Meta<typeof AiActionCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AiActionCard",
  component: AiActionCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AiActionCard>;

/**
 * The base shell used by `DataQualityCard` and `SuggestedAction` — see those
 * components for the fully-composed, domain-specific variants.
 */
export const Default: Story = {
  render: () => (
    <div style={{ maxWidth: 460 }}>
      <AiActionCard
        label={<AiLabel kind="generated" text="AI action" />}
        badge={<Badge tone="warning">Medium risk</Badge>}
        title="Example action title"
        fields={[
          { label: "Records affected", value: "12 of 340" },
          { label: "Owner", value: "Data Engineering" },
        ]}
        footer={
          <div className="flex items-center gap-2">
            <Button type="button" variant="outline" size="sm">
              Apply
            </Button>
            <Button type="button" variant="ghost" size="sm">
              Dismiss
            </Button>
          </div>
        }
      />
    </div>
  ),
};

export const FullWidthFooter: Story = {
  render: () => (
    <div style={{ maxWidth: 420 }}>
      <AiActionCard
        className="rounded-[var(--radius-card)] border border-[var(--color-border-subtle)]"
        bodyClassName="p-3"
        label={<AiLabel kind="recommendation" text="Suggested action" />}
        badge={
          <Badge tone="success" className="ml-auto">
            Low risk
          </Badge>
        }
        title="Example full-width footer"
        fields={[{ label: "Reason", value: "Keyword match" }]}
        footerFullWidth
        footer={
          <Button type="button" variant="outline" size="sm">
            Apply
          </Button>
        }
      />
    </div>
  ),
};
