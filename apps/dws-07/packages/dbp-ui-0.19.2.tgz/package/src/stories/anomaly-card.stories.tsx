import type { Meta, StoryObj } from "@storybook/react";
import { AnomalyCard } from "../components/anomaly-card.js";

const meta: Meta<typeof AnomalyCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AnomalyCard",
  component: AnomalyCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AnomalyCard>;

export const Critical: Story = {
  args: {
    metric: "Checkout error rate",
    detail: "Error rate jumped to 4.8% (baseline 0.3%) in the last hour, concentrated on the payment step.",
    when: "12 min ago",
    severity: "crit",
  },
};

export const Medium: Story = {
  args: {
    metric: "Ticket backlog",
    detail: "Backlog is 22% above the 4-week average for a Tuesday.",
    when: "1 hour ago",
    severity: "med",
  },
};
