import type { Meta, StoryObj } from "@storybook/react";
import { ReadOnlyValue } from "../components/read-only-value.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/ReadOnlyValue",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Populated: Story = {
  render: () => (
    <ReadOnlyValue label="Requested by" value="Priya Sharma" style={{ width: "320px" }} />
  ),
};

export const Empty: Story = {
  render: () => <ReadOnlyValue label="Assigned to" style={{ width: "320px" }} />,
};

export const WithHelperText: Story = {
  render: () => (
    <ReadOnlyValue
      label="Approval status"
      value="Approved"
      helperText="Approved by Finance on 12 Jul 2026."
      style={{ width: "320px" }}
    />
  ),
};

export const SystemValueBadge: Story = {
  name: "System value (Auto badge)",
  render: () => (
    <ReadOnlyValue label="Reference number" value="REQ-2026-0714" badge="Auto" style={{ width: "320px" }} />
  ),
};
