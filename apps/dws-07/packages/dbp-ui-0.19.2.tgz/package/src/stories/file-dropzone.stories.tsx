import type { Meta, StoryObj } from "@storybook/react";
import { FileDropzone } from "../components/file-dropzone.js";

const meta: Meta<typeof FileDropzone> = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/FileDropzone",
  component: FileDropzone,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof FileDropzone>;

export const Default: Story = {
  render: () => (
    <div style={{ width: "420px" }}>
      <FileDropzone />
    </div>
  ),
};

export const WithHelperTextAndAccept: Story = {
  render: () => (
    <div style={{ width: "420px" }}>
      <FileDropzone
        accept=".pdf,.docx"
        helperText="PDF or Word, up to 10MB per file."
        browseLabel="choose files"
      />
    </div>
  ),
};

export const SingleFile: Story = {
  render: () => (
    <div style={{ width: "420px" }}>
      <FileDropzone multiple={false} promptText="Drop a single file here, or" />
    </div>
  ),
};
