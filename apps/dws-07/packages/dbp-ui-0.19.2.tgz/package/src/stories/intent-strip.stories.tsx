import type { Meta, StoryObj } from "@storybook/react";
import { IntentStrip } from "../components/intent-strip.js";

const meta: Meta<typeof IntentStrip> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/IntentStrip",
  component: IntentStrip,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof IntentStrip>;

export const Executive: Story = {
  args: {
    audience: "CxO, board",
    decisions: "Where to invest next quarter",
    questions: "Are we on track against strategy?",
    mode: "Monthly review",
  },
};
