import type { Meta, StoryObj } from "@storybook/react"
import { LandingFooter } from "../components/landing-footer.js"

const meta: Meta<typeof LandingFooter> = {
  title: "Layer 07 — App Scaffolds/Molecules/Public/LandingFooter",
  component: LandingFooter,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj<typeof LandingFooter>

const sampleColumns = [
  {
    heading: "Navigation",
    links: [
      { label: "Orientation", href: "#" },
      { label: "Operating Guide", href: "#" },
      { label: "Marketplace", href: "#" },
      { label: "Dashboard", href: "#" },
    ],
  },
  {
    heading: "Marketplaces",
    links: [
      { label: "Services", href: "#" },
      { label: "Task Templates", href: "#" },
      { label: "Knowledge", href: "#" },
      { label: "Work Directory", href: "#" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "About", href: "#" },
      { label: "Security", href: "#" },
      { label: "Support", href: "#" },
      { label: "Contact", href: "#" },
    ],
  },
]

export const Default: Story = {
  args: {
    productCode: "DWS.01",
    productName: "Work.Space4.0",
    tagline: "A governed execution workspace for digital business teams.",
    columns: sampleColumns,
    legal: "© 2026 DigitalQatalyst. All rights reserved. DWS.01 is a registered product of DigitalQatalyst Pte Ltd.",
  },
}

export const DefaultColumns: Story = {
  name: "Default placeholder columns",
  args: {
    productCode: "DIA.02",
    productName: "AnalyticsOps",
    tagline: "Governed analytics operations for enterprise teams.",
  },
}

export const CustomLegal: Story = {
  args: {
    productCode: "DWS.05",
    productName: "Workflow Management",
    columns: sampleColumns,
    legal: "© 2026 DigitalQatalyst. DWS.05 is in limited preview. All rights reserved.",
  },
}
