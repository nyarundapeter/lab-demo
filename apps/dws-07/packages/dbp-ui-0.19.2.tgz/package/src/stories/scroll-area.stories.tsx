import type { Meta, StoryObj } from "@storybook/react";
import { ScrollArea, ScrollBar } from "../components/scroll-area.js";

const meta: Meta<typeof ScrollArea> = {
  title: "Layer 07 — App Scaffolds/Atoms/Layout/ScrollArea",
  component: ScrollArea,
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj<typeof ScrollArea>;

const tags = [
  "Analytics", "Data Quality", "Business Intelligence", "Machine Learning", "ETL Pipeline",
  "Data Governance", "Reporting", "Visualization", "API Integration", "Real-time", "Batch",
  "Cloud Storage", "Data Warehouse", "Data Lake", "Streaming", "Dashboard",
  "Monitoring", "Alerting", "Compliance", "Security", "Access Control",
];

export const VerticalScroll: Story = {
  name: "Vertical scroll",
  render: () => (
    <ScrollArea className="h-48 w-72 rounded-md border border-[var(--color-border)]">
      <div style={{ padding: "16px" }}>
        <h4 style={{ fontSize: "13px", fontWeight: 600, marginBottom: "12px" }}>Tags</h4>
        {tags.map((tag) => (
          <div
            key={tag}
            style={{
              padding: "8px 0",
              borderBottom: "1px solid var(--color-border)",
              fontSize: "13px",
            }}
          >
            {tag}
          </div>
        ))}
      </div>
    </ScrollArea>
  ),
};

export const HorizontalScroll: Story = {
  name: "Horizontal scroll",
  render: () => (
    <ScrollArea className="w-96 whitespace-nowrap rounded-md border border-[var(--color-border)]">
      <div style={{ display: "flex", gap: "16px", padding: "16px" }}>
        {tags.map((tag) => (
          <div
            key={tag}
            style={{
              display: "inline-flex",
              alignItems: "center",
              padding: "4px 12px",
              borderRadius: "9999px",
              border: "1px solid var(--color-border)",
              fontSize: "12px",
              whiteSpace: "nowrap",
              background: "var(--color-surface)",
            }}
          >
            {tag}
          </div>
        ))}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  ),
};

export const FixedHeight: Story = {
  name: "Fixed height list",
  render: () => (
    <ScrollArea className="h-64 w-80">
      <div style={{ display: "flex", flexDirection: "column" }}>
        {Array.from({ length: 30 }, (_, i) => (
          <div
            key={i}
            style={{
              padding: "10px 16px",
              borderBottom: "1px solid var(--color-border)",
              fontSize: "13px",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <span>Row item {i + 1}</span>
            <span style={{ color: "var(--color-text-muted)", fontSize: "12px" }}>
              {i % 3 === 0 ? "Active" : i % 3 === 1 ? "Pending" : "Inactive"}
            </span>
          </div>
        ))}
      </div>
    </ScrollArea>
  ),
};

export const CodeBlock: Story = {
  name: "Code block",
  render: () => (
    <ScrollArea className="h-48 w-full rounded-md border border-[var(--color-border)] bg-gray-950">
      <pre style={{ padding: "16px", fontSize: "12px", color: "#e5e7eb", margin: 0 }}>
        {`const fetchData = async (endpoint: string) => {
  const response = await fetch(endpoint, {
    method: 'GET',
    headers: {
      'Authorization': \`Bearer \${process.env.API_TOKEN}\`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(\`HTTP error! status: \${response.status}\`);
  }

  const data = await response.json();
  return data;
};

export { fetchData };`}
      </pre>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  ),
};
