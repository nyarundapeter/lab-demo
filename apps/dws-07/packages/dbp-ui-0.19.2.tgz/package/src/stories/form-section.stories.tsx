import type { Meta, StoryObj } from "@storybook/react";
import { FormSection } from "../components/form-section.js";
import { FormField } from "../components/form-field.js";
import { Input } from "../components/input.js";
import { Switch } from "../components/switch.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/FormSection",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <FormSection title="Identity" style={{ width: "480px" }}>
      <FormField label="Organisation name" required>
        <Input defaultValue="Digital Operations Workspace" />
      </FormField>
      <FormField label="Display name" helperText="Shown in the shell header and emails.">
        <Input defaultValue="DWS" />
      </FormField>
    </FormSection>
  ),
};

export const WithDescription: Story = {
  render: () => (
    <FormSection
      title="Preferences"
      description="Workspace-wide defaults applied to all members."
      style={{ width: "480px" }}
    >
      <FormField label="Enable audit logging">
        <Switch defaultChecked />
      </FormField>
    </FormSection>
  ),
};

export const StackedSections: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "32px", width: "480px" }}>
      <FormSection title="Identity">
        <FormField label="Organisation name" required>
          <Input defaultValue="Digital Operations Workspace" />
        </FormField>
      </FormSection>
      <FormSection title="Primary contact">
        <FormField label="Contact email" required>
          <Input type="email" defaultValue="admin@example.com" />
        </FormField>
      </FormSection>
    </div>
  ),
};
