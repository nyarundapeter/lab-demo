import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { RichTextField } from "../components/rich-text-field.js";
import { FormField } from "../components/form-field.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/RichTextField",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

function Controlled({ initial = "" }: { initial?: string }) {
  const [value, setValue] = React.useState(initial);
  return <RichTextField value={value} onChange={setValue} />;
}

export const Default: Story = {
  render: () => (
    <FormField label="Description" style={{ width: "480px" }}>
      <Controlled />
    </FormField>
  ),
};

export const WithValue: Story = {
  name: "With value",
  render: () => (
    <FormField label="Description" style={{ width: "480px" }}>
      <Controlled initial="<p>This standard applies to <strong>all</strong> production workloads.</p><ul><li>Encrypt at rest</li><li>Encrypt in transit</li></ul>" />
    </FormField>
  ),
};

export const ErrorState: Story = {
  name: "Error state",
  render: () => (
    <FormField label="Description" required error="A description is required." style={{ width: "480px" }}>
      <Controlled />
    </FormField>
  ),
};
