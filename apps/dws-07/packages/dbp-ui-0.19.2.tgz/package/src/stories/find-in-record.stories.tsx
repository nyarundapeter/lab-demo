import type { Meta, StoryObj } from "@storybook/react";
import { Mail, Phone, StickyNote } from "lucide-react";
import { FindInRecord, type FindInRecordEntry } from "../components/find-in-record.js";

const ENTRIES: FindInRecordEntry[] = [
  { id: "1", who: "Ava", text: "Sent renewal proposal for Q3 term.", timeLabel: "2h ago", icon: Mail },
  { id: "2", who: "Jon", text: "Called to discuss the renewal timeline — pushed to next week.", timeLabel: "1d ago", icon: Phone },
  { id: "3", who: "Ava", text: "Note: customer wants a shorter renewal cycle going forward.", timeLabel: "3d ago", icon: StickyNote },
  { id: "4", who: "System", text: "Deal stage changed to Renewal.", timeLabel: "5d ago" },
];

const meta: Meta<typeof FindInRecord> = {
  title: "Layer 07 — App Scaffolds/Molecules/Search/FindInRecord",
  component: FindInRecord,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof FindInRecord>;

export const Default: Story = {
  args: { entries: ENTRIES },
  decorators: [(Story) => <div style={{ maxWidth: 480, border: "1px solid var(--color-border-default)", borderRadius: 8 }}><Story /></div>],
};
