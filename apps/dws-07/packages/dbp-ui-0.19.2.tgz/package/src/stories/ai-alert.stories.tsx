import type { Meta, StoryObj } from "@storybook/react";
import { AiAlert, type AiAlertData } from "../components/ai-alert.js";

const meta: Meta<typeof AiAlert> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AiAlert",
  component: AiAlert,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AiAlert>;

const SLA_BREACH: AiAlertData = {
  title: "Predicted SLA breach across 4 open cases",
  detected: "Queue velocity suggests 4 Tier-2 cases will breach first-response within 2 hours.",
  confidence: "high",
  confidenceNote: "Based on inbound rate, current staffing, and elapsed SLA time on the 4 cases.",
  related: "Tier-2 queue",
  evidence: [
    "Inbound rate up 40% vs. the trailing 7-day average for this hour.",
    "Only 2 agents online; 3 typically staffed at this time.",
    "2 of the 4 cases are already at 70% of their SLA window.",
  ],
  action: "Review anomaly",
};

const EXPORT_VOLUME: AiAlertData = {
  title: "Unusual export volume detected on your account",
  detected: "14 large exports in the last hour — well above your normal pattern. This may be worth reviewing.",
  confidence: "medium",
  related: "Audit log",
  evidence: [
    "Your 30-day average is 2 exports/hour.",
    "Exports originated from a single new session.",
  ],
  action: "Review activity",
};

export const Default: Story = {
  render: () => (
    <div style={{ maxWidth: 620 }}>
      <AiAlert data={SLA_BREACH} defaultExpanded />
    </div>
  ),
};

export const Collapsed: Story = {
  render: () => (
    <div style={{ maxWidth: 620 }}>
      <AiAlert data={EXPORT_VOLUME} />
    </div>
  ),
};
