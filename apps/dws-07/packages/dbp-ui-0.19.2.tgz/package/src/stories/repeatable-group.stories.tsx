import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { RepeatableGroup } from "../components/repeatable-group.js";
import { FormField } from "../components/form-field.js";
import { Input } from "../components/input.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/RepeatableGroup",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

interface LineItem {
  team: string;
  contactEmail: string;
}

function Controlled({ initial }: { initial: LineItem[] }) {
  const [items, setItems] = React.useState<LineItem[]>(initial);
  return (
    <RepeatableGroup
      items={items}
      addLabel="Add another team"
      onAdd={() => setItems((prev) => [...prev, { team: "", contactEmail: "" }])}
      onRemove={(index) => setItems((prev) => prev.filter((_, i) => i !== index))}
      renderItem={(item, index) => (
        <div style={{ display: "flex", gap: "12px" }}>
          <FormField label="Affected team" style={{ flex: 1 }}>
            <Input
              value={item.team}
              onChange={(e) =>
                setItems((prev) => prev.map((row, i) => (i === index ? { ...row, team: e.target.value } : row)))
              }
            />
          </FormField>
          <FormField label="Contact email" style={{ flex: 1 }}>
            <Input
              type="email"
              value={item.contactEmail}
              onChange={(e) =>
                setItems((prev) =>
                  prev.map((row, i) => (i === index ? { ...row, contactEmail: e.target.value } : row)),
                )
              }
            />
          </FormField>
        </div>
      )}
    />
  );
}

export const Default: Story = {
  render: () => (
    <div style={{ width: "480px" }}>
      <Controlled initial={[{ team: "", contactEmail: "" }]} />
    </div>
  ),
};

export const WithMultipleRows: Story = {
  name: "With multiple rows",
  render: () => (
    <div style={{ width: "480px" }}>
      <Controlled
        initial={[
          { team: "Engineering", contactEmail: "eng-lead@example.com" },
          { team: "Finance", contactEmail: "finance-lead@example.com" },
        ]}
      />
    </div>
  ),
};
