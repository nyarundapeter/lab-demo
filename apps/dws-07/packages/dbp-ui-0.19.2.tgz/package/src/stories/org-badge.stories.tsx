import type { Meta, StoryObj } from "@storybook/react";
import { OrgBadge } from "../components/org-badge.js";

/**
 * @deprecated `OrgBadge` is now a thin re-export of `OrgIdentityRow` — see
 * "Layer 07 — App Scaffolds/Molecules/Identity/OrgIdentityRow" for the
 * canonical stories. This file only proves the backward-compatible alias
 * still renders.
 */
const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Identity/OrgBadge (deprecated alias)",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const DeprecatedAlias: Story = {
  render: () => <OrgBadge name="Northwind" domain="northwind.example" style={{ width: "280px" }} />,
};
