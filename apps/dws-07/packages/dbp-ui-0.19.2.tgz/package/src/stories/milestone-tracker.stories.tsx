import type { Meta, StoryObj } from "@storybook/react";
import { MilestoneTracker } from "../components/milestone-tracker.js";
import type { StageRow } from "../components/vertical-stage-tracker.js";

const MILESTONES: StageRow[] = [
  {
    id: "beta",
    label: "Beta release",
    status: "done",
    completedAt: "2026-06-20T00:00:00.000Z",
    ownerLabel: "Nadia Rahimi",
  },
  {
    id: "ga",
    label: "General availability",
    status: "active",
    dueAt: "2026-07-30T00:00:00.000Z",
    ownerLabel: "Milo Chen",
    risk: "medium",
    note: "Two integration test suites still red — tracking to slip 2–3 days.",
  },
  {
    id: "sunset-v1",
    label: "Sunset v1 API",
    status: "upcoming",
    dueAt: "2026-09-01T00:00:00.000Z",
    ownerLabel: "Tom Reyes",
    risk: "high",
    note: "Blocked on GA — cannot start until the prior milestone lands.",
  },
];

const meta: Meta<typeof MilestoneTracker> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/MilestoneTracker",
  component: MilestoneTracker,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof MilestoneTracker>;

/** Major checkpoints with target/actual dates, owner, and a slippage risk read. */
export const Default: Story = {
  args: {
    milestones: MILESTONES,
  },
};
