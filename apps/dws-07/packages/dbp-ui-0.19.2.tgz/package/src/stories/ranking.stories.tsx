import type { Meta, StoryObj } from "@storybook/react";
import { Ranking } from "../components/ranking.js";

const meta: Meta<typeof Ranking> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/Ranking",
  component: Ranking,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Ranking>;

export const Leaderboard: Story = {
  args: {
    items: [
      { name: "Amara Chen", value: 128400, avatar: true, delta: 8.2 },
      { name: "Marcus Osei", value: 96200, avatar: true, delta: -2.1 },
      { name: "Priya Singh", value: 84100, avatar: true, delta: 4.6 },
      { name: "Diego Fernandez", value: 71300, avatar: true, delta: 0 },
    ],
    format: (v: number) => `$${(v / 1000).toFixed(0)}K`,
  },
};

export const NoAvatars: Story = {
  args: {
    items: [
      { name: "North region", value: 42 },
      { name: "South region", value: 31 },
      { name: "East region", value: 19 },
    ],
  },
};
