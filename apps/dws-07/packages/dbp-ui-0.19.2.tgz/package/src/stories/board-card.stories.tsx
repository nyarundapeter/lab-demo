import type { Meta, StoryObj } from "@storybook/react"
import React from "react"
import { BoardCard } from "../components/board-card.js"

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/BoardCard",
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj

export const Default: Story = {
  render: () => (
    <div style={{ width: 280 }}>
      <BoardCard
        title="CDD Clarification Request"
        subtitle="Ahmed Al-Mansoori"
        meta="Compliance · Jun 18, 2026"
        badgeTone="danger"
        badgeLabel="High"
      />
    </div>
  ),
}

export const Clickable: Story = {
  render: () => (
    <div style={{ width: 280 }}>
      <BoardCard
        title="Clickable Card"
        subtitle="Ahmed Al-Mansoori"
        badgeTone="info"
        badgeLabel="Medium"
        onClick={() => alert("Card clicked")}
      />
    </div>
  ),
}

export const RiskStatusAvatarAndDueDate: Story = {
  name: "Risk + status chips, avatar, due date",
  render: () => (
    <div style={{ width: 280 }}>
      <BoardCard
        title="Aurora Health Labs — diagnostics supply agreement renewal"
        meta="Aurora Health Labs · Healthcare"
        badgeTone="danger"
        badgeLabel="High risk"
        secondaryBadgeTone="gray"
        secondaryBadgeLabel="Docs pending"
        assigneeName="Kiran Patel"
        dueLabel="Jul 5"
        overdue
      />
    </div>
  ),
}

export const Unassigned: Story = {
  render: () => (
    <div style={{ width: 280 }}>
      <BoardCard
        title="Vertex Consulting Group"
        meta="Vertex Consulting · Prof. Services"
        badgeTone="gray"
        badgeLabel="Medium"
        secondaryBadgeTone="gray"
        secondaryBadgeLabel="Screening"
        dueLabel="Jul 18"
      />
    </div>
  ),
}

export const LockedComplianceHold: Story = {
  render: () => (
    <div style={{ width: 280 }}>
      <BoardCard
        title="Nova Robotics"
        meta="Nova Robotics · Industrial"
        badgeTone="danger"
        badgeLabel="High risk"
        secondaryBadgeTone="gray"
        secondaryBadgeLabel="Pending approval"
        assigneeName="Amara Reyes"
        dueLabel="Jul 7"
        locked
      />
    </div>
  ),
}

export const TagsAndGradedDueTiers: Story = {
  name: "#Tag chips + graded due-date tiers",
  render: () => (
    <div className="flex flex-col gap-3">
      <div style={{ width: 280 }}>
        <BoardCard
          title="Aurora Health Labs renewal"
          subtitle="Kiran Patel"
          tags={["compliance", "renewal"]}
          dueLabel="Jun 20"
          dueTier="overdue"
        />
      </div>
      <div style={{ width: 280 }}>
        <BoardCard title="Ironclad Security review" subtitle="Amara Reyes" tags={["security"]} dueLabel="Due today" dueTier="today" />
      </div>
      <div style={{ width: 280 }}>
        <BoardCard title="Copperline onboarding" subtitle="Mei Tan" dueLabel="2d" dueTier="soon" />
      </div>
      <div style={{ width: 280 }}>
        <BoardCard title="Vertex Consulting intake" subtitle="Amara Reyes" dueLabel="No date" dueTier="none" />
      </div>
    </div>
  ),
}
