import type { Meta, StoryObj } from "@storybook/react"
import { MeshSection } from "../components/mesh-section.js"

const meta: Meta<typeof MeshSection> = {
  title: "Layer 07 — App Scaffolds/Molecules/Public/MeshSection",
  component: MeshSection,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj<typeof MeshSection>

const Demo = () => (
  <div className="mx-auto max-w-[1200px] px-8 py-20 text-center">
    <h2 className="text-3xl font-semibold text-primary">Mesh band content</h2>
    <p className="mt-4 text-base text-[var(--color-text-secondary)]">
      This is placeholder content rendered inside a MeshSection band.
    </p>
  </div>
)

export const HeroLight: Story = {
  args: { variant: "heroLight", children: <Demo /> },
}

export const HeroDark: Story = {
  args: { variant: "heroDark", children: <Demo /> },
}

export const CtaOrange: Story = {
  args: { variant: "ctaOrange", children: <Demo /> },
}

export const WithGrid: Story = {
  args: { variant: "heroLight", grid: true, children: <Demo /> },
}
