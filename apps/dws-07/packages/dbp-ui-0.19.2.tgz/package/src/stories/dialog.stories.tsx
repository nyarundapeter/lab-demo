import type { Meta, StoryObj } from "@storybook/react";
import { Button } from "../components/button.js";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogBody,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "../components/dialog.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Overlays/Dialog",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="navy">Open dialog</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Confirm action</DialogTitle>
          <DialogDescription>This action cannot be undone. Are you sure?</DialogDescription>
        </DialogHeader>
        <DialogBody>
          <p style={{ color: "var(--color-text-secondary)", fontSize: "0.875rem" }}>
            Body content goes here — forms, details, etc.
          </p>
        </DialogBody>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="ghost">Cancel</Button>
          </DialogClose>
          <Button variant="orange">Confirm</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  ),
};

export const Large: Story = {
  render: () => (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">Open large</Button>
      </DialogTrigger>
      <DialogContent size="lg">
        <DialogHeader>
          <DialogTitle>Large dialog</DialogTitle>
        </DialogHeader>
        <DialogBody>
          <p style={{ color: "var(--color-text-muted)", fontSize: "0.875rem" }}>
            Use size=&quot;lg&quot; for wider content — e.g. wizard steps, record editors.
          </p>
        </DialogBody>
        <DialogFooter>
          <Button variant="orange">Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  ),
};

const SIZES: { size: "sm" | "default" | "lg" | "xl" | "full"; label: string; px: string }[] = [
  { size: "sm", label: "sm", px: "400px" },
  { size: "default", label: "default", px: "520px" },
  { size: "lg", label: "lg", px: "720px" },
  { size: "xl", label: "xl", px: "960px" },
  { size: "full", label: "full", px: "calc(100vw - 2rem)" },
];

export const AllSizes: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
      {SIZES.map(({ size, label, px }) => (
        <Dialog key={size}>
          <DialogTrigger asChild>
            <Button variant="outline">
              {label} ({px})
            </Button>
          </DialogTrigger>
          <DialogContent size={size}>
            <DialogHeader>
              <DialogTitle>size=&quot;{label}&quot;</DialogTitle>
              <DialogDescription>max-width: {px}</DialogDescription>
            </DialogHeader>
            <DialogBody>
              <div
                style={{
                  height: "1rem",
                  width: "100%",
                  background:
                    "repeating-linear-gradient(90deg, var(--color-navy-200) 0 1px, transparent 1px 40px)",
                }}
                aria-hidden="true"
              />
              <p style={{ color: "var(--color-text-muted)", fontSize: "0.875rem", marginTop: "0.5rem" }}>
                Ruler ticks every 40px — content width matches the modal&apos;s max-width.
              </p>
            </DialogBody>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="ghost">Close</Button>
              </DialogClose>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      ))}
    </div>
  ),
};
