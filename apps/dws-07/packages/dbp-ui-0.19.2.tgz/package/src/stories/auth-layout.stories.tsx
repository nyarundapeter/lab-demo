import type { Meta, StoryObj } from "@storybook/react";
import { AuthLayout } from "../components/auth-layout.js";

const meta: Meta<typeof AuthLayout> = {
  title: "Layer 07 — App Scaffolds/Templates/AuthLayout",
  component: AuthLayout,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AuthLayout>;

export const Default: Story = {
  args: {
    headline: "You've been invited to Northwind Labs.",
    subtitle: "Set up your account to start collaborating with your team in a single secure workspace.",
    features: [
      "SSO, SCIM provisioning and audit logs",
      "Granular roles and workspace isolation",
      "Enterprise-grade security by default",
    ],
    quote: {
      text: "Onboarding a new region used to take a week. With Northwind it's an afternoon.",
      attribution: "Operations Director, Meridian Foods",
    },
    children: (
      <div className="text-center">
        <h2 className="text-lg font-semibold text-primary">Join Northwind Labs</h2>
        <p className="mt-2 text-sm text-[var(--color-text-muted)]">Credential card content goes here.</p>
      </div>
    ),
  },
};

/** No features/quote — the shortest valid card content. */
export const Minimal: Story = {
  args: {
    headline: "Reset your password",
    children: (
      <div className="text-center text-sm text-[var(--color-text-muted)]">Reset form content goes here.</div>
    ),
  },
};
