import type { Meta, StoryObj } from "@storybook/react";
import { AiConfidence } from "../components/ai-confidence.js";

const meta: Meta<typeof AiConfidence> = {
  title: "Layer 07 — App Scaffolds/Atoms/Indicators/AiConfidence",
  component: AiConfidence,
  tags: ["autodocs"],
  argTypes: {
    level: {
      control: "select",
      options: ["high", "medium", "low", "insufficient"],
    },
    note: { control: "text" },
    inline: { control: "boolean" },
  },
  args: {
    level: "high",
    note: "Based on inbound rate, current staffing, and elapsed SLA time on the 4 cases.",
    inline: false,
  },
};
export default meta;
type Story = StoryObj<typeof AiConfidence>;

export const Default: Story = {};

export const Medium: Story = {
  args: { level: "medium", note: "Fewer historical samples than usual for this window." },
};

export const Low: Story = {
  args: { level: "low", note: undefined },
};

export const Insufficient: Story = {
  args: { level: "insufficient", note: undefined },
};

export const Inline: Story = {
  args: { level: "high", inline: true },
};

export const AllLevels: Story = {
  name: "All levels (side by side)",
  render: () => (
    <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
      <AiConfidence level="high" />
      <AiConfidence level="medium" />
      <AiConfidence level="low" />
      <AiConfidence level="insufficient" />
    </div>
  ),
};
