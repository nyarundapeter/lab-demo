import type { Meta, StoryObj } from "@storybook/react";
import { FieldLabel } from "../components/field-label.js";

const meta: Meta<typeof FieldLabel> = {
  title: "Layer 07 — App Scaffolds/Atoms/FieldLabel",
  component: FieldLabel,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof FieldLabel>;

export const Default: Story = {
  args: { children: "Company name" },
};

export const Required: Story = {
  args: { children: "Employee ID", required: true },
};

export const Optional: Story = {
  args: { children: "Cost centre", optional: true },
};

export const Disabled: Story = {
  args: { children: "Reseller code", disabled: true },
};

export const Error: Story = {
  args: { children: "Manager email", error: true },
};
