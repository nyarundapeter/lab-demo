import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { SectionHeading } from "./foundations-shared.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Foundations/Typography",
  tags: ["autodocs"],
  parameters: { layout: "fullscreen" },
};
export default meta;
type Story = StoryObj;

const TYPE_SCALE = ["--text-xs", "--text-sm", "--text-base", "--text-lg", "--text-xl", "--text-2xl", "--text-3xl", "--text-4xl"];
const FONT_WEIGHTS: [string, string][] = [
  ["--font-weight-normal", "Normal (400)"],
  ["--font-weight-medium", "Medium (500)"],
  ["--font-weight-semibold", "Semibold (600)"],
  ["--font-weight-bold", "Bold (700)"],
];

export const TypeScale: Story = {
  render: () => (
    <div style={{ padding: 32, background: "var(--color-surface)" }}>
      <section style={{ marginBottom: 32 }}>
        <SectionHeading>Type scale</SectionHeading>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {TYPE_SCALE.map((token) => (
            <div key={token} style={{ display: "flex", alignItems: "baseline", gap: 16 }}>
              <span style={{ width: 110, fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--color-text-muted)" }}>{token}</span>
              <span style={{ fontSize: `var(${token})`, color: "var(--color-text)", fontFamily: "var(--font-sans)" }}>
                The quick brown fox
              </span>
            </div>
          ))}
        </div>
      </section>
      <section>
        <SectionHeading>Font weights</SectionHeading>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {FONT_WEIGHTS.map(([token, label]) => (
            <div key={token} style={{ display: "flex", alignItems: "baseline", gap: 16 }}>
              <span style={{ width: 180, fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--color-text-muted)" }}>
                {token} — {label}
              </span>
              <span style={{ fontSize: "var(--text-lg)", fontWeight: `var(${token})` as React.CSSProperties["fontWeight"], color: "var(--color-text)" }}>
                The quick brown fox
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  ),
};
