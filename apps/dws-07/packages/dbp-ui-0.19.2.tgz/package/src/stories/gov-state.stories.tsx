import type { Meta, StoryObj } from "@storybook/react";
import { GovState, GOV_STATE, type GovStateKind } from "../components/gov-state.js";
import { Button } from "../components/button.js";

const meta: Meta<typeof GovState> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/GovState",
  component: GovState,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof GovState>;

export const AllStates: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "10px", maxWidth: 480 }}>
      {(Object.keys(GOV_STATE) as GovStateKind[]).map((state) => (
        <GovState key={state} state={state} />
      ))}
    </div>
  ),
};

export const WithExplanationAndActions: Story = {
  render: () => (
    <div style={{ maxWidth: 420 }}>
      <GovState
        state="insufficient"
        why="There isn't enough recent activity on this case to generate a reliable summary."
        next="Add at least one update to try again."
        actions={<Button size="sm" variant="outline">Add update</Button>}
      />
    </div>
  ),
};

export const Error: Story = {
  render: () => (
    <div style={{ maxWidth: 420 }}>
      <GovState
        state="error"
        why="The assistant could not complete this request."
        actions={<Button size="sm" variant="outline">Retry</Button>}
      />
    </div>
  ),
};
