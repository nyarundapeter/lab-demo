import type { Meta, StoryObj } from "@storybook/react";
import { FileText, Building2, User } from "lucide-react";
import { Highlight, TypePill, StatusChip, MetaLine } from "../components/search-result-row.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Search/SearchResultRow",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const HighlightExample: Story = {
  name: "Highlight",
  render: () => (
    <p style={{ fontSize: 14 }}>
      <Highlight text="Meridian Foods — Platform renewal Q3" terms={["renewal", "Q3"]} currentIndex={0} />
    </p>
  ),
};

export const TypePillExamples: Story = {
  name: "TypePill",
  render: () => (
    <div style={{ display: "flex", gap: 8 }}>
      <TypePill icon={FileText} label="Deal" />
      <TypePill icon={Building2} label="Account" />
      <TypePill icon={User} label="Contact" />
    </div>
  ),
};

export const StatusChipExamples: Story = {
  name: "StatusChip",
  render: () => (
    <div style={{ display: "flex", gap: 12 }}>
      <StatusChip status="good" />
      <StatusChip status="warn" />
      <StatusChip status="bad" />
      <StatusChip status="neutral" label="Draft" />
    </div>
  ),
};

export const MetaLineExample: Story = {
  name: "MetaLine",
  render: () => (
    <MetaLine
      items={[
        { icon: User, label: "Ava Okafor" },
        { label: "2h ago" },
        { label: "DEAL-4021", mono: true },
      ]}
    />
  ),
};
