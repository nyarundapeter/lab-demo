import type { Meta, StoryObj } from "@storybook/react";
import React from "react";
import { SegmentedControl } from "../components/segmented-control.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/SegmentedControl",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

const viewingOptions = [
  { value: "new", label: "New Joiner" },
  { value: "returning", label: "Returning" },
];

const viewOptions = [
  { value: "list", label: "List" },
  { value: "grid", label: "Grid" },
  { value: "kanban", label: "Kanban" },
];

export const TwoOptions: Story = {
  render: () => {
    const [v, setV] = React.useState("new");
    return <SegmentedControl options={viewingOptions} value={v} onChange={setV} name="viewing-mode" />;
  },
};

export const ThreeOptions: Story = {
  render: () => {
    const [v, setV] = React.useState("list");
    return <SegmentedControl options={viewOptions} value={v} onChange={setV} name="view-mode" />;
  },
};
