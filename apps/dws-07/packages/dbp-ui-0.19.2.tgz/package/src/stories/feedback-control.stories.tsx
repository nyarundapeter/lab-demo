import type { Meta, StoryObj } from "@storybook/react";
import { FeedbackControl } from "../components/feedback-control.js";

const meta: Meta<typeof FeedbackControl> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/FeedbackControl",
  component: FeedbackControl,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof FeedbackControl>;

export const Default: Story = {
  render: () => <FeedbackControl />,
};

export const Compact: Story = {
  render: () => <FeedbackControl compact />,
};
