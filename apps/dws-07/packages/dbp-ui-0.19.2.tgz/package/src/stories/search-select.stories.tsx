import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { SearchSelect } from "../components/search-select.js";
import { FormField } from "../components/form-field.js";
import { Avatar } from "../components/avatar.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/SearchSelect",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

const DEPARTMENT_OPTIONS = [
  { value: "eng", label: "Engineering", description: "Builds and ships product." },
  { value: "sales", label: "Sales" },
  { value: "finance-dept", label: "Finance" },
  { value: "support", label: "Support" },
];

const USER_OPTIONS = [
  { value: "u1", label: "Ana García", icon: <Avatar name="Ana García" size="sm" /> },
  { value: "u2", label: "Ben Okafor", icon: <Avatar name="Ben Okafor" size="sm" /> },
  { value: "u3", label: "Chen Wei", icon: <Avatar name="Chen Wei" size="sm" /> },
];

function Controlled(props: Omit<React.ComponentProps<typeof SearchSelect>, "value" | "onValueChange">) {
  const [value, setValue] = React.useState<string | undefined>(undefined);
  return <SearchSelect {...props} value={value} onValueChange={setValue} />;
}

export const Default: Story = {
  render: () => (
    <FormField label="Department" style={{ width: "320px" }}>
      <Controlled options={DEPARTMENT_OPTIONS} />
    </FormField>
  ),
};

export const UserPicker: Story = {
  name: "As a user-picker (options carry an avatar icon)",
  render: () => (
    <FormField label="Manager" style={{ width: "320px" }}>
      <Controlled options={USER_OPTIONS} placeholder="Search people…" searchPlaceholder="Search people…" />
    </FormField>
  ),
};

export const ErrorState: Story = {
  name: "Error state",
  render: () => (
    <FormField label="Department" required error="Select a department." style={{ width: "320px" }}>
      <Controlled options={DEPARTMENT_OPTIONS} />
    </FormField>
  ),
};

export const NoResults: Story = {
  name: "No results",
  render: () => (
    <FormField label="Department" style={{ width: "320px" }}>
      <SearchSelect options={[]} placeholder="Search…" emptyText="No departments found." />
    </FormField>
  ),
};

export const Disabled: Story = {
  render: () => (
    <FormField label="Department" style={{ width: "320px" }}>
      <SearchSelect options={DEPARTMENT_OPTIONS} value="eng" disabled />
    </FormField>
  ),
};
