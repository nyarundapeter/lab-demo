import type { Meta, StoryObj } from "@storybook/react";
import { Breadcrumb } from "../components/breadcrumb.js";

/**
 * Breadcrumb renders as a DQ "eyebrow trail": JetBrains Mono, uppercase, wide
 * tracking, orange separators, with the active (last) crumb in orange.
 */
const meta: Meta<typeof Breadcrumb> = {
  title: "Layer 07 — App Scaffolds/Atoms/Layout/Breadcrumb",
  component: Breadcrumb,
  tags: ["autodocs"],
  decorators: [
    (Story) => (
      <div style={{ padding: "16px", background: "var(--color-surface)" }}>
        <Story />
      </div>
    ),
  ],
};
export default meta;
type Story = StoryObj<typeof Breadcrumb>;

export const ThreeLevel: Story = {
  args: {
    items: [
      { label: "Home", href: "/" },
      { label: "Catalog", href: "/catalog" },
      { label: "Knowledge KA-GL-001" },
    ],
  },
};

export const TwoLevel: Story = {
  args: {
    items: [
      { label: "Settings", href: "/settings" },
      { label: "Notifications" },
    ],
  },
};

export const Single: Story = {
  args: { items: [{ label: "Dashboard" }] },
};
