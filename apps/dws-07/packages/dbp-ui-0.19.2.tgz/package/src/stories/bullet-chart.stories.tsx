import type { Meta, StoryObj } from "@storybook/react";
import { BulletChart } from "../components/bullet-chart.js";

const meta: Meta<typeof BulletChart> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/BulletChart",
  component: BulletChart,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof BulletChart>;

export const Default: Story = {
  args: { value: 72, target: 85, max: 100, label: "Revenue", valueLabel: "$72K / $85K" },
};

export const AboveTarget: Story = {
  args: {
    value: 92,
    target: 85,
    max: 100,
    color: "var(--color-success)",
    label: "Revenue",
    valueLabel: "$92K / $85K",
  },
};

export const BelowTarget: Story = {
  args: {
    value: 40,
    target: 85,
    max: 100,
    color: "var(--color-danger)",
    label: "Revenue",
    valueLabel: "$40K / $85K",
  },
};

export const NoLabel: Story = { args: { value: 60, target: 75, max: 100 } };

export const Stack: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px", width: "320px" }}>
      <BulletChart value={72} target={85} max={100} label="Revenue" valueLabel="$72K / $85K" />
      <BulletChart
        value={92}
        target={85}
        max={100}
        color="var(--color-success)"
        label="Bookings"
        valueLabel="92 / 85"
      />
      <BulletChart
        value={40}
        target={85}
        max={100}
        color="var(--color-danger)"
        label="Renewals"
        valueLabel="40 / 85"
      />
    </div>
  ),
};
