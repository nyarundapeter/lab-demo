import type { Meta, StoryObj } from "@storybook/react";
import { ParallelTracker } from "../components/parallel-tracker.js";
import type { ParallelBranch } from "../components/parallel-tracker.js";

const BRANCHES: ParallelBranch[] = [
  { id: "it", label: "IT provisioning", status: "done", percent: 100, ownerLabel: "Ava Okafor", dueLabel: "Jul 10" },
  { id: "security", label: "Security training", status: "active", percent: 40, ownerLabel: "Milo Chen", dueLabel: "Jul 14" },
  { id: "facilities", label: "Facilities badge", status: "blocked", percent: 0, ownerLabel: "Tom Reyes", dueLabel: "Jul 12", note: "Waiting on ID photo upload." },
];

const meta: Meta<typeof ParallelTracker> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/ParallelTracker",
  component: ParallelTracker,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ParallelTracker>;

/** Independent onboarding branches, one blocked, sharing a merge rule. */
export const Default: Story = {
  args: {
    branches: BRANCHES,
    rule: "All branches must complete before day-1 access is granted",
  },
};
