import type { Meta, StoryObj } from "@storybook/react";
import { ProvTag, PROV_LABEL } from "../components/prov-tag.js";
import type { AiProvenance } from "@dbp/contracts";

const meta: Meta<typeof ProvTag> = {
  title: "Layer 07 — App Scaffolds/Atoms/Badge/ProvTag",
  component: ProvTag,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ProvTag>;

export const Source: Story = {
  args: { provenance: "source" },
};

export const AllProvenances: Story = {
  name: "All provenances",
  render: () => (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
      {(Object.keys(PROV_LABEL) as AiProvenance[]).map((provenance) => (
        <ProvTag key={provenance} provenance={provenance} />
      ))}
    </div>
  ),
};
