import type { Meta, StoryObj } from "@storybook/react";
import { MilestoneRow } from "../components/milestone-row.js";

const meta: Meta<typeof MilestoneRow> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/MilestoneRow",
  component: MilestoneRow,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof MilestoneRow>;

export const List: Story = {
  render: () => (
    <div style={{ width: "480px" }}>
      <MilestoneRow
        title="Discovery & scoping"
        phase="Phase 1"
        owner="A. Chen"
        date="Jun 12"
        status="good"
        pct={100}
      />
      <MilestoneRow
        title="Design review"
        phase="Phase 2"
        owner="M. Osei"
        date="Jul 20"
        status="warn"
        pct={62}
      />
      <MilestoneRow
        title="Migration cutover"
        phase="Phase 3"
        owner="R. Singh"
        date="Aug 1"
        status="bad"
        pct={18}
        late
      />
    </div>
  ),
};
