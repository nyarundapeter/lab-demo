import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { User } from "lucide-react";
import { FilterPillPopover } from "../components/filter-pill-popover.js";
import { Input } from "../components/input.js";

const meta: Meta<typeof FilterPillPopover> = {
  title: "Layer 07 — App Scaffolds/Molecules/Overlays/FilterPillPopover",
  component: FilterPillPopover,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof FilterPillPopover>;

const USERS = ["Ava Okafor", "Jordan Reyes", "Priya Nair"];

export const AssignOwnerMiniForm: Story = {
  name: "Mini form — assign owner",
  render: () => {
    const [owner, setOwner] = React.useState<string | null>(null);
    return (
      <FilterPillPopover label={owner ?? "Assign"} icon={User} active={!!owner}>
        <div className="flex flex-col gap-2">
          <Input placeholder="Search people…" autoFocus />
          {USERS.map((u) => (
            <button
              key={u}
              type="button"
              className="rounded-[var(--radius-button)] px-2 py-1.5 text-left text-sm hover:bg-[var(--color-navy-50)]"
              onClick={() => setOwner(u)}
            >
              {u}
            </button>
          ))}
        </div>
      </FilterPillPopover>
    );
  },
};
