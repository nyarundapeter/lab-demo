import type { Meta, StoryObj } from "@storybook/react";
import { SevChip } from "../components/sev-chip.js";

const meta: Meta<typeof SevChip> = {
  title: "Layer 07 — App Scaffolds/Atoms/Badge/SevChip",
  component: SevChip,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof SevChip>;

export const Info: Story = { args: { severity: "info" } };
export const Success: Story = { args: { severity: "success" } };
export const Warning: Story = { args: { severity: "warning" } };
export const Error: Story = { args: { severity: "error" } };
export const Critical: Story = { args: { severity: "critical" } };

export const AllSeverities: Story = {
  name: "All severities (5-level taxonomy)",
  render: () => (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
      <SevChip severity="info" />
      <SevChip severity="success" />
      <SevChip severity="warning" />
      <SevChip severity="error" />
      <SevChip severity="critical" />
    </div>
  ),
};
