import type { Meta, StoryObj } from "@storybook/react";
import { Inbox, FolderOpen, SearchX, Lock } from "lucide-react";
import { EmptyState } from "../components/empty-state.js";
import { Button } from "../components/button.js";

const meta: Meta<typeof EmptyState> = {
  title: "Layer 07 — App Scaffolds/Molecules/Feedback & State/EmptyState",
  component: EmptyState,
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj<typeof EmptyState>;

export const Default: Story = {
  args: {
    icon: <Inbox size={24} strokeWidth={1.5} />,
    title: "Nothing here yet",
    description: "Once items are added they will appear here.",
  },
};

export const WithActionButton: Story = {
  args: {
    icon: <FolderOpen size={24} strokeWidth={1.5} />,
    title: "No projects found",
    description: "Get started by creating your first project.",
    action: <Button size="sm">Create project</Button>,
  },
};

export const NoIcon: Story = {
  args: {
    title: "No results",
    description: "Try adjusting your search or filter criteria.",
  },
};

export const SearchEmpty: Story = {
  args: {
    icon: <SearchX size={24} strokeWidth={1.5} />,
    title: "No results found",
    description: "We couldn't find anything matching your search. Try different keywords.",
    action: <Button variant="outline" size="sm">Clear search</Button>,
  },
};

export const Compact: Story = {
  args: {
    icon: <Inbox size={20} strokeWidth={1.5} />,
    title: "Empty",
    description: "Nothing to display.",
    className: "py-8",
  },
};

// ─── New headline API stories ──────────────────────────────────────────────

export const HeadlineOnly: Story = {
  args: { headline: "No tasks found" },
};

export const HeadlineWithDescription: Story = {
  args: {
    headline: "No invoices yet",
    description: "Create your first invoice to get started.",
  },
};

export const HeadlineWithActionObject: Story = {
  args: {
    headline: "No records",
    action: { label: "Create Record", onClick: () => {} },
  },
};

export const HeadlineFull: Story = {
  args: {
    headline: "Nothing here",
    description: "Add something to see it here.",
    action: { label: "Add Item", onClick: () => {} },
  },
};

/**
 * Restricted-access presentation — reuses EmptyState directly (lock icon,
 * "Access restricted" headline, request-access CTA). The reference's dashed
 * border treatment is applied via `className`; no new component needed.
 */
export const Restricted: Story = {
  args: {
    icon: <Lock size={22} strokeWidth={1.5} />,
    headline: "Access restricted",
    description: "You do not have permission to view this configuration area.",
    action: { label: "Request access", onClick: () => {} },
    className: "border border-dashed border-border-default rounded-lg",
  },
};

// ─── Danger tone (absorbs the former ErrorState component) ────────────────

export const DangerTone: Story = {
  name: "Danger tone (absorbs ErrorState)",
  args: {
    tone: "danger",
    description: "The record could not be loaded. Try again in a moment.",
  },
};

export const DangerToneWithAction: Story = {
  name: "Danger tone with retry action",
  args: {
    tone: "danger",
    headline: "Failed to load record",
    description: "A network error occurred while fetching this record.",
    action: <Button size="sm">Retry</Button>,
  },
};
