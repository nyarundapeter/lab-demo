import * as React from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureRbacClient } from "@dbp/ps-rbac/client";

/* Shared mock PS.RBAC wiring for the admin RBAC component stories
 * (AdminUserList / AdminRoleList / AdminAccessMatrix). Route-aware fetch
 * mock over configureRbacClient — no real service required. */

export const MOCK_MATRIX = {
  roles: [
    { id: "platform-admin", label: "Platform Admin" },
    { id: "approver", label: "Approver", tenantId: "tenant-alpha" },
    { id: "viewer", label: "Viewer", tenantId: "tenant-alpha" },
  ],
  permissions: [
    { resource: "record", action: "record.read", description: "View records" },
    { resource: "record", action: "record.write", description: "Create and edit records" },
    { resource: "workflow", action: "workflow.approve", description: "Approve workflow steps" },
  ],
  matrix: [
    { role: "platform-admin", resource: "record", action: "record.read" },
    { role: "platform-admin", resource: "record", action: "record.write" },
    { role: "platform-admin", resource: "workflow", action: "workflow.approve" },
    { role: "approver", resource: "record", action: "record.read" },
    { role: "approver", resource: "workflow", action: "workflow.approve" },
    { role: "viewer", resource: "record", action: "record.read" },
  ],
};

export const EMPTY_MATRIX = { roles: [], permissions: [], matrix: [] };

function json(body: unknown, status = 200): Promise<Response> {
  return Promise.resolve(
    new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } }),
  );
}

export function makeRbacFetch(kind: "populated" | "empty" | "error" | "pending") {
  return (input: RequestInfo | URL): Promise<Response> => {
    if (kind === "pending") return new Promise<Response>(() => {});
    if (kind === "error") return json({ error: "PS.RBAC unavailable" }, 500);
    const url = String(input);
    if (/\/admin\/users\/[^/]+\/roles/.test(url)) {
      if (kind === "empty") return json({ roles: [] });
      return json({
        roles: url.includes("user-admin")
          ? [{ roleId: "platform-admin", userId: "user-admin", tenantId: "tenant-alpha" }]
          : [{ roleId: "viewer", userId: "user-01", tenantId: "tenant-alpha" }],
      });
    }
    return json(kind === "empty" ? EMPTY_MATRIX : MOCK_MATRIX);
  };
}

export function RbacStoryProvider({
  kind,
  children,
}: {
  kind: "populated" | "empty" | "error" | "pending";
  children: React.ReactNode;
}) {
  const qc = React.useMemo(
    () => new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } }),
    [],
  );
  configureRbacClient({ baseUrl: "http://mock.test/api/platform/rbac", fetch: makeRbacFetch(kind) });
  return <QueryClientProvider client={qc}>{children}</QueryClientProvider>;
}
