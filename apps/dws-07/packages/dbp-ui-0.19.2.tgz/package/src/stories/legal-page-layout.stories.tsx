import type { Meta, StoryObj } from "@storybook/react"
import { LegalPageLayout } from "../components/legal-page-layout.js"

const meta: Meta<typeof LegalPageLayout> = {
  title: "Layer 07 — App Scaffolds/Templates/LegalPageLayout",
  component: LegalPageLayout,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj<typeof LegalPageLayout>

export const Terms: Story = {
  args: {
    eyebrow: "LEGAL",
    title: "Terms of Use",
    subtitle: "The terms governing your use of this platform.",
    lastUpdated: "June 2026",
    contactEmail: "info@digitalqatalyst.com",
    sections: [
      {
        id: "agreement",
        heading: "1. Agreement to These Terms",
        body: [
          "By accessing this platform, you agree to be bound by these Terms of Use.",
          "If you do not agree to these terms, you may not access or use the platform.",
        ],
      },
      {
        id: "use",
        heading: "2. Permitted Use",
        body: [
          "You may use the platform only for lawful purposes and in accordance with these Terms.",
          "You must not use the platform in any way that violates applicable laws or regulations.",
        ],
      },
      {
        id: "ip",
        heading: "3. Intellectual Property",
        body: [
          "The platform and its original content, features, and functionality are owned by Digital Qatalyst and are protected by applicable intellectual property laws.",
        ],
      },
      {
        id: "contact",
        heading: "4. Contact Us",
        body: [
          "Questions about these Terms can be directed to info@digitalqatalyst.com.",
        ],
      },
    ],
  },
}

export const Privacy: Story = {
  args: {
    eyebrow: "LEGAL",
    title: "Privacy Policy",
    subtitle: "How we collect, use, and protect your personal data.",
    lastUpdated: "June 2026",
    contactEmail: "privacy@digitalqatalyst.com",
    sections: [
      {
        id: "collection",
        heading: "1. Data We Collect",
        body: [
          "We collect information you provide directly to us, such as when you create an account or submit a contact form.",
          "We may also collect usage data automatically through cookies and similar technologies.",
        ],
      },
      {
        id: "use",
        heading: "2. How We Use Your Data",
        body: [
          "We use your data to operate and improve the platform, respond to your inquiries, and send service-related communications.",
        ],
      },
      {
        id: "contact",
        heading: "3. Contact for Privacy Queries",
        body: [
          "For privacy-related inquiries, email privacy@digitalqatalyst.com.",
        ],
      },
    ],
  },
}
