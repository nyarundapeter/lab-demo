import type { Meta, StoryObj } from "@storybook/react";
import { EscalationCard } from "../components/escalation-card.js";

const meta: Meta<typeof EscalationCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/EscalationCard",
  component: EscalationCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof EscalationCard>;

export const SlaBreach: Story = {
  args: {
    variant: "sla",
    title: "Review step overdue",
    detail: "The review step has exceeded its 90-minute SLA by 22 minutes.",
    escalatedTo: "Finance Lead",
    when: "22 min ago",
    onResolve: () => {},
  },
};

export const Manual: Story = {
  args: {
    variant: "manual",
    title: "Escalated by requester",
    detail: "Requester flagged this case as time-sensitive and asked for expedited review.",
    escalatedTo: "Ops Manager",
    when: "1 hour ago",
    onResolve: () => {},
  },
};
