import type { Meta, StoryObj } from "@storybook/react";
import { ActivityStrip, type ActivityStripEvent } from "../components/activity-strip.js";

const meta: Meta<typeof ActivityStrip> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/ActivityStrip",
  component: ActivityStrip,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ActivityStrip>;

const EVENTS: ActivityStripEvent[] = [
  { id: "1", label: "Case summary regenerated", kind: "summary", status: "accepted" },
  { id: "2", label: "Anomaly flagged on EU-West latency", kind: "anomaly", status: "pending" },
  { id: "3", label: "Draft reply written", kind: "draft", status: "edited" },
  { id: "4", label: "Auto-tagged as billing", kind: "auto", status: "automated" },
];

export const Default: Story = {
  render: () => (
    <div style={{ maxWidth: 320 }}>
      <ActivityStrip events={EVENTS} onViewAll={() => {}} />
    </div>
  ),
};

export const LimitOne: Story = {
  render: () => (
    <div style={{ maxWidth: 320 }}>
      <ActivityStrip events={EVENTS} limit={1} onViewAll={() => {}} />
    </div>
  ),
};
