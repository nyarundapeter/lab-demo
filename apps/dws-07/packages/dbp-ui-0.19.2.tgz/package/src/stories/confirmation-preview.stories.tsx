import type { Meta, StoryObj } from "@storybook/react";
import { useState } from "react";
import { ConfirmationPreview } from "../components/confirmation-preview.js";
import { Button } from "../components/button.js";

const meta: Meta<typeof ConfirmationPreview> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/ConfirmationPreview",
  component: ConfirmationPreview,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ConfirmationPreview>;

function Demo() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setOpen(true)}>Apply AI suggestion</Button>
      <ConfirmationPreview
        open={open}
        onOpenChange={setOpen}
        description="Demo — no live mutation path exists yet; confirming closes this dialog."
        fields={[
          { label: "Priority", before: "Medium", after: "High" },
          { label: "Owner", before: "Unassigned", after: "J. Alvarez" },
          { label: "Due date", before: "—", after: "2026-07-24" },
        ]}
        onConfirm={() => setOpen(false)}
      />
    </>
  );
}

export const Default: Story = {
  render: () => <Demo />,
};
