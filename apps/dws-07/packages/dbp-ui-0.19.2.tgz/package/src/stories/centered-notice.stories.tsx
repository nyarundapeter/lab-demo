import type { Meta, StoryObj } from "@storybook/react";
import { Wrench, AlertCircle, Smartphone } from "lucide-react";
import { CenteredNotice } from "../components/centered-notice.js";

const meta: Meta<typeof CenteredNotice> = {
  title: "Layer 07 — App Scaffolds/Molecules/Identity/CenteredNotice",
  component: CenteredNotice,
  tags: ["autodocs"],
  parameters: {
    docs: {
      description: {
        component:
          "Standalone (no app-shell) branded card for whole-app interstitials. Port of `identity-errors.jsx`'s `CenteredNotice`.",
      },
    },
  },
};
export default meta;
type Story = StoryObj<typeof CenteredNotice>;

export const Maintenance: Story = {
  args: {
    icon: Wrench,
    tone: "brand",
    brand: { name: "Workspace" },
    kicker: "SCHEDULED MAINTENANCE",
    title: "We'll be right back",
    children:
      "The workspace is undergoing planned maintenance to improve performance. We expect to be back shortly. Your data is safe.",
    footer: "Follow the status page for live updates",
  },
  render: (args) => (
    <div style={{ height: 420 }}>
      <CenteredNotice {...args} />
    </div>
  ),
};

export const UnsupportedBrowser: Story = {
  args: {
    icon: AlertCircle,
    tone: "warning",
    kicker: "UNSUPPORTED BROWSER",
    title: "Time for an update",
    children:
      "Your browser is a few versions behind and some features won't work correctly. Please update to continue.",
  },
  render: (args) => (
    <div style={{ height: 400 }}>
      <CenteredNotice {...args} />
    </div>
  ),
};

export const UnsupportedViewport: Story = {
  args: {
    icon: Smartphone,
    tone: "neutral",
    kicker: "SCREEN TOO SMALL",
    title: "Best on a larger screen",
    children: "This workspace needs at least 768px of width. Rotate your device or open it on a larger screen.",
  },
  render: (args) => (
    <div style={{ height: 400 }}>
      <CenteredNotice {...args} />
    </div>
  ),
};
