import type { Meta, StoryObj } from "@storybook/react";
import React from "react";
import { Pagination } from "../components/pagination.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Layout & Navigation/Pagination",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

function PaginationDemo({ total = 120, initialPage = 1 }: { total?: number; initialPage?: number }) {
  const [page, setPage] = React.useState(initialPage);
  return (
    <Pagination
      page={page}
      pageSize={10}
      total={total}
      onPageChange={setPage}
      showCaption
    />
  );
}

export const Default: Story = {
  render: () => <PaginationDemo />,
};

export const MidPage: Story = {
  render: () => <PaginationDemo initialPage={6} total={200} />,
};

export const SmallSet: Story = {
  render: () => <PaginationDemo total={30} />,
};

export const WithPageSize: Story = {
  render: () => {
    const [page, setPage] = React.useState(1);
    const [pageSize, setPageSize] = React.useState(10);
    return (
      <Pagination
        page={page}
        pageSize={pageSize}
        total={300}
        onPageChange={setPage}
        onPageSizeChange={(ps) => { setPageSize(ps); setPage(1); }}
        showCaption
      />
    );
  },
};
