import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ConflictBanner } from "../components/conflict-banner.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Feedback & State/ConflictBanner",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

const FIELDS = [
  { field: "status", label: "Status", mine: "Blocked", theirs: "In progress" },
  { field: "priority", label: "Priority", mine: "Critical", theirs: "High" },
];

export const Default: Story = {
  name: "Overwrite permitted",
  render: () => (
    <div className="max-w-lg">
      <ConflictBanner
        updatedByLabel="Priya Shah"
        updatedAtLabel="12s ago"
        fields={FIELDS}
        canOverwrite
        onResolve={(action) => console.log("resolve", action)}
      />
    </div>
  ),
};

export const PermissionDeniedOverwrite: Story = {
  name: "Overwrite denied (no update ability)",
  render: () => (
    <div className="max-w-lg">
      <ConflictBanner
        updatedByLabel="Priya Shah"
        updatedAtLabel="12s ago"
        fields={FIELDS}
        canOverwrite={false}
        onResolve={(action) => console.log("resolve", action)}
      />
    </div>
  ),
};

export const SaveAsNewDisabled: Story = {
  name: "Save-as-new not offered (default off)",
  render: () => (
    <div className="max-w-lg">
      <ConflictBanner
        updatedByLabel="Tomas Berg"
        updatedAtLabel="just now"
        fields={FIELDS}
        canOverwrite
        allowSaveAsNew={false}
        onResolve={(action) => console.log("resolve", action)}
      />
    </div>
  ),
};

export const SaveAsNewEnabled: Story = {
  name: "Save-as-new offered (entity type opted in)",
  render: () => (
    <div className="max-w-lg">
      <ConflictBanner
        updatedByLabel="Tomas Berg"
        updatedAtLabel="just now"
        fields={FIELDS}
        canOverwrite
        allowSaveAsNew
        onResolve={(action) => console.log("resolve", action)}
      />
    </div>
  ),
};
