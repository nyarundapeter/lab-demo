import type { Meta, StoryObj } from "@storybook/react";
import { DashSection } from "../components/dash-section.js";

const meta: Meta<typeof DashSection> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/DashSection",
  component: DashSection,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof DashSection>;

export const Default: Story = {
  args: {
    title: "Portfolio health",
    sub: "Updated 5 min ago",
    children: <p style={{ fontSize: 13 }}>Section content goes here.</p>,
  },
};

export const WithAction: Story = {
  args: {
    title: "Recent activity",
    action: <button type="button" style={{ fontSize: 12 }}>View all</button>,
    children: <p style={{ fontSize: 13 }}>Section content goes here.</p>,
  },
};
