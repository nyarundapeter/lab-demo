import type { Meta, StoryObj } from "@storybook/react";
import { RefineButton } from "../components/refine-button.js";

const meta: Meta<typeof RefineButton> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/RefineButton",
  component: RefineButton,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof RefineButton>;

export const Default: Story = {
  render: () => <RefineButton onRefine={() => {}} />,
};
