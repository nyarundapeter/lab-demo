import type { Meta, StoryObj } from "@storybook/react";
import { CommitteeDecision } from "../components/committee-decision.js";
import type { CommitteeMemberVote } from "../components/committee-decision.js";

const MEMBERS: CommitteeMemberVote[] = [
  { id: "1", name: "Nadia Rahimi", vote: "approve", tag: "Chair" },
  { id: "2", name: "Omar Al-Hashimi", vote: "approve" },
  { id: "3", name: "Jonas Weber", vote: "reject" },
  { id: "4", name: "Leo Fischer", vote: "abstain" },
  { id: "5", name: "Grace Okonkwo", vote: "pending" },
];

const meta: Meta<typeof CommitteeDecision> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/CommitteeDecision",
  component: CommitteeDecision,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof CommitteeDecision>;

/** Quorum reached — 2 for, 1 against, 1 abstain, 1 not yet voted. */
export const Default: Story = {
  args: {
    title: "Change Approval Board",
    subtitle: "REL-243 · Meeting Jul 12, 14:00",
    members: MEMBERS,
    quorum: "4/5",
    quorumMet: true,
    outcomeNote: "Decision recorded by Chair after quorum",
  },
};

/** Quorum not yet met — the badge switches to a warning tone. */
export const QuorumNotMet: Story = {
  args: {
    title: "Change Approval Board",
    subtitle: "REL-244 · Meeting Jul 19, 14:00",
    members: MEMBERS.map((m) => (m.vote === "approve" ? { ...m, vote: "pending" as const } : m)),
    quorum: "2/5",
    quorumMet: false,
  },
};
