import type { CSSProperties, FC, ReactNode } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import {
  AlertTriangle,
  Copy,
  Download,
  RefreshCw,
  Target,
  TrendingUp,
} from "lucide-react";
import { AiSurface, AiSurfaceFacet, CategoryTag, type InsightCategory } from "../components/ai-surface.js";
import { Badge } from "../components/badge.js";
import { Button } from "../components/button.js";
import { CiteRef } from "../components/cite-ref.js";
import { FeedbackControl } from "../components/feedback-control.js";
import { ProvTag } from "../components/prov-tag.js";
import { SourceList } from "../components/source-list.js";

const meta: Meta<typeof AiSurface> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AiSurface",
  component: AiSurface,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AiSurface>;

function MetaSep() {
  return (
    <span
      aria-hidden="true"
      className="inline-block size-[3px] shrink-0 rounded-full bg-[var(--color-text-muted)]/50"
    />
  );
}

/** Insight row — oracle `page-dashboard.jsx` `Line` (icon + text + ProvTag). */
function InsightLine({
  icon: Icon,
  tone,
  children,
}: {
  icon: FC<{ size?: number; strokeWidth?: number; "aria-hidden"?: boolean; style?: CSSProperties }>
  tone: string
  children: ReactNode
}) {
  return (
    <div className="flex items-center gap-2 text-[13px] leading-snug text-[var(--color-text)]">
      <Icon size={14} strokeWidth={2} aria-hidden={true} style={{ color: tone, flexShrink: 0 }} />
      <span className="min-w-0 flex-1">{children}</span>
    </div>
  );
}

/**
 * Oracle Executive summary composition (`page-dashboard.jsx` ExecSummary):
 * structure + density copied; factory purple signals; white fill (no wash).
 */
export const SummaryCardShape: Story = {
  name: "Executive summary shape",
  render: () => (
    <div style={{ maxWidth: 720 }}>
      <AiSurface
        label="summary"
        title="Executive summary"
        meta={
          <>
            <span>This month</span>
            <MetaSep />
            <span>Generated 10:45</span>
            <MetaSep />
            <Badge tone="ai" size="sm" className="h-[22px] gap-1 rounded-[6px] px-2 font-medium">
              Using dashboard scope
            </Badge>
          </>
        }
        actions={
          <>
            <Button type="button" variant="ghost" size="icon" className="size-7" aria-label="Regenerate">
              <RefreshCw size={14} aria-hidden="true" />
            </Button>
            <Button type="button" variant="ghost" size="icon" className="size-7" aria-label="Copy">
              <Copy size={14} aria-hidden="true" />
            </Button>
            <Button type="button" variant="ghost" size="icon" className="size-7" aria-label="Export briefing">
              <Download size={14} aria-hidden="true" />
            </Button>
          </>
        }
        foot={
          <>
            <ProvTag provenance="ai" />
            <FeedbackControl compact className="ml-auto" />
          </>
        }
      >
        <p className="m-0 mb-2.5 text-[13.5px] leading-[1.65] text-[var(--color-text)]">
          Service volume is up <strong>16%</strong> month-to-date while median resolution improved to{" "}
          <strong>5.1h</strong> <CiteRef n={3} />. The headline risk is an active{" "}
          <strong>payments gateway incident</strong> in EU-West driving an error-rate anomaly and
          threatening SLA on two enterprise accounts <CiteRef n={1} />.
        </p>

        <div className="flex flex-col gap-1.5">
          <InsightLine icon={TrendingUp} tone="hsl(var(--prov-human))">
            Resolution time down 18% vs. last month <ProvTag provenance="calc" className="ml-1.5 align-middle" />
          </InsightLine>
          <InsightLine icon={AlertTriangle} tone="var(--color-warning)">
            SLA breaches trending up (5 vs. 3) — concentrated in Payments{" "}
            <ProvTag provenance="calc" className="ml-1.5 align-middle" />
          </InsightLine>
          <InsightLine icon={Target} tone="hsl(var(--ai))">
            AI interpretation: staffing on the EU shift is the main controllable factor{" "}
            <ProvTag provenance="ai" className="ml-1.5 align-middle" />
          </InsightLine>
        </div>

        <div className="mt-3">
          <SourceList
            sources={[
              { n: 1, type: "Case", title: "Payments gateway — EU-West", meta: "Open", fresh: "12m", rel: "high" },
              { n: 3, type: "Metric", title: "Service volume MTD", meta: "Live", fresh: "1m", rel: "high" },
              { n: 7, type: "Metric", title: "Median resolution", meta: "Live", fresh: "1m", rel: "medium" },
            ]}
            label="Sources"
          />
        </div>
      </AiSurface>
    </div>
  ),
};

export const FlatVariant: Story = {
  render: () => (
    <div style={{ maxWidth: 480 }}>
      <AiSurface label="assisted" flat>
        <AiSurfaceFacet label="Recommendation" prov="predict">
          Roll back one EU-West node to validate root cause.
        </AiSurfaceFacet>
      </AiSurface>
    </div>
  ),
};

const CATEGORIES: InsightCategory[] = [
  "Trend",
  "Anomaly",
  "Risk",
  "Opportunity",
  "Root cause",
  "Forecast",
  "Data quality",
  "Exception",
  "Driver",
];

export const AllCategoryTags: Story = {
  render: () => (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
      {CATEGORIES.map((c) => (
        <CategoryTag key={c} category={c} />
      ))}
    </div>
  ),
};
