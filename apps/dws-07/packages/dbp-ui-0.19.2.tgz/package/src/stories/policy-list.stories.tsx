import type { Meta, StoryObj } from "@storybook/react";
import { PolicyList } from "../components/policy-list.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/PolicyList",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const AllUnmet: Story = {
  name: "All unmet",
  render: () => (
    <PolicyList
      items={[
        { label: "At least 12 characters", met: false },
        { label: "Upper and lower case letters", met: false },
        { label: "A number", met: false },
        { label: "A symbol (!@#$…)", met: false },
      ]}
      style={{ width: "280px" }}
    />
  ),
};

export const Partial: Story = {
  render: () => (
    <PolicyList
      items={[
        { label: "At least 12 characters", met: true },
        { label: "Upper and lower case letters", met: true },
        { label: "A number", met: false },
        { label: "A symbol (!@#$…)", met: false },
      ]}
      style={{ width: "280px" }}
    />
  ),
};

export const AllMet: Story = {
  name: "All met",
  render: () => (
    <PolicyList
      items={[
        { label: "At least 12 characters", met: true },
        { label: "Upper and lower case letters", met: true },
        { label: "A number", met: true },
        { label: "A symbol (!@#$…)", met: true },
      ]}
      style={{ width: "280px" }}
    />
  ),
};
