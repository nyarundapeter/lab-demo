import type { Meta, StoryObj } from "@storybook/react";
import { ProvTag } from "../components/prov-tag.js";
import { CtrlBadge } from "../components/ctrl-badge.js";
import { AiConfidence } from "../components/ai-confidence.js";
import { AiMark } from "../components/ai-mark.js";
import type { AiConfidenceLevel, AiControlLevel, AiProvenance } from "@dbp/contracts";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/Provenance & Control",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

const PROVENANCES: AiProvenance[] = ["source", "calc", "ai", "predict", "human", "auto"];
const LEVELS: AiControlLevel[] = [1, 2, 3, 4];
const CONFIDENCE_LEVELS: AiConfidenceLevel[] = ["high", "medium", "low", "insufficient"];

export const AllProvenanceHues: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      {PROVENANCES.map((p) => (
        <ProvTag key={p} provenance={p} />
      ))}
    </div>
  ),
};

export const AllControlLevels: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      {LEVELS.map((level) => (
        <CtrlBadge key={level} level={level} />
      ))}
    </div>
  ),
};

export const HumanDecisionOnlyFlag: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <CtrlBadge level={1} humanDecisionOnly={false} />
      <CtrlBadge level={1} humanDecisionOnly />
      <CtrlBadge level={3} humanDecisionOnly />
    </div>
  ),
};

export const ConfidenceRange: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {CONFIDENCE_LEVELS.map((level) => (
        <AiConfidence key={level} level={level} />
      ))}
      <AiConfidence level="low" note="Based on 3 prior cases — small sample size." />
      <AiConfidence level="high" inline />
    </div>
  ),
};

export const AiGlyph: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
      <AiMark size={11} />
      <AiMark size={16} />
      <AiMark size={22} />
    </div>
  ),
};
