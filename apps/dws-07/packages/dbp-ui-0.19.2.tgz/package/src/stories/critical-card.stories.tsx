import type { Meta, StoryObj } from "@storybook/react";
import { CriticalCard } from "../components/critical-card.js";

const meta: Meta<typeof CriticalCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/CriticalCard",
  component: CriticalCard,
  tags: ["autodocs"],
  parameters: { layout: "padded" },
};
export default meta;
type Story = StoryObj<typeof CriticalCard>;

const FIELDS = [
  { label: "Impact", value: "3 workspaces · 1,240 records queued" },
  { label: "Detected", value: "6 min ago · 3:29 PM" },
  { label: "Owner", value: "Priya Shah" },
  { label: "Required response", value: "Restore sync or fail over" },
];

export const Default: Story = {
  args: {
    record: "Sync Service",
    title: "Production outage: Salesforce sync failing",
    message:
      "The outbound sync queue to Salesforce has been failing for 6 minutes. Records are queuing but not delivering.",
    fields: FIELDS,
    onOpenIncident: () => {},
    onAck: () => {},
    onMarkFalsePositive: () => {},
  },
};

export const Resolved: Story = {
  args: {
    ...Default.args,
    status: "resolved",
  },
};
