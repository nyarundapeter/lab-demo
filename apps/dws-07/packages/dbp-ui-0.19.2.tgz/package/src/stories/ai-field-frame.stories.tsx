import type { Meta, StoryObj } from "@storybook/react";
import { AiFieldFrame } from "../components/ai-field-frame.js";
import { AssistTrigger } from "../components/assist-trigger.js";
import { ProvTag } from "../components/prov-tag.js";

const meta: Meta<typeof AiFieldFrame> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AiFieldFrame",
  component: AiFieldFrame,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AiFieldFrame>;

export const Default: Story = {
  render: () => (
    <div style={{ maxWidth: 340 }}>
      <AiFieldFrame label="Customer name" required assist={<AssistTrigger />}>
        <input className="input" placeholder="Enter a name…" style={{ width: "100%", height: 32, padding: "0 8px" }} />
      </AiFieldFrame>
    </div>
  ),
};

export const WithProvenanceNote: Story = {
  render: () => (
    <div style={{ maxWidth: 340 }}>
      <AiFieldFrame
        label="Priority"
        hint="(optional)"
        assist={<AssistTrigger state="unavailable" />}
        provNote={<><ProvTag provenance="human" />Entered by you</>}
      >
        <input className="input" defaultValue="High" style={{ width: "100%", height: 32, padding: "0 8px" }} />
      </AiFieldFrame>
    </div>
  ),
};
