import type { Meta, StoryObj } from "@storybook/react";
import { ColorGroup, triad } from "./foundations-shared.js";

/**
 * "Sub-atomic" layer per the atomic-design model (Frost). Sourced live from
 * packages/shared/design-tokens/{base,theme}.css via CSS custom properties
 * (never a literal hex — this file is subject to the repo's blocking
 * no-raw-design-values lint rule).
 */
const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Foundations/Colors",
  tags: ["autodocs"],
  parameters: { layout: "fullscreen" },
};
export default meta;
type Story = StoryObj;

export const AllGroups: Story = {
  render: () => (
    <div style={{ padding: 32, background: "var(--color-surface)" }}>
      <ColorGroup
        title="Brand"
        tokens={[
          ["--color-primary", "primary"],
          ["--color-primary-foreground", "primary-foreground"],
          ["--color-secondary", "secondary"],
        ]}
      />
      <ColorGroup title="Status — success" tokens={triad("success")} />
      <ColorGroup title="Status — warning" tokens={triad("warning")} />
      <ColorGroup title="Status — danger" tokens={triad("danger")} />
      <ColorGroup title="Status — info" tokens={triad("info")} />
      <ColorGroup title="Status — active" tokens={triad("active")} />
      <ColorGroup title="Status — paused" tokens={triad("paused")} />
      <ColorGroup title="Status — critical" tokens={triad("critical")} />
      <ColorGroup title="Status — testing" tokens={triad("testing")} />
      <ColorGroup title="Status — neutral" tokens={triad("neutral", false)} />
      <ColorGroup
        title="Environment (base only — each follows the same surface/text/border pattern as the Status triads above)"
        tokens={[
          ["--color-env-dev", "env-dev"],
          ["--color-env-test", "env-test"],
          ["--color-env-stage", "env-stage"],
          ["--color-env-prod", "env-prod"],
        ]}
      />
      <ColorGroup
        title="Text"
        tokens={[
          ["--color-text", "text"],
          ["--color-text-secondary", "text-secondary"],
          ["--color-text-muted", "text-muted"],
          ["--color-text-disabled", "text-disabled"],
        ]}
      />
      <ColorGroup
        title="Border"
        tokens={[
          ["--color-border", "border"],
          ["--color-border-subtle", "border-subtle"],
          ["--color-border-strong", "border-strong"],
        ]}
      />
      <ColorGroup
        title="Surface"
        tokens={[
          ["--color-surface", "surface"],
          ["--color-surface-2", "surface-2"],
          ["--color-surface-content", "surface-content"],
          ["--color-surface-nav", "surface-nav"],
          ["--color-surface-accent", "surface-accent"],
          ["--color-surface-raised", "surface-raised"],
          ["--color-surface-secondary", "surface-secondary"],
          ["--color-background", "background"],
        ]}
      />
      <ColorGroup
        title="Navy / Orange ramps"
        tokens={[
          ["--color-navy-50", "navy-50"],
          ["--color-navy-100", "navy-100"],
          ["--color-navy-200", "navy-200"],
          ["--color-orange-50", "orange-50"],
          ["--color-orange-100", "orange-100"],
          ["--color-orange-600", "orange-600"],
        ]}
      />
      <ColorGroup title="Other" tokens={[["--color-nav-accent", "nav-accent"]]} />
      <p style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--color-text-muted)", maxWidth: 640 }}>
        Pure aliases (not shown as separate swatches — same color as their target, zero new
        information): --color-brand-navy/--color-surface-navy → --color-primary,
        --color-brand-orange → --color-secondary, --color-text-primary → --color-text,
        --color-border-default → --color-border, --color-bg → --color-background,
        --color-destructive → --color-danger.
      </p>
    </div>
  ),
};
