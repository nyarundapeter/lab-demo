import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ActivityComposer } from "../components/activity-composer.js";
import type { ActivityDraft, ActivityMentionUser, ActivityTimelineConfig } from "../schemas/activity.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Activity/ActivityComposer",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

const MENTION_CANDIDATES: ActivityMentionUser[] = [
  { id: "u1", name: "Priya Nair" },
  { id: "u2", name: "Tomas Berg" },
  { id: "u3", name: "Amara Osei" },
  { id: "u4", name: "Diego Ruiz" },
];

const FULL_CONFIG: ActivityTimelineConfig = {
  entityType: "deal",
  activityTypes: {},
  mentions: true,
  tags: true,
  attachments: true,
  labels: {
    composerPlaceholder: "Add a note… use @ to mention teammates, #tag to label it",
  },
};

const MINIMAL_CONFIG: ActivityTimelineConfig = {
  entityType: "deal",
  activityTypes: {},
  mentions: false,
  tags: false,
  attachments: false,
};

function Harness({ config }: { config: ActivityTimelineConfig }) {
  const [saved, setSaved] = React.useState<ActivityDraft | null>(null);
  return (
    <div className="flex max-w-lg flex-col gap-3">
      <ActivityComposer config={config} mentionCandidates={MENTION_CANDIDATES} onSave={setSaved} />
      {saved && (
        <pre className="rounded-[6px] border border-[var(--color-border)] bg-[var(--color-surface)] p-3 text-xs">
          {JSON.stringify(saved, null, 2)}
        </pre>
      )}
    </div>
  );
}

export const FullyConfigured: Story = {
  name: "Mentions + tags + attachments (stub)",
  render: () => <Harness config={FULL_CONFIG} />,
};

export const MinimalConfig: Story = {
  name: "No config-gated affordances",
  render: () => <Harness config={MINIMAL_CONFIG} />,
};

export const RichTextAndMentions: Story = {
  name: "Tiptap toolbar + @mention picker (ADR-0048)",
  render: () => <Harness config={FULL_CONFIG} />,
  parameters: {
    docs: {
      description: {
        story:
          "Bold/italic/lists/links toolbar plus the `@` mention picker (minimal Tiptap v3 extension profile per ADR-0048). Type `@` to open the picker; Save serializes the Tiptap doc to `body` (JSON) with a derived `plainText` and any `mentionedUserIds`.",
      },
    },
  },
};
