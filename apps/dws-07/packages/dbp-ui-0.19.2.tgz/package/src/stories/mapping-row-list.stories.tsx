import type { Meta, StoryObj } from "@storybook/react"
import React from "react"
import { MappingRowList } from "../components/mapping-row-list.js"

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Config/MappingRowList",
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj

const FIELD_MAPPING_ROWS = [
  { source: "customer_id", target: "accountId", meta: "Direct" },
  { source: "full_name", target: "displayName", meta: "Concat" },
  { source: "email_addr", target: "email", meta: "Lowercase" },
  { source: "created_ts", target: "createdAt", meta: "ISO 8601" },
]

const RELATIONSHIP_ROWS = [
  { source: "Case", target: "Account", meta: "Many-to-one", label: "belongs to" },
  { source: "Case", target: "Comment", meta: "One-to-many", label: "has many" },
  { source: "Case", target: "User", meta: "Many-to-one", label: "assigned to" },
]

export const AsFieldMapping: Story = {
  render: () => <MappingRowList variant="table" rows={FIELD_MAPPING_ROWS} />,
}

export const AsRelationshipEditor: Story = {
  render: () => (
    <MappingRowList
      variant="connector"
      rows={RELATIONSHIP_ROWS.map((r) => ({ ...r, onEdit: () => {} }))}
      onAddRow={() => {}}
    />
  ),
}
