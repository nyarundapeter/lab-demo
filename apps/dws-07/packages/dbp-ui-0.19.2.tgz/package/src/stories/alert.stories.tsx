import type { Meta, StoryObj } from "@storybook/react";
import { Alert } from "../components/alert.js";

const meta: Meta<typeof Alert> = {
  title: "Layer 07 — App Scaffolds/Atoms/Feedback/Alert",
  component: Alert,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Alert>;

export const Info: Story = {
  args: { tone: "info", title: "Information", children: "Your session will expire in 30 minutes." },
};

export const Success: Story = {
  args: { tone: "success", title: "Saved successfully", children: "All changes have been committed." },
};

export const Warning: Story = {
  args: { tone: "warning", title: "Review required", children: "This record has pending governance approvals." },
};

export const Danger: Story = {
  args: { tone: "danger", title: "Action failed", children: "Could not connect to the data service. Try again." },
};

export const Critical: Story = {
  args: { tone: "critical", title: "Critical", children: "This account has been suspended pending review." },
};

export const Dismissible: Story = {
  args: { tone: "info", title: "Tip", children: "You can use keyboard shortcuts to navigate faster.", dismissible: true },
};

export const Solid: Story = {
  name: "Solid variant",
  args: { tone: "critical", variant: "solid", title: "Critical", children: "This account has been suspended pending review." },
};

export const Compact: Story = {
  name: "Compact variant",
  args: { tone: "warning", variant: "compact", title: "Warning", children: "Pending governance approval." },
};

export const AllTones: Story = {
  name: "All tones",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: "480px" }}>
      <Alert tone="info" title="Info">Informational message</Alert>
      <Alert tone="success" title="Success">Operation completed</Alert>
      <Alert tone="warning" title="Warning">Proceed with caution</Alert>
      <Alert tone="danger" title="Error">Something went wrong</Alert>
      <Alert tone="critical" title="Critical">Immediate action required</Alert>
    </div>
  ),
};

export const AllVariants: Story = {
  name: "Solid & compact — all tones",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: "480px" }}>
      <Alert tone="info" variant="solid" title="Info">Informational message</Alert>
      <Alert tone="success" variant="solid" title="Success">Operation completed</Alert>
      <Alert tone="warning" variant="solid" title="Warning">Proceed with caution</Alert>
      <Alert tone="danger" variant="solid" title="Error">Something went wrong</Alert>
      <Alert tone="critical" variant="solid" title="Critical">Immediate action required</Alert>
      <Alert tone="info" variant="compact" title="Info">Informational message</Alert>
      <Alert tone="critical" variant="compact" title="Critical">Immediate action required</Alert>
    </div>
  ),
};
