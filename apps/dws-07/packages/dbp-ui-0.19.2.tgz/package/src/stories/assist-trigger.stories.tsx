import type { Meta, StoryObj } from "@storybook/react";
import { AssistTrigger } from "../components/assist-trigger.js";

const meta: Meta<typeof AssistTrigger> = {
  title: "Layer 07 — App Scaffolds/Atoms/Actions/AssistTrigger",
  component: AssistTrigger,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AssistTrigger>;

export const AllStates: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "16px", alignItems: "center" }}>
      <AssistTrigger state="ready" />
      <AssistTrigger state="loading" />
      <AssistTrigger state="unavailable" />
    </div>
  ),
};

export const CustomLabel: Story = {
  args: { label: "Suggest options", state: "ready" },
};
