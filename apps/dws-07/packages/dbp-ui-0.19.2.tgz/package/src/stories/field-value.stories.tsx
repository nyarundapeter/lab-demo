import type { Meta, StoryObj } from "@storybook/react";
import { FieldValue } from "../components/field-value.js";

const meta: Meta<typeof FieldValue> = {
  title: "Layer 07 — App Scaffolds/Atoms/FieldValue",
  component: FieldValue,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof FieldValue>;

export const Text: Story = {
  args: { value: "Acme Corporation", format: "text" },
};

export const Number: Story = {
  args: { value: 38000, format: "number" },
};

export const Date: Story = {
  args: { value: "2026-01-15", format: "date" },
};

export const Badge: Story = {
  args: { value: "Active", format: "badge" },
};

export const Empty: Story = {
  args: { value: undefined, format: "text" },
};
