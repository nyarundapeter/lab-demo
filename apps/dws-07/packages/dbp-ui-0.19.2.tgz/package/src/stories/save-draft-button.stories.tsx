import type { Meta, StoryObj } from "@storybook/react";
import { SaveDraftButton } from "../components/save-draft-button.js";

const meta: Meta<typeof SaveDraftButton> = {
  title: "Layer 07 — App Scaffolds/Molecules/Overlays/SaveDraftButton",
  component: SaveDraftButton,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof SaveDraftButton>;

export const Default: Story = {};

export const Saving: Story = {
  args: { saving: true },
};

export const CustomLabel: Story = {
  args: { label: "Keep as draft" },
};
