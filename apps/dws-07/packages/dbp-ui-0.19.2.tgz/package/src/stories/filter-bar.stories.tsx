import type { Meta, StoryObj } from "@storybook/react"
import React from "react"
import { FilterBar } from "../components/filter-bar.js"

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Layout & Navigation/FilterBar",
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj

const CHIPS = [
  { key: "all", label: "All", count: 42 },
  { key: "active", label: "Active", count: 18 },
  { key: "pending", label: "Pending", count: 7 },
  { key: "archived", label: "Archived", count: 17 },
]

const SORT_OPTIONS = [
  { value: "newest", label: "Newest first" },
  { value: "oldest", label: "Oldest first" },
  { value: "name-asc", label: "Name A–Z" },
  { value: "name-desc", label: "Name Z–A" },
]

export const Default: Story = {
  render: () => {
    const [search, setSearch] = React.useState("")
    const [chip, setChip] = React.useState("all")
    const [sort, setSort] = React.useState("newest")
    return (
      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        chips={CHIPS}
        activeChip={chip}
        onChipChange={setChip}
        sortOptions={SORT_OPTIONS}
        sortValue={sort}
        onSortChange={setSort}
      />
    )
  },
}

export const SearchOnly: Story = {
  render: () => {
    const [search, setSearch] = React.useState("")
    return (
      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search records…"
      />
    )
  },
}

export const WithActiveChip: Story = {
  render: () => {
    const [chip, setChip] = React.useState("active")
    return (
      <FilterBar
        chips={CHIPS}
        activeChip={chip}
        onChipChange={setChip}
      />
    )
  },
}

export const NoSearch: Story = {
  render: () => {
    const [chip, setChip] = React.useState("all")
    const [sort, setSort] = React.useState("newest")
    return (
      <FilterBar
        chips={CHIPS}
        activeChip={chip}
        onChipChange={setChip}
        sortOptions={SORT_OPTIONS}
        sortValue={sort}
        onSortChange={setSort}
      />
    )
  },
}

export const WithClearAllAndSummary: Story = {
  render: () => {
    const [search, setSearch] = React.useState("Aurora")
    const [chip, setChip] = React.useState("pending")
    const hasActive = search.length > 0 || chip !== "all"
    return (
      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        chips={CHIPS}
        activeChip={chip}
        onChipChange={setChip}
        resultSummary="7 of 42 cases"
        showClearAll={hasActive}
        onClearAll={() => {
          setSearch("")
          setChip("all")
        }}
      />
    )
  },
}
