import type { Meta, StoryObj } from "@storybook/react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  CardClickable,
} from "../components/card.js";
import { Button } from "../components/button.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Layout/Card",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <Card style={{ width: "360px" }}>
      <CardHeader>
        <CardTitle>Project Aurora</CardTitle>
        <CardDescription>Migration status and next milestones.</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-[var(--color-text-secondary)]">
          Phase 2 of the data migration is on track for completion this sprint.
        </p>
      </CardContent>
      <CardFooter>
        <Button variant="outline" size="sm">
          View details
        </Button>
        <Button size="sm">Open</Button>
      </CardFooter>
    </Card>
  ),
};

export const HeaderAndContentOnly: Story = {
  render: () => (
    <Card style={{ width: "360px" }}>
      <CardHeader>
        <CardTitle>No footer actions</CardTitle>
        <CardDescription>Cards work without a footer too.</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-[var(--color-text-secondary)]">Just header + body content.</p>
      </CardContent>
    </Card>
  ),
};

export const Clickable: Story = {
  render: () => (
    <CardClickable style={{ width: "360px" }} role="button" tabIndex={0}>
      <CardHeader>
        <CardTitle>Clickable card</CardTitle>
        <CardDescription>Lifts on hover — used for catalog/entity picker rows.</CardDescription>
      </CardHeader>
    </CardClickable>
  ),
};
