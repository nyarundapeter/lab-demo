import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { PwField } from "../components/pw-field.js";
import { FormField } from "../components/form-field.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/PwField",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

function Controlled({ initial = "" }: { initial?: string }) {
  const [value, setValue] = React.useState(initial);
  return <PwField value={value} onChange={(e) => setValue(e.target.value)} />;
}

export const Default: Story = {
  render: () => (
    <FormField label="Password" style={{ width: "320px" }}>
      <Controlled />
    </FormField>
  ),
};

export const Prefilled: Story = {
  render: () => (
    <FormField label="Password" style={{ width: "320px" }}>
      <Controlled initial="correcthorsebatterystaple" />
    </FormField>
  ),
};

export const ErrorState: Story = {
  name: "Error state",
  render: () => (
    <FormField label="Password" required error="Password is required." style={{ width: "320px" }}>
      <PwField value="" onChange={() => {}} state="error" />
    </FormField>
  ),
};
