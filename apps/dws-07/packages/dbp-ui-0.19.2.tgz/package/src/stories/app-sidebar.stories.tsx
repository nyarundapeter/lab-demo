import type { Meta, StoryObj } from "@storybook/react";
import type { SidebarConfig } from "@dbp/contracts";
import { AppSidebar, SidebarIdentity } from "../components/app-sidebar.js";

/**
 * Three-level DQ hierarchy:
 *   section eyebrow (orange) → group rows (icon + chevron) → nested children.
 * Icons resolve from lucide names (PascalCase) on each group item.
 */
const sidebarConfig: SidebarConfig = {
  collapsible: false,
  sections: [
    {
      id: "workspace",
      label: "Workspace",
      items: [
        { id: "home", label: "Home", href: "/home", icon: "Home" },
        {
          id: "tasks",
          label: "Tasks",
          href: "/tasks",
          icon: "ListChecks",
          badge: "4",
          children: [
            { id: "assigned", label: "Assigned to me", href: "/tasks/assigned" },
            { id: "watching", label: "Watching", href: "/tasks/watching" },
          ],
        },
        {
          id: "knowledge",
          label: "Knowledge",
          href: "/knowledge",
          icon: "BookOpen",
          children: [
            { id: "playbooks", label: "Playbooks", href: "/knowledge/playbooks" },
            { id: "standards", label: "Standards", href: "/knowledge/standards" },
          ],
        },
      ],
    },
    {
      id: "admin",
      label: "Administration",
      items: [
        { id: "people", label: "People", href: "/people", icon: "Users" },
        { id: "settings", label: "Settings", href: "/settings", icon: "Settings" },
      ],
    },
  ],
};

const meta: Meta<typeof AppSidebar> = {
  title: "Layer 07 — App Scaffolds/Molecules/Chrome/AppSidebar",
  component: AppSidebar,
  parameters: { layout: "padded" },
  tags: ["autodocs"],
  decorators: [
    (Story) => (
      <div
        style={{
          height: "560px",
          width: "280px",
          border: "1px solid var(--color-border-subtle)",
        }}
      >
        <Story />
      </div>
    ),
  ],
};
export default meta;
type Story = StoryObj<typeof AppSidebar>;

export const Default: Story = {
  args: { config: sidebarConfig, activePath: "/home" },
};

/** Active descendant — parent group is highlighted and auto-expanded. */
export const ActiveChild: Story = {
  args: { config: sidebarConfig, activePath: "/tasks/assigned" },
};

export const ActiveSettings: Story = {
  args: { config: sidebarConfig, activePath: "/settings" },
};

export const CollapsibleSections: Story = {
  args: {
    config: { ...sidebarConfig, collapsible: true },
    activePath: '/home',
  },
};

export const WithPersistedState: Story = {
  args: {
    config: { ...sidebarConfig, collapsible: true },
    activePath: '/home',
    storageKey: 'storybook-nav-state',
  },
};

/**
 * SidebarIdentity — the solution identity block anchored at the top of the
 * sidebar (shell v3 anatomy, N27 ruling). Replaces the app lockup that
 * previously lived in AppTopBar.
 */
export const WithIdentityExpanded: Story = {
  render: () => (
    <>
      <SidebarIdentity code="DWS.01" name="Work.Space4.0" />
      <AppSidebar config={sidebarConfig} activePath="/home" />
    </>
  ),
};

export const WithIdentityCollapsed: Story = {
  decorators: [
    (Story) => (
      <div style={{ height: "560px", width: "64px", border: "1px solid var(--color-border-subtle)" }}>
        <Story />
      </div>
    ),
  ],
  render: () => (
    <>
      <SidebarIdentity code="DWS.01" name="Work.Space4.0" collapsed />
      <AppSidebar config={sidebarConfig} activePath="/home" iconOnly showSearch />
    </>
  ),
};

/**
 * Nav search (N27b) — search input directly under the identity header,
 * live-filters the nav tree by label. Empty query shows the full tree.
 */
export const WithNavSearchEmpty: Story = {
  render: () => (
    <>
      <SidebarIdentity code="DWS.01" name="Work.Space4.0" />
      <AppSidebar config={sidebarConfig} activePath="/home" showSearch />
    </>
  ),
};

/**
 * Filtering query pre-applied via a controlled wrapper: "people" only matches
 * the Administration group's "People" item — the Workspace group (no match)
 * is hidden entirely.
 */
export const WithNavSearchFiltering: Story = {
  render: () => {
    const filteredConfig: SidebarConfig = {
      ...sidebarConfig,
      sections: sidebarConfig.sections
        .map((section) => ({
          ...section,
          items: section.items.filter((item) => item.label.toLowerCase().includes("people")),
        }))
        .filter((section) => section.items.length > 0),
    };
    return (
      <>
        <SidebarIdentity code="DWS.01" name="Work.Space4.0" />
        <AppSidebar config={filteredConfig} activePath="/home" showSearch />
      </>
    );
  },
};

/** Collapsed sidebar: the nav search input is hidden entirely (N27b). */
export const WithNavSearchCollapsed: Story = {
  decorators: [
    (Story) => (
      <div style={{ height: "560px", width: "64px", border: "1px solid var(--color-border-subtle)" }}>
        <Story />
      </div>
    ),
  ],
  render: () => (
    <>
      <SidebarIdentity code="DWS.01" name="Work.Space4.0" collapsed />
      <AppSidebar config={sidebarConfig} activePath="/home" iconOnly showSearch />
    </>
  ),
};
