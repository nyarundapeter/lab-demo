import type { ReactNode } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { AnomalyInsightCard, type AnomalyInsightCardData } from "../components/anomaly-insight-card.js";

const meta: Meta<typeof AnomalyInsightCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AnomalyInsightCard",
  component: AnomalyInsightCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AnomalyInsightCard>;

/** Oracle ai-example-dashboard AnomalyCard fixture (Payments API / EU-West). */
const DATA: AnomalyInsightCardData = {
  detected: "3h ago",
  metric: "Error rate · EU-West",
  title: "Payments API error rate 6.2× above expected range",
  confidence: "high",
  confidenceNote: "Onset aligns tightly with a known deploy window; 8 weeks of baseline history.",
  expected: "0.4–0.9%",
  observed: "4.8%",
  causes:
    "Three enterprise accounts route checkout through this region. Two are within 8 hours of an SLA breach.",
  sources: [
    { n: 1, type: "Metric", title: "EU-West error rate", meta: "Live metric", fresh: "1 min", rel: "high" },
    { n: 2, type: "Activity", title: "Deploy payments-svc 3.14.2", meta: "08:52", fresh: "1h", rel: "high" },
    { n: 3, type: "Case", title: "Meridian Foods — CS-4821", meta: "Open", fresh: "12m", rel: "high" },
  ],
};

/** Oracle insight-rail width is 340px outer — pad must sit outside the card or the body
 *  text column shrinks (~295px) and “Possible causes” wraps at 5 words instead of 6. */
function RailFrame({ children }: { children: ReactNode }) {
  return (
    <div style={{ padding: 8, background: "var(--color-surface, #F6F6FB)" }}>
      <div style={{ width: 340 }}>{children}</div>
    </div>
  )
}

export const Default: Story = {
  render: () => (
    <RailFrame>
      <AnomalyInsightCard data={DATA} />
    </RailFrame>
  ),
};

export const NoSources: Story = {
  render: () => (
    <RailFrame>
      <AnomalyInsightCard data={{ ...DATA, sources: [] }} />
    </RailFrame>
  ),
};

export const LowConfidence: Story = {
  render: () => (
    <RailFrame>
      <AnomalyInsightCard
        data={{
          ...DATA,
          confidence: "low",
          confidenceNote: "Sparse baseline in this region; treat as a weak signal.",
        }}
      />
    </RailFrame>
  ),
};
