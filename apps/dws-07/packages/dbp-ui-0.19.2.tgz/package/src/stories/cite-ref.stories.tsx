import type { Meta, StoryObj } from "@storybook/react";
import { CiteRef } from "../components/cite-ref.js";

const meta: Meta<typeof CiteRef> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/CiteRef",
  component: CiteRef,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof CiteRef>;

export const Inline: Story = {
  render: () => (
    <p style={{ fontSize: 14, maxWidth: 420 }}>
      Case volume grew 12% quarter over quarter <CiteRef n={1} onOpen={(n) => alert(`open source ${n}`)} />, driven
      mostly by the onboarding backlog <CiteRef n={2} onOpen={(n) => alert(`open source ${n}`)} />.
    </p>
  ),
};
