import type { Meta, StoryObj } from "@storybook/react";
import { LifecycleBar, deriveConfigLifecycleStages } from "../components/lifecycle-bar.js";
import type { StageRow } from "../components/vertical-stage-tracker.js";

const meta: Meta<typeof LifecycleBar> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/LifecycleBar",
  component: LifecycleBar,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof LifecycleBar>;

export const ConfigLifecycleChip: Story = {
  render: () => (
    <LifecycleBar variant="chip" stages={deriveConfigLifecycleStages("Published")} />
  ),
};

const CASE_STAGES: StageRow[] = [
  { id: "intake", label: "Intake", status: "done" },
  { id: "review", label: "Review", status: "done" },
  { id: "decision", label: "Decision", status: "active" },
  { id: "resolution", label: "Resolution", status: "upcoming" },
  { id: "closed", label: "Closed", status: "upcoming" },
];

export const CaseTrackerStepper: Story = {
  render: () => <LifecycleBar variant="stepper" stages={CASE_STAGES} />,
};

const STAGES_WITH_ISSUES: StageRow[] = [
  { id: "intake", label: "Intake", status: "done" },
  { id: "review", label: "Review", status: "blocked" },
  { id: "decision", label: "Decision", status: "upcoming" },
  { id: "resolution", label: "Resolution", status: "upcoming" },
];

export const StepperWithBlockedStage: Story = {
  render: () => <LifecycleBar variant="stepper" stages={STAGES_WITH_ISSUES} />,
};
