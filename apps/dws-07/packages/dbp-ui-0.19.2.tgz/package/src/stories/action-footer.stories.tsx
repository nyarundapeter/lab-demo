import type { Meta, StoryObj } from "@storybook/react";
import { ActionFooter } from "../components/action-footer.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/ActionFooter",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const PrimaryOnly: Story = {
  name: "Primary only",
  render: () => (
    <div style={{ width: 640 }}>
      <ActionFooter primary={{ label: "Submit", onClick: () => {} }} />
    </div>
  ),
};

export const FullSet: Story = {
  name: "Full set (destructive · save status · tertiary · secondary · primary)",
  render: () => (
    <div style={{ width: 640 }}>
      <ActionFooter
        destructive={{ label: "Delete", onClick: () => {} }}
        saveStatus="saved"
        savedAt="2 minutes ago"
        tertiary={{ label: "Save draft", onClick: () => {} }}
        secondary={{ label: "Cancel", onClick: () => {} }}
        primary={{ label: "Submit request", onClick: () => {} }}
      />
    </div>
  ),
};

export const Loading: Story = {
  render: () => (
    <div style={{ width: 640 }}>
      <ActionFooter
        secondary={{ label: "Cancel", onClick: () => {} }}
        primary={{ label: "Submitting…", onClick: () => {}, loading: true }}
      />
    </div>
  ),
};

export const Sticky: Story = {
  render: () => (
    <div style={{ width: 640, height: 160, overflowY: "auto", border: "1px solid var(--color-border)" }}>
      <div style={{ padding: 16, height: 320 }}>Scrollable form content…</div>
      <ActionFooter
        sticky
        secondary={{ label: "Cancel", onClick: () => {} }}
        primary={{ label: "Save", onClick: () => {} }}
      />
    </div>
  ),
};
