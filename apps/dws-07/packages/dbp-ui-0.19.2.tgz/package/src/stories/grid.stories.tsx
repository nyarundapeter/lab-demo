import type * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { Grid, Col } from "../components/grid.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Foundations/Grid",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

function Swatch({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-input border border-[var(--color-border-default)] bg-[var(--color-navy-50)] px-3 py-6 text-center text-xs text-primary">
      {children}
    </div>
  );
}

export const TwelveColumn: Story = {
  render: () => (
    <Grid>
      {Array.from({ length: 12 }).map((_, i) => (
        <Col key={i} span={1}>
          <Swatch>{i + 1}</Swatch>
        </Col>
      ))}
    </Grid>
  ),
};

export const ResponsiveCardGrid: Story = {
  name: "Responsive — 1up mobile / 2up md / 3up xl",
  render: () => (
    <Grid>
      {Array.from({ length: 6 }).map((_, i) => (
        <Col key={i} span={6} xl={4}>
          <Swatch>Card {i + 1}</Swatch>
        </Col>
      ))}
    </Grid>
  ),
};

export const MixedSpans: Story = {
  render: () => (
    <Grid>
      <Col span={8}>
        <Swatch>span=8</Swatch>
      </Col>
      <Col span={4}>
        <Swatch>span=4</Swatch>
      </Col>
      <Col span={4}>
        <Swatch>span=4</Swatch>
      </Col>
      <Col span={4}>
        <Swatch>span=4</Swatch>
      </Col>
      <Col span={4}>
        <Swatch>span=4</Swatch>
      </Col>
    </Grid>
  ),
};
