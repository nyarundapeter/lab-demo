import type { Meta, StoryObj } from "@storybook/react";
import { AdminSettingsForm } from "../components/admin-settings-form.js";
import { Button } from "../components/button.js";
import { GENERAL_FIELDS } from "./admin-settings-form.stories.js";

/**
 * Cookbook/Platform Management/Admin Settings Form
 *
 * A thin, second title on top of `AdminSettingsForm`'s existing `Default` story
 * (`admin-settings-form.stories.tsx`) — reusing the same `GENERAL_FIELDS` fixture
 * (mirrors `ADMIN_FORM_SPECS["admin/auth"].tabs[0]` in `scaffold-solution.mjs`)
 * rather than re-typing it.
 *
 * `AdminSettingsForm` backs the `config-form-single` and `config-form-tabs`
 * layouts' auto-generated forms — see Reference/Layout Archetypes → config-form.
 *
 * **Real solution:** not tied to one — `admin/auth` and its siblings are
 * standard-menu-injected demo routes (`ADMIN_FORM_SPECS` in `scaffold-solution.mjs`),
 * present identically across every solution's demo surface, not one authored module.
 */

function AdminSettingsFormPage() {
  return (
    <div style={{ width: "480px", display: "flex", flexDirection: "column", gap: "16px" }}>
      <AdminSettingsForm formId="auth-general" fields={GENERAL_FIELDS} />
      <Button type="submit" form="auth-general">
        Save changes
      </Button>
    </div>
  );
}

const meta: Meta<typeof AdminSettingsFormPage> = {
  title: "Cookbook/Platform Management/Admin Settings Form",
  component: AdminSettingsFormPage,
  parameters: {
    docs: {
      description: {
        component:
          "Real `AdminSettingsForm` (RHF + Zod) — see `Design System/Admin/AdminSettingsForm` " +
          "→ `Default` for the same story with full annotation, including the `ValidationError` variant.",
      },
    },
  },
};
export default meta;
type Story = StoryObj<typeof AdminSettingsFormPage>;

export const Default: Story = {};
