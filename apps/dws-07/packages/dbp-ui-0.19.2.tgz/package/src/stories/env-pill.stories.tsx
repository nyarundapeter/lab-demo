import type { Meta, StoryObj } from "@storybook/react";
import { EnvPill } from "../components/env-pill.js";

const meta: Meta<typeof EnvPill> = {
  title: "Layer 07 — App Scaffolds/Atoms/Badge/EnvPill",
  component: EnvPill,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof EnvPill>;

export const Dev: Story = {
  args: { env: "dev" },
};

export const Test: Story = {
  args: { env: "test" },
};

export const Stage: Story = {
  args: { env: "stage" },
};

export const Prod: Story = {
  args: { env: "prod" },
};

export const WithRegion: Story = {
  name: "With region",
  args: { env: "stage", region: "us-east-1" },
};

export const AllEnvironments: Story = {
  name: "All environments",
  render: () => (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
      <EnvPill env="dev" />
      <EnvPill env="test" />
      <EnvPill env="stage" />
      <EnvPill env="prod" />
    </div>
  ),
};
