import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { DateRangeField, type DateRangeValue } from "../components/date-range-field.js";
import { FormField } from "../components/form-field.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/DateRangeField",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

function Controlled({ initial = {} as DateRangeValue }: { initial?: DateRangeValue }) {
  const [value, setValue] = React.useState<DateRangeValue>(initial);
  return <DateRangeField label="Effective period" value={value} onChange={setValue} />;
}

export const Default: Story = {
  render: () => (
    <FormField label="Effective period" helperText="The end date can't be before the start date." style={{ width: "420px" }}>
      <Controlled />
    </FormField>
  ),
};

export const WithValue: Story = {
  name: "With value",
  render: () => (
    <FormField label="Effective period" style={{ width: "420px" }}>
      <Controlled initial={{ from: "2026-08-01", to: "2026-12-31" }} />
    </FormField>
  ),
};

export const ErrorState: Story = {
  name: "Error state",
  render: () => (
    <FormField label="Effective period" required error="Both a start and end date are required." style={{ width: "420px" }}>
      <Controlled />
    </FormField>
  ),
};

export const Disabled: Story = {
  render: () => (
    <FormField label="Effective period" style={{ width: "420px" }}>
      <DateRangeField label="Effective period" value={{ from: "2026-08-01", to: "2026-12-31" }} onChange={() => {}} disabled />
    </FormField>
  ),
};
