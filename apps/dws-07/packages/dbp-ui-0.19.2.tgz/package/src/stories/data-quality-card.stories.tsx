import type { Meta, StoryObj } from "@storybook/react";
import { DataQualityCard, type DataQualityCardItem } from "../components/data-quality-card.js";

const meta: Meta<typeof DataQualityCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/DataQualityCard",
  component: DataQualityCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof DataQualityCard>;

const ITEM: DataQualityCardItem = {
  issue: "23 records have a malformed postcode",
  severity: "medium",
  records: "23 of 1,204",
  impact: "Regional rollups may undercount EU-West by up to 4%",
  fix: "Normalize postcode format from the source system",
  owner: "Data Engineering",
};

export const Default: Story = {
  render: () => (
    <div style={{ maxWidth: 460 }}>
      <DataQualityCard item={ITEM} onAssignOwner={() => {}} onDismiss={() => {}} />
    </div>
  ),
};

export const HighSeverity: Story = {
  render: () => (
    <div style={{ maxWidth: 460 }}>
      <DataQualityCard item={{ ...ITEM, severity: "high", issue: "Currency field missing on 340 invoices" }} />
    </div>
  ),
};
