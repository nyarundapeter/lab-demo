import type { Meta, StoryObj } from "@storybook/react";
import { ForecastInline } from "../components/forecast-inline.js";

const meta: Meta<typeof ForecastInline> = {
  title: "Layer 07 — App Scaffolds/Atoms/Indicators/ForecastInline",
  component: ForecastInline,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ForecastInline>;

export const Default: Story = {
  args: {
    text: (
      <>
        Backlog reaches <strong>~290</strong> in 2 weeks without added capacity.
      </>
    ),
  },
};

export const CustomLabel: Story = {
  args: { label: "Projected", text: "Ticket volume up 12% next quarter." },
};
