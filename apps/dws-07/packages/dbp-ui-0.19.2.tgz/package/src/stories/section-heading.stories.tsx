import type { Meta, StoryObj } from "@storybook/react"
import { SectionHeading } from "../components/section-heading.js"

const meta: Meta<typeof SectionHeading> = {
  title: "Layer 07 — App Scaffolds/Molecules/Public/SectionHeading",
  component: SectionHeading,
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj<typeof SectionHeading>

export const Centered: Story = {
  args: {
    kicker: "MARKETPLACE",
    title: "Browse our services",
    description: "Discover the offerings available on this platform.",
  },
}

export const LeftAligned: Story = {
  args: {
    align: "left",
    kicker: "LEGAL",
    title: "Legal & policies",
  },
}

export const TitleOnly: Story = {
  args: {
    title: "Our Platform",
    align: "center",
  },
}

export const WithLongDescription: Story = {
  args: {
    kicker: "SOLUTIONS",
    title: "Built for enterprise",
    description:
      "From digital operations to customer experience — our platform brings every service layer together, governed and ready for scale.",
    align: "center",
  },
}
