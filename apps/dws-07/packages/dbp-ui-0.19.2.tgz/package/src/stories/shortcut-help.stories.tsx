import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ShortcutHelp } from "../components/shortcut-help.js";
import type { ShortcutHelpConfig, ShortcutHelpDataState } from "../components/shortcut-help.js";
import { Button } from "../components/button.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Utilities/ShortcutHelp",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

const CONFIG: ShortcutHelpConfig = {
  groups: [
    {
      id: "global",
      title: "Global",
      bindings: [
        { id: "cmdk", keys: ["mod", "k"], description: "Open command palette" },
        { id: "help", keys: ["?"], description: "Show this shortcuts overlay" },
      ],
    },
    {
      id: "navigation",
      title: "Navigation",
      bindings: [
        { id: "next", keys: ["j"], description: "Next item in list" },
        { id: "prev", keys: ["k"], description: "Previous item in list" },
        { id: "back", keys: ["esc"], description: "Close panel / go back" },
        { id: "home", keys: ["g", "h"], description: "Go to Home", separator: "sequence" },
      ],
    },
    {
      id: "records",
      title: "Records",
      bindings: [
        { id: "new", keys: ["mod", "n"], description: "Create new record" },
        { id: "save", keys: ["mod", "shift", "enter"], description: "Save and close" },
      ],
    },
  ],
};

const EMPTY_CONFIG: ShortcutHelpConfig = { groups: [] };

function Harness({ config, state }: { config: ShortcutHelpConfig; state?: ShortcutHelpDataState }) {
  const [open, setOpen] = React.useState(true);
  return (
    <div>
      <Button variant="outline" onClick={() => setOpen(true)}>
        View shortcuts
      </Button>
      <ShortcutHelp open={open} onClose={() => setOpen(false)} config={config} {...(state ? { state } : {})} />
    </div>
  );
}

export const Populated: Story = {
  name: "Populated",
  render: () => <Harness config={CONFIG} state="populated" />,
};

export const Empty: Story = {
  name: "Empty (no registrations)",
  render: () => <Harness config={EMPTY_CONFIG} state="empty" />,
};

export const Loading: Story = {
  name: "Loading",
  render: () => <Harness config={CONFIG} state="loading" />,
};

export const WindowsPlatform: Story = {
  name: "Windows/Linux kbd rendering",
  render: () => {
    const [open, setOpen] = React.useState(true);
    return (
      <div>
        <Button variant="outline" onClick={() => setOpen(true)}>
          View shortcuts
        </Button>
        <ShortcutHelp open={open} onClose={() => setOpen(false)} config={CONFIG} platform="other" />
      </div>
    );
  },
};
