import type { Meta, StoryObj } from "@storybook/react";
import { Check } from "lucide-react";
import { Badge } from "../components/badge.js";
import { AiMark } from "../components/ai-mark.js";

const meta: Meta<typeof Badge> = {
  title: "Layer 07 — App Scaffolds/Atoms/Badge",
  component: Badge,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Badge>;

export const Default: Story = {
  args: { tone: "default", children: "Default" },
};

export const Success: Story = {
  args: { tone: "success", children: "Success" },
};

export const Warning: Story = {
  args: { tone: "warning", children: "Warning" },
};

export const Danger: Story = {
  args: { tone: "danger", children: "Danger" },
};

export const Info: Story = {
  args: { tone: "info", children: "Info" },
};

export const Active: Story = {
  args: { tone: "active", children: "Active" },
};

export const Paused: Story = {
  args: { tone: "paused", children: "Paused" },
};

export const Critical: Story = {
  args: { tone: "critical", children: "Critical" },
};

export const Testing: Story = {
  args: { tone: "testing", children: "Testing" },
};

export const Gray: Story = {
  args: { tone: "gray", children: "Gray" },
};

export const Orange: Story = {
  args: { tone: "orange", children: "Orange" },
};

export const Navy: Story = {
  args: { tone: "navy", children: "Navy" },
};

export const Ai: Story = {
  name: "AI (consolidated from ContextChip, 2026-07-20)",
  args: {
    tone: "ai",
    children: (
      <>
        <AiMark size={11} />
        Using current case
      </>
    ),
  },
};

export const WithDot: Story = {
  name: "With dot",
  args: { tone: "active", dot: true, children: "Active" },
};

export const WithIcon: Story = {
  name: "With icon (checkmark, spaced not overlapping)",
  args: {
    tone: "active",
    children: (
      <>
        <Check aria-hidden="true" />
        Active
      </>
    ),
  },
};

export const AllTones: Story = {
  name: "All tones (consolidated 2026-07-17)",
  render: () => (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", maxWidth: "560px" }}>
      <Badge tone="default">Default</Badge>
      <Badge tone="success">Success</Badge>
      <Badge tone="warning">Warning</Badge>
      <Badge tone="danger">Danger</Badge>
      <Badge tone="info">Info</Badge>
      <Badge tone="active">Active</Badge>
      <Badge tone="paused">Paused</Badge>
      <Badge tone="critical">Critical</Badge>
      <Badge tone="testing">Testing</Badge>
      <Badge tone="gray">Gray</Badge>
      <Badge tone="orange">Orange</Badge>
      <Badge tone="navy">Navy</Badge>
      <Badge tone="ai">
        <AiMark size={11} />
        AI
      </Badge>
    </div>
  ),
};
