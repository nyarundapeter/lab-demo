import type { Meta, StoryObj } from "@storybook/react";
import { FormField } from "../components/form-field.js";
import { Input } from "../components/input.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/FormField",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <FormField label="Email address" helperText="We'll never share your email." style={{ width: "320px" }}>
      <Input placeholder="you@example.com" type="email" />
    </FormField>
  ),
};

export const WithError: Story = {
  render: () => (
    <FormField label="Password" error="Password must be at least 8 characters." style={{ width: "320px" }}>
      <Input type="password" error />
    </FormField>
  ),
};

export const Required: Story = {
  render: () => (
    <FormField label="Full name" required style={{ width: "320px" }}>
      <Input placeholder="Jane Smith" />
    </FormField>
  ),
};

export const Optional: Story = {
  render: () => (
    <FormField label="Middle name" optional style={{ width: "320px" }}>
      <Input placeholder="Optional" />
    </FormField>
  ),
};

export const RequiredAndOptionalMarking: Story = {
  name: "Required/optional marking (NN/g convention)",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px", width: "320px" }}>
      <FormField label="Company name" required>
        <Input placeholder="Acme Inc." />
      </FormField>
      <FormField label="Website" optional>
        <Input placeholder="https://" />
      </FormField>
    </div>
  ),
};

export const ValidationStates: Story = {
  name: "Validation states (default/error/warning/success)",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px", width: "320px" }}>
      <FormField label="Full name" helperText="As it appears on your ID.">
        <Input placeholder="Jane Smith" />
      </FormField>
      <FormField label="Password" error="Password must be at least 8 characters.">
        <Input type="password" error />
      </FormField>
      <FormField label="Account name" state="warning" message="This name is close to an existing account.">
        <Input defaultValue="Acme" />
      </FormField>
      <FormField label="Username" state="success" message="This username is available.">
        <Input defaultValue="jane-smith" />
      </FormField>
    </div>
  ),
};
