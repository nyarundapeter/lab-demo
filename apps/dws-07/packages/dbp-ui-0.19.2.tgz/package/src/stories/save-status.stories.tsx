import type { Meta, StoryObj } from "@storybook/react";
import { SaveStatus } from "../components/save-status.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/SaveStatus",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Idle: Story = {
  name: "Idle (renders nothing)",
  render: () => (
    <div style={{ minHeight: 20 }}>
      <SaveStatus status="idle" />
    </div>
  ),
};

export const Saving: Story = {
  render: () => <SaveStatus status="saving" />,
};

export const Saved: Story = {
  render: () => <SaveStatus status="saved" savedAt="just now" />,
};

export const Error: Story = {
  render: () => <SaveStatus status="error" />,
};
