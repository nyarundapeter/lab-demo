import type { Meta, StoryObj } from "@storybook/react";
import React from "react";
import { CollectionToolbar } from "../components/collection-toolbar.js";
import { Button } from "../components/button.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Layout & Navigation/CollectionToolbar",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

const STATUS_OPTIONS = [
  { value: "all", label: "All" },
  { value: "open", label: "Open" },
  { value: "in-progress", label: "In Progress" },
];

export const Default: Story = {
  render: () => {
    const [status, setStatus] = React.useState("all");
    const [search, setSearch] = React.useState("");
    return (
      <CollectionToolbar
        statusOptions={STATUS_OPTIONS}
        statusValue={status}
        onStatusChange={setStatus}
        searchValue={search}
        onSearchChange={setSearch}
        resultCount="42 results"
      />
    );
  },
};

export const WithFiltersAndChips: Story = {
  render: () => {
    const [region, setRegion] = React.useState("all");
    const [chips, setChips] = React.useState([
      { key: "region", label: "Region: EMEA" },
      { key: "priority", label: "Priority: High" },
    ]);
    return (
      <CollectionToolbar
        statusOptions={STATUS_OPTIONS}
        statusValue="open"
        onStatusChange={() => {}}
        filters={[
          {
            key: "region",
            label: "Region",
            value: region,
            onChange: setRegion,
            options: [
              { value: "all", label: "All regions" },
              { value: "emea", label: "EMEA" },
              { value: "apac", label: "APAC" },
            ],
          },
        ]}
        chips={chips.map((c) => ({
          ...c,
          onRemove: () => setChips((prev) => prev.filter((x) => x.key !== c.key)),
        }))}
        onClearAll={() => setChips([])}
        resultCount="7 of 42 cases"
        actions={<Button size="sm">Export</Button>}
      />
    );
  },
};
