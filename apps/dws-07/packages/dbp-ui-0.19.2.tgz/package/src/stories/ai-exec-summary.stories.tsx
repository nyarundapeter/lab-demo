import type { Meta, StoryObj } from "@storybook/react";
import { AiExecSummary, type AiExecSummaryPoint } from "../components/ai-exec-summary.js";

const meta: Meta<typeof AiExecSummary> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AiExecSummary",
  component: AiExecSummary,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AiExecSummary>;

const POINTS: AiExecSummaryPoint[] = [
  { text: "Revenue trending above plan.", tone: "good", cite: "Revenue vs target" },
  { text: "Two initiatives moved to at-risk this week.", tone: "warn", cite: "Portfolio health" },
  { text: "Churn in the mid-market segment rose 1.4pt.", tone: "bad", cite: "Segment breakdown" },
];

export const Default: Story = {
  render: () => (
    <div style={{ maxWidth: 720 }}>
      <AiExecSummary
        period="This month"
        scope="Using dashboard scope"
        points={POINTS}
        outlook="On current trend, full-year revenue lands at £34.6M."
      />
    </div>
  ),
};

export const NoOutlook: Story = {
  render: () => (
    <div style={{ maxWidth: 480 }}>
      <AiExecSummary period="Q3 to date" points={POINTS.slice(0, 1)} />
    </div>
  ),
};
