import type { Meta, StoryObj } from "@storybook/react";
import { ExceptionCard } from "../components/exception-card.js";

const meta: Meta<typeof ExceptionCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/ExceptionCard",
  component: ExceptionCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ExceptionCard>;

export const Policy: Story = {
  args: {
    variant: "policy",
    title: "Threshold override applied",
    detail: "An approver overrode the $10,000 auto-approval threshold for this request.",
    onResolve: () => {},
  },
};

export const System: Story = {
  args: {
    variant: "system",
    title: "Integration timeout",
    detail: "The vendor verification service did not respond within 30s. The step is on hold.",
    onResolve: () => {},
  },
};
