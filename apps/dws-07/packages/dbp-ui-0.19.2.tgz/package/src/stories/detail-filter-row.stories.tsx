import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { DetailFilterRow } from "../components/detail-filter-row.js";

const meta: Meta<typeof DetailFilterRow> = {
  title: "Design System/Primitives/DetailFilterRow",
  component: DetailFilterRow,
  tags: ["autodocs"],
  argTypes: {
    countLabel: { control: "text" },
  },
  args: {
    countLabel: "12 of 513",
  },
};

export default meta;
type Story = StoryObj<typeof DetailFilterRow>;

export const MappingOnly: Story = {
  render: (args) => {
    const [active, setActive] = React.useState<"all" | "mapped" | "unmapped">("all");
    return (
      <DetailFilterRow
        {...args}
        mapping={{
          options: [
            { value: "all", label: "All" },
            { value: "mapped", label: "Mapped" },
            { value: "unmapped", label: "Unmapped" },
          ],
          active,
          onChange: setActive,
        }}
      />
    );
  },
};

export const FullRow: Story = {
  name: "Mapping + selects + search",
  render: (args) => {
    const [active, setActive] = React.useState<"all" | "partial" | "unmapped">("all");
    const [domain, setDomain] = React.useState("__all__");
    const [subDomain, setSubDomain] = React.useState("__all__");
    const [search, setSearch] = React.useState("");
    return (
      <DetailFilterRow
        {...args}
        mapping={{
          options: [
            { value: "all", label: "All" },
            { value: "partial", label: "Partial" },
            { value: "unmapped", label: "Unmapped" },
          ],
          active,
          onChange: setActive,
        }}
        select={{ value: domain, onChange: setDomain, allValue: "__all__", allLabel: "All domains", options: ["Privacy", "Security", "Financial"] }}
        secondarySelect={{ value: subDomain, onChange: setSubDomain, allValue: "__all__", allLabel: "All sub-domains", options: ["Retention", "Access", "Encryption"] }}
        search={{ value: search, onChange: setSearch, placeholder: "Search requirements…" }}
      />
    );
  },
};
