import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { InlineEditable } from "../components/inline-editable.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/InlineEditable",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

function Controlled({ initial, ...rest }: { initial: string } & Omit<
  React.ComponentProps<typeof InlineEditable>,
  "value" | "onSave"
>) {
  const [value, setValue] = React.useState(initial);
  return <InlineEditable {...rest} value={value} onSave={setValue} />;
}

export const Default: Story = {
  render: () => (
    <div style={{ width: 320 }}>
      <Controlled label="Deal name" initial="Q3 renewal — Acme Corp" />
    </div>
  ),
};

export const Empty: Story = {
  render: () => (
    <div style={{ width: 320 }}>
      <Controlled label="Deal name" initial="" placeholder="Untitled deal" />
    </div>
  ),
};

export const Multiline: Story = {
  render: () => (
    <div style={{ width: 320 }}>
      <Controlled
        label="Notes"
        initial="Follow up after the renewal call to confirm the new seat count."
        multiline
        helper="Cmd/Ctrl+Enter to save, Escape to cancel."
      />
    </div>
  ),
};

export const Disabled: Story = {
  render: () => (
    <div style={{ width: 320 }}>
      <Controlled label="Deal name" initial="Locked while under review" disabled />
    </div>
  ),
};
