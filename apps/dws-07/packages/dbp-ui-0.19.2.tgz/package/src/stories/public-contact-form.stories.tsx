import type { Meta, StoryObj } from "@storybook/react"
import { PublicContactForm } from "../components/public-contact-form.js"

const meta: Meta<typeof PublicContactForm> = {
  title: "Layer 07 — App Scaffolds/Molecules/Public/PublicContactForm",
  component: PublicContactForm,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj<typeof PublicContactForm>

export const Default: Story = {
  args: {
    headline: "Tell us what you need.",
    body: "Every message is reviewed by an advisor who will match you to the right services.",
    email: "info@digitalqatalyst.com",
    phone: "+971 4 266 6169",
    address: "708, Opal Tower, Business Bay, Dubai, UAE",
    interestOptions: [
      "Digital Transformation",
      "Platform Engineering",
      "Data & Analytics",
      "Customer Experience",
    ],
    needOptions: [
      "Advisory Consultation",
      "Platform Implementation",
      "Support & Managed Services",
    ],
  },
}

export const Minimal: Story = {
  args: {
    headline: "Get in touch.",
    body: "We will get back to you within 2 business days.",
    email: "info@digitalqatalyst.com",
  },
}

export const WithPhoneAndAddress: Story = {
  args: {
    headline: "Contact our team.",
    body: "Reach out and we will connect you with the right advisor.",
    email: "info@digitalqatalyst.com",
    phone: "+971 4 266 6169",
    address: "708, Opal Tower, Business Bay, Dubai, UAE",
  },
}
