import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureAuditClient, type AuditEvent } from "@dbp/ps-audit/client";
import { AdminAuditLog } from "../components/admin-audit-log.js";

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), { status: 200, headers: { "content-type": "application/json" } }),
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise<Response>(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal Server Error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      }),
    );
}

const EVENTS: AuditEvent[] = [
  {
    id: "e1000000-0000-0000-0000-000000000001",
    ts: "2026-06-20T08:00:00.000Z",
    actor: { userId: "u-001", email: "alice@example.com", displayName: "Alice Nguyen" },
    action: "user.login",
    target: { entityType: "Session", entityId: "sess-9999" },
    delta: null,
    tenantId: "tenant-alpha",
  },
  {
    id: "e2000000-0000-0000-0000-000000000002",
    ts: "2026-06-20T09:15:00.000Z",
    actor: { userId: "u-002", email: "bob@example.com", displayName: "Bob Kaur" },
    action: "role.assign",
    target: { entityType: "User", entityId: "u-010" },
    delta: null,
    tenantId: "tenant-alpha",
  },
  {
    id: "e3000000-0000-0000-0000-000000000003",
    ts: "2026-06-20T11:00:00.000Z",
    actor: { userId: "u-003", email: "carol@example.com", displayName: "Carol Hassan" },
    action: "login.failed",
    target: { entityType: "Session", entityId: "sess-1111" },
    delta: null,
    tenantId: "tenant-alpha",
  },
];

const meta: Meta<typeof AdminAuditLog> = {
  title: "Layer 07 — App Scaffolds/Organisms/AdminAuditLog",
  component: AdminAuditLog,
  tags: ["autodocs"],
  // AdminAuditLog owns its data fetch (useActivityFeed) and takes no props —
  // the mock response shape is the only per-story variable, driven via the
  // `decorators` below rather than `args`. argTypes declared for the
  // controls-everywhere ratchet; the component has nothing to control.
  argTypes: {},
};
export default meta;
type Story = StoryObj<typeof AdminAuditLog>;

function withAuditClient(fetchImpl: () => Promise<Response>) {
  return [
    (Story: React.ComponentType) => {
      configureAuditClient({
        baseUrl: "http://storybook.test/api/platform/audit",
        fetch: fetchImpl,
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <Story />
        </QueryClientProvider>
      );
    },
  ];
}

export const Default: Story = {
  decorators: withAuditClient(makeFetch({ events: EVENTS, nextCursor: null })),
};

export const Loading: Story = {
  decorators: withAuditClient(pendingFetch()),
};

export const Empty: Story = {
  decorators: withAuditClient(makeFetch({ events: [], nextCursor: null })),
};

export const Error: Story = {
  decorators: withAuditClient(errorFetch()),
};
