import type { Meta, StoryObj } from "@storybook/react";
import { SectionHeading } from "./foundations-shared.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Foundations/RadiusAndShadow",
  tags: ["autodocs"],
  parameters: { layout: "fullscreen" },
};
export default meta;
type Story = StoryObj;

const RADIUS_SCALE: [string, string][] = [
  ["--radius", "radius"],
  ["--radius-button", "radius-button"],
  ["--radius-input", "radius-input"],
  ["--radius-card", "radius-card"],
  ["--radius-md", "radius-md"],
  ["--radius-modal", "radius-modal"],
  ["--radius-pill", "radius-pill"],
];

const SHADOW_SCALE: [string, string][] = [
  ["--shadow-sm", "shadow-sm"],
  ["--shadow-md", "shadow-md"],
  ["--shadow-lg", "shadow-lg"],
  ["--shadow-xl", "shadow-xl"],
  ["--shadow-hover", "shadow-hover"],
];

export const Scales: Story = {
  render: () => (
    <div style={{ padding: 32, background: "var(--color-surface)" }}>
      <section style={{ marginBottom: 32 }}>
        <SectionHeading>Radius</SectionHeading>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 20 }}>
          {RADIUS_SCALE.map(([token, label]) => (
            <div key={token} style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "center" }}>
              <div style={{ width: 64, height: 64, background: "var(--color-surface-2)", border: "1px solid var(--color-border-default)", borderRadius: `var(${token})` }} />
              <span style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: "var(--color-text-muted)" }}>{label}</span>
            </div>
          ))}
        </div>
      </section>
      <section>
        <SectionHeading>Shadow</SectionHeading>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 28 }}>
          {SHADOW_SCALE.map(([token, label]) => (
            <div key={token} style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "center" }}>
              <div style={{ width: 72, height: 72, background: "var(--color-surface-2)", borderRadius: "var(--radius-md)", boxShadow: `var(${token})` }} />
              <span style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: "var(--color-text-muted)" }}>{label}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  ),
};
