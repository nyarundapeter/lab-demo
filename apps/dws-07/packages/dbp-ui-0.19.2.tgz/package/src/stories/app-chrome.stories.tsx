import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { AppChrome } from "../components/app-chrome.js";
import type { AppChromeSession } from "../components/app-chrome.js";
import { Input } from "../components/input.js";

const client = new QueryClient();

const meta: Meta<typeof AppChrome> = {
  title: "Layer 07 — App Scaffolds/Molecules/Chrome/AppChrome",
  component: AppChrome,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
  decorators: [
    (Story) => (
      <QueryClientProvider client={client}>
        <Story />
      </QueryClientProvider>
    ),
  ],
};
export default meta;
type Story = StoryObj<typeof AppChrome>;

const approver: AppChromeSession = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  displayName: "Alpha Finance Approver",
  primaryRole: "Finance Approver",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
};

const multiRole: AppChromeSession = {
  ...approver,
  displayName: "Sam Okoro",
  // Many roles — proves the switcher is a compact dropdown that does not overflow
  // the top bar (a SegmentedControl would).
  roles: [
    "platform-admin",
    "cro",
    "risk-manager",
    "compliance-officer",
    "internal-auditor",
    "control-owner",
    "viewer",
  ],
};

/**
 * AppChrome no longer imports the search/notification organisms itself
 * (Layer 06/07 boundary — `@dbp/ui` stays free of PS.SEARCH/PS.NOTIF-fetching
 * code). In a real solution these slots are filled with the actual
 * `@dbp/organisms/search-bar` / `@dbp/organisms/notification-bell` elements
 * (see the `SolutionChrome` wrapper the generator emits); these stories use
 * lightweight stand-ins so the chrome's own layout can be demonstrated
 * without wiring live PS.SEARCH/PS.NOTIF backends.
 */
function SearchSlotPlaceholder() {
  return <Input type="text" placeholder="Search shifts, people, requests…" className="w-full" />;
}
function NotificationSlotPlaceholder() {
  return (
    <button
      type="button"
      aria-label="Notifications"
      className="flex h-[var(--shell-control-h)] w-[var(--shell-control-h)] items-center justify-center rounded-button text-primary hover:bg-surface"
    >
      <Bell size={17} strokeWidth={1.5} aria-hidden="true" />
    </button>
  );
}

/**
 * Fully wired solution (PS.SEARCH + PS.NOTIF): global search, notification bell,
 * settings, and the avatar block — all session + capability driven.
 */
export const FullyWired: Story = {
  args: {
    productCode: "DWS.05",
    productName: "Digital WFMS",
    session: approver,
    search: <SearchSlotPlaceholder />,
    notifications: <NotificationSlotPlaceholder />,
  },
};

/**
 * Analytics solution (PS.AUTH + PS.DATA + PS.AI only): NO search, NO bell — just
 * settings + avatar. Demonstrates that omitting a slot is the capability gate.
 */
export const NoSearchNoBell: Story = {
  args: {
    productCode: "DIA.02",
    productName: "AnalyticsOps",
    session: approver,
  },
};

/** Multi-role session — the optional role switcher appears as a compact dropdown (lg+). */
export const WithRoleSwitcher: Story = {
  args: {
    productCode: "DWS.04",
    productName: "Digital ERP",
    session: multiRole,
    search: <SearchSlotPlaceholder />,
    notifications: <NotificationSlotPlaceholder />,
  },
};

const noRoles: AppChromeSession = {
  ...approver,
  displayName: "Jordan Reyes",
  primaryRole: "",
  roles: [],
};

/**
 * Tenant-scoped session with zero roles (e.g. after switching to a non-home
 * tenant with no grant there) — the avatar sub-label shows an explicit muted
 * "No roles in this workspace" state instead of rendering nothing; no role
 * switcher, consistent with the single-role behaviour.
 */
export const NoRolesInWorkspace: Story = {
  args: {
    productCode: "DWS.04",
    productName: "Digital ERP",
    session: noRoles,
    search: <SearchSlotPlaceholder />,
    notifications: <NotificationSlotPlaceholder />,
  },
};

/** Loading / unauthenticated — session is null, so no avatar block renders. */
export const NoSession: Story = {
  args: {
    productCode: "DXP.01A",
    productName: "Digital Channels Web",
    session: null,
    search: <SearchSlotPlaceholder />,
    notifications: <NotificationSlotPlaceholder />,
  },
};
