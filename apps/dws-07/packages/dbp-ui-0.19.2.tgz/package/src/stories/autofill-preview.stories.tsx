import type { Meta, StoryObj } from "@storybook/react";
import { AutofillPreview, type AutofillPreviewData } from "../components/autofill-preview.js";

const meta: Meta<typeof AutofillPreview> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AutofillPreview",
  component: AutofillPreview,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AutofillPreview>;

const DATA: AutofillPreviewData = {
  sourceName: "meridian-intake.eml",
  fields: [
    { field: "Company", value: "Meridian Foods", note: "Email signature", conf: "high" },
    { field: "Region", value: "EU-West", note: "IP geolocation", conf: "medium" },
    {
      field: "Priority",
      value: "High",
      note: "Keyword match",
      conf: "low",
      conflict: true,
      existing: "Medium",
    },
  ],
};

export const ReviewStep: Story = {
  render: () => (
    <div style={{ maxWidth: 520 }}>
      <AutofillPreview data={DATA} onApply={() => {}} onClose={() => {}} />
    </div>
  ),
};

export const NoConflicts: Story = {
  render: () => (
    <div style={{ maxWidth: 520 }}>
      <AutofillPreview
        data={{ sourceName: "profile record", fields: DATA.fields.filter((f) => !f.conflict) }}
        onApply={() => {}}
        onClose={() => {}}
      />
    </div>
  ),
};
