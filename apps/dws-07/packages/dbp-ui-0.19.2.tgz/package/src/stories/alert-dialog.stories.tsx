import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { Button } from "../components/button.js";
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
  ConfirmDialog,
  DestructiveConfirmDialog,
  HighImpactConfirmDialog,
  BulkConfirmDialog,
  ProductionConfirmDialog,
  UnsavedChangesConfirmDialog,
} from "../components/alert-dialog.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Overlays/AlertDialog",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="navy">Open alert dialog</Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Discard changes?</AlertDialogTitle>
          <AlertDialogDescription>
            You have unsaved changes. This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel asChild>
            <Button variant="ghost">Cancel</Button>
          </AlertDialogCancel>
          <AlertDialogAction asChild>
            <Button variant="orange">Discard</Button>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  ),
};

export const ConfirmDialogDefault: Story = {
  render: () => {
    const [open, setOpen] = React.useState(false);
    return (
      <>
        <Button variant="navy" onClick={() => setOpen(true)}>
          Leave page
        </Button>
        <ConfirmDialog
          open={open}
          onOpenChange={setOpen}
          title="Leave without saving?"
          description="Your changes will be lost if you leave this page."
          confirmLabel="Leave"
          cancelLabel="Stay"
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

export const ConfirmDialogDestructive: Story = {
  render: () => {
    const [open, setOpen] = React.useState(false);
    return (
      <>
        <Button variant="destructive" onClick={() => setOpen(true)}>
          Delete record
        </Button>
        <ConfirmDialog
          open={open}
          onOpenChange={setOpen}
          title="Delete this record?"
          description="This action is permanent and cannot be undone."
          confirmLabel="Delete"
          destructive
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

// ─── Risk-tier confirm variants (OVL-05) ──────────────────────────────────

export const RiskTierDestructive: Story = {
  name: "Risk tier — Destructive",
  render: () => {
    const [open, setOpen] = React.useState(false);
    return (
      <>
        <Button variant="destructive" onClick={() => setOpen(true)}>
          Delete request
        </Button>
        <DestructiveConfirmDialog
          open={open}
          onOpenChange={setOpen}
          title="Delete request SR-4815?"
          description={'"Offboard contractor — revoke all access" will be permanently deleted from Meridian Foods.'}
          impact={
            <span>
              This also removes <strong>2 linked tasks</strong> and cancels a scheduled access review.
              Deleted requests can be restored within 30 days, after which removal is permanent.
            </span>
          }
          recoveryNote="Recoverable for 30 days"
          confirmLabel="Delete request"
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

export const RiskTierHighImpact: Story = {
  name: "Risk tier — High-impact (required reason)",
  render: () => {
    const [open, setOpen] = React.useState(false);
    const [reason, setReason] = React.useState("");
    return (
      <>
        <Button variant="destructive" onClick={() => setOpen(true)}>
          Revoke all access
        </Button>
        <HighImpactConfirmDialog
          open={open}
          onOpenChange={setOpen}
          title="Revoke all access for this contractor?"
          description="This immediately revokes every active grant for Camille Dubois. Active sessions are terminated and cannot be restored automatically."
          impactRows={[
            { label: "Systems affected", value: "Okta, VPN, Salesforce, GitHub, AWS" },
            { label: "Active sessions", value: "4 will end now" },
          ]}
          reasonOptions={[
            { value: "ended", label: "Engagement ended" },
            { value: "security", label: "Security concern" },
            { value: "policy", label: "Policy violation" },
            { value: "manager", label: "Requested by manager" },
          ]}
          reason={reason}
          onReasonChange={setReason}
          confirmLabel="Revoke 6 grants"
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

export const RiskTierBulk: Story = {
  name: "Risk tier — Bulk (count + preview)",
  render: () => {
    const [open, setOpen] = React.useState(false);
    return (
      <>
        <Button variant="orange" onClick={() => setOpen(true)}>
          Close 12 requests
        </Button>
        <BulkConfirmDialog
          open={open}
          onOpenChange={setOpen}
          title="Close 12 requests?"
          description="All 12 selected requests will be marked Resolved and their requesters notified."
          affectedPreview={
            <span>
              <strong>3 of 12</strong> have open sub-tasks that will be cancelled. Review those first if
              you&rsquo;re unsure.
            </span>
          }
          confirmLabel="Close 12 requests"
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

export const RiskTierProduction: Story = {
  name: "Risk tier — Production (typed-phrase arm-to-confirm)",
  render: () => {
    const [open, setOpen] = React.useState(false);
    return (
      <>
        <Button variant="destructive" onClick={() => setOpen(true)}>
          Publish to production
        </Button>
        <ProductionConfirmDialog
          open={open}
          onOpenChange={setOpen}
          title="Publish workflow to production?"
          description={'This replaces the live "Access approval v3" workflow. It affects every in-flight request and takes effect immediately for all users.'}
          envContext="Northwind Labs · eu-central-1"
          armPhrase="PRODUCTION"
          ackLabel="I understand this change is logged to the audit trail and takes effect immediately."
          confirmLabel="Publish to production"
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

export const RiskTierUnsaved: Story = {
  name: "Risk tier — Unsaved changes (6th tier, closes OVL-05)",
  render: () => {
    const [open, setOpen] = React.useState(false);
    return (
      <>
        <Button variant="outline" onClick={() => setOpen(true)}>
          Close editor
        </Button>
        <UnsavedChangesConfirmDialog
          open={open}
          onOpenChange={setOpen}
          description="You've made changes to SR-4820 that haven't been saved. Leaving now will discard them."
          onDiscard={() => setOpen(false)}
          onSaveAndLeave={() => setOpen(false)}
        />
      </>
    );
  },
};
