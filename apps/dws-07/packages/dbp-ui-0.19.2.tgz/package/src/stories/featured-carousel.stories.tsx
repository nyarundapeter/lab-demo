import type { Meta, StoryObj } from "@storybook/react";
import * as React from "react";
import { FeaturedCarousel } from "../components/featured-carousel.js";

const meta: Meta<typeof FeaturedCarousel> = {
  title: "Layer 07 — App Scaffolds/Molecules/Layout & Navigation/FeaturedCarousel",
  component: FeaturedCarousel,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof FeaturedCarousel>;

const MOCK_ROWS = Array.from({ length: 6 }).map((_, i) => ({
  id: `svc-${i + 1}`,
  data: {
    title: [
      "Digital ERP Suite",
      "Analytics Platform",
      "Fleet Management",
      "Procurement Hub",
      "Customer Portal",
      "Workflow Automation",
    ][i],
    description: "Curated platform offering, pre-configured for fast rollout.",
    typeLabel: "Solution",
    status: "Available",
    featured: true,
  },
}));

/** FeaturedCarousel fetches `/api/platform/data/entities/...` on mount — stub
 * `window.fetch` for the story so it renders real cards instead of the
 * loading skeleton / empty-state null-render. */
function MockedCarousel(props: React.ComponentProps<typeof FeaturedCarousel>) {
  React.useEffect(() => {
    const original = window.fetch;
    window.fetch = (async () =>
      new Response(JSON.stringify({ rows: MOCK_ROWS }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      })) as typeof window.fetch;
    return () => {
      window.fetch = original;
    };
  }, []);
  return <FeaturedCarousel {...props} />;
}

export const Default: Story = {
  render: () => (
    <MockedCarousel
      entityType="services"
      kicker="Curated Selection"
      title="Featured Services"
      lede="Hand-picked offerings from the platform catalogue."
      featuredField="featured"
      cardFields={{ title: "title", description: "description", typeLabel: "typeLabel", status: "status" }}
    />
  ),
};
