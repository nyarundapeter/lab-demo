import type { Meta, StoryObj } from "@storybook/react";
import type { ComponentProps } from "react";
import { Workflow, GitBranch, FileText, Hash, Plug, Database, Users } from "lucide-react";
import { ChangeImpactPanel, type ImpactItem } from "../components/change-impact-panel.js";

const IMPACT_ITEMS: ImpactItem[] = [
  {
    type: "Workflows",
    icon: <Workflow size={14} strokeWidth={1.5} />,
    count: 2,
    items: ["Incident escalation", "SLA breach handling"],
    to: "workflows",
  },
  {
    type: "Rules",
    icon: <GitBranch size={14} strokeWidth={1.5} />,
    count: 1,
    items: ["VIP customer fast-track"],
    to: "rules",
    conflict: true,
  },
  {
    type: "Forms",
    icon: <FileText size={14} strokeWidth={1.5} />,
    count: 2,
    items: ["Service request intake", "Escalation form"],
  },
  {
    type: "Fields",
    icon: <Hash size={14} strokeWidth={1.5} />,
    count: 1,
    items: ["account.tier (referenced)"],
  },
  {
    type: "Integrations",
    icon: <Plug size={14} strokeWidth={1.5} />,
    count: 1,
    items: ["ServiceNow sync"],
    to: "integrations",
  },
  {
    type: "Active records",
    icon: <Database size={14} strokeWidth={1.5} />,
    count: 214,
    items: ["Requests matching in last 30 days"],
  },
  {
    type: "Users affected",
    icon: <Users size={14} strokeWidth={1.5} />,
    count: 42,
    items: ["EMEA Infrastructure Desk (12)", "General Triage (30)"],
  },
];

const meta: Meta<typeof ChangeImpactPanel> = {
  title: "Layer 07 — App Scaffolds/Molecules/Config/ChangeImpactPanel",
  component: ChangeImpactPanel,
  tags: ["autodocs"],
  parameters: { layout: "padded" },
};
export default meta;
type Story = StoryObj<typeof ChangeImpactPanel>;

const renderPanel = (args: ComponentProps<typeof ChangeImpactPanel>) => (
  <div style={{ maxWidth: 640 }}>
    <ChangeImpactPanel {...args} />
  </div>
);

const defaultArgs = {
  items: IMPACT_ITEMS,
  riskLevel: "medium" as const,
  onNavigate: (to: string) => console.log("Navigate:", to),
};

export const Default: Story = {
  args: defaultArgs,
  render: renderPanel,
};

export const LowRisk: Story = {
  name: "Low risk",
  args: {
    ...defaultArgs,
    riskLevel: "low",
  },
  render: renderPanel,
};

export const HighRisk: Story = {
  name: "High risk",
  args: {
    ...defaultArgs,
    riskLevel: "high",
  },
  render: renderPanel,
};

export const NoConflicts: Story = {
  name: "No conflicts",
  args: {
    items: IMPACT_ITEMS.map((item) => ({ ...item, conflict: false })),
    riskLevel: "low",
  },
  render: renderPanel,
};
