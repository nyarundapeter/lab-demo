import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { AISearchBar } from "../components/ai-search-bar.js";

const meta: Meta<typeof AISearchBar> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AISearchBar",
  component: AISearchBar,
  tags: ["autodocs"],
  argTypes: {
    placeholder: { control: "text" },
    kbdHint: { control: "boolean" },
  },
  parameters: {
    layout: "padded",
  },
};

export default meta;
type Story = StoryObj<typeof AISearchBar>;

export const Default: Story = {
  args: {
    placeholder: "Search or ask anything…",
    kbdHint: true,
    onSubmit: (value: string) => console.log("Submitted:", value),
  },
};

export const WithoutKbdHint: Story = {
  name: "Without keyboard hint",
  args: {
    placeholder: "Search…",
    kbdHint: false,
    onSubmit: (value: string) => console.log("Submitted:", value),
  },
};

export const CustomPlaceholder: Story = {
  name: "Custom placeholder",
  args: {
    placeholder: "Search data products, knowledge, or ask a question…",
    kbdHint: true,
    onSubmit: (value: string) => console.log("Submitted:", value),
  },
};

export const WithSuggestionsLayout: Story = {
  name: "With suggestions (layout)",
  render: () => {
    const [submitted, setSubmitted] = React.useState<string | null>(null);
    const suggestions = ["Sales analytics", "Customer data", "Revenue dashboard", "Data quality"];

    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: "600px" }}>
        <AISearchBar
          placeholder="Search or ask anything…"
          onSubmit={(v) => setSubmitted(v)}
        />
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {suggestions.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSubmitted(s)}
              style={{
                padding: "4px 12px",
                borderRadius: "9999px",
                border: "1px solid var(--color-border)",
                fontSize: "12px",
                background: "white",
                cursor: "pointer",
              }}
            >
              {s}
            </button>
          ))}
        </div>
        {submitted && (
          <p style={{ fontSize: "13px", color: "var(--color-text-muted)" }}>
            Submitted: <strong>{submitted}</strong>
          </p>
        )}
      </div>
    );
  },
};

export const FullWidth: Story = {
  name: "Full width",
  render: () => (
    <div style={{ width: "100%" }}>
      <AISearchBar
        placeholder="Search or ask anything…"
        onSubmit={(v) => console.log("Submitted:", v)}
      />
    </div>
  ),
};
