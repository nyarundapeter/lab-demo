import type { Meta, StoryObj } from "@storybook/react";
import { HealthStatusCard } from "../components/health-status-card.js";

const meta: Meta<typeof HealthStatusCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/HealthStatusCard",
  component: HealthStatusCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof HealthStatusCard>;

export const OnTrack: Story = {
  args: {
    title: "Q3 Renewals",
    status: "good",
    headline: "94%",
    subMetrics: [
      { label: "Renewed", value: 142 },
      { label: "At risk", value: 6 },
      { label: "Churned", value: 3 },
    ],
    action: "View portfolio",
  },
};

export const AtRisk: Story = {
  args: {
    title: "Platform SLA",
    status: "warn",
    headline: "98.2%",
    subMetrics: [
      { label: "Incidents", value: 4 },
      { label: "MTTR", value: "38m" },
    ],
  },
};
