import type { Meta, StoryObj } from "@storybook/react";
import { Gauge } from "../components/gauge.js";

const meta: Meta<typeof Gauge> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/Gauge",
  component: Gauge,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Gauge>;

const THRESHOLDS = [
  { upTo: 60, color: "var(--color-success)" },
  { upTo: 85, color: "var(--color-warning)" },
  { upTo: 100, color: "var(--color-danger)" },
];

export const Default: Story = {
  args: { value: 42, thresholds: THRESHOLDS, label: "Licence usage" },
};

export const WarningBand: Story = {
  args: { value: 78, thresholds: THRESHOLDS, label: "Licence usage" },
};

export const DangerBand: Story = {
  args: { value: 96, thresholds: THRESHOLDS, label: "Licence usage" },
};

export const CustomUnit: Story = {
  args: {
    value: 72,
    max: 100,
    unit: "ms",
    label: "Latency",
    thresholds: [
      { upTo: 50, color: "var(--color-success)" },
      { upTo: 80, color: "var(--color-warning)" },
      { upTo: 100, color: "var(--color-danger)" },
    ],
  },
};

export const AllBands: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "24px" }}>
      <Gauge value={42} thresholds={THRESHOLDS} label="Good" />
      <Gauge value={78} thresholds={THRESHOLDS} label="Warning" />
      <Gauge value={96} thresholds={THRESHOLDS} label="Danger" />
    </div>
  ),
};
