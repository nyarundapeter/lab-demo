import type { Meta, StoryObj } from "@storybook/react";
import { ChevronLeft, Download, X } from "lucide-react";
import {
  FullScreenModal,
  FullScreenModalTrigger,
  FullScreenModalContent,
  FullScreenModalBar,
  FullScreenModalTitle,
  FullScreenModalDescription,
  FullScreenModalBody,
  FullScreenModalMain,
  FullScreenModalRail,
  FullScreenModalFooter,
  FullScreenModalClose,
} from "../components/fullscreen-modal.js";
import { Button } from "../components/button.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Overlays/FullScreenModal",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

/** Document review — main pane + info rail, read-only footer note + primary action. */
export const DocumentReview: Story = {
  render: () => (
    <FullScreenModal>
      <FullScreenModalTrigger asChild>
        <Button variant="outline">Review document</Button>
      </FullScreenModalTrigger>
      <FullScreenModalContent hideClose aria-describedby={undefined}>
        <FullScreenModalBar>
          <FullScreenModalClose asChild>
            <button
              type="button"
              aria-label="Back"
              className="flex h-8 w-8 items-center justify-center rounded text-[var(--color-text-muted)] hover:bg-[var(--color-navy-50)]"
            >
              <ChevronLeft size={18} />
            </button>
          </FullScreenModalClose>
          <div className="min-w-0">
            <FullScreenModalDescription>Document review · SR-4815</FullScreenModalDescription>
            <FullScreenModalTitle>MSA_Meridian_v3.pdf</FullScreenModalTitle>
          </div>
          <div className="flex-1" />
          <button
            type="button"
            title="Download"
            className="flex h-8 w-8 items-center justify-center rounded text-[var(--color-text-muted)] hover:bg-[var(--color-navy-50)]"
          >
            <Download size={16} />
          </button>
          <FullScreenModalClose asChild>
            <button
              type="button"
              aria-label="Close"
              className="flex h-8 w-8 items-center justify-center rounded text-[var(--color-text-muted)] hover:bg-[var(--color-navy-50)]"
            >
              <X size={18} />
            </button>
          </FullScreenModalClose>
        </FullScreenModalBar>
        <FullScreenModalBody>
          <FullScreenModalMain>
            <div className="flex justify-center p-8">
              <div className="w-full max-w-[620px] rounded-card border border-[var(--color-border-subtle)] bg-white p-10 shadow-sm">
                <div className="mb-5 text-[11px] uppercase tracking-[0.1em] text-[var(--color-text-muted)]">
                  Master Services Agreement
                </div>
                <div className="mb-4 text-lg font-semibold">Meridian Foods — Amendment 3</div>
                <div className="flex flex-col gap-2.5">
                  {[95, 88, 92, 70].map((w, i) => (
                    <div key={i} className="h-2 rounded bg-[var(--color-surface)]" style={{ width: `${w}%` }} />
                  ))}
                </div>
              </div>
            </div>
          </FullScreenModalMain>
          <FullScreenModalRail>
            <div className="mb-3 text-xs font-semibold uppercase tracking-[0.04em] text-[var(--color-text-muted)]">
              Document info
            </div>
            <dl className="flex flex-col gap-2 text-xs">
              <div>
                <dt className="text-[var(--color-text-muted)]">File</dt>
                <dd>MSA_v3.pdf · 284 KB</dd>
              </div>
              <div>
                <dt className="text-[var(--color-text-muted)]">Uploaded</dt>
                <dd>Ava Okafor · 2h ago</dd>
              </div>
              <div>
                <dt className="text-[var(--color-text-muted)]">Pages</dt>
                <dd>14</dd>
              </div>
            </dl>
          </FullScreenModalRail>
        </FullScreenModalBody>
        <FullScreenModalFooter>
          <span className="text-xs text-[var(--color-text-muted)]">Read-only preview</span>
          <div className="flex-1" />
          <FullScreenModalClose asChild>
            <Button variant="outline" size="sm">Close</Button>
          </FullScreenModalClose>
          <Button size="sm">Approve document</Button>
        </FullScreenModalFooter>
      </FullScreenModalContent>
    </FullScreenModal>
  ),
};

/** Bulk edit — form main pane + affected-records rail, sticky apply action. */
export const BulkEdit: Story = {
  render: () => (
    <FullScreenModal>
      <FullScreenModalTrigger asChild>
        <Button variant="outline">Bulk edit 12 requests</Button>
      </FullScreenModalTrigger>
      <FullScreenModalContent hideClose aria-describedby={undefined}>
        <FullScreenModalBar>
          <FullScreenModalClose asChild>
            <button
              type="button"
              aria-label="Back"
              className="flex h-8 w-8 items-center justify-center rounded text-[var(--color-text-muted)] hover:bg-[var(--color-navy-50)]"
            >
              <ChevronLeft size={18} />
            </button>
          </FullScreenModalClose>
          <div className="min-w-0">
            <FullScreenModalDescription>Bulk action review</FullScreenModalDescription>
            <FullScreenModalTitle>Bulk edit — 12 requests</FullScreenModalTitle>
          </div>
        </FullScreenModalBar>
        <FullScreenModalBody>
          <FullScreenModalMain>
            <div className="p-6">
              <div className="mb-4 rounded-card border border-[var(--color-info-border)] bg-[var(--color-info-surface)] p-3 text-sm text-[var(--color-info-text)]">
                Editing <strong>12 requests</strong>. Blank fields are left unchanged.
              </div>
              <div className="grid max-w-[560px] grid-cols-2 gap-4">
                <label className="flex flex-col gap-1 text-xs font-medium text-[var(--color-text-primary)]">
                  Priority
                  <select className="rounded border border-[var(--color-border-default)] px-2 py-1.5 text-sm">
                    <option>Leave unchanged</option>
                  </select>
                </label>
                <label className="flex flex-col gap-1 text-xs font-medium text-[var(--color-text-primary)]">
                  Status
                  <select className="rounded border border-[var(--color-border-default)] px-2 py-1.5 text-sm">
                    <option>Leave unchanged</option>
                  </select>
                </label>
              </div>
            </div>
          </FullScreenModalMain>
          <FullScreenModalRail>
            <div className="mb-3 text-xs font-semibold uppercase tracking-[0.04em] text-[var(--color-text-muted)]">
              Affected records
            </div>
            <div className="flex flex-col gap-2 text-xs text-[var(--color-text-muted)]">
              <span>SR-4801 · SR-4802 · SR-4803</span>
              <span>…and 9 more</span>
            </div>
          </FullScreenModalRail>
        </FullScreenModalBody>
        <FullScreenModalFooter>
          <div className="flex-1" />
          <FullScreenModalClose asChild>
            <Button variant="outline" size="sm">Cancel</Button>
          </FullScreenModalClose>
          <FullScreenModalClose asChild>
            <Button size="sm">Apply to 12 requests</Button>
          </FullScreenModalClose>
        </FullScreenModalFooter>
      </FullScreenModalContent>
    </FullScreenModal>
  ),
};
