import type { Meta, StoryObj } from "@storybook/react";
import { AppFooter } from "../components/app-footer.js";

const meta: Meta<typeof AppFooter> = {
  title: "Layer 07 — App Scaffolds/Molecules/Chrome/AppFooter",
  component: AppFooter,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AppFooter>;

/** Full status bar: copyright lockup, command hints, links, env badge, version. */
export const Default: Story = {
  args: {
    productName: "Digital Workspace",
    year: 2026,
    version: "v1.4.2",
    shortcuts: [
      { keys: "⌘K", label: "Search" },
      { keys: "⌘/", label: "Help" },
      { keys: "G then H", label: "Home" },
    ],
    links: [
      { label: "Privacy", href: "/privacy" },
      { label: "Terms", href: "/terms" },
      { label: "Support", href: "/help" },
    ],
  },
};

/** With a non-production environment badge. */
export const WithEnvBadge: Story = {
  args: {
    ...Default.args,
    env: "Staging",
  },
};

/** Minimal: copyright + version only (no shortcuts, no links). */
export const Minimal: Story = {
  args: {
    productName: "Digital Workspace",
    year: 2026,
    version: "v1.4.2",
  },
};

/** Explicit copyright string overrides the composed default. */
export const ExplicitCopyright: Story = {
  args: {
    copyright: "© 2026 DigitalQatalyst. All rights reserved.",
    version: "build 8d67f84",
  },
};

/**
 * All optional props omitted — every zone must render nothing (no empty styled
 * elements). Guards the RC-C optional-slot discipline.
 */
export const Empty: Story = {
  args: {},
};
