import type { Meta, StoryObj } from '@storybook/react'
import { PublicPageHeader } from '../components/public-page-header.js'

const meta: Meta<typeof PublicPageHeader> = {
  title: 'Layer 07 — App Scaffolds/Molecules/Public/PublicPageHeader',
  component: PublicPageHeader,
  parameters: { layout: 'fullscreen' },
}
export default meta
type Story = StoryObj<typeof PublicPageHeader>

/** Contact / legal style — eyebrow + title + subtitle, no aside. */
export const ContentPage: Story = {
  args: {
    eyebrow: 'Contact',
    title: 'Tell us what you need.',
    subtitle:
      'Every message is reviewed by an advisor who will match you to the right services and next steps.',
  },
}

/** Marketplace detail style — text meta line (no pills) + summary + ideal-for + a right-hand aside card. */
export const DetailWithAside: Story = {
  args: {
    title: 'Cloud Infrastructure Setup',
    meta: (
      <div className="flex flex-wrap items-center gap-x-2.5 gap-y-2 text-sm text-gray-500">
        <span className="font-medium capitalize text-gray-600">Technology</span>
        <span aria-hidden="true" className="text-gray-300">•</span>
        <span className="capitalize">Enterprise</span>
        <span className="ml-0.5 inline-flex items-center gap-1 rounded-full bg-[var(--color-primary)] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.1em] text-white">
          High-Impact
        </span>
      </div>
    ),
    subtitle: 'Full cloud environment provisioning on major providers with IaC templates and runbooks.',
    children: (
      <p className="mt-6 text-sm text-gray-500">
        <span className="font-medium text-gray-700">Ideal for: </span>
        Cloud architects, platform engineering leads, IT directors
      </p>
    ),
    aside: (
      <div className="rounded-2xl border border-gray-200 bg-white p-7 shadow-sm">
        <p className="text-3xl font-bold text-[var(--color-primary)]">From $12,000</p>
        <p className="mt-1 text-sm text-gray-500">Timeline: 3 Weeks</p>
        <button
          type="button"
          className="mt-7 w-full rounded-full bg-[var(--color-secondary)] px-6 py-3.5 text-sm font-semibold text-white"
        >
          Get started
        </button>
      </div>
    ),
  },
}

/** Grid backdrop disabled. */
export const NoGrid: Story = {
  args: {
    eyebrow: 'Legal',
    title: 'Privacy Policy',
    subtitle: 'How we collect, use, and protect your information.',
    grid: false,
  },
}
