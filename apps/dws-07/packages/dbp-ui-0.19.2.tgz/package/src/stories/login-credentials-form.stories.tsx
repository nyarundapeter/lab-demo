import type * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { LoginCredentialsForm } from "../components/login-credentials-form.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Chrome/LoginCredentialsForm",
  tags: ["autodocs"],
  parameters: {
    docs: {
      description: {
        component:
          "Email + password credentials form for (public)/login pages — owns the form chrome (labels, inputs, error alert, submit, optional demo-account prefill) so page files stay pure declarations per ADR-0035.",
      },
    },
  },
};
export default meta;
type Story = StoryObj;

const SEED_USERS = [
  { label: "Platform Admin (tenant-alpha)", email: "platform-admin@alpha.dev.local" },
  { label: "Demo User (tenant-alpha)", email: "user-01@alpha.dev.local" },
];

function frame(children: React.ReactNode) {
  return <div style={{ width: "360px" }}>{children}</div>;
}

export const Default: Story = {
  render: () => frame(<LoginCredentialsForm onSubmit={() => {}} />),
};

export const WithSeedUsers: Story = {
  render: () =>
    frame(<LoginCredentialsForm onSubmit={() => {}} seedUsers={SEED_USERS} seedPassword="dbp-dev-password" />),
};

export const Loading: Story = {
  name: "Loading — submit in flight",
  render: () => frame(<LoginCredentialsForm onSubmit={() => {}} loading />),
};

export const Error: Story = {
  name: "Error — invalid credentials",
  render: () =>
    frame(
      <LoginCredentialsForm
        onSubmit={() => {}}
        error="Login failed. Please check your credentials."
        seedUsers={SEED_USERS}
        seedPassword="dbp-dev-password"
      />,
    ),
};
