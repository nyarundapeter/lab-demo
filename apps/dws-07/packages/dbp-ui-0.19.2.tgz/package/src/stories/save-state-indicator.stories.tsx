import type { Meta, StoryObj } from "@storybook/react";
import { SaveStateIndicator, SAVE_STATE } from "../components/save-state-indicator.js";

const meta: Meta<typeof SaveStateIndicator> = {
  title: "Layer 07 — App Scaffolds/Molecules/Overlays/SaveStateIndicator",
  component: SaveStateIndicator,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof SaveStateIndicator>;

export const AllStates: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {SAVE_STATE.map((state) => (
        <div key={state} style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ width: 90, fontSize: 12, fontFamily: "monospace" }}>{state}</span>
          <SaveStateIndicator state={state} />
        </div>
      ))}
    </div>
  ),
};

export const Dirty: Story = { args: { state: "dirty" } };
export const Saving: Story = { args: { state: "saving" } };
export const Saved: Story = { args: { state: "saved" } };
export const Failed: Story = { args: { state: "failed" } };
