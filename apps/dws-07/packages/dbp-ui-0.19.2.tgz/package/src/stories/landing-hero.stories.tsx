import type { Meta, StoryObj } from "@storybook/react"
import { ShieldCheck, Zap, Users, Globe } from "lucide-react"
import { LandingHero } from "../components/landing-hero.js"

const meta: Meta<typeof LandingHero> = {
  title: "Layer 07 — App Scaffolds/Molecules/Public/LandingHero",
  component: LandingHero,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj<typeof LandingHero>

export const Default: Story = {
  args: {
    overline: "Digital Workspace for Every Employee",
    headline: "Everything you need.",
    headlineAccent: "One workspace.",
    body: "A unified platform for governed daily work — tasks, knowledge, services, and performance visibility in one place.",
    primaryCta: { label: "Get Started", href: "#" },
    secondaryCta: { label: "Take a Tour", href: "#" },
    trustBullets: [
      { icon: <ShieldCheck size={16} strokeWidth={1.5} />, label: "SOC 2 Compliant" },
      { icon: <Zap size={16} strokeWidth={1.5} />, label: "Live in days" },
      { icon: <Users size={16} strokeWidth={1.5} />, label: "Multi-tenant" },
      { icon: <Globe size={16} strokeWidth={1.5} />, label: "Global reach" },
    ],
  },
}

export const NoBullets: Story = {
  args: {
    overline: "AnalyticsOps Platform",
    headline: "Turn data into decisions.",
    headlineAccent: "At speed.",
    body: "Governed analytics operations for modern enterprise teams.",
    primaryCta: { label: "Request access", href: "#" },
    secondaryCta: { label: "Watch demo", href: "#" },
  },
}

export const WithPreview: Story = {
  args: {
    ...Default.args,
    preview: (
      <div
        className="flex aspect-video w-full items-center justify-center rounded-[20px] border border-[var(--color-border-subtle)] bg-[var(--color-navy-50)] text-sm font-medium text-[var(--color-text-muted)]"
      >
        Custom preview slot
      </div>
    ),
  },
}
