import type { Meta, StoryObj } from "@storybook/react";
import {
  DetailLinkedRecordsList,
  DetailStatusText,
  DetailChip,
  standardLinkedRecordColumns,
} from "../components/detail-linked-records-list.js";

const meta: Meta<typeof DetailLinkedRecordsList> = {
  title: "Design System/Primitives/DetailLinkedRecordsList",
  component: DetailLinkedRecordsList,
  tags: ["autodocs"],
  argTypes: {
    variant: { control: "select", options: ["list", "table"] },
    isLoading: { control: "boolean" },
    hideCount: { control: "boolean" },
    previewCount: { control: "number" },
  },
};

export default meta;
type Story = StoryObj<typeof DetailLinkedRecordsList>;

const records = [
  { id: "1", primary: "Encryption at rest control", secondary: "CTL-0142", badge: { label: "effective", tone: "success" as const } },
  { id: "2", primary: "Access review control", secondary: "CTL-0198", badge: { label: "partially-effective", tone: "warning" as const } },
  { id: "3", primary: "Data classification control", secondary: "CTL-0203", badge: { label: "not-effective", tone: "danger" as const } },
  { id: "4", primary: "Vendor risk control", secondary: "CTL-0210", badge: { label: "effective", tone: "success" as const } },
  { id: "5", primary: "Change management control", secondary: "CTL-0221", badge: { label: "effective", tone: "success" as const } },
];

export const ListVariant: Story = {
  args: { records, variant: "list" },
};

export const TableVariant: Story = {
  args: { records, variant: "table", columns: standardLinkedRecordColumns() },
};

export const Empty: Story = {
  args: { records: [], emptyTitle: "No linked controls", emptyDescription: "Link a control to get started." },
};

export const Loading: Story = {
  args: { records: [], isLoading: true },
};

export const StatusTextAndChip: Story = {
  name: "DetailStatusText / DetailChip",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <DetailStatusText tone="success">Effective</DetailStatusText>
      <DetailStatusText tone="warning">Partially effective</DetailStatusText>
      <DetailStatusText tone="danger">Not effective</DetailStatusText>
      <DetailChip tone="gray">Privacy</DetailChip>
    </div>
  ),
};
