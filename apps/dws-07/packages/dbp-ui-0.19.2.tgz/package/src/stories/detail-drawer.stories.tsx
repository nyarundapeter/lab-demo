import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { DetailDrawer } from "../components/detail-drawer.js";
import {
  DetailLinkedRecordsList,
  standardLinkedRecordColumns,
} from "../components/detail-linked-records-list.js";
import { DetailFilterRow } from "../components/detail-filter-row.js";
import { Button } from "../components/button.js";

const meta: Meta<typeof DetailDrawer> = {
  title: "Design System/Primitives/DetailDrawer",
  component: DetailDrawer,
  tags: ["autodocs"],
  argTypes: {
    title: { control: "text" },
    subtitle: { control: "text" },
    expanded: { control: "boolean" },
    open: { control: "boolean" },
  },
  args: {
    open: true,
    expanded: false,
    title: "REQ-2026-041",
    subtitle: "Data residency requirement",
    activeTab: "overview",
  },
};

export default meta;
type Story = StoryObj<typeof DetailDrawer>;

const linkedRecords = [
  { id: "1", primary: "Encryption at rest control", secondary: "CTL-0142", badge: { label: "effective", tone: "success" as const } },
  { id: "2", primary: "Access review control", secondary: "CTL-0198", badge: { label: "partially-effective", tone: "warning" as const } },
  { id: "3", primary: "Data classification control", secondary: "CTL-0203", badge: { label: "not-effective", tone: "danger" as const } },
];

export const Default: Story = {
  render: (args) => {
    const [open, setOpen] = React.useState(args.open);
    const [expanded, setExpanded] = React.useState(args.expanded);
    const [activeTab, setActiveTab] = React.useState(args.activeTab);
    return (
      <DetailDrawer
        {...args}
        open={open}
        onClose={() => setOpen(false)}
        expanded={expanded}
        onExpandedChange={setExpanded}
        activeTab={activeTab}
        onActiveTabChange={setActiveTab}
        pills={[{ label: "Active", tone: "success" }]}
        tabs={[
          { key: "overview", label: "Overview", content: <p style={{ fontSize: 13, color: "var(--color-text-muted)" }}>Overview content goes here.</p> },
          { key: "controls", label: "Controls", content: <DetailLinkedRecordsList records={linkedRecords} variant="table" columns={standardLinkedRecordColumns()} /> },
          { key: "activity", label: "Activity", content: <p style={{ fontSize: 13, color: "var(--color-text-muted)" }}>Activity feed goes here — compose with @dbp/ui's ActivityTimeline.</p> },
        ]}
        footerActions={<Button variant="orange" size="sm">Save</Button>}
      />
    );
  },
};

export const ComposedFullDrawer: Story = {
  name: "Composed — full drawer with filter row",
  render: () => {
    const [open, setOpen] = React.useState(true);
    const [expanded, setExpanded] = React.useState(false);
    const [activeTab, setActiveTab] = React.useState("controls");
    const [mapping, setMapping] = React.useState<"all" | "mapped" | "unmapped">("all");

    return (
      <DetailDrawer
        open={open}
        onClose={() => setOpen(false)}
        expanded={expanded}
        onExpandedChange={setExpanded}
        title="Data residency requirement"
        subtitle="REQ-2026-041 · Regulatory Register"
        pills={[{ label: "In review", tone: "warning" }]}
        activeTab={activeTab}
        onActiveTabChange={setActiveTab}
        copyUrl="https://example.com/registers/regulatory/REQ-2026-041"
        tabs={[
          {
            key: "controls",
            label: "Linked controls",
            content: (
              <div className="detail-drawer-stack">
                <DetailFilterRow
                  mapping={{
                    options: [
                      { value: "all", label: "All" },
                      { value: "mapped", label: "Mapped" },
                      { value: "unmapped", label: "Unmapped" },
                    ],
                    active: mapping,
                    onChange: setMapping,
                  }}
                  countLabel={`${linkedRecords.length} of ${linkedRecords.length}`}
                />
                <DetailLinkedRecordsList
                  records={linkedRecords}
                  variant="table"
                  columns={standardLinkedRecordColumns()}
                />
              </div>
            ),
          },
          {
            key: "overview",
            label: "Overview",
            content: <p style={{ fontSize: 13, color: "var(--color-text-muted)" }}>Requirement overview.</p>,
          },
        ]}
        footerActions={
          <>
            <Button variant="outline" size="sm">Cancel</Button>
            <Button variant="orange" size="sm">Approve</Button>
          </>
        }
      />
    );
  },
};
