import type { Meta, StoryObj } from "@storybook/react";
import { CompactTracker } from "../components/compact-tracker.js";
import type { StageRow } from "../components/vertical-stage-tracker.js";

const STAGES: StageRow[] = [
  { id: "intake", label: "Intake", status: "done" },
  { id: "review", label: "Review", status: "done" },
  { id: "approval", label: "Approval", status: "active" },
  { id: "provisioning", label: "Provisioning", status: "upcoming" },
  { id: "closeout", label: "Closeout", status: "upcoming" },
];

const meta: Meta<typeof CompactTracker> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/CompactTracker",
  component: CompactTracker,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof CompactTracker>;

/** Single-row workbench tracker — a pill per stage, done stages checked, the active stage pulsing. */
export const Default: Story = {
  args: {
    stages: STAGES,
  },
};

/** A blocked stage mid-flow. */
export const Blocked: Story = {
  args: {
    stages: [
      { id: "intake", label: "Intake", status: "done" },
      { id: "review", label: "Review", status: "blocked" },
      { id: "approval", label: "Approval", status: "upcoming" },
    ],
  },
};
