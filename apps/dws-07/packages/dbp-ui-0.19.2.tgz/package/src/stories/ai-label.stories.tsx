import type { Meta, StoryObj } from "@storybook/react";
import { AiLabel, AI_LABEL, type AiLabelKind } from "../components/ai-label.js";

const meta: Meta<typeof AiLabel> = {
  title: "Layer 07 — App Scaffolds/Atoms/Indicators/AiLabel",
  component: AiLabel,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AiLabel>;

export const AllKinds: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
      {(Object.keys(AI_LABEL) as AiLabelKind[]).map((kind) => (
        <AiLabel key={kind} kind={kind} />
      ))}
    </div>
  ),
};

export const HumanProvenance: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "8px" }}>
      <AiLabel kind="confirmed" />
      <AiLabel kind="reviewed" />
    </div>
  ),
};

export const CustomText: Story = {
  render: () => <AiLabel kind="summary" text="AI-generated case summary" />,
};
