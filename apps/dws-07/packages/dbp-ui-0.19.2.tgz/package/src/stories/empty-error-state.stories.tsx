import type { Meta, StoryObj } from "@storybook/react";
import { FolderOpen } from "lucide-react";
import { EmptyState } from "../components/empty-state.js";
import { ErrorState } from "../components/error-state.js";
import { Button } from "../components/button.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Feedback & State/EmptyAndErrorState",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Empty: Story = {
  render: () => (
    <div style={{ border: "1px solid var(--color-border-default)", borderRadius: "var(--radius-card)" }}>
      <EmptyState
        icon={<FolderOpen size={22} strokeWidth={1.5} />}
        title="No records found"
        description="Adjust your filters or create a new record to get started."
        action={<Button variant="navy" size="sm">New record</Button>}
      />
    </div>
  ),
};

export const EmptyMinimal: Story = {
  render: () => (
    <div style={{ border: "1px solid var(--color-border-default)", borderRadius: "var(--radius-card)" }}>
      <EmptyState title="Nothing here yet" />
    </div>
  ),
};

export const ErrorExample: Story = {
  name: "Error",
  render: () => (
    <div style={{ border: "1px solid var(--color-border-default)", borderRadius: "var(--radius-card)" }}>
      <ErrorState
        error="Failed to load: invalid pagination query"
        action={<Button variant="outline" size="sm">Retry</Button>}
      />
    </div>
  ),
};

export const ErrorCustomTitle: Story = {
  render: () => (
    <div style={{ border: "1px solid var(--color-border-default)", borderRadius: "var(--radius-card)" }}>
      <ErrorState title="Connection failed" description="The data service is unreachable." />
    </div>
  ),
};
