import type { Meta, StoryObj } from "@storybook/react";
import { ConditionalTracker } from "../components/conditional-tracker.js";
import type { ConditionalAlternative } from "../components/conditional-tracker.js";
import type { StageRow } from "../components/vertical-stage-tracker.js";

const STAGES: StageRow[] = [
  { id: "intake", label: "Intake", status: "done", completedAt: "2026-07-08T10:00:00.000Z" },
  { id: "vp-review", label: "VP review", status: "active", ownerLabel: "Nadia Rahimi", dueAt: "2026-07-15T17:00:00.000Z" },
  { id: "finance-review", label: "Finance sign-off", status: "upcoming" },
];

const ALTERNATIVES: ConditionalAlternative[] = [
  { id: "auto", label: "Auto-approval", description: "Taken when the amount is below €5,000." },
  { id: "manager", label: "Manager approval", description: "Taken for amounts between €5,000 and €25,000." },
];

const meta: Meta<typeof ConditionalTracker> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/ConditionalTracker",
  component: ConditionalTracker,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ConditionalTracker>;

/** Active path shown first; not-taken alternatives collapse until asked for. */
export const Default: Story = {
  args: {
    stages: STAGES,
    decision: "Amount ≥ €25,000",
    alternatives: ALTERNATIVES,
  },
};
