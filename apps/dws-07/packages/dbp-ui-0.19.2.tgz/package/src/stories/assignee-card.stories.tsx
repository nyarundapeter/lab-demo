import type { Meta, StoryObj } from "@storybook/react";
import { AssigneeCard } from "../components/assignee-card.js";

const meta: Meta<typeof AssigneeCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/AssigneeCard",
  component: AssigneeCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AssigneeCard>;

export const Individual: Story = {
  args: {
    kind: "individual",
    name: "Ahmed Al-Mansoori",
    subtitle: "Finance Approver",
    workload: "6 open items",
    onReassign: () => {},
  },
};

export const Team: Story = {
  args: {
    kind: "team",
    name: "Procurement Ops",
    subtitle: "12 members",
    workload: "34 open items",
    onReassign: () => {},
  },
};

export const Unassigned: Story = {
  args: {
    kind: "unassigned",
    onReassign: () => {},
  },
};

export const Queue: Story = {
  args: {
    kind: "queue",
    name: "Security queue",
    subtitle: "Queue · 6 waiting",
    onReassign: () => {},
  },
};

export const Delegation: Story = {
  args: {
    kind: "delegation",
    name: "Sana Iqbal",
    subtitle: "Delegated by Nadia Ahmadi · until Jul 20",
    onReassign: () => {},
  },
};

export const Multiple: Story = {
  args: {
    kind: "multiple",
    subtitle: "3 co-owners",
    coOwners: [{ name: "Ava Chen" }, { name: "Milo Ferreira" }, { name: "Tom Weiss" }],
    onReassign: () => {},
  },
};
