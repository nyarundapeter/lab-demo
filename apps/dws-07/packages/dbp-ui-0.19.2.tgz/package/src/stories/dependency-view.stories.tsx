import type { Meta, StoryObj } from "@storybook/react";
import type { ComponentProps } from "react";
import { DependencyView } from "../components/dependency-view.js";

const meta: Meta<typeof DependencyView> = {
  title: "Layer 07 — App Scaffolds/Molecules/Config/DependencyView",
  component: DependencyView,
  tags: ["autodocs"],
  parameters: { layout: "padded" },
};
export default meta;
type Story = StoryObj<typeof DependencyView>;

const renderView = (args: ComponentProps<typeof DependencyView>) => (
  <div style={{ maxWidth: 720 }}>
    <DependencyView {...args} />
  </div>
);

export const Default: Story = {
  args: {
    upstream: [
      { label: "Request created", sub: "Trigger event" },
      { label: "Category changed", sub: "Trigger event" },
    ],
    current: { label: "Tier 1 routing", sub: "This rule · v7" },
    downstream: [
      { label: "EMEA Infra Desk", sub: "Assignment target", to: "teams" },
      { label: "Incident escalation", sub: "Workflow · triggered", to: "workflows" },
      { label: "Request assigned", sub: "Notification template", to: "templates" },
    ],
    onNavigate: (to: string) => console.log("Navigate:", to),
  },
  render: renderView,
};

export const NoDownstream: Story = {
  name: "No downstream dependents",
  args: {
    upstream: [{ label: "Request created", sub: "Trigger event" }],
    current: { label: "Draft rule", sub: "This rule · v1" },
    downstream: [],
  },
  render: renderView,
};
