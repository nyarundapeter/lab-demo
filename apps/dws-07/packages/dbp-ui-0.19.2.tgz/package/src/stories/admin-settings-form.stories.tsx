import type { Meta, StoryObj } from "@storybook/react";
import { AdminSettingsForm } from "../components/admin-settings-form.js";
import { Button } from "../components/button.js";
import type { AdminSettingsFormField } from "../components/admin-settings-form.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Forms/AdminSettingsForm",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

// Mirrors ADMIN_FORM_SPECS["admin/auth"].tabs[0] ("General") in scaffold-solution.mjs.
export const GENERAL_FIELDS: AdminSettingsFormField[] = [
  { name: "session-timeout", label: "Session timeout (minutes)", fieldType: "number", defaultValue: "60", required: true },
  {
    name: "max-sessions",
    label: "Max concurrent sessions",
    fieldType: "select",
    defaultValue: "5",
    options: [
      { value: "1", label: "1" },
      { value: "3", label: "3" },
      { value: "5", label: "5" },
      { value: "10", label: "10" },
      { value: "unlimited", label: "Unlimited" },
    ],
  },
  { name: "require-mfa", label: "Require multi-factor authentication", fieldType: "switch", defaultChecked: true },
  { name: "password-complexity", label: "Enforce password complexity", fieldType: "switch", defaultChecked: true },
];

export const Default: Story = {
  render: () => (
    <div style={{ width: "480px", display: "flex", flexDirection: "column", gap: "16px" }}>
      <AdminSettingsForm formId="auth-general" fields={GENERAL_FIELDS} />
      <Button type="submit" form="auth-general">
        Save changes
      </Button>
    </div>
  ),
};

// Fields are contained in a bordered card, matching the admin reference's settings-section
// anatomy (title/description outside, fields inside the card — see admin-specimens.jsx).
export const WithTitle: Story = {
  render: () => (
    <div style={{ width: "480px", display: "flex", flexDirection: "column", gap: "16px" }}>
      <AdminSettingsForm
        formId="auth-general-titled"
        fields={GENERAL_FIELDS}
        title="Session policy"
        description="Controls how long sessions stay active and what re-authentication is required."
      />
      <Button type="submit" form="auth-general-titled">
        Save changes
      </Button>
    </div>
  ),
};

const SECTIONS = [
  { title: "Regional & language", fields: [GENERAL_FIELDS[0]!, GENERAL_FIELDS[1]!] },
  { title: "Security", fields: [GENERAL_FIELDS[2]!, GENERAL_FIELDS[3]!] },
];

// Multiple sections each render as their own titled card, stacked with the standard form gap.
export const WithSections: Story = {
  render: () => (
    <div style={{ width: "480px", display: "flex", flexDirection: "column", gap: "16px" }}>
      <AdminSettingsForm formId="auth-sections" sections={SECTIONS} />
      <Button type="submit" form="auth-sections">
        Save changes
      </Button>
    </div>
  ),
};

// A required text field left empty demonstrates the inline validation-error state on submit.
const VALIDATION_FIELDS: AdminSettingsFormField[] = [
  { name: "org-name", label: "Organisation name", fieldType: "text", required: true },
  { name: "billing-email", label: "Billing email", fieldType: "email", required: true },
];

export const ValidationError: Story = {
  render: () => (
    <div style={{ width: "480px", display: "flex", flexDirection: "column", gap: "16px" }}>
      <p style={{ fontSize: "13px" }}>Click Save with the fields empty to see inline validation errors.</p>
      <AdminSettingsForm formId="org-validation" fields={VALIDATION_FIELDS} />
      <Button type="submit" form="org-validation">
        Save changes
      </Button>
    </div>
  ),
};
