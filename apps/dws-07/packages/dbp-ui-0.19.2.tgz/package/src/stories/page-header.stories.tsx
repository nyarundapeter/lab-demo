import * as React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { PageHeader } from '../components/page-header.js'
import { FilterBar } from '../components/filter-bar.js'
import { CollectionToolbar } from '../components/collection-toolbar.js'

const meta: Meta<typeof PageHeader> = {
  title: 'Layer 07 — App Scaffolds/Molecules/Chrome/PageHeader',
  component: PageHeader,
  parameters: { layout: 'padded' },
}
export default meta
type Story = StoryObj<typeof PageHeader>

/**
 * Amendment D-2 (component-architecture-standard.md §7b) — thinned. No
 * visible title, no visible breadcrumb by default: the shell's top bar
 * already carries page identity. `title` stays required and renders as a
 * real (`sr-only`) `<h1>` for accessibility, but the only visible content is
 * `aside`. Compare against `Layer 07 — App Scaffolds/Templates/AppChrome`
 * for where the breadcrumb trail actually shows up.
 */
export const Default: Story = { args: { title: 'My Dashboard' } }

export const WithAction: Story = {
  args: { title: 'Tasks', action: { label: 'Create Task', onClick: () => {} } },
}

/**
 * The standard content-pattern (§7b): search/filter zone + trailing action
 * buttons, in one row. Compose `FilterBar` or `CollectionToolbar` — don't
 * hand-roll a bespoke toolbar per page.
 */
export const WithFilterBar: Story = {
  args: {
    title: 'Cases',
    aside: (
      <FilterBar
        searchPlaceholder="Search cases…"
        chips={[{ key: 'all', label: 'All' }, { key: 'open', label: 'Open', count: 12 }]}
        activeChip="all"
        resultSummary="128 cases"
        actions={
          <button type="button" className="rounded-[var(--radius)] bg-[var(--color-primary)] px-3 py-1.5 text-sm font-medium text-white">
            New Case
          </button>
        }
      />
    ),
  },
}

export const WithCollectionToolbar: Story = {
  args: {
    title: 'Service Requests',
    aside: (
      <CollectionToolbar
        statusOptions={[{ value: 'all', label: 'All' }, { value: 'pending', label: 'Pending' }]}
        statusValue="all"
        onStatusChange={() => {}}
        searchPlaceholder="Search requests…"
        resultCount="42 results"
        actions={
          <button type="button" className="rounded-[var(--radius)] bg-[var(--color-primary)] px-3 py-1.5 text-sm font-medium text-white">
            New Request
          </button>
        }
      />
    ),
  },
}

/**
 * Legacy no-chrome layout path only (`buildModuleNav()`'s `!useChrome`
 * branch) — the one caller with no shell breadcrumb to defer to. Everywhere
 * else, leave `showBreadcrumb` off (the default).
 */
export const LegacyNoChromeBreadcrumb: Story = {
  args: {
    title: 'Invoices',
    showBreadcrumb: true,
    breadcrumb: [{ label: 'DXP.01A', href: '/' }, { label: 'Invoices' }],
  },
}

/**
 * `subtitle` and `titleSpan` are accepted (existing call sites still
 * type-check during migration) but no longer render/affect layout — this
 * story looks identical to `Default` on purpose, proving they're inert.
 */
export const DeprecatedPropsAreIgnored: Story = {
  name: 'Deprecated props are ignored (subtitle, titleSpan)',
  args: { title: 'My Dashboard', subtitle: 'This text never renders', titleSpan: 2 },
}
