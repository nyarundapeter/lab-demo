import type { Meta, StoryObj } from "@storybook/react";
import { Checkbox } from "../components/checkbox.js";
import { Switch } from "../components/switch.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Form Controls/CheckboxAndSwitch",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Checkboxes: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Checkbox aria-label="Unchecked" /> Unchecked
      </label>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Checkbox aria-label="Checked" defaultChecked /> Checked
      </label>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Checkbox aria-label="Disabled" disabled /> Disabled
      </label>
    </div>
  ),
};

export const Switches: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Switch aria-label="Off" /> Off
      </label>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Switch aria-label="On" defaultChecked /> On
      </label>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Switch aria-label="Disabled" disabled /> Disabled
      </label>
    </div>
  ),
};

/* FieldState parity (2026-07-17 audit item 3) — Checkbox/Switch now share
 * Input/Select/Textarea's `state` prop. */
export const ValidationStates: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
          <Checkbox aria-label="Error, unchecked" state="error" /> Error (unchecked)
        </label>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
          <Checkbox aria-label="Error, checked" state="error" defaultChecked /> Error (checked)
        </label>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
          <Checkbox aria-label="Warning" state="warning" /> Warning
        </label>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
          <Checkbox aria-label="Success" state="success" defaultChecked /> Success
        </label>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
          <Switch aria-label="Error, off" state="error" /> Error (off)
        </label>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
          <Switch aria-label="Error, on" state="error" defaultChecked /> Error (on)
        </label>
      </div>
    </div>
  ),
};
