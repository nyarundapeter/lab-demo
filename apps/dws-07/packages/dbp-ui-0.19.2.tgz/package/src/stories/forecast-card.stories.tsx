import type { ReactNode } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ForecastCard, type ForecastCardData } from "../components/forecast-card.js";

const meta: Meta<typeof ForecastCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/ForecastCard",
  component: ForecastCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ForecastCard>;

/** Oracle insight-rail width is 340px outer — pad must sit outside the card. */
function RailFrame({ children }: { children: ReactNode }) {
  return (
    <div style={{ padding: 8, background: "var(--color-surface, #F6F6FB)" }}>
      <div style={{ width: 340 }}>{children}</div>
    </div>
  );
}

/** Oracle ai-example-dashboard ForecastCard fixture (SLA breach risk). */
const DATA: ForecastCardData = {
  label: "SLA breach risk — open high-priority cases",
  value: "5 cases likely to breach",
  period: "Next 48 hours",
  updated: "6m ago",
  confidence: "medium",
  confidenceNote:
    "Forecast uncertainty widens beyond 30 hours; staffing change is a manual assumption.",
  range: "3–7 cases (80% interval)",
  target: "Target: ≤ 2 breaches / week",
  drivers: [
    "Queue depth +34% vs. last week",
    "One fewer agent on EU shift",
    "Gateway incident CS-4821 blocking 2 cases",
  ],
  basis: "12 weeks of resolution-time history, weighted by current queue depth and staffing.",
};

export const Default: Story = {
  args: { data: DATA },
  render: (args) => (
    <RailFrame>
      <ForecastCard {...args} />
    </RailFrame>
  ),
};

export const HighConfidence: Story = {
  args: {
    data: {
      ...DATA,
      confidence: "high",
      confidenceNote: "Tight band from 12 weeks of stable resolution-time history.",
      value: "2 cases likely to breach",
      range: "1–3 cases (80% interval)",
    },
  },
  render: (args) => (
    <RailFrame>
      <ForecastCard {...args} />
    </RailFrame>
  ),
};
