import type { Meta, StoryObj } from "@storybook/react";
import { AiThinking, AiSteps } from "../components/ai-steps.js";

const meta: Meta<typeof AiSteps> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AiSteps",
  component: AiSteps,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AiSteps>;

export const Thinking: Story = {
  render: () => <AiThinking />,
};

export const Steps: Story = {
  render: () => (
    <AiSteps
      steps={[
        { label: "Reading case history", state: "done" },
        { label: "Querying related records", state: "active" },
        { label: "Composing response", state: "pending" },
      ]}
    />
  ),
};
