import type { Meta, StoryObj } from "@storybook/react";
import { Input } from "../components/input.js";
import { FormField } from "../components/form-field.js";

const meta: Meta<typeof Input> = {
  title: "Layer 07 — App Scaffolds/Atoms/Form Controls/Input",
  component: Input,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Input>;

export const Default: Story = {
  render: () => (
    <div style={{ width: "280px" }}>
      <Input placeholder="Type here…" />
    </div>
  ),
};

export const Disabled: Story = {
  render: () => (
    <div style={{ width: "280px" }}>
      <Input placeholder="Disabled" disabled />
    </div>
  ),
};

/* FieldState variants (FG2, 2026-07-17) — `state="error" | "warning" | "success"`. */
export const ValidationStates: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px", width: "280px" }}>
      <Input placeholder="Default" state="default" />
      <Input placeholder="Error" state="error" defaultValue="invalid@" />
      <Input placeholder="Warning" state="warning" defaultValue="near limit" />
      <Input placeholder="Success" state="success" defaultValue="valid@example.com" />
    </div>
  ),
};

export const InFormFieldWithMessages: Story = {
  name: "In FormField — error/warning/success",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px", width: "320px" }}>
      <FormField label="Email" required error="Enter a valid email address.">
        <Input type="email" defaultValue="not-an-email" />
      </FormField>
      <FormField label="Username" state="warning" message="This name is close to another member's.">
        <Input defaultValue="jdoe2" />
      </FormField>
      <FormField label="Coupon code" state="success" message="Code applied.">
        <Input defaultValue="SAVE20" />
      </FormField>
    </div>
  ),
};
