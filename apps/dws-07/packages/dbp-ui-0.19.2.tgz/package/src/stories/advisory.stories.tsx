import type { Meta, StoryObj } from "@storybook/react";
import { Advisory } from "../components/advisory.js";

const meta: Meta<typeof Advisory> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/Advisory",
  component: Advisory,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Advisory>;

export const Default: Story = {
  render: () => <Advisory />,
};

export const CustomText: Story = {
  render: () => <Advisory>Advisory only — a manager must approve before this ships</Advisory>,
};
