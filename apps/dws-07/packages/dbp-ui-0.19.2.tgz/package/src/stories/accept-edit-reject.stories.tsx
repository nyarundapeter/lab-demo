import type { Meta, StoryObj } from "@storybook/react";
import { AcceptEditReject } from "../components/accept-edit-reject.js";

const meta: Meta<typeof AcceptEditReject> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AcceptEditReject",
  component: AcceptEditReject,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AcceptEditReject>;

export const Default: Story = {
  render: () => (
    <AcceptEditReject
      onAccept={() => alert("accepted")}
      onEdit={() => alert("edit")}
      onReject={(reason) => alert(`rejected: ${reason ?? "no reason"}`)}
    />
  ),
};

export const AcceptOnly: Story = {
  render: () => <AcceptEditReject acceptLabel="Apply suggestion" onAccept={() => alert("applied")} />,
};

export const SoftAccept: Story = {
  render: () => (
    <AcceptEditReject
      primary={false}
      onAccept={() => alert("accepted")}
      onReject={() => alert("rejected")}
    />
  ),
};
