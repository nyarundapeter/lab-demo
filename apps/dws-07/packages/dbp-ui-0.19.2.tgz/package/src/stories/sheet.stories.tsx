import type { Meta, StoryObj } from "@storybook/react";
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
} from "../components/sheet.js";
import { Button } from "../components/button.js";
import { X } from "lucide-react";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Overlays/Sheet",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

export const RightSlideIn: Story = {
  name: "Right (default)",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open right sheet</Button>
      </SheetTrigger>
      <SheetContent side="right">
        <SheetHeader>
          <SheetTitle>Panel Title</SheetTitle>
          <SheetDescription>
            This panel slides in from the right. Use it for detail views, forms, or
            supplementary content.
          </SheetDescription>
        </SheetHeader>
        <div style={{ padding: "8px 0" }}>
          <p style={{ fontSize: "14px", color: "var(--color-text-muted)" }}>
            Panel body content goes here.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  ),
};

export const LeftSlideIn: Story = {
  name: "Left",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open left sheet</Button>
      </SheetTrigger>
      <SheetContent side="left">
        <SheetHeader>
          <SheetTitle>Navigation</SheetTitle>
          <SheetDescription>Side navigation panel.</SheetDescription>
        </SheetHeader>
        <nav style={{ marginTop: "8px" }}>
          <ul style={{ display: "flex", flexDirection: "column", gap: "4px", listStyle: "none", padding: 0 }}>
            {["Dashboard", "Projects", "Team", "Settings"].map((item) => (
              <li key={item}>
                <a
                  href="#"
                  style={{
                    display: "block",
                    padding: "8px 12px",
                    borderRadius: "6px",
                    fontSize: "14px",
                    textDecoration: "none",
                    color: "var(--color-text)",
                  }}
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </SheetContent>
    </Sheet>
  ),
};

export const TopSlideIn: Story = {
  name: "Top",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open top sheet</Button>
      </SheetTrigger>
      <SheetContent side="top">
        <SheetHeader>
          <SheetTitle>Notification Banner</SheetTitle>
          <SheetDescription>This sheet slides down from the top of the screen.</SheetDescription>
        </SheetHeader>
      </SheetContent>
    </Sheet>
  ),
};

export const BottomSlideIn: Story = {
  name: "Bottom",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open bottom sheet</Button>
      </SheetTrigger>
      <SheetContent side="bottom">
        <SheetHeader>
          <SheetTitle>Mobile Action Sheet</SheetTitle>
          <SheetDescription>Common actions for the selected item.</SheetDescription>
        </SheetHeader>
        <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
          <Button size="sm">Edit</Button>
          <Button size="sm" variant="outline">Duplicate</Button>
          <Button size="sm" variant="destructive">Delete</Button>
        </div>
      </SheetContent>
    </Sheet>
  ),
};

const DETENTS: { detent: "compact" | "half" | "full"; height: string }[] = [
  { detent: "compact", height: "32vh" },
  { detent: "half", height: "55vh" },
  { detent: "full", height: "92vh" },
];

export const BottomDetents: Story = {
  name: "Bottom — detents",
  render: () => (
    <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
      {DETENTS.map(({ detent, height }) => (
        <Sheet key={detent}>
          <SheetTrigger asChild>
            <Button variant="outline">
              {detent} ({height})
            </Button>
          </SheetTrigger>
          <SheetContent side="bottom" detent={detent}>
            <SheetHeader>
              <SheetTitle>detent=&quot;{detent}&quot;</SheetTitle>
              <SheetDescription>height: {height} of viewport</SheetDescription>
            </SheetHeader>
            <p style={{ fontSize: "14px", color: "var(--color-text-muted)", marginTop: "8px" }}>
              Compact for a glance, half for browsing, full when the content needs the height.
            </p>
          </SheetContent>
        </Sheet>
      ))}
    </div>
  ),
};

const DRAWER_SIZES: { size: "narrow" | "standard" | "wide" | "xwide"; px: string }[] = [
  { size: "narrow", px: "360px" },
  { size: "standard", px: "460px" },
  { size: "wide", px: "640px" },
  { size: "xwide", px: "860px" },
];

export const AllSizes: Story = {
  name: "All widths",
  render: () => (
    <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
      {DRAWER_SIZES.map(({ size, px }) => (
        <Sheet key={size}>
          <SheetTrigger asChild>
            <Button variant="outline">
              {size} ({px})
            </Button>
          </SheetTrigger>
          <SheetContent side="right" size={size}>
            <SheetHeader>
              <SheetTitle>size=&quot;{size}&quot;</SheetTitle>
              <SheetDescription>width: {px}</SheetDescription>
            </SheetHeader>
            <div
              style={{
                height: "1rem",
                width: "100%",
                marginTop: "8px",
                background:
                  "repeating-linear-gradient(90deg, var(--color-navy-200) 0 1px, transparent 1px 40px)",
              }}
              aria-hidden="true"
            />
            <p style={{ fontSize: "14px", color: "var(--color-text-muted)", marginTop: "8px" }}>
              Ruler ticks every 40px — panel width matches the drawer&apos;s fixed width.
            </p>
          </SheetContent>
        </Sheet>
      ))}
    </div>
  ),
};

export const WithFormContent: Story = {
  name: "With form content",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button>Edit profile</Button>
      </SheetTrigger>
      <SheetContent side="right">
        <SheetHeader>
          <SheetTitle>Edit Profile</SheetTitle>
          <SheetDescription>
            Update your profile information. Changes are saved automatically.
          </SheetDescription>
        </SheetHeader>
        <div style={{ display: "flex", flexDirection: "column", gap: "16px", marginTop: "16px" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <label style={{ fontSize: "13px", fontWeight: 500 }}>Name</label>
            <input
              type="text"
              defaultValue="Alex Johnson"
              style={{
                border: "1px solid var(--color-border)",
                borderRadius: "6px",
                padding: "8px 12px",
                fontSize: "14px",
              }}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <label style={{ fontSize: "13px", fontWeight: 500 }}>Email</label>
            <input
              type="email"
              defaultValue="alex@example.com"
              style={{
                border: "1px solid var(--color-border)",
                borderRadius: "6px",
                padding: "8px 12px",
                fontSize: "14px",
              }}
            />
          </div>
          <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
            <Button size="sm">Save changes</Button>
            <SheetClose asChild>
              <Button size="sm" variant="outline">Cancel</Button>
            </SheetClose>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  ),
};

export const HideDefaultClose: Story = {
  name: "hideClose (custom header close button)",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open sheet with custom close</Button>
      </SheetTrigger>
      <SheetContent side="right" hideClose>
        <SheetHeader style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <SheetTitle>Custom Header</SheetTitle>
            <SheetDescription>
              This sheet supplies its own close button, so the default top-right X is hidden via
              `hideClose` to avoid two stacked close controls.
            </SheetDescription>
          </div>
          <SheetClose asChild>
            <Button size="sm" variant="outline" aria-label="Close">
              <X style={{ width: 16, height: 16 }} />
            </Button>
          </SheetClose>
        </SheetHeader>
      </SheetContent>
    </Sheet>
  ),
};

export const MobileSwipeToDismiss: Story = {
  name: "Bottom — swipe to dismiss (OVL-11)",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open swipeable sheet</Button>
      </SheetTrigger>
      <SheetContent side="bottom" detent="half" swipeToDismiss>
        <SheetHeader>
          <SheetTitle>Filters</SheetTitle>
          <SheetDescription>
            Drag the grip handle down to dismiss — low-risk content only.
          </SheetDescription>
        </SheetHeader>
        <p style={{ fontSize: "14px", color: "var(--color-text-muted)", marginTop: "8px" }}>
          Swipe-to-dismiss is disabled on `dismissable=false` sheets (e.g. a form holding
          unsaved input) — see the next story.
        </p>
      </SheetContent>
    </Sheet>
  ),
};

export const MobileNonDismissible: Story = {
  name: "Bottom — non-dismissible (unsaved form)",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open non-dismissible sheet</Button>
      </SheetTrigger>
      <SheetContent side="bottom" detent="full" swipeToDismiss dismissable={false}>
        <SheetHeader>
          <SheetTitle>New request</SheetTitle>
          <SheetDescription>
            Escape, outside-click, and swipe are all disabled — this sheet holds unsaved
            input, so closing must go through the explicit ✕.
          </SheetDescription>
        </SheetHeader>
      </SheetContent>
    </Sheet>
  ),
};

export const Resizable: Story = {
  name: "Right — resizable (OVL-07)",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open resizable drawer</Button>
      </SheetTrigger>
      <SheetContent side="right" size="standard" resizable minWidth={320} maxWidth={860}>
        <SheetHeader>
          <SheetTitle>Resizable drawer</SheetTitle>
          <SheetDescription>
            Drag the handle on the left edge (or focus it and press Left/Right) to
            resize between 320px and 860px.
          </SheetDescription>
        </SheetHeader>
        <div style={{ padding: "8px 0" }}>
          <p style={{ fontSize: "14px", color: "var(--color-text-muted)" }}>
            Panel body content goes here.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  ),
};
