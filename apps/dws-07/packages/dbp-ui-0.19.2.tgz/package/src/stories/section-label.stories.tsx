import type { Meta, StoryObj } from "@storybook/react";
import { SectionLabel } from "../components/section-label.js";

const meta: Meta<typeof SectionLabel> = {
  title: "Layer 07 — App Scaffolds/Atoms/SectionLabel",
  component: SectionLabel,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof SectionLabel>;

export const Default: Story = {
  args: { children: "Section" },
};

export const Muted: Story = {
  args: { tone: "muted", children: "Overview" },
};

export const Primary: Story = {
  args: { tone: "primary", children: "Overview" },
};

export const Secondary: Story = {
  args: { tone: "secondary", children: "Overview" },
};

export const AsHeading: Story = {
  name: "Rendered as h3",
  args: { as: "h3", children: "Section heading" },
};

export const AllTones: Story = {
  name: "All tones",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      <SectionLabel tone="muted">Muted</SectionLabel>
      <SectionLabel tone="primary">Primary</SectionLabel>
      <SectionLabel tone="secondary">Secondary</SectionLabel>
    </div>
  ),
};
