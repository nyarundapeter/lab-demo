import type { Meta, StoryObj } from "@storybook/react";
import { SettingsNav } from "../components/settings-nav.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Layout & Navigation/SettingsNav",
  tags: ["autodocs"],
  parameters: {
    docs: {
      description: {
        component:
          "Sibling-settings navigation rail for admin config pages — extracted from the generator's inline nav emission (GATE.06: pages carry no raw chrome). Static links, no data fetching.",
      },
    },
  },
};
export default meta;
type Story = StoryObj;

const LINKS = [
  { href: "/admin/auth", label: "Authentication" },
  { href: "/admin/notifications", label: "Notifications" },
  { href: "/admin/search", label: "Search" },
  { href: "/admin/audit", label: "Audit" },
];

export const Default: Story = {
  render: () => (
    <div style={{ width: "220px" }}>
      <SettingsNav links={LINKS} />
    </div>
  ),
};

export const LongLabels: Story = {
  name: "Edge — long labels in a narrow rail",
  render: () => (
    <div style={{ width: "180px" }}>
      <SettingsNav
        links={[
          ...LINKS,
          { href: "/admin/data-retention", label: "Data retention and archival policy configuration" },
        ]}
      />
    </div>
  ),
};
