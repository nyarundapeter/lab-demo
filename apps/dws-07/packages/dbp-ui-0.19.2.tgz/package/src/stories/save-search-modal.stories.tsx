import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { SaveSearchModal } from "../components/save-search-modal.js";
import { Button } from "../components/button.js";

const meta: Meta<typeof SaveSearchModal> = {
  title: "Layer 07 — App Scaffolds/Molecules/Search/SaveSearchModal",
  component: SaveSearchModal,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof SaveSearchModal>;

function Controlled() {
  const [open, setOpen] = useState(true);
  return (
    <>
      <Button onClick={() => setOpen(true)}>Save search</Button>
      <SaveSearchModal
        open={open}
        onOpenChange={setOpen}
        defaultName="At-risk renewals"
        queryChips={[
          { label: "renewal" },
          { label: "in:deals" },
          { label: "status:open", kind: "filter" },
        ]}
        onSave={(input) => {
          console.log("saved", input);
          setOpen(false);
        }}
      />
    </>
  );
}

export const Default: Story = {
  render: () => <Controlled />,
};
