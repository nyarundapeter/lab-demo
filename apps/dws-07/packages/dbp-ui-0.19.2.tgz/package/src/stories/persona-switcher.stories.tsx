import type { Meta, StoryObj } from "@storybook/react";
import { useState } from "react";
import { PersonaSwitcher, type Persona } from "../components/persona-switcher.js";

const PERSONAS: Persona[] = [
  { id: "platform", label: "Platform administrator", description: "Full configuration access" },
  { id: "business", label: "Business administrator", description: "Business-hours & branding" },
  { id: "security", label: "Security administrator", description: "Security & retention" },
  { id: "integration", label: "Integration administrator", description: "Connections & credentials" },
  { id: "product", label: "Product owner", description: "Feature flags & defaults" },
];

/**
 * **Open architecture question — not resolved by this story.** What "persona"
 * means is undecided per
 * `docs/03-features/specs/admin-system-ingestion-ledger-2026-07-13.md#d-persona-switcher-vs-real-delegated-administration--ruling-4`
 * (RULING #4): (a) demo-only mock toggle, (b) a display-preference layer over
 * the admin's own real, resolved RBAC roles — the audit's recommendation —
 * or (c) alias the existing `TenantSwitcher`. This story renders the
 * component with mock data purely to demonstrate the UI; it does not imply
 * option (a) has been chosen.
 */
const meta: Meta<typeof PersonaSwitcher> = {
  title: "Layer 07 — App Scaffolds/Molecules/Config/PersonaSwitcher",
  component: PersonaSwitcher,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof PersonaSwitcher>;

export const Default: Story = {
  render: () => {
    const [value, setValue] = useState("platform");
    return <PersonaSwitcher personas={PERSONAS} value={value} onChange={setValue} />;
  },
};
