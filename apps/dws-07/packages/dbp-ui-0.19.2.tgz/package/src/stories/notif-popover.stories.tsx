import type { Meta, StoryObj } from "@storybook/react";
import { NotifPopover, type NotifPopoverItem } from "../components/notif-popover.js";

const meta: Meta<typeof NotifPopover> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/NotifPopover",
  component: NotifPopover,
  tags: ["autodocs"],
  parameters: { layout: "padded" },
};
export default meta;
type Story = StoryObj<typeof NotifPopover>;

const ITEMS: NotifPopoverItem[] = [
  {
    id: "n1",
    title: "SLA at risk — case CS-2093",
    message: "Breaches in ~22 minutes unless reassigned.",
    type: "action",
    severity: "critical",
    unread: true,
    actionRequired: true,
    time: "4 min ago",
    record: "CS-2093",
  },
  {
    id: "n2",
    title: "Priya Nair mentioned you",
    message: "In the Meridian Health renewal thread — can you confirm the target date?",
    type: "reminder",
    unread: true,
    time: "22 min ago",
    record: "Meridian Health",
  },
  {
    id: "n3",
    title: "Deploy completed — payments-svc 3.14.2",
    message: "Rolled out to all EU-West nodes with no elevated error rate.",
    type: "system",
    unread: false,
    time: "1h ago",
    record: "payments-svc",
  },
];

export const Default: Story = {
  args: {
    items: ITEMS,
    unreadCount: 2,
  },
};

export const Empty: Story = {
  args: {
    items: [],
  },
};
