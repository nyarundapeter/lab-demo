import type { Meta, StoryObj } from "@storybook/react";
import { DashboardDensityProvider, useDashboardDensity, type DashboardDensity } from "../components/dashboard-density.js";

function DensityReadout() {
  const density = useDashboardDensity();
  return (
    <div style={{ padding: "16px", border: "1px solid var(--color-border-subtle)", borderRadius: "var(--radius-card)" }}>
      Resolved density: <strong>{density}</strong>
    </div>
  );
}

interface DemoProps {
  density: DashboardDensity;
}

function Demo({ density }: DemoProps) {
  return (
    <DashboardDensityProvider density={density}>
      <DensityReadout />
    </DashboardDensityProvider>
  );
}

const meta: Meta<typeof Demo> = {
  title: "Layer 07 — App Scaffolds/Utilities/DashboardDensity",
  component: Demo,
  tags: ["autodocs"],
  argTypes: {
    density: {
      control: "select",
      options: ["executive", "standard", "operational"],
    },
  },
  args: {
    density: "standard",
  },
};
export default meta;
type Story = StoryObj<typeof Demo>;

export const Standard: Story = {};

export const Executive: Story = {
  args: { density: "executive" },
};

export const Operational: Story = {
  args: { density: "operational" },
};
