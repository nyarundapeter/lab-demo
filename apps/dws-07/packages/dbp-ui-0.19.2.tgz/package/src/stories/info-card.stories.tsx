import type { Meta, StoryObj } from "@storybook/react";
import { InfoCard } from "../components/info-card.js";

const meta: Meta<typeof InfoCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/InfoCard",
  component: InfoCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof InfoCard>;

export const AllTones: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: 420 }}>
      <InfoCard tone="neutral" title="Neutral" />
      <InfoCard tone="success" title="Success" />
      <InfoCard tone="warning" title="Warning" />
      <InfoCard tone="danger" title="Danger" />
      <InfoCard tone="info" title="Info" />
    </div>
  ),
};
