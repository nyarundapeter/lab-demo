import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverClose,
} from "../components/popover.js";
import { Button } from "../components/button.js";
import { Input, FieldLabel } from "../components/input.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Overlays/Popover",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

export const Basic: Story = {
  name: "Basic",
  render: () => (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline">Open popover</Button>
      </PopoverTrigger>
      <PopoverContent>
        <p className="text-sm text-[var(--color-text-primary)]">
          Anchored, dismissible content — click the trigger again, click
          outside, or press Escape to close.
        </p>
      </PopoverContent>
    </Popover>
  ),
};

export const WithForm: Story = {
  name: "With form content",
  render: () => (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline">Edit dimensions</Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <div className="flex flex-col gap-3">
          <div>
            <h4 className="text-sm font-semibold text-[var(--color-text-primary)]">Dimensions</h4>
            <p className="text-xs text-[var(--color-text-muted)]">
              Set the preferred size for this panel.
            </p>
          </div>
          <div className="flex flex-col gap-2">
            <FieldLabel htmlFor="popover-width">Width</FieldLabel>
            <Input id="popover-width" defaultValue="100%" />
            <FieldLabel htmlFor="popover-height">Height</FieldLabel>
            <Input id="popover-height" defaultValue="25px" />
          </div>
          <div className="flex justify-end">
            <PopoverClose asChild>
              <Button size="sm">Done</Button>
            </PopoverClose>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  ),
};

export const Alignment: Story = {
  name: "Alignment",
  render: () => (
    <div className="flex gap-4">
      {(["start", "center", "end"] as const).map((align) => (
        <Popover key={align}>
          <PopoverTrigger asChild>
            <Button variant="outline">{align}</Button>
          </PopoverTrigger>
          <PopoverContent align={align}>
            <p className="text-sm text-[var(--color-text-primary)]">Aligned "{align}" to the trigger.</p>
          </PopoverContent>
        </Popover>
      ))}
    </div>
  ),
};
