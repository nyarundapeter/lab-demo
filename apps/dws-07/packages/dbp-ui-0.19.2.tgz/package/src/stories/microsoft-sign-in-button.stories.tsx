import type { Meta, StoryObj } from "@storybook/react"
import { MicrosoftSignInButton } from "../components/microsoft-sign-in-button.js"

const meta: Meta<typeof MicrosoftSignInButton> = {
  title: "Layer 07 — App Scaffolds/Atoms/Auth/MicrosoftSignInButton",
  component: MicrosoftSignInButton,
  parameters: { layout: "centered" },
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj<typeof MicrosoftSignInButton>

export const Default: Story = {
  args: {
    label: "Sign in with Microsoft",
    authorizeUrl: "#",
  },
}

export const EntraExternal: Story = {
  args: {
    label: "Sign in with your Microsoft account",
    authorizeUrl: "#",
  },
}

export const Loading: Story = {
  args: {
    label: "Sign in with Microsoft",
    loading: true,
    authorizeUrl: "#",
  },
}
