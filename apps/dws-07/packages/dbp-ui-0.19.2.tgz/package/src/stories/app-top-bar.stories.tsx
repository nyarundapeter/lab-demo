import type { Meta, StoryObj } from "@storybook/react";
import type * as React from "react";
import { AppTopBar } from "../components/app-top-bar.js";

const meta: Meta<typeof AppTopBar> = {
  title: "Layer 07 — App Scaffolds/Molecules/Chrome/AppTopBar",
  component: AppTopBar,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AppTopBar>;

/**
 * Shell v3 anatomy (N27 ruling): no app lockup — the bar's left section is
 * breadcrumb-only (rendered by the shell just after the sidebar toggle,
 * which lives outside this component). The identity block that used to sit
 * here now lives in the sidebar header (see SidebarIdentity in the
 * AppSidebar stories).
 */
export const Default: Story = {
  args: {
    config: {
      appName: "DWS.01 / Work.Space4.0",
      logoAlt: "DWS.01",
      showSearch: true,
      showNotifications: true,
      showUser: true,
      actions: [],
    },
    userName: "Ian Brooks",
    userRole: "Operations Lead",
  },
};

/** `productCode`/`productName` are deprecated no-ops kept for source compatibility — the bar no longer renders a lockup regardless of what's passed. */
export const DeprecatedLockupPropsAreIgnored: Story = {
  args: {
    config: {
      appName: "ignored-when-props-set",
      logoAlt: "DIA.02",
      showSearch: true,
      showNotifications: true,
      showUser: true,
      actions: [],
    },
    productCode: "DIA.02",
    productName: "AnalyticsOps",
    userName: "Priya Nair",
    userRole: "Data Analyst",
  },
};

/** With a role/context selector slot rendered before the divider. */
export const WithRoleSelector: Story = {
  args: {
    config: {
      appName: "DWS.05 / Workforce",
      logoAlt: "DWS.05",
      showSearch: true,
      showNotifications: true,
      showUser: true,
      actions: [],
    },
    roleSlot: (
      <button
        type="button"
        className="flex h-10 items-center gap-2 rounded-button border-[1.5px] border-[var(--color-border-default)] bg-white px-3 text-xs font-bold text-primary hover:bg-[var(--color-navy-50)]"
      >
        <span className="hidden font-mono text-[10px] font-bold uppercase tracking-wider text-[var(--color-text-muted)] xl:block">
          Role
        </span>
        Approver
      </button>
    ),
    userName: "Sam Okoro",
    userRole: "Finance Approver",
  },
};

/** Dark variant — for use over a navy header / login chrome. */
export const DarkVariant: Story = {
  parameters: {
    backgrounds: { default: "navy", values: [{ name: "navy", value: "#030F35" }] },
  },
  args: {
    config: {
      appName: "DWS.01 / Work.Space4.0",
      logoAlt: "DWS.01",
      showSearch: false,
      showNotifications: false,
      showUser: false,
      actions: [],
    },
    variant: "dark",
  },
};

/** Breadcrumb-in-topbar (shell v3, N27 ruling): the trail is the entire left section — no lockup precedes it — and its terminal crumb is the page title, not a second row under PageHeader. */
export const WithBreadcrumb: Story = {
  args: {
    config: {
      appName: "DWS.06 / Workflow Factory",
      logoAlt: "DWS.06",
      showSearch: true,
      showNotifications: true,
      showUser: true,
      actions: [],
    },
    breadcrumbSlot: (
      <nav aria-label="Breadcrumb" className="flex min-w-0 items-center gap-1.5 text-[12px] font-medium">
        <span className="text-[var(--color-text-muted)]">Workspace</span>
        <span aria-hidden className="text-[var(--color-text-disabled)]">/</span>
        <span className="text-[var(--color-text-muted)]">Manage Work</span>
        <span aria-hidden className="text-[var(--color-text-disabled)]">/</span>
        <span className="text-[var(--color-text-secondary)]" aria-current="page">Cases</span>
      </nav>
    ),
    userName: "Ian Brooks",
    userRole: "Operations Lead",
  },
};

function atWidth(px: number) {
  return {
    decorators: [
      (Story: () => React.ReactElement) => (
        <div style={{ width: px, border: "1px dashed var(--color-border-default)" }}>
          <Story />
        </div>
      ),
    ],
    parameters: { chromatic: { viewports: [px] } },
  };
}

/** 1280px — desktop: search pill, both switchers with full labels, breadcrumb all visible. */
export const Width1280: Story = { ...WithBreadcrumb, ...atWidth(1280) };

/** 1024px — the width that used to wrap: switchers collapse to icon-only, search collapses to an icon button. Nothing wraps. */
export const Width1024: Story = { ...WithBreadcrumb, ...atWidth(1024) };

/** 768px — tablet: breadcrumb still visible, switchers/search icon-only. */
export const Width768: Story = { ...WithBreadcrumb, ...atWidth(768) };

/** 375px — mobile: lockup only, breadcrumb hidden (page title is the wayfinding cue), controls icon-only. */
export const Width375: Story = { ...WithBreadcrumb, ...atWidth(375) };

/** Minimal: just the lockup, no search / notifications / user. */
export const MinimalBranding: Story = {
  args: {
    config: {
      appName: "Analytics Suite",
      logoAlt: "Analytics",
      showSearch: false,
      showNotifications: false,
      showUser: false,
      actions: [],
    },
  },
};
