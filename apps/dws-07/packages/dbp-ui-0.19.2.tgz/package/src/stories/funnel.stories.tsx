import type { Meta, StoryObj } from "@storybook/react";
import { Funnel } from "../components/funnel.js";

const meta: Meta<typeof Funnel> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/Funnel",
  component: Funnel,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Funnel>;

export const Adoption: Story = {
  args: {
    stages: [
      { label: "Signed up", value: 4200 },
      { label: "Activated account", value: 3100 },
      { label: "Completed onboarding", value: 2050 },
      { label: "Invited a teammate", value: 980 },
      { label: "Became a weekly active user", value: 620 },
    ],
  },
};

export const CustomColors: Story = {
  args: {
    stages: [
      { label: "Viewed listing", value: 12000, color: "var(--color-info)" },
      { label: "Requested access", value: 3400, color: "var(--color-primary)" },
      { label: "Approved", value: 2100, color: "var(--color-success)" },
      { label: "Provisioned", value: 1800, color: "var(--color-warning)" },
    ],
  },
};
