import type { Meta, StoryObj } from "@storybook/react";
import { CtrlBadge } from "../components/ctrl-badge.js";

const meta: Meta<typeof CtrlBadge> = {
  title: "Layer 07 — App Scaffolds/Atoms/Badge/CtrlBadge",
  component: CtrlBadge,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof CtrlBadge>;

export const AllLevels: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
      <CtrlBadge level={1} />
      <CtrlBadge level={2} />
      <CtrlBadge level={3} />
      <CtrlBadge level={4} />
    </div>
  ),
};

export const WithoutNumericPrefix: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
      <CtrlBadge level={2} showNum={false} />
      <CtrlBadge level={4} showNum={false} />
    </div>
  ),
};

export const HumanDecisionOnly: Story = {
  render: () => <CtrlBadge level={4} humanDecisionOnly />,
};
