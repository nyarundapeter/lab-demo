import type { Meta, StoryObj } from '@storybook/react'
import { ErrorCard } from '../components/error-card.js'

const meta: Meta<typeof ErrorCard> = {
  title: 'Layer 07 — App Scaffolds/Molecules/Feedback & State/ErrorCard',
  component: ErrorCard,
  parameters: { layout: 'padded' },
  tags: ['autodocs'],
}
export default meta
type Story = StoryObj<typeof ErrorCard>

export const Default: Story = { args: { message: 'Failed to load data. Please try again.' } }
export const WithRetry: Story = {
  args: { message: 'Network error. Check your connection.', onRetry: () => {} },
}
