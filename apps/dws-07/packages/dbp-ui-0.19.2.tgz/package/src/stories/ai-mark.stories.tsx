import type { Meta, StoryObj } from "@storybook/react";
import { AiMark } from "../components/ai-mark.js";

const meta: Meta<typeof AiMark> = {
  title: "Layer 07 — App Scaffolds/Atoms/Indicators/AiMark",
  component: AiMark,
  tags: ["autodocs"],
  argTypes: {
    size: { control: { type: "number", min: 8, max: 32, step: 1 } },
  },
  args: {
    size: 12,
  },
};
export default meta;
type Story = StoryObj<typeof AiMark>;

export const Default: Story = {};

export const Small: Story = {
  args: { size: 11 },
};

export const Large: Story = {
  args: { size: 24 },
};
