import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { RadioGroup } from "../components/radio-group.js";
import { FormField } from "../components/form-field.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Form Controls/RadioGroup",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

const PLAN_OPTIONS = [
  { value: "starter", label: "Starter" },
  { value: "growth", label: "Growth" },
  { value: "enterprise", label: "Enterprise" },
];

const ROLE_OPTIONS = [
  { value: "viewer", label: "Viewer", description: "Read-only access to shared records." },
  { value: "editor", label: "Editor", description: "Can create and edit records." },
  { value: "admin", label: "Admin", description: "Full access, including user management and billing." },
];

function Controlled({ options, ...props }: React.ComponentProps<typeof RadioGroup>) {
  const [value, setValue] = React.useState<string>(props.value ?? options[0]?.value ?? "");
  return <RadioGroup {...props} options={options} value={value} onValueChange={setValue} />;
}

export const List: Story = {
  render: () => <Controlled name="plan-list" options={PLAN_OPTIONS} style={{ width: "280px" }} />,
};

export const Card: Story = {
  render: () => (
    <Controlled name="role-card" variant="card" options={ROLE_OPTIONS} style={{ width: "360px" }} />
  ),
};

export const CardWithDisabledOption: Story = {
  name: "Card — disabled option",
  render: () => (
    <Controlled
      name="role-card-disabled"
      variant="card"
      options={[
        ...ROLE_OPTIONS,
        {
          value: "owner",
          label: "Owner",
          description: "Only available on the Enterprise plan.",
          disabled: true,
        },
      ]}
      style={{ width: "360px" }}
    />
  ),
};

export const LongOptionLabel: Story = {
  name: "Edge — long option label",
  render: () => (
    <Controlled
      name="long-label"
      variant="card"
      options={[
        {
          value: "a",
          label: "A very long option label that wraps across more than one line in the choice card",
          description: "A correspondingly long description to check the card doesn't break its layout when both label and description wrap.",
        },
        { value: "b", label: "Short option" },
      ]}
      style={{ width: "320px" }}
    />
  ),
};

export const WithFormFieldError: Story = {
  name: "In FormField — error state",
  render: () => (
    <FormField label="Access level" required error="Select an access level." style={{ width: "360px" }}>
      <Controlled name="access-error" variant="card" options={ROLE_OPTIONS} value="" />
    </FormField>
  ),
};

export const Disabled: Story = {
  render: () => (
    <RadioGroup name="disabled-group" options={PLAN_OPTIONS} value="growth" disabled style={{ width: "280px" }} />
  ),
};
