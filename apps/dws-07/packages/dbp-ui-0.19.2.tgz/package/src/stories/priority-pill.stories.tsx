import type { Meta, StoryObj } from "@storybook/react";
import { PriorityPill } from "../components/priority-pill.js";

const meta: Meta<typeof PriorityPill> = {
  title: "Layer 07 — App Scaffolds/Atoms/Badge/PriorityPill",
  component: PriorityPill,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof PriorityPill>;

export const Low: Story = { args: { priority: "low" } };
export const Normal: Story = { args: { priority: "normal" } };
export const High: Story = { args: { priority: "high" } };
export const Urgent: Story = { args: { priority: "urgent" } };

export const AllPriorities: Story = {
  name: "All priorities (4-level taxonomy)",
  render: () => (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
      <PriorityPill priority="low" />
      <PriorityPill priority="normal" />
      <PriorityPill priority="high" />
      <PriorityPill priority="urgent" />
    </div>
  ),
};
