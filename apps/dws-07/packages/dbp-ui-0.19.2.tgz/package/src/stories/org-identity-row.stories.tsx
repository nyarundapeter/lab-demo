import type { Meta, StoryObj } from "@storybook/react";
import { OrgIdentityRow } from "../components/org-identity-row.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Identity/OrgIdentityRow",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => <OrgIdentityRow name="Northwind" domain="northwind.example" style={{ width: "280px" }} />,
};

export const NoDomain: Story = {
  name: "No domain",
  render: () => <OrgIdentityRow name="Meridian Foods" style={{ width: "280px" }} />,
};

export const LongName: Story = {
  name: "Long name (truncates)",
  render: () => (
    <OrgIdentityRow name="Meridian Regional Operations Cooperative" domain="meridian-regional-ops.example" style={{ width: "280px" }} />
  ),
};
