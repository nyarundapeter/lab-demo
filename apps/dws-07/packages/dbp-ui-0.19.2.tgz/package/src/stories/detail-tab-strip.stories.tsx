import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { DetailTabStrip } from "../components/detail-tab-strip.js";

const meta: Meta<typeof DetailTabStrip> = {
  title: "Design System/Primitives/DetailTabStrip",
  component: DetailTabStrip,
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj<typeof DetailTabStrip>;

const tabs = [
  { key: "overview", label: "Overview", content: null },
  { key: "controls", label: "Linked controls", content: null },
  { key: "activity", label: "Activity", content: null },
];

export const Default: Story = {
  render: () => {
    const [active, setActive] = React.useState("overview");
    return (
      <div style={{ width: "480px" }}>
        <DetailTabStrip tabs={tabs} activeTab={active} onActiveTabChange={setActive} />
      </div>
    );
  },
};

export const Overflowing: Story = {
  name: "Overflow with more menu",
  render: () => {
    const manyTabs = [
      "Overview", "Controls", "Policies", "Obligations", "Evidence",
      "Assessments", "Risks", "Activity", "Attachments", "History",
    ].map((label) => ({ key: label.toLowerCase(), label, content: null }));
    const [active, setActive] = React.useState(manyTabs[0]!.key);
    return (
      <div style={{ width: "320px" }}>
        <DetailTabStrip tabs={manyTabs} activeTab={active} onActiveTabChange={setActive} />
      </div>
    );
  },
};
