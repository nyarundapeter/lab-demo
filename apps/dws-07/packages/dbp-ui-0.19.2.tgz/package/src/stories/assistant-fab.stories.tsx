import type { Meta, StoryObj } from "@storybook/react";
import { AssistantFab } from "../components/assistant-fab.js";

const meta: Meta<typeof AssistantFab> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AssistantFab",
  component: AssistantFab,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AssistantFab>;

export const Default: Story = {
  render: () => (
    <div style={{ position: "relative", height: "160px" }}>
      <AssistantFab />
    </div>
  ),
};
