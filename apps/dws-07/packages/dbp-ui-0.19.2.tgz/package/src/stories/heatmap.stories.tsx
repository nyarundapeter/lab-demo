import type { Meta, StoryObj } from "@storybook/react";
import { Heatmap } from "../components/heatmap.js";

const meta: Meta<typeof Heatmap> = {
  title: "Layer 07 — App Scaffolds/Molecules/Data Display/Heatmap",
  component: Heatmap,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Heatmap>;

function riskColor(value: number) {
  if (value >= 4) return { bg: "var(--color-danger)", fg: "#fff" };
  if (value >= 2) return { bg: "var(--color-warning)", fg: "#111" };
  return { bg: "var(--color-success)", fg: "#fff" };
}

export const RiskMatrix: Story = {
  args: {
    rows: ["Critical", "High", "Medium", "Low"],
    cols: ["Rare", "Unlikely", "Possible", "Likely", "Certain"],
    data: [
      [2, 3, 4, 5, 5],
      [1, 2, 3, 4, 5],
      [1, 1, 2, 3, 4],
      [1, 1, 1, 2, 3],
    ],
    colorFor: riskColor,
    ariaLabel: "Risk heatmap — impact by likelihood",
  },
};

function retentionColor(value: number) {
  const alpha = Math.max(0.08, value / 100);
  return { bg: `color-mix(in srgb, var(--color-primary) ${Math.round(alpha * 100)}%, white)`, fg: value > 55 ? "#fff" : "#111" };
}

export const CohortRetention: Story = {
  args: {
    rows: ["Jan", "Feb", "Mar", "Apr"],
    cols: ["Month 0", "Month 1", "Month 2", "Month 3"],
    data: [
      [100, 62, 48, 40],
      [100, 58, 44, 0],
      [100, 65, 0, 0],
      [100, 0, 0, 0],
    ],
    colorFor: retentionColor,
    cellText: (v: number) => (v > 0 ? `${v}%` : "—"),
    ariaLabel: "Cohort retention by month",
  },
};
