import type { Meta, StoryObj } from "@storybook/react";
import { AutofillLauncher } from "../components/autofill-launcher.js";

const meta: Meta<typeof AutofillLauncher> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/AutofillLauncher",
  component: AutofillLauncher,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AutofillLauncher>;

export const Default: Story = {
  render: () => (
    <div style={{ maxWidth: 420 }}>
      <AutofillLauncher onStart={() => {}} />
    </div>
  ),
};
