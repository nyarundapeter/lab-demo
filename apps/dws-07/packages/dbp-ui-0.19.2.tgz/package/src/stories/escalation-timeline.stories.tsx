import type { Meta, StoryObj } from "@storybook/react";
import { EscalationTimeline, type EscalationStep } from "../components/escalation-timeline.js";

const meta: Meta<typeof EscalationTimeline> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/EscalationTimeline",
  component: EscalationTimeline,
  tags: ["autodocs"],
  parameters: { layout: "padded" },
};
export default meta;
type Story = StoryObj<typeof EscalationTimeline>;

const STEPS: EscalationStep[] = [
  { id: "1", label: "Approval assigned", time: "Mon 09:00", severity: "info", note: "Routed to Ava Okafor · due Wed 17:00", done: true },
  { id: "2", label: "Reminder — 24h before due", time: "Tue 17:00", severity: "info", note: "“1 day left. 2 similar requests pending.”", done: true },
  { id: "3", label: "Due today", time: "Wed 09:00", severity: "warning", note: "“Due by 17:00 today. Requestor is blocked.”", done: true },
  { id: "4", label: "Overdue", time: "Wed 17:30", severity: "error", note: "“Overdue by 30 min. Escalates to manager in 2h.”", done: true, current: true },
  { id: "5", label: "Escalated to manager", time: "Wed 19:30", severity: "error", note: "Reassigned to Lena Fischer · priority raised to Urgent" },
  { id: "6", label: "Resolved", time: "—", severity: "success", note: "Decision recorded, requestor notified, timeline closed" },
];

export const Default: Story = {
  args: { steps: STEPS },
};

export const AllDone: Story = {
  args: { steps: STEPS.map((s) => ({ ...s, done: true, current: false })) },
};
