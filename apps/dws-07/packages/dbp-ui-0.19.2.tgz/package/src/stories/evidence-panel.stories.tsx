import type { Meta, StoryObj } from "@storybook/react";
import { FileText, Link2, Database } from "lucide-react";
import { EvidencePanel } from "../components/evidence-panel.js";
import type { EvidenceItem } from "../components/evidence-panel.js";

const ITEMS: EvidenceItem[] = [
  { id: "1", name: "Vendor invoice PDF", meta: "PDF · 2.4 MB", icon: FileText, verified: true, onPreview: () => {} },
  { id: "2", name: "PO-2026-1187", meta: "Linked record · matched", icon: Link2, verified: true, onPreview: () => {} },
  { id: "3", name: "Security assessment", meta: "Required for renewals", icon: Database, verified: false },
];

const meta: Meta<typeof EvidencePanel> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/EvidencePanel",
  component: EvidencePanel,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof EvidencePanel>;

/** Two verified items, one missing — the header count reflects verified/total. */
export const Default: Story = {
  args: { items: ITEMS },
};

/** All items verified. */
export const AllVerified: Story = {
  args: { items: ITEMS.filter((i) => i.verified) },
};
