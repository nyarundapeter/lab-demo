import type { Meta, StoryObj } from "@storybook/react";
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectLabel,
  SelectGroup,
  SelectValue,
} from "../components/select.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Form Controls/Select",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <div style={{ width: "240px" }}>
      <Select>
        <SelectTrigger>
          <SelectValue placeholder="Select a status…" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="active">Active</SelectItem>
          <SelectItem value="pending">Pending</SelectItem>
          <SelectItem value="closed">Closed</SelectItem>
        </SelectContent>
      </Select>
    </div>
  ),
};

export const WithGroups: Story = {
  render: () => (
    <div style={{ width: "240px" }}>
      <Select>
        <SelectTrigger>
          <SelectValue placeholder="Select role…" />
        </SelectTrigger>
        <SelectContent>
          <SelectGroup>
            <SelectLabel>Operations</SelectLabel>
            <SelectItem value="analyst">Analyst</SelectItem>
            <SelectItem value="manager">Manager</SelectItem>
          </SelectGroup>
          <SelectGroup>
            <SelectLabel>Technology</SelectLabel>
            <SelectItem value="engineer">Engineer</SelectItem>
            <SelectItem value="architect">Architect</SelectItem>
          </SelectGroup>
        </SelectContent>
      </Select>
    </div>
  ),
};

export const ErrorState: Story = {
  render: () => (
    <div style={{ width: "240px" }}>
      <Select>
        <SelectTrigger error>
          <SelectValue placeholder="Required field" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="a">A</SelectItem>
        </SelectContent>
      </Select>
    </div>
  ),
};
