import type { Meta, StoryObj } from "@storybook/react";
import { Delta } from "../components/delta.js";

const meta: Meta<typeof Delta> = {
  title: "Layer 07 — App Scaffolds/Atoms/Indicators/Delta",
  component: Delta,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Delta>;

export const UpGood: Story = { args: { value: 12.4, polarity: "up-good" } };
export const DownGoodImprovement: Story = { args: { value: -8, polarity: "down-good" } };
export const DownGoodRegression: Story = { args: { value: 8, polarity: "down-good" } };
export const Flat: Story = { args: { value: 0 } };

export const Row: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "16px" }}>
      <Delta value={12.4} polarity="up-good" />
      <Delta value={-3.1} polarity="up-good" />
      <Delta value={-8} polarity="down-good" />
      <Delta value={0} />
    </div>
  ),
};
