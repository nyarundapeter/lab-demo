import type { Meta, StoryObj } from "@storybook/react";
import { AnnouncementBanner } from "../components/announcement-banner.js";

const meta: Meta<typeof AnnouncementBanner> = {
  title: "Layer 07 — App Scaffolds/Molecules/Collaboration/AnnouncementBanner",
  component: AnnouncementBanner,
  tags: ["autodocs"],
  parameters: {
    docs: {
      description: {
        component:
          "**Not wired — no shell Banner slot yet.** Ports `collaboration-system/forums.jsx` " +
          "`AnnouncementBanner`. Per Wave 3's Blocked-row build policy (Amendment A), the full " +
          "visual surface is built here against a typed prop interface, but `AppChrome` has no " +
          "banner slot to mount it into today (Wave 3 Family 4f source table: \"NEW, blocked\" — " +
          "\"No Banner slot exists yet in the shell\"). This component is Storybook-only until a " +
          "shell banner slot is added; do not wire it into a live app route before then.",
      },
    },
  },
};
export default meta;
type Story = StoryObj<typeof AnnouncementBanner>;

export const Default: Story = {
  args: {
    title: "Scheduled maintenance this weekend",
    body: "The platform will be briefly unavailable Saturday 2–4 AM ET for a database upgrade.",
    ctaLabel: "Learn more",
    onCtaClick: () => {},
    onDismiss: () => {},
    onDontShowAgain: () => {},
  },
};

export const WithoutCta: Story = {
  args: {
    title: "New pricing matrix is live",
    body: "Tiered renewal pricing is now available under Settings > Billing.",
    onDismiss: () => {},
  },
};
