import * as React from "react";

/**
 * Shared rendering helpers for the Design System/Foundations/* pages
 * (Colors/Typography/Spacing/RadiusAndShadow). NOT a *.stories.tsx file —
 * deliberately, so Storybook's stories glob doesn't try to index it as its
 * own component.
 */

export function useResolvedVar(token: string): string {
  const [value, setValue] = React.useState("");
  React.useEffect(() => {
    setValue(getComputedStyle(document.documentElement).getPropertyValue(token).trim());
  }, [token]);
  return value;
}

export function Swatch({ token, label }: { token: string; label: string }) {
  const resolved = useResolvedVar(token);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4, width: 132 }}>
      <div
        style={{
          height: 48,
          borderRadius: "var(--radius-md)",
          border: "1px solid var(--color-border-default)",
          background: `var(${token})`,
        }}
      />
      <span style={{ fontSize: 11, fontWeight: 600, color: "var(--color-text)" }}>{label}</span>
      <span style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: "var(--color-text-muted)" }}>
        {token}
      </span>
      <span style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: "var(--color-text-muted)" }}>
        {resolved || "…"}
      </span>
    </div>
  );
}

export function ColorGroup({ title, tokens }: { title: string; tokens: [string, string][] }) {
  return (
    <section style={{ marginBottom: 32 }}>
      <h3 style={{ fontSize: 13, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--color-text-muted)", marginBottom: 12 }}>
        {title}
      </h3>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 16 }}>
        {tokens.map(([token, label]) => (
          <Swatch key={token} token={token} label={label} />
        ))}
      </div>
    </section>
  );
}

export const triad = (name: string, hasBase = true): [string, string][] => [
  ...(hasBase ? ([[`--color-${name}`, `${name} (base)`]] as [string, string][]) : []),
  [`--color-${name}-surface`, `${name}-surface`],
  [`--color-${name}-text`, `${name}-text`],
  [`--color-${name}-border`, `${name}-border`],
];

export function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <h3 style={{ fontSize: 13, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--color-text-muted)", marginBottom: 12 }}>
      {children}
    </h3>
  );
}
