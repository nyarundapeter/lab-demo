import type { Meta, StoryObj } from "@storybook/react";
import { ProvenanceKey } from "../components/provenance-key.js";

const meta: Meta<typeof ProvenanceKey> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/ProvenanceKey",
  component: ProvenanceKey,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ProvenanceKey>;

export const Default: Story = {};
