import type { Meta, StoryObj } from "@storybook/react";
import { RootCauseCard, type RootCauseCardData } from "../components/root-cause-card.js";

const meta: Meta<typeof RootCauseCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/AI/RootCauseCard",
  component: RootCauseCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof RootCauseCard>;

const DATA: RootCauseCardData = {
  problem: "Checkout failures — EU-West, since 09:00",
  hypotheses: [
    {
      cause: "Deploy payments-svc 3.14.2 introduced a regression",
      confidence: "high",
      support: ["Onset aligns with deploy at 08:52", "Error rate correlates with node rollout order"],
      contradicting: ["2 nodes on 3.14.2 show no elevated errors"],
      validate: "Roll back one EU-West node to 3.14.1 and compare error rates.",
      sources: [
        { n: 1, type: "Activity", title: "Deploy payments-svc 3.14.2", meta: "08:52", fresh: "1h", rel: "high" },
        { n: 2, type: "Metric", title: "EU-West error rate", meta: "Live metric", fresh: "1 min", rel: "high" },
      ],
    },
    {
      cause: "Upstream card-processor outage",
      confidence: "low",
      support: ["Processor status page shows a brief blip at 09:10"],
      contradicting: ["Blip duration (4 min) is much shorter than the observed 2h failure window"],
      validate: "Cross-reference processor incident log against full failure timeline.",
      sources: [{ n: 3, type: "Activity", title: "Processor status page", meta: "09:10", fresh: "30 min", rel: "medium" }],
    },
  ],
};

export const Default: Story = {
  render: () => (
    <div style={{ maxWidth: 560 }}>
      <RootCauseCard data={DATA} onCreateInvestigation={() => {}} />
    </div>
  ),
};
