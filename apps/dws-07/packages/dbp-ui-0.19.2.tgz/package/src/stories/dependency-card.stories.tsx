import type { Meta, StoryObj } from "@storybook/react";
import { DependencyCard } from "../components/dependency-card.js";

const meta: Meta<typeof DependencyCard> = {
  title: "Layer 07 — App Scaffolds/Molecules/Workflow/DependencyCard",
  component: DependencyCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof DependencyCard>;

export const Blocking: Story = {
  args: {
    direction: "blocking",
    recordLabel: "PR-1042 Vendor onboarding",
    statusLabel: "In review",
    onNavigate: () => {},
  },
};

export const BlockedBy: Story = {
  args: {
    direction: "blocked-by",
    recordLabel: "CR-2201 Budget approval",
    statusLabel: "Pending",
    onNavigate: () => {},
  },
};
