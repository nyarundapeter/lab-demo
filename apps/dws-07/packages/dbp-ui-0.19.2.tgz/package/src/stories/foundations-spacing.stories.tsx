import type { Meta, StoryObj } from "@storybook/react";
import { SectionHeading } from "./foundations-shared.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Foundations/Spacing",
  tags: ["autodocs"],
  parameters: { layout: "fullscreen" },
};
export default meta;
type Story = StoryObj;

const SPACE_SCALE = ["--space-0", "--space-1", "--space-2", "--space-3", "--space-4", "--space-5", "--space-6", "--space-8", "--space-10", "--space-12", "--space-16", "--space-20", "--space-24"];

export const Scale: Story = {
  render: () => (
    <div style={{ padding: 32, background: "var(--color-surface)" }}>
      <SectionHeading>Spacing scale</SectionHeading>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {SPACE_SCALE.map((token) => (
          <div key={token} style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ width: 110, fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--color-text-muted)" }}>{token}</span>
            <div style={{ height: 16, width: `var(${token})`, background: "var(--color-primary)", borderRadius: 2 }} />
          </div>
        ))}
      </div>
    </div>
  ),
};
