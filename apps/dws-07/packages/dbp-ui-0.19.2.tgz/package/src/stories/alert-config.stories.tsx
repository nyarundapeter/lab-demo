import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { AlertConfig, type AlertFrequency } from "../components/alert-config.js";

const meta: Meta<typeof AlertConfig> = {
  title: "Layer 07 — App Scaffolds/Molecules/Search/AlertConfig",
  component: AlertConfig,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AlertConfig>;

function Controlled() {
  const [enabled, setEnabled] = useState(true);
  const [frequency, setFrequency] = useState<AlertFrequency>("realtime");
  return (
    <AlertConfig
      enabled={enabled}
      frequency={frequency}
      onEnabledChange={setEnabled}
      onFrequencyChange={setFrequency}
      description="Get alerted when a record starts matching this search."
    />
  );
}

export const Default: Story = {
  render: () => <Controlled />,
};

export const Off: Story = {
  args: { enabled: false, frequency: "realtime", onEnabledChange: () => {}, onFrequencyChange: () => {} },
};
