import type { Meta, StoryObj } from "@storybook/react";
import { ActivityTimeline } from "../components/activity-timeline.js";
import type { ActivityEntry, ActivityTimelineConfig } from "../schemas/activity.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Molecules/Activity/ActivityTimeline",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

const CONFIG: ActivityTimelineConfig = {
  entityType: "deal",
  activityTypes: {
    note: { icon: "note", tone: "warning", label: "Note" },
    email: { icon: "mail", tone: "info", label: "Email" },
    call: { icon: "phone", tone: "success", label: "Call" },
    meeting: { icon: "calendar", tone: "danger", label: "Meeting" },
    stage: { icon: "arrowRight", tone: "neutral", label: "Stage change" },
  },
  mentions: true,
  tags: true,
  attachments: true,
  labels: {
    emptyBody: "No activity logged for this deal yet.",
    errorBody: "The activity feed didn't load. Try again.",
  },
};

const ENTRIES: ActivityEntry[] = [
  {
    id: "act-1",
    type: "stage",
    actorName: "System",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    bodyText: "Moved from Negotiation to Contracting.",
  },
  {
    id: "act-2",
    type: "call",
    actorName: "Tomas Berg",
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    bodyText: "Quick call to confirm rollout timeline. @Priya Nair to send the updated SOW by Friday.",
    tags: ["renewal", "timeline"],
  },
  {
    id: "act-3",
    type: "email",
    actorName: "Amara Osei",
    timestamp: new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString(),
    bodyText: "Sent the revised pricing proposal reflecting the multi-year discount. Attached the signed order form template.",
    tags: ["pricing"],
    attachments: [
      { id: "f1", name: "Order-Form-v3.pdf", sizeKb: 214 },
      { id: "f2", name: "Security-Questionnaire.xlsx", sizeKb: 88 },
    ],
  },
  {
    id: "act-4",
    type: "note",
    actorName: "Diego Ruiz",
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    bodyText: "Champion confirmed budget is approved for Q3.",
  },
  {
    id: "act-5",
    type: "legacy_import",
    actorName: "Migration Bot",
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    bodyText: "Imported from the previous CRM during account migration.",
  },
];

export const Populated: Story = {
  render: () => <ActivityTimeline config={CONFIG} state="populated" entries={ENTRIES} />,
};

export const SingleItem: Story = {
  name: "Single item (connector edge case)",
  render: () => <ActivityTimeline config={CONFIG} state="populated" entries={[ENTRIES[0]!]} />,
};

export const Loading: Story = {
  render: () => <ActivityTimeline config={CONFIG} state="loading" />,
};

export const Empty: Story = {
  render: () => <ActivityTimeline config={CONFIG} state="empty" />,
};

export const ErrorWithRetry: Story = {
  name: "Error (with retry)",
  render: () => <ActivityTimeline config={CONFIG} state="error" onRetry={() => {}} />,
};

export const UnknownTypeFallback: Story = {
  name: "Unmapped activity type (neutral fallback)",
  render: () => <ActivityTimeline config={CONFIG} state="populated" entries={[ENTRIES[4]!]} />,
};
