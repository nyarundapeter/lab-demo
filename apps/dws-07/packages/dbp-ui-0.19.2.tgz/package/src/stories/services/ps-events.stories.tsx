import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureEventsClient } from "@dbp/ps-events/client";
import { useRecentEvents } from "@dbp/ps-events/client";
import type { DomainEvent, DomainEventType } from "@dbp/ps-events/client";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      })
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise<Response>(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal server error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      })
    );
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const MOCK_EVENTS: DomainEvent[] = [
  {
    id: "00000000-0000-0000-0000-000000000001",
    type: "workflow.advanced" as DomainEventType,
    source: "ps-workflow",
    ts: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    tenantId: "tenant-alpha",
    correlationId: "00000000-0000-0000-0000-00000000a001",
    payload: { workflowId: "wf-001", stepId: "review", actor: "admin" },
  },
  {
    id: "00000000-0000-0000-0000-000000000002",
    type: "entity.created" as DomainEventType,
    source: "ps-data",
    ts: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    tenantId: "tenant-alpha",
    correlationId: "00000000-0000-0000-0000-00000000a002",
    payload: { entityType: "task", entityId: "task-001" },
  },
  {
    id: "00000000-0000-0000-0000-000000000003",
    type: "notification.sent" as DomainEventType,
    source: "ps-notif",
    ts: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
    tenantId: "tenant-alpha",
    correlationId: "00000000-0000-0000-0000-00000000a003",
    payload: { to: "alice@example.com", type: "task.assigned" },
  },
];

// ---------------------------------------------------------------------------
// Relative time helper
// ---------------------------------------------------------------------------

function relativeTime(isoTs: string): string {
  const diffMs = Date.now() - new Date(isoTs).getTime();
  const diffMin = Math.floor(diffMs / 60_000);
  if (diffMin < 1) return "just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return `${Math.floor(diffHr / 24)}d ago`;
}

// ---------------------------------------------------------------------------
// Badge colour by event type
// ---------------------------------------------------------------------------

const TYPE_COLORS: Record<string, string> = {
  "workflow.advanced": "#0d6efd",
  "workflow.rejected": "#dc3545",
  "entity.created": "#198754",
  "entity.updated": "#fd7e14",
  "entity.deleted": "#6c757d",
  "notification.sent": "#6610f2",
};

function typeBadgeStyle(type: string): React.CSSProperties {
  return {
    display: "inline-block",
    padding: "2px 8px",
    borderRadius: 4,
    fontSize: 11,
    fontWeight: 600,
    color: "#fff",
    background: TYPE_COLORS[type] ?? "#495057",
    letterSpacing: "0.02em",
  };
}

// ---------------------------------------------------------------------------
// Demo component
// ---------------------------------------------------------------------------

function EventStreamDemo() {
  const { events, isLoading, error } = useRecentEvents({ tenantId: "tenant-alpha" });

  if (isLoading) {
    return (
      <div style={{ padding: "2rem", color: "#6c757d", fontSize: 14 }}>
        Loading events…
      </div>
    );
  }

  if (error) {
    return (
      <div
        style={{
          padding: "1rem",
          background: "#fff5f5",
          border: "1px solid #f5c6cb",
          borderRadius: 6,
          color: "#721c24",
          fontSize: 14,
        }}
      >
        Failed to load events: {(error as Error).message}
      </div>
    );
  }

  if (events.length === 0) {
    return (
      <div
        style={{
          padding: "2rem",
          textAlign: "center",
          color: "#6c757d",
          fontSize: 14,
          border: "1px dashed #dee2e6",
          borderRadius: 6,
        }}
      >
        No events yet.
      </div>
    );
  }

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", maxWidth: 640 }}>
      <h3 style={{ marginBottom: "1rem", fontSize: 15, fontWeight: 600, color: "#212529" }}>
        Recent Domain Events
      </h3>
      <ol
        style={{
          listStyle: "none",
          margin: 0,
          padding: 0,
          display: "flex",
          flexDirection: "column",
          gap: 0,
          borderLeft: "2px solid #dee2e6",
          paddingLeft: "1rem",
        }}
      >
        {events.map((evt) => (
          <li
            key={evt.id}
            style={{
              position: "relative",
              paddingBottom: "1.25rem",
            }}
          >
            {/* timeline dot */}
            <span
              style={{
                position: "absolute",
                left: "-1.4rem",
                top: 3,
                width: 10,
                height: 10,
                borderRadius: "50%",
                background: TYPE_COLORS[evt.type] ?? "#adb5bd",
                border: "2px solid #fff",
                boxShadow: "0 0 0 1px #dee2e6",
              }}
            />
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <span style={typeBadgeStyle(evt.type)}>{evt.type}</span>
              <span style={{ fontSize: 12, color: "#adb5bd" }}>{relativeTime(evt.ts)}</span>
            </div>
            <div style={{ fontSize: 12, color: "#6c757d", marginBottom: 4 }}>
              source: <strong style={{ color: "#495057" }}>{evt.source}</strong>
              &nbsp;·&nbsp;id: <code style={{ fontSize: 11 }}>{evt.id}</code>
            </div>
            <pre
              style={{
                margin: 0,
                padding: "6px 10px",
                background: "#f8f9fa",
                borderRadius: 4,
                fontSize: 11,
                color: "#343a40",
                overflowX: "auto",
              }}
            >
              {JSON.stringify(evt.payload, null, 2)}
            </pre>
          </li>
        ))}
      </ol>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Meta
// ---------------------------------------------------------------------------

const meta: Meta<typeof EventStreamDemo> = {
  title: "Layer 06 — Platform Services/PS.EVENTS/Event Stream",
  component: EventStreamDemo,
  tags: ["autodocs"],
};
export default meta;

type Story = StoryObj<typeof EventStreamDemo>;

// ---------------------------------------------------------------------------
// Stories
// ---------------------------------------------------------------------------

export const WithEvents: Story = {
  name: "WithEvents",
  decorators: [
    (Story) => {
      configureEventsClient({
        baseUrl: "http://storybook.test/api/platform/events",
        fetch: makeFetch({ events: MOCK_EVENTS, nextCursor: null }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Loading: Story = {
  name: "Loading",
  decorators: [
    (Story) => {
      configureEventsClient({
        baseUrl: "http://storybook.test/api/platform/events",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Empty: Story = {
  name: "Empty",
  decorators: [
    (Story) => {
      configureEventsClient({
        baseUrl: "http://storybook.test/api/platform/events",
        fetch: makeFetch({ events: [], nextCursor: null }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Error: Story = {
  name: "Error",
  decorators: [
    (Story) => {
      configureEventsClient({
        baseUrl: "http://storybook.test/api/platform/events",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};
