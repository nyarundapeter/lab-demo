import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureDataClient } from "@dbp/ps-data/client";
import { useEntityList, useEntity } from "@dbp/ps-data/client";
import type { EntityRecord } from "@dbp/ps-data/client";

// ---------------------------------------------------------------------------
// Fake fetch helpers
// ---------------------------------------------------------------------------

type FakeFetchData = Record<string, unknown>;

function makeFetch(
  handler: (url: string) => FakeFetchData | null,
): () => (input: string) => Promise<Response> {
  return () => (input: string) => {
    const data = handler(input);
    if (data === null) {
      return Promise.resolve(
        new Response(JSON.stringify({ error: "Not found" }), {
          status: 404,
          headers: { "content-type": "application/json" },
        }),
      );
    }
    return Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
  };
}

function errorFetch(): (input: string) => Promise<Response> {
  return (_input: string) =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal Server Error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      }),
    );
}

function pendingFetch(): (input: string) => Promise<Response> {
  return (_input: string) => new Promise<Response>(() => {});
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const MOCK_ROWS: EntityRecord[] = [
  {
    id: "rec-001",
    type: "demo-record",
    tenantId: "tenant-alpha",
    createdAt: "2026-01-10T08:00:00Z",
    updatedAt: "2026-06-01T12:00:00Z",
    data: { name: "Alpha Initiative", status: "Active", owner: "Sarah Chen", priority: "High" },
  },
  {
    id: "rec-002",
    type: "demo-record",
    tenantId: "tenant-alpha",
    createdAt: "2026-02-14T09:30:00Z",
    updatedAt: "2026-06-10T14:20:00Z",
    data: { name: "Beta Programme", status: "In Review", owner: "James Park", priority: "Medium" },
  },
  {
    id: "rec-003",
    type: "demo-record",
    tenantId: "tenant-alpha",
    createdAt: "2026-03-05T11:00:00Z",
    updatedAt: "2026-06-15T09:45:00Z",
    data: { name: "Gamma Project", status: "Pending", owner: "Nadia Al-Rashid", priority: "Low" },
  },
  {
    id: "rec-004",
    type: "demo-record",
    tenantId: "tenant-alpha",
    createdAt: "2026-04-20T13:00:00Z",
    updatedAt: "2026-06-18T16:00:00Z",
    data: { name: "Delta Workstream", status: "Active", owner: "Tom Liu", priority: "High" },
  },
  {
    id: "rec-005",
    type: "demo-record",
    tenantId: "tenant-alpha",
    createdAt: "2026-05-01T07:00:00Z",
    updatedAt: "2026-06-19T10:30:00Z",
    data: { name: "Epsilon Track", status: "Closed", owner: "Priya Menon", priority: "Medium" },
  },
];

const MOCK_DETAIL: EntityRecord = {
  id: "rec-001",
  type: "demo-record",
  tenantId: "tenant-alpha",
  createdAt: "2026-01-10T08:00:00Z",
  updatedAt: "2026-06-01T12:00:00Z",
  data: { name: "Alpha Initiative", status: "Active", owner: "Sarah Chen", priority: "High" },
};

function listResponse(rows: EntityRecord[]) {
  return { rows, total: rows.length, page: 1, pageSize: 20 };
}

// ---------------------------------------------------------------------------
// Status badge helper
// ---------------------------------------------------------------------------

const STATUS_COLORS: Record<string, string> = {
  Active: "#16a34a",
  "In Review": "#d97706",
  Pending: "#6b7280",
  Closed: "#dc2626",
};

function StatusBadge({ status }: { status: string }) {
  const color = STATUS_COLORS[status] ?? "#6b7280";
  return (
    <span
      style={{
        display: "inline-block",
        padding: "2px 8px",
        borderRadius: 4,
        fontSize: 12,
        fontWeight: 600,
        background: color + "22",
        color,
        border: `1px solid ${color}44`,
      }}
    >
      {status}
    </span>
  );
}

// ---------------------------------------------------------------------------
// EntityListDemo
// ---------------------------------------------------------------------------

function EntityListDemo() {
  const { rows, total, isLoading, error } = useEntityList("demo-record");

  if (isLoading) {
    return (
      <div style={{ padding: "2rem", color: "#6b7280", fontFamily: "sans-serif" }}>
        Loading records…
      </div>
    );
  }

  if (error) {
    return (
      <div
        style={{
          padding: "1rem",
          background: "#fef2f2",
          border: "1px solid #fca5a5",
          borderRadius: 8,
          color: "#dc2626",
          fontFamily: "sans-serif",
        }}
      >
        <strong>Error:</strong> {(error as Error).message ?? "Failed to load records."}
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div
        style={{
          padding: "2rem",
          textAlign: "center",
          color: "#9ca3af",
          fontFamily: "sans-serif",
        }}
      >
        No records found.
      </div>
    );
  }

  return (
    <div style={{ fontFamily: "sans-serif" }}>
      <div
        style={{
          marginBottom: 12,
          fontSize: 13,
          color: "#6b7280",
        }}
      >
        {total} record{total !== 1 ? "s" : ""}
      </div>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
        <thead>
          <tr style={{ borderBottom: "2px solid #e5e7eb" }}>
            <th style={{ textAlign: "left", padding: "8px 12px", color: "#374151" }}>Name</th>
            <th style={{ textAlign: "left", padding: "8px 12px", color: "#374151" }}>Status</th>
            <th style={{ textAlign: "left", padding: "8px 12px", color: "#374151" }}>Owner</th>
            <th style={{ textAlign: "left", padding: "8px 12px", color: "#374151" }}>Priority</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const d = row.data as { name?: string; status?: string; owner?: string; priority?: string };
            return (
              <tr
                key={row.id}
                style={{ borderBottom: "1px solid #f3f4f6" }}
              >
                <td style={{ padding: "10px 12px", color: "#111827", fontWeight: 500 }}>
                  {d.name ?? row.id}
                </td>
                <td style={{ padding: "10px 12px" }}>
                  <StatusBadge status={d.status ?? "Unknown"} />
                </td>
                <td style={{ padding: "10px 12px", color: "#374151" }}>{d.owner ?? "—"}</td>
                <td style={{ padding: "10px 12px", color: "#374151" }}>{d.priority ?? "—"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------------------
// EntityDetailDemo
// ---------------------------------------------------------------------------

function EntityDetailDemo({ id }: { id: string }) {
  const { record, isLoading, error } = useEntity("demo-record", id);

  if (isLoading) {
    return (
      <div style={{ padding: "2rem", color: "#6b7280", fontFamily: "sans-serif" }}>
        Loading record…
      </div>
    );
  }

  if (error) {
    const msg = (error as Error).message ?? "";
    const is404 = msg.includes("404") || msg.includes("not found") || msg.toLowerCase().includes("not found");
    return (
      <div
        style={{
          padding: "1rem",
          background: is404 ? "#fffbeb" : "#fef2f2",
          border: `1px solid ${is404 ? "#fcd34d" : "#fca5a5"}`,
          borderRadius: 8,
          color: is404 ? "#92400e" : "#dc2626",
          fontFamily: "sans-serif",
        }}
      >
        <strong>{is404 ? "Not Found:" : "Error:"}</strong>{" "}
        {is404 ? `No record with id "${id}" exists.` : msg || "Failed to load record."}
      </div>
    );
  }

  if (!record) return null;

  const d = record.data as { name?: string; status?: string; owner?: string; priority?: string };

  return (
    <div
      style={{
        fontFamily: "sans-serif",
        border: "1px solid #e5e7eb",
        borderRadius: 8,
        overflow: "hidden",
        maxWidth: 480,
      }}
    >
      <div
        style={{
          background: "#f9fafb",
          borderBottom: "1px solid #e5e7eb",
          padding: "12px 16px",
          display: "flex",
          alignItems: "center",
          gap: 10,
        }}
      >
        <span style={{ fontWeight: 700, fontSize: 16, color: "#111827" }}>{d.name ?? record.id}</span>
        <StatusBadge status={d.status ?? "Unknown"} />
      </div>
      <dl style={{ margin: 0, padding: "12px 16px", display: "grid", gap: 8 }}>
        {(
          [
            ["ID", record.id],
            ["Type", record.type],
            ["Tenant", record.tenantId],
            ["Owner", d.owner ?? "—"],
            ["Priority", d.priority ?? "—"],
            ["Created", new Date(record.createdAt).toLocaleDateString()],
            ["Updated", new Date(record.updatedAt).toLocaleDateString()],
          ] as [string, string][]
        ).map(([label, value]) => (
          <div key={label} style={{ display: "flex", gap: 8, fontSize: 14 }}>
            <dt style={{ color: "#6b7280", minWidth: 80 }}>{label}</dt>
            <dd style={{ margin: 0, color: "#111827" }}>{value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Story: EntityList — Meta
// ---------------------------------------------------------------------------

const EntityListMeta: Meta = {
  title: "Layer 06 — Platform Services/PS.DATA/Entity List",
  tags: ["autodocs"],
  parameters: { layout: "padded" },
};

export default EntityListMeta;

// Populated
export const Populated: StoryObj = {
  name: "Populated",
  decorators: [
    (Story) => {
      configureDataClient({
        baseUrl: "http://storybook.test/api/platform/data",
        fetch: makeFetch((_url) => listResponse(MOCK_ROWS) as unknown as FakeFetchData)(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <EntityListDemo />,
};

// Loading
export const Loading: StoryObj = {
  name: "Loading",
  decorators: [
    (Story) => {
      configureDataClient({
        baseUrl: "http://storybook.test/api/platform/data",
        fetch: pendingFetch(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <EntityListDemo />,
};

// Empty
export const Empty: StoryObj = {
  name: "Empty",
  decorators: [
    (Story) => {
      configureDataClient({
        baseUrl: "http://storybook.test/api/platform/data",
        fetch: makeFetch((_url) => listResponse([]) as unknown as FakeFetchData)(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <EntityListDemo />,
};

// Error
export const Error: StoryObj = {
  name: "Error",
  decorators: [
    (Story) => {
      configureDataClient({
        baseUrl: "http://storybook.test/api/platform/data",
        fetch: errorFetch(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <EntityListDemo />,
};

// ---------------------------------------------------------------------------
// Story: EntityDetail — separate file would be ideal but co-located here
// per the task instruction (single file).
// We export these under a different title via a named re-export approach,
// but Storybook requires default export per file.
// Solution: append the detail stories to this file using StoryObj with
// explicit title override via parameters.storyName.
// ---------------------------------------------------------------------------

export const DetailPopulated: StoryObj = {
  name: "Layer 06 — Platform Services/PS.DATA/Entity Detail — Populated",
  parameters: { storyName: "Populated" },
  decorators: [
    (Story) => {
      configureDataClient({
        baseUrl: "http://storybook.test/api/platform/data",
        fetch: makeFetch((url) => {
          if (/\/entities\/demo-record\/rec-001/.test(url)) {
            return MOCK_DETAIL as unknown as FakeFetchData;
          }
          return listResponse(MOCK_ROWS) as unknown as FakeFetchData;
        })(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <EntityDetailDemo id="rec-001" />,
};

export const DetailLoading: StoryObj = {
  name: "Layer 06 — Platform Services/PS.DATA/Entity Detail — Loading",
  decorators: [
    (Story) => {
      configureDataClient({
        baseUrl: "http://storybook.test/api/platform/data",
        fetch: pendingFetch(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <EntityDetailDemo id="rec-001" />,
};

export const DetailNotFound: StoryObj = {
  name: "Layer 06 — Platform Services/PS.DATA/Entity Detail — NotFound",
  decorators: [
    (Story) => {
      configureDataClient({
        baseUrl: "http://storybook.test/api/platform/data",
        fetch: makeFetch((_url) => null)(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <EntityDetailDemo id="rec-999" />,
};
