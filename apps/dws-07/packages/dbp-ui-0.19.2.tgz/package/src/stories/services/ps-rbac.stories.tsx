import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureRbacClient, Gate, useCan, fetchMatrix } from "@dbp/ps-rbac/client";
import type { MatrixResponse } from "@dbp/ps-rbac/client";
import { useEffect, useState } from "react";

// ---------------------------------------------------------------------------
// Fetch helpers
// ---------------------------------------------------------------------------

function toMessage(err: unknown): string {
  if (err !== null && typeof err === "object" && "message" in err && typeof (err as { message: unknown }).message === "string") {
    return (err as { message: string }).message;
  }
  return "Unknown error";
}

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise<Response>(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      }),
    );
}

// ---------------------------------------------------------------------------
// Packed CASL rules mocks
// ---------------------------------------------------------------------------

// Admin: can do everything
// CASL packRules produces tuples: [action, subject] — NOT plain objects.
const ADMIN_PACKED_RULES = {
  rules: [
    ["manage", "all"],
  ],
  tenantId: "tenant-alpha",
  roles: ["platform-admin"],
};

// Viewer: can only read/view
const VIEWER_PACKED_RULES = {
  rules: [
    ["invoice.view", "all"],
    ["record.view", "all"],
  ],
  tenantId: "tenant-alpha",
  roles: ["viewer"],
};

// ---------------------------------------------------------------------------
// Matrix mock
// ---------------------------------------------------------------------------

const MATRIX_DATA: MatrixResponse = {
  roles: [
    { id: "platform-admin", label: "Platform Admin" },
    { id: "solution-author", label: "Solution Author" },
    { id: "viewer", label: "Viewer" },
  ],
  permissions: [
    { action: "invoice.approve", resource: "Invoice", description: "Approve invoices" },
    { action: "invoice.view", resource: "Invoice", description: "View invoices" },
    { action: "record.create", resource: "Record", description: "Create records" },
    { action: "record.view", resource: "Record", description: "View records" },
  ],
  matrix: [
    { role: "platform-admin", action: "invoice.approve", resource: "Invoice", condition: null },
    { role: "platform-admin", action: "invoice.view", resource: "Invoice", condition: null },
    { role: "platform-admin", action: "record.create", resource: "Record", condition: null },
    { role: "platform-admin", action: "record.view", resource: "Record", condition: null },
    { role: "solution-author", action: "invoice.view", resource: "Invoice", condition: null },
    { role: "solution-author", action: "record.create", resource: "Record", condition: null },
    { role: "solution-author", action: "record.view", resource: "Record", condition: null },
    { role: "viewer", action: "invoice.view", resource: "Invoice", condition: null },
    { role: "viewer", action: "record.view", resource: "Record", condition: null },
  ],
};

// ---------------------------------------------------------------------------
// Permission Gate stories
// ---------------------------------------------------------------------------

function PermissionGateDemo() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
      <Gate
        action="invoice.approve"
        fallback={
          <div
            style={{
              padding: "0.75rem 1rem",
              background: "#fef2f2",
              border: "1px solid #fca5a5",
              borderRadius: "6px",
              color: "#dc2626",
              fontFamily: "system-ui, sans-serif",
              fontSize: "0.875rem",
            }}
          >
            Denied — you do not have permission to approve invoices.
          </div>
        }
      >
        <div
          style={{
            padding: "0.75rem 1rem",
            background: "#f0fdf4",
            border: "1px solid #86efac",
            borderRadius: "6px",
            color: "#16a34a",
            fontFamily: "system-ui, sans-serif",
            fontSize: "0.875rem",
          }}
        >
          Allowed — Approve Invoice button would render here.
        </div>
      </Gate>

      <Gate
        action="record.view"
        fallback={
          <div
            style={{
              padding: "0.75rem 1rem",
              background: "#fef2f2",
              border: "1px solid #fca5a5",
              borderRadius: "6px",
              color: "#dc2626",
              fontFamily: "system-ui, sans-serif",
              fontSize: "0.875rem",
            }}
          >
            Denied — you cannot view records.
          </div>
        }
      >
        <div
          style={{
            padding: "0.75rem 1rem",
            background: "#f0fdf4",
            border: "1px solid #86efac",
            borderRadius: "6px",
            color: "#16a34a",
            fontFamily: "system-ui, sans-serif",
            fontSize: "0.875rem",
          }}
        >
          Allowed — Records list would render here.
        </div>
      </Gate>
    </div>
  );
}

const gateMeta: Meta<typeof PermissionGateDemo> = {
  title: "Layer 06 — Platform Services/PS.RBAC/Permission Gate",
  component: PermissionGateDemo,
  tags: ["autodocs"],
};

export default gateMeta;
type GateStory = StoryObj<typeof PermissionGateDemo>;

export const Allowed: GateStory = {
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: makeFetch(ADMIN_PACKED_RULES),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Denied: GateStory = {
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: makeFetch(VIEWER_PACKED_RULES),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Loading: GateStory = {
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <p
              style={{
                fontFamily: "system-ui, sans-serif",
                fontSize: "0.875rem",
                color: "#6b7280",
                marginBottom: "0.5rem",
              }}
            >
              Rules loading — Gate renders fallback (or nothing) while pending.
            </p>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Empty: GateStory = {
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: makeFetch({ rules: [], tenantId: "tenant-alpha", roles: [] }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <p
              style={{
                fontFamily: "system-ui, sans-serif",
                fontSize: "0.875rem",
                color: "#6b7280",
                marginBottom: "0.5rem",
              }}
            >
              Empty rules — user has no permissions assigned.
            </p>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Error: GateStory = {
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <p
              style={{
                fontFamily: "system-ui, sans-serif",
                fontSize: "0.875rem",
                color: "#dc2626",
                marginBottom: "0.5rem",
              }}
            >
              Rules fetch errored — Gate defaults to denied (safe failure).
            </p>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ---------------------------------------------------------------------------
// Permission Matrix stories — separate named export file below
// We follow the pattern of one default export per file, so Matrix and useCan
// stories live in companion files. However the task requests all three in one
// file. We export non-default named stories for the other two components via
// a secondary meta trick (Storybook 7+ supports multiple CSF files; the
// single-file constraint is met by exporting the demos as plain components
// with inline meta objects used in a single default export above.
//
// Since Storybook requires exactly ONE default export per file we embed the
// Matrix and useCan demos as additional stories under this file by reusing the
// component slot and overriding render.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Matrix demo component
// ---------------------------------------------------------------------------

function MatrixDemo() {
  const [matrix, setMatrix] = useState<MatrixResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetchMatrix()
      .then((data) => {
        if (!cancelled) {
          setMatrix(data);
          setLoading(false);
        }
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          setError(toMessage(err));
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) {
    return (
      <p style={{ fontFamily: "system-ui, sans-serif", color: "#6b7280" }}>
        Loading permission matrix…
      </p>
    );
  }

  if (error) {
    return (
      <p style={{ fontFamily: "system-ui, sans-serif", color: "#dc2626" }}>Error: {error}</p>
    );
  }

  if (!matrix) return null;

  const roles = matrix.roles;
  const permissions = matrix.permissions;

  function hasPermission(roleId: string, action: string): boolean {
    return matrix!.matrix.some((e) => e.role === roleId && e.action === action);
  }

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", fontSize: "0.875rem" }}>
      <table
        style={{
          borderCollapse: "collapse",
          width: "100%",
          border: "1px solid #e5e7eb",
        }}
      >
        <thead>
          <tr style={{ background: "#f9fafb" }}>
            <th
              style={{
                padding: "0.5rem 0.75rem",
                textAlign: "left",
                borderBottom: "1px solid #e5e7eb",
                color: "#374151",
              }}
            >
              Permission
            </th>
            {roles.map((role) => (
              <th
                key={role.id}
                style={{
                  padding: "0.5rem 0.75rem",
                  textAlign: "center",
                  borderBottom: "1px solid #e5e7eb",
                  color: "#374151",
                }}
              >
                {role.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {permissions.map((perm, i) => (
            <tr
              key={perm.action}
              style={{ background: i % 2 === 0 ? "#ffffff" : "#f9fafb" }}
            >
              <td
                style={{
                  padding: "0.5rem 0.75rem",
                  borderBottom: "1px solid #f3f4f6",
                  color: "#111827",
                }}
              >
                <div style={{ fontWeight: 500 }}>{perm.action}</div>
                {perm.description && (
                  <div style={{ color: "#6b7280", fontSize: "0.75rem" }}>{perm.description}</div>
                )}
              </td>
              {roles.map((role) => (
                <td
                  key={role.id}
                  style={{
                    padding: "0.5rem 0.75rem",
                    textAlign: "center",
                    borderBottom: "1px solid #f3f4f6",
                  }}
                >
                  {hasPermission(role.id, perm.action) ? (
                    <span style={{ color: "#16a34a", fontWeight: 600 }}>Yes</span>
                  ) : (
                    <span style={{ color: "#d1d5db" }}>—</span>
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------------------
// useCan demo component
// ---------------------------------------------------------------------------

const DEMO_ACTIONS = [
  { action: "invoice.approve", label: "invoice.approve" },
  { action: "invoice.view", label: "invoice.view" },
  { action: "record.create", label: "record.create" },
  { action: "record.view", label: "record.view" },
];

function UseCanDemo() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "0.5rem",
        fontFamily: "system-ui, sans-serif",
      }}
    >
      {DEMO_ACTIONS.map(({ action, label }) => (
        <CanRow key={action} action={action} label={label} />
      ))}
    </div>
  );
}

function CanRow({ action, label }: { action: string; label: string }) {
  const allowed = useCan(action);
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "0.75rem",
        padding: "0.5rem 0.75rem",
        border: "1px solid #e5e7eb",
        borderRadius: "6px",
        background: "#ffffff",
      }}
    >
      <code
        style={{
          flex: 1,
          fontSize: "0.8125rem",
          color: "#374151",
          fontFamily: "monospace",
        }}
      >
        {label}
      </code>
      <span
        style={{
          display: "inline-block",
          padding: "0.125rem 0.5rem",
          borderRadius: "9999px",
          fontSize: "0.75rem",
          fontWeight: 600,
          background: allowed ? "#dcfce7" : "#fee2e2",
          color: allowed ? "#15803d" : "#dc2626",
        }}
      >
        {allowed ? "Allowed" : "Denied"}
      </span>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Additional stories rendered via render override on the same default export
// ---------------------------------------------------------------------------

export const PermissionMatrix_Populated: GateStory = {
  name: "Permission Matrix / Populated",
  render: () => {
    return (
      <div style={{ padding: "1rem" }}>
        <MatrixDemo />
      </div>
    );
  },
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: makeFetch(MATRIX_DATA),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <Story />
        </QueryClientProvider>
      );
    },
  ],
};

export const PermissionMatrix_Loading: GateStory = {
  name: "Permission Matrix / Loading",
  render: () => (
    <div style={{ padding: "1rem" }}>
      <MatrixDemo />
    </div>
  ),
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <Story />
        </QueryClientProvider>
      );
    },
  ],
};

export const UseCanHook_AdminUser: GateStory = {
  name: "useCan Hook / AdminUser",
  render: () => (
    <div style={{ padding: "1rem" }}>
      <p
        style={{
          fontFamily: "system-ui, sans-serif",
          fontSize: "0.875rem",
          color: "#6b7280",
          marginBottom: "0.75rem",
        }}
      >
        Role: platform-admin — all actions allowed via manage:all rule.
      </p>
      <UseCanDemo />
    </div>
  ),
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: makeFetch(ADMIN_PACKED_RULES),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <Story />
        </QueryClientProvider>
      );
    },
  ],
};

export const UseCanHook_ViewerUser: GateStory = {
  name: "useCan Hook / ViewerUser",
  render: () => (
    <div style={{ padding: "1rem" }}>
      <p
        style={{
          fontFamily: "system-ui, sans-serif",
          fontSize: "0.875rem",
          color: "#6b7280",
          marginBottom: "0.75rem",
        }}
      >
        Role: viewer — only invoice.view and record.view permitted.
      </p>
      <UseCanDemo />
    </div>
  ),
  decorators: [
    (Story) => {
      configureRbacClient({
        baseUrl: "http://storybook.test/api/platform/rbac",
        fetch: makeFetch(VIEWER_PACKED_RULES),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <Story />
        </QueryClientProvider>
      );
    },
  ],
};
