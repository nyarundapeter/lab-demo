import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { configureWorkflowClient } from "@dbp/ps-workflow/client";
import type { WorkflowInstance, WorkflowStatus } from "@dbp/ps-workflow/client";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      })
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal Server Error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      })
    );
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const ACTOR_REQUESTER = {
  userId: "u1",
  roles: ["requester"],
  tenantId: "tenant-alpha",
};

const ACTOR_REVIEWER = {
  userId: "u2",
  roles: ["reviewer"],
  tenantId: "tenant-alpha",
};

const BASE_INSTANCE: WorkflowInstance = {
  workflowId: "wf-001",
  definitionId: "invoice-approval",
  definitionVersion: "1.0",
  tenantId: "tenant-alpha",
  revision: 1,
  status: "running",
  currentStep: "review",
  steps: [
    {
      stepId: "submitted",
      action: "start",
      actor: ACTOR_REQUESTER,
      ts: "2026-06-20T08:00:00.000Z",
      comment: undefined,
    },
  ],
  context: { invoiceId: "inv-001", amount: 12500 },
  createdAt: "2026-06-20T08:00:00.000Z",
  updatedAt: "2026-06-20T08:05:00.000Z",
  assignedUserId: null,
  sortOrder: null,
};

const COMPLETED_INSTANCE: WorkflowInstance = {
  ...BASE_INSTANCE,
  status: "completed",
  currentStep: null,
  steps: [
    {
      stepId: "submitted",
      action: "start",
      actor: ACTOR_REQUESTER,
      ts: "2026-06-20T08:00:00.000Z",
      comment: undefined,
    },
    {
      stepId: "review",
      action: "advance",
      actor: ACTOR_REVIEWER,
      ts: "2026-06-20T09:00:00.000Z",
      comment: "Looks good",
    },
    {
      stepId: "approved",
      action: "advance",
      actor: ACTOR_REVIEWER,
      ts: "2026-06-20T09:30:00.000Z",
      comment: undefined,
    },
  ],
  updatedAt: "2026-06-20T09:30:00.000Z",
};

const REJECTED_INSTANCE: WorkflowInstance = {
  ...BASE_INSTANCE,
  status: "rejected",
  currentStep: null,
  steps: [
    {
      stepId: "submitted",
      action: "start",
      actor: ACTOR_REQUESTER,
      ts: "2026-06-20T08:00:00.000Z",
      comment: undefined,
    },
    {
      stepId: "review",
      action: "reject",
      actor: ACTOR_REVIEWER,
      ts: "2026-06-20T09:00:00.000Z",
      comment: "Amount exceeds limit",
    },
  ],
  updatedAt: "2026-06-20T09:00:00.000Z",
};

// ---------------------------------------------------------------------------
// STATUS BADGE
// ---------------------------------------------------------------------------

const STATUS_COLORS: Record<WorkflowStatus, { bg: string; color: string }> = {
  running: { bg: "#e0f2fe", color: "#0369a1" },
  completed: { bg: "#dcfce7", color: "#15803d" },
  rejected: { bg: "#fee2e2", color: "#b91c1c" },
  cancelled: { bg: "#f1f5f9", color: "#475569" },
};

function StatusBadge({ status }: { status: WorkflowStatus }) {
   
  const { bg, color } = STATUS_COLORS[status]!;
  return (
    <span
      style={{
        background: bg,
        color,
        padding: "2px 10px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 600,
        textTransform: "uppercase",
        letterSpacing: "0.05em",
      }}
    >
      {status}
    </span>
  );
}

// ---------------------------------------------------------------------------
// WORKFLOW INSTANCE DEMO
// ---------------------------------------------------------------------------

import { useWorkflow } from "@dbp/ps-workflow/client";

interface WorkflowInstanceDemoProps {
  workflowId: string;
}

function WorkflowInstanceDemo({ workflowId }: WorkflowInstanceDemoProps) {
  const { state, steps, isLoading, error, advance, reject } = useWorkflow(workflowId);

  if (isLoading) {
    return (
      <div style={{ padding: "2rem", color: "#6b7280", fontStyle: "italic" }}>
        Loading workflow instance…
      </div>
    );
  }

  if (error) {
    return (
      <div
        style={{
          padding: "1rem",
          background: "#fee2e2",
          color: "#b91c1c",
          borderRadius: 8,
        }}
      >
        Failed to load workflow: {String(error)}
      </div>
    );
  }

  return (
    <div style={{ fontFamily: "sans-serif", maxWidth: 560 }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          marginBottom: 20,
        }}
      >
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700 }}>
          Invoice Approval — {workflowId}
        </h2>
        {state && <StatusBadge status={state} />}
      </div>

      {/* Step history */}
      <div style={{ marginBottom: 20 }}>
        <h3 style={{ fontSize: 13, fontWeight: 600, color: "#6b7280", marginBottom: 8 }}>
          STEP HISTORY
        </h3>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {steps.map((entry, idx) => {
            const isCurrent = idx === steps.length - 1 && state === "running";
            return (
              <div
                key={`${entry.stepId}-${idx}`}
                style={{
                  padding: "10px 14px",
                  background: isCurrent ? "#eff6ff" : "#f9fafb",
                  border: isCurrent ? "1.5px solid #3b82f6" : "1px solid #e5e7eb",
                  borderRadius: 8,
                  display: "flex",
                  flexDirection: "column",
                  gap: 2,
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{entry.stepId}</span>
                  <span
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color:
                        entry.action === "reject"
                          ? "#b91c1c"
                          : entry.action === "advance"
                          ? "#15803d"
                          : "#6b7280",
                    }}
                  >
                    {entry.action.toUpperCase()}
                    {isCurrent && " — current"}
                  </span>
                </div>
                <div style={{ fontSize: 12, color: "#374151" }}>
                  {entry.actor.userId}
                  {" · "}
                  {entry.actor.roles.join(", ")}
                </div>
                <div style={{ fontSize: 11, color: "#9ca3af" }}>
                  {new Date(entry.ts).toLocaleString()}
                </div>
                {entry.comment && (
                  <div
                    style={{
                      marginTop: 4,
                      fontSize: 12,
                      color: "#4b5563",
                      fontStyle: "italic",
                    }}
                  >
                    "{entry.comment}"
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Actions */}
      {state === "running" && (
        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={() => advance({ comment: "Approved via Storybook" }, "demo-session")}
            style={{
              background: "#16a34a",
              color: "#fff",
              border: "none",
              padding: "8px 18px",
              borderRadius: 6,
              cursor: "pointer",
              fontWeight: 600,
              fontSize: 14,
            }}
          >
            Advance
          </button>
          <button
            onClick={() => reject({ comment: "Rejected via Storybook" }, "demo-session")}
            style={{
              background: "#dc2626",
              color: "#fff",
              border: "none",
              padding: "8px 18px",
              borderRadius: 6,
              cursor: "pointer",
              fontWeight: 600,
              fontSize: 14,
            }}
          >
            Reject
          </button>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// META: WORKFLOW INSTANCE
// ---------------------------------------------------------------------------

const instanceMeta: Meta<typeof WorkflowInstanceDemo> = {
  title: "Layer 06 — Platform Services/PS.WORKFLOW/Workflow Instance",
  component: WorkflowInstanceDemo,
  tags: ["autodocs"],
};

export default instanceMeta;
type InstanceStory = StoryObj<typeof WorkflowInstanceDemo>;

export const Running: InstanceStory = {
  args: { workflowId: "wf-001" },
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: makeFetch(BASE_INSTANCE),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Completed: InstanceStory = {
  args: { workflowId: "wf-001" },
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: makeFetch(COMPLETED_INSTANCE),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Rejected: InstanceStory = {
  args: { workflowId: "wf-001" },
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: makeFetch(REJECTED_INSTANCE),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Loading: InstanceStory = {
  args: { workflowId: "wf-001" },
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: pendingFetch(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Error: InstanceStory = {
  args: { workflowId: "wf-001" },
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: errorFetch(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ---------------------------------------------------------------------------
// START WORKFLOW DEMO
// ---------------------------------------------------------------------------

import { useStartWorkflow } from "@dbp/ps-workflow/client";

const DEFINITION_IDS = [
  "invoice-approval",
  "onboarding-flow",
  "change-request",
  "leave-approval",
];

function StartWorkflowDemo() {
  const [definitionId, setDefinitionId] = useState(DEFINITION_IDS[0] ?? "invoice-approval");
  const [contextJson, setContextJson] = useState(
    JSON.stringify({ invoiceId: "inv-002", amount: 5000 }, null, 2)
  );
  const [jsonError, setJsonError] = useState<string | null>(null);

  const mutation = useStartWorkflow();

  function handleSubmit() {
    setJsonError(null);
    let context: Record<string, unknown> | undefined;
    if (contextJson.trim()) {
      try {
        context = JSON.parse(contextJson) as Record<string, unknown>;
      } catch {
        setJsonError("Invalid JSON in context field");
        return;
      }
    }
    mutation.mutate({ definitionId, ...(context !== undefined ? { context } : {}) });
  }

  return (
    <div style={{ fontFamily: "sans-serif", maxWidth: 480 }}>
      <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20 }}>Start Workflow</h2>

      <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 20 }}>
        <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#374151" }}>
            Definition ID
          </span>
          <select
            value={definitionId}
            onChange={(e) => setDefinitionId(e.target.value)}
            style={{
              padding: "8px 10px",
              borderRadius: 6,
              border: "1px solid #d1d5db",
              fontSize: 14,
            }}
          >
            {DEFINITION_IDS.map((id) => (
              <option key={id} value={id}>
                {id}
              </option>
            ))}
          </select>
        </label>

        <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#374151" }}>
            Context (JSON)
          </span>
          <textarea
            value={contextJson}
            onChange={(e) => setContextJson(e.target.value)}
            rows={5}
            style={{
              padding: "8px 10px",
              borderRadius: 6,
              border: jsonError ? "1.5px solid #dc2626" : "1px solid #d1d5db",
              fontSize: 13,
              fontFamily: "monospace",
              resize: "vertical",
            }}
          />
          {jsonError && (
            <span style={{ color: "#dc2626", fontSize: 12 }}>{jsonError}</span>
          )}
        </label>
      </div>

      <button
        onClick={handleSubmit}
        disabled={mutation.isPending}
        style={{
          background: mutation.isPending ? "#9ca3af" : "#030F35",
          color: "#fff",
          border: "none",
          padding: "10px 22px",
          borderRadius: 6,
          cursor: mutation.isPending ? "not-allowed" : "pointer",
          fontWeight: 600,
          fontSize: 14,
          marginBottom: 20,
        }}
      >
        {mutation.isPending ? "Starting…" : "Start Workflow"}
      </button>

      {mutation.isSuccess && mutation.data && (
        <div
          style={{
            padding: "12px 16px",
            background: "#dcfce7",
            border: "1px solid #86efac",
            borderRadius: 8,
            color: "#15803d",
          }}
        >
          <div style={{ fontWeight: 700, marginBottom: 4 }}>Workflow started</div>
          <div style={{ fontSize: 13 }}>
            ID: <code>{mutation.data.workflowId}</code>
          </div>
          <div style={{ fontSize: 13 }}>
            Definition: <code>{mutation.data.definitionId}</code>
          </div>
          <div style={{ fontSize: 13 }}>
            Status: <strong>{mutation.data.status}</strong>
          </div>
        </div>
      )}

      {mutation.isError && (
        <div
          style={{
            padding: "12px 16px",
            background: "#fee2e2",
            border: "1px solid #fca5a5",
            borderRadius: 8,
            color: "#b91c1c",
          }}
        >
          Failed to start workflow: {String(mutation.error)}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// META: START WORKFLOW
// ---------------------------------------------------------------------------

// Export as a separate file isn't possible in one module. We export the Start
// Workflow stories as named exports so Storybook autodiscovery picks them up
// via the title override on each story.

const NEW_INSTANCE: WorkflowInstance = {
  workflowId: "wf-002",
  definitionId: "invoice-approval",
  definitionVersion: "1.0",
  tenantId: "tenant-alpha",
  revision: 1,
  status: "running",
  currentStep: "review",
  steps: [
    {
      stepId: "submitted",
      action: "start",
      actor: ACTOR_REQUESTER,
      ts: "2026-06-20T10:00:00.000Z",
      comment: undefined,
    },
  ],
  context: { invoiceId: "inv-002", amount: 5000 },
  createdAt: "2026-06-20T10:00:00.000Z",
  updatedAt: "2026-06-20T10:00:00.000Z",
  sortOrder: null,
  assignedUserId: null,
};

// We need a second meta for the Start Workflow panel. Storybook supports only
// one default export per file, so we place it in the same file and rely on
// title discrimination via the story's storyName / parameters.title override.
// The canonical approach: create a wrapper component that sets parameters.title.

export const StartWorkflowIdle: StoryObj = {
  name: "Idle",
  parameters: {
    storySource: { source: "" },
    docs: { canvas: { sourceState: "none" } },
    chromatic: { disableSnapshot: false },
    // Override breadcrumb title for this story group
    title: "Layer 06 — Platform Services/PS.WORKFLOW/Start Workflow",
  },
  render: () => <StartWorkflowDemo />,
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: makeFetch(NEW_INSTANCE),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const StartWorkflowSubmitting: StoryObj = {
  name: "Submitting",
  parameters: {
    title: "Layer 06 — Platform Services/PS.WORKFLOW/Start Workflow",
  },
  render: () => {
    // Show the spinner state by triggering mutation immediately via a wrapper
    function SubmittingDemo() {
      const mutation = useStartWorkflow();
      // Kick off a pending mutation on mount via the configured pending fetch
      const [kicked, setKicked] = useState(false);
      if (!kicked) {
        setKicked(true);
        mutation.mutate({ definitionId: "invoice-approval", context: {} });
      }
      return (
        <div style={{ fontFamily: "sans-serif", maxWidth: 480 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20 }}>Start Workflow</h2>
          <button
            disabled
            style={{
              background: "#9ca3af",
              color: "#fff",
              border: "none",
              padding: "10px 22px",
              borderRadius: 6,
              cursor: "not-allowed",
              fontWeight: 600,
              fontSize: 14,
            }}
          >
            Starting…
          </button>
        </div>
      );
    }
    return <SubmittingDemo />;
  },
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: pendingFetch(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const StartWorkflowSuccess: StoryObj = {
  name: "Success",
  parameters: {
    title: "Layer 06 — Platform Services/PS.WORKFLOW/Start Workflow",
  },
  render: () => {
    function SuccessDemo() {
      return (
        <div style={{ fontFamily: "sans-serif", maxWidth: 480 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20 }}>Start Workflow</h2>
          <div
            style={{
              padding: "12px 16px",
              background: "#dcfce7",
              border: "1px solid #86efac",
              borderRadius: 8,
              color: "#15803d",
            }}
          >
            <div style={{ fontWeight: 700, marginBottom: 4 }}>Workflow started</div>
            <div style={{ fontSize: 13 }}>
              ID: <code>{NEW_INSTANCE.workflowId}</code>
            </div>
            <div style={{ fontSize: 13 }}>
              Definition: <code>{NEW_INSTANCE.definitionId}</code>
            </div>
            <div style={{ fontSize: 13 }}>
              Status: <strong>{NEW_INSTANCE.status}</strong>
            </div>
          </div>
        </div>
      );
    }
    return <SuccessDemo />;
  },
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: makeFetch(NEW_INSTANCE),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const StartWorkflowEmpty: StoryObj = {
  name: "Empty",
  parameters: {
    title: "Layer 06 — Platform Services/PS.WORKFLOW/Start Workflow",
  },
  render: () => {
    function EmptyDemo() {
      return (
        <div style={{ fontFamily: "sans-serif", maxWidth: 480 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20 }}>Start Workflow</h2>
          <div
            style={{
              padding: "24px",
              background: "#f9fafb",
              border: "1px dashed #d1d5db",
              borderRadius: 8,
              color: "#9ca3af",
              textAlign: "center",
              fontSize: 14,
            }}
          >
            No workflow definitions available.
          </div>
        </div>
      );
    }
    return <EmptyDemo />;
  },
  decorators: [
    (Story) => {
      configureWorkflowClient({
        baseUrl: "http://storybook.test/api/platform/workflow",
        fetch: makeFetch({ definitions: [] }),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};
