import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureAuthClient, useSessionIdentity } from "@dbp/ps-auth/client";
import type { AuthStatus, SessionIdentity } from "@dbp/ps-auth/client";
import { MicrosoftSignInButton } from "../../components/microsoft-sign-in-button.js";

// ---------------------------------------------------------------------------
// Fake fetch helpers
// ---------------------------------------------------------------------------

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: { code: "SERVER_ERROR", message: "Internal server error" } }), {
        status: 500,
        headers: { "content-type": "application/json" },
      }),
    );
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const SESSION_QUERY_KEY = ["dbp", "ps-auth", "session"] as const;

const mockUser = {
  id: "u-001",
  email: "admin@alpha.dev.local",
  displayName: "Platform Admin",
  roles: ["platform-admin", "solution-author"],
  tenantId: "tenant-alpha",
};

const mockSessionData = { session: { userId: "u-001", tenantId: "tenant-alpha" }, user: mockUser };

// ---------------------------------------------------------------------------
// SessionIdentityDemo component
// ---------------------------------------------------------------------------

function FieldRow({ label, value }: { label: string; value: string | React.ReactNode }) {
  return (
    <div
      style={{
        display: "flex",
        gap: "1rem",
        padding: "0.5rem 0",
        borderBottom: "1px solid var(--color-border, #e5e7eb)",
      }}
    >
      <span
        style={{
          minWidth: "140px",
          fontSize: "0.75rem",
          fontWeight: 600,
          textTransform: "uppercase",
          letterSpacing: "0.05em",
          color: "var(--color-text-secondary, #6b7280)",
        }}
      >
        {label}
      </span>
      <span style={{ fontSize: "0.875rem", color: "var(--color-text-primary, #111827)" }}>{value}</span>
    </div>
  );
}

function RoleBadge({ role }: { role: string }) {
  return (
    <span
      style={{
        display: "inline-block",
        padding: "0.125rem 0.5rem",
        borderRadius: "9999px",
        fontSize: "0.75rem",
        fontWeight: 500,
        backgroundColor: "var(--color-brand-navy, #030F35)",
        color: "#fff",
        marginRight: "0.375rem",
      }}
    >
      {role}
    </span>
  );
}

function SessionIdentityDemo() {
  const { identity, status } = useSessionIdentity();

  if (status === "loading") {
    return (
      <div
        style={{
          padding: "1.5rem",
          borderRadius: "8px",
          border: "1px solid var(--color-border, #e5e7eb)",
          color: "var(--color-text-secondary, #6b7280)",
          fontSize: "0.875rem",
        }}
      >
        Loading session identity…
      </div>
    );
  }

  if (status === "unauthenticated" || identity === null) {
    return (
      <div
        style={{
          padding: "1.5rem",
          borderRadius: "8px",
          border: "1px solid #fcd34d",
          backgroundColor: "#fffbeb",
          color: "#92400e",
          fontSize: "0.875rem",
        }}
      >
        No authenticated session — identity unavailable.
      </div>
    );
  }

  return (
    <div
      style={{
        maxWidth: "480px",
        borderRadius: "8px",
        border: "1px solid var(--color-border, #e5e7eb)",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          padding: "0.75rem 1rem",
          backgroundColor: "var(--color-brand-navy, #030F35)",
          color: "#fff",
          fontSize: "0.875rem",
          fontWeight: 600,
          display: "flex",
          alignItems: "center",
          gap: "0.5rem",
        }}
      >
        <span
          style={{
            width: "32px",
            height: "32px",
            borderRadius: "50%",
            backgroundColor: "var(--color-brand-orange, #FB5535)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "0.75rem",
            fontWeight: 700,
          }}
        >
          {identity.displayName
            .split(" ")
            .map((n) => n[0])
            .join("")
            .slice(0, 2)}
        </span>
        <div>
          <div>{identity.displayName}</div>
          <div style={{ fontSize: "0.7rem", fontWeight: 400, opacity: 0.75 }}>{identity.primaryRole}</div>
        </div>
      </div>
      <div style={{ padding: "0.5rem 1rem 1rem" }}>
        <FieldRow label="User ID" value={identity.userId} />
        <FieldRow label="Email" value={identity.email} />
        <FieldRow label="Display Name" value={identity.displayName} />
        <FieldRow label="Primary Role" value={identity.primaryRole} />
        <FieldRow label="Tenant ID" value={identity.tenantId} />
        <FieldRow
          label="All Roles"
          value={
            identity.roles.length > 0 ? (
              <span>{identity.roles.map((r) => <RoleBadge key={r} role={r} />)}</span>
            ) : (
              <em style={{ color: "var(--color-text-secondary, #6b7280)" }}>none</em>
            )
          }
        />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Meta — Session Identity
// ---------------------------------------------------------------------------

const sessionIdentityMeta: Meta<typeof SessionIdentityDemo> = {
  title: "Layer 06 — Platform Services/PS.AUTH/Session Identity",
  component: SessionIdentityDemo,
  tags: ["autodocs"],
};

export default sessionIdentityMeta;

type Story = StoryObj<typeof SessionIdentityDemo>;

export const Authenticated: Story = {
  decorators: [
    (StoryFn) => {
      configureAuthClient({
        baseUrl: "http://storybook.test/api/platform/auth",
        fetch: makeFetch(mockSessionData),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      qc.setQueryData(SESSION_QUERY_KEY, mockSessionData);
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <StoryFn />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Loading: Story = {
  decorators: [
    (StoryFn) => {
      configureAuthClient({
        baseUrl: "http://storybook.test/api/platform/auth",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      // No setQueryData — query stays in pending/loading state
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <StoryFn />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Unauthenticated: Story = {
  decorators: [
    (StoryFn) => {
      configureAuthClient({
        baseUrl: "http://storybook.test/api/platform/auth",
        fetch: makeFetch({ session: null, user: null }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      qc.setQueryData(SESSION_QUERY_KEY, { session: null, user: null });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <StoryFn />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ---------------------------------------------------------------------------
// AuthStatusBadge component
// ---------------------------------------------------------------------------

interface AuthStatusBadgeProps {
  status: AuthStatus;
  identity: SessionIdentity | null;
}

const STATUS_STYLES: Record<AuthStatus, { bg: string; color: string; label: string }> = {
  authenticated: { bg: "#d1fae5", color: "#065f46", label: "Authenticated" },
  unauthenticated: { bg: "#fef3c7", color: "#92400e", label: "Unauthenticated" },
  loading: { bg: "#f3f4f6", color: "#4b5563", label: "Loading…" },
};

function AuthStatusBadge({ status, identity }: AuthStatusBadgeProps) {
  const style = STATUS_STYLES[status];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem", maxWidth: "360px" }}>
      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: "0.5rem",
          padding: "0.375rem 0.875rem",
          borderRadius: "9999px",
          backgroundColor: style.bg,
          color: style.color,
          fontWeight: 600,
          fontSize: "0.875rem",
          width: "fit-content",
        }}
      >
        <span
          style={{
            width: "8px",
            height: "8px",
            borderRadius: "50%",
            backgroundColor: style.color,
          }}
        />
        {style.label}
      </div>

      {identity !== null && (
        <div
          style={{
            padding: "0.875rem 1rem",
            borderRadius: "8px",
            border: "1px solid var(--color-border, #e5e7eb)",
            fontSize: "0.8125rem",
            lineHeight: 1.6,
          }}
        >
          <div>
            <strong>{identity.displayName}</strong>
          </div>
          <div style={{ color: "var(--color-text-secondary, #6b7280)" }}>{identity.email}</div>
          <div style={{ color: "var(--color-text-secondary, #6b7280)" }}>{identity.primaryRole}</div>
          <div style={{ marginTop: "0.375rem", color: "var(--color-text-secondary, #6b7280)", fontSize: "0.75rem" }}>
            Tenant: <code>{identity.tenantId}</code>
          </div>
        </div>
      )}
    </div>
  );
}

function AuthStatusDemo() {
  const { identity, status } = useSessionIdentity();
  return <AuthStatusBadge status={status} identity={identity} />;
}

// ---------------------------------------------------------------------------
// We export Auth Status stories as a separate named export file would normally
// be a separate file, but the instructions ask for both in one file.
// Re-export with a sub-path title via a second Meta is not supported by SB in
// a single default export — so we use a wrapper component with the correct
// title declared in the exported story objects via the `parameters` override.
// ---------------------------------------------------------------------------

export const AuthStatusAuthenticated: Story = {
  name: "Authenticated",
  parameters: {
    storybook: {
      title: "Layer 06 — Platform Services/PS.AUTH/Auth Status",
    },
    docs: { description: { story: "Auth Status badge — authenticated state (green)." } },
  },
  render: () => <AuthStatusDemo />,
  decorators: [
    (StoryFn) => {
      configureAuthClient({
        baseUrl: "http://storybook.test/api/platform/auth",
        fetch: makeFetch(mockSessionData),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      qc.setQueryData(SESSION_QUERY_KEY, mockSessionData);
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <StoryFn />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const AuthStatusUnauthenticated: Story = {
  name: "Unauthenticated",
  parameters: {
    docs: { description: { story: "Auth Status badge — unauthenticated state (amber)." } },
  },
  render: () => <AuthStatusDemo />,
  decorators: [
    (StoryFn) => {
      configureAuthClient({
        baseUrl: "http://storybook.test/api/platform/auth",
        fetch: makeFetch({ session: null, user: null }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      qc.setQueryData(SESSION_QUERY_KEY, { session: null, user: null });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <StoryFn />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const AuthStatusLoading: Story = {
  name: "Loading",
  parameters: {
    docs: { description: { story: "Auth Status badge — loading state (grey)." } },
  },
  render: () => <AuthStatusDemo />,
  decorators: [
    (StoryFn) => {
      configureAuthClient({
        baseUrl: "http://storybook.test/api/platform/auth",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <StoryFn />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Empty: Story = {
  name: "Empty (No Roles)",
  parameters: {
    docs: { description: { story: "Session identity with no roles assigned." } },
  },
  decorators: [
    (StoryFn) => {
      const noRolesData = {
        session: { userId: "u-002", tenantId: "tenant-beta" },
        user: {
          id: "u-002",
          email: "guest@beta.dev.local",
          displayName: "Guest User",
          roles: [] as string[],
          tenantId: "tenant-beta",
        },
      };
      configureAuthClient({
        baseUrl: "http://storybook.test/api/platform/auth",
        fetch: makeFetch(noRolesData),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      qc.setQueryData(SESSION_QUERY_KEY, noRolesData);
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <StoryFn />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Error: Story = {
  name: "Error",
  parameters: {
    docs: { description: { story: "Session fetch returns a 500 — identity unavailable." } },
  },
  decorators: [
    (StoryFn) => {
      configureAuthClient({
        baseUrl: "http://storybook.test/api/platform/auth",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <StoryFn />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ---------------------------------------------------------------------------
// Provider Selection — shows the login UI branching introduced in feat/auth-adapters
// ---------------------------------------------------------------------------

type ProviderKind = "password" | "ldap" | "entra" | "entra-external";

interface ProviderSelectionDemoProps {
  provider: ProviderKind;
}

function ProviderSelectionDemo({ provider }: ProviderSelectionDemoProps) {
  const isFederated = provider === "entra" || provider === "entra-external";

  const providerLabel: Record<ProviderKind, string> = {
    password: "password (dev in-memory)",
    ldap: "ldap (on-prem Active Directory)",
    entra: "entra (Entra ID workforce)",
    "entra-external": "entra-external (Entra External ID / CIAM)",
  };

  return (
    <div style={{ maxWidth: "400px", padding: "1.5rem", border: "1px solid var(--color-border, #e5e7eb)", borderRadius: "8px", display: "flex", flexDirection: "column", gap: "1rem" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
        <span style={{ fontSize: "0.7rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", color: "var(--color-text-secondary, #6b7280)" }}>
          DBP_IDP_PROVIDER
        </span>
        <code style={{ fontSize: "0.75rem", padding: "0.125rem 0.375rem", borderRadius: "4px", backgroundColor: "var(--color-surface-secondary, #f3f4f6)" }}>
          {providerLabel[provider]}
        </code>
      </div>

      {isFederated ? (
        <MicrosoftSignInButton
          authorizeUrl="#"
          label={provider === "entra-external" ? "Sign in with your Microsoft account" : "Sign in with Microsoft"}
        />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
          <input
            type="email"
            placeholder="your@email.example"
            disabled
            style={{ padding: "0.5rem 0.75rem", borderRadius: "6px", border: "1px solid var(--color-border, #e5e7eb)", fontSize: "0.875rem", color: "var(--color-text-secondary, #6b7280)", backgroundColor: "#f9fafb" }}
          />
          <input
            type="password"
            placeholder="••••••••"
            disabled
            style={{ padding: "0.5rem 0.75rem", borderRadius: "6px", border: "1px solid var(--color-border, #e5e7eb)", fontSize: "0.875rem", color: "var(--color-text-secondary, #6b7280)", backgroundColor: "#f9fafb" }}
          />
          <button
            disabled
            style={{ padding: "0.5rem 1rem", borderRadius: "6px", backgroundColor: "var(--color-primary, #030F35)", color: "#fff", fontSize: "0.875rem", fontWeight: 600, opacity: 0.7 }}
          >
            Sign in
          </button>
          {provider === "ldap" && (
            <p style={{ fontSize: "0.75rem", color: "var(--color-text-secondary, #6b7280)", margin: 0 }}>
              Credentials are validated against on-prem AD via LDAP bind.
            </p>
          )}
        </div>
      )}
    </div>
  );
}

// We need a second default export workaround — Storybook only supports one per file.
// Export additional stories as named exports under the session-identity meta.
// The provider selection stories live in a separate logical group via `name` parameter.

type ProviderStory = StoryObj<ProviderSelectionDemoProps>;

export const ProviderPassword: ProviderStory = {
  name: "Provider — password (dev)",
  render: (args) => <ProviderSelectionDemo {...args} />,
  args: { provider: "password" },
  parameters: {
    docs: { description: { story: "Default dev mode — in-memory password form. No external IdP required." } },
  },
};

export const ProviderLdap: ProviderStory = {
  name: "Provider — ldap (on-prem AD)",
  render: (args) => <ProviderSelectionDemo {...args} />,
  args: { provider: "ldap" },
  parameters: {
    docs: { description: { story: "On-prem Active Directory via LDAP. Uses the password form; credentials are verified via service-account bind + user re-bind." } },
  },
};

export const ProviderEntra: ProviderStory = {
  name: "Provider — entra (workforce)",
  render: (args) => <ProviderSelectionDemo {...args} />,
  args: { provider: "entra" },
  parameters: {
    docs: { description: { story: "Microsoft Entra ID workforce SSO. Renders MicrosoftSignInButton which redirects to /api/platform/auth/authorize → Microsoft OIDC." } },
  },
};

export const ProviderEntraExternal: ProviderStory = {
  name: "Provider — entra-external (CIAM)",
  render: (args) => <ProviderSelectionDemo {...args} />,
  args: { provider: "entra-external" },
  parameters: {
    docs: { description: { story: "Microsoft Entra External ID (CIAM) for consumer/partner identities. Uses ciamlogin.com authority and sub claim (not oid)." } },
  },
};
