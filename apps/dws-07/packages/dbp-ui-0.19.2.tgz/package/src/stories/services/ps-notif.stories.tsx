import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureNotifClient } from "@dbp/ps-notif/client";
import { useNotifications, useSend, useSendEmail } from "@dbp/ps-notif/client";
import type { Notification, NotificationsResponse } from "@dbp/ps-notif/client";
import React, { useState } from "react";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      })
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise<Response>(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal server error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      })
    );
}

// ---------------------------------------------------------------------------
// Sample data
// ---------------------------------------------------------------------------

const NOTIF_UNREAD: Notification[] = [
  {
    id: "11111111-1111-1111-1111-111111111111",
    to: "user@example.com",
    type: "ALERT",
    message: "Your workflow approval is pending review.",
    link: "https://example.com/workflows/42",
    channel: "in-app",
    status: "unread",
    ts: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    tenantId: "tenant-alpha",
  },
  {
    id: "22222222-2222-2222-2222-222222222222",
    to: "user@example.com",
    type: "INFO",
    message: "Platform maintenance scheduled for Sunday 02:00 UTC.",
    channel: "in-app",
    status: "unread",
    ts: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    tenantId: "tenant-alpha",
  },
  {
    id: "33333333-3333-3333-3333-333333333333",
    to: "user@example.com",
    type: "SUCCESS",
    message: "Report export completed successfully.",
    link: "https://example.com/reports/export/7",
    channel: "in-app",
    status: "read",
    ts: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    tenantId: "tenant-alpha",
  },
];

const FEED_UNREAD: NotificationsResponse = { items: NOTIF_UNREAD, unread: 2 };
const FEED_ALL_READ: NotificationsResponse = {
  items: NOTIF_UNREAD.map((n) => ({ ...n, status: "read" as const })),
  unread: 0,
};
const FEED_EMPTY: NotificationsResponse = { items: [], unread: 0 };

// ---------------------------------------------------------------------------
// NotificationFeedDemo
// ---------------------------------------------------------------------------

const TYPE_COLORS: Record<string, string> = {
  ALERT: "#dc2626",
  INFO: "#2563eb",
  SUCCESS: "#16a34a",
};

function TypeBadge({ type }: { type: string }) {
  const bg = TYPE_COLORS[type] ?? "#6b7280";
  return (
    <span
      style={{
        display: "inline-block",
        padding: "2px 8px",
        borderRadius: 4,
        background: bg,
        color: "#fff",
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: "0.04em",
        textTransform: "uppercase",
      }}
    >
      {type}
    </span>
  );
}

function formatTs(ts: string): string {
  const d = new Date(ts);
  const diffMs = Date.now() - d.getTime();
  const diffMin = Math.round(diffMs / 60000);
  if (diffMin < 1) return "just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffH = Math.round(diffMin / 60);
  if (diffH < 24) return `${diffH}h ago`;
  return d.toLocaleDateString();
}

function NotificationFeedDemo() {
  const { items, unread, markAllRead, isLoading, error } = useNotifications();

  if (isLoading) {
    return (
      <div style={{ padding: 24, color: "#6b7280" }}>Loading notifications…</div>
    );
  }
  if (error) {
    return (
      <div style={{ padding: 24, color: "#dc2626" }}>
        Error: {error.message}
      </div>
    );
  }

  return (
    <div
      style={{
        width: 380,
        border: "1px solid #e5e7eb",
        borderRadius: 8,
        overflow: "hidden",
        fontFamily: "system-ui, sans-serif",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "12px 16px",
          background: "#f9fafb",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <span style={{ fontWeight: 700, fontSize: 14 }}>
          Notifications{" "}
          {unread > 0 && (
            <span
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                width: 20,
                height: 20,
                borderRadius: "50%",
                background: "#dc2626",
                color: "#fff",
                fontSize: 11,
                fontWeight: 700,
                marginLeft: 6,
              }}
            >
              {unread}
            </span>
          )}
        </span>
        {unread > 0 && (
          <button
            onClick={() => markAllRead()}
            style={{
              fontSize: 12,
              color: "#2563eb",
              background: "none",
              border: "none",
              cursor: "pointer",
              padding: 0,
            }}
          >
            Mark all read
          </button>
        )}
      </div>

      {/* List */}
      {items.length === 0 ? (
        <div style={{ padding: 32, textAlign: "center", color: "#9ca3af", fontSize: 14 }}>
          No notifications
        </div>
      ) : (
        <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
          {items.map((n) => (
            <li
              key={n.id}
              style={{
                display: "flex",
                gap: 12,
                padding: "12px 16px",
                background: n.status === "unread" ? "#eff6ff" : "#fff",
                borderBottom: "1px solid #e5e7eb",
                alignItems: "flex-start",
              }}
            >
              {/* Unread dot */}
              <div style={{ paddingTop: 4, flexShrink: 0 }}>
                <div
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    background: n.status === "unread" ? "#2563eb" : "transparent",
                    border: n.status === "unread" ? "none" : "1px solid #d1d5db",
                  }}
                />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                  <TypeBadge type={n.type} />
                  <span style={{ fontSize: 11, color: "#9ca3af", marginLeft: "auto" }}>
                    {formatTs(n.ts)}
                  </span>
                </div>
                <p style={{ margin: 0, fontSize: 13, color: "#111827", lineHeight: 1.4 }}>
                  {n.message}
                </p>
                {n.link && (
                  <a
                    href={n.link}
                    style={{ fontSize: 12, color: "#2563eb", textDecoration: "none", display: "inline-block", marginTop: 4 }}
                  >
                    View &rarr;
                  </a>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Stories: Notification Feed
// ---------------------------------------------------------------------------

const feedMeta: Meta<typeof NotificationFeedDemo> = {
  title: "Layer 06 — Platform Services/PS.NOTIF/Notification Feed",
  component: NotificationFeedDemo,
  tags: ["autodocs"],
};

export default feedMeta;

type FeedStory = StoryObj<typeof NotificationFeedDemo>;

export const WithUnread: FeedStory = {
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: makeFetch(FEED_UNREAD),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const AllRead: FeedStory = {
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: makeFetch(FEED_ALL_READ),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Empty: FeedStory = {
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: makeFetch(FEED_EMPTY),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Loading: FeedStory = {
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Error: FeedStory = {
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ---------------------------------------------------------------------------
// SendDemo
// ---------------------------------------------------------------------------

type SendChannel = "in-app" | "email" | "sms";

function SendDemo() {
  const { send: doSend, isPending, error } = useSend();
  const [to, setTo] = useState("user@example.com");
  const [type, setType] = useState("INFO");
  const [message, setMessage] = useState("Hello from Storybook.");
  const [channel, setChannel] = useState<SendChannel>("in-app");
  const [sentId, setSentId] = useState<string | null>(null);

  const inputStyle: React.CSSProperties = {
    display: "block",
    width: "100%",
    padding: "6px 10px",
    border: "1px solid #d1d5db",
    borderRadius: 6,
    fontSize: 13,
    boxSizing: "border-box",
  };
  const labelStyle: React.CSSProperties = {
    display: "block",
    fontSize: 12,
    fontWeight: 600,
    marginBottom: 4,
    color: "#374151",
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSentId(null);
    doSend(
      { to, type, message, channel },
    );
  };

  return (
    <div
      style={{
        width: 360,
        border: "1px solid #e5e7eb",
        borderRadius: 8,
        padding: 20,
        fontFamily: "system-ui, sans-serif",
      }}
    >
      <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 700 }}>
        Send Notification
      </h3>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div>
          <label style={labelStyle}>To</label>
          <input
            style={inputStyle}
            value={to}
            onChange={(e) => setTo(e.target.value)}
            required
          />
        </div>
        <div>
          <label style={labelStyle}>Type</label>
          <input
            style={inputStyle}
            value={type}
            onChange={(e) => setType(e.target.value)}
            required
          />
        </div>
        <div>
          <label style={labelStyle}>Message</label>
          <textarea
            style={{ ...inputStyle, resize: "vertical", minHeight: 64 }}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            required
          />
        </div>
        <div>
          <label style={labelStyle}>Channel</label>
          <select
            style={inputStyle}
            value={channel}
            onChange={(e) => setChannel(e.target.value as SendChannel)}
          >
            <option value="in-app">In-App</option>
            <option value="email">Email</option>
            <option value="sms">SMS</option>
          </select>
        </div>
        <button
          type="submit"
          disabled={isPending}
          style={{
            padding: "8px 16px",
            background: isPending ? "#9ca3af" : "#030F35",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            fontSize: 13,
            fontWeight: 600,
            cursor: isPending ? "not-allowed" : "pointer",
          }}
        >
          {isPending ? "Sending…" : "Send Notification"}
        </button>
      </form>
      {sentId && (
        <div
          style={{
            marginTop: 12,
            padding: "8px 12px",
            background: "#f0fdf4",
            border: "1px solid #bbf7d0",
            borderRadius: 6,
            fontSize: 13,
            color: "#15803d",
          }}
        >
          Sent — ID: {sentId}
        </div>
      )}
      {error && (
        <div
          style={{
            marginTop: 12,
            padding: "8px 12px",
            background: "#fef2f2",
            border: "1px solid #fecaca",
            borderRadius: 6,
            fontSize: 13,
            color: "#dc2626",
          }}
        >
          Error: {error.message}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Stories: Send Notification
// ---------------------------------------------------------------------------

export const sendMeta: Meta<typeof SendDemo> = {
  title: "Layer 06 — Platform Services/PS.NOTIF/Send Notification",
  component: SendDemo,
  tags: ["autodocs"],
};

type SendStory = StoryObj<typeof SendDemo>;

const SENT_RESPONSE: Notification = {
  id: "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  to: "user@example.com",
  type: "INFO",
  message: "Hello from Storybook.",
  channel: "in-app",
  status: "unread",
  ts: new Date().toISOString(),
  tenantId: "tenant-alpha",
};

export const Idle: SendStory = {
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: makeFetch(SENT_RESPONSE),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Submitting: SendStory = {
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Sent: SendStory = {
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: makeFetch(SENT_RESPONSE),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const SendError: SendStory = {
  name: "Error",
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ---------------------------------------------------------------------------
// SendEmailDemo
// ---------------------------------------------------------------------------

function SendEmailDemo() {
  const { sendEmail: doSendEmail, isPending, error } = useSendEmail();
  const [to, setTo] = useState("recipient@example.com");
  const [subject, setSubject] = useState("Platform Update");
  const [body, setBody] = useState("Hello,\n\nThis is a platform notification.\n\nRegards,\nThe Platform");
  const [sent, setSent] = useState(false);

  const inputStyle: React.CSSProperties = {
    display: "block",
    width: "100%",
    padding: "6px 10px",
    border: "1px solid #d1d5db",
    borderRadius: 6,
    fontSize: 13,
    boxSizing: "border-box",
  };
  const labelStyle: React.CSSProperties = {
    display: "block",
    fontSize: 12,
    fontWeight: 600,
    marginBottom: 4,
    color: "#374151",
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(false);
    doSendEmail({ to, subject, text: body });
    setSent(true);
  };

  return (
    <div
      style={{
        width: 400,
        border: "1px solid #e5e7eb",
        borderRadius: 8,
        padding: 20,
        fontFamily: "system-ui, sans-serif",
      }}
    >
      <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 700 }}>
        Send Email
      </h3>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div>
          <label style={labelStyle}>To</label>
          <input
            style={inputStyle}
            type="email"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            required
          />
        </div>
        <div>
          <label style={labelStyle}>Subject</label>
          <input
            style={inputStyle}
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            required
          />
        </div>
        <div>
          <label style={labelStyle}>Body</label>
          <textarea
            style={{ ...inputStyle, resize: "vertical", minHeight: 100 }}
            value={body}
            onChange={(e) => setBody(e.target.value)}
            required
          />
        </div>
        <button
          type="submit"
          disabled={isPending}
          style={{
            padding: "8px 16px",
            background: isPending ? "#9ca3af" : "#030F35",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            fontSize: 13,
            fontWeight: 600,
            cursor: isPending ? "not-allowed" : "pointer",
          }}
        >
          {isPending ? "Sending…" : "Send Email"}
        </button>
      </form>
      {sent && !error && (
        <div
          style={{
            marginTop: 12,
            padding: "8px 12px",
            background: "#f0fdf4",
            border: "1px solid #bbf7d0",
            borderRadius: 6,
            fontSize: 13,
            color: "#15803d",
          }}
        >
          Email sent successfully.
        </div>
      )}
      {error && (
        <div
          style={{
            marginTop: 12,
            padding: "8px 12px",
            background: "#fef2f2",
            border: "1px solid #fecaca",
            borderRadius: 6,
            fontSize: 13,
            color: "#dc2626",
          }}
        >
          Error: {error.message}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Stories: Send Email
// ---------------------------------------------------------------------------

export const emailMeta: Meta<typeof SendEmailDemo> = {
  title: "Layer 06 — Platform Services/PS.NOTIF/Send Email",
  component: SendEmailDemo,
  tags: ["autodocs"],
};

type EmailStory = StoryObj<typeof SendEmailDemo>;

export const EmailIdle: EmailStory = {
  name: "Idle",
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: makeFetch({ ok: true }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const EmailSent: EmailStory = {
  name: "Sent",
  decorators: [
    (Story) => {
      configureNotifClient({
        baseUrl: "http://storybook.test/api/platform/notif",
        fetch: makeFetch({ ok: true }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};
