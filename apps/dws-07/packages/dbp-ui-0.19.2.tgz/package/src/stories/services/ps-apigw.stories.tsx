import React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  configureApigwClient,
  listRoutes,
  getGatewayConfig,
  type GatewayRoute,
  type GatewayConfig,
} from "@dbp/ps-apigw/client";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function toMessage(err: unknown): string {
  if (err !== null && typeof err === "object" && "message" in err && typeof (err as { message: unknown }).message === "string") {
    return (err as { message: string }).message;
  }
  return "Unknown error";
}

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      })
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal server error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      })
    );
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const MOCK_ROUTES: GatewayRoute[] = [
  {
    path: "/api/platform/auth",
    service: "ps-auth",
    auth: "none",
    rateLimit: null,
    methods: ["GET", "POST"],
  },
  {
    path: "/api/platform/data",
    service: "ps-data",
    auth: "session",
    rateLimit: { windowSeconds: 60, maxRequests: 1000 },
    methods: ["GET", "POST", "PATCH", "DELETE"],
  },
  {
    path: "/api/platform/workflow",
    service: "ps-workflow",
    auth: "session",
    rateLimit: { windowSeconds: 60, maxRequests: 200 },
    methods: ["GET", "POST"],
  },
  {
    path: "/api/platform/notif",
    service: "ps-notif",
    auth: "session",
    rateLimit: null,
    methods: ["GET", "POST"],
  },
  {
    path: "/api/platform/ai",
    service: "ps-ai",
    auth: "session",
    rateLimit: { windowSeconds: 60, maxRequests: 100 },
    methods: ["GET", "POST"],
  },
];

const MOCK_CONFIG: GatewayConfig = {
  version: "1.0.0",
  routes: MOCK_ROUTES,
};

// ---------------------------------------------------------------------------
// Route Registry Demo
// ---------------------------------------------------------------------------

type RouteState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "success"; routes: GatewayRoute[] };

function RouteRegistryDemo() {
  const [state, setState] = React.useState<RouteState>({ status: "loading" });

  React.useEffect(() => {
    let cancelled = false;
    listRoutes()
      .then((res) => {
        if (!cancelled) setState({ status: "success", routes: res });
      })
      .catch((err: unknown) => {
        if (!cancelled)
          setState({
            status: "error",
            message: toMessage(err),
          });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (state.status === "loading") {
    return (
      <p style={{ color: "var(--color-fg-muted, #6b7280)", fontFamily: "sans-serif" }}>
        Loading routes…
      </p>
    );
  }

  if (state.status === "error") {
    return (
      <p style={{ color: "var(--color-danger, #dc2626)", fontFamily: "sans-serif" }}>
        Error: {state.message}
      </p>
    );
  }

  if (state.routes.length === 0) {
    return (
      <p style={{ color: "var(--color-fg-muted, #6b7280)", fontFamily: "sans-serif" }}>
        No routes registered.
      </p>
    );
  }

  return (
    <div style={{ fontFamily: "sans-serif" }}>
      <h3 style={{ marginBottom: "0.75rem", fontSize: "0.875rem", fontWeight: 600 }}>
        Route Registry ({state.routes.length} routes)
      </h3>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          fontSize: "0.8125rem",
        }}
      >
        <thead>
          <tr style={{ background: "var(--color-surface-raised, #f3f4f6)" }}>
            {["Path", "Service", "Auth mode", "Methods", "Rate limit"].map((h) => (
              <th
                key={h}
                style={{
                  textAlign: "left",
                  padding: "0.5rem 0.75rem",
                  fontWeight: 600,
                  borderBottom: "1px solid var(--color-border, #e5e7eb)",
                }}
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {state.routes.map((route) => (
            <tr
              key={route.path}
              style={{ borderBottom: "1px solid var(--color-border, #e5e7eb)" }}
            >
              <td style={{ padding: "0.5rem 0.75rem", fontFamily: "monospace", fontSize: "0.8rem" }}>
                {route.path}
              </td>
              <td style={{ padding: "0.5rem 0.75rem" }}>{route.service}</td>
              <td style={{ padding: "0.5rem 0.75rem" }}>
                <span
                  style={{
                    display: "inline-block",
                    padding: "0.125rem 0.5rem",
                    borderRadius: "9999px",
                    fontSize: "0.75rem",
                    fontWeight: 500,
                    background:
                      route.auth === "none"
                        ? "var(--color-warning-subtle, #fef3c7)"
                        : "var(--color-success-subtle, #dcfce7)",
                    color:
                      route.auth === "none"
                        ? "var(--color-warning, #92400e)"
                        : "var(--color-success, #166534)",
                  }}
                >
                  {route.auth}
                </span>
              </td>
              <td style={{ padding: "0.5rem 0.75rem", fontFamily: "monospace", fontSize: "0.75rem" }}>
                {route.methods.join(", ")}
              </td>
              <td style={{ padding: "0.5rem 0.75rem" }}>
                {route.rateLimit
                  ? `${route.rateLimit.maxRequests} req / ${route.rateLimit.windowSeconds}s`
                  : "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Route Registry Meta + Stories
// ---------------------------------------------------------------------------

const routeMeta: Meta<typeof RouteRegistryDemo> = {
  title: "Layer 06 — Platform Services/PS.APIGW/Route Registry",
  component: RouteRegistryDemo,
  tags: ["autodocs"],
};

export default routeMeta;

type RouteStory = StoryObj<typeof RouteRegistryDemo>;

export const Populated: RouteStory = {
  decorators: [
    (Story) => {
      configureApigwClient({
        baseUrl: "http://storybook.test/api/platform/apigw",
        fetch: makeFetch({ routes: MOCK_ROUTES }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Loading: RouteStory = {
  decorators: [
    (Story) => {
      configureApigwClient({
        baseUrl: "http://storybook.test/api/platform/apigw",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Empty: RouteStory = {
  decorators: [
    (Story) => {
      configureApigwClient({
        baseUrl: "http://storybook.test/api/platform/apigw",
        fetch: makeFetch({ routes: [] }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Error: RouteStory = {
  decorators: [
    (Story) => {
      configureApigwClient({
        baseUrl: "http://storybook.test/api/platform/apigw",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ---------------------------------------------------------------------------
// Gateway Config Demo
// ---------------------------------------------------------------------------

type ConfigState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "success"; config: GatewayConfig };

function GatewayConfigDemo() {
  const [state, setState] = React.useState<ConfigState>({ status: "loading" });

  React.useEffect(() => {
    let cancelled = false;
    getGatewayConfig()
      .then((config) => {
        if (!cancelled) setState({ status: "success", config });
      })
      .catch((err: unknown) => {
        if (!cancelled)
          setState({
            status: "error",
            message: toMessage(err),
          });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (state.status === "loading") {
    return (
      <p style={{ color: "var(--color-fg-muted, #6b7280)", fontFamily: "sans-serif" }}>
        Loading config…
      </p>
    );
  }

  if (state.status === "error") {
    return (
      <p style={{ color: "var(--color-danger, #dc2626)", fontFamily: "sans-serif" }}>
        Error: {state.message}
      </p>
    );
  }

  const { config } = state;

  return (
    <div
      style={{
        fontFamily: "sans-serif",
        border: "1px solid var(--color-border, #e5e7eb)",
        borderRadius: "0.5rem",
        padding: "1.25rem",
        maxWidth: "360px",
        background: "var(--color-surface, #ffffff)",
      }}
    >
      <h3 style={{ margin: "0 0 0.75rem", fontSize: "0.9375rem", fontWeight: 600 }}>
        API Gateway
      </h3>
      <dl style={{ margin: 0, display: "grid", gridTemplateColumns: "auto 1fr", gap: "0.375rem 1rem" }}>
        <dt style={{ color: "var(--color-fg-muted, #6b7280)", fontSize: "0.8125rem" }}>Version</dt>
        <dd style={{ margin: 0, fontFamily: "monospace", fontSize: "0.8125rem" }}>{config.version}</dd>
        <dt style={{ color: "var(--color-fg-muted, #6b7280)", fontSize: "0.8125rem" }}>Routes</dt>
        <dd style={{ margin: 0, fontSize: "0.8125rem" }}>{config.routes.length} registered</dd>
        <dt style={{ color: "var(--color-fg-muted, #6b7280)", fontSize: "0.8125rem" }}>Auth-required</dt>
        <dd style={{ margin: 0, fontSize: "0.8125rem" }}>
          {config.routes.filter((r) => r.auth !== "none").length} routes
        </dd>
        <dt style={{ color: "var(--color-fg-muted, #6b7280)", fontSize: "0.8125rem" }}>Rate-limited</dt>
        <dd style={{ margin: 0, fontSize: "0.8125rem" }}>
          {config.routes.filter((r) => r.rateLimit !== null).length} routes
        </dd>
      </dl>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Gateway Config Meta + Stories
// ---------------------------------------------------------------------------
// NOTE: Storybook requires each file to have exactly one default export (Meta).
// The Route Registry meta is the file's default export above.
// The Gateway Config stories are exported as named exports with a suffix to
// distinguish them; they use the component directly with a different title via
// the storyName property.

export const GatewayConfigPopulated: RouteStory & { storyName?: string } = {
  storyName: "Gateway Config — Populated",
  render: () => <GatewayConfigDemo />,
  decorators: [
    (Story) => {
      configureApigwClient({
        baseUrl: "http://storybook.test/api/platform/apigw",
        fetch: makeFetch(MOCK_CONFIG),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const GatewayConfigLoading: RouteStory & { storyName?: string } = {
  storyName: "Gateway Config — Loading",
  render: () => <GatewayConfigDemo />,
  decorators: [
    (Story) => {
      configureApigwClient({
        baseUrl: "http://storybook.test/api/platform/apigw",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const GatewayConfigError: RouteStory & { storyName?: string } = {
  storyName: "Gateway Config — Error",
  render: () => <GatewayConfigDemo />,
  decorators: [
    (Story) => {
      configureApigwClient({
        baseUrl: "http://storybook.test/api/platform/apigw",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};
