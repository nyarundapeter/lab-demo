import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { configureSearchClient } from "@dbp/ps-search/client";
import { useSearch, useIndex } from "@dbp/ps-search/client";
import type { SearchHit } from "@dbp/ps-search/client";

// ---------------------------------------------------------------------------
// Fetch helpers
// ---------------------------------------------------------------------------

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise<Response>(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal Server Error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      }),
    );
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const MOCK_RESULTS = {
  results: [
    {
      id: "inv-001",
      entityType: "invoice",
      title: "Invoice #INV-2024-001",
      score: 0.98,
      highlights: { title: "Invoice #INV-2024-001", body: "Due amount: $4,500" },
    },
    {
      id: "inv-002",
      entityType: "invoice",
      title: "Invoice #INV-2024-002",
      score: 0.87,
      highlights: { title: "Invoice #INV-2024-002", body: "Overdue invoice for consulting services" },
    },
    {
      id: "inv-003",
      entityType: "invoice",
      title: "Invoice #INV-2024-003",
      score: 0.76,
      highlights: { body: "Invoice rejected — missing PO reference" },
    },
    {
      id: "inv-004",
      entityType: "payment",
      title: "Payment for Invoice #INV-2024-001",
      score: 0.65,
      highlights: { body: "Invoice settled via bank transfer" },
    },
  ],
  facets: [
    { field: "entityType", values: [{ value: "invoice", count: 3 }, { value: "payment", count: 1 }] },
  ],
  total: 4,
};

const EMPTY_RESULTS = { results: [], facets: [], total: 0 };

// ---------------------------------------------------------------------------
// Story 1: Search Results
// ---------------------------------------------------------------------------

function SearchResultsDemo({ query }: { query: string }) {
  const [input, setInput] = useState(query);
  const [submitted, setSubmitted] = useState(query);
  const { results, loading, total } = useSearch(submitted);

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", maxWidth: 600 }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && setSubmitted(input)}
          placeholder="Search…"
          style={{
            flex: 1,
            padding: "8px 12px",
            border: "1px solid #d1d5db",
            borderRadius: 6,
            fontSize: 14,
          }}
        />
        <button
          onClick={() => setSubmitted(input)}
          style={{
            padding: "8px 16px",
            background: "#030F35",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            cursor: "pointer",
            fontSize: 14,
          }}
        >
          Search
        </button>
      </div>

      {loading && (
        <p style={{ color: "#6b7280", fontSize: 14 }}>Searching…</p>
      )}

      {!loading && submitted && total === 0 && (
        <p style={{ color: "#6b7280", fontSize: 14 }}>No results for "{submitted}"</p>
      )}

      {!loading && total > 0 && (
        <>
          <p style={{ fontSize: 13, color: "#6b7280", marginBottom: 12 }}>
            {total} result{total !== 1 ? "s" : ""} for "{submitted}"
          </p>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 10 }}>
            {results.map((hit: SearchHit) => (
              <li
                key={hit.id}
                style={{
                  border: "1px solid #e5e7eb",
                  borderRadius: 8,
                  padding: "12px 16px",
                  background: "#fff",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                  <span
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      background: "#EEF2FF",
                      color: "#4338CA",
                      borderRadius: 4,
                      padding: "2px 6px",
                      textTransform: "uppercase",
                      letterSpacing: "0.05em",
                    }}
                  >
                    {hit.entityType}
                  </span>
                  <span style={{ fontSize: 12, color: "#9ca3af", marginLeft: "auto" }}>
                    score {hit.score.toFixed(2)}
                  </span>
                </div>
                <p style={{ margin: "0 0 4px", fontWeight: 600, fontSize: 14, color: "#111827" }}>
                  {hit.title}
                </p>
                {hit.highlights && (
                  <p style={{ margin: 0, fontSize: 13, color: "#6b7280" }}>
                    {Object.values(hit.highlights)[0]}
                  </p>
                )}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

const searchMeta: Meta<typeof SearchResultsDemo> = {
  title: "Layer 06 — Platform Services/PS.SEARCH/Search Results",
  component: SearchResultsDemo,
  tags: ["autodocs"],
};
export default searchMeta;

type SearchStory = StoryObj<typeof SearchResultsDemo>;

export const WithResults: SearchStory = {
  args: { query: "invoice" },
  decorators: [
    (Story) => {
      configureSearchClient({
        baseUrl: "http://storybook.test/api/platform/search",
        fetch: makeFetch(MOCK_RESULTS),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Loading: SearchStory = {
  args: { query: "invoice" },
  decorators: [
    (Story) => {
      configureSearchClient({
        baseUrl: "http://storybook.test/api/platform/search",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const NoResults: SearchStory = {
  args: { query: "xyzzy" },
  decorators: [
    (Story) => {
      configureSearchClient({
        baseUrl: "http://storybook.test/api/platform/search",
        fetch: makeFetch(EMPTY_RESULTS),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Error: SearchStory = {
  args: { query: "invoice" },
  decorators: [
    (Story) => {
      configureSearchClient({
        baseUrl: "http://storybook.test/api/platform/search",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ---------------------------------------------------------------------------
// Story 2: Index Operations — separate file would be ideal but placed here
// per task instructions (single file output).
// We export a second default-like set via named re-export trick by using
// a component-level meta in a separate "virtual story" section.
// Storybook supports multiple components in one file via named exports only
// when the title is the same; for different titles we need separate files.
// Since task asks for one file, we embed IndexDemo stories with a wrapper
// approach: compose them as named exports under the same meta and note the
// title difference via storyName.
// ---------------------------------------------------------------------------

interface IndexedDoc {
  entityType: string;
  id: string;
  title: string;
  status: "idle" | "indexed" | "removed";
  count: number;
}

function IndexDemo({ initialStatus }: { initialStatus: "idle" | "indexed" | "removed" }) {
  const [entityType, setEntityType] = useState("invoice");
  const [docId, setDocId] = useState("inv-999");
  const [docTitle, setDocTitle] = useState("Invoice #INV-999");
  const [state, setState] = useState<IndexedDoc>({
    entityType: "invoice",
    id: "inv-999",
    title: "Invoice #INV-999",
    status: initialStatus,
    count: initialStatus === "indexed" ? 1 : 0,
  });

  const indexMutation = useIndex();

  const handleIndex = async () => {
    await indexMutation.mutateAsync({
      entityType,
      doc: { id: docId, title: docTitle, fields: {} },
    });
    setState((s) => ({ ...s, entityType, id: docId, title: docTitle, status: "indexed", count: s.count + 1 }));
  };

  const handleRemove = async () => {
    await indexMutation.mutateAsync({
      entityType: state.entityType,
      doc: { id: state.id, title: state.title, fields: {} },
    });
    setState((s) => ({ ...s, status: "removed", count: Math.max(0, s.count - 1) }));
  };

  const statusColor: Record<string, string> = {
    idle: "#6b7280",
    indexed: "#059669",
    removed: "#dc2626",
  };

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", maxWidth: 540 }}>
      <div
        style={{
          background: "#f9fafb",
          border: "1px solid #e5e7eb",
          borderRadius: 10,
          padding: "16px 20px",
          marginBottom: 16,
        }}
      >
        <p style={{ margin: "0 0 12px", fontWeight: 600, fontSize: 14, color: "#111827" }}>
          Index a Document
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <input
            value={entityType}
            onChange={(e) => setEntityType(e.target.value)}
            placeholder="Entity type (e.g. invoice)"
            style={{ padding: "7px 10px", border: "1px solid #d1d5db", borderRadius: 6, fontSize: 13 }}
          />
          <input
            value={docId}
            onChange={(e) => setDocId(e.target.value)}
            placeholder="Document ID"
            style={{ padding: "7px 10px", border: "1px solid #d1d5db", borderRadius: 6, fontSize: 13 }}
          />
          <input
            value={docTitle}
            onChange={(e) => setDocTitle(e.target.value)}
            placeholder="Title"
            style={{ padding: "7px 10px", border: "1px solid #d1d5db", borderRadius: 6, fontSize: 13 }}
          />
          <button
            onClick={() => void handleIndex()}
            disabled={indexMutation.isPending}
            style={{
              padding: "8px 14px",
              background: "#030F35",
              color: "#fff",
              border: "none",
              borderRadius: 6,
              cursor: "pointer",
              fontSize: 13,
              fontWeight: 600,
              alignSelf: "flex-start",
            }}
          >
            {indexMutation.isPending ? "Indexing…" : "Index Document"}
          </button>
        </div>
      </div>

      <div
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 10,
          padding: "16px 20px",
          background: "#fff",
          marginBottom: 16,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <p style={{ margin: "0 0 2px", fontWeight: 600, fontSize: 14, color: "#111827" }}>
              {state.title}
            </p>
            <p style={{ margin: 0, fontSize: 12, color: "#6b7280" }}>
              {state.entityType} / {state.id}
            </p>
          </div>
          <span
            style={{
              fontSize: 12,
              fontWeight: 600,
              color: statusColor[state.status],
              textTransform: "capitalize",
            }}
          >
            {state.status}
          </span>
        </div>
        {state.status === "indexed" && (
          <button
            onClick={() => void handleRemove()}
            disabled={indexMutation.isPending}
            style={{
              marginTop: 12,
              padding: "6px 12px",
              background: "#fee2e2",
              color: "#dc2626",
              border: "none",
              borderRadius: 6,
              cursor: "pointer",
              fontSize: 12,
              fontWeight: 600,
            }}
          >
            Remove from Index
          </button>
        )}
      </div>

      <div
        style={{
          background: "#f0fdf4",
          border: "1px solid #bbf7d0",
          borderRadius: 8,
          padding: "10px 14px",
          fontSize: 13,
          color: "#166534",
        }}
      >
        Indexed document count: <strong>{state.count}</strong>
      </div>
    </div>
  );
}

// We export these as named exports with storyName to differentiate the title
// within the same meta. A proper separate file per-title is recommended in
// production; this fulfils the task's single-file constraint.

export const IndexIdle: StoryObj<typeof IndexDemo> = {
  name: "Layer 06 — Platform Services/PS.SEARCH/Index Operations — Idle",
  render: () => <IndexDemo initialStatus="idle" />,
  decorators: [
    (Story) => {
      configureSearchClient({
        baseUrl: "http://storybook.test/api/platform/search",
        fetch: makeFetch({ ok: true }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Indexed: StoryObj<typeof IndexDemo> = {
  name: "Layer 06 — Platform Services/PS.SEARCH/Index Operations — Indexed",
  render: () => <IndexDemo initialStatus="indexed" />,
  decorators: [
    (Story) => {
      configureSearchClient({
        baseUrl: "http://storybook.test/api/platform/search",
        fetch: makeFetch({ ok: true }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Removed: StoryObj<typeof IndexDemo> = {
  name: "Layer 06 — Platform Services/PS.SEARCH/Index Operations — Removed",
  render: () => <IndexDemo initialStatus="removed" />,
  decorators: [
    (Story) => {
      configureSearchClient({
        baseUrl: "http://storybook.test/api/platform/search",
        fetch: makeFetch({ ok: true }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};
