/**
 * PS.AI — Platform AI Service stories
 * Covers: RAG Search, Recommendations, Assistant (SSE)
 */
import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { configureAiClient, useRagSearch, useRecommend, useAssistant } from "@dbp/ps-ai/client";
import type { RagResult, Recommendation, ChatMessage } from "@dbp/ps-ai/client";

// ---------------------------------------------------------------------------
// Fetch helpers
// ---------------------------------------------------------------------------

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise<Response>(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal server error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      }),
    );
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const MOCK_RAG_RESULTS: RagResult[] = [
  {
    id: "doc-001",
    scope: "finance",
    title: "Invoice Approval Process — Standard SOP",
    snippet:
      "The invoice approval process begins when a supplier submits an invoice. Finance reviews the document, matches it against the PO, and routes it to the approver.",
    score: 0.97,
  },
  {
    id: "doc-002",
    scope: "finance",
    title: "Three-Way Match Policy",
    snippet:
      "All invoices above AED 10,000 must pass a three-way match: purchase order, goods receipt, and invoice. Discrepancies trigger an exception workflow.",
    score: 0.88,
  },
  {
    id: "doc-003",
    scope: "operations",
    title: "Delegated Authority Matrix",
    snippet:
      "Approval authorities by spend tier: up to AED 5k — team lead; up to AED 50k — department head; above AED 50k — CFO sign-off required.",
    score: 0.74,
  },
];

const MOCK_RECOMMENDATIONS: Recommendation[] = [
  {
    id: "rec-001",
    label: "Review pending invoices",
    reason: "You have 4 invoices awaiting approval that are approaching their SLA deadline.",
    score: 0.95,
  },
  {
    id: "rec-002",
    label: "Complete your timesheet",
    reason: "Week-ending timesheets are due today. You have not submitted for this period.",
    score: 0.89,
  },
  {
    id: "rec-003",
    label: "Acknowledge updated leave policy",
    reason: "HR published a revised annual leave policy. Acknowledgement is required by all staff.",
    score: 0.76,
  },
];

const MOCK_CONVERSATION: ChatMessage[] = [
  { role: "user", content: "What are the open tasks?" },
  {
    role: "assistant",
    content:
      "There are 5 open tasks assigned to you: Task A, Task B, Task C, Task D, Task E.",
  },
];

// ---------------------------------------------------------------------------
// Demo components
// ---------------------------------------------------------------------------

function RagSearchDemo({ query }: { query: string }) {
  const [input, setInput] = useState(query);
  const [activeQuery, setActiveQuery] = useState(query);
  const { results, isLoading, error } = useRagSearch(activeQuery);

  return (
    <div style={{ fontFamily: "inherit", maxWidth: 600 }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Search knowledge base…"
          style={{
            flex: 1,
            padding: "8px 12px",
            border: "1px solid #d1d5db",
            borderRadius: 6,
            fontSize: 14,
          }}
        />
        <button
          onClick={() => setActiveQuery(input)}
          style={{
            padding: "8px 16px",
            background: "#030F35",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            cursor: "pointer",
            fontSize: 14,
          }}
        >
          Search
        </button>
      </div>

      {isLoading && <p style={{ color: "#6b7280", fontSize: 14 }}>Searching…</p>}

      {error && (
        <p style={{ color: "#dc2626", fontSize: 14 }}>Error: {error.message}</p>
      )}

      {!isLoading && !error && results.length === 0 && activeQuery.length > 0 && (
        <p style={{ color: "#6b7280", fontSize: 14 }}>
          No results found for &ldquo;{activeQuery}&rdquo;.
        </p>
      )}

      {results.map((r) => (
        <div
          key={r.id}
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 8,
            padding: "12px 16px",
            marginBottom: 10,
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              marginBottom: 4,
            }}
          >
            <strong style={{ fontSize: 14, color: "#111827" }}>{r.title}</strong>
            <span
              style={{
                fontSize: 11,
                background: "#f0fdf4",
                color: "#15803d",
                border: "1px solid #bbf7d0",
                borderRadius: 4,
                padding: "2px 6px",
                marginLeft: 8,
                whiteSpace: "nowrap",
              }}
            >
              {Math.round(r.score * 100)}% match
            </span>
          </div>
          <p style={{ fontSize: 13, color: "#6b7280", margin: 0 }}>{r.snippet}</p>
          <span style={{ fontSize: 11, color: "#9ca3af", marginTop: 4, display: "block" }}>
            Scope: {r.scope}
          </span>
        </div>
      ))}
    </div>
  );
}

function RecommendationsDemo({ entity }: { entity: string }) {
  const { recommendations, isLoading, error } = useRecommend(entity);

  if (isLoading) {
    return <p style={{ color: "#6b7280", fontSize: 14 }}>Loading recommendations…</p>;
  }

  if (error) {
    return (
      <p style={{ color: "#dc2626", fontSize: 14 }}>Error: {error.message}</p>
    );
  }

  if (recommendations.length === 0) {
    return (
      <p style={{ color: "#6b7280", fontSize: 14 }}>
        No recommendations available at this time.
      </p>
    );
  }

  return (
    <div style={{ fontFamily: "inherit", maxWidth: 520 }}>
      <h3 style={{ fontSize: 14, fontWeight: 600, color: "#374151", marginBottom: 12 }}>
        AI Recommendations
      </h3>
      {recommendations.map((rec) => (
        <div
          key={rec.id}
          style={{
            display: "flex",
            gap: 12,
            alignItems: "flex-start",
            border: "1px solid #e5e7eb",
            borderRadius: 8,
            padding: "12px 14px",
            marginBottom: 8,
          }}
        >
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: "50%",
              background: "#fff7ed",
              border: "1px solid #fed7aa",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              fontSize: 16,
            }}
          >
            ★
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 500, color: "#111827", marginBottom: 2 }}>
              {rec.label}
            </div>
            <div style={{ fontSize: 13, color: "#6b7280" }}>{rec.reason}</div>
          </div>
          <span
            style={{
              fontSize: 11,
              color: "#6b7280",
              whiteSpace: "nowrap",
              alignSelf: "center",
            }}
          >
            {Math.round(rec.score * 100)}%
          </span>
        </div>
      ))}
    </div>
  );
}

function AssistantDemo({ prefillMessages }: { prefillMessages: ChatMessage[] }) {
  const { messages, streaming, ask } = useAssistant();
  const [input, setInput] = useState("");

  // Show prefilled messages when no live messages exist yet (story default state).
  const displayMessages =
    prefillMessages.length > 0 && messages.length === 0 ? prefillMessages : messages;

  const handleSend = () => {
    const trimmed = input.trim();
    if (trimmed) {
      void ask(trimmed);
      setInput("");
    }
  };

  return (
    <div
      style={{
        fontFamily: "inherit",
        maxWidth: 560,
        border: "1px solid #e5e7eb",
        borderRadius: 10,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          background: "#030F35",
          color: "#fff",
          padding: "10px 16px",
          fontSize: 13,
          fontWeight: 600,
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <span>AI Assistant</span>
        {streaming && (
          <span style={{ fontSize: 11, color: "#fb5535", marginLeft: "auto" }}>
            Streaming…
          </span>
        )}
      </div>

      <div
        style={{
          minHeight: 180,
          padding: "16px",
          background: "#f9fafb",
          display: "flex",
          flexDirection: "column",
          gap: 10,
        }}
      >
        {displayMessages.length === 0 && (
          <p
            style={{
              color: "#9ca3af",
              fontSize: 13,
              textAlign: "center",
              margin: "auto",
            }}
          >
            Start a conversation…
          </p>
        )}
        {displayMessages.map((msg, i) => (
          <div
            key={i}
            style={{
              alignSelf: msg.role === "user" ? "flex-end" : "flex-start",
              maxWidth: "80%",
              background: msg.role === "user" ? "#030F35" : "#fff",
              color: msg.role === "user" ? "#fff" : "#111827",
              border: msg.role === "user" ? "none" : "1px solid #e5e7eb",
              borderRadius: 8,
              padding: "8px 12px",
              fontSize: 13,
            }}
          >
            {msg.content}
          </div>
        ))}
      </div>

      <div
        style={{
          display: "flex",
          gap: 8,
          padding: "10px 12px",
          borderTop: "1px solid #e5e7eb",
          background: "#fff",
        }}
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask something…"
          style={{
            flex: 1,
            padding: "7px 10px",
            border: "1px solid #d1d5db",
            borderRadius: 6,
            fontSize: 13,
          }}
        />
        <button
          onClick={handleSend}
          disabled={streaming}
          style={{
            padding: "7px 14px",
            background: "#FB5535",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            cursor: "pointer",
            fontSize: 13,
            opacity: streaming ? 0.6 : 1,
          }}
        >
          Send
        </button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Wrapper components for Meta typing
// ---------------------------------------------------------------------------

type RagSearchProps = { query: string; _variant: "WithResults" | "Loading" | "NoResults" | "Error" };
type RecommendationsProps = { entity: string; _variant: "WithRecommendations" | "Loading" | "Empty" };
type AssistantProps = { _variant: "WithConversation" | "Empty" };

function RagSearchStoryWrapper({ query }: RagSearchProps) {
  return <RagSearchDemo query={query} />;
}

function RecommendationsStoryWrapper({ entity }: RecommendationsProps) {
  return <RecommendationsDemo entity={entity} />;
}

function AssistantStoryWrapper({ _variant }: AssistantProps) {
  const prefill = _variant === "WithConversation" ? MOCK_CONVERSATION : [];
  return <AssistantDemo prefillMessages={prefill} />;
}

// ---------------------------------------------------------------------------
// Meta — single file, stories grouped by name prefix
// ---------------------------------------------------------------------------

const meta: Meta = {
  title: "Layer 06 — Platform Services/PS.AI",
  tags: ["autodocs"],
  parameters: { layout: "padded" },
};

export default meta;

// ── RAG Search ──────────────────────────────────────────────────────────────

export const RagSearch_WithResults: StoryObj = {
  name: "RAG Search/With Results",
  render: () => <RagSearchStoryWrapper query="invoice approval process" _variant="WithResults" />,
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: makeFetch({ results: MOCK_RAG_RESULTS }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const RagSearch_Loading: StoryObj = {
  name: "RAG Search/Loading",
  render: () => <RagSearchStoryWrapper query="invoice approval process" _variant="Loading" />,
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const RagSearch_NoResults: StoryObj = {
  name: "RAG Search/No Results",
  render: () => <RagSearchStoryWrapper query="xyzzy not found anywhere" _variant="NoResults" />,
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: makeFetch({ results: [] }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const RagSearch_Error: StoryObj = {
  name: "RAG Search/Error",
  render: () => <RagSearchStoryWrapper query="invoice approval process" _variant="Error" />,
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: errorFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ── Recommendations ──────────────────────────────────────────────────────────

export const Recommendations_WithRecommendations: StoryObj = {
  name: "Recommendations/With Recommendations",
  render: () => (
    <RecommendationsStoryWrapper entity="user-dashboard" _variant="WithRecommendations" />
  ),
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: makeFetch({ recommendations: MOCK_RECOMMENDATIONS }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Recommendations_Loading: StoryObj = {
  name: "Recommendations/Loading",
  render: () => <RecommendationsStoryWrapper entity="user-dashboard" _variant="Loading" />,
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Recommendations_Empty: StoryObj = {
  name: "Recommendations/Empty",
  render: () => <RecommendationsStoryWrapper entity="user-dashboard" _variant="Empty" />,
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: makeFetch({ recommendations: [] }),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

// ── Assistant (SSE) ──────────────────────────────────────────────────────────

export const Assistant_WithConversation: StoryObj = {
  name: "Assistant (SSE)/With Conversation",
  render: () => <AssistantStoryWrapper _variant="WithConversation" />,
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Assistant_Empty: StoryObj = {
  name: "Assistant (SSE)/Empty",
  render: () => <AssistantStoryWrapper _variant="Empty" />,
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: "http://storybook.test/api/platform/ai",
        fetch: pendingFetch(),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};
