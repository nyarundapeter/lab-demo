import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import React, { useState } from "react";
import {
  configureAuditClient,
  useActivityFeed,
  logEvent,
  type AuditEvent,
} from "@dbp/ps-audit/client";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function toMessage(err: unknown): string {
  if (err !== null && typeof err === "object" && "message" in err && typeof (err as { message: unknown }).message === "string") {
    return (err as { message: string }).message;
  }
  return "Unknown error";
}

function makeFetch(data: unknown): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify(data), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

function pendingFetch(): () => Promise<Response> {
  return () => new Promise<Response>(() => {});
}

function errorFetch(): () => Promise<Response> {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ error: "Internal Server Error" }), {
        status: 500,
        headers: { "content-type": "application/json" },
      }),
    );
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const MOCK_EVENTS: AuditEvent[] = [
  {
    id: "e1000000-0000-0000-0000-000000000001",
    ts: "2026-06-20T08:00:00.000Z",
    actor: {
      userId: "u-001",
      email: "alice@example.com",
      displayName: "Alice Nguyen",
    },
    action: "entity.create",
    target: { entityType: "Project", entityId: "demo-entity-001" },
    delta: null,
    tenantId: "tenant-alpha",
  },
  {
    id: "e2000000-0000-0000-0000-000000000002",
    ts: "2026-06-20T09:15:00.000Z",
    actor: {
      userId: "u-002",
      email: "bob@example.com",
      displayName: "Bob Kaur",
    },
    action: "record.update",
    target: { entityType: "Project", entityId: "demo-entity-001" },
    delta: {
      status: { from: "draft", to: "in-progress" },
      priority: { from: "low", to: "high" },
    },
    tenantId: "tenant-alpha",
  },
  {
    id: "e3000000-0000-0000-0000-000000000003",
    ts: "2026-06-20T11:00:00.000Z",
    actor: {
      userId: "u-003",
      email: "carol@example.com",
      displayName: "Carol Hassan",
    },
    action: "invoice.approve",
    target: { entityType: "Invoice", entityId: "inv-0042" },
    delta: null,
    tenantId: "tenant-alpha",
  },
  {
    id: "e4000000-0000-0000-0000-000000000004",
    ts: "2026-06-20T13:30:00.000Z",
    actor: {
      userId: "u-001",
      email: "alice@example.com",
      displayName: "Alice Nguyen",
    },
    action: "user.login",
    target: { entityType: "Session", entityId: "sess-9999" },
    delta: null,
    tenantId: "tenant-alpha",
  },
];

const FEED_RESPONSE = { events: MOCK_EVENTS, nextCursor: null };
const EMPTY_FEED = { events: [], nextCursor: null };

// ---------------------------------------------------------------------------
// Helper: format delta
// ---------------------------------------------------------------------------

function formatDelta(delta: AuditEvent["delta"]): string {
  if (!delta) return "—";
  return Object.entries(delta)
    .map(([field, change]) => {
      const c = change as { from: unknown; to: unknown };
      return `${field}: ${String(c.from)} → ${String(c.to)}`;
    })
    .join("; ");
}

// ---------------------------------------------------------------------------
// AuditEventLogDemo
// ---------------------------------------------------------------------------

function AuditEventLogDemo() {
  const { events, isLoading, error } = useActivityFeed("demo-entity-001");

  if (isLoading) {
    return (
      <div style={{ padding: "2rem", color: "var(--color-text-subtle, #6b7280)" }}>
        Loading audit events…
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ padding: "2rem", color: "var(--color-danger, #dc2626)" }}>
        Error: {error.message}
      </div>
    );
  }

  if (events.length === 0) {
    return (
      <div style={{ padding: "2rem", color: "var(--color-text-subtle, #6b7280)" }}>
        No audit events found.
      </div>
    );
  }

  return (
    <div style={{ fontFamily: "inherit", overflowX: "auto" }}>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          fontSize: "0.875rem",
        }}
      >
        <thead>
          <tr
            style={{
              background: "var(--color-surface-raised, #f9fafb)",
              textAlign: "left",
            }}
          >
            {["Timestamp", "Actor", "Action", "Target", "Delta Summary"].map(
              (h) => (
                <th
                  key={h}
                  style={{
                    padding: "0.5rem 0.75rem",
                    borderBottom: "1px solid var(--color-border, #e5e7eb)",
                    fontWeight: 600,
                    whiteSpace: "nowrap",
                  }}
                >
                  {h}
                </th>
              ),
            )}
          </tr>
        </thead>
        <tbody>
          {events.map((ev, idx) => (
            <tr
              key={ev.id}
              style={{
                background: idx % 2 === 0 ? "transparent" : "var(--color-surface-raised, #f9fafb)",
              }}
            >
              <td style={{ padding: "0.5rem 0.75rem", whiteSpace: "nowrap" }}>
                {new Date(ev.ts).toLocaleString()}
              </td>
              <td style={{ padding: "0.5rem 0.75rem", whiteSpace: "nowrap" }}>
                <div style={{ fontWeight: 500 }}>{ev.actor.displayName}</div>
                <div style={{ fontSize: "0.75rem", color: "var(--color-text-subtle, #6b7280)" }}>
                  {ev.actor.email}
                </div>
              </td>
              <td style={{ padding: "0.5rem 0.75rem" }}>
                <code
                  style={{
                    background: "var(--color-surface-code, #f3f4f6)",
                    padding: "0.1rem 0.3rem",
                    borderRadius: "0.25rem",
                    fontSize: "0.8rem",
                  }}
                >
                  {ev.action}
                </code>
              </td>
              <td style={{ padding: "0.5rem 0.75rem", whiteSpace: "nowrap" }}>
                <span style={{ fontWeight: 500 }}>{ev.target.entityType}</span>
                <span
                  style={{
                    marginLeft: "0.25rem",
                    fontSize: "0.75rem",
                    color: "var(--color-text-subtle, #6b7280)",
                  }}
                >
                  {ev.target.entityId}
                </span>
              </td>
              <td
                style={{
                  padding: "0.5rem 0.75rem",
                  fontSize: "0.8rem",
                  color: ev.delta
                    ? "var(--color-text, inherit)"
                    : "var(--color-text-subtle, #6b7280)",
                }}
              >
                {formatDelta(ev.delta)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Meta — Audit Event Log
// ---------------------------------------------------------------------------

const metaLog = {
  title: "Layer 06 — Platform Services/PS.AUDIT/Audit Event Log",
  tags: ["autodocs"],
} satisfies Meta;

export default metaLog;

type Story = StoryObj<typeof metaLog>;

export const WithEvents: Story = {
  name: "WithEvents",
  decorators: [
    (Story) => {
      configureAuditClient({
        baseUrl: "http://storybook.test/api/platform/audit",
        fetch: makeFetch(FEED_RESPONSE),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <AuditEventLogDemo />,
};

export const Loading: Story = {
  name: "Loading",
  decorators: [
    (Story) => {
      configureAuditClient({
        baseUrl: "http://storybook.test/api/platform/audit",
        fetch: pendingFetch(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <AuditEventLogDemo />,
};

export const Empty: Story = {
  name: "Empty",
  decorators: [
    (Story) => {
      configureAuditClient({
        baseUrl: "http://storybook.test/api/platform/audit",
        fetch: makeFetch(EMPTY_FEED),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <AuditEventLogDemo />,
};

export const Error: Story = {
  name: "Error",
  decorators: [
    (Story) => {
      configureAuditClient({
        baseUrl: "http://storybook.test/api/platform/audit",
        fetch: errorFetch(),
        tenantId: "tenant-alpha",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <AuditEventLogDemo />,
};

// ---------------------------------------------------------------------------
// LogEventDemo
// ---------------------------------------------------------------------------

type LogState = "idle" | "logging" | "logged";

const CREATED_EVENT: AuditEvent = {
  id: "e9000000-0000-0000-0000-000000000099",
  ts: new Date().toISOString(),
  actor: {
    userId: "u-demo",
    email: "demo@example.com",
    displayName: "Demo User",
  },
  action: "demo.action",
  target: { entityType: "DemoEntity", entityId: "demo-001" },
  delta: null,
  tenantId: "tenant-alpha",
};

function LogEventDemo({
  mockFetch,
}: {
  mockFetch: () => Promise<Response>;
}) {
  const [action, setAction] = useState("record.update");
  const [targetType, setTargetType] = useState("Project");
  const [targetId, setTargetId] = useState("demo-entity-001");
  const [state, setState] = useState<LogState>("idle");
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  async function handleLog() {
    setState("logging");
    setErrMsg(null);
    try {
      configureAuditClient({
        baseUrl: "http://storybook.test/api/platform/audit",
        fetch: mockFetch,
        tenantId: "tenant-alpha",
      });
      await logEvent({
        actor: {
          userId: "u-demo",
          email: "demo@example.com",
          displayName: "Demo User",
        },
        action,
        target: { entityType: targetType, entityId: targetId },
        delta: null,
      });
      setCreatedId(`evt-${Date.now().toString(36)}`);
      setState("logged");
    } catch (e) {
      setErrMsg(toMessage(e));
      setState("idle");
    }
  }

  const inputStyle: React.CSSProperties = {
    padding: "0.375rem 0.5rem",
    border: "1px solid var(--color-border, #d1d5db)",
    borderRadius: "0.375rem",
    fontSize: "0.875rem",
    width: "100%",
    boxSizing: "border-box",
  };

  const labelStyle: React.CSSProperties = {
    display: "block",
    fontSize: "0.75rem",
    fontWeight: 600,
    marginBottom: "0.25rem",
    color: "var(--color-text-subtle, #4b5563)",
  };

  return (
    <div style={{ maxWidth: 480, display: "flex", flexDirection: "column", gap: "1rem" }}>
      <h3 style={{ margin: 0, fontSize: "1rem", fontWeight: 600 }}>Log Audit Event</h3>

      <div>
        <label style={labelStyle}>Action</label>
        <input
          style={inputStyle}
          value={action}
          onChange={(e) => setAction(e.target.value)}
          placeholder="e.g. record.update"
        />
      </div>

      <div>
        <label style={labelStyle}>Target Entity Type</label>
        <input
          style={inputStyle}
          value={targetType}
          onChange={(e) => setTargetType(e.target.value)}
          placeholder="e.g. Project"
        />
      </div>

      <div>
        <label style={labelStyle}>Target Entity ID</label>
        <input
          style={inputStyle}
          value={targetId}
          onChange={(e) => setTargetId(e.target.value)}
          placeholder="e.g. demo-entity-001"
        />
      </div>

      <button
        onClick={() => void handleLog()}
        disabled={state === "logging"}
        style={{
          padding: "0.5rem 1rem",
          borderRadius: "0.375rem",
          border: "none",
          background: state === "logging"
            ? "var(--color-surface-raised, #e5e7eb)"
            : "var(--color-brand-navy, #030F35)",
          color: state === "logging" ? "var(--color-text-subtle, #6b7280)" : "#fff",
          fontWeight: 600,
          cursor: state === "logging" ? "not-allowed" : "pointer",
          fontSize: "0.875rem",
        }}
      >
        {state === "logging" ? "Logging…" : "Log Event"}
      </button>

      {state === "logged" && createdId && (
        <div
          style={{
            padding: "0.75rem",
            background: "var(--color-success-subtle, #f0fdf4)",
            border: "1px solid var(--color-success, #16a34a)",
            borderRadius: "0.375rem",
            fontSize: "0.875rem",
          }}
        >
          <strong>Event logged.</strong>
          <br />
          <span style={{ fontFamily: "monospace", fontSize: "0.8rem" }}>ID: {createdId}</span>
        </div>
      )}

      {errMsg && (
        <div
          style={{
            padding: "0.75rem",
            background: "var(--color-danger-subtle, #fef2f2)",
            border: "1px solid var(--color-danger, #dc2626)",
            borderRadius: "0.375rem",
            fontSize: "0.875rem",
            color: "var(--color-danger, #dc2626)",
          }}
        >
          {errMsg}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Meta — Log Event
// ---------------------------------------------------------------------------

export const LogEventMeta = {
  title: "Layer 06 — Platform Services/PS.AUDIT/Log Event",
  tags: ["autodocs"],
} satisfies Meta;

// We export a second meta-block by re-exporting a named stories file.
// Storybook requires one default export per file, so we place Log Event stories
// as named exports under a separate component file convention — but since the
// task requires a single file, we embed the Log Event stories inline using the
// same default export (Storybook supports a single default export per file).
// The stories below use the title override via the `parameters.docs.title`
// approach combined with `storyName`, which is the correct single-file
// multi-group workaround.

export const Idle: Story = {
  name: "Log Event / Idle",
  parameters: {
    docs: { description: { story: "Form in its initial idle state, ready to submit." } },
  },
  decorators: [
    (Story) => {
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <LogEventDemo mockFetch={makeFetch(CREATED_EVENT)} />,
};

export const Logging: Story = {
  name: "Log Event / Logging",
  parameters: {
    docs: { description: { story: "Button in disabled loading state while POST is in-flight." } },
  },
  decorators: [
    (Story) => {
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  render: () => <LogEventDemo mockFetch={pendingFetch()} />,
};

export const Logged: Story = {
  name: "Log Event / Logged",
  parameters: {
    docs: {
      description: {
        story:
          "After a successful POST the returned event ID is displayed in a success banner.",
      },
    },
  },
  decorators: [
    (Story) => {
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  // Pre-seed the "logged" state by using a wrapper that immediately shows
  // the success banner with the mocked event id.
  render: () => {
    function PreLoggedDemo() {
      const [state] = useState<LogState>("logged");
      const [createdId] = useState<string>(CREATED_EVENT.id);

      const inputStyle: React.CSSProperties = {
        padding: "0.375rem 0.5rem",
        border: "1px solid var(--color-border, #d1d5db)",
        borderRadius: "0.375rem",
        fontSize: "0.875rem",
        width: "100%",
        boxSizing: "border-box",
      };
      const labelStyle: React.CSSProperties = {
        display: "block",
        fontSize: "0.75rem",
        fontWeight: 600,
        marginBottom: "0.25rem",
        color: "var(--color-text-subtle, #4b5563)",
      };

      return (
        <div style={{ maxWidth: 480, display: "flex", flexDirection: "column", gap: "1rem" }}>
          <h3 style={{ margin: 0, fontSize: "1rem", fontWeight: 600 }}>Log Audit Event</h3>
          <div>
            <label style={labelStyle}>Action</label>
            <input style={inputStyle} defaultValue="demo.action" readOnly />
          </div>
          <div>
            <label style={labelStyle}>Target Entity Type</label>
            <input style={inputStyle} defaultValue="DemoEntity" readOnly />
          </div>
          <div>
            <label style={labelStyle}>Target Entity ID</label>
            <input style={inputStyle} defaultValue="demo-001" readOnly />
          </div>
          <button
            disabled
            style={{
              padding: "0.5rem 1rem",
              borderRadius: "0.375rem",
              border: "none",
              background: "var(--color-brand-navy, #030F35)",
              color: "#fff",
              fontWeight: 600,
              fontSize: "0.875rem",
              cursor: "default",
            }}
          >
            Log Event
          </button>
          {state === "logged" && (
            <div
              style={{
                padding: "0.75rem",
                background: "var(--color-success-subtle, #f0fdf4)",
                border: "1px solid var(--color-success, #16a34a)",
                borderRadius: "0.375rem",
                fontSize: "0.875rem",
              }}
            >
              <strong>Event logged.</strong>
              <br />
              <span style={{ fontFamily: "monospace", fontSize: "0.8rem" }}>
                ID: {createdId}
              </span>
            </div>
          )}
        </div>
      );
    }
    return <PreLoggedDemo />;
  },
};
