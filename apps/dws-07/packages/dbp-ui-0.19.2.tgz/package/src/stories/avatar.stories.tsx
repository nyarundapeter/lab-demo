import type { Meta, StoryObj } from "@storybook/react";
import { Avatar, AvatarLockup, AvatarStack } from "../components/avatar.js";

const meta: Meta = {
  title: "Layer 07 — App Scaffolds/Atoms/Indicators/Avatar",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Sizes: Story = {
  render: () => (
    <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
      <Avatar name="Alice Brown" size="sm" />
      <Avatar name="Bob Clarke" size="md" />
      <Avatar name="Carol Davies" size="lg" />
    </div>
  ),
};

export const Palette: Story = {
  name: "Deterministic color palette",
  render: () => (
    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
      {["Alice Brown", "Bob Clarke", "Carol Davies", "Dave Evans", "Eve Foster", "Frank Green"].map((n) => (
        <Avatar key={n} name={n} size="md" title={n} />
      ))}
    </div>
  ),
};

export const WithImage: Story = {
  render: () => (
    <Avatar
      name="Test User"
      size="lg"
      src="https://i.pravatar.cc/48?img=3"
    />
  ),
};

export const Lockup: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <AvatarLockup name="Ian Hargreaves" role="Senior Analyst" />
      <AvatarLockup name="Sarah Mitchell" role="Platform Admin" size="lg" />
    </div>
  ),
};

export const Presence: Story = {
  name: "Presence dot (collaboration-system/presence.jsx)",
  render: () => (
    <div style={{ display: "flex", gap: "24px", flexWrap: "wrap" }}>
      {(["online", "away", "offline"] as const).map((p) => (
        <div key={p} style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <Avatar name="Priya Nair" size="lg" presence={p} />
          <span style={{ fontSize: 13, fontWeight: 600, textTransform: "capitalize" }}>{p}</span>
        </div>
      ))}
    </div>
  ),
};

export const Stack: Story = {
  name: "AvatarStack — \"viewing now\" cluster",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
      <AvatarStack
        items={[
          { name: "Dan Whitfield", presence: "online" },
          { name: "Sofia Marchetti", presence: "away" },
          { name: "Priya Nair" },
        ]}
      />
      <AvatarStack
        items={[
          { name: "Dan Whitfield" },
          { name: "Sofia Marchetti" },
          { name: "Priya Nair" },
          { name: "Marcus Lee" },
          { name: "Owen Clarke" },
          { name: "Anita Rao" },
        ]}
        max={4}
      />
    </div>
  ),
};
