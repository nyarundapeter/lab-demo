import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ChecklistFilterMenu } from "../components/checklist-filter-menu.js";

const meta: Meta<typeof ChecklistFilterMenu> = {
  title: "Layer 07 — App Scaffolds/Molecules/Overlays/ChecklistFilterMenu",
  component: ChecklistFilterMenu,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof ChecklistFilterMenu>;

const PRIORITY_OPTIONS = [
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "critical", label: "Critical" },
];

const COLUMN_OPTIONS = [
  { value: "owner", label: "Owner" },
  { value: "priority", label: "Priority" },
  { value: "status", label: "Status" },
  { value: "sla", label: "SLA" },
];

export const QuickFilter: Story = {
  name: "Quick filter (staged, Apply/Clear)",
  render: () => {
    const [values, setValues] = React.useState<string[]>(["high"]);
    return (
      <ChecklistFilterMenu
        triggerLabel="Priority"
        options={PRIORITY_OPTIONS}
        values={values}
        onValuesChange={setValues}
        onApply={() => {}}
      />
    );
  },
};

export const ColumnConfig: Story = {
  name: "Column config (live toggle)",
  render: () => {
    const [values, setValues] = React.useState<string[]>(["owner", "priority", "status"]);
    return (
      <ChecklistFilterMenu triggerLabel="Columns" options={COLUMN_OPTIONS} values={values} onValuesChange={setValues} />
    );
  },
};
