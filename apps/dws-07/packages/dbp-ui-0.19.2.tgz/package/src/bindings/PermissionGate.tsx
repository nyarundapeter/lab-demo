import { type ReactNode } from "react";
import { Gate } from "@dbp/ps-rbac/client";

export interface PermissionGateProps {
  action: string;
  resource?: string;
  fallback?: ReactNode;
  children: ReactNode;
}

/**
 * Thin wrapper over PS.RBAC's own <Gate> component.
 * All permission logic lives in the SDK — this component only adds the
 * @dbp/ui export surface so shells/features don't import from ps-rbac directly.
 */
export function PermissionGate({ action, resource, fallback, children }: PermissionGateProps) {
  return (
    <Gate action={action} {...(resource !== undefined && { resource })} fallback={fallback}>
      {children}
    </Gate>
  );
}
