# @dbp/contracts

Zod schemas that are the single source of truth for the DBP Blueprint's cross-cutting data shapes — environment config, the organism catalogue, page vocabulary, shell nav, solution manifests, template catalogue, tenant, versioning, plus the discovery/workspace/operations domains added under ADR-0039. TypeScript types are derived via `z.infer<typeof Schema>`, never hand-authored, so solutions and platform services validate against one shared contract instead of drifting interfaces.

**Tier:** shared

## Exports
| Export | Path |
|---|---|
| `.` | `./src/index.ts` |
| `./*` | `./src/*.ts` |

No `publishConfig.exports` override — ships raw TypeScript source (no build step); consumers transpile it themselves (`transpilePackages` in tarball-installed standalones).

## Config schema
This package *is* the config schema layer — see `src/environment.ts`, `src/solution-manifest.ts`, `src/discovery/`, `src/workspace/`, `src/operations/` for the individual Zod schemas re-exported from `src/index.ts`.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` writes `"@dbp/contracts": "workspace:*"` into every generated solution's `package.json`. Also a direct dependency of `@dbp/nav-gating`, `@dbp/scaffold-tools`, and other `@dbp/*` packages that validate against its schemas.

## Shipping
Workspace package during monorepo development (`workspace:*`). For standalone repos, it ships as a committed tarball (`file:packages/dbp-contracts-0.1.2.tgz`) resolved via `.pnpmfile.cjs` — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
