# @dbp/ps-workflow

Workflow orchestration platform service. The server side (`dispatch`,
`getWorkflowService`, `server/bootstrap`) drives workflow definitions and
instance state transitions, including SLA timer scheduling via
`@dbp/ps-scheduler`; the client side (`configureWorkflowClient`,
`startWorkflow`, `advanceInstance`, `getInstance`, `getDefinition`,
`listInstances`, `registerDefinition`, `rejectInstance`, `useWorkflow`,
`useStartWorkflow`, `useWorkflowInstances`) is the sanctioned way solutions
drive approval/state-machine flows — solutions never hand-roll their own
workflow engine.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `./client/index.ts` (source) / `./dist/client/index.js` (published) |
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |
| `./server/bootstrap` | `./server/bootstrap.ts` (source) / `./dist/server/bootstrap.js` (published) |

`publishConfig.exports` splits all three entries to `dist/` with `.d.ts` types — same subpaths, built output only.

## Config schema
See `contract.yaml` (OpenAPI 3.0.3, generated via `pnpm contracts:gen` from Zod schemas re-exported from `./client`, e.g. `ActorSchema`, `AdvanceRequestSchema`, `DefinitionListResponseSchema`, `InstanceListResponseSchema`, `RejectRequestSchema` — never hand-edited).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` registers `PS.WORKFLOW` (dir `workflow`, package `@dbp/ps-workflow`, base path `/api/platform/workflow`), wires `configureWorkflowClient` from `@dbp/ps-workflow/client`, generates each app's workflow bridge route (the only place importing both `@dbp/ps-workflow/server` and `@dbp/ps-scheduler/server`), and calls `ensureWorkflowStorage` from `@dbp/ps-workflow/server/bootstrap` during app bootstrap.

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client delivery, ships as a packed `.tgz` tarball committed into the standalone's `packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
