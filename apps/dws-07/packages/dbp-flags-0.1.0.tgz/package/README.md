# @dbp/flags

Feature-flag evaluation for solution apps: a Zod schema for a solution manifest's `flags:` block (`FeatureFlagEntrySchema`/`FeatureFlagsBlockSchema`), a pure evaluator (`evaluateFlags`/`isFlagEnabled`), a React context/provider (`FeatureFlagsProvider`), a `useFeatureFlag` hook, and a `FeatureGate` component for conditionally rendering UI. React is an optional peer dependency — the schema/evaluator work standalone (e.g. server-side), the React pieces are only needed when gating UI.

**Tier:** shared

## Exports
| Export | Path |
|---|---|
| `.` | `./src/index.ts` |
| `./server` | `./src/server.ts` |

No `publishConfig.exports` override — ships raw TypeScript source.

## Config schema
`src/schema.ts` — `FeatureFlagEntrySchema` and `FeatureFlagsBlockSchema` (Zod), re-exported from `src/index.ts`.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` emits `import { FeatureFlagsProvider } from "@dbp/flags";`, `import { useFeatureFlag } from "@dbp/flags";`, and `import { FeatureGate } from "@dbp/flags";` into generated app code when a solution manifest declares a `flags:` block.

## Shipping
Workspace package during monorepo development (`workspace:*`). For standalone repos, it ships as a committed tarball (`file:packages/dbp-flags-0.1.0.tgz`) resolved via `.pnpmfile.cjs` — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
