import { describe, expect, it } from "vitest";
import { evaluateFlags, isFlagEnabled } from "./evaluate.js";

const defaults = {
  "APP.F01": true,
  "APP.F21": false,
  "MARKETPLACE": true,
};

describe("evaluateFlags", () => {
  it("returns manifest defaults when no env overrides", () => {
    const result = evaluateFlags(defaults, {});
    expect(result).toEqual({ "APP.F01": true, "APP.F21": false, "MARKETPLACE": true });
  });

  it("env override true enables a manifest-disabled flag", () => {
    const result = evaluateFlags(defaults, { "APP.F21": true });
    expect(result["APP.F21"]).toBe(true);
  });

  it("env override false disables a manifest-enabled flag", () => {
    const result = evaluateFlags(defaults, { "APP.F01": false });
    expect(result["APP.F01"]).toBe(false);
  });

  it("env override undefined leaves manifest default unchanged", () => {
    const result = evaluateFlags(defaults, { "APP.F01": undefined });
    expect(result["APP.F01"]).toBe(true);
  });

  it("only overrides the specified flags, others use defaults", () => {
    const result = evaluateFlags(defaults, { "APP.F21": true });
    expect(result["APP.F01"]).toBe(true);
    expect(result["MARKETPLACE"]).toBe(true);
  });

  it("returns empty map for empty defaults", () => {
    expect(evaluateFlags({}, {})).toEqual({});
  });

  it("does not include unknown keys from overrides", () => {
    const result = evaluateFlags(defaults, { "UNKNOWN": true } as Record<string, boolean | undefined>);
    expect("UNKNOWN" in result).toBe(false);
  });
});

describe("isFlagEnabled", () => {
  const resolved = evaluateFlags(defaults, {});

  it("returns true for an enabled flag", () => {
    expect(isFlagEnabled(resolved, "APP.F01")).toBe(true);
  });

  it("returns false for a disabled flag", () => {
    expect(isFlagEnabled(resolved, "APP.F21")).toBe(false);
  });

  it("returns false for unknown flag (deny-by-default)", () => {
    expect(isFlagEnabled(resolved, "NONEXISTENT")).toBe(false);
  });
});
