import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { FeatureGate } from "./FeatureGate.js";
import { FeatureFlagsProvider } from "./context.js";

const meta: Meta<typeof FeatureGate> = {
  title: "Layer 06 — Platform Services/Feature Flags/FeatureGate",
  component: FeatureGate,
  tags: ["autodocs"],
  decorators: [
    (Story, ctx) => {
      const flagValue = ctx.args.flag ?? "DEMO_FLAG";
      const enabled = ctx.parameters["flagEnabled"] ?? true;
      return (
        <FeatureFlagsProvider value={{ [flagValue]: enabled }}>
          <Story />
        </FeatureFlagsProvider>
      );
    },
  ],
};
export default meta;
type Story = StoryObj<typeof FeatureGate>;

export const Enabled: Story = {
  parameters: { flagEnabled: true },
  args: {
    flag: "DEMO_FLAG",
    children: (
      <div style={{ padding: "16px", background: "#f0fdf4", border: "1px solid #86efac", borderRadius: "8px" }}>
        ✓ Feature is enabled — this content renders.
      </div>
    ),
  },
};

export const Disabled: Story = {
  parameters: { flagEnabled: false },
  args: {
    flag: "DEMO_FLAG",
    children: (
      <div style={{ padding: "16px", background: "#f0fdf4", border: "1px solid #86efac", borderRadius: "8px" }}>
        This content is hidden when the flag is off.
      </div>
    ),
  },
};

export const DisabledWithFallback: Story = {
  parameters: { flagEnabled: false },
  args: {
    flag: "DEMO_FLAG",
    children: (
      <div style={{ padding: "16px", background: "#f0fdf4", border: "1px solid #86efac", borderRadius: "8px" }}>
        Feature content (hidden when flag is off).
      </div>
    ),
    fallback: (
      <div style={{ padding: "16px", background: "#fef9c3", border: "1px solid #fde047", borderRadius: "8px" }}>
        ⚠ This feature is not available in your current release.
      </div>
    ),
  },
};

export const AllFlags: Story = {
  name: "All flags — DWS.01 MVP-1 example",
  decorators: [
    (Story) => (
      <FeatureFlagsProvider
        value={{
          "APP.F01": true,
          "APP.F19": true,
          "APP.F07": true,
          "APP.F03": true,
          "APP.F12": true,
          "MARKETPLACE": true,
          "COPILOT": false,
          "ADMIN": false,
        }}
      >
        <Story />
      </FeatureFlagsProvider>
    ),
  ],
  render: () => {
    const flags = [
      { id: "APP.F01", label: "Service Operations" },
      { id: "APP.F19", label: "My Work" },
      { id: "APP.F07", label: "Submit Dashboard" },
      { id: "APP.F03", label: "Intake Form" },
      { id: "APP.F12", label: "Home" },
      { id: "MARKETPLACE", label: "Drive Marketplace" },
      { id: "COPILOT", label: "AI Copilot" },
      { id: "ADMIN", label: "Admin" },
    ];
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "8px", fontFamily: "monospace", fontSize: "13px" }}>
        {flags.map(({ id, label }) => (
          <FeatureGate
            key={id}
            flag={id}
            fallback={
              <div style={{ padding: "8px 12px", background: "#fef2f2", border: "1px solid #fca5a5", borderRadius: "6px" }}>
                ✗ <strong>{id}</strong> — {label} (disabled)
              </div>
            }
          >
            <div style={{ padding: "8px 12px", background: "#f0fdf4", border: "1px solid #86efac", borderRadius: "6px" }}>
              ✓ <strong>{id}</strong> — {label} (enabled)
            </div>
          </FeatureGate>
        ))}
      </div>
    );
  },
};
