import * as React from "react";
import { afterEach, describe, expect, it } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";

afterEach(cleanup);
import { FeatureFlagsProvider } from "./context.js";
import { FeatureGate } from "./FeatureGate.js";
import { useFeatureFlag } from "./hooks.js";

function wrap(flags: Record<string, boolean>, ui: React.ReactNode) {
  return render(<FeatureFlagsProvider value={flags}>{ui}</FeatureFlagsProvider>);
}

describe("FeatureGate", () => {
  it("renders children when flag is enabled", () => {
    wrap({ "APP.F01": true }, <FeatureGate flag="APP.F01"><span>content</span></FeatureGate>);
    expect(screen.getByText("content")).toBeTruthy();
  });

  it("renders nothing when flag is disabled (no fallback)", () => {
    wrap({ "APP.F01": false }, <FeatureGate flag="APP.F01"><span>content</span></FeatureGate>);
    expect(screen.queryByText("content")).toBeNull();
  });

  it("renders fallback when flag is disabled", () => {
    wrap(
      { "APP.F01": false },
      <FeatureGate flag="APP.F01" fallback={<span>fallback</span>}><span>content</span></FeatureGate>,
    );
    expect(screen.queryByText("content")).toBeNull();
    expect(screen.getByText("fallback")).toBeTruthy();
  });

  it("deny-by-default: unknown flag renders nothing", () => {
    wrap({}, <FeatureGate flag="UNKNOWN"><span>content</span></FeatureGate>);
    expect(screen.queryByText("content")).toBeNull();
  });
});

describe("useFeatureFlag", () => {
  function FlagConsumer({ id }: { id: string }) {
    const enabled = useFeatureFlag(id);
    return <span>{enabled ? "on" : "off"}</span>;
  }

  it("returns true for an enabled flag", () => {
    wrap({ "FEATURE_X": true }, <FlagConsumer id="FEATURE_X" />);
    expect(screen.getByText("on")).toBeTruthy();
  });

  it("returns false for a disabled flag", () => {
    wrap({ "FEATURE_X": false }, <FlagConsumer id="FEATURE_X" />);
    expect(screen.getByText("off")).toBeTruthy();
  });

  it("returns false (deny-by-default) for unknown flag", () => {
    wrap({}, <FlagConsumer id="UNKNOWN" />);
    expect(screen.getByText("off")).toBeTruthy();
  });

  it("throws when provider is missing", () => {
    const spy = console.error;
    console.error = () => {};
    expect(() => render(<FlagConsumer id="X" />)).toThrow("FeatureFlagsProvider not found");
    console.error = spy;
  });
});
