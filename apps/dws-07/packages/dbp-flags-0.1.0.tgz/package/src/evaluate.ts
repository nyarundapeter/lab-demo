import type { ResolvedFlagsMap } from "./schema.js";

/**
 * Resolves feature flags by merging manifest defaults with runtime env overrides.
 *
 * Resolution order (highest priority wins):
 *   env override  >  manifest default  >  false (deny-by-default)
 */
export function evaluateFlags(
  defaults: Record<string, boolean>,
  envOverrides: Record<string, boolean | undefined>,
): ResolvedFlagsMap {
  const resolved: ResolvedFlagsMap = {};
  for (const id of Object.keys(defaults)) {
    const override = envOverrides[id];
    resolved[id] = override !== undefined ? override : (defaults[id] ?? false);
  }
  return resolved;
}

/**
 * Returns true if the flag is enabled in the resolved map.
 * Unknown flags return false (deny-by-default).
 */
export function isFlagEnabled(
  resolved: ResolvedFlagsMap,
  id: string,
): boolean {
  return resolved[id] ?? false;
}
