import { evaluateFlags } from "./evaluate.js";
import type { ResolvedFlagsMap } from "./schema.js";

/**
 * Derives env override map from process.env (or a provided env record).
 * Reads DBP_FLAG_<ID> vars and coerces to boolean.
 *
 * Coercion: "false", "0", "" → false; anything else → true.
 */
function parseEnvOverrides(
  defaults: Record<string, boolean>,
  env: Record<string, string | undefined>,
): Record<string, boolean | undefined> {
  const overrides: Record<string, boolean | undefined> = {};
  for (const id of Object.keys(defaults)) {
    const envKey = "DBP_FLAG_" + id.replace(/[^A-Z0-9]/g, "_");
    const raw = env[envKey];
    if (raw === undefined) continue;
    overrides[id] = raw !== "" && raw !== "false" && raw !== "0";
  }
  return overrides;
}

/**
 * Server-side flag resolution. Pass the validated `env` object from lib/env.ts
 * and the `featureFlagDefaults` from solution/flags/config.ts.
 *
 * Safe to call from Server Components and Route Handlers — no React imports.
 */
export function getFeatureFlags(
  defaults: Record<string, boolean>,
  env: Record<string, string | undefined> = process.env,
): ResolvedFlagsMap {
  const overrides = parseEnvOverrides(defaults, env);
  return evaluateFlags(defaults, overrides);
}
