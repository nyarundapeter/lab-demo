import { z } from "zod";

export const FeatureFlagEntrySchema = z
  .object({
    id: z
      .string()
      .min(1)
      .regex(
        /^[A-Z0-9_.]+$/,
        "Flag ID must be uppercase alphanumeric with dots or underscores (e.g. APP.F01, FEATURE_AI)",
      ),
    label: z.string().min(1),
    enabled: z.boolean(),
  })
  .strict();

export type FeatureFlagEntry = z.infer<typeof FeatureFlagEntrySchema>;

export const FeatureFlagsBlockSchema = z
  .array(FeatureFlagEntrySchema)
  .refine(
    (arr) => new Set(arr.map((f) => f.id)).size === arr.length,
    { message: "Duplicate flag IDs in feature_flags block" },
  );

export type FeatureFlagsBlock = z.infer<typeof FeatureFlagsBlockSchema>;

export type ResolvedFlagsMap = Record<string, boolean>;
