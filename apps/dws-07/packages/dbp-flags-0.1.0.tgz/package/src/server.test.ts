import { describe, expect, it } from "vitest";
import { getFeatureFlags } from "./server.js";

const defaults = { "APP.F01": true, "APP.F21": false, "COPILOT": false };

describe("getFeatureFlags", () => {
  it("uses manifest defaults when no DBP_FLAG_* env vars set", () => {
    const flags = getFeatureFlags(defaults, {});
    expect(flags).toEqual({ "APP.F01": true, "APP.F21": false, "COPILOT": false });
  });

  it("enables a flag via DBP_FLAG_ env var set to 'true'", () => {
    const flags = getFeatureFlags(defaults, { DBP_FLAG_APP_F21: "true" });
    expect(flags["APP.F21"]).toBe(true);
  });

  it("disables a flag via DBP_FLAG_ env var set to 'false'", () => {
    const flags = getFeatureFlags(defaults, { DBP_FLAG_APP_F01: "false" });
    expect(flags["APP.F01"]).toBe(false);
  });

  it("coerces '0' to false", () => {
    const flags = getFeatureFlags(defaults, { DBP_FLAG_APP_F01: "0" });
    expect(flags["APP.F01"]).toBe(false);
  });

  it("coerces empty string to false", () => {
    const flags = getFeatureFlags(defaults, { DBP_FLAG_APP_F01: "" });
    expect(flags["APP.F01"]).toBe(false);
  });

  it("coerces any non-false string to true", () => {
    const flags = getFeatureFlags(defaults, { DBP_FLAG_APP_F21: "1" });
    expect(flags["APP.F21"]).toBe(true);
  });

  it("derives correct env var name for dot-notation IDs (APP.F01 → DBP_FLAG_APP_F01)", () => {
    const flags = getFeatureFlags({ "APP.F01": false }, { DBP_FLAG_APP_F01: "true" });
    expect(flags["APP.F01"]).toBe(true);
  });

  it("derives correct env var name for underscore IDs (COPILOT → DBP_FLAG_COPILOT)", () => {
    const flags = getFeatureFlags({ "COPILOT": false }, { DBG_FLAG_COPILOT: "true", DBP_FLAG_COPILOT: "true" });
    expect(flags["COPILOT"]).toBe(true);
  });

  it("returns empty map for empty defaults", () => {
    expect(getFeatureFlags({}, { DBP_FLAG_ANYTHING: "true" })).toEqual({});
  });
});
