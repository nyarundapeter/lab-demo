"use client";

import * as React from "react";
import type { ResolvedFlagsMap } from "./schema.js";

export const FeatureFlagsContext = React.createContext<ResolvedFlagsMap | null>(null);

export interface FeatureFlagsProviderProps {
  value: ResolvedFlagsMap;
  children: React.ReactNode;
}

export function FeatureFlagsProvider({ value, children }: FeatureFlagsProviderProps) {
  return (
    <FeatureFlagsContext.Provider value={value}>
      {children}
    </FeatureFlagsContext.Provider>
  );
}
