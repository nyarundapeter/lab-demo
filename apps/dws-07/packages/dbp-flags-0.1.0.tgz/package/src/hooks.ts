"use client";

import * as React from "react";
import { FeatureFlagsContext } from "./context.js";

export function useFeatureFlag(id: string): boolean {
  const ctx = React.useContext(FeatureFlagsContext);
  if (ctx === null) {
    throw new Error(
      "useFeatureFlag: FeatureFlagsProvider not found in tree. " +
        "Wrap your app (or the relevant subtree) with <FeatureFlagsProvider value={flags}>.",
    );
  }
  return ctx[id] ?? false;
}
