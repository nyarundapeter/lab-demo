import { describe, expect, it, vi } from "vitest";
import { measureP95 } from "./measure-p95";

describe("measureP95", () => {
  it("runs warmup + sample iterations and returns raw samples plus p95", async () => {
    let calls = 0;
    const result = await measureP95(
      () => {
        calls += 1;
      },
      { warmup: 5, samples: 20 },
    );

    expect(calls).toBe(25);
    expect(result.raw).toHaveLength(20);
    expect(result.p95).toBeGreaterThanOrEqual(0);
  });

  it("computes p95 via linear interpolation, not floor-index", async () => {
    // Fake a clock so each sample's elapsed time is deterministically 0,1,2,...,9ms
    // (measureP95 calls performance.now() once at the start and once at the end
    // of each iteration, so consecutive calls must differ by the target duration).
    const elapsed = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
    let call = 0;
    let clock = 0;
    const nowSpy = vi.spyOn(performance, "now").mockImplementation(() => {
      if (call % 2 === 1) clock += elapsed[Math.floor(call / 2)] as number;
      const value = clock;
      call += 1;
      return value;
    });

    const result = await measureP95(() => undefined, { warmup: 0, samples: elapsed.length });

    nowSpy.mockRestore();

    expect(result.raw).toEqual(elapsed);
    // sorted = [0..9], rank = (10 - 1) * 0.95 = 8.55 -> interpolate between 8 and 9.
    expect(result.p95).toBeCloseTo(8.55, 10);
  });

  it("defaults to 50 warmup and 500 samples", async () => {
    let calls = 0;
    await measureP95(() => {
      calls += 1;
    });
    expect(calls).toBe(550);
  });
});
