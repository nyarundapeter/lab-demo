export interface MeasureP95Options {
  /** Iterations run and discarded before timing starts (JIT/cache warmup). */
  warmup?: number;
  /** Number of timed iterations used to compute the percentile. */
  samples?: number;
  /** Fraction of top outliers to trim before computing the percentile. */
  trimTop?: number;
}

export interface MeasureP95Result {
  p95: number;
  raw: number[];
}

/**
 * Whether wall-clock SLO tests should throw on a missed threshold.
 *
 * Default CI (`pnpm test` inside dbp-pipeline.yml's build-test-scan job) runs on
 * shared, noisy GitHub Actions runners with no dedicated hardware — wall-clock p95
 * assertions there are not a sound same-day regression gate (see PROGRESS.md's
 * ps-apigw quarantine entry: 8.70ms -> 8.21ms -> 10.17ms drift with zero code
 * change). Real enforcement lives in nightly-nfr.yml, which sets SLO_ENFORCE=1.
 * Default CI measures and logs only, so `pnpm test` never fails on runner noise.
 */
export function sloEnforced(): boolean {
  return process.env.SLO_ENFORCE === "1";
}

/**
 * Assert a measured p95 against `thresholdMs` only when SLO_ENFORCE=1 (nightly-nfr).
 * Under default CI this logs the measurement and always passes, so the SLO suites
 * never fail the required per-PR `pnpm test` gate on shared-runner noise.
 */
export function assertSLO(result: MeasureP95Result, thresholdMs: number, label: string): void {
  const line = `SLO probe: ${label} p95 = ${result.p95.toFixed(2)}ms (target ${thresholdMs}ms)`;
  if (sloEnforced()) {
    console.log(`${line} [SLO_ENFORCE=1 — asserting]`);
    if (result.p95 >= thresholdMs) {
      throw new Error(`${line} — FAILED (nightly-nfr real gate)`);
    }
    return;
  }
  console.log(`${line} [measure-only — default CI does not gate on wall-clock p95; see nightly-nfr.yml]`);
}

function percentile95(sorted: number[]): number {
  if (sorted.length === 1) return sorted[0] as number;
  const rank = (sorted.length - 1) * 0.95;
  const lower = Math.floor(rank);
  const upper = Math.ceil(rank);
  const lowerValue = sorted[lower] as number;
  const upperValue = sorted[upper] as number;
  if (lower === upper) return lowerValue;
  const weight = rank - lower;
  return lowerValue + (upperValue - lowerValue) * weight;
}

export async function measureP95(
  fn: () => void | Promise<void>,
  opts?: MeasureP95Options,
): Promise<MeasureP95Result> {
  const warmup = opts?.warmup ?? 50;
  const samples = opts?.samples ?? 500;
  const trimTop = opts?.trimTop ?? 0;

  for (let i = 0; i < warmup; i += 1) {
    await fn();
  }

  const raw: number[] = [];
  for (let i = 0; i < samples; i += 1) {
    const start = performance.now();
    await fn();
    raw.push(performance.now() - start);
  }

  const sorted = [...raw].sort((a, b) => a - b);
  const trimmed =
    trimTop > 0 ? sorted.slice(0, Math.max(1, Math.floor(sorted.length * (1 - trimTop)))) : sorted;

  return { p95: percentile95(trimmed), raw };
}
