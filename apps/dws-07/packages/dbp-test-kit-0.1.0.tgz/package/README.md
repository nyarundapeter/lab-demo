# @dbp/test-kit

A small shared testing utility package. Currently exports one helper, `measure-p95` (`src/measure-p95.ts`, re-exported via `src/index.ts`), for measuring p95 timing in tests. Thin package — this is its full surface area today.

**Tier:** shared

## Exports
| Export | Path |
|---|---|
| `.` | `./src/index.ts` |

No `publishConfig.exports` override — ships raw TypeScript source.

## Config schema
N/A — no config schema in this package.

## Consumed by
TBD — no `@dbp/test-kit` import found via grep of `scripts/scaffold-solution.mjs` or `apps/`. Likely intended for use inside other `@dbp/*` packages' own test suites (as a devDependency), not emitted into generated solutions.

## Shipping
Workspace package during monorepo development (`workspace:*`). For standalone repos, it would ship as a committed tarball (`file:packages/dbp-test-kit-0.1.0.tgz`) resolved via `.pnpmfile.cjs` if pulled in as a dependency — see `docs/08-contributing/package-distribution.md`. Given its TBD consumption, it may currently only be used within this monorepo's own test tooling.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
