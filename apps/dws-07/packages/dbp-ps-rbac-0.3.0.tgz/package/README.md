# @dbp/ps-rbac

Role-based access control platform service. The server side compiles CASL
abilities from role/group assignments and exposes a packed-rules HTTP API
(`/matrix`, `/rules`, `/check`, `/version`); the client side (`configureRbacClient`,
`usePackedRules`, `useCan`, `useAbility`, `<Gate>`, `<Can>`, `useCRUD`,
`useRuleVersion`) evaluates permissions locally in-process against those packed
rules for sub-10ms checks, plus admin hooks for managing user/group role and
group-membership assignments. Solutions never hand-roll permission checks —
all authorization routes through this package.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `./client/index.ts` (source) / `./dist/client/index.js` (published) |
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |

`publishConfig.exports` splits both entries to `dist/` with `.d.ts` types — same subpaths, built output only.

## Config schema
`client/types.ts` (Zod schemas: `CheckRequestSchema`, `CheckResponseSchema`, `MatrixResponseSchema`, `PackedRulesResponseSchema`, `RbacErrorResponseSchema`, `RuleVersionResponseSchema`).

## Tiered ability generator

`server/tiered-ability.ts` — `generateCapabilityMatrix(subjectVerbs)` mechanically expands a
`{ subject: verbs[] }` table into the viewer < contributor < reviewer < approver capability ladder;
`compileScopedAbilityFromAssignments(matrix, assignments, ctx, options)` compiles a CASL ability from
domain-/entity-scoped `RoleAssignment`s against it. Use this instead of hand-authoring a `MatrixEntry[]`
when a solution needs domain/business-unit scope beyond the `MATRIX`/`compileAbility()` path's
`tenantId`/ownership-only conditions. See the Storybook guide (Layer 06 — Platform Services/PS.RBAC/
Ability Model Guide) for the design pattern this implements.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` registers `PS.RBAC` (dir `rbac`, package `@dbp/ps-rbac`, base path `/api/platform/rbac`), wires `configureRbacClient` from `@dbp/ps-rbac/client`, and re-exports `can`/`compileAbility` from `@dbp/ps-rbac/server` and `useCan`/`useAbility`/`Gate` from `@dbp/ps-rbac/client` through each generated app's own RBAC composition seam (apps never import `@dbp/ps-rbac` directly outside that seam).

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client delivery, ships as a packed `.tgz` tarball committed into the standalone's `packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
