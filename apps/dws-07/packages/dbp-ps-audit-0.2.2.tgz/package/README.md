# @dbp/ps-audit

registryId: `PS.AUDIT`

Records who did what to which entity, immutably, and serves activity feeds.
Solutions call `logEvent` after any state-changing operation; the Phase-4
ActivityFeed UI component binds to `useActivityFeed` — it is not a
per-solution build.

**Tier:** platform-service

## ⚠ Dev default looks durable but isn't

Outside `NODE_ENV=production`, an unset `AUDIT_STORAGE` silently defaults to `"memory"`
(`server/bootstrap.ts`). Production fails fast if `AUDIT_STORAGE` isn't `drizzle` — but in dev,
`logEvent()` writes and `useActivityFeed` reads both work end-to-end against the in-memory
store, so the activity feed looks fully wired. **Nothing is ever written to `audit.audit_event`
in Postgres.** Symptom: audit events are visible in the running app but vanish on restart, and
querying `audit.audit_event` directly returns nothing, even though the UI shows a populated
timeline. Remedy: set `AUDIT_STORAGE=drizzle` (with a usable `DATABASE_URL`) whenever you need
audit events to actually persist — including local dev sessions where you're testing
persistence, not just the UI. This default is deliberate (fast dev boot, no DB requirement) —
do not change `bootstrap.ts` to fail without `AUDIT_STORAGE` set outside production.

## Exports
| Export | Path |
|---|---|
| `./client` | `./client/index.ts` (source) / `./dist/client/index.js` (published) |
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |
| `./server/bootstrap` | `./server/bootstrap.ts` (source) / `./dist/server/bootstrap.js` (published) |

`publishConfig.exports` splits all three entries to `dist/` with `.d.ts` types — same subpaths, built output only.

## Config schema
See `contract.yaml` (OpenAPI 3.0.3, generated via `pnpm contracts:gen` from Zod schemas — never hand-edited).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` registers `PS.AUDIT` (dir `audit`, package `@dbp/ps-audit`, base path `/api/platform/audit`), wires `configureAuditClient` from `@dbp/ps-audit/client` into generated solution bootstrap, and (when audit is enabled for a solution) imports `getAuditService` from `@dbp/ps-audit/server` plus `ensureAuditStorage` from `@dbp/ps-audit/server/bootstrap` for storage bootstrap.

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client delivery, ships as a packed `.tgz` tarball committed into the standalone's `packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
