-- =============================================================================
-- 0013_rbac_group_tables.sql
-- DBP Platform — rbac.group / rbac.group_member / rbac.group_role
--
-- Purpose: src/schema/rbac.ts declares rbac.group (named group within a
-- tenant, for batch role assignment), rbac.group_member (user <-> group,
-- tenant-scoped, FK-guaranteed to an active iam.membership row), and
-- rbac.group_role (role assigned to a group — members inherit it, resolved at
-- GET /rbac/rules time) — none of which any prior migration shipped.
-- 0000_platform_init.sql only created rbac.role / rbac.permission /
-- rbac.role_permission / rbac.user_role.
--
-- Ordering : Apply AFTER 0012_notif_notification_preference.sql.
-- Idempotent / forward-only.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- rbac.group — named group within a tenant
-- -----------------------------------------------------------------------------

create table if not exists rbac.group (
  id          uuid        primary key default gen_random_uuid(),
  tenant_id   text        not null references iam.tenant(id) on delete cascade,
  name        text        not null,
  description text,
  created_at  timestamptz not null default now(),
  unique (tenant_id, name)
);

create index if not exists group_tenant_idx on rbac.group (tenant_id);

alter table rbac.group enable row level security;
create policy tenant_isolation on rbac.group
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- -----------------------------------------------------------------------------
-- rbac.group_member — user <-> group membership (tenant-scoped)
--
-- user_id integrity is enforced by the composite FK to iam.membership,
-- guaranteeing the user is an active tenant member before joining a group.
-- -----------------------------------------------------------------------------

create table if not exists rbac.group_member (
  id         uuid        primary key default gen_random_uuid(),
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  group_id   uuid        not null references rbac.group(id) on delete cascade,
  user_id    text        not null,
  created_at timestamptz not null default now(),
  unique (tenant_id, group_id, user_id),
  foreign key (tenant_id, user_id)
    references iam.membership(tenant_id, user_id) on delete cascade
);

create index if not exists group_member_user_idx on rbac.group_member (tenant_id, user_id);

alter table rbac.group_member enable row level security;
create policy tenant_isolation on rbac.group_member
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- -----------------------------------------------------------------------------
-- rbac.group_role — role assignment to a group (tenant-scoped)
-- -----------------------------------------------------------------------------

create table if not exists rbac.group_role (
  id         uuid        primary key default gen_random_uuid(),
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  group_id   uuid        not null references rbac.group(id) on delete cascade,
  role_id    text        not null references rbac.role(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (tenant_id, group_id, role_id)
);

create index if not exists group_role_group_idx on rbac.group_role (tenant_id, group_id);

alter table rbac.group_role enable row level security;
create policy tenant_isolation on rbac.group_role
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

grant select, insert, update, delete on rbac.group, rbac.group_member, rbac.group_role to dbp_app;
grant select on rbac.group, rbac.group_member, rbac.group_role to dbp_readonly;
