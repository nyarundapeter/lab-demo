-- =============================================================================
-- 0001_platform_rls.sql
-- DBP Platform — roles, row-level security, and grants
--
-- Purpose  : Creates the application database roles (dbp_auth, dbp_app,
--            dbp_readonly), enables RLS on every tenant-scoped table, attaches
--            the appropriate policy to each table, and grants the minimum
--            required privileges to each role.
--
-- Ordering : Apply AFTER 0000_platform_init.sql, BEFORE 0002_seed.sql.
--
-- Role design:
--   dbp_owner    — DDL / migration role (created per-substrate outside SQL);
--                  bypasses RLS via table ownership.
--   dbp_auth     — Pre-tenant identity resolution; iam schema only; no tenant
--                  GUC set.  Used exclusively by PS.AUTH to call
--                  iam.resolve_login() and iam.provision_login().
--   dbp_app      — Post-tenant runtime; the DATABASE_URL connection role.
--                  RLS is enforced; tenant GUC set by withTenant() per tx.
--   dbp_readonly — BI / reporting / read replicas; SELECT-only on all schemas.
--
-- RLS surface (four categories):
--   TENANT_SCOPED    — standard `tenant_id = current_tenant_id()` isolation
--   MEMBERSHIP_GATED — global rows visible only via a membership-existence check
--   UNSCOPED_AUTH    — NO RLS; reachable only by dbp_auth (iam.identity)
--   GLOBAL           — no RLS; shared across all tenants (config/registry tables)
--
-- =============================================================================


-- ---------------------------------------------------------------------------
-- Database roles (NOLOGIN group roles; concrete login roles created per-substrate)
-- Idempotent guard: only create if not already present.
-- ---------------------------------------------------------------------------

do $$ begin
  if not exists (select from pg_roles where rolname = 'dbp_auth') then
    create role dbp_auth nologin;
  end if;
  if not exists (select from pg_roles where rolname = 'dbp_app') then
    create role dbp_app nologin;
  end if;
  if not exists (select from pg_roles where rolname = 'dbp_readonly') then
    create role dbp_readonly nologin;
  end if;
end $$;


-- ---------------------------------------------------------------------------
-- Schema usage grants
-- dbp_auth: iam only (pre-tenant)
-- dbp_app:  all schemas except iam (uses resolve_login SECURITY DEFINER instead)
-- dbp_readonly: all schemas
-- ---------------------------------------------------------------------------

grant usage on schema iam       to dbp_auth;

grant usage on schema platform  to dbp_app, dbp_readonly;
grant usage on schema iam       to dbp_app, dbp_readonly;
grant usage on schema rbac      to dbp_app, dbp_readonly;
grant usage on schema audit     to dbp_app, dbp_readonly;
grant usage on schema notif     to dbp_app, dbp_readonly;
grant usage on schema search    to dbp_app, dbp_readonly;
grant usage on schema workflow  to dbp_app, dbp_readonly;
grant usage on schema events    to dbp_app, dbp_readonly;
grant usage on schema ai        to dbp_app, dbp_readonly;
grant usage on schema data      to dbp_app, dbp_readonly;
grant usage on schema apigw     to dbp_app, dbp_readonly;


-- ---------------------------------------------------------------------------
-- Row-level security
--
-- § CATEGORY 1 — TENANT_SCOPED tables
--   Standard policy:
--     using      (tenant_id = platform.current_tenant_id())
--     with check (tenant_id = platform.current_tenant_id())
--
-- § CATEGORY 2 — MEMBERSHIP_GATED tables (iam.user)
--   Global rows visible only if a membership exists in the active tenant:
--     using (exists (
--       select 1 from iam.membership m
--       where m.user_id = "user".id
--         and m.tenant_id = platform.current_tenant_id()
--     ))
--   with check is omitted: user create/update happens in the pre-tenant auth
--   path (dbp_auth / SECURITY DEFINER), not under tenant RLS.
--
-- § CATEGORY 3 — UNSCOPED_AUTH tables (iam.identity)
--   NO RLS at all.  iam.identity has no tenant_id column (it is global).
--   Isolation is enforced by withholding the SELECT grant from dbp_app entirely.
--   The only access path is iam.resolve_login() SECURITY DEFINER.
--
-- § CATEGORY 4 — GLOBAL / config tables (no RLS)
--   iam.tenant, rbac.role, rbac.permission, rbac.role_permission,
--   workflow.definition, events.producer_registration, data.entity_type,
--   apigw.route
--
-- EXCEPTION — events.domain_event has a NULLABLE tenant_id (platform-global
-- events carry no tenant).  Its policy allows rows where tenant_id IS NULL
-- (platform events visible to all) OR matches the current tenant.
-- ---------------------------------------------------------------------------


-- § iam.user — MEMBERSHIP_GATED (global record, tenant-visibility via membership)
alter table iam."user" enable row level security;
create policy member_visibility on iam."user"
  using (
    exists (
      select 1 from iam.membership m
      where  m.user_id   = iam."user".id
        and  m.tenant_id = platform.current_tenant_id()
    )
  );
-- with check intentionally omitted: writes go through dbp_auth SECURITY DEFINER.

-- § iam.membership — TENANT_SCOPED
alter table iam.membership enable row level security;
create policy tenant_isolation on iam.membership
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § iam.session — TENANT_SCOPED (tenant_id = active tenant for this session)
alter table iam.session enable row level security;
create policy tenant_isolation on iam.session
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- (iam.identity — NO RLS; see CATEGORY 3 above)

-- § rbac.user_role — TENANT_SCOPED
alter table rbac.user_role enable row level security;
create policy tenant_isolation on rbac.user_role
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § audit.audit_event — TENANT_SCOPED
alter table audit.audit_event enable row level security;
create policy tenant_isolation on audit.audit_event
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § notif.notification — TENANT_SCOPED
alter table notif.notification enable row level security;
create policy tenant_isolation on notif.notification
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § search.search_document — TENANT_SCOPED
alter table search.search_document enable row level security;
create policy tenant_isolation on search.search_document
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § workflow.instance — TENANT_SCOPED
alter table workflow.instance enable row level security;
create policy tenant_isolation on workflow.instance
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § events.domain_event — EXCEPTION: tenant_id is nullable (platform-global events)
alter table events.domain_event enable row level security;
create policy tenant_isolation on events.domain_event
  using      (tenant_id is null or tenant_id = platform.current_tenant_id())
  with check (tenant_id is null or tenant_id = platform.current_tenant_id());

-- § ai.conversation — TENANT_SCOPED
alter table ai.conversation enable row level security;
create policy tenant_isolation on ai.conversation
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § ai.message — TENANT_SCOPED
alter table ai.message enable row level security;
create policy tenant_isolation on ai.message
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § ai.rag_document — TENANT_SCOPED
alter table ai.rag_document enable row level security;
create policy tenant_isolation on ai.rag_document
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § data.entity — TENANT_SCOPED
alter table data.entity enable row level security;
create policy tenant_isolation on data.entity
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- § data.entity_link — TENANT_SCOPED
alter table data.entity_link enable row level security;
create policy tenant_isolation on data.entity_link
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());


-- ---------------------------------------------------------------------------
-- Grants — dbp_auth (pre-tenant role; iam schema only)
--
-- dbp_auth does NOT set a tenant GUC. It calls iam.resolve_login() exclusively;
-- it does NOT need direct SELECT on iam tables (the function is SECURITY DEFINER
-- and reads above RLS). Grant execute only.
-- ---------------------------------------------------------------------------

grant execute on function iam.resolve_login(text, text) to dbp_auth;


-- ---------------------------------------------------------------------------
-- Grants — dbp_app (post-tenant runtime; enforces RLS)
--
-- Global / config tables: full CRUD (runtime registration: defineEntity,
-- registerProducer, startWorkflow defs, registerRoute, tenant provisioning).
--
-- iam.identity is intentionally EXCLUDED: dbp_app must never see raw credentials.
-- Access goes through iam.resolve_login() SECURITY DEFINER only.
-- ---------------------------------------------------------------------------

-- Global / config tables — full CRUD for dbp_app
grant select, insert, update, delete on iam.tenant                        to dbp_app;
grant select, insert, update, delete on rbac.role                         to dbp_app;
grant select, insert, update, delete on rbac.permission                   to dbp_app;
grant select, insert, update, delete on rbac.role_permission              to dbp_app;
grant select, insert, update, delete on workflow.definition               to dbp_app;
grant select, insert, update, delete on events.producer_registration      to dbp_app;
grant select, insert, update, delete on data.entity_type                  to dbp_app;
grant select, insert, update, delete on apigw.route                       to dbp_app;

-- iam — tenant-scoped tables (membership, session) + global user (membership-gated)
-- iam.identity is NOT granted to dbp_app (no direct access; SECURITY DEFINER path only)
grant select, insert, update, delete on iam."user"                        to dbp_app;
grant select, insert, update, delete on iam.membership                    to dbp_app;
grant select, insert, update, delete on iam.session                       to dbp_app;

-- rbac — tenant-scoped
grant select, insert, update, delete on rbac.user_role                    to dbp_app;

-- Remaining tenant-scoped tables
grant select, insert, update, delete on notif.notification                to dbp_app;
grant select, insert, update, delete on search.search_document            to dbp_app;
grant select, insert, update, delete on workflow.instance                 to dbp_app;
grant select, insert, update, delete on events.domain_event               to dbp_app;
grant select, insert, update, delete on ai.conversation                   to dbp_app;
grant select, insert, update, delete on ai.message                        to dbp_app;
grant select, insert, update, delete on ai.rag_document                   to dbp_app;
grant select, insert, update, delete on data.entity                       to dbp_app;
grant select, insert, update, delete on data.entity_link                  to dbp_app;

-- audit.audit_event — INSERT + SELECT only; UPDATE/DELETE explicitly revoked.
grant insert, select on audit.audit_event to dbp_app;
revoke update, delete on audit.audit_event from dbp_app;

-- Sequence usage
grant usage on all sequences in schema iam      to dbp_app;
grant usage on all sequences in schema rbac     to dbp_app;
grant usage on all sequences in schema audit    to dbp_app;
grant usage on all sequences in schema notif    to dbp_app;
grant usage on all sequences in schema search   to dbp_app;
grant usage on all sequences in schema workflow to dbp_app;
grant usage on all sequences in schema events   to dbp_app;
grant usage on all sequences in schema ai       to dbp_app;
grant usage on all sequences in schema data     to dbp_app;
grant usage on all sequences in schema apigw    to dbp_app;
grant usage on all sequences in schema platform to dbp_app;


-- ---------------------------------------------------------------------------
-- Grants — dbp_readonly (SELECT on all tables in every schema)
-- ---------------------------------------------------------------------------

grant select on all tables in schema platform  to dbp_readonly;
grant select on all tables in schema iam       to dbp_readonly;
grant select on all tables in schema rbac      to dbp_readonly;
grant select on all tables in schema audit     to dbp_readonly;
grant select on all tables in schema notif     to dbp_readonly;
grant select on all tables in schema search    to dbp_readonly;
grant select on all tables in schema workflow  to dbp_readonly;
grant select on all tables in schema events    to dbp_readonly;
grant select on all tables in schema ai        to dbp_readonly;
grant select on all tables in schema data      to dbp_readonly;
grant select on all tables in schema apigw     to dbp_readonly;
