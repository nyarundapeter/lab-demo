-- =============================================================================
-- 0003_iam_provision_login.sql
-- DBP Platform — JIT user provisioning (first-login path)
--
-- Adds iam.provision_login() SECURITY DEFINER — the second pre-tenant auth
-- entry point alongside iam.resolve_login().
--
-- Called by PS.AUTH after verifying an IdP token when no existing
-- iam.identity row exists for (provider, subject). Upserts atomically:
--   1. iam.user (upsert on id; email unique index deconflicts on re-provision)
--   2. iam.identity (upsert on provider + subject unique)
--   3. iam.membership (upsert on tenant_id + user_id unique; default status 'active')
--
-- Returns the same shape as iam.resolve_login() so the caller treats
-- provision and resolve identically.
-- =============================================================================

create or replace function iam.provision_login(
  p_provider      text,
  p_subject       text,
  p_user_id       text,         -- caller-minted userId (from IdP sub or uuid)
  p_email         text,
  p_display_name  text,
  p_tenant_id     text
) returns table (
  user_id           text,
  email             text,
  display_name      text,
  tenant_id         text,
  membership_status text
)
  language plpgsql
  security definer
as $$
begin
  -- 1. Upsert iam.user (global; idempotent on id)
  insert into iam."user" (id, email, display_name, status)
  values (p_user_id, p_email, p_display_name, 'active')
  on conflict (id) do update
    set email        = excluded.email,
        display_name = excluded.display_name,
        updated_at   = now()
  where iam."user".status = 'active';

  -- 2. Upsert iam.identity (idempotent on provider + subject)
  insert into iam.identity (user_id, provider, subject)
  values (p_user_id, p_provider, p_subject)
  on conflict (provider, subject) do nothing;

  -- 3. Upsert iam.membership (idempotent on tenant_id + user_id)
  insert into iam.membership (tenant_id, user_id, status)
  values (p_tenant_id, p_user_id, 'active')
  on conflict (tenant_id, user_id) do update
    set status = 'active'
  where iam.membership.status = 'revoked';  -- only reactivate if previously revoked

  -- 4. Return same shape as resolve_login
  return query
    select
      u.id              as user_id,
      u.email,
      u.display_name,
      m.tenant_id,
      m.status          as membership_status
    from  iam."user"     u
    join  iam.membership m on m.user_id = u.id
    where u.id        = p_user_id
      and m.tenant_id = p_tenant_id;
end;
$$;

-- Grant execute to dbp_auth (the pre-tenant role)
grant execute on function iam.provision_login(text, text, text, text, text, text) to dbp_auth;
