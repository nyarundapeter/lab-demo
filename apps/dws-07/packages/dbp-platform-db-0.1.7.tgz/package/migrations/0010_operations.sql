-- =============================================================================
-- 0010_operations.sql
-- DBP Platform — operations domain schema (fulfilment & operations)
--
-- Purpose  : Production relational data model (ADR-0039) — fulfilment:
--            workflow_instances, workflow_steps, task_queues, task_assignments,
--            approval_decisions.
--
-- Identity : text ids; tenant_id -> iam.tenant(id); assignee/approver -> iam."user"(id).
-- Workflow : operations.workflow_instances JOINS the baseline workflow schema
--            (FK (tenant_id, workflow_id) -> workflow.instance) — it does NOT
--            re-implement workflow execution (design §5).
--
-- Ordering : apply after 0009_workspace (and the baseline workflow schema).
--            FKs downward only (operations -> workspace/workflow/iam/platform).
-- Idempotent / forward-only.
-- =============================================================================

create schema if not exists operations;

grant usage on schema operations to dbp_app, dbp_readonly;

-- ---------------------------------------------------------------------------
-- operations.workflow_instances — links a workspace.requests row to the
-- baseline workflow.instance row that fulfils it. Not a duplicate of
-- workflow.instance: this is the request<->workflow join + operations-level
-- status rollup.
-- ---------------------------------------------------------------------------

create table if not exists operations.workflow_instances (
  id                      text        primary key,
  tenant_id               text        not null references iam.tenant(id) on delete cascade,
  request_id              text        not null references workspace.requests(id) on delete cascade,
  workflow_definition_id  text        not null,
  workflow_id             text,
  status                  text        not null default 'running' check (status in ('running','completed','rejected')),
  created_at              timestamptz not null default now(),
  updated_at              timestamptz,
  created_by              text,
  foreign key (tenant_id, workflow_id) references workflow.instance(tenant_id, workflow_id)
);
create index if not exists workflow_instances_tenant_idx  on operations.workflow_instances (tenant_id);
create index if not exists workflow_instances_request_idx on operations.workflow_instances (tenant_id, request_id);
create index if not exists workflow_instances_wfid_idx    on operations.workflow_instances (tenant_id, workflow_id);
create index if not exists workflow_instances_status_idx  on operations.workflow_instances (tenant_id, status);

-- ---------------------------------------------------------------------------
-- operations.workflow_steps — per-step detail (SLA due_at etc.) for an
-- operations.workflow_instances row. workflow.instance already stores its
-- own `steps jsonb` array; this table exists for step-level relational
-- queries (assignments/approvals/SLA joins) that the JSONB blob can't index.
-- ---------------------------------------------------------------------------

create table if not exists operations.workflow_steps (
  id                     text        primary key,
  tenant_id              text        not null references iam.tenant(id) on delete cascade,
  workflow_instance_id   text        not null references operations.workflow_instances(id) on delete cascade,
  step_key               text        not null,
  status                 text        not null default 'pending' check (status in ('pending','in_progress','completed','skipped','rejected')),
  due_at                 timestamptz,
  completed_at           timestamptz,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz,
  unique (workflow_instance_id, step_key)
);
create index if not exists workflow_steps_tenant_idx    on operations.workflow_steps (tenant_id);
create index if not exists workflow_steps_instance_idx  on operations.workflow_steps (tenant_id, workflow_instance_id);
create index if not exists workflow_steps_status_idx    on operations.workflow_steps (tenant_id, status);
create index if not exists workflow_steps_due_idx       on operations.workflow_steps (tenant_id, due_at);

-- ---------------------------------------------------------------------------
-- operations.task_queues — routing queues (e.g. it_fulfilment, hra_requests).
-- ---------------------------------------------------------------------------

create table if not exists operations.task_queues (
  id           text        primary key,
  tenant_id    text        not null references iam.tenant(id) on delete cascade,
  key          text        not null,
  name         text        not null,
  description  text,
  status       text        not null default 'active' check (status in ('active','inactive')),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz,
  created_by   text,
  unique (tenant_id, key)
);
create index if not exists task_queues_tenant_idx on operations.task_queues (tenant_id);

-- ---------------------------------------------------------------------------
-- operations.task_assignments — who is doing the fulfilment work.
-- ---------------------------------------------------------------------------

create table if not exists operations.task_assignments (
  id                    text        primary key,
  tenant_id             text        not null references iam.tenant(id) on delete cascade,
  workflow_step_id      text        not null references operations.workflow_steps(id) on delete cascade,
  queue_id              text        references operations.task_queues(id),
  assignee_id           text        references iam."user"(id),
  status                text        not null default 'assigned' check (status in ('assigned','in_progress','completed','reassigned')),
  assigned_at           timestamptz not null default now(),
  completed_at          timestamptz,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz
);
create index if not exists task_assignments_tenant_idx   on operations.task_assignments (tenant_id);
create index if not exists task_assignments_step_idx     on operations.task_assignments (tenant_id, workflow_step_id);
create index if not exists task_assignments_queue_idx    on operations.task_assignments (tenant_id, queue_id);
create index if not exists task_assignments_assignee_idx on operations.task_assignments (tenant_id, assignee_id);

-- ---------------------------------------------------------------------------
-- operations.approval_decisions — per workflow_step approval outcome.
-- ---------------------------------------------------------------------------

create table if not exists operations.approval_decisions (
  id                text        primary key,
  tenant_id         text        not null references iam.tenant(id) on delete cascade,
  workflow_step_id  text        not null references operations.workflow_steps(id) on delete cascade,
  approver_id       text        references iam."user"(id),
  decision          text        not null check (decision in ('approved','rejected','returned')),
  comment           text,
  decided_at        timestamptz not null default now(),
  created_at        timestamptz not null default now()
);
create index if not exists approval_decisions_tenant_idx on operations.approval_decisions (tenant_id);
create index if not exists approval_decisions_step_idx   on operations.approval_decisions (tenant_id, workflow_step_id);
create index if not exists approval_decisions_approver_idx on operations.approval_decisions (tenant_id, approver_id);

-- ---------------------------------------------------------------------------
-- updated_at triggers (platform.set_updated_at(), mirrors platform-db pattern)
-- ---------------------------------------------------------------------------

drop trigger if exists workflow_instances_set_updated_at on operations.workflow_instances;
create trigger workflow_instances_set_updated_at
  before update on operations.workflow_instances
  for each row execute function platform.set_updated_at();

drop trigger if exists workflow_steps_set_updated_at on operations.workflow_steps;
create trigger workflow_steps_set_updated_at
  before update on operations.workflow_steps
  for each row execute function platform.set_updated_at();

drop trigger if exists task_queues_set_updated_at on operations.task_queues;
create trigger task_queues_set_updated_at
  before update on operations.task_queues
  for each row execute function platform.set_updated_at();

drop trigger if exists task_assignments_set_updated_at on operations.task_assignments;
create trigger task_assignments_set_updated_at
  before update on operations.task_assignments
  for each row execute function platform.set_updated_at();

-- approval_decisions is append-only — no updated_at trigger.

-- ---------------------------------------------------------------------------
-- RLS — tenant isolation only, mirrors platform-db TENANT_SCOPED pattern.
-- ---------------------------------------------------------------------------

alter table operations.workflow_instances enable row level security;
drop policy if exists tenant_isolation on operations.workflow_instances;
create policy tenant_isolation on operations.workflow_instances
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table operations.workflow_steps enable row level security;
drop policy if exists tenant_isolation on operations.workflow_steps;
create policy tenant_isolation on operations.workflow_steps
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table operations.task_queues enable row level security;
drop policy if exists tenant_isolation on operations.task_queues;
create policy tenant_isolation on operations.task_queues
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table operations.task_assignments enable row level security;
drop policy if exists tenant_isolation on operations.task_assignments;
create policy tenant_isolation on operations.task_assignments
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table operations.approval_decisions enable row level security;
drop policy if exists tenant_isolation on operations.approval_decisions;
create policy tenant_isolation on operations.approval_decisions
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- ---------------------------------------------------------------------------
-- Grants — dbp_app (post-tenant runtime; RLS-enforced)
-- ---------------------------------------------------------------------------

grant select, insert, update, delete on operations.workflow_instances  to dbp_app;
grant select, insert, update, delete on operations.workflow_steps      to dbp_app;
grant select, insert, update, delete on operations.task_queues         to dbp_app;
grant select, insert, update, delete on operations.task_assignments    to dbp_app;
grant select, insert, update, delete on operations.approval_decisions  to dbp_app;

grant select on all tables in schema operations to dbp_readonly;
