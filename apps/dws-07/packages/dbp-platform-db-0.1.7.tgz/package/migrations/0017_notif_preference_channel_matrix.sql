-- =============================================================================
-- 0017_notif_preference_channel_matrix.sql
-- DBP Platform — notif.notification_preference gains a `channel` column,
-- turning per-type opt-in/out into a type×channel matrix (PS.NOTIF NOT-22,
-- docs/03-features/audits/design-audit-2026-07-17-notification-overlay.md
-- row A22, reference `notif-prefs.jsx:11-76`).
--
-- Backward-compatible: existing rows are per-type-only preferences that were
-- always evaluated against the "in-app" send path (the only channel
-- resolveShouldSend was ever called for) — backfilling `channel = 'in-app'`
-- preserves their original meaning exactly. The old (tenant_id, user_id,
-- type) uniqueness is widened to (tenant_id, user_id, type, channel), so a
-- second row can now be added per type for 'email'/'sms' without touching
-- existing rows.
--
-- Ordering : Apply AFTER 0016_notif_status_lifecycle_and_verbs.sql.
-- Idempotent / forward-only.
-- =============================================================================

alter table notif.notification_preference
  add column if not exists channel text not null default 'in-app';

alter table notif.notification_preference drop constraint if exists notification_preference_channel_check;
alter table notif.notification_preference
  add constraint notification_preference_channel_check
  check (channel in ('in-app', 'email', 'sms'));

-- 0014 declared `unique (tenant_id, user_id, type)` with no explicit name, so
-- Postgres auto-named it `notification_preference_tenant_id_user_id_type_key`.
alter table notif.notification_preference
  drop constraint if exists notification_preference_tenant_id_user_id_type_key;
alter table notif.notification_preference
  add constraint notif_pref_user_type_channel_uq unique (tenant_id, user_id, type, channel);
