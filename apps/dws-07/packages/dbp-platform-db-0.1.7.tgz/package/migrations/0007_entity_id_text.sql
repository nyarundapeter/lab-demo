-- =============================================================================
-- 0007_entity_id_text.sql
-- DBP Platform — data.entity / data.entity_link ids: uuid → text (G2)
--
-- Purpose  : data.entity.id and data.entity_link.from_id/to_id were typed
--            uuid, but the generic entity store is a schema-light,
--            arbitrary-key store — solutions key entities by business codes
--            (e.g. 'CTL-001') or ULIDs, never by uuid. DrizzleEntityStorageAdapter
--            always inserts the caller-supplied id verbatim (never generates
--            one), so the uuid column rejected every non-hex-valid id.
--            audit.audit_event.target_entity_id is already text, confirming
--            text is the platform-wide id contract for entities.
--
-- Ordering : Apply AFTER 0001_platform_rls.sql (RLS policies are on
--            tenant_id, unaffected by this change).
--
-- Notes    :
--   1. entity_link.id (its own generated PK) stays uuid — only the
--      entity-referencing columns (entity.id, entity_link.from_id/to_id)
--      change to text.
--   2. entity.id's `default gen_random_uuid()` is dropped — callers must
--      always supply an id (matches DrizzleEntityStorageAdapter behavior).
--   3. FK constraints are dropped and recreated around the type change;
--      indexes/unique constraints on the affected columns are rebuilt
--      automatically by ALTER COLUMN TYPE.
--   4. api.entities (0004_api_schema.sql) is defined over data.entity and
--      blocks the type change ("cannot alter type of a column used by a
--      view or rule"). It is dropped before the alters and recreated
--      identically to 0004 afterward, so this migration applies safely in
--      strict numeric order 0000→0006.
-- =============================================================================

drop view if exists api.entities;

alter table data.entity_link drop constraint entity_link_from_id_fkey;
alter table data.entity_link drop constraint entity_link_to_id_fkey;

alter table data.entity
  alter column id type text using id::text,
  alter column id drop default;

alter table data.entity_link
  alter column from_id type text using from_id::text,
  alter column to_id   type text using to_id::text;

alter table data.entity_link
  add constraint entity_link_from_id_fkey foreign key (from_id) references data.entity(id) on delete cascade,
  add constraint entity_link_to_id_fkey   foreign key (to_id)   references data.entity(id) on delete cascade;

-- Flat view of the JSONB entity store (standard tenant RLS via data.entity)
create or replace view api.entities
  with (security_invoker = true)
as
  select e.id, e.tenant_id, e.type, e.data, e.created_at, e.updated_at
  from   data.entity e;

grant select on api.entities to dbp_app, dbp_readonly;
