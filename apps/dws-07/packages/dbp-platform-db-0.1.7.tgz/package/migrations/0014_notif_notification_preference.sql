-- =============================================================================
-- 0012_notif_notification_preference.sql
-- DBP Platform — notif.notification_preference (PS.NOTIF §N4)
--
-- Purpose: src/schema/notif.ts declares notif.notification_preference (per-user,
-- per-type opt-in/out — docs/09-plans/sharavi-decision-pack-2026-07-11.md
-- 2026-07-17 rulings) but no prior migration ever shipped it. `tier` is policy
-- data (mandatory/recommended/optional) enforced at the service layer
-- (server/preferences-storage.ts + handlers.ts), not a fixed CHECK constraint —
-- it can change per release.
--
-- Ordering : Apply AFTER 0011_workflow_tenant_scoped_definition_and_transitions.sql.
-- Idempotent / forward-only.
-- =============================================================================

create table if not exists notif.notification_preference (
  id         uuid        primary key default gen_random_uuid(),
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  user_id    text        not null,
  type       text        not null,
  tier       text        not null,
  opted_in   boolean     not null default true,
  updated_at timestamptz not null default now(),
  unique (tenant_id, user_id, type)
);

create index if not exists notif_pref_user_idx
  on notif.notification_preference (tenant_id, user_id);

alter table notif.notification_preference enable row level security;
create policy tenant_isolation on notif.notification_preference
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

grant select, insert, update, delete on notif.notification_preference to dbp_app;
grant select on notif.notification_preference to dbp_readonly;
