-- =============================================================================
-- 0011_workflow_tenant_scoped_definition_and_transitions.sql
-- DBP Platform — bring workflow.* in line with src/schema/workflow.ts
--
-- Purpose: src/schema/workflow.ts (the Drizzle source of truth used by
-- DrizzleWorkflowStorageAdapter) declares several things no prior migration
-- ever shipped:
--   1. workflow.definition is tenant-scoped (tenant_id column, PK widened to
--      (tenant_id, id, version)) — 0000_platform_init.sql created it GLOBAL
--      (PK (id, version), no tenant_id), and 0001_platform_rls.sql explicitly
--      documented it as one of the no-RLS global tables. The adapter's
--      putDefinition()/getDefinition()/listDefinitions() all query
--      definition.tenant_id, which does not exist until this migration.
--      It also never got version_major/version_minor/version_patch (parsed
--      from `version` at write time — the schema's sort/resolution key for
--      workflow_definition_version_idx), so this migration backfills those
--      by parsing the existing semver `version` text column.
--   2. workflow.instance is missing: revision, terminal, parent_instance_id,
--      parent_step_id, subprocess_depth, sla_due_at, sla_timer_key,
--      last_transition_id, completed_at — and the indexes that depend on
--      them (workflow_instance_listing_idx, workflow_sla_due_idx,
--      workflow_parent_idx). Only entity_type/entity_record_id (0006) and
--      the original 0000 columns exist today.
--   3. workflow.transition (the durable, append-only transition-history
--      table) was never created at all.
--
-- Backfill: see the per-definition tenant-duplication block below (section 1)
-- for how existing workflow.definition rows are assigned a tenant_id — every
-- tenant with a workflow.instance already referencing a given definition gets
-- its own copy; a definition with no referencing instances yet falls back to
-- the canonical seeded tenant ('tenant-alpha', see 0002_seed.sql).
--
-- Ordering : Apply AFTER 0010_operations.sql.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. workflow.definition — widen to tenant-scoped
-- -----------------------------------------------------------------------------

alter table workflow.definition
  add column if not exists tenant_id text,
  add column if not exists version_major integer,
  add column if not exists version_minor integer,
  add column if not exists version_patch integer;

-- Backfill version_major/minor/patch by parsing the existing semver `version`
-- text column (e.g. "1.2.0"). Every version written by SP-3 is a validated
-- plain semver string, so a strict 3-part split is safe here.
update workflow.definition
   set version_major = split_part(version, '.', 1)::integer,
       version_minor = split_part(version, '.', 2)::integer,
       version_patch = split_part(version, '.', 3)::integer
 where version_major is null;

alter table workflow.definition
  alter column version_major set not null,
  alter column version_minor set not null,
  alter column version_patch set not null;

-- Drop the FK from workflow.instance to the old (id, version) PK, and the old
-- PK itself, BEFORE the tenant-duplication backfill below — the backfill
-- deliberately creates multiple rows sharing the same (id, version) (one per
-- tenant that references it), which the old single-tenant PK would reject.
-- Both constraint names are looked up dynamically: they were auto-generated
-- by the unnamed inline `primary key (id, version)` / `foreign key (...)
-- references workflow.definition(id, version)` in 0000_platform_init.sql.
do $$
declare
  con_name text;
begin
  select conname into con_name
    from pg_constraint
   where conrelid = 'workflow.instance'::regclass
     and contype = 'f'
     and confrelid = 'workflow.definition'::regclass;
  if con_name is not null then
    execute format('alter table workflow.instance drop constraint %I', con_name);
  end if;
end $$;

do $$
declare
  con_name text;
begin
  select conname into con_name
    from pg_constraint
   where conrelid = 'workflow.definition'::regclass
     and contype = 'p';
  if con_name is not null then
    execute format('alter table workflow.definition drop constraint %I', con_name);
  end if;
end $$;

-- Backfill: the old model shared one global (id, version) definition row
-- across every tenant with instances against it. Widening the PK to include
-- tenant_id means each such tenant now needs its OWN copy of that row (the
-- FK from workflow.instance requires an exact tenant_id match). For each
-- global definition, assign the first referencing tenant in place, then
-- INSERT a duplicate row per additional distinct referencing tenant (safe
-- now that the old single-tenant PK above has been dropped).
-- Definitions with zero referencing instances (never actually used, or
-- authored but not yet started) fall back to the canonical seeded tenant.
do $$
declare
  def_rec  record;
  ten_rec  record;
  first_tenant text;
begin
  for def_rec in select id, version from workflow.definition where tenant_id is null loop
    first_tenant := null;
    for ten_rec in
      select distinct i.tenant_id
        from workflow.instance i
       where i.definition_id = def_rec.id and i.definition_version = def_rec.version
       order by i.tenant_id
    loop
      if first_tenant is null then
        first_tenant := ten_rec.tenant_id;
        update workflow.definition
           set tenant_id = first_tenant
         where id = def_rec.id and version = def_rec.version;
      else
        insert into workflow.definition (tenant_id, id, version, version_major, version_minor, version_patch, name, initial_step, steps, created_at)
        select ten_rec.tenant_id, id, version, version_major, version_minor, version_patch, name, initial_step, steps, created_at
          from workflow.definition
         where id = def_rec.id and version = def_rec.version and tenant_id = first_tenant;
      end if;
    end loop;

    if first_tenant is null then
      update workflow.definition
         set tenant_id = 'tenant-alpha'
       where id = def_rec.id and version = def_rec.version and tenant_id is null;
    end if;
  end loop;
end $$;

alter table workflow.definition
  alter column tenant_id set not null,
  add constraint definition_tenant_id_fkey
    foreign key (tenant_id) references iam.tenant(id) on delete cascade;

alter table workflow.definition
  add primary key (tenant_id, id, version);

create index if not exists workflow_definition_version_idx
  on workflow.definition (tenant_id, id, version_major desc, version_minor desc, version_patch desc);

-- Re-add the instance -> definition FK, now composite through tenant_id.
alter table workflow.instance
  add constraint instance_definition_fkey
    foreign key (tenant_id, definition_id, definition_version)
    references workflow.definition(tenant_id, id, version);

-- workflow.definition is now tenant-scoped — enable RLS (it was in the
-- documented global/no-RLS group in 0001_platform_rls.sql; that grouping is
-- now stale for this table).
alter table workflow.definition enable row level security;
create policy tenant_isolation on workflow.definition
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- -----------------------------------------------------------------------------
-- 2. workflow.instance — add the columns src/schema/workflow.ts declares
-- -----------------------------------------------------------------------------

alter table workflow.instance
  add column if not exists revision integer not null default 1,
  add column if not exists terminal boolean not null default false,
  add column if not exists parent_instance_id text,
  add column if not exists parent_step_id text,
  add column if not exists subprocess_depth integer not null default 0,
  add column if not exists sla_due_at timestamptz,
  add column if not exists sla_timer_key text,
  add column if not exists last_transition_id uuid,
  add column if not exists completed_at timestamptz;

-- Backfill `terminal` from the existing status column for any pre-existing rows
-- (default false above only covers new rows going forward).
update workflow.instance
   set terminal = (status in ('completed', 'rejected'))
 where terminal = false and status in ('completed', 'rejected');

alter table workflow.instance
  add constraint instance_parent_fkey
    foreign key (tenant_id, parent_instance_id)
    references workflow.instance(tenant_id, workflow_id);

create index if not exists workflow_instance_listing_idx
  on workflow.instance (tenant_id, definition_id, status, updated_at desc);

create index if not exists workflow_sla_due_idx
  on workflow.instance (sla_due_at)
  where sla_due_at is not null and not terminal;

create index if not exists workflow_parent_idx
  on workflow.instance (tenant_id, parent_instance_id);

-- -----------------------------------------------------------------------------
-- 3. workflow.transition — new durable, append-only transition-history table
-- -----------------------------------------------------------------------------

create table workflow.transition (
  transition_id uuid        primary key default gen_random_uuid(),
  tenant_id     text        not null references iam.tenant(id) on delete cascade,
  instance_id   text        not null,
  action        text        not null,
  actor         text        not null,
  from_step     text,
  to_step       text,
  revision      integer     not null,
  created_at    timestamptz not null default now(),
  foreign key (tenant_id, instance_id)
    references workflow.instance(tenant_id, workflow_id) on delete cascade
);

create index workflow_transition_instance_idx
  on workflow.transition (tenant_id, instance_id, created_at desc);

alter table workflow.transition enable row level security;
create policy tenant_isolation on workflow.transition
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

grant select, insert, update, delete on workflow.definition to dbp_app;
grant select, insert, update, delete on workflow.transition to dbp_app;

-- -----------------------------------------------------------------------------
-- 4. api.workflow_instances view — join must now include tenant_id, since
--    workflow.definition's PK is no longer just (id, version)
-- -----------------------------------------------------------------------------

create or replace view api.workflow_instances
  with (security_invoker = true)
as
  select i.workflow_id, i.tenant_id, i.definition_id, i.definition_version,
         i.status, i.current_step, i.created_at, i.updated_at,
         d.name as definition_name
  from   workflow.instance   i
  join   workflow.definition d on d.tenant_id = i.tenant_id
                               and d.id = i.definition_id
                               and d.version = i.definition_version;
