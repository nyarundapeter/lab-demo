-- =============================================================================
-- 0008_discovery.sql
-- DBP Platform — discovery domain schema (marketplace catalogue)
--
-- Purpose  : Production relational data model (ADR-0039) — the marketplace
--            catalogue: marketplaces, submarketplaces, listing_categories,
--            listings, listing_attributes, listing_media, listing_placements,
--            listing_bundles(+items), filter_definitions/values, service_details.
--
-- Identity : text ids; tenant_id references iam.tenant(id) (D1 = iam-text,
--            2026-07-03). RLS = platform.current_tenant_id(); grants to dbp_app /
--            dbp_readonly; updated_at via platform.set_updated_at() — matches the
--            platform baseline conventions exactly.
--
-- Ordering : apply after the baseline (needs iam.tenant, platform.*), before
--            0009_workspace. FKs flow downward only (discovery -> iam/platform).
-- Idempotent: create ... if not exists / create or replace. Forward-only.
-- Provenance: platform-domain-schemas integration (docs/plans/platform-domain-
--            schemas-integration-design-2026-07-03.md). workspace_id /
--            provider_department_id intentionally dropped (design §6).
-- =============================================================================

create schema if not exists discovery;

grant usage on schema discovery to dbp_app, dbp_readonly;

-- ---------------------------------------------------------------------------
-- discovery.marketplaces — top-level catalogue groupings (Services, Knowledge,
-- Trackers, Analytics, Task Library, ...).
-- ---------------------------------------------------------------------------

create table if not exists discovery.marketplaces (
  id           text        primary key,
  tenant_id    text        not null references iam.tenant(id) on delete cascade,
  key          text        not null,
  name         text        not null,
  description  text,
  status       text        not null default 'active' check (status in ('active','inactive','hidden')),
  sort_order   integer     not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz,
  created_by   text,
  deleted_at   timestamptz,
  unique (tenant_id, key)
);
create index if not exists marketplaces_tenant_idx on discovery.marketplaces (tenant_id);
create index if not exists marketplaces_status_idx on discovery.marketplaces (tenant_id, status);

-- ---------------------------------------------------------------------------
-- discovery.submarketplaces — internal/external zoning within a marketplace.
-- ---------------------------------------------------------------------------

create table if not exists discovery.submarketplaces (
  id           text        primary key,
  tenant_id    text        not null references iam.tenant(id) on delete cascade,
  slug         text        not null,
  name         text        not null,
  tagline      text,
  zone         text        not null check (zone in ('internal','external')),
  sort_order   integer     not null default 0,
  status       text        not null default 'active' check (status in ('active','inactive')),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz,
  created_by   text,
  deleted_at   timestamptz
);
create index if not exists submarketplaces_tenant_idx on discovery.submarketplaces (tenant_id);
create index if not exists submarketplaces_zone_idx   on discovery.submarketplaces (tenant_id, zone);

-- ---------------------------------------------------------------------------
-- discovery.listing_categories — self-referencing category tree per marketplace.
-- ---------------------------------------------------------------------------

create table if not exists discovery.listing_categories (
  id             text        primary key,
  tenant_id      text        not null references iam.tenant(id) on delete cascade,
  marketplace_id text        not null references discovery.marketplaces(id) on delete cascade,
  parent_id      text        references discovery.listing_categories(id),
  name           text        not null,
  slug           text        not null,
  description    text,
  sort_order     integer     not null default 0,
  status         text        not null default 'active' check (status in ('active','inactive')),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz,
  created_by     text,
  deleted_at     timestamptz,
  unique (marketplace_id, slug)
);
create index if not exists listing_categories_tenant_idx  on discovery.listing_categories (tenant_id);
create index if not exists listing_categories_mkt_idx     on discovery.listing_categories (tenant_id, marketplace_id);
create index if not exists listing_categories_parent_idx  on discovery.listing_categories (tenant_id, parent_id);

-- ---------------------------------------------------------------------------
-- discovery.listings — one row per catalogue entry of any type.
-- ---------------------------------------------------------------------------

create table if not exists discovery.listings (
  id                 text        primary key,
  tenant_id          text        not null references iam.tenant(id) on delete cascade,
  marketplace_id     text        not null references discovery.marketplaces(id) on delete cascade,
  submarketplace_id  text        references discovery.submarketplaces(id),
  category_id        text        references discovery.listing_categories(id),
  title              text        not null,
  slug               text        not null,
  summary            text,
  description        text,
  status             text        not null default 'draft' check (status in ('draft','published','archived')),
  owner_id           text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz,
  created_by         text,
  deleted_at         timestamptz,
  unique (marketplace_id, slug)
);
create index if not exists listings_tenant_idx  on discovery.listings (tenant_id);
create index if not exists listings_mkt_idx     on discovery.listings (tenant_id, marketplace_id);
create index if not exists listings_submkt_idx  on discovery.listings (tenant_id, submarketplace_id);
create index if not exists listings_category_idx on discovery.listings (tenant_id, category_id);
create index if not exists listings_status_idx  on discovery.listings (tenant_id, status);
create index if not exists listings_owner_idx   on discovery.listings (tenant_id, owner_id);

-- ---------------------------------------------------------------------------
-- discovery.listing_attributes — key/value/data_type facets (EAV).
-- ---------------------------------------------------------------------------

create table if not exists discovery.listing_attributes (
  id           text        primary key,
  tenant_id    text        not null references iam.tenant(id) on delete cascade,
  listing_id   text        not null references discovery.listings(id) on delete cascade,
  key          text        not null,
  value        text        not null,
  data_type    text        not null default 'text',
  sort_order   integer     not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz,
  unique (listing_id, key)
);
create index if not exists listing_attributes_tenant_idx  on discovery.listing_attributes (tenant_id);
create index if not exists listing_attributes_listing_idx on discovery.listing_attributes (tenant_id, listing_id);

-- ---------------------------------------------------------------------------
-- discovery.listing_media — media attached to a listing (registry only; bytes
-- live wherever this build's file storage is — no platform.files here).
-- ---------------------------------------------------------------------------

create table if not exists discovery.listing_media (
  id           text        primary key,
  tenant_id    text        not null references iam.tenant(id) on delete cascade,
  listing_id   text        not null references discovery.listings(id) on delete cascade,
  file_id      text,
  alt_text     text,
  sort_order   integer     not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz
);
create index if not exists listing_media_tenant_idx  on discovery.listing_media (tenant_id);
create index if not exists listing_media_listing_idx on discovery.listing_media (tenant_id, listing_id);

-- ---------------------------------------------------------------------------
-- discovery.listing_placements — featured/curated slots.
-- ---------------------------------------------------------------------------

create table if not exists discovery.listing_placements (
  id           text        primary key,
  tenant_id    text        not null references iam.tenant(id) on delete cascade,
  listing_id   text        not null references discovery.listings(id) on delete cascade,
  slot         text        not null check (slot in ('home_featured','category_hero','promoted','new')),
  rank         integer     not null default 0,
  starts_at    timestamptz,
  ends_at      timestamptz,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz,
  created_by   text
);
create index if not exists listing_placements_tenant_idx  on discovery.listing_placements (tenant_id);
create index if not exists listing_placements_listing_idx on discovery.listing_placements (tenant_id, listing_id);
create index if not exists listing_placements_slot_idx    on discovery.listing_placements (tenant_id, slot);

-- ---------------------------------------------------------------------------
-- discovery.listing_bundles / listing_bundle_items — grouped listings.
-- ---------------------------------------------------------------------------

create table if not exists discovery.listing_bundles (
  id             text        primary key,
  tenant_id      text        not null references iam.tenant(id) on delete cascade,
  marketplace_id text        not null references discovery.marketplaces(id),
  title          text        not null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz,
  created_by     text
);
create index if not exists listing_bundles_tenant_idx on discovery.listing_bundles (tenant_id);
create index if not exists listing_bundles_mkt_idx    on discovery.listing_bundles (tenant_id, marketplace_id);

create table if not exists discovery.listing_bundle_items (
  bundle_id  text    not null references discovery.listing_bundles(id) on delete cascade,
  listing_id text    not null references discovery.listings(id) on delete cascade,
  quantity   integer not null default 1,
  primary key (bundle_id, listing_id)
);
create index if not exists listing_bundle_items_listing_idx on discovery.listing_bundle_items (listing_id);

-- ---------------------------------------------------------------------------
-- discovery.filter_definitions / filter_values — catalogue filter facets.
-- ---------------------------------------------------------------------------

create table if not exists discovery.filter_definitions (
  id                 text        primary key,
  tenant_id          text        not null references iam.tenant(id) on delete cascade,
  submarketplace_id  text        references discovery.submarketplaces(id),
  key                text        not null,
  label              text        not null,
  filter_type        text        not null default 'single' check (filter_type in ('single','multi')),
  is_shared          boolean     not null default false,
  sort_order         integer     not null default 0,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz,
  created_by         text,
  unique (tenant_id, submarketplace_id, key)
);
create index if not exists filter_definitions_tenant_idx  on discovery.filter_definitions (tenant_id);
create index if not exists filter_definitions_submkt_idx  on discovery.filter_definitions (tenant_id, submarketplace_id);

create table if not exists discovery.filter_values (
  id                     text        primary key,
  tenant_id              text        not null references iam.tenant(id) on delete cascade,
  filter_definition_id   text        not null references discovery.filter_definitions(id) on delete cascade,
  value                  text        not null,
  label                  text        not null,
  sort_order             integer     not null default 0,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz,
  unique (filter_definition_id, value)
);
create index if not exists filter_values_tenant_idx on discovery.filter_values (tenant_id);
create index if not exists filter_values_def_idx    on discovery.filter_values (tenant_id, filter_definition_id);

-- ---------------------------------------------------------------------------
-- discovery.service_details — 1:1 structured extension for service listings.
-- provider_department_id dropped (no platform.departments in this baseline).
-- ---------------------------------------------------------------------------

create table if not exists discovery.service_details (
  listing_id       text        primary key references discovery.listings(id) on delete cascade,
  tenant_id        text        not null references iam.tenant(id) on delete cascade,
  approval         text        not null default 'not_required' check (approval in ('not_required','conditional','required')),
  approval_detail  text,
  risk             text        check (risk in ('standard','governance_sensitive','review_sensitive','at_risk')),
  default_sla      text,
  purpose          text,
  when_to_use      text[]      not null default '{}',
  when_not_to_use  text[]      not null default '{}',
  required_inputs  text[]      not null default '{}',
  fulfilment_path  text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz,
  created_by       text,
  deleted_at       timestamptz
);
create index if not exists service_details_tenant_idx on discovery.service_details (tenant_id);

-- ---------------------------------------------------------------------------
-- updated_at triggers (platform.set_updated_at(), mirrors platform-db pattern)
-- ---------------------------------------------------------------------------

drop trigger if exists marketplaces_set_updated_at on discovery.marketplaces;
create trigger marketplaces_set_updated_at
  before update on discovery.marketplaces
  for each row execute function platform.set_updated_at();

drop trigger if exists submarketplaces_set_updated_at on discovery.submarketplaces;
create trigger submarketplaces_set_updated_at
  before update on discovery.submarketplaces
  for each row execute function platform.set_updated_at();

drop trigger if exists listing_categories_set_updated_at on discovery.listing_categories;
create trigger listing_categories_set_updated_at
  before update on discovery.listing_categories
  for each row execute function platform.set_updated_at();

drop trigger if exists listings_set_updated_at on discovery.listings;
create trigger listings_set_updated_at
  before update on discovery.listings
  for each row execute function platform.set_updated_at();

drop trigger if exists listing_attributes_set_updated_at on discovery.listing_attributes;
create trigger listing_attributes_set_updated_at
  before update on discovery.listing_attributes
  for each row execute function platform.set_updated_at();

drop trigger if exists listing_media_set_updated_at on discovery.listing_media;
create trigger listing_media_set_updated_at
  before update on discovery.listing_media
  for each row execute function platform.set_updated_at();

drop trigger if exists listing_placements_set_updated_at on discovery.listing_placements;
create trigger listing_placements_set_updated_at
  before update on discovery.listing_placements
  for each row execute function platform.set_updated_at();

drop trigger if exists listing_bundles_set_updated_at on discovery.listing_bundles;
create trigger listing_bundles_set_updated_at
  before update on discovery.listing_bundles
  for each row execute function platform.set_updated_at();

drop trigger if exists filter_definitions_set_updated_at on discovery.filter_definitions;
create trigger filter_definitions_set_updated_at
  before update on discovery.filter_definitions
  for each row execute function platform.set_updated_at();

drop trigger if exists filter_values_set_updated_at on discovery.filter_values;
create trigger filter_values_set_updated_at
  before update on discovery.filter_values
  for each row execute function platform.set_updated_at();

drop trigger if exists service_details_set_updated_at on discovery.service_details;
create trigger service_details_set_updated_at
  before update on discovery.service_details
  for each row execute function platform.set_updated_at();

-- ---------------------------------------------------------------------------
-- RLS — tenant isolation only, mirrors platform-db TENANT_SCOPED pattern.
-- ---------------------------------------------------------------------------

alter table discovery.marketplaces enable row level security;
drop policy if exists tenant_isolation on discovery.marketplaces;
create policy tenant_isolation on discovery.marketplaces
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.submarketplaces enable row level security;
drop policy if exists tenant_isolation on discovery.submarketplaces;
create policy tenant_isolation on discovery.submarketplaces
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.listing_categories enable row level security;
drop policy if exists tenant_isolation on discovery.listing_categories;
create policy tenant_isolation on discovery.listing_categories
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.listings enable row level security;
drop policy if exists tenant_isolation on discovery.listings;
create policy tenant_isolation on discovery.listings
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.listing_attributes enable row level security;
drop policy if exists tenant_isolation on discovery.listing_attributes;
create policy tenant_isolation on discovery.listing_attributes
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.listing_media enable row level security;
drop policy if exists tenant_isolation on discovery.listing_media;
create policy tenant_isolation on discovery.listing_media
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.listing_placements enable row level security;
drop policy if exists tenant_isolation on discovery.listing_placements;
create policy tenant_isolation on discovery.listing_placements
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.listing_bundles enable row level security;
drop policy if exists tenant_isolation on discovery.listing_bundles;
create policy tenant_isolation on discovery.listing_bundles
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.listing_bundle_items enable row level security;
drop policy if exists tenant_isolation on discovery.listing_bundle_items;
create policy tenant_isolation on discovery.listing_bundle_items
  using (exists (
    select 1 from discovery.listing_bundles b
    where b.id = listing_bundle_items.bundle_id
      and b.tenant_id = platform.current_tenant_id()
  ))
  with check (exists (
    select 1 from discovery.listing_bundles b
    where b.id = listing_bundle_items.bundle_id
      and b.tenant_id = platform.current_tenant_id()
  ));

alter table discovery.filter_definitions enable row level security;
drop policy if exists tenant_isolation on discovery.filter_definitions;
create policy tenant_isolation on discovery.filter_definitions
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.filter_values enable row level security;
drop policy if exists tenant_isolation on discovery.filter_values;
create policy tenant_isolation on discovery.filter_values
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table discovery.service_details enable row level security;
drop policy if exists tenant_isolation on discovery.service_details;
create policy tenant_isolation on discovery.service_details
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- ---------------------------------------------------------------------------
-- Grants — dbp_app (post-tenant runtime; RLS-enforced)
-- ---------------------------------------------------------------------------

grant select, insert, update, delete on discovery.marketplaces         to dbp_app;
grant select, insert, update, delete on discovery.submarketplaces      to dbp_app;
grant select, insert, update, delete on discovery.listing_categories   to dbp_app;
grant select, insert, update, delete on discovery.listings             to dbp_app;
grant select, insert, update, delete on discovery.listing_attributes   to dbp_app;
grant select, insert, update, delete on discovery.listing_media        to dbp_app;
grant select, insert, update, delete on discovery.listing_placements   to dbp_app;
grant select, insert, update, delete on discovery.listing_bundles      to dbp_app;
grant select, insert, update, delete on discovery.listing_bundle_items to dbp_app;
grant select, insert, update, delete on discovery.filter_definitions   to dbp_app;
grant select, insert, update, delete on discovery.filter_values        to dbp_app;
grant select, insert, update, delete on discovery.service_details      to dbp_app;

grant select on all tables in schema discovery to dbp_readonly;
