-- =============================================================================
-- 0016_notif_status_lifecycle_and_verbs.sql
-- DBP Platform — notif.notification 6-state lifecycle + verb columns (PS.NOTIF
-- NOT-11 / NOT-10, docs/03-features/audits/design-audit-2026-07-17-
-- notification-overlay.md rows A11/A10).
--
-- Purpose:
--   1. Widen the `status` CHECK from ('unread','read') to the full 6-state
--      lifecycle ('unread','read','seen','acknowledged','resolved','archived').
--      Backward-compatible: existing 'unread'/'read' rows remain valid as-is,
--      no data migration needed — the four new states are additive.
--   2. Add `snoozed_until` (nullable timestamptz) — backs POST .../snooze.
--   3. Add `false_positive` (boolean, default false) — backs
--      POST .../false-positive (CriticalCard's onMarkFalsePositive, W5b).
--
-- Ordering : Apply AFTER 0015_rbac_group_tables.sql.
-- Idempotent / forward-only.
-- =============================================================================

alter table notif.notification drop constraint if exists notification_status_check;
alter table notif.notification
  add constraint notification_status_check
  check (status in ('unread', 'read', 'seen', 'acknowledged', 'resolved', 'archived'));

alter table notif.notification
  add column if not exists snoozed_until timestamptz,
  add column if not exists false_positive boolean not null default false;
