-- =============================================================================
-- 0002_seed.sql
-- DBP Platform — default seed data
--
-- Purpose  : Inserts the canonical tenant, roles, permissions, and
--            role-permission matrix that every DBP solution starts with.
--            Mirrors the in-memory fixtures in rbac/server/policy.ts so the
--            DB-backed and in-memory paths stay consistent.
--
-- Ordering : Apply AFTER 0001_platform_rls.sql.
--
-- Idempotent: All inserts use ON CONFLICT DO NOTHING, so this file is safe to
--             re-run and doubles as dev/demo data.  It will not overwrite any
--             manual changes made after the first application.
--
-- Scope    : Platform baseline only.  Optional demo users are NOT seeded here
--            to keep this file safe for production bootstrapping.
-- =============================================================================


-- ---------------------------------------------------------------------------
-- Tenant
-- ---------------------------------------------------------------------------

insert into iam.tenant (id, name)
values ('tenant-alpha', 'Tenant Alpha')
on conflict (id) do nothing;


-- ---------------------------------------------------------------------------
-- Roles (platform-global; tenant_id null)
-- Source: rbac/server/policy.ts ROLES constant
-- ---------------------------------------------------------------------------

insert into rbac.role (id, label, tenant_id) values
  ('finance-approver',       'Finance Approver',        null),
  ('finance-clerk',          'Finance Clerk',            null),
  ('procurement-requester',  'Procurement Requester',    null),
  ('platform-admin',         'Platform Admin',           null)
on conflict (id) do nothing;


-- ---------------------------------------------------------------------------
-- Permissions (platform-global; action + resource is the natural PK)
-- Source: rbac/server/policy.ts PERMISSIONS constant
-- ---------------------------------------------------------------------------

insert into rbac.permission (action, resource, description) values
  ('invoice.approve',            'invoice',          'Approve an invoice submitted by another user.'),
  ('invoice.read',               'invoice',          'Read invoice records.'),
  ('invoice.create',             'invoice',          'Create a new invoice.'),
  ('invoice.update-own',         'invoice',          'Update invoices created by self.'),
  ('purchase-request.create',    'purchase-request', 'Create a purchase request.'),
  ('purchase-request.read-own',  'purchase-request', 'Read own purchase requests.'),
  ('manage',                     'all',              'Superuser: manage all resources.')
on conflict (action, resource) do nothing;


-- ---------------------------------------------------------------------------
-- Role-permission matrix
-- Source: rbac/server/policy.ts MATRIX constant
--
-- Conditions are the CASL declarative predicates stored as JSONB.
-- Keys used:
--   submittedBy.$ne.$userId   — "not submitted by the requesting user" (approve-not-own)
--   submittedBy.$eq.$userId   — "submitted by the requesting user"      (own-record access)
--   tenantId.$eq.$tenantId    — "within the session tenant"             (tenant scoping)
--
-- The unique constraint on rbac.role_permission is:
--   (role_id, action, resource, coalesce(tenant_id, ''))
-- so the ON CONFLICT target mirrors that expression.
--
-- All rows here are platform-global (tenant_id null).
-- ---------------------------------------------------------------------------

insert into rbac.role_permission (role_id, action, resource, condition, tenant_id) values

  -- finance-approver ---------------------------------------------------------
  -- May approve invoices — but NOT invoices they themselves submitted.
  (
    'finance-approver',
    'invoice.approve',
    'invoice',
    '{"submittedBy":{"$ne":"$userId"}}'::jsonb,
    null
  ),
  -- May read all invoices within their tenant.
  (
    'finance-approver',
    'invoice.read',
    'invoice',
    '{"tenantId":{"$eq":"$tenantId"}}'::jsonb,
    null
  ),

  -- finance-clerk ------------------------------------------------------------
  -- May create invoices within their tenant.
  (
    'finance-clerk',
    'invoice.create',
    'invoice',
    '{"tenantId":{"$eq":"$tenantId"}}'::jsonb,
    null
  ),
  -- May read only own invoices.
  (
    'finance-clerk',
    'invoice.read',
    'invoice',
    '{"submittedBy":{"$eq":"$userId"}}'::jsonb,
    null
  ),
  -- May update only own invoices.
  (
    'finance-clerk',
    'invoice.update-own',
    'invoice',
    '{"submittedBy":{"$eq":"$userId"}}'::jsonb,
    null
  ),

  -- procurement-requester ----------------------------------------------------
  -- May create purchase requests within their tenant.
  (
    'procurement-requester',
    'purchase-request.create',
    'purchase-request',
    '{"tenantId":{"$eq":"$tenantId"}}'::jsonb,
    null
  ),
  -- May read only own purchase requests.
  (
    'procurement-requester',
    'purchase-request.read-own',
    'purchase-request',
    '{"submittedBy":{"$eq":"$userId"}}'::jsonb,
    null
  ),

  -- platform-admin -----------------------------------------------------------
  -- Manage all — unconditional full access.
  (
    'platform-admin',
    'manage',
    'all',
    null,
    null
  )

on conflict (role_id, action, resource, coalesce(tenant_id, '')) do nothing;
