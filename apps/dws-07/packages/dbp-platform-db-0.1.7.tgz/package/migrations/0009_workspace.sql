-- =============================================================================
-- 0009_workspace.sql
-- DBP Platform — workspace domain schema (the signed-in working area)
--
-- Purpose  : Production relational data model (ADR-0039) — the request anchor:
--            request_batches, requests (the universal anchor), request_timeline,
--            form_submissions, documents, conversations, messages.
--
-- Identity : text ids; tenant_id -> iam.tenant(id); user/actor cols -> iam."user"(id)
--            (D1 = iam-text). RLS / grants / set_updated_at per baseline convention.
--
-- Ordering : apply after 0008_discovery (requests.listing_id -> discovery.listings),
--            before 0010_operations. FKs downward only (workspace -> discovery/iam/platform).
-- Idempotent / forward-only. Payments/quotes/orders intentionally out of scope (design §6).
-- =============================================================================

create schema if not exists workspace;

grant usage on schema workspace to dbp_app, dbp_readonly;

-- ---------------------------------------------------------------------------
-- workspace.request_batches — "cart"/checkout grouping (created before
-- requests so requests.batch_id can reference it).
-- ---------------------------------------------------------------------------

create table if not exists workspace.request_batches (
  id            text        primary key,
  tenant_id     text        not null references iam.tenant(id) on delete cascade,
  requester_id  text        not null references iam."user"(id),
  status        text        not null default 'open' check (status in ('open','submitted','abandoned')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz,
  created_by    text
);
create index if not exists request_batches_tenant_idx    on workspace.request_batches (tenant_id);
create index if not exists request_batches_requester_idx on workspace.request_batches (tenant_id, requester_id);
create index if not exists request_batches_status_idx    on workspace.request_batches (tenant_id, status);

-- ---------------------------------------------------------------------------
-- workspace.requests — THE universal anchor. Every service/task/knowledge/
-- tracker/analytics interaction is a row here.
-- ---------------------------------------------------------------------------

create table if not exists workspace.requests (
  id             text        primary key,
  tenant_id      text        not null references iam.tenant(id) on delete cascade,
  user_id        text        not null references iam."user"(id),
  type           text        not null,
  status         text        not null default 'draft' check (status in
                  ('draft','submitted','pending_approval','in_review','in_fulfilment',
                   'returned_for_information','closed','cancelled')),
  reference_no   text        not null,
  listing_id     text        references discovery.listings(id),
  batch_id       text        references workspace.request_batches(id),
  source_enquiry_id text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz,
  created_by     text,
  deleted_at     timestamptz,
  unique (tenant_id, reference_no)
);
create index if not exists requests_tenant_idx   on workspace.requests (tenant_id);
create index if not exists requests_user_idx     on workspace.requests (tenant_id, user_id);
create index if not exists requests_type_idx     on workspace.requests (tenant_id, type);
create index if not exists requests_status_idx   on workspace.requests (tenant_id, status);
create index if not exists requests_listing_idx  on workspace.requests (tenant_id, listing_id);
create index if not exists requests_batch_idx    on workspace.requests (tenant_id, batch_id);

-- ---------------------------------------------------------------------------
-- workspace.request_timeline — append-only event log per request.
-- ---------------------------------------------------------------------------

create table if not exists workspace.request_timeline (
  id           text        primary key,
  tenant_id    text        not null references iam.tenant(id) on delete cascade,
  request_id   text        not null references workspace.requests(id) on delete cascade,
  event_type   text        not null,
  description  text,
  actor_id     text        references iam."user"(id),
  created_at   timestamptz not null default now()
);
create index if not exists request_timeline_tenant_idx  on workspace.request_timeline (tenant_id);
create index if not exists request_timeline_request_idx on workspace.request_timeline (tenant_id, request_id);

-- ---------------------------------------------------------------------------
-- workspace.form_submissions — captures required_inputs against a request.
-- ---------------------------------------------------------------------------

create table if not exists workspace.form_submissions (
  id            text        primary key,
  tenant_id     text        not null references iam.tenant(id) on delete cascade,
  request_id    text        not null references workspace.requests(id) on delete cascade,
  form_key      text        not null,
  data          jsonb       not null default '{}'::jsonb,
  submitted_by  text        references iam."user"(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz
);
create index if not exists form_submissions_tenant_idx  on workspace.form_submissions (tenant_id);
create index if not exists form_submissions_request_idx on workspace.form_submissions (tenant_id, request_id);

-- ---------------------------------------------------------------------------
-- workspace.documents — document wallet, attached to a request (registry
-- only; bytes live wherever this build's file storage is).
-- ---------------------------------------------------------------------------

create table if not exists workspace.documents (
  id            text        primary key,
  tenant_id     text        not null references iam.tenant(id) on delete cascade,
  request_id    text        references workspace.requests(id) on delete cascade,
  file_id       text,
  file_name     text        not null,
  doc_type      text,
  uploaded_by   text        references iam."user"(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz,
  deleted_at    timestamptz
);
create index if not exists documents_tenant_idx  on workspace.documents (tenant_id);
create index if not exists documents_request_idx on workspace.documents (tenant_id, request_id);

-- ---------------------------------------------------------------------------
-- workspace.conversations / workspace.messages — request-scoped messaging.
-- ---------------------------------------------------------------------------

create table if not exists workspace.conversations (
  id           text        primary key,
  tenant_id    text        not null references iam.tenant(id) on delete cascade,
  request_id   text        references workspace.requests(id) on delete cascade,
  subject      text,
  status       text        not null default 'open' check (status in ('open','closed')),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz
);
create index if not exists conversations_tenant_idx  on workspace.conversations (tenant_id);
create index if not exists conversations_request_idx on workspace.conversations (tenant_id, request_id);

create table if not exists workspace.messages (
  id               text        primary key,
  tenant_id        text        not null references iam.tenant(id) on delete cascade,
  conversation_id  text        not null references workspace.conversations(id) on delete cascade,
  sender_id        text        references iam."user"(id),
  body             text        not null,
  created_at       timestamptz not null default now()
);
create index if not exists messages_tenant_idx       on workspace.messages (tenant_id);
create index if not exists messages_conversation_idx on workspace.messages (tenant_id, conversation_id);

-- ---------------------------------------------------------------------------
-- updated_at triggers (platform.set_updated_at(), mirrors platform-db pattern)
-- ---------------------------------------------------------------------------

drop trigger if exists request_batches_set_updated_at on workspace.request_batches;
create trigger request_batches_set_updated_at
  before update on workspace.request_batches
  for each row execute function platform.set_updated_at();

drop trigger if exists requests_set_updated_at on workspace.requests;
create trigger requests_set_updated_at
  before update on workspace.requests
  for each row execute function platform.set_updated_at();

drop trigger if exists form_submissions_set_updated_at on workspace.form_submissions;
create trigger form_submissions_set_updated_at
  before update on workspace.form_submissions
  for each row execute function platform.set_updated_at();

drop trigger if exists documents_set_updated_at on workspace.documents;
create trigger documents_set_updated_at
  before update on workspace.documents
  for each row execute function platform.set_updated_at();

drop trigger if exists conversations_set_updated_at on workspace.conversations;
create trigger conversations_set_updated_at
  before update on workspace.conversations
  for each row execute function platform.set_updated_at();

-- request_timeline and messages are append-only — no updated_at trigger.

-- ---------------------------------------------------------------------------
-- RLS — tenant isolation only, mirrors platform-db TENANT_SCOPED pattern.
-- ---------------------------------------------------------------------------

alter table workspace.request_batches enable row level security;
drop policy if exists tenant_isolation on workspace.request_batches;
create policy tenant_isolation on workspace.request_batches
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table workspace.requests enable row level security;
drop policy if exists tenant_isolation on workspace.requests;
create policy tenant_isolation on workspace.requests
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table workspace.request_timeline enable row level security;
drop policy if exists tenant_isolation on workspace.request_timeline;
create policy tenant_isolation on workspace.request_timeline
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table workspace.form_submissions enable row level security;
drop policy if exists tenant_isolation on workspace.form_submissions;
create policy tenant_isolation on workspace.form_submissions
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table workspace.documents enable row level security;
drop policy if exists tenant_isolation on workspace.documents;
create policy tenant_isolation on workspace.documents
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table workspace.conversations enable row level security;
drop policy if exists tenant_isolation on workspace.conversations;
create policy tenant_isolation on workspace.conversations
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

alter table workspace.messages enable row level security;
drop policy if exists tenant_isolation on workspace.messages;
create policy tenant_isolation on workspace.messages
  using      (tenant_id = platform.current_tenant_id())
  with check (tenant_id = platform.current_tenant_id());

-- ---------------------------------------------------------------------------
-- Grants — dbp_app (post-tenant runtime; RLS-enforced)
-- ---------------------------------------------------------------------------

grant select, insert, update, delete on workspace.request_batches    to dbp_app;
grant select, insert, update, delete on workspace.requests           to dbp_app;
grant select, insert, update, delete on workspace.request_timeline   to dbp_app;
grant select, insert, update, delete on workspace.form_submissions   to dbp_app;
grant select, insert, update, delete on workspace.documents          to dbp_app;
grant select, insert, update, delete on workspace.conversations      to dbp_app;
grant select, insert, update, delete on workspace.messages           to dbp_app;

grant select on all tables in schema workspace to dbp_readonly;
