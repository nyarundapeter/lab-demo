-- =============================================================================
-- 0000_platform_init.sql
-- DBP Platform — base schema initialisation
--
-- Purpose  : Creates all extensions, schemas, helper functions, tables, and
--            indexes that back the ten Layer-06 platform services.  This is the
--            fixed platform base; solution-specific entities live in the generic
--            JSONB store (data.entity) and require no additional DDL, or in
--            generated typed tables when storage:'typed' is declared (AF-01).
--
-- Ordering : Apply migrations in sequence on a fresh database:
--              1. 0000_platform_init.sql   ← this file
--              2. 0001_platform_rls.sql    roles · RLS · grants
--              3. 0002_seed.sql            default tenant · roles · permissions
--
-- Target   : PostgreSQL 16 (Supabase project or Azure Database for PostgreSQL).
--            All features used are in vanilla PG 16 — no Supabase-proprietary
--            SQL.  Run once on a fresh database; not intended for incremental
--            re-application (tables use plain CREATE TABLE, not IF NOT EXISTS).
--
-- Schema rename: `auth` is Supabase's reserved GoTrue schema.  All PS.AUTH
--   tables live in the `iam` schema instead.  Never use `auth.*` here.
-- =============================================================================


-- ---------------------------------------------------------------------------
-- Extensions
-- ---------------------------------------------------------------------------

create extension if not exists pgcrypto;   -- gen_random_uuid()
create extension if not exists vector;     -- pgvector — PS.AI embeddings
create extension if not exists pg_trgm;    -- fuzzy text search aid


-- ---------------------------------------------------------------------------
-- Schemas  (one per Layer-06 platform service + the shared platform schema)
-- ---------------------------------------------------------------------------

create schema if not exists platform;
create schema if not exists iam;           -- PS.AUTH (renamed from auth; Supabase reserves auth)
create schema if not exists rbac;
create schema if not exists audit;
create schema if not exists notif;
create schema if not exists search;
create schema if not exists workflow;
create schema if not exists events;
create schema if not exists ai;
create schema if not exists data;
create schema if not exists apigw;


-- ---------------------------------------------------------------------------
-- §4.0  platform — shared infrastructure
--       GUC-based session context helpers.
--       The app sets these GUCs per transaction via withTenant(); RLS reads
--       them to enforce isolation without touching the query itself.
-- ---------------------------------------------------------------------------

-- Returns the tenant_id set for the current transaction (or NULL).
create or replace function platform.current_tenant_id() returns text
  language sql stable as
  $$ select nullif(current_setting('app.tenant_id', true), '') $$;

-- Returns the user_id set for the current transaction (or NULL).
create or replace function platform.current_user_id() returns text
  language sql stable as
  $$ select nullif(current_setting('app.user_id', true), '') $$;

-- Returns the role array from the comma-joined 'app.roles' GUC.
create or replace function platform.current_roles() returns text[]
  language sql stable as
  $$
    select coalesce(
      string_to_array(nullif(current_setting('app.roles', true), ''), ','),
      '{}'
    )
  $$;

-- Predicate: true when the current session carries the given role.
create or replace function platform.has_role(role text) returns boolean
  language sql stable as
  $$ select role = any(platform.current_roles()) $$;

-- Trigger function: stamp updated_at with now() on every UPDATE.
create or replace function platform.set_updated_at() returns trigger
  language plpgsql as
  $$ begin new.updated_at := now(); return new; end $$;


-- ---------------------------------------------------------------------------
-- §4.1  iam — PS.AUTH  (Identity & Access Management)
--
--       Global Identity + Membership model (ADR-0020):
--         iam.tenant     — GLOBAL isolation boundary (no tenant_id column)
--         iam.user       — GLOBAL human identity (one record per human, no tenant_id)
--         iam.identity   — GLOBAL federated login link (no tenant_id; pre-tenant)
--         iam.membership — TENANT-SCOPED join: one row per (tenant, user) pair
--         iam.session    — TENANT-SCOPED active-session registry; tenant_id =
--                          the ACTIVE tenant for this session
--
--       Pre-tenant resolution: iam.resolve_login() is a SECURITY DEFINER
--       function (owned by dbp_owner, called by dbp_auth role).  It reads
--       above RLS to resolve provider+subject → user+memberships without
--       any tenant context set.
-- ---------------------------------------------------------------------------

-- iam.tenant — GLOBAL (one row per client organisation).
-- No tenant_id column; this table IS the isolation boundary.
create table iam.tenant (
  id           text        primary key,           -- slug, e.g. 'tenant-alpha'
  name         text        not null,
  external_id  text,                              -- IdP org id; correlates the same client
                                                  -- across multiple solution databases
  status       text        not null default 'active'
               check (status in ('active', 'suspended', 'archived')),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- iam.user — GLOBAL human identity.
-- No tenant_id: one human, one global record, many tenant memberships.
-- "user" is a reserved SQL keyword; the double-quoted identifier is mandatory
-- everywhere this table is referenced.
create table iam."user" (
  id           text        primary key,           -- string userId; may be the IdP subject
  email        text        not null,
  display_name text        not null,
  status       text        not null default 'active'
               check (status in ('active', 'suspended', 'disabled')),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
-- Global case-insensitive email uniqueness (no tenant prefix; one login per email).
-- Expression-based, so it must be a unique INDEX (not an inline UNIQUE constraint).
create unique index user_email_lower_idx on iam."user" (lower(email));

-- iam.identity — GLOBAL federated login link.
-- No tenant_id: resolved pre-tenant (before any tenant context exists).
-- NOT under RLS; NOT granted to dbp_app — reachable only by dbp_auth via
-- iam.resolve_login() SECURITY DEFINER.
create table iam.identity (
  id          uuid        primary key default gen_random_uuid(),
  user_id     text        not null references iam."user"(id) on delete cascade,
  provider    text        not null,               -- 'password' | 'oidc' | 'entra'
  subject     text        not null,               -- provider sub / email
  secret_hash text,                               -- argon2/bcrypt for 'password'; NEVER plaintext
  created_at  timestamptz not null default now(),
  unique (provider, subject)
);
create index identity_user_idx on iam.identity (user_id);

-- iam.membership — TENANT-SCOPED: carries the tenant↔user relationship.
-- One row per (tenant, user) pair; composite unique is the FK target for
-- rbac.user_role, ensuring role assignments require real membership.
-- Revoking a membership cascades to remove that user's role assignments in
-- that tenant only.
create table iam.membership (
  id         uuid        primary key default gen_random_uuid(),
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  user_id    text        not null references iam."user"(id) on delete cascade,
  status     text        not null default 'active'
             check (status in ('invited', 'active', 'revoked')),
  created_at timestamptz not null default now(),
  unique (tenant_id, user_id)          -- FK target for rbac.user_role composite FK
);
create index membership_user_idx   on iam.membership (user_id);
create index membership_tenant_idx on iam.membership (tenant_id);

-- iam.session — TENANT-SCOPED active-session registry (revocation / refresh).
-- tenant_id = ACTIVE tenant for this session (the tenant the user is currently
-- operating in; a tenant-switch re-mints a new session row / token).
-- user_id = global user (references iam.user.id, not tied to this tenant).
-- Note: stateless JWT flows (ADR-0005) may not need this table; kept for
-- revocation / refresh-token tracking.
create table iam.session (
  id          uuid        primary key default gen_random_uuid(),
  tenant_id   text        not null references iam.tenant(id) on delete cascade,
  user_id     text        not null references iam."user"(id) on delete cascade,
  token_hash  text        not null unique,        -- sha256 of opaque/refresh token
  issued_at   timestamptz not null default now(),
  expires_at  timestamptz not null,
  revoked_at  timestamptz,
  user_agent  text,
  ip          inet
);
create index session_user_idx    on iam.session (tenant_id, user_id);
create index session_expiry_idx  on iam.session (expires_at);

-- iam.resolve_login — pre-tenant identity resolution.
-- SECURITY DEFINER: owned by dbp_owner; executes above tenant RLS.
-- Called by PS.AUTH (via dbp_auth role) to resolve a provider+subject to the
-- global user + all active memberships.  Returns one row per active membership.
-- PS.AUTH then mints a JWT with a `memberships[]` claim.
create or replace function iam.resolve_login(
  p_provider text,
  p_subject  text
) returns table (
  user_id      text,
  email        text,
  display_name text,
  tenant_id    text,
  membership_status text
)
  language sql
  security definer
  stable
as $$
  select
    u.id              as user_id,
    u.email,
    u.display_name,
    m.tenant_id,
    m.status          as membership_status
  from  iam.identity    i
  join  iam."user"      u  on u.id = i.user_id
  join  iam.membership  m  on m.user_id = u.id
  where i.provider = p_provider
    and i.subject  = p_subject
    and u.status   = 'active'
    and m.status   = 'active';
$$;


-- ---------------------------------------------------------------------------
-- §4.2  rbac — PS.RBAC (policy-as-code, DB-backed, tenant-overridable)
-- ---------------------------------------------------------------------------

-- rbac.role — GLOBAL defaults; tenant_id non-null → custom role for that tenant.
create table rbac.role (
  id         text        primary key,             -- 'finance-approver'
  label      text        not null,
  tenant_id  text        references iam.tenant(id) on delete cascade,  -- null = platform-global
  created_at timestamptz not null default now()
);

-- rbac.permission — GLOBAL; (action, resource) is the natural key.
create table rbac.permission (
  action      text not null,                      -- 'invoice.approve'
  resource    text not null,                      -- 'invoice'
  description text,
  primary key (action, resource)
);

-- rbac.role_permission — the CASL matrix; conditions stored as JSONB.
-- Unique index uses coalesce(tenant_id,'') to allow the partial-unique semantics
-- required when tenant_id is NULL (two NULLs would otherwise not clash).
create table rbac.role_permission (
  id        uuid    primary key default gen_random_uuid(),
  role_id   text    not null references rbac.role(id) on delete cascade,
  action    text    not null,
  resource  text    not null,
  condition jsonb,                                -- null = unconditional
                                                  -- e.g. {"submittedBy":{"$ne":"$userId"}}
  tenant_id text    references iam.tenant(id) on delete cascade,  -- null = all tenants
  foreign key (action, resource) references rbac.permission(action, resource) on delete cascade
);
-- Functional unique index: coalesce(tenant_id,'') makes two GLOBAL rows (NULL
-- tenant) collide (a UNIQUE table constraint cannot hold an expression). The
-- ON CONFLICT target in 0002_seed.sql matches this exact expression.
create unique index role_permission_unique_idx
  on rbac.role_permission (role_id, action, resource, coalesce(tenant_id, ''));

-- rbac.user_role — TENANT-SCOPED role assignment.
-- user_id is plain text — integrity is enforced by the composite FK to
-- iam.membership(tenant_id, user_id), which guarantees the user is an active
-- member of this tenant and cascades on membership revocation.
create table rbac.user_role (
  id         uuid        primary key default gen_random_uuid(),
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  user_id    text        not null,
  role_id    text        not null references rbac.role(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (tenant_id, user_id, role_id),
  -- Composite FK to iam.membership: role can only be assigned to an actual member.
  -- Named constraint so it appears clearly in pg_constraint / error messages.
  constraint user_role_membership_fk
    foreign key (tenant_id, user_id) references iam.membership(tenant_id, user_id) on delete cascade
);
create index user_role_lookup_idx on rbac.user_role (tenant_id, user_id);


-- ---------------------------------------------------------------------------
-- §4.3  audit — PS.AUDIT (append-only; UPDATE/DELETE revoked in 0001)
-- ---------------------------------------------------------------------------

create table audit.audit_event (
  id                 uuid        primary key default gen_random_uuid(),
  seq                bigint      generated always as identity,  -- monotonic cursor
  tenant_id          text        not null references iam.tenant(id) on delete cascade,
  ts                 timestamptz not null default now(),
  actor_user_id      text        not null,
  actor_email        text        not null,
  actor_display_name text        not null,
  action             text        not null,
  target_entity_type text        not null,
  target_entity_id   text        not null,
  delta              jsonb
);
create index audit_tenant_seq_idx on audit.audit_event (tenant_id, seq desc);
create index audit_target_idx     on audit.audit_event (tenant_id, target_entity_id, seq desc);


-- ---------------------------------------------------------------------------
-- §4.4  notif — PS.NOTIF
-- ---------------------------------------------------------------------------

create table notif.notification (
  id                uuid        primary key default gen_random_uuid(),
  tenant_id         text        not null references iam.tenant(id) on delete cascade,
  recipient_user_id text        not null,         -- the `to` user id
  type              text        not null,
  message           text        not null,
  link              text,
  channel           text        not null
                    check (channel in ('in-app', 'email', 'sms')),
  status            text        not null default 'unread'
                    check (status in ('unread', 'read')),
  ts                timestamptz not null default now(),
  read_at           timestamptz
);
create index notif_recipient_idx on notif.notification (tenant_id, recipient_user_id, ts desc);
create index notif_unread_idx    on notif.notification (tenant_id, recipient_user_id)
  where status = 'unread';


-- ---------------------------------------------------------------------------
-- §4.5  search — PS.SEARCH (Postgres FTS; tsvector generated column)
-- ---------------------------------------------------------------------------

create table search.search_document (
  id          text        not null,               -- caller-supplied document id
  tenant_id   text        not null references iam.tenant(id) on delete cascade,
  entity_type text        not null,
  title       text        not null,
  body        text,
  fields      jsonb       not null default '{}',  -- flat key-value for filters / facets
  tsv         tsvector    generated always as (
                to_tsvector('english', coalesce(title, '') || ' ' || coalesce(body, ''))
              ) stored,
  updated_at  timestamptz not null default now(),
  primary key (tenant_id, entity_type, id)
);
create index search_tsv_idx    on search.search_document using gin (tsv);
create index search_fields_idx on search.search_document using gin (fields jsonb_path_ops);


-- ---------------------------------------------------------------------------
-- §4.6  workflow — PS.WORKFLOW
-- ---------------------------------------------------------------------------

-- workflow.definition — GLOBAL; versioned workflow templates.
create table workflow.definition (
  id           text        not null,
  version      text        not null,
  name         text        not null,
  initial_step text        not null,
  steps        jsonb       not null,              -- WorkflowStep[]
  created_at   timestamptz not null default now(),
  primary key (id, version)
);

-- workflow.instance — TENANT-SCOPED; one row per running/completed workflow.
create table workflow.instance (
  workflow_id        text        not null,        -- instance id (caller-supplied)
  tenant_id          text        not null references iam.tenant(id) on delete cascade,
  definition_id      text        not null,
  definition_version text        not null,
  status             text        not null
                     check (status in ('running', 'completed', 'rejected')),
  current_step       text,
  steps              jsonb       not null default '[]',  -- StepHistoryEntry[]
  context            jsonb       not null default '{}',
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  primary key (tenant_id, workflow_id),
  foreign key (definition_id, definition_version)
    references workflow.definition(id, version)
);
create index workflow_status_idx on workflow.instance (tenant_id, status, updated_at desc);


-- ---------------------------------------------------------------------------
-- §4.7  events — PS.EVENTS (transactional outbox / append-only event log)
-- ---------------------------------------------------------------------------

-- events.producer_registration — GLOBAL; one row per event type / producer.
create table events.producer_registration (
  event_type text        primary key,
  source     text        not null,
  created_at timestamptz not null default now()
);

-- events.domain_event — append-only log; published_at null = pending dispatch.
-- tenant_id is NULLABLE — platform-global events carry no tenant.
create table events.domain_event (
  seq            bigint      generated always as identity primary key,
  id             uuid        not null default gen_random_uuid(),
  tenant_id      text        references iam.tenant(id) on delete cascade,  -- null = platform-global
  type           text        not null,
  payload        jsonb       not null,
  source         text        not null,
  ts             timestamptz not null default now(),
  correlation_id uuid        not null,
  published_at   timestamptz                       -- null = pending outbox dispatch
);
create index event_type_idx   on events.domain_event (type, seq desc);
create index event_tenant_idx on events.domain_event (tenant_id, seq desc);
create index event_outbox_idx on events.domain_event (seq)
  where published_at is null;


-- ---------------------------------------------------------------------------
-- §4.8  ai — PS.AI (conversations + RAG corpus with pgvector)
-- ---------------------------------------------------------------------------

-- ai.conversation — TENANT-SCOPED; keyed by caller-supplied conversationId.
create table ai.conversation (
  id         text        primary key,             -- conversationId (caller-supplied)
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  user_id    text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ai.message — TENANT-SCOPED; ordered within a conversation by seq.
create table ai.message (
  id              uuid        primary key default gen_random_uuid(),
  tenant_id       text        not null references iam.tenant(id) on delete cascade,
  conversation_id text        not null references ai.conversation(id) on delete cascade,
  role            text        not null check (role in ('user', 'assistant')),
  content         text        not null,
  seq             int         not null,           -- order within conversation
  created_at      timestamptz not null default now(),
  unique (conversation_id, seq)
);
create index ai_message_conv_idx on ai.message (tenant_id, conversation_id, seq);

-- ai.rag_document — TENANT-SCOPED RAG corpus; embedding null until embedded.
-- vector(1536) matches the default PGVECTOR_DIM (OpenAI text-embedding-3-small).
-- The HNSW ANN index is commented out; enable once the corpus is non-trivial.
create table ai.rag_document (
  id         text        not null,
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  scope      text        not null,
  title      text        not null,
  content    text        not null,
  embedding  vector(1536),                        -- null until embedded; keyword fallback used
  tsv        tsvector    generated always as (
               to_tsvector('english', coalesce(title, '') || ' ' || coalesce(content, ''))
             ) stored,
  updated_at timestamptz not null default now(),
  primary key (tenant_id, scope, id)
);
create index rag_tsv_idx on ai.rag_document using gin (tsv);
-- HNSW vector ANN index — enable once corpus is non-trivial:
--   create index rag_embedding_idx on ai.rag_document
--     using hnsw (embedding vector_cosine_ops);


-- ---------------------------------------------------------------------------
-- §4.9  data — PS.DATA (JSONB entity plane + solution schema registry)
--
-- This is the `jsonb` track of the entity storage model (AF-01).
-- Entities declared with storage:'jsonb' (dynamic shapes: forms, prefs, config)
-- land here.  Entities declared with storage:'typed' (default; known-shape
-- relational entities like Invoice, Vendor) land in generated typed tables.
-- ---------------------------------------------------------------------------

-- data.entity_type — GLOBAL schema registry; one row per entity kind registered
-- by the solution at startup (defineEntity).
create table data.entity_type (
  type        text        primary key,            -- lowercase-kebab, e.g. 'invoice'
  json_schema jsonb       not null,               -- Zod-derived JSON Schema
  version     int         not null default 1,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- data.entity — TENANT-SCOPED JSONB store; the jsonb track for dynamic entities.
create table data.entity (
  id         uuid        primary key default gen_random_uuid(),
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  type       text        not null references data.entity_type(type),
  data       jsonb       not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index entity_list_idx on data.entity (tenant_id, type, created_at, id);     -- adapter sort
create index entity_data_idx on data.entity using gin (data jsonb_path_ops);       -- filter queries

-- data.entity_link — optional typed relationships between entities.
create table data.entity_link (
  id         uuid        primary key default gen_random_uuid(),
  tenant_id  text        not null references iam.tenant(id) on delete cascade,
  from_id    uuid        not null references data.entity(id) on delete cascade,
  to_id      uuid        not null references data.entity(id) on delete cascade,
  rel        text        not null,
  created_at timestamptz not null default now(),
  unique (tenant_id, from_id, rel, to_id)
);


-- ---------------------------------------------------------------------------
-- §4.10  apigw — PS.APIGW (route registry / config-as-code)
-- ---------------------------------------------------------------------------

create table apigw.route (
  id         uuid        primary key default gen_random_uuid(),
  path       text        not null unique,
  service    text        not null,
  auth       boolean     not null default true,
  rate_limit int,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);


-- ---------------------------------------------------------------------------
-- updated_at triggers
-- Apply platform.set_updated_at() BEFORE UPDATE on every table that carries
-- an updated_at column.  Naming convention: <table>_set_updated_at.
-- ---------------------------------------------------------------------------

-- iam.tenant
create trigger tenant_set_updated_at
  before update on iam.tenant
  for each row execute function platform.set_updated_at();

-- iam."user"  (quoted — reserved keyword)
create trigger user_set_updated_at
  before update on iam."user"
  for each row execute function platform.set_updated_at();

-- workflow.instance
create trigger instance_set_updated_at
  before update on workflow.instance
  for each row execute function platform.set_updated_at();

-- search.search_document
create trigger search_document_set_updated_at
  before update on search.search_document
  for each row execute function platform.set_updated_at();

-- ai.conversation
create trigger conversation_set_updated_at
  before update on ai.conversation
  for each row execute function platform.set_updated_at();

-- ai.rag_document
create trigger rag_document_set_updated_at
  before update on ai.rag_document
  for each row execute function platform.set_updated_at();

-- data.entity_type
create trigger entity_type_set_updated_at
  before update on data.entity_type
  for each row execute function platform.set_updated_at();

-- data.entity
create trigger entity_set_updated_at
  before update on data.entity
  for each row execute function platform.set_updated_at();

-- apigw.route
create trigger route_set_updated_at
  before update on apigw.route
  for each row execute function platform.set_updated_at();
