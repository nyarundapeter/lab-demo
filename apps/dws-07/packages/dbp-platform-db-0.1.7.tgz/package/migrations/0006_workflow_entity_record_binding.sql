-- =============================================================================
-- 0006_workflow_entity_record_binding.sql
-- DBP Platform — record<->instance binding on workflow.instance (ADR-0038
-- follow-up #4 / PS-WORKFLOW-DB-Design.md "Addendum 2026-07-03")
--
-- Purpose  : Adds nullable entity_type/entity_record_id columns to
--            workflow.instance so "this record's workflow instances" is one
--            indexed lookup, instead of a client-side JSONB context.recordId
--            match. Additive only — no existing column is altered or dropped.
--
-- Ordering : Apply AFTER 0005_tenant_rls_hardening.sql.
-- =============================================================================

alter table workflow.instance
  add column if not exists entity_type text,
  add column if not exists entity_record_id text;

create index if not exists workflow_entity_record_idx
  on workflow.instance (tenant_id, entity_type, entity_record_id);
