-- =============================================================================
-- 0012_workflow_instance_sort_order.sql
-- N19 (Sharavi 2026-07-17) — kanban card order persists server-side via a
-- `sortOrder` field on the PS.WORKFLOW instance schema, superseding the
-- interim client-session-only ordering (K2).
--
-- Ordering: Apply AFTER 0011_workflow_tenant_scoped_definition_and_transitions.sql.
-- =============================================================================

alter table workflow.instance
  add column if not exists sort_order double precision;

create index if not exists workflow_step_sort_order_idx
  on workflow.instance (tenant_id, current_step, sort_order);
