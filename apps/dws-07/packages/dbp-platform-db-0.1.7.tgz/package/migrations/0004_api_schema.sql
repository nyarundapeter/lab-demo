-- =============================================================================
-- 0004_api_schema.sql
-- DBP Platform — curated api schema (PostgREST / Supabase Data API surface)
--
-- Purpose  : Creates the `api` schema and a set of curated platform-level
--            views for use by PostgREST, BI tooling, admin consoles, and
--            external read consumers.
--
-- Design   : PostgREST is configured with PGRST_DB_SCHEMA=api so it only
--            sees `api.*`. Raw service schemas (iam, data, rbac, etc.) are
--            never exposed. All views use security_invoker=true to inherit
--            RLS from their underlying tables.
--
--            Solution-specific Rung-3 views (e.g. api.invoices from Invoice
--            entities) are emitted by the scaffold generator as separate
--            additive migrations — not here.
--
-- Ordering : Apply AFTER 0001_platform_rls.sql (roles must exist).
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Schema
-- ---------------------------------------------------------------------------

create schema if not exists api;

-- ---------------------------------------------------------------------------
-- Views
-- ---------------------------------------------------------------------------

-- Tenant registry (global, no RLS)
create or replace view api.tenants
  with (security_invoker = true)
as
  select id, name, external_id, status, created_at, updated_at
  from   iam.tenant;

-- Global user roster (membership-gated by RLS on iam.user)
create or replace view api.users
  with (security_invoker = true)
as
  select id, email, display_name, status, created_at, updated_at
  from   iam."user";

-- Tenant <-> user join (standard tenant RLS via iam.membership)
create or replace view api.memberships
  with (security_invoker = true)
as
  select m.id, m.tenant_id, m.user_id, m.status, m.created_at,
         u.email, u.display_name
  from   iam.membership  m
  join   iam."user"      u on u.id = m.user_id;

-- RBAC role definitions (global, no RLS)
create or replace view api.roles
  with (security_invoker = true)
as
  select id, label, tenant_id, created_at
  from   rbac.role;

-- Role assignments (standard tenant RLS via rbac.user_role)
create or replace view api.user_roles
  with (security_invoker = true)
as
  select ur.id, ur.tenant_id, ur.user_id, ur.role_id, ur.created_at,
         r.label as role_label,
         u.email as user_email
  from   rbac.user_role  ur
  join   rbac.role       r  on r.id  = ur.role_id
  join   iam."user"      u  on u.id  = ur.user_id;

-- Append-only audit log (standard tenant RLS via audit.audit_event)
create or replace view api.audit_events
  with (security_invoker = true)
as
  select id, seq, tenant_id, ts, actor_user_id, actor_email, actor_display_name,
         action, target_entity_type, target_entity_id, delta
  from   audit.audit_event;

-- Notification feed (standard tenant RLS via notif.notification)
create or replace view api.notifications
  with (security_invoker = true)
as
  select id, tenant_id, recipient_user_id, type, message, link,
         channel, status, ts, read_at
  from   notif.notification;

-- Flat view of the JSONB entity store (standard tenant RLS via data.entity)
create or replace view api.entities
  with (security_invoker = true)
as
  select e.id, e.tenant_id, e.type, e.data, e.created_at, e.updated_at
  from   data.entity e;

-- Workflow instance status (standard tenant RLS via workflow.instance)
create or replace view api.workflow_instances
  with (security_invoker = true)
as
  select i.workflow_id, i.tenant_id, i.definition_id, i.definition_version,
         i.status, i.current_step, i.created_at, i.updated_at,
         d.name as definition_name
  from   workflow.instance   i
  join   workflow.definition d on d.id = i.definition_id
                               and d.version = i.definition_version;

-- ---------------------------------------------------------------------------
-- Grants
-- ---------------------------------------------------------------------------

-- api schema: accessible to dbp_app and dbp_readonly
grant usage on schema api to dbp_app, dbp_readonly;

-- dbp_readonly: SELECT on all views
grant select on all tables in schema api to dbp_readonly;

-- dbp_app: SELECT only (api schema is read-path only; writes go through service schemas)
grant select on all tables in schema api to dbp_app;
