-- =============================================================================
-- 0005_tenant_rls_hardening.sql
-- DBP Platform — membership-gated RLS on iam.tenant (Risk R5 mitigation)
--
-- Purpose  : Restricts dbp_app's view of iam.tenant to only tenants where
--            the current user (platform.current_user_id()) has an active
--            membership. Without this, a dbp_app connection could enumerate
--            all client tenants — a confidentiality issue in multi-client
--            deployments.
--
-- Ordering : Apply AFTER 0001_platform_rls.sql.
--
-- Notes    :
--   1. dbp_owner bypasses RLS (table owner) — migrations and admin scripts
--      retain full access.
--   2. dbp_readonly is also restricted: it sees only tenants for the session
--      user. For unrestricted BI access to all tenants, use dbp_owner.
--   3. New-tenant provisioning (INSERT) is performed by dbp_owner, not
--      dbp_app — so the with check policy will not block provisioning.
--   4. The policy is PERMISSIVE (default), layered with the schema-level
--      grant. If platform.current_user_id() is NULL (no auth context),
--      the subquery returns no rows → zero tenant rows visible.
-- =============================================================================

-- Enable RLS on iam.tenant
alter table iam.tenant enable row level security;

-- Membership-gated visibility policy for dbp_app and dbp_readonly.
-- A tenant is visible only if the current user has an active membership in it.
create policy member_tenant_visibility on iam.tenant
  as permissive
  for select
  to dbp_app, dbp_readonly
  using (
    exists (
      select 1
      from   iam.membership m
      where  m.tenant_id = iam.tenant.id
        and  m.user_id   = platform.current_user_id()
        and  m.status    = 'active'
    )
  );

-- INSERT/UPDATE/DELETE on iam.tenant remains dbp_owner-only
-- (dbp_app has SELECT, INSERT, UPDATE, DELETE grants from 0001 — restrict
-- to SELECT for the app role to harden tenant mutation).
-- NOTE: If runtime tenant provisioning via dbp_app is required in the future,
-- replace this with a SECURITY DEFINER function (iam.provision_tenant).
revoke insert, update, delete on iam.tenant from dbp_app;
