-- =============================================================================
-- 0012_entity_version_updated_by.sql
-- DBP Platform — data.entity gains `version` + `updated_by`
--
-- Purpose: spec-ps-data-revisions-2026-07-17.md (PS.DATA revision/ETag
-- concurrent-editing). src/schema/data.ts now declares `version` (optimistic
-- concurrency token, SP-DATA-PATTERNS AC-4) and `updated_by` (actor userId
-- from the PS.AUTH session context) on data.entity — neither column existed
-- before this migration; DrizzleEntityStorageAdapter.put() requires `version`
-- for its conditional `WHERE version = $expected` UPDATE.
--
-- Backfill: existing rows have no version history, so every existing row
-- starts at version 1 (matches the in-memory handler's create-time default).
-- `updated_by` has no reliable historical actor to backfill — left null.
--
-- Ordering : Apply AFTER 0011_workflow_tenant_scoped_definition_and_transitions.sql.
-- =============================================================================

alter table data.entity
  add column if not exists version integer not null default 1,
  add column if not exists updated_by text;
