-- =============================================================================
-- 0012_entity_composite_type_id_identity.sql
-- DBP Platform — data.entity: composite (type, id) upsert identity
--   (STCB GG-06/GG-07/GG-22, docs/09-plans/seed-migration-ownership-design-2026-07-25.md)
--
-- Purpose  : data.entity.id is the sole primary key; DrizzleEntityStorageAdapter.put()
--            upserted on `target: entity.id` alone. The read path (get/list) already
--            filters by (id AND type). The generator emits fixture ids
--            (demoRecordSeed/demoCatalogItemSeed) that collide with domain-array ids
--            across several apps' manifests — on Postgres the demo put silently
--            overwrote the domain row's `data` while `type` stayed unchanged, and
--            because reads are type-filtered, the demo row probed "absent" forever,
--            defeating any row-existence seed gate. This migration adds a composite
--            unique index on (type, id) so the upsert conflict target can match the
--            read path's identity.
--
-- Ordering : Apply after 0011. `id` remains the primary key (entity_link.from_id/
--            to_id FK-reference data.entity(id), which requires `id` to stay a
--            unique/PK target) — this migration is additive, not a PK replacement.
-- =============================================================================

alter table data.entity
  add constraint entity_type_id_uniq unique (type, id);
