import { defineConfig } from "drizzle-kit";

export default defineConfig({
  schema: "./src/schema/index.ts",
  out: "./migrations",
  dialect: "postgresql",
  dbCredentials: {
    url: process.env.DIRECT_URL!,
  },
  schemaFilter: [
    "iam",
    "rbac",
    "audit",
    "notif",
    "search",
    "workflow",
    "events",
    "ai",
    "data",
    "apigw",
    "platform",
    "api",
  ],
});
