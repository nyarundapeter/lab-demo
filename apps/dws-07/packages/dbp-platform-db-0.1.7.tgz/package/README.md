# @dbp/platform-db

The base Postgres database layer backing all ten Layer-06 platform services (PS.AUTH through PS.APIGW). Every generated solution starts from the same baseline migration — identical DDL, zero per-solution tables needed. Solution-specific business entities (invoices, vendors, …) live in the generic JSONB store (`data.entity`) with runtime schema registration; no DDL is required per solution.

**Tier:** platform-db

## Exports
| Export | Path |
|---|---|
| `.` | `./dist/index.js` (types: `./dist/index.d.ts`) — re-exports `schema`, `client`, `adapters`, `contracts` |
| `./schema` | `./dist/schema/index.js` (types: `./dist/schema/index.d.ts`) |
| `./client` | `./dist/client.js` (types: `./dist/client.d.ts`) |

`publishConfig` targets a local Verdaccio registry (`http://localhost:4873`) but the `exports` map itself is unchanged from the above — no dist split beyond what's already listed.

## Config schema
N/A — no Zod config schema in this package. `src/contracts.ts` defines the `Session` shape (`{ tenantId, userId?, roles? }`) consumed by `withTenant`; `src/schema/` holds the Drizzle table definitions (source of truth for DDL diffing via `db:generate`).

## Quick start (minimal steps)

1. Copy `.env.example` to `.env` and fill in `DATABASE_URL` and `DIRECT_URL` (see Substrate section below).
2. Open a Supabase SQL editor (or `psql`) connected as `dbp_owner` and apply the migrations in order:
   ```
   migrations/0000_platform_init.sql   — extensions, schemas, tables, indexes
   migrations/0001_platform_rls.sql    — roles, RLS policies, GUC helpers, grants
   migrations/0002_seed.sql            — tenant-alpha, 4 roles, 7 permissions, matrix
   ```
   The three SQL files are authored by the SQL migration task; they are the apply-first path.
3. Done — the platform base schema is ready. All ten services are backed.

> **Drizzle-forward (after baseline).** Run `pnpm db:generate` to baseline subsequent schema changes as `0003+` migrations. The schema in `src/schema/` is the diff source; mark `0000–0002` as already applied in drizzle-kit's journal.

---

## Schema → service map

| Postgres schema | Platform service |
|---|---|
| `auth`     | PS.AUTH — tenant, user, identity, session |
| `rbac`     | PS.RBAC — role, permission, policy matrix |
| `audit`    | PS.AUDIT — append-only event log |
| `notif`    | PS.NOTIF — in-app / email / SMS notifications |
| `search`   | PS.SEARCH — Postgres FTS (tsvector) |
| `workflow` | PS.WORKFLOW — definition + instance |
| `events`   | PS.EVENTS — domain event log + transactional outbox |
| `ai`       | PS.AI — conversation, message, RAG corpus (pgvector) |
| `data`     | PS.DATA — JSONB entity store + schema registry |
| `apigw`    | PS.APIGW — route config registry |
| `platform` | Shared — GUC helpers, extensions, `updated_at` trigger |

---

## `withTenant` — per-request RLS context

Every request that touches a tenant-scoped table must be wrapped in `withTenant`. It opens a transaction, sets the three transaction-local GUCs that RLS reads, then runs your query function. RLS transparently scopes every query to the correct tenant — no manual `where tenant_id = ?` required.

```ts
import { db, withTenant } from "@dbp/platform-db/client";
import { entity } from "@dbp/platform-db/schema";
import { eq } from "drizzle-orm";

const invoices = await withTenant(session, (tx) =>
  tx.select().from(entity).where(eq(entity.type, "invoice"))
);
```

The GUCs set are:
- `app.tenant_id` — used by all `tenant_isolation` RLS policies
- `app.user_id` — available for ownership predicates
- `app.roles` — comma-joined; used by role predicates in PS.RBAC

`session` is `{ tenantId: string; userId?: string; roles?: string[] }` — a subset of the contracts `Session` type.

---

## Supabase ↔ Azure portability

Two connection strings (the Supabase-standard split; Azure Flexible Server satisfies the same interface):

```
DATABASE_URL=postgresql://dbp_app:...@<pooled-host>:6543/postgres?pgbouncer=true
DIRECT_URL=postgresql://dbp_owner:...@<direct-host>:5432/postgres
```

- `DATABASE_URL` — pooled (PgBouncer transaction mode), used by the app runtime. Set `prepare: false` for PgBouncer compatibility (already set in `client.ts`).
- `DIRECT_URL` — direct connection, used by `drizzle-kit` for migrations.

Portability rules (moving to Azure = a connection-string change only):
- No Supabase-proprietary SQL. Tenant context is set via `current_setting('app.*')`, never `auth.uid()`.
- `pgcrypto`, `vector` (pgvector), `pg_trgm` are available on both substrates. On Azure Flexible Server, add them to the `azure.extensions` allowlist server parameter, then `CREATE EXTENSION`.
- pgvector dimension (1536 for `ai.rag_document.embedding`) matches OpenAI `text-embedding-3-small` / `ada-002`. Adjust via the `PGVECTOR_DIM` env var in your embedding service if using a different model.

---

## SQL migration files

The three hand-authored SQL files in `migrations/` are owned by a parallel task — do not edit them here. Reference only:

| File | Contents |
|---|---|
| `0000_platform_init.sql` | Extensions, all 11 schemas, all tables, indexes, check constraints, generated tsvector columns, GUC helper functions, `updated_at` trigger |
| `0001_platform_rls.sql`  | Database roles (`dbp_app`, `dbp_readonly`), RLS enable + `tenant_isolation` policies, column-level grants, append-only audit grants |
| `0002_seed.sql`          | `tenant-alpha`, 4 roles, 7 permissions, role-permission matrix — idempotent (`ON CONFLICT DO NOTHING`) |

## Consumed by

Generator emit + app direct import. `scripts/scaffold-solution.mjs` adds `"@dbp/platform-db": "workspace:*"` as a dependency for persistent-storage solutions (line ~1260), declares it in `serverExternalPackages`/`serverComponentsExternalPackages` for the data route (~1761–1765), and documents `pnpm --filter @dbp/platform-db db:migrate` in generated onboarding docs (~2831). Generated apps import it directly, e.g. `apps/dws-03/app/**` imports `{ withTenant, listings, marketplaces } from "@dbp/platform-db"` in server-only route/service files.

## Shipping

Within the monorepo, `@dbp/platform-db` resolves via normal pnpm workspace linking (`workspace:*`) — no build step needed for consumption during development. For standalone/client delivery it ships as a packed tarball via the tarball + `.pnpmfile.cjs` mechanism described in `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.

## Migration governance policy

Solution-owned migrations built on this baseline (`db/migrations/<solution-schema>/` in a
generated app) are governed by a factory-wide policy — migration-only schema changes,
replayability, release-folder naming, one-table-one-lineage — see
`docs/02-guides/02-operations/database-migrations-policy.md` and its implementing spec
`docs/03-features/specs/spec-migration-governance-2026-07-11.md`. This package's own
`migrations/` (the vendored platform baseline, §"SQL migration files" above) is exempt from the
solution-facing rules in that policy — it is drizzle-diff-sourced and re-synced via
`scripts/sync-platform-migrations.mjs`, not authored release-by-release.
