# @dbp/ps-ai

registryId: `PS.AI`

Single AI surface for DBP solutions: assistant conversations (streaming SSE),
RAG-backed search over registered content, and deterministic recommendations.
Solutions consume the client SDK and never embed model calls or roll their own
AI logic — all model traffic routes through the `AiGatewayAdapter` seam, the
PromptOps governance boundary. Maps to DIA.03 (AIOps).

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `./client/index.ts` (source) / `./dist/client/index.js` (published) |
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |

`publishConfig.exports` splits both entries to `dist/` with `.d.ts` types — same subpaths, built output only.

## Config schema
See `contract.yaml` (OpenAPI 3.0.3, generated via `pnpm contracts:gen` from Zod schemas — never hand-edited).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` registers `PS.AI` (dir `ai`, package `@dbp/ps-ai`, base path `/api/platform/ai`) and wires `configureAiClient` from `@dbp/ps-ai/client` into generated solution bootstrap.

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client delivery, ships as a packed `.tgz` tarball committed into the standalone's `packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
