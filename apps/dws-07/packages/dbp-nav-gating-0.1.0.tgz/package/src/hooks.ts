"use client";

import { useContext } from "react";
import { FeatureFlagsContext } from "@dbp/flags";
import { useContextualAbility } from "@dbp/ps-org/client";
import type { GatableNavItem } from "./types.js";
import { applyGating } from "./resolve.js";

/**
 * Filters a nav item array based on the current user's flags and org-contextual ability.
 *
 * - Feature flags are read from `<FeatureFlagsProvider>` (required in the tree).
 * - RBAC ability is read from `useContextualAbility()` — org-aware when `<OrgContextProvider>`
 *   is in the tree, tenant-level otherwise.
 * - Items without `gating` pass through unchanged (zero overhead path).
 * - Returns the full list while ability is loading (optimistic).
 */
export function useGatedNav(navItems: GatableNavItem[]): GatableNavItem[] {
  const flags = useContext(FeatureFlagsContext) ?? {};
  const ability = useContextualAbility();
  return applyGating(navItems, flags, ability);
}
