export type { GatableNavItem, NavGating, NavGatingMode, GatingResult } from "./types.js";
export { resolveNavGating, applyGating } from "./resolve.js";
export { useGatedNav } from "./hooks.js";
