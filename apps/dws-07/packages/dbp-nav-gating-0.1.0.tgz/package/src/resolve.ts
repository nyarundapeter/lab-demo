import type { MongoAbility } from "@casl/ability";
import type { GatableNavItem, GatingResult } from "./types.js";

/**
 * Pure function — resolves a nav item to its visibility state.
 * All three outcomes are stateless: same inputs always produce same output.
 *
 * - `visible`  — user passes all active gates; item renders normally.
 * - `hidden`   — user fails a gate with hiddenBehavior: "hide"; item is removed.
 * - `disabled` — user fails a gate with hiddenBehavior: "disable"; item renders with aria-disabled.
 */
export function resolveNavGating(
  item: GatableNavItem,
  flags: Record<string, boolean>,
  ability: MongoAbility | null,
): GatingResult {
  const { gating } = item;
  if (!gating || gating.modes.length === 0) return "visible";

  const { modes, requiredPermission, featureFlag, hiddenBehavior } = gating;

  for (const mode of modes) {
    if (mode === "flag-based") {
      if (featureFlag && !flags[featureFlag]) {
        return hiddenBehavior === "disable" ? "disabled" : "hidden";
      }
    } else if (mode === "rbac") {
      if (!ability) {
        // Ability not yet resolved (loading) — optimistic: show item.
        continue;
      }
      if (requiredPermission) {
        // Permission string format: "action.subject" e.g. "task.read" → can("task.read", "task")
        // We treat the full string as the action and derive subject as the part before the first dot.
        const [subject] = requiredPermission.split(".");
        if (!ability.can(requiredPermission, subject ?? requiredPermission)) {
          return hiddenBehavior === "disable" ? "disabled" : "hidden";
        }
      }
    }
  }

  return "visible";
}

/**
 * Applies `resolveNavGating` to a flat list of nav items.
 * Hidden items are removed; disabled items have their `href` stripped and
 * `aria-disabled: true` noted via the `_disabled` marker.
 */
export function applyGating(
  items: GatableNavItem[],
  flags: Record<string, boolean>,
  ability: MongoAbility | null,
): GatableNavItem[] {
  const result: GatableNavItem[] = [];
  for (const item of items) {
    const state = resolveNavGating(item, flags, ability);
    if (state === "hidden") continue;
    if (state === "disabled") {
      // Strip href so the shell renders as a disabled anchor rather than a live link.
      const { href: _omit, ...rest } = item;
      result.push({ ...rest, gating: item.gating } as GatableNavItem);
    } else {
      result.push(item);
    }
  }
  return result;
}
