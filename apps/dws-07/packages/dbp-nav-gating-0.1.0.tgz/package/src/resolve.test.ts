import { describe, it, expect } from "vitest";
import type { MongoAbility } from "@casl/ability";
import { resolveNavGating, applyGating } from "./resolve.js";
import type { GatableNavItem } from "./types.js";

function makeAbility(allow: Record<string, boolean>): MongoAbility {
  return {
    can: (action: string) => allow[action] ?? false,
  } as unknown as MongoAbility;
}

const NO_FLAGS = {};
const ALL_FLAGS: Record<string, boolean> = { tasks_module: true };
const FULL_ABILITY = makeAbility({ "task.read": true });
const EMPTY_ABILITY = makeAbility({});

const ungated: GatableNavItem = { id: "home", label: "Home", href: "/home" };

const flagGated: GatableNavItem = {
  id: "tasks",
  label: "Tasks",
  href: "/tasks",
  gating: { modes: ["flag-based"], featureFlag: "tasks_module", hiddenBehavior: "hide" },
};

const rbacGated: GatableNavItem = {
  id: "tasks",
  label: "Tasks",
  href: "/tasks",
  gating: { modes: ["rbac"], requiredPermission: "task.read", hiddenBehavior: "hide" },
};

const disableGated: GatableNavItem = {
  id: "tasks",
  label: "Tasks",
  href: "/tasks",
  gating: { modes: ["rbac"], requiredPermission: "task.read", hiddenBehavior: "disable" },
};

const comboGated: GatableNavItem = {
  id: "tasks",
  label: "Tasks",
  href: "/tasks",
  gating: { modes: ["flag-based", "rbac"], featureFlag: "tasks_module", requiredPermission: "task.read", hiddenBehavior: "hide" },
};

describe("resolveNavGating", () => {
  it("ungated item → visible", () => {
    expect(resolveNavGating(ungated, NO_FLAGS, null)).toBe("visible");
  });

  it("flag-based: flag off → hidden", () => {
    expect(resolveNavGating(flagGated, NO_FLAGS, null)).toBe("hidden");
  });

  it("flag-based: flag on → visible", () => {
    expect(resolveNavGating(flagGated, ALL_FLAGS, null)).toBe("visible");
  });

  it("rbac: no ability (loading) → visible (optimistic)", () => {
    expect(resolveNavGating(rbacGated, NO_FLAGS, null)).toBe("visible");
  });

  it("rbac: ability denies → hidden", () => {
    expect(resolveNavGating(rbacGated, NO_FLAGS, EMPTY_ABILITY)).toBe("hidden");
  });

  it("rbac: ability allows → visible", () => {
    expect(resolveNavGating(rbacGated, NO_FLAGS, FULL_ABILITY)).toBe("visible");
  });

  it("hiddenBehavior: disable → disabled when denied", () => {
    expect(resolveNavGating(disableGated, NO_FLAGS, EMPTY_ABILITY)).toBe("disabled");
  });

  it("combo: both must pass — flag off → hidden even with ability", () => {
    expect(resolveNavGating(comboGated, NO_FLAGS, FULL_ABILITY)).toBe("hidden");
  });

  it("combo: both must pass — ability denies → hidden even with flag", () => {
    expect(resolveNavGating(comboGated, ALL_FLAGS, EMPTY_ABILITY)).toBe("hidden");
  });

  it("combo: both pass → visible", () => {
    expect(resolveNavGating(comboGated, ALL_FLAGS, FULL_ABILITY)).toBe("visible");
  });
});

describe("applyGating", () => {
  it("removes hidden items", () => {
    const items = [ungated, flagGated];
    const result = applyGating(items, NO_FLAGS, null);
    expect(result).toHaveLength(1);
    expect(result[0]?.id).toBe("home");
  });

  it("strips href from disabled items", () => {
    const items = [disableGated];
    const result = applyGating(items, NO_FLAGS, EMPTY_ABILITY);
    expect(result).toHaveLength(1);
    expect(result[0]?.href).toBeUndefined();
  });

  it("passes all items when no gating declared", () => {
    const items = [ungated, { id: "x", label: "X", href: "/x" }];
    const result = applyGating(items, NO_FLAGS, EMPTY_ABILITY);
    expect(result).toHaveLength(2);
  });
});
