import type { NavItem } from "@dbp/contracts/shell-nav";

export type NavGatingMode = "flag-based" | "rbac";

export type NavGating = {
  modes: NavGatingMode[];
  requiredPermission?: string;
  featureFlag?: string;
  hiddenBehavior: "hide" | "disable";
};

/**
 * A nav item that optionally carries gating metadata.
 * Drop-in replacement for NavItem — items without `gating` pass through unchanged.
 */
export interface GatableNavItem extends NavItem {
  gating?: NavGating;
}

export type GatingResult = "visible" | "hidden" | "disabled";
