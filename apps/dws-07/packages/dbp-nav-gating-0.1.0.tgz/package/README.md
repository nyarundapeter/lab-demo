# @dbp/nav-gating

Resolves which navigation items a user can see, combining CASL ability checks (RBAC) with `@dbp/flags` feature-flag state. Exports `resolveNavGating`/`applyGating` (pure resolution logic operating on `GatableNavItem[]`) and a `useGatedNav` React hook for wiring the result into a nav component. Depends on `@dbp/contracts` (nav item shapes), `@dbp/flags`, and `@dbp/ps-org` (org/tenant context for ability checks).

**Tier:** shared

## Exports
| Export | Path |
|---|---|
| `.` | `./src/index.ts` |

No `publishConfig.exports` override — ships raw TypeScript source.

## Config schema
N/A — no config schema in this package; it consumes `GatableNavItem`/`NavGating` types (`src/types.ts`) and evaluates them against `@dbp/flags` and CASL abilities rather than defining its own Zod schema.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` emits `import { useGatedNav, type GatableNavItem } from "@dbp/nav-gating";` into generated standard-nav code when a solution's nav config needs gating.

## Shipping
Workspace package during monorepo development (`workspace:*`). For standalone repos, it ships as a committed tarball (`file:packages/dbp-nav-gating-0.1.0.tgz`) resolved via `.pnpmfile.cjs` — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
