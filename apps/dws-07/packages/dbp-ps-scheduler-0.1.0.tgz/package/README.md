# @dbp/ps-scheduler

Minimal PS.SCHEDULER slice (SP-8 / ADR-0037), scoped to workflow SLA timers
only. Server-only package (`createRouteHandlers`, `fireTimer`,
`scheduleSlaTimer`, `isInngestConfigured`) built on top of Inngest as an
optional peer dependency — when `INNGEST_EVENT_KEY`/`INNGEST_SIGNING_KEY` are
absent, the package never imports `inngest` and its route handlers return 404,
and `@dbp/ps-workflow`'s own lazy-evaluation fallback handles SLA breaches
instead. Per the platform-services import-boundary rules this package may
import only `@dbp/contracts` from the workspace — it cannot import
`@dbp/ps-workflow/server` directly; the mounting app supplies a
`fetchInstance` callback that dispatches into PS.WORKFLOW's
`GET /instances/:id`.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |

`publishConfig.exports` splits the entry to `dist/` with `.d.ts` types — same subpath, built output only. No `./client` export — this package has no client-side surface.

## Config schema
N/A — no Zod config schema in this package (input/output types are plain TS interfaces in `server/logic.ts` and `server/inngest.ts`).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` adds `@dbp/ps-scheduler` as a workspace dependency whenever a workflow route mount is generated, and generates the app's own `/api/platform/scheduler/inngest` route as the sole place that imports both `@dbp/ps-scheduler/server` and `@dbp/ps-workflow/server` (bridging the import-boundary restriction described above).

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client delivery, ships as a packed `.tgz` tarball committed into the standalone's `packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
