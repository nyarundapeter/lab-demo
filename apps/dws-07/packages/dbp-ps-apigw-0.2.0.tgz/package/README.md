# @dbp/ps-apigw

registryId: `PS.APIGW`

Gateway config-as-code: the authoritative registry of which API paths are
exposed externally, which service handles each path, which auth mode is
required, and what rate limits apply. Solutions and services register their
routes here at startup.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `./client/index.ts` (source) / `./dist/client/index.js` (published) |
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |

`publishConfig.exports` splits both entries to `dist/` with `.d.ts` types — same subpaths, built output only.

## Config schema
Two generated artefacts: `contract.yaml` (OpenAPI 3.0.3) and `gateway-config.schema.json` (JSON Schema), both generated via `pnpm contracts:gen` — never hand-edited.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` registers `PS.APIGW` (dir `apigw`, package `@dbp/ps-apigw`, base path `/api/platform/apigw`) and wires `configureApigwClient` from `@dbp/ps-apigw/client` into generated solution bootstrap.

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client delivery, ships as a packed `.tgz` tarball committed into the standalone's `packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
