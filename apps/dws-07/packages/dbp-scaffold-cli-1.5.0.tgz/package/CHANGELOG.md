# Changelog

All notable changes to `@dbp/scaffold-cli` are documented here.

## [1.5.0] - 2026-07-27

Version realignment to `docs/REGISTRY.yaml#blueprint_version` (`platform/v1.5.0`), plus the
generator fixes that landed in the platform since 1.4.1.

This package pins its version to the blueprint version by design, but nothing enforced it: the
platform bump touches six mirror locations and this package was in none of them, so it silently
stayed on 1.4.1 while the platform moved to 1.5.0. A consumer regenerating from a v1.5.0 export
would have run a two-releases-old generator. Now covered by
`packages/shared/scaffold-tools/src/__tests__/scaffold-cli-version-alignment.test.ts`, so the
drift fails a gate instead of shipping.

The toolchain this package vendors gains, since 1.4.1: the `pageComponent` seam fixes (kebab-case
component identifiers, emitted-test import paths, the `Button` import missing from body-only
pages), sweep-ownership on regen, demo-catalog fixture-id namespacing, and multi-mode feature
config validation.

## [1.4.1] - 2026-07-26

Initial release. WS-7 phase 1 (packaging + provenance): the generator toolchain
(`scaffold-solution.mjs`, `regen-standalone.mjs`, `scaffold-dry-run.mjs`, and the
standard-menu/theme-policy/quality-ratchet scripts previously copied loose by
`export-standalone.sh`) is now packaged as a versioned `@dbp/*` workspace package,
packed into every standalone export's `packages/` tarball set through the existing
pack loop. Version pinned to `1.4.1` to match `docs/REGISTRY.yaml#blueprint_version`
(`platform/v1.4.1`) at time of packaging.

Also lands: `scripts/regen-standalone.mjs` now refuses to run when the installed
`@dbp/scaffold-cli` version and the standalone's `blueprint-release.json#blueprint_version`
disagree (`scripts/lib/version-skew.mjs`), per the WS-7 ruling "regen only with matching
blueprint_version — bump together".
