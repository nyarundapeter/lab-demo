# @dbp/scaffold-cli

Versioned, vendored packaging of the DBP generator toolchain, shipped inside every
standalone export so builders can run `pnpm regen` locally instead of waiting on a
hand-merged diff from the platform team (WS-7,
`docs/09-plans/standalone-self-regen-design-2026-07-26.md`).

## What it ships

The canonical sources live in the monorepo's `scripts/` dir and are owned by whoever
maintains `scaffold-solution.mjs` — this package **wraps** them, it does not fork or
rewrite them. Its `prepack` lifecycle script (`prepack/copy-sources.mjs`) copies the
current content of `scripts/` into `src/` immediately before every `pnpm pack`, so the
tarball always carries exactly what's in `scripts/` at pack time:

- `scaffold-solution.mjs` — the generator itself (standalone-mode aware)
- `regen-standalone.mjs` — the builder "one file" workflow (`pnpm regen`)
- `scaffold-dry-run.mjs` — the `--dry-run` diff report
- `standard-menu-scaffold.mjs`, `standard-menu.json`, `standard-menu-layout-map.json`,
  `theme-policy.mjs` — standard nav/theme scaffolding
- `check-generated-conformance.mjs`, `check-coverage-ratchet.mjs`,
  `check-structured-logs.mjs`, `check-negative-case-heuristic.mjs`,
  `probe-tenant-rls.mjs`, `reconcile-ratchet.mjs` — quality ratchet gates
- `lib/`, `db-governance-templates/` — shared helpers and DB governance templates

## Distribution

Committed tarball, not a private npm registry — matches every other `@dbp/*` package
in this repo. `export-standalone.sh` packs this package through the same
`pnpm -r --filter './packages/**' exec -- pnpm pack` loop as every other platform
package (no separate mechanism); the standalone's `package.json#scripts.regen`/
`scripts.scaffold` invoke it via `node_modules/@dbp/scaffold-cli/src/*.mjs`.

## Versioning

`package.json#version` is kept aligned with `docs/REGISTRY.yaml#blueprint_version`
(stripped of its `platform/v` prefix) — see
`docs/02-guides/02-operations/package-versioning-and-updates.md`. Bump this package's
version and `blueprint_version` together in the same blueprint release; a standalone's
`regen-standalone.mjs` refuses to run when the two disagree (`scripts/lib/version-skew.mjs`).

## Not published to npm

This package is not intended for `pnpm add @dbp/scaffold-cli` from outside a
factory-driven export — see the "Distribution decision" open question in the WS-7
design doc for when that might change.
