#!/usr/bin/env node
/**
 * scaffold-solution — Phase 5 scaffold generator.
 *
 * Usage:
 *   pnpm scaffold -- <path-to-SOLUTION.md> [--out-dir <dir>] [--force]
 *
 * Pipeline:
 *   1. Parse SOLUTION.md YAML frontmatter → validate against SolutionManifestSchema
 *   2. Resolve against REGISTRY.yaml (shells, features, services)
 *   3. Validate each feature config against the feature's Zod contract (via tsx import)
 *   4. Emit apps/<solution-dir>/ as a Next 15 App Router app
 *   5. Write resolved solution/_arch/SOLUTION.md
 *   6. Print a wiring summary
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { parseArgs } from "node:util";
import { execFileSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import YAML from "yaml";
import { demoEntities, demoWorkflow, KANBAN_DEFINITION_ID, buildNavSections as buildStdNavSections, buildModules as buildStdModules } from "./standard-menu-scaffold.mjs";
import { assertThemeColours } from "./theme-policy.mjs";
import { validateNavSectionIds, validateSidebarAreas } from "./nav-validation.mjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const REPO_ROOT = path.resolve(__dirname, "..");

// ── Standalone mode ───────────────────────────────────────────────────────────
// The generator also SHIPS inside exported solution repos (export-standalone.sh
// copies scripts/ + docs/REGISTRY.yaml) so builders can edit the manifest and
// regenerate WITHOUT the monorepo — the one-file workflow. In that context the
// monorepo package trees don't exist; platform sources resolve from the
// installed @dbp tarballs (which ship raw TS + migrations) instead.
const IS_STANDALONE = !fs.existsSync(path.join(REPO_ROOT, "packages/shared/contracts/src/solution-manifest.ts"));
if (IS_STANDALONE) {
  console.log("  [standalone mode] monorepo trees absent — resolving platform sources from node_modules/@dbp/*");
}

/**
 * Resolve tsx execution as [executable, prefixArgs].
 *
 * tsx's .bin entry is a .CMD on Windows — execFileSync(EINVAL) without shell.
 * Instead we invoke `node <tsx-cli.mjs> <script> [args...]` directly:
 * - No shell involved: no command-injection surface.
 * - Data arguments come in as separate array entries, not interpolated strings.
 * - Works cross-platform without a .cmd wrapper.
 */
function resolveTsxExec() {
  const tsxCliCandidates = [
    path.join(REPO_ROOT, "node_modules", "tsx", "dist", "cli.mjs"),
    path.join(REPO_ROOT, "..", "node_modules", "tsx", "dist", "cli.mjs"),
    // Worktree support: the worktree lives inside .claude/worktrees/<name>/ so the
    // actual repo root (which holds node_modules) is 3 levels up.
    path.join(REPO_ROOT, "..", "..", "..", "node_modules", "tsx", "dist", "cli.mjs"),
  ];
  for (const c of tsxCliCandidates) {
    if (fs.existsSync(c)) return { bin: process.execPath, prefix: [c] };
  }
  // Final fallback for non-Windows: direct tsx shim (will throw ENOENT if missing)
  const tsxShim = path.join(REPO_ROOT, "node_modules", ".bin", "tsx");
  return { bin: tsxShim, prefix: [] };
}

// ─── CLI parsing ─────────────────────────────────────────────────────────────

const { values: cliValues, positionals } = parseArgs({
  args: process.argv.slice(2),
  options: {
    "out-dir": { type: "string" },
    force: { type: "boolean", default: false },
    // Override the pre-regen safety check (R5): allow --force to overwrite
    // generator-owned files that have been hand-modified (header stripped).
    "allow-dirty": { type: "boolean", default: false },
    // Override the post-emit conformance gate: let a generation with ERROR-class
    // conformance findings complete anyway (warnings never block).
    "allow-nonconformant": { type: "boolean", default: false },
  },
  allowPositionals: true,
});

if (positionals.length !== 1) {
  console.error(
    "Usage: pnpm scaffold -- <path-to-SOLUTION.md> [--out-dir <dir>] [--force] [--allow-dirty] [--allow-nonconformant]",
  );
  process.exit(1);
}

const solutionMdPath = path.resolve(positionals[0]);
const forceRegen = cliValues["force"] === true;
const allowDirty = cliValues["allow-dirty"] === true;
const allowNonconformant = cliValues["allow-nonconformant"] === true;
const startMs = Date.now();

// ─── Helpers ─────────────────────────────────────────────────────────────────

function die(msg) {
  console.error(`\nERROR: ${msg}`);
  process.exit(1);
}

function warn(msg) {
  console.warn(`WARN: ${msg}`);
}

/** Derives the DBP_FLAG_* env var name from a feature flag ID.
 *  e.g. "APP.F01" → "DBP_FLAG_APP_F01", "FEATURE_AI" → "DBP_FLAG_FEATURE_AI"
 */
function flagEnvVar(id) {
  return "DBP_FLAG_" + id.replace(/[^A-Z0-9]/g, "_");
}

// ─── Theme colour/font/radius policy ──────────────────────────────────────────
// Corrections 1 + 1b (docs/01-Architecture/Standard-Navigation-and-Layout-Map.md)
// plus the Arial-trap font guard + radius nudge now live in ./theme-policy.mjs as
// pure, unit-testable functions (see packages/shared/scaffold-tools tests). The
// generator just injects its die/warn at the call site below.

// ─── Standard-menu → layout map (optional, Correction 2) ──────────────────────
// (Feature-Area id → Feature label → doc layout name). Consulted by chooseLayout
// when a module declares `section` + `menuItem`. standard-menu-layout-map.json
// now uses the canonical LAYOUT_IDS directly (Tier 2 rename, 2026-07-07) except
// `lve` / `conversational`, kept as distinct DOC-level markers (real semantic
// info — "this menu item is LVE/conversational-style") even though the generator
// normalises both to a shared implementation (lve-split / canvas-workspace).
const STANDARD_MENU_LAYOUT = (() => {
  try {
    const raw = fs.readFileSync(path.join(__dirname, "standard-menu-layout-map.json"), "utf8");
    return JSON.parse(raw);
  } catch {
    return {};
  }
})();

// Doc names are now identical to LAYOUT_IDS except the two normalized markers.
const DOC_LAYOUT_TO_EMIT = {
  "overview-content": "overview-content",
  "object-page-detail": "object-page-detail",
  "analytics-dashboard": "analytics-dashboard",
  "collection-grid": "collection-grid",
  "overview-grid": "overview-grid",
  "config-form-custom": "config-form-custom",
  bare: "canvas-bare",
  lve: "lve-split",
  // "conversational" is NOT a layout/archetype — it is the copilot feature (APP.F15)
  // composed USING overview-grid (its insight cards are a grid overview). 2026-07-09.
  conversational: "overview-grid",
};

/** Resolve a module's standard-menu layout, or null when not declared/mapped. */
function layoutFromStandardMenu(mod) {
  if (!mod.section || !mod.menuItem) return null;
  const docLayout = STANDARD_MENU_LAYOUT[mod.section]?.[mod.menuItem];
  return docLayout ? (DOC_LAYOUT_TO_EMIT[docLayout] ?? null) : null;
}

/** Parse YAML frontmatter from a markdown file (between first --- delimiters). */
function parseFrontmatter(content) {
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!match) return null;
  return YAML.parse(match[1]);
}

/** solution id → output dir name: DWS.04 → dws-04, TEST.01 → test-01 */
function solutionIdToDir(id) {
  return id.toLowerCase().replace(/\./g, "-");
}



// ─── Step 1: Parse & validate manifest ───────────────────────────────────────

if (!fs.existsSync(solutionMdPath)) die(`SOLUTION.md not found: ${solutionMdPath}`);

const solutionMdContent = fs.readFileSync(solutionMdPath, "utf8");
let raw = parseFrontmatter(solutionMdContent);
if (!raw) die(`No YAML frontmatter found in ${solutionMdPath}. Wrap it in --- delimiters.`);

// ─── Standard manifest baseline (deep-merged UNDER the solution) ──────────────
// Every solution inherits scripts/standard-manifest.yaml so generated apps don't
// diverge by what each author remembered (footer/login/home drift). The solution
// wins on every key; arrays are replaced wholesale. See scripts/standard-manifest.yaml.
/** Deep-merge `override` ONTO `base`: objects recurse, arrays/scalars replace. */
function deepMergeUnder(base, override) {
  if (Array.isArray(override) || Array.isArray(base)) return override; // arrays replace
  if (base && override && typeof base === "object" && typeof override === "object") {
    const out = { ...base };
    for (const k of Object.keys(override)) {
      out[k] = k in base ? deepMergeUnder(base[k], override[k]) : override[k];
    }
    return out;
  }
  return override === undefined ? base : override; // scalars: override wins
}
{
  const baselinePath = path.join(__dirname, "standard-manifest.yaml");
  if (fs.existsSync(baselinePath)) {
    const baseline = YAML.parse(fs.readFileSync(baselinePath, "utf8")) ?? {};
    raw = deepMergeUnder(baseline, raw); // solution (raw) overrides baseline
    console.log("  Standard manifest baseline merged (footer + future basic components).");
  }
}

// Validate the raw frontmatter object against SolutionManifestSchema by running
// a small TypeScript script via tsx. Data is passed through temp files — never
// interpolated into shell strings — so there is no command-injection surface.

// Use file:// URL for the schema contract path so Node.js ESM can resolve it
// cross-platform (especially on Windows where bare absolute paths like C:/... fail).
const schemaContractUrl = pathToFileURL(
  IS_STANDALONE
    ? path.join(REPO_ROOT, "node_modules/@dbp/contracts/src/solution-manifest.ts")
    : path.join(REPO_ROOT, "packages/shared/contracts/src/solution-manifest.ts"),
).href;

// The validator script reads raw JSON from a temp data file, validates it, and
// writes the coerced+defaulted result (or error issues) to an output file.
const schemaValidatorScript = `
import { SolutionManifestSchema } from '${schemaContractUrl}';
import fs from 'node:fs';
const dataFile = process.argv[2];
const outFile = process.argv[3];
const raw = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
const result = SolutionManifestSchema.safeParse(raw);
if (!result.success) {
  fs.writeFileSync(outFile, JSON.stringify({ ok: false, issues: result.error.issues }), 'utf8');
  process.exit(1);
}
fs.writeFileSync(outFile, JSON.stringify({ ok: true, data: result.data }), 'utf8');
`;

// Unique per-process token so concurrent generator runs (e.g. parallel Vitest
// suites) never clobber each other's temp validator files in the shared workspace/ dir.
const TMP_TOKEN = `${process.pid}-${Math.random().toString(36).slice(2, 10)}`;

let manifest;
{
  const workspaceDir = path.join(REPO_ROOT, "workspace");
  fs.mkdirSync(workspaceDir, { recursive: true });
  const tmpScript = path.join(workspaceDir, `_schema-validate-${TMP_TOKEN}.mts`);
  const tmpData = path.join(workspaceDir, `_schema-data-${TMP_TOKEN}.json`);
  const tmpOut = path.join(workspaceDir, `_schema-out-${TMP_TOKEN}.json`);

  fs.writeFileSync(tmpScript, schemaValidatorScript, "utf8");
  fs.writeFileSync(tmpData, JSON.stringify(raw), "utf8");

  const tsx = resolveTsxExec();
  try {
    // execFileSync — no shell, args passed as a literal array (no injection surface).
    // Data flows through temp files; the args array contains only safe file paths.
    execFileSync(
      tsx.bin,
      [...tsx.prefix, tmpScript, tmpData, tmpOut],
      { cwd: REPO_ROOT, encoding: "utf8", stdio: ["ignore", "inherit", "pipe"] },
    );
  } catch {
    // tsx exited non-zero — read the output file for structured issues
  } finally {
    // Always clean up the temp script and data files
    for (const f of [tmpScript, tmpData]) {
      try { fs.unlinkSync(f); } catch { /* ignore */ }
    }
  }

  if (!fs.existsSync(tmpOut)) {
    die("Schema validator did not produce output — tsx may not be available. Run `pnpm install` first.");
  }
  const result = JSON.parse(fs.readFileSync(tmpOut, "utf8"));
  try { fs.unlinkSync(tmpOut); } catch { /* ignore */ }

  if (!result.ok) {
    const msgs = (result.issues ?? [])
      .map((i) => `  ${(i.path ?? []).join(".") || "root"}: ${i.message}`)
      .join("\n");
    die(`SOLUTION.md manifest validation failed:\n${msgs}`);
  }
  manifest = result.data;
}

// (GAP-BRS-5, H2 Table 3) manifest opt-out for app-level rate-limit enforcement — computed
// early so both package.json deps (below) and middleware.ts/lib/env.ts (later) can branch
// on it. Absent/true ⇒ emit the enforcement code; explicit false ⇒ omit it entirely.
const rateLimitEnabled = manifest.rateLimit?.enabled !== false;

// ─── Cross-MAJOR version guard (SP-MIGRATION-TOOLING) ────────────────────────
// If the manifest declares platform_version_pinned and its MAJOR component is
// less than the current PLATFORM_VERSION MAJOR, refuse to scaffold and direct
// the operator to run `dbp upgrade` first.
// This is a read-only guard; it never modifies the manifest or any files.
{
  const CURRENT_MAJOR = 1; // Keep in sync with PLATFORM_VERSION ("platform/v1.5.0")
  const pinnedStr = manifest.platform_version_pinned;
  if (pinnedStr) {
    const pinnedMajorMatch = pinnedStr.match(/^platform\/v(\d+)\./);
    const pinnedMajor = pinnedMajorMatch ? parseInt(pinnedMajorMatch[1], 10) : null;
    if (pinnedMajor !== null && pinnedMajor < CURRENT_MAJOR) {
      console.error("");
      console.error("╔═══════════════════════════════════════════════════════════╗");
      console.error("║  SCAFFOLD BLOCKED — CROSS-MAJOR VERSION MISMATCH          ║");
      console.error("╚═══════════════════════════════════════════════════════════╝");
      console.error("");
      console.error(`  Manifest pin  : ${pinnedStr}  (MAJOR ${pinnedMajor})`);
      console.error(`  Platform now  : platform/v${CURRENT_MAJOR}.x.x`);
      console.error("");
      console.error("  Cross-MAJOR upgrades are never automatic.");
      console.error("  Run the upgrade report first and follow all manual steps:");
      console.error("");
      console.error("    node scripts/dbp-upgrade.mjs --pinned " + pinnedStr);
      console.error("");
      console.error("  Once the wiring audit is complete, update platform_version_pinned");
      console.error(`  in your SOLUTION.md to platform/v${CURRENT_MAJOR}.0.0 and re-run scaffold.`);
      console.error("  See: docs/UPGRADE-CONTRACT.md §7.3");
      console.error("");
      process.exit(1);
    }
  }
}

// ─── Standard menu (default demo scaffold) ───────────────────────────────────
// Every solution gets the FULL standard menu (all Feature Areas/Groups/Features
// from scripts/standard-menu.json = the curated markdown) as demo pages + the full
// 3-level sidebar. A manifest module OVERRIDES a standard slot by route (real
// feature wins); builders refine + add solution-specific groups. Gated on PS.DATA
// (the demo pages need the data plane). Source: docs/01-Architecture/
// Standard-Navigation-and-Layout-Map.md + docs/plans/2026-06-18-standard-menu-demo-scaffold.md.
// ── Generate-time nav section id validation ──────────────────────────────────
// Runs on the AUTHORED manifest, BEFORE the standard-menu injection below splices
// stdNav into every module — the point is to check what the builder wrote, not what
// the generator synthesised. Mirrors mergeNavConfig()'s runtime rules so a bad id
// fails the regen instead of surviving it and 500ing on first page load.
validateNavSectionIds(manifest);

if ((manifest.consumes_platform_services ?? []).includes("PS.DATA")) {
  let stdNav = buildStdNavSections();

  // ── nav.sidebar_areas: reorder / filter standard-menu sections ───────────────
  // When the manifest declares an ordered list of area IDs, rearrange stdNav to
  // match. Areas not listed are intentionally dropped (that is the filter).
  //
  // An UNRECOGNISED id is a hard error. It previously fell through `.filter(Boolean)`
  // and silently omitted the area — the builder saw a blank nav slot with no
  // diagnostic, the same failure class mergeNavConfig() exists to prevent. Custom
  // ids declared in `customNavSections` are called out separately: they are legal
  // section ids, but they are appended from the module's own `nav.sections` (below)
  // and are not orderable through sidebar_areas, which sequences the standard menu.
  if (Array.isArray(manifest.nav?.sidebar_areas) && manifest.nav.sidebar_areas.length > 0) {
    const byId = new Map(stdNav.map((s) => [s.id, s]));
    validateSidebarAreas(manifest.nav.sidebar_areas, byId.keys(), manifest.customNavSections);
    const ordered = manifest.nav.sidebar_areas.map((id) => byId.get(id));
    if (ordered.length > 0) stdNav = ordered;
  }

  const existingTypes = new Set((manifest.entities ?? []).map((e) => e.type));
  const demos = demoEntities().filter((e) => !existingTypes.has(e.type));
  manifest.entities = [...(manifest.entities ?? []), ...demos];

  // Marketplace spine Phase A: register service-offering-request BEFORE synthesizing
  // standard-menu modules so My Requests + Service Requests bind that entity (not the
  // primary lifecycle type). Later APP.F22 block is idempotent (override-wins).
  // See docs/plans/marketplace-spine-2026-07-30-plan.md Phase A.
  const willEmitMarketplaceRequest =
    manifest.marketplace != null ||
    (manifest.modules ?? []).some((m) =>
      (m.features ?? []).some((f) => f.id === "APP.F10" || f.id === "APP.F22"),
    );
  if (
    willEmitMarketplaceRequest &&
    !(manifest.entities ?? []).some((e) => e.type === "service-offering-request")
  ) {
    manifest.entities = [
      ...(manifest.entities ?? []),
      {
        type: "service-offering-request",
        fields: [
          { name: "serviceId", type: "string", required: true },
          { name: "description", type: "string", required: true },
          { name: "urgency", type: "enum", enum: ["low", "medium", "high"], required: true },
          { name: "justification", type: "string", required: false },
        ],
        seed: [],
      },
    ];
  }

  const synth = buildStdModules(manifest, stdNav);
  // Uniform sidebar: every page (synthetic + real) renders the full standard menu.
  for (const m of manifest.modules) {
    // Preserve any solution-specific sections the manifest author declared on this module
    // before injection — they are appended after the standard menu so the full feature
    // catalogue always appears first, with custom areas below.
    const solutionSections = m.nav?.sections ?? [];
    m.nav = {
      ...(m.nav ?? {}),
      logo: m.nav?.logo ?? manifest.solution,
      sections: solutionSections.length > 0 ? [...stdNav, ...solutionSections] : stdNav,
    };
  }
  manifest.modules = [...synth, ...manifest.modules];
  console.log(`  Standard menu: +${synth.length} demo pages, +${demos.length} demo entities`);
}

// ─── Step 2: Resolve against REGISTRY.yaml ───────────────────────────────────

// Standalone repos carry a vendored copy at docs/REGISTRY.yaml (shipped by export-standalone.sh).
const registryPath = path.join(REPO_ROOT, "docs", "REGISTRY.yaml");
const registry = YAML.parse(fs.readFileSync(registryPath, "utf8"));

/** Map: shell id → registry entry */
const shellMap = new Map(registry.shells.map((s) => [s.id, s]));
/** Map: feature id → registry entry */
const featureMap = new Map(registry.features.map((f) => [f.id, f]));
/** Set of known service ids */
const knownServices = new Set(registry.platform_services.map((s) => s.id));

// Validate consumes_platform_services
for (const ps of manifest.consumes_platform_services) {
  if (!knownServices.has(ps))
    die(`Unknown platform service "${ps}" in consumes_platform_services. Not in REGISTRY.yaml.`);
}
const consumedSet = new Set(manifest.consumes_platform_services);

// Validate modules
for (const mod of manifest.modules) {
  // scaffold must be known
  if (!shellMap.has(mod.scaffold)) die(`Module ${mod.id}: unknown scaffold "${mod.scaffold}". Not in REGISTRY.yaml.`);

  const shell = shellMap.get(mod.scaffold);

  // shell.composes ⊆ consumes — warn, not fail (architecture note: shells have their own
  // composes list; solutions may legally omit a shell's optional services if they don't use them)
  for (const ps of shell.composes ?? []) {
    if (!consumedSet.has(ps))
      warn(
        `Module ${mod.id}: shell ${mod.scaffold} composes ${ps} but solution does not declare it in consumes_platform_services. If the shell feature requires it, add it.`,
      );
  }

  // feature validation
  for (const feat of mod.features) {
    if (!featureMap.has(feat.id))
      die(`Module ${mod.id}: unknown feature "${feat.id}". Not in REGISTRY.yaml features.`);

    // wires must be ⊆ consumes_platform_services
    for (const wire of feat.wires) {
      if (!consumedSet.has(wire))
        die(
          `Module ${mod.id} / feature ${feat.id} (${feat.role}): wires "${wire}" is not declared in consumes_platform_services. Add it or remove the wire.`,
        );
    }
  }
}

// ── Duplicate-route guard ─────────────────────────────────────────────────────
// Two modules resolving to the same route would cause one to silently overwrite
// the other's page file. Catch this early with a clear error.
{
  const seen = new Map(); // route → module id
  for (const mod of manifest.modules) {
    const route = `/${moduleRouteSegment(mod)}`;
    if (seen.has(route)) {
      die(
        `Duplicate module route "${route}": modules ${seen.get(route)} and ${mod.id} both resolve to the same path. ` +
          `Set an explicit \`route:\` on one of them to disambiguate.`,
      );
    }
    seen.set(route, mod.id);
  }
}

// ─── Step 3: Validate feature configs against Zod contracts ──────────────────

// Map feature registry id → npm package dir name (e.g. APP.F01 → entity-list)
// We derive this from each organism's FEATURE.md `registry_id` frontmatter by
// scanning (post-U4: organisms no longer carry a per-organism package.json —
// registry metadata moved to FEATURE.md, see component-architecture-standard.md
// §3.1). In standalone mode the installed @dbp/organisms tarball (raw TS,
// FEATURE.md included) is the scan target instead of the monorepo tree.
const featuresDir = IS_STANDALONE
  ? path.join(REPO_ROOT, "node_modules", "@dbp", "organisms")
  : path.join(REPO_ROOT, "packages/stack/app-scaffolds/features");
const featureDirMap = new Map(); // registry id → absolute dir path

if (fs.existsSync(featuresDir)) {
  for (const entry of fs.readdirSync(featuresDir, { withFileTypes: true })) {
    if (!entry.isDirectory() && !entry.isSymbolicLink()) continue;
    const entryDir = path.join(featuresDir, entry.name);
    const featureMdPath = path.join(entryDir, "FEATURE.md");
    if (!fs.existsSync(featureMdPath)) continue;
    const match = fs.readFileSync(featureMdPath, "utf8").match(/^registry_id:\s*(\S+)\s*$/m);
    if (match) featureDirMap.set(match[1], entryDir);
  }
}

// ── Reusable feature-config validator ────────────────────────────────────────
// Validate ONE config object against a feature package's Zod contract (types.ts)
// via tsx. Returns { ok: true } | { ok: true, skipped } | { ok: false, issues }.
//
// Used by Step 3 (manifest module-feature configs) AND by emit-time SYNTHESISED
// configs (e.g. the catalogue [id] detail route built in emitCatalogueDetailRoute).
// Holding generator-built configs to the same contract closes the runtime-only
// blind spot that previously let a malformed APP.F11 breadcrumb ship green and
// only fail client-side after login.
// See docs/01-Architecture/GENERATOR-REVIEW-marketplace-detail-breadcrumb.md.
let _cfgValidateSeq = 0;
function validateFeatureConfig(featureId, config) {
  const featureDir = featureDirMap.get(featureId);
  if (!featureDir) return { ok: true, skipped: `no package dir found for ${featureId}` };
  const typesPath = path.join(featureDir, "types.ts");
  if (!fs.existsSync(typesPath)) return { ok: true, skipped: `no types.ts for ${featureId}` };

  // Run a tiny tsx script that imports the feature's Zod schema and validates the
  // config. Data flows through temp files — no shell string interpolation. The
  // per-call seq suffix keeps concurrent/repeated calls (same featureId) isolated.
  const workspaceDir = path.join(REPO_ROOT, "workspace");
  fs.mkdirSync(workspaceDir, { recursive: true });
  const featTmpId = `${featureId.replace(/\./g, "-")}-${TMP_TOKEN}-${_cfgValidateSeq++}`;
  const tmpCfgData = path.join(workspaceDir, `_feat-cfg-data-${featTmpId}.json`);
  const tmpCfgOut = path.join(workspaceDir, `_feat-cfg-out-${featTmpId}.json`);
  const tmpCfgScript = path.join(workspaceDir, `_feat-cfg-${featTmpId}.mts`);

  // Use file:// URL so Node ESM can resolve it cross-platform
  const featureTypesUrl = pathToFileURL(typesPath).href;
  const cfgValidatorScript = `
import * as T from '${featureTypesUrl}';
import fs from 'node:fs';
const dataFile = process.argv[2];
const outFile = process.argv[3];
// A feature's types.ts exports its top-level contract(s) with a name ending in
// 'Config' — preferred over sub-schemas (e.g. ColumnDefSchema), which are not the
// contract. A feature may legitimately export MORE THAN ONE config mode: APP.F06
// exports both ApprovalSurfaceConfig (single instance) and ApprovalQueueConfig
// (queue over a definition). Validate against ALL of them and accept if ANY match.
//
// Do NOT pick "the first *Config export" — an ES module namespace object has its
// own keys SORTED, not in declaration order, so "first" means alphabetically first.
// That silently validated every APP.F06 config against ApprovalQueueConfig (Q < S),
// rejecting correct single-instance configs for missing queue-only fields.
type ZodLike = { safeParse: (x: unknown) => { success: boolean; error?: { issues: unknown[] } }; _def?: unknown };
const isSchemaShaped = (v: unknown): v is ZodLike =>
  v != null && typeof v === 'object' && typeof (v as Record<string, unknown>).safeParse === 'function';
const entries = Object.entries(T as Record<string, unknown>);
const configEntries = entries.filter(([k, v]) => k.endsWith('Config') && isSchemaShaped(v)) as [string, ZodLike][];
const candidates: [string, ZodLike][] = configEntries.length > 0
  ? configEntries
  : (entries.filter(([, v]) => isSchemaShaped(v)) as [string, ZodLike][]).slice(0, 1);
if (candidates.length === 0) {
  fs.writeFileSync(outFile, JSON.stringify({ ok: true, note: 'no-schema' }), 'utf8');
  process.exit(0);
}
const raw = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
const attempts = candidates.map(([name, schema]) => ({ name, result: schema.safeParse(raw) }));
if (!attempts.some((a) => a.result.success)) {
  // All modes rejected it. Report the mode that got closest (fewest issues) so the
  // error names the contract the author most likely meant, not an unrelated sibling.
  const best = attempts.reduce((a, b) =>
    (a.result.error?.issues?.length ?? Infinity) <= (b.result.error?.issues?.length ?? Infinity) ? a : b);
  fs.writeFileSync(outFile, JSON.stringify({
    ok: false,
    schema: best.name,
    triedSchemas: attempts.map((a) => a.name),
    issues: best.result.error?.issues ?? [],
  }), 'utf8');
  process.exit(1);
}
fs.writeFileSync(outFile, JSON.stringify({ ok: true }), 'utf8');
`;

  fs.writeFileSync(tmpCfgScript, cfgValidatorScript, "utf8");
  fs.writeFileSync(tmpCfgData, JSON.stringify(config), "utf8");

  try {
    const tsx2 = resolveTsxExec();
    execFileSync(tsx2.bin, [...tsx2.prefix, tmpCfgScript, tmpCfgData, tmpCfgOut], {
      cwd: REPO_ROOT,
      encoding: "utf8",
      stdio: ["ignore", "inherit", "pipe"],
    });
  } catch {
    // Non-zero exit — read structured output below
  } finally {
    for (const f of [tmpCfgScript, tmpCfgData]) {
      try { fs.unlinkSync(f); } catch { /* ignore */ }
    }
  }

  if (!fs.existsSync(tmpCfgOut)) {
    return { ok: true, skipped: `validator produced no output for ${featureId}` };
  }
  const cfgResult = JSON.parse(fs.readFileSync(tmpCfgOut, "utf8"));
  try { fs.unlinkSync(tmpCfgOut); } catch { /* ignore */ }
  return cfgResult;
}

/** Format Zod issues as an indented `path: message` block. */
function formatConfigIssues(issues) {
  return (issues ?? [])
    .map((i) => `    ${(i.path ?? []).join(".") || "root"}: ${i.message}`)
    .join("\n");
}

for (const mod of manifest.modules) {
  for (const feat of mod.features) {
    // config: {} is an explicit "not yet configured" stub — skip validation silently
    // rather than failing. The generator will emit a scaffold placeholder page.
    if (feat.config && typeof feat.config === "object" && Object.keys(feat.config).length === 0) {
      warn(`Feature ${feat.id} (${feat.role}): config: {} stub — skipping config validation.`);
      continue;
    }
    const res = validateFeatureConfig(feat.id, feat.config);
    if (res.skipped) {
      warn(`Feature ${feat.id}: ${res.skipped} — skipping config validation.`);
      continue;
    }
    if (!res.ok) {
      die(
        `Module ${mod.id} / feature ${feat.id} (${feat.role}) config validation failed` +
          (res.schema ? ` against ${res.schema}` : "") +
          (res.triedSchemas && res.triedSchemas.length > 1
            ? ` (tried: ${res.triedSchemas.join(", ")})`
            : "") +
          `:\n` +
          formatConfigIssues(res.issues),
      );
    }
  }
}

// ─── Step 4: Emit the app ─────────────────────────────────────────────────────

const solutionDir = solutionIdToDir(manifest.solution);
const outDirBase = cliValues["out-dir"]
  ? path.resolve(cliValues["out-dir"])
  : path.join(REPO_ROOT, "apps", solutionDir);
// Package name is derived from the manifest's solution id (canonical, stable
// across `--out-dir` regens), not from the target output directory basename —
// deriving from the target dir broke `--force` regen idempotency: the same
// manifest regenerated into a different-named output directory (e.g. a temp
// `out2` dir during tests) produced a different package name. The default
// out-dir (`apps/<solutionDir>`) already matches this slug, so this also
// satisfies infra/01-standards/naming-rules.mjs `expectedPackageName`'s
// @dbp/app-<dir> expectation for committed apps.
const appName = `@dbp/app-${solutionDir}`;

// ─── Generator-owned vs solution-owned file contract ─────────────────────────
//
// THE KEYSTONE SAFETY CONTRACT. Every file the generator emits falls into exactly
// one of two categories. This is what makes `--force` non-destructive.
//
//   GENERATOR_OWNED  — the chrome/pages/config/providers/middleware/_arch. Safe to
//                      both CREATE and OVERWRITE on every regen. These are pure
//                      functions of the manifest + registry; regenerating them is
//                      always correct and byte-identical for the same input.
//
//   SOLUTION_OWNED   — hand-authored solution assets: entity schemas, workflow
//                      definitions, module configs, the host-seam instrumentation,
//                      and the platform-data route (which carries hand-edited SEED
//                      rows). These are NEVER deleted and NEVER overwritten once
//                      they exist. A first scaffold writes a working template; a
//                      regen leaves any existing one completely untouched.
//
// A `--force` regen may clean/overwrite ONLY generator-owned paths. It must never
// `rm` or overwrite a solution-owned file or directory. There is no wholesale
// directory delete — the previous `fs.rmSync(outDirBase)` is gone precisely because
// it caught solution-owned files (instrumentation.ts, solution/entities/*, the
// hand-seeded data route) in its blast radius. See SYSTEM-DESIGN-ASSESSMENT §7 and
// CLAUDE.md "Subagent isolation & the destructive generator".

/**
 * Classify an emitted relative path as solution-owned (true) or generator-owned (false).
 *
 * Solution-owned paths — NEVER deleted, NEVER overwritten if present:
 *   - instrumentation.ts                         (host seam: schema/workflow/seed bootstrap)
 *   - solution/entities/**                        (Zod entity schemas — source of truth)
 *   - solution/workflows/**                       (workflow definitions)
 *   - solution/modules/**                         (module configs)
 *   - app/api/platform/data/[[...path]]/route.ts  (DATA-ROUTE/SEED choice — see below)
 *   - anything listed in manifest.solutionOwnedOverrides (DEF-9 escape hatch — see below)
 *
 * DEF-9 (blueprint-2026-07-05-release-defects.md): a solution can outgrow a generator-owned
 * extension seam (e.g. hand-author real logic directly into the PS.DATA or PS.AUTH route
 * instead of only using the solution/adapters/** seam). Before solutionOwnedOverrides existed,
 * that hand-authored logic was silently reverted on every regen/publish, because the whole
 * "preserve hand-work" guarantee is only as correct as this classification. Declaring the
 * path in manifest.solutionOwnedOverrides always wins over the rules below.
 *
 * NOTE on app/theme-overrides.css: the assessment lists it as solution-owned, but in
 * THIS generator it is a pure projection of `manifest.theme` (emitted deterministically),
 * so it is generator-owned: the manifest's `theme:` block is the single source of truth
 * and a regen must reproduce it. Solution-specific style that must survive a regen lives
 * in the manifest theme tokens, not in hand-edits to this generated file.
 *
 * ── DATA-ROUTE / SEED approach (the hard case) ──────────────────────────────────
 * When manifest.entities is declared, the data route is OVERWRITTEN on every regen
 * with the filled template (the one that imports registerAndSeedData). This mirrors
 * how solution/fixtures/seed.ts is always-overwritten when entities are present —
 * the manifest is the source of truth and both files must stay in sync.
 *
 * ⚠ SEED-API CONTRACT (instrumentation.ts is solution-owned — the generator NEVER
 * emits it, so it cannot be auto-synced). The generator-owned seed module exposes
 * exactly ONE seeding entrypoint: `registerAndSeedData(dataSvc)`. Any hand-authored
 * instrumentation.ts MUST call that — NOT older/removed exports (e.g. `seedFixtures`,
 * `offers`). When the standard-menu scaffold injects demo entities, seed.ts is
 * (re)written with this API; a stale instrumentation.ts referencing the old API will
 * break the build. If you change the seed module's public API, grep every app's
 * instrumentation.ts and update by hand. (See docs/03-Features/specs/ARCHETYPE-
 * REFERENCE-SPEC.md §2 + the generator-owned/solution-owned contract in CLAUDE.md.)
 *
 * When manifest.entities is absent, the data route is treated as solution-owned
 * (create-if-missing), so hand-edited seed data is preserved byte-for-byte. This
 * matches the original option (a) contract for apps that manage their own bootstrap.
 *
 * The distinction is captured in isSolutionOwned() below and in the write call at
 * the PS.DATA service route emission block further down (search DATA-ROUTE-WRITE).
 */
function isSolutionOwned(relPath) {
  // Normalise to forward slashes so the predicate is OS-independent.
  const p = relPath.replace(/\\/g, "/");
  // DEF-9 (blueprint-2026-07-05-release-defects.md): a manifest-declared override always
  // wins — lets a solution take over a generator-owned extension seam (the PS.DATA/PS.AUTH
  // route, solution/fixtures/demo-identities.ts, etc.) once it has hand-authored real logic
  // there, instead of the generator's default classification silently reverting it on every
  // regen/publish. See SolutionManifestSchema#solutionOwnedOverrides.
  if ((manifest.solutionOwnedOverrides ?? []).includes(p)) return true;
  // NOTE: solution/fixtures/seed.ts is intentionally excluded from the unconditional
  // list below (GG-22 fix, docs/09-plans/seed-migration-ownership-design-2026-07-25.md).
  // When manifest.entities is declared, the generator RE-EMITS (overwrites) seed.ts on
  // every run so the manifest stays the single source of truth — UNLESS the solution has
  // declared "solution/fixtures/seed.ts" in manifest.solutionOwnedOverrides, in which case
  // the check above already returns true and the emission block (search
  // "solution/fixtures/seed.ts — OVERWRITTEN") falls through to writeFile()'s
  // create-if-missing path instead of its previous unconditional fs.writeFileSync bypass.
  // When manifest.entities is absent, seed.ts is omitted entirely (not written).
  //
  // NOTE: app/api/platform/data/[[...path]]/route.ts is CONDITIONALLY solution-owned:
  //   - When manifest.entities is ABSENT  → solution-owned (create-if-missing).
  //   - When manifest.entities is PRESENT → generator-owned (overwritten on regen).
  // The conditional write is handled at the DATA-ROUTE-WRITE block below; isSolutionOwned
  // returns true here only for the absent-entities case (default). When entities are present,
  // the write block bypasses writeFile() and writes directly (always-overwrite).
  return (
    p === "instrumentation.ts" ||
    p === "instrumentation.node.ts" ||
    p.startsWith("solution/entities/") ||
    p.startsWith("solution/workflows/") ||
    p.startsWith("solution/modules/") ||
    p === "app/api/platform/data/[[...path]]/route.ts" ||
    // Developer experience files — created on first scaffold, preserved on regen
    p === "AGENTS.md" ||
    p === "CLAUDE.md" ||
    p.startsWith(".ai/") ||
    p.startsWith("docs/") ||
    // Env files — .env.local is create-if-missing (contains real secrets, gitignored)
    // .env.example is generator-owned (always re-emitted, safe to overwrite)
    p === ".env.local" ||
    // Solution composition seams — established by generator on first scaffold, never overwritten.
    // These directories own the RBAC policy, external adapters, typed data client, and lifecycle
    // action components. The generator emits stubs; the solution fills them in.
    p.startsWith("solution/rbac/") ||
    p.startsWith("solution/adapters/") ||
    p.startsWith("solution/lib/") ||
    p.startsWith("solution/features/") ||
    // R1 page-component seam: custom page bodies wired via a module's `pageComponent`.
    // Generator emits a create-if-missing stub here; developers own the implementation.
    p.startsWith("solution/pages/") ||
    // Solution-level test suites: the generator emits smoke-test stubs (auth
    // bootstrap, per-pageComponent render tests); developers own and extend them.
    p.startsWith("solution/__tests__/") ||
    // Quality-ratchet baseline: fresh scaffolds start at zero; adopted apps set
    // real counts once and burn them down. Never reset by a regen.
    p === "quality-ratchet.json" ||
    // Generated Control Slice item #3 (docs/03-features/specs/spec-generated-control-slice-2026-07-11.md):
    // PROGRESS.md is seed-once — created empty-with-header if absent, then never
    // regenerated once it has session entries, so a regen never clobbers history.
    p === "PROGRESS.md"
  );
}

// Generator-owned files emitted on this run — collected so --force can surgically
// delete stale generator-owned files (e.g. a module route dropped from the manifest)
// without ever touching solution-owned paths. solution/_arch/** is generator-owned
// (resolved provenance) and is included implicitly via writeFile below.
const emittedGeneratorOwned = new Set();

// sweep-ownership-authority fix (2026-07-25): the ownership manifest from the
// PREVIOUS run is the only provable record of "this file is a generator artifact
// from a prior regen". Read it BEFORE emission starts (sweepStaleGeneratorOwned()
// reads this Set, not the just-emitted list) so a hand-added file under app/ that
// no manifest module emits — previously indistinguishable from a stale generator
// artifact and silently deleted by --force — can be told apart: it is neither
// re-emitted this run NOR present in the prior manifest, so it is preserved.
// Malformed/unreadable JSON is treated as ABSENT (fallback path in
// sweepStaleGeneratorOwned), never a crash and never a reason to delete-everything.
let priorGeneratorOwned = null; // null = manifest absent/unreadable — fallback path
{
  const priorOwnershipPath = path.join(outDirBase, "solution/_arch/generator-owned.json");
  if (fs.existsSync(priorOwnershipPath)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(priorOwnershipPath, "utf8"));
      if (Array.isArray(parsed)) priorGeneratorOwned = new Set(parsed);
    } catch { /* malformed JSON — leave priorGeneratorOwned null, fallback path */ }
  }
}

// Unknown files preserved by the sweep-ownership-authority fix because they are
// neither re-emitted this run nor provably a generator artifact from a prior run.
// Populated by sweepStaleGeneratorOwned(), reported at end of run (Step 6).
const preservedUnknownFiles = [];

// Demo-stub parameterization (gaps-log #3): the first demo-record LVE config seen
// becomes the canonical base for lib/demo-lve-config.ts; demo pages then call
// buildDemoLveConfig(title) instead of inlining a ~300-line byte-identical blob.
// Unbuilt pages become one-liners and greppable ("buildDemoLveConfig").
let demoLveCanonicalCfg = null;

const isRegenOfExisting = fs.existsSync(outDirBase);
if (isRegenOfExisting && !forceRegen) {
  die(
    `Output directory "${outDirBase}" already exists. Use --force to regenerate ` +
      `(generator-owned chrome/pages/config are refreshed; solution-owned files — ` +
      `instrumentation.ts, solution/entities|workflows|modules/**, and the platform-data ` +
      `route — are preserved untouched).`,
  );
}

// R5 — pre-regen safety check: refuse to overwrite hand-modified generator-owned
// pages unless the operator explicitly opts in with --allow-dirty.
if (isRegenOfExisting && forceRegen && !allowDirty) {
  // Routes now covered by the pageComponent seam are expected to be overwritten with
  // the thin generated wrapper (their real content already lives in solution/pages/**,
  // preserved separately across regens) — a stale hand-bridge/hand-authored body at
  // these exact paths is the seam doing its job, not data loss, so the safety check
  // must not block a regen on them.
  const seamCoveredPaths = new Set(
    manifest.modules
      .filter((m) => m.pageComponent && resolveShellId(m.scaffold) === "SH.WORKSPACE")
      .map((m) => `app/(authenticated)/${moduleRoutePath(m)}/page.tsx`),
  );
  const dirty = detectHandModifiedGeneratorFiles().filter((p) => !seamCoveredPaths.has(p));
  if (dirty.length > 0) {
    die(
      `Pre-regen safety check: ${dirty.length} generator-owned file(s) under app/ have been ` +
        `hand-modified (their "${"Generated by scaffold-solution"}" header is gone). ` +
        `A --force regen would OVERWRITE and destroy that work:\n` +
        dirty.map((p) => `    ${p}`).join("\n") +
        `\n\nFix one of two ways:\n` +
        `  • Move the custom content into a solution-owned seam — set the module's ` +
        `"pageComponent" field in the manifest to a solution/pages/<name> component ` +
        `(solution/pages/** is preserved across regens).\n` +
        `  • Or re-run with --allow-dirty to overwrite these files anyway (the hand-edits are lost).`,
    );
  }
}

/**
 * Write an emitted file under the contract.
 *
 *   - GENERATOR_OWNED: always written/overwritten (deterministic chrome).
 *   - SOLUTION_OWNED:  written only if absent. If a hand-authored file already
 *                      exists, it is LEFT UNTOUCHED and a note is logged so the
 *                      operator knows the solution edits were preserved.
 *
 * Either way the file is NEVER deleted here — destructive cleanup is confined to
 * sweepStaleGeneratorOwned() below, which only ever removes generator-owned paths.
 */
function writeFile(relPath, content) {
  const abs = path.join(outDirBase, relPath);
  const solutionOwned = isSolutionOwned(relPath);

  if (solutionOwned) {
    if (fs.existsSync(abs)) {
      // Preserve hand-authored solution asset — do not overwrite, do not delete.
      console.log(`  preserved (solution-owned): ${relPath}`);
      return;
    }
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, content, "utf8");
    return;
  }

  emittedGeneratorOwned.add(relPath.replace(/\\/g, "/"));
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, content, "utf8");
}

// ── merge-append ownership class ────────────────────────────────────────────
// Generated Control Slice items #1/#2 (docs/03-features/specs/spec-generated-
// control-slice-2026-07-11.md): AGENTS.md/CLAUDE.md carry a generator-owned
// "factory non-negotiables" block, delimited by markers, at the TOP of an
// otherwise solution-owned file. On first scaffold the block + the generated
// body are both written. On regen, only the delimited block is refreshed —
// everything else (solution identity, hand-edited sections, prior session
// history) is left byte-for-byte untouched, mirroring the same "preserve
// hand-work" guarantee writeFile() gives fully solution-owned files.
const FACTORY_NON_NEGOTIABLES_START =
  "<!-- FACTORY-NON-NEGOTIABLES:START — generator-owned, refreshed on every regen. Do not hand-edit between these markers. -->";
const FACTORY_NON_NEGOTIABLES_END = "<!-- FACTORY-NON-NEGOTIABLES:END -->";

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function writeMergeAppendFile(relPath, block, fallbackBody) {
  const abs = path.join(outDirBase, relPath);
  const delimited = `${FACTORY_NON_NEGOTIABLES_START}\n${block}\n${FACTORY_NON_NEGOTIABLES_END}`;

  if (!fs.existsSync(abs)) {
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, `${delimited}\n\n${fallbackBody}`, "utf8");
    console.log(`  created (merge-append seed): ${relPath}`);
    return;
  }

  const existing = fs.readFileSync(abs, "utf8");
  const markerRe = new RegExp(
    `${escapeRegExp(FACTORY_NON_NEGOTIABLES_START)}[\\s\\S]*?${escapeRegExp(FACTORY_NON_NEGOTIABLES_END)}`,
  );
  let updated;
  if (markerRe.test(existing)) {
    updated = existing.replace(markerRe, delimited);
    console.log(`  merge-append block refreshed: ${relPath}`);
  } else {
    // File predates the control slice (or markers were hand-removed) — insert
    // the block at the top without touching any existing content.
    updated = `${delimited}\n\n${existing}`;
    console.log(`  merge-append block inserted (file predates the control slice): ${relPath}`);
  }
  fs.writeFileSync(abs, updated, "utf8");
}

/**
 * G8 — migration-governance toolchain. Emitted only in postgres mode
 * (isPersistentStorage) so every generated persistent-storage app ships
 * db:migrate / db:snapshot / db:check + the CI drift/lint/replay/snapshot gate
 * with zero hand-authoring.
 *
 * The emitted file bodies live as real, diffable, testable template assets under
 * scripts/db-governance-templates/ (not inline strings — that avoids template-in-
 * template escaping hazards for the regex/bash/JS bodies). They are rendered here by
 * simple token substitution and written into the generated app.
 *
 * Ownership:
 *   - scripts/db-migrate.mjs, sync-platform-migrations.mjs, check-migrations.mjs,
 *     db-snapshot.sh, .github/workflows/db-migrations.yml, .github/CODEOWNERS,
 *     db/migrations/platform/*  → GENERATOR-OWNED (always re-emitted; fixes propagate).
 *   - db/migrations/<slug>/     → SOLUTION-OWNED (dir created only if missing, so real
 *     migrations already committed there are never touched on regen).
 */
function emitMigrationGovernance(slug) {
  const TPL_DIR = path.join(REPO_ROOT, "scripts", "db-governance-templates");
  // CI service DB name — snake_case, Postgres-identifier-safe.
  const ciDb = slug.replace(/[^a-z0-9]+/gi, "_").toLowerCase() + "_ci";

  // Platform-db version — filled into the vendored README so drift is visible.
  let platformDbVersion = "unknown";
  try {
    platformDbVersion = JSON.parse(
      fs.readFileSync(
        IS_STANDALONE
          ? path.join(REPO_ROOT, "node_modules", "@dbp", "platform-db", "package.json")
          : path.join(REPO_ROOT, "packages", "stack", "platform-db", "package.json"),
        "utf8",
      ),
    ).version;
  } catch { /* best-effort */ }

  const render = (file, tokens = {}) => {
    let s = fs.readFileSync(path.join(TPL_DIR, file), "utf8");
    for (const [k, v] of Object.entries(tokens)) s = s.split(k).join(v);
    return s;
  };

  // ── Generator-owned files (always overwritten — fixes propagate on regen) ──
  writeFile("scripts/db-migrate.mjs", render("db-migrate.mjs", { "__SOLUTION_SCHEMA__": slug }));
  writeFile("scripts/sync-platform-migrations.mjs", render("sync-platform-migrations.mjs"));
  writeFile("scripts/check-migrations.mjs", render("check-migrations.mjs"));
  writeFile("scripts/db-snapshot.sh", render("db-snapshot.sh"));
  writeFile(".github/workflows/db-migrations.yml", render("db-migrations.yml", { "__CI_DB__": ciDb }));
  writeFile(
    "db/migrations/platform/README.md",
    render("platform-README.md", { "__SOLUTION_SCHEMA__": slug, "__PLATFORM_DB_VERSION__": platformDbVersion }),
  );

  // Vendored platform baseline — read verbatim from THIS blueprint's own package at
  // generation time, so the vendored copy always matches the blueprint the app was
  // generated from (never hard-coded SQL strings in the generator).
  const platformMigrationsSrc = IS_STANDALONE
    ? path.join(REPO_ROOT, "node_modules", "@dbp", "platform-db", "migrations")
    : path.join(REPO_ROOT, "packages", "stack", "platform-db", "migrations");
  if (fs.existsSync(platformMigrationsSrc)) {
    for (const f of fs.readdirSync(platformMigrationsSrc).filter((f) => f.endsWith(".sql"))) {
      writeFile(`db/migrations/platform/${f}`, fs.readFileSync(path.join(platformMigrationsSrc, f), "utf8"));
    }
  } else {
    console.warn(`  ⚠ G8: platform-db migrations not found at ${platformMigrationsSrc} — skipping vendor copy.`);
  }

  // .github/CODEOWNERS — merge/append the db/** ownership section behind a marker so a
  // regen replaces only the G8 section and never clobbers hand-added ownership rules above.
  const codeownersPath = path.join(outDirBase, ".github", "CODEOWNERS");
  fs.mkdirSync(path.dirname(codeownersPath), { recursive: true });
  const MARKER = "# --- G8: db migration governance (generator-owned; do not hand-edit this section) ---";
  const existingCodeowners = fs.existsSync(codeownersPath) ? fs.readFileSync(codeownersPath, "utf8") : "";
  const withoutOldSection = existingCodeowners.split(MARKER)[0].replace(/\s*$/, "");
  const merged =
    (withoutOldSection ? withoutOldSection + "\n\n" : "# Code owners — required reviewers for sensitive paths.\n\n") +
    MARKER + "\n" + render("CODEOWNERS");
  fs.writeFileSync(codeownersPath, merged.endsWith("\n") ? merged : merged + "\n", "utf8");
  emittedGeneratorOwned.add(".github/CODEOWNERS");

  // db/migrations/<slug>/.gitkeep — solution-owned dir, create-if-missing only so real
  // migrations committed there are never clobbered by a regen.
  const solutionMigDir = path.join(outDirBase, "db", "migrations", slug);
  if (!fs.existsSync(solutionMigDir)) {
    fs.mkdirSync(solutionMigDir, { recursive: true });
    fs.writeFileSync(path.join(solutionMigDir, ".gitkeep"), "", "utf8");
  }
}

/**
 * R5 — pre-regen safety check. BEFORE --force overwrites anything, scan the
 * generator-owned `app/` tree for page/route files that have lost their
 * "Generated by scaffold-solution" header — a sign they were hand-replaced or
 * heavily hand-edited. Overwriting them silently destroys solution work (the
 * DWS.03 "39 hand-edited pages" incident). Runs as a pre-pass so an abort never
 * leaves a half-written tree.
 *
 * Scope: .ts/.tsx files under app/ only — the files teams actually hand-edit.
 * JSON/config files have no comment header, so a header check is not meaningful for
 * them and they are excluded here; solution-owned paths skipped.
 * Limitation: header-absence catches full replacements (the common, dangerous
 * case). A small edit that keeps the header is NOT flagged.
 *
 * A hand-added non-.ts/.tsx file under app/ (e.g. a bespoke .json/.css/.mdx) is NOT
 * scanned by this header check, but is no longer a silent-deletion risk: the
 * sweep-ownership-authority fix in sweepStaleGeneratorOwned() only deletes a file
 * provably listed in the PREVIOUS run's generator-owned.json, so an unknown
 * hand-added file of any extension is preserved and reported in the Step 6 summary
 * (see preservedUnknownFiles) rather than silently deleted.
 *
 * @returns {string[]} repo-relative paths of hand-modified generator-owned files
 */
function detectHandModifiedGeneratorFiles() {
  const HEADER = "Generated by scaffold-solution";
  // Generator-owned files intentionally emitted WITHOUT the header (infrastructure:
  // root layout/providers/toaster, login/logout, and all PS API route mounts under
  // app/api/). Excluded so a normal regen never false-positives on them. Limitation:
  // hand-edits to these specific files are not caught — the check targets the module
  // page bodies (app/(authenticated)/<route>/page.tsx), the documented hand-edit surface.
  const HEADERLESS = new Set([
    "app/layout.tsx",
    "app/providers.tsx",
    "app/toaster-mount.tsx",
    "app/(public)/login/page.tsx",
    "app/(public)/logout/route.ts",
    // Bespoke dynamic-segment sub-route, genuinely hand-authored and never
    // generator-emitted (no per-record kanban detail template exists) — see the
    // file's own header comment. Manifest module routes cannot express a "[id]"
    // segment (ModuleSchema.route regex forbids brackets), so the pageComponent
    // seam can't cover it either; matches the documented Phase-0 scope of
    // packages/shared/contracts/src/emitted-page-layout-marker.test.ts, which
    // already excludes "bespoke sub-routes ([id], request, legal, ...)".
    "app/(authenticated)/manage-work/tasks/[id]/page.tsx",
  ]);
  const isHeaderless = (rel) => HEADERLESS.has(rel) || rel.startsWith("app/api/");
  const dirty = [];
  function walk(absRoot) {
    if (!fs.existsSync(absRoot)) return;
    for (const entry of fs.readdirSync(absRoot, { withFileTypes: true })) {
      const absChild = path.join(absRoot, entry.name);
      const rel = path.relative(outDirBase, absChild).replace(/\\/g, "/");
      if (entry.isDirectory()) {
        if (isSolutionOwned(rel + "/")) continue; // never flag solution-owned subtrees
        walk(absChild);
      } else {
        if (!/\.(ts|tsx)$/.test(entry.name)) continue;
        if (isSolutionOwned(rel)) continue;
        if (isHeaderless(rel)) continue; // intentionally emitted without the header
        let head = "";
        try { head = fs.readFileSync(absChild, "utf8").slice(0, 400); } catch { continue; }
        if (!head.includes(HEADER)) dirty.push(rel);
      }
    }
  }
  walk(path.join(outDirBase, "app"));
  return dirty;
}

/**
 * After all generator-owned files are emitted, remove any generator-owned file
 * left over from a PREVIOUS regen that this run did NOT emit (e.g. a module route
 * for a module since removed from the manifest). This is the only place --force
 * deletes anything, and it provably skips solution-owned paths via isSolutionOwned.
 *
 * It walks the known generator-owned directories only (app/, middleware.ts, configs,
 * solution/_arch). It never recurses into solution/entities|workflows|modules, and it
 * never touches the solution-owned data route, instrumentation.ts, or node_modules.
 *
 * sweep-ownership-authority fix (2026-07-25): a file not re-emitted this run is NOT
 * automatically stale. Previously `!isSolutionOwned(rel) && !emittedGeneratorOwned.has(rel)`
 * was sufficient to delete — which meant a hand-ADDED file under app/ that no manifest
 * module emits (a bespoke route) was indistinguishable from a genuinely stale generator
 * artifact, and --force deleted it silently. Deletion now additionally requires the file
 * to be listed in `priorGeneratorOwned` — the PREVIOUS run's generator-owned.json — which
 * is the only provable record that a file actually came out of the generator. A file that
 * is neither re-emitted this run NOR in the prior manifest is UNKNOWN, not stale: it is
 * preserved and collected into preservedUnknownFiles for the Step 6 report. If the prior
 * manifest is absent or malformed (priorGeneratorOwned === null — first-ever regen, or a
 * hand-corrupted file), the sweep cannot prove anything is stale, so it deletes nothing
 * and preserves everything, with a console warning (see below).
 */
function sweepStaleGeneratorOwned() {
  if (!isRegenOfExisting) return;

  if (priorGeneratorOwned === null) {
    console.warn(
      "  ⚠ sweep-ownership-authority: solution/_arch/generator-owned.json is missing or " +
        "malformed — no prior-run record to prove staleness, so no generator-owned files " +
        "will be pruned this run. The manifest written at the end of this run will let the " +
        "next regen prune safely.",
    );
    return;
  }

  // Directories/files that may contain generator-owned output. We sweep these and
  // delete any file NOT re-emitted this run, except solution-owned paths.
  const sweepRoots = ["app", "solution/_arch"];

  /** @param {string} root absolute dir to walk */
  function walk(root) {
    if (!fs.existsSync(root)) return;
    for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
      const absChild = path.join(root, entry.name);
      const rel = path.relative(outDirBase, absChild).replace(/\\/g, "/");
      if (entry.isDirectory()) {
        // Never descend into solution-owned subtrees. The trailing "/" makes the
        // isSolutionOwned startsWith() prefixes (solution/entities/ etc.) match the
        // bare directory path, so this guard is data-driven, not a hardcoded list.
        if (isSolutionOwned(rel + "/")) continue;
        walk(absChild);
        // Remove now-empty generator-owned directories left by a dropped route.
        try {
          if (fs.readdirSync(absChild).length === 0) fs.rmdirSync(absChild);
        } catch { /* non-empty or race — leave it */ }
      } else {
        if (isSolutionOwned(rel)) continue; // never delete a solution-owned file
        if (emittedGeneratorOwned.has(rel)) continue; // re-emitted this run — current
        if (priorGeneratorOwned.has(rel)) {
          // Provably a generator artifact from a prior run that was not re-emitted —
          // e.g. a module route for a module since removed from the manifest.
          try { fs.unlinkSync(absChild); } catch { /* ignore */ }
        } else {
          // Not solution-owned, not re-emitted, and not in the prior manifest —
          // unknown to the generator (most likely hand-added). Preserve it.
          preservedUnknownFiles.push(rel);
        }
      }
    }
  }

  for (const r of sweepRoots) walk(path.join(outDirBase, r));
}

// ── Build dependency lists ───────────────────────────────────────────────────

// Services map: PS.ID → { dir, packageName, basePath }
const SERVICE_META = {
  "PS.AUTH": { dir: "auth", packageName: "@dbp/ps-auth", basePath: "/api/platform/auth" },
  "PS.DATA": { dir: "data", packageName: "@dbp/ps-data", basePath: "/api/platform/data" },
  "PS.NOTIF": { dir: "notif", packageName: "@dbp/ps-notif", basePath: "/api/platform/notif" },
  "PS.SEARCH": { dir: "search", packageName: "@dbp/ps-search", basePath: "/api/platform/search" },
  "PS.WORKFLOW": { dir: "workflow", packageName: "@dbp/ps-workflow", basePath: "/api/platform/workflow" },
  "PS.RBAC": { dir: "rbac", packageName: "@dbp/ps-rbac", basePath: "/api/platform/rbac" },
  "PS.AUDIT": { dir: "audit", packageName: "@dbp/ps-audit", basePath: "/api/platform/audit" },
  "PS.AI": { dir: "ai", packageName: "@dbp/ps-ai", basePath: "/api/platform/ai" },
  "PS.EVENTS": { dir: "events", packageName: "@dbp/ps-events", basePath: "/api/platform/events" },
  "PS.APIGW": { dir: "apigw", packageName: "@dbp/ps-apigw", basePath: "/api/platform/apigw" },
};

// Shell map: SH.ID → { dir, packageName }
const SHELL_META = {
  // ── Canonical two-shell model (Phase 2) ────────────────────────────────────
  // SH.PUBLIC  = public shell (landing / login / public pages; no SessionGuard)
  // SH.WORKSPACE = transaction shell (AppChrome + 3-level nav + SessionGuard)
  "SH.PUBLIC":    { dir: "landing",     packageName: "@dbp/shell-landing" },
  "SH.WORKSPACE": { dir: "transaction", packageName: "@dbp/shell-transaction" },
  // ── Legacy ids kept for back-compat (existing manifests still resolve) ─────
  // SH.01/03/04 are intentionally absent: their old per-stage shell packages
  // (marketplace, delivery-admin, workbench) were removed in the two-shell
  // consolidation. resolveShellId() maps SH.01/02/03/04 → SH.WORKSPACE before
  // any look-up here, so manifests still using those ids resolve to transaction.
  "SH.00": { dir: "landing",         packageName: "@dbp/shell-landing" },
  "SH.02": { dir: "transaction",     packageName: "@dbp/shell-transaction" },
};

/**
 * Back-compat shell alias table.
 * Any manifest that still uses SH.00–SH.04 is silently normalised before
 * SHELL_COMPONENT / resolveSlot look-ups.  The generator never touches solution
 * manifests, so old files keep working unchanged.
 *
 *   SH.00             → SH.PUBLIC    (public/landing pages)
 *   SH.01/02/03/04    → SH.WORKSPACE (TransactionShell — one authenticated shell)
 */
/**
 * Resolve a shell id (legacy or canonical) to the canonical two-shell id.
 * The alias table lives inside the function body rather than in a module-scope
 * `const` so this stays callable from the pre-regen safety check above, which
 * runs during module evaluation — a module-scope const would be in its temporal
 * dead zone at that point and throw.
 */
function resolveShellId(shellId) {
  const SHELL_ALIAS = {
    "SH.00": "SH.PUBLIC",
    "SH.01": "SH.WORKSPACE",
    "SH.02": "SH.WORKSPACE",
    "SH.03": "SH.WORKSPACE",
    "SH.04": "SH.WORKSPACE",
  };
  return SHELL_ALIAS[shellId] ?? shellId;
}

// Feature map: registry ID → package name.
// DERIVED from each organism's FEATURE.md `registry_id` frontmatter so new
// features never silently no-op. The scan runs over the same `featuresDir`
// already used by the featureDirMap loop (Step 3). We build this map early so
// it is available for the archetype detection block below.
//
// Post-U4: all organisms live in the single `@dbp/organisms` package (one
// subpath export per slug) rather than one npm package per organism, so every
// registry id maps to the same package name — `deps["@dbp/organisms"]` and
// `transpilePackages`'s dedup (`[...new Set(...)]`, see next.config.ts emission
// below) collapse the N lookups into one entry.
//
// NOTE: featuresDir is declared above (Step 3 block).
const FEATURE_PKG = (() => {
  const map = {};
  const slugByRegistryId = {};
  if (!fs.existsSync(featuresDir)) return map;
  for (const entry of fs.readdirSync(featuresDir, { withFileTypes: true })) {
    // node_modules entries can be symlinks (pnpm) — accept both (standalone mode).
    if (!entry.isDirectory() && !entry.isSymbolicLink()) continue;
    const featureMdPath = path.join(featuresDir, entry.name, "FEATURE.md");
    if (!fs.existsSync(featureMdPath)) continue;
    const match = fs.readFileSync(featureMdPath, "utf8").match(/^registry_id:\s*(\S+)\s*$/m);
    if (!match) continue;
    const registryId = match[1];
    if (slugByRegistryId[registryId] && slugByRegistryId[registryId] !== entry.name) {
      die(
        `duplicate registry_id ${JSON.stringify(registryId)}: claimed by both ` +
          `${slugByRegistryId[registryId]} and ${entry.name} ` +
          `(packages/stack/app-scaffolds/features/*/FEATURE.md)`,
      );
    }
    slugByRegistryId[registryId] = entry.name;
    map[registryId] = "@dbp/organisms";
  }
  return map;
})();

// ── Archetype route detection ─────────────────────────────────────────────────
// The five optional top-level blocks each gate a route family. We derive which
// shells + feature packages they pull in so deps / transpilePackages / tailwind
// content globs / FEATURE_COMPONENT registration / middleware all stay in sync.
const hasLanding = manifest.landing != null;
const hasHome = manifest.home != null;

// ── Public-page policy (Correction 3) ─────────────────────────────────────────
// Only DXP solutions expose public pages (a "/" landing). Every other solution
// type exposes ONLY /login and redirects "/" inward. Driven by solution_type
// (falls back to platform). A non-DXP manifest carrying a landing: block is a
// hard error — the policy cannot be bypassed by leaving stale config.
const solutionType = manifest.solution_type ?? manifest.platform;
const isDXP = solutionType === "DXP";
if (hasLanding && !isDXP) {
  die(
    `Public-page policy: solution ${manifest.solution} (type ${solutionType}) declares a landing: ` +
    `block, but only DXP solutions may expose a public landing page. Remove the landing: block ` +
    `(non-DXP solutions get "/" → /login + a /login page), or set solution_type: DXP. ` +
    `See docs/01-Architecture/Standard-Navigation-and-Layout-Map.md (Correction 3).`,
  );
}
const hasMarketplace = manifest.marketplace != null;
const hasMarketplaceDetail = hasMarketplace && manifest.marketplace.detail != null;
const hasCopilot = manifest.copilot != null;
const hasContact = manifest.contact != null;
const hasLegal = manifest.legal != null;
const hasCanvasPublic = manifest.canvasPublic != null;

if ((hasContact || hasLegal || hasCanvasPublic) && !isDXP) {
  die(
    `Public-page policy: solution ${manifest.solution} (type ${solutionType}) declares a ` +
      `contact:/legal:/canvasPublic: block, but only DXP solutions may expose public pages. ` +
      `Remove the block or change the solution type.`,
  );
}

// Shells used by archetype routes (in addition to module scaffolds).
const archetypeShellIds = new Set();
if (hasLanding) archetypeShellIds.add("SH.00");
// Contact pages use LandingShell (SH.00) even when hasLanding is false.
if (hasContact) archetypeShellIds.add("SH.00");
// canvasPublic pages import from @dbp/shell-landing (PublicCanvasLayout) even
// when hasLanding is false — same dependency-registration reason as contact.
if (hasCanvasPublic) archetypeShellIds.add("SH.00");
if (hasHome) archetypeShellIds.add("SH.02");
if (hasMarketplace) archetypeShellIds.add("SH.01");
if (hasCopilot) archetypeShellIds.add("SH.04");

// Feature ids used by archetype routes.
const archetypeFeatureIds = new Set();
if (hasMarketplace) archetypeFeatureIds.add("APP.F10");
if (hasMarketplaceDetail) archetypeFeatureIds.add("APP.F11");
if (hasCopilot) archetypeFeatureIds.add("APP.F15");
// Any module rendering a catalog grid (APP.F10) now emits a co-located [id] detail
// route using MarketplaceItemDetail (APP.F11) — a wired card must land on a real
// detail page. Ensure its package is a dependency even without a main marketplace.detail.
if (manifest.modules.some((m) => m.features.some((f) => f.id === "APP.F10"))) {
  archetypeFeatureIds.add("APP.F11");
}
// Every marketplace/catalogue detail page emits a /request sub-route (APP.F22).
// The "Submit Enquiry" button already exists on every detail page — the route must exist too.
if (hasMarketplace || manifest.modules.some((m) => m.features.some((f) => f.id === "APP.F10"))) {
  archetypeFeatureIds.add("APP.F22");
  // The request form (SubmitRequestForm) POSTs to
  // /api/platform/data/entities/service-offering-request. It is a platform-shipped
  // entity — solutions must not have to hand-declare it in their manifest 'entities:'
  // block just to make the enquiry flow work. Auto-register it here (same pattern as
  // the standard-menu demo entities above) whenever APP.F22 is emitted, unless the
  // solution already declares its own 'service-offering-request' entity (solution
  // override wins — e.g. custom fields/lifecycle).
  if (!(manifest.entities ?? []).some((e) => e.type === "service-offering-request")) {
    manifest.entities = [
      ...(manifest.entities ?? []),
      {
        type: "service-offering-request",
        fields: [
          { name: "serviceId", type: "string", required: true },
          { name: "description", type: "string", required: true },
          { name: "urgency", type: "enum", enum: ["low", "medium", "high"], required: true },
          { name: "justification", type: "string", required: false },
        ],
        seed: [],
      },
    ];
  }
}
// Every guided multi-step form (APP.F27) autosaves drafts against the
// "form-draft" PS.DATA entity (useWizardDraft / use-form-draft, WizardDraftSchema
// / FormDraftSchema — both keep an opaque `values` object, hence the 'json' field
// type) and submits the finished wizard against "provision-request" (the wizard's
// own entityType, e.g. apps/dbp's provision-user page). Same auto-register pattern
// as service-offering-request for APP.F22 above — solutions must not have to
// hand-declare these just to make the wizard's autosave/submit flow work; a
// solution-declared entity of the same type wins over this default.
if (manifest.modules.some((m) => m.features.some((f) => f.id === "APP.F27"))) {
  archetypeFeatureIds.add("APP.F27");
  if (!(manifest.entities ?? []).some((e) => e.type === "form-draft")) {
    manifest.entities = [
      ...(manifest.entities ?? []),
      {
        type: "form-draft",
        fields: [
          { name: "wizardDefinitionId", type: "string", required: false },
          { name: "formDefinitionId", type: "string", required: false },
          { name: "wizardVersion", type: "number", required: false },
          { name: "formVersion", type: "number", required: false },
          { name: "userId", type: "string", required: true },
          { name: "currentStepId", type: "string", required: false },
          { name: "values", type: "json", required: true },
          { name: "dirtyFieldIds", type: "string_array", required: false },
          { name: "savedAt", type: "string", required: true },
        ],
        seed: [],
      },
    ];
  }
  if (!(manifest.entities ?? []).some((e) => e.type === "provision-request")) {
    manifest.entities = [
      ...(manifest.entities ?? []),
      {
        type: "provision-request",
        fields: [{ name: "values", type: "json", required: true }],
        seed: [],
      },
    ];
  }
}
// The Reminders card (RemindersCard, part of APP.F21 WorkspaceDashboard) reads
// rows via useEntityList("reminder", { filters: { userId } }) and persists Delete
// via deleteEntity — it is a platform-shipped entity, so solutions must not have
// to hand-declare it just to get a working Workspace Dashboard. APP.F21 is always
// emitted as the standard menu's "My Dashboard" page whenever PS.DATA is consumed
// (see standard-menu-scaffold.mjs featuresFor("dashboard")), so this check also
// covers a solution's own real module that wires APP.F21 directly. Auto-register
// it here (same override-wins pattern as service-offering-request above) unless
// the solution already declares its own 'reminder' entity. Seed rows are scoped to
// usr-alpha-user-01 — the second DEMO_IDENTITIES account emitted below whenever
// PS.AUTH is consumed — so the demo "Demo User" login sees seeded reminders.
if (manifest.modules.some((m) => m.features.some((f) => f.id === "APP.F21"))) {
  if (!(manifest.entities ?? []).some((e) => e.type === "reminder")) {
    manifest.entities = [
      ...(manifest.entities ?? []),
      {
        type: "reminder",
        fields: [
          { name: "title", type: "string", required: true },
          { name: "dueAt", type: "string", required: false },
          { name: "done", type: "boolean", required: false },
          { name: "userId", type: "string", required: true },
        ],
        seed: [
          {
            id: "rm000000-0001-4000-8000-000000000001",
            data: { title: "Assess any new risks identified in the morning meeting.", dueAt: "Today", done: false, userId: "usr-alpha-user-01" },
          },
          {
            id: "rm000000-0002-4000-8000-000000000002",
            data: { title: "Outline key points for tomorrow's stand-up meeting.", dueAt: "Today", done: false, userId: "usr-alpha-user-01" },
          },
        ],
      },
    ];
  }
}
// canvas-workspace's [id] detail route (emitBuilderDetailRoute, see below) mounts
// APP.F02 (EntityDetail) without the owning module ever declaring APP.F02 as a wired
// feature — it's a generator-synthesized route, invisible to the normal per-feature
// dependency collection below. Replicates chooseLayout()'s canvas-workspace resolution
// (explicit override, or one of ADMIN_ARCHETYPE_MAP's canvas-workspace routes) so
// @dbp/organisms/entity-detail is always declared as a dependency when needed. Keep the
// admin route list in sync with ADMIN_ARCHETYPE_MAP's "canvas-workspace" entries.
// admin/form-builder and admin/workflow-builder moved off canvas-workspace to the
// honest "Coming soon" body (ADMIN_DEFERRED_ROUTES) — no [id] detail route, no
// EntityDetail dependency needed for them any more.
const CANVAS_WORKSPACE_ADMIN_ROUTES = new Set(["admin/data-flows", "admin/data-model"]);
if (
  manifest.modules.some(
    (m) => m.layout === "canvas-workspace" || CANVAS_WORKSPACE_ADMIN_ROUTES.has(moduleRouteSegment(m)),
  )
) {
  archetypeFeatureIds.add("APP.F02");
}

// ── Footgun guard 1: feature references an entityType that is never seeded ─────
// A feature config (list/detail/dashboard/kpi/marketplace/copilot) pointed at an
// entityType with no `entities:` declaration renders EMPTY at runtime despite a
// green build — the build proves compilation, not data. By here manifest.entities
// already includes the standard-menu demo entities (demo-record/demo-catalog-item),
// so the only types that trip this are bespoke ones the author forgot to seed.
// See memory project-manifest-entities-block-seeding.
{
  const declaredEntityTypes = new Set((manifest.entities ?? []).map((e) => e.type));
  const referencedEntityTypes = new Set();
  const collectEntityTypes = (node) => {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) return node.forEach(collectEntityTypes);
    for (const [k, v] of Object.entries(node)) {
      if (k === "entityType" && typeof v === "string") referencedEntityTypes.add(v);
      else collectEntityTypes(v);
    }
  };
  collectEntityTypes(manifest.modules);
  collectEntityTypes(manifest.home);
  collectEntityTypes(manifest.marketplace);
  collectEntityTypes(manifest.copilot);
  const unseeded = [...referencedEntityTypes].filter((t) => !declaredEntityTypes.has(t));
  if (unseeded.length) {
    warn(
      `Entity type(s) ${unseeded.map((t) => `'${t}'`).join(", ")} are referenced by features but ` +
        `not declared in the manifest 'entities:' block — their surfaces will render EMPTY (no seed ` +
        `rows) at runtime despite a green build. Add an 'entities:' block (type/fields/seed) for them, ` +
        `or point the features at a seeded demo entity. (project-manifest-entities-block-seeding)`,
    );
  }
}

// ── Footgun guard 2: marketplace entityType still points at demo placeholder ────
// When the solution declares real (bespoke) entities alongside the standard-menu demo
// entities, but the marketplace block still targets "demo-catalog-item", the catalogue
// will show demo placeholder rows rather than real solution data.
if (hasMarketplace && manifest.marketplace.entityType) {
  const DEMO_ENTITY_TYPES = new Set(["demo-catalog-item", "demo-record"]);
  const bespoke = (manifest.entities ?? []).filter((e) => !DEMO_ENTITY_TYPES.has(e.type));
  if (DEMO_ENTITY_TYPES.has(manifest.marketplace.entityType) && bespoke.length > 0) {
    warn(
      `marketplace.entityType is '${manifest.marketplace.entityType}' (a demo placeholder) but the ` +
        `manifest declares bespoke entities (${bespoke.map((e) => `'${e.type}'`).join(", ")}). ` +
        `Update marketplace.entityType to one of your declared entity types or the catalogue will ` +
        `display demo placeholder rows instead of real solution data.`,
    );
  }
}

// ── Footgun guard 2: /home will render hero-only ──────────────────────────────
// The authenticated /home is a Content-Landing composition: LandingHero + features
// + howItWorks + cta. kpis/support are NOT rendered by it. Without features/howItWorks
// the page is just the hero band. See memory project-home-composition-needs-manifest-sections.
if (hasHome) {
  const h = manifest.home;
  if (!h.features?.items?.length && !h.howItWorks?.steps?.length) {
    warn(
      `home: declares neither 'features' nor 'howItWorks' — /home will render the HERO BAND ONLY ` +
        `(kpis/support are not rendered by this composition). Add home.features.items and/or ` +
        `home.howItWorks.steps to fill the page below the fold.`,
    );
  }
}

// Collect unique shells, features, services used
const usedShells = new Set([
  ...manifest.modules.map((m) => m.scaffold),
  ...archetypeShellIds,
]);
const usedFeatureIds = new Set([
  ...manifest.modules.flatMap((m) => m.features.map((f) => f.id)),
  ...archetypeFeatureIds,
]);
const consumedServices = manifest.consumes_platform_services;

// Capability flags for the connected app chrome (enriched top bar). Derived
// PURELY from consumes_platform_services so wiring a service is the only thing
// needed to light up its top-bar affordance. Declared here (before the module
// page loop, which references HAS_AUTH via buildModuleNav) to avoid a TDZ error.
const HAS_AUTH = consumedServices.includes("PS.AUTH");
const HAS_SEARCH = consumedServices.includes("PS.SEARCH");
const HAS_NOTIF = consumedServices.includes("PS.NOTIF");

const shellPackages = [...usedShells].map((id) => SHELL_META[resolveShellId(id)]?.packageName).filter(Boolean);
const featurePackages = [...usedFeatureIds].map((id) => FEATURE_PKG[id]).filter(Boolean);
const servicePackages = consumedServices.map((id) => SERVICE_META[id]?.packageName).filter(Boolean);

// ── package.json ─────────────────────────────────────────────────────────────

// SP-GEN-PERSIST-MODE: resolve persistent-storage mode from the validated manifest.
// Hoisted here (rather than near instrumentation.ts emission) so the package.json
// scripts/deps (G8), next.config.ts externals (G6), and the PS.DATA route template
// (G9) can all use it.
const isPersistentStorage = manifest.storage_mode === "postgres";
// ADR-0039: relational (production) data model. Orthogonal to persistence; the
// manifest superRefine guarantees relational ⇒ postgres, so isPersistentStorage is
// implied. Drives the typed BFF route seam (Wave 4). Absent ⇒ prototype (JSONB).
const isRelationalDataModel = manifest.data_model === "relational";

// ── APP.F26 Command Palette (chrome-level, not a routed page) ────────────────
//
// Gated on the manifest declaring "APP.F26" in the top-level `capabilities`
// array (docs/03-features/specs/capability-keyboard-shortcuts-spec-2026-07-10.md
// §3). When present, the authenticated shell mounts <CommandPalette>, opened
// via mod+k / "/" (useShortcuts, global scope), sourced from the solution's own
// nav sections flattened into CommandPaletteConfig — the generator never
// hand-authors commands, it projects the manifest's own nav.
const hasCommandPalette = (manifest.capabilities ?? []).includes("APP.F26");

const deps = {
  next: "^15.3.3",
  react: "^19.1.0",
  "react-dom": "^19.1.0",
  zod: "^3.25.76",
  // The emitted login + landing pages import lucide icons directly, so the app
  // must declare lucide-react (not only the feature packages that re-import it).
  "lucide-react": "^0.468.0",
  "@dbp/contracts": "workspace:*",
  "@dbp/design-tokens": "workspace:*",
  "@dbp/ui": "workspace:*",
  "@tanstack/react-query": "^5.101.0",
  // lib/env.ts uses @t3-oss/env-nextjs for build-time + runtime env validation
  // (ADR-0029). Must be in app deps even though it's also in devDeps of @dbp/config
  // — apps do a direct import so pnpm requires it declared here too.
  "@t3-oss/env-nextjs": "^0.13.11",
};

for (const pkg of [...servicePackages, ...shellPackages, ...featurePackages]) {
  deps[pkg] = "workspace:*";
}

// Conditional deps driven by wired services (gaps #13)
if (HAS_AUTH) {
  // jose is required for stateless JWT session verification in middleware + auth handlers
  deps["jose"] = "^5.9.6";
  // next.config.ts's serverExternalPackages (G6) unconditionally externalizes these
  // three SSO packages for every app that consumes PS.AUTH — @dbp/ps-auth/server
  // imports them at module scope regardless of whether SAML/LDAP/Azure AD is
  // actually configured. Externalizing tells webpack to leave them as a runtime
  // require() instead of bundling; under pnpm's strict linking that require()
  // then fails to resolve unless the app itself also declares them directly (they
  // are only regular dependencies of @dbp/ps-auth, not of this app). Versions
  // pinned to match packages/stack/platform-services/auth/package.json exactly.
  // (Found via the minimum-test-plan build spec's data-persistence probe,
  // docs/09-plans/minimum-test-plan-build-spec-2026-07-07.md Increment G —
  // same root cause class as the drizzle-orm fix below.)
  deps["@node-saml/node-saml"] = "^5.1.0";
  deps["@azure/msal-node"] = "^5.2.5";
  deps["ldapts"] = "^8.1.8";
}
if (consumedServices.includes("PS.DATA")) {
  // @dbp/platform-db is required by the data route's init-database import
  deps["@dbp/platform-db"] = "workspace:*";
}
if (hasContact && !deps["@dbp/ps-notif"]) {
  // Contact API route imports getEmailTransport from @dbp/ps-notif/server.
  // Add the package if not already pulled in via consumes_platform_services.
  deps["@dbp/ps-notif"] = "workspace:*";
}
if (rateLimitEnabled && !deps["@dbp/ps-apigw"]) {
  // GAP-BRS-5: middleware.ts imports the rate-limit seam from @dbp/ps-apigw/server
  // unconditionally when rate limiting is enabled (manifest.rateLimit.enabled, default
  // true) — independent of whether PS.APIGW is in consumes_platform_services (PS.APIGW
  // is config-only per its SERVICE.md and most solutions don't declare it as consumed).
  deps["@dbp/ps-apigw"] = "workspace:*";
}
// G8: migration-governance toolchain requires the `postgres` client to run
// scripts/db-migrate.mjs (env-agnostic migration runner) against a real DB.
if (isPersistentStorage) {
  deps["postgres"] = "^3.4.5";
  // @dbp/platform-db declares drizzle-orm as a peerDependency, and next.config.ts's
  // serverExternalPackages (G6) externalizes it the same way as postgres above —
  // it must be a direct dependency here too, or pnpm's strict linking leaves it
  // unresolvable at runtime (the exact bug that crashlooped apps/dws-03's Postgres
  // bootstrap; fixed there directly in commit 111b25a9, fixed at the source here).
  // Version matches packages/stack/platform-db's own devDependency pin.
  deps["drizzle-orm"] = "^0.45.2";
}
if (hasCommandPalette && !deps["@dbp/organisms"]) {
  // APP.F26 Command Palette — chrome-level mount (authenticated-client-shell.tsx),
  // gated on manifest.capabilities, so it is never picked up via usedFeatureIds.
  deps["@dbp/organisms"] = "workspace:*";
}
if (consumedServices.includes("PS.WORKFLOW")) {
  // SP-5/SP-8: the workflow route mount + scheduler mount import @dbp/ps-scheduler/server
  // whenever PS.WORKFLOW is consumed (bootstrap + scheduler leg are unconditional).
  deps["@dbp/ps-scheduler"] = "workspace:*";
  // PS-WORKFLOW-UI §5b: any manifest entity declaring workflows[] gets the workflow-bound
  // stepper wired into its LVE/EntityList surfaces — the emitted page imports
  // @dbp/organisms/workflow-binding, so the package must be declared here.
  const hasWorkflowBindings = (manifest.entities ?? []).some(
    (e) => Array.isArray(e.workflows) && e.workflows.length > 0,
  );
  if (hasWorkflowBindings) {
    deps["@dbp/organisms"] = "workspace:*";
  }
}

const packageJson = {
  name: appName,
  version: "0.0.0",
  private: true,
  // Pinned so pnpm/action-setup in the emitted pr-checks.yml workflow resolves the
  // same pnpm as the blueprint monorepo (standalone exports run CI from this file).
  packageManager: "pnpm@11.5.3",
  scripts: {
    dev: manifest.dev?.port ? `next dev -p ${manifest.dev.port}` : "next dev",
    build: "next build",
    start: "next start",
    typecheck: "tsc --noEmit",
    // Quality-infra bundle: every solution ships lint wiring + the single
    // documented gate command (`pnpm verify`) from day one. Rules live in
    // @dbp/config/eslint so updates arrive via a package bump, not hand-edits.
    // No --max-warnings: warn-level rules (e.g. max-lines) are deliberately
    // non-blocking so already-over-budget files don't gate work in flight —
    // only errors fail this script. ESLint's own default exit behaviour
    // already fails on any error regardless of warning count. New warnings
    // are still capped: scripts/check-ratchet.mjs's lintWarnings count is a
    // baseline ratchet (GG-17) — it can't grow, only shrink.
    lint: "eslint .",
    verify: "pnpm typecheck && pnpm lint && pnpm test && node scripts/check-ratchet.mjs && node scripts/check-env.mjs",
    // Standalone CI parity (Increment H) — same warn-baseline commands the monorepo runs in
    // dbp-pipeline.yml, scoped to this solution. Adoption mode: exit 0 unless run with --strict.
    "test:a11y": "playwright test --config=playwright.a11y.config.ts",
    // UX audit harness (deterministic layer) — companion to e2e/ux-audit-brief.md's
    // agentic audit. See docs/03-features/specs/ux-audit-harness-2026-07-17.md.
    ...(HAS_AUTH ? { "test:ux": "playwright test --config=playwright.ux.config.ts" } : {}),
    "test:bundle": "size-limit",
    "test:coverage": "vitest run --coverage && node scripts/check-coverage-ratchet.mjs",
    "test:structured-logs": "node scripts/check-structured-logs.mjs",
    // Every app carries the shared /logout route test (added in the auth template),
    // and may carry its own vitest.config.ts + tests/. --passWithNoTests keeps
    // `turbo test` green for apps that have none. (vitest devDep below.)
    test: "vitest run --passWithNoTests",
    // G8: migration-governance toolchain — every postgres-mode app gets these
    // scripts wired for free (scaffold-solution.mjs), never hand-authored.
    ...(isPersistentStorage
      ? {
          "db:migrate": "node scripts/db-migrate.mjs",
          "db:check": "node scripts/check-migrations.mjs",
          "db:sync-platform": "node scripts/sync-platform-migrations.mjs",
          "db:snapshot": "bash scripts/db-snapshot.sh",
        }
      : {}),
  },
  dbp: {
    solutionId: manifest.solution,
  },
  dependencies: Object.fromEntries(Object.entries(deps).sort(([a], [b]) => a.localeCompare(b))),
  devDependencies: {
    "@dbp/config": "workspace:*",
    // Component-test enablement: jsdom environment (opted into per-file via the
    // `// @vitest-environment jsdom` pragma) + testing-library for render smoke
    // tests. Without these, component tests are structurally impossible in a UI
    // scaffold (the DWS.01 audit's 2.9 finding).
    "@testing-library/react": "^16.1.0",
    "@types/node": "^22.10.0",
    "@types/react": "^19.1.0",
    "@types/react-dom": "^19.1.0",
    // CSS build pipeline — hoisted from root in the monorepo but must be
    // declared here so standalone exports have them available.
    autoprefixer: "^10.4.21",
    // Standalone CI parity (Increment H): same NFR tooling the monorepo uses for
    // N5 (a11y)/N6 (bundle budget)/N9 (coverage ratchet), warn-baseline mode.
    "@axe-core/playwright": "^4.12.1",
    "@playwright/test": "^1.60.0",
    "@vitest/coverage-v8": "^3.2.0",
    "size-limit": "^12.1.0",
    "@size-limit/file": "^12.1.0",
    // The lint rules themselves ship inside @dbp/config (its own dependencies);
    // the app only needs the eslint host binary (@dbp/config peer dependency).
    eslint: "^9.17.0",
    jsdom: "^25.0.1",
    postcss: "^8.5.3",
    tailwindcss: "^3.4.17",
    typescript: "^5.7.2",
    // Required: the app-level tests (e.g. tests/logout-route.test.ts) + any
    // vitest.config.ts import from "vitest"/"vitest/config". Without this the
    // production `next build` typecheck fails to resolve them.
    vitest: "^3.2.0",
  },
};

writeFile("package.json", JSON.stringify(packageJson, null, 2) + "\n");

// ── tsconfig.json ─────────────────────────────────────────────────────────────

writeFile(
  "tsconfig.json",
  JSON.stringify(
    {
      extends: "@dbp/config/tsconfig/base.json",
      compilerOptions: {
        plugins: [{ name: "next" }],
        incremental: true,
        allowJs: true,
      },
      include: ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
      exclude: ["node_modules"],
    },
    null,
    2,
  ) + "\n",
);

// ── Quality-infra bundle ──────────────────────────────────────────────────────
// Every solution inherits the factory's quality gates at generation time:
// eslint config (one import line — rule updates arrive via @dbp/config bumps),
// vitest config with component-test enablement, a PR-checks CI workflow, and a
// quality ratchet (counts only go down). `pnpm verify` is the single documented
// gate command across all solutions. (DWS.01 audit: 0.1, 0.3, 1.7, 2.9, `verify`.)

writeFile(
  "eslint.config.mjs",
  `// Generated by scaffold-solution — do not edit.
// All rules live in @dbp/config (boundary matrix + design-system rules); this file
// only composes the presets so rule updates arrive via a @dbp/config version bump.
// dqDesignRules/maxLinesConfig are re-scoped to this app's own trees because a
// standalone repo has the app at its root — the preset's monorepo apps/** globs
// never match here. maxLinesConfig deliberately excludes app/** (generator-owned
// chrome/pages/route config, per ADR-0050) — only solution/** is hand-authored.
import dbp, { dqDesignRules, maxLinesConfig } from "@dbp/config/eslint";
import dbpNextjs from "@dbp/config/eslint/nextjs";

export default [
  ...dbp,
  ...dbpNextjs,
  ...dqDesignRules(["app/**/*.{ts,tsx}", "solution/**/*.{ts,tsx}", "components/**/*.{ts,tsx}", "lib/**/*.{ts,tsx}"]),
  ...maxLinesConfig(["solution/**/*.{ts,tsx}", "instrumentation.ts", "instrumentation.node.ts"]),
];
`,
);

writeFile(
  "vitest.config.ts",
  `// Generated by scaffold-solution — do not edit.
// Default environment is node (route/adapter tests). Component tests opt into the
// DOM per file with the pragma comment \`// @vitest-environment jsdom\` on line 1 —
// the emitted solution/pages test stubs carry it already.
import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["**/*.test.{ts,tsx}"],
    exclude: ["**/node_modules/**", "**/.next/**"],
    environment: "node",
    passWithNoTests: true,
  },
});
`,
);

writeFile(
  ".github/workflows/pr-checks.yml",
  `# Generated by scaffold-solution — do not edit.
# Quality gate for standalone solution repos: every PR runs the same \`pnpm verify\`
# a developer runs locally, plus a production build. Works offline against the
# committed @dbp tarballs — no registry access required.
name: PR checks

on:
  pull_request:
  push:
    branches: [main, master, develop]

jobs:
  verify:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22
          cache: pnpm
      - name: install
        run: pnpm install --frozen-lockfile
      # Generated Control Slice item #7 (docs/03-features/specs/spec-generated-control-slice-2026-07-11.md,
      # also Bucket B2(b)): a dedicated, unmasked \`tsc --noEmit\` step, independent of
      # \`pnpm verify\` and of \`pnpm build\`. next.config.ts's \`typescript.ignoreBuildErrors\`
      # (when a team sets it) suppresses type errors inside \`next build\` — it cannot
      # suppress this step, so real type errors can't hide from CI either way.
      - name: typecheck (unmasked tsc --noEmit)
        run: pnpm typecheck
      - name: verify (typecheck + lint + test + ratchet)
        run: pnpm verify
      - name: build
        run: pnpm build
      # Standalone CI parity (Increment H, docs/09-plans/minimum-test-plan-build-spec-2026-07-07.md
      # §5): the same factory-global NFR gates dbp-pipeline.yml runs, in the same warn-baseline
      # mode (the underlying scripts default to exit 0; only --strict makes them fatal — no
      # continue-on-error needed, matching the monorepo's own convention).
      - name: a11y smoke (warn-baseline)
        run: pnpm test:a11y
      - name: bundle budget (warn-baseline)
        run: pnpm test:bundle
      - name: coverage ratchet (adoption mode)
        run: pnpm test:coverage
      - name: structured-logs scan (adoption mode)
        run: pnpm test:structured-logs
`,
);

writeFile(
  "scripts/check-ratchet.mjs",
  `#!/usr/bin/env node
// Generated by scaffold-solution — do not edit.
// Quality ratchet: counts of known debt classes may only go DOWN. The baseline
// lives in quality-ratchet.json (solution-owned — update it when you burn debt
// down). Wired into \`pnpm verify\`; a count above baseline fails the gate.
//
// lintWarnings (GG-17): the lint script deliberately omits --max-warnings 0
// because some rules (e.g. ADR-0017 max-lines) are warn-level on purpose, so
// a hard zero-cap would gate already-over-budget files that are out of scope
// for the change in flight. Instead this ratchet counts ESLint warnings and
// caps them at the committed baseline — new warnings fail the gate, existing
// warn-level debt does not, and the baseline can only be lowered, never raised
// without review.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execSync } from "node:child_process";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SCAN_DIRS = ["app", "solution", "components", "lib"].filter((d) =>
  fs.existsSync(path.join(ROOT, d)),
);

function* walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === ".next") continue;
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(abs);
    else if (/\\.(tsx?|jsx?|css)$/.test(entry.name)) yield abs;
  }
}

function countEslintWarnings() {
  let out = "";
  try {
    out = execSync("eslint . --format json", { cwd: ROOT, encoding: "utf8", maxBuffer: 1024 * 1024 * 64 });
  } catch (err) {
    // ESLint exits 1 when errors are present — the JSON report is still on stdout.
    out = err.stdout?.toString() ?? "";
    if (!out) {
      console.warn("[ratchet] eslint run produced no output — skipping lintWarnings this run.");
      return 0;
    }
  }
  try {
    const results = JSON.parse(out);
    return results.reduce((sum, r) => sum + (r.warningCount ?? 0), 0);
  } catch {
    console.warn("[ratchet] could not parse eslint JSON output — skipping lintWarnings this run.");
    return 0;
  }
}

const counts = { orangeFills: 0, rawGrayClasses: 0, oversizeFiles: 0, lintWarnings: countEslintWarnings() };
for (const dir of SCAN_DIRS) {
  for (const file of walk(path.join(ROOT, dir))) {
    const src = fs.readFileSync(file, "utf8");
    // DQ design system: orange (--color-secondary / #FB5535) is an accent, never a fill.
    counts.orangeFills += (src.match(/bg-\\[var\\(--color-secondary\\)\\]|bg-\\[#(?:FB5535|fb5535)\\]/g) ?? []).length;
    // Raw Tailwind grays bypass the token system (allowlisted in globals.css only).
    if (!file.endsWith("globals.css")) {
      counts.rawGrayClasses += (src.match(/(?:^|["'\\s])(?:bg|text|border)-gray-\\d{2,3}/g) ?? []).length;
    }
    // Oversize applies to HAND-AUTHORED components only — generator-owned chrome
    // (header "Generated by scaffold-solution") is regenerated, not maintained here.
    if (
      /\\.(tsx|jsx)$/.test(file) &&
      !src.slice(0, 400).includes("Generated by scaffold-solution") &&
      src.split("\\n").length > 400
    ) {
      counts.oversizeFiles += 1;
    }
  }
}

const baselinePath = path.join(ROOT, "quality-ratchet.json");
if (!fs.existsSync(baselinePath)) {
  fs.writeFileSync(baselinePath, JSON.stringify(counts, null, 2) + "\\n");
  console.log("[ratchet] no baseline found — wrote current counts as quality-ratchet.json");
  process.exit(0);
}
const baseline = JSON.parse(fs.readFileSync(baselinePath, "utf8"));
let failed = false;
for (const [key, value] of Object.entries(counts)) {
  const allowed = baseline[key] ?? 0;
  if (value > allowed) {
    console.error(\`[ratchet] \${key}: \${value} > baseline \${allowed} — counts only go down. Fix the new debt or (exceptionally) raise the baseline with a review.\`);
    failed = true;
  } else if (value < allowed) {
    console.log(\`[ratchet] \${key}: \${value} < baseline \${allowed} — nice. Lower the baseline in quality-ratchet.json to lock it in.\`);
  }
}
process.exit(failed ? 1 : 0);
`,
);

// Baseline is solution-owned (create-if-missing): fresh scaffolds start at zero
// debt; adopted apps set their real counts once and burn them down.
writeFile("quality-ratchet.json", JSON.stringify({ orangeFills: 0, rawGrayClasses: 0, oversizeFiles: 0 }, null, 2) + "\n");

writeFile(
  "scripts/check-env.mjs",
  `#!/usr/bin/env node
// Generated by scaffold-solution — do not edit.
// Env-drift gate (wired into \`pnpm verify\`): every process.env.X the app source
// reads must be declared in .env.example, so a fresh clone can always discover the
// full configuration surface. The generator derives .env.example from the manifest;
// this check catches drift from HAND-WRITTEN code adding undeclared reads.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
// Runtime-provided or framework-internal vars that never belong in .env.example.
const BUILTINS = new Set(["NODE_ENV", "NEXT_RUNTIME", "NEXT_PHASE", "PORT", "CI", "VERCEL", "VERCEL_ENV", "VERCEL_URL", "TZ"]);
const SCAN_DIRS = ["app", "solution", "components", "lib", "middleware.ts", "instrumentation.ts", "instrumentation.node.ts", "next.config.ts"]
  .map((d) => path.join(ROOT, d))
  .filter((d) => fs.existsSync(d));

function* walk(target) {
  const stat = fs.statSync(target);
  if (stat.isFile()) { yield target; return; }
  for (const entry of fs.readdirSync(target, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === ".next") continue;
    const abs = path.join(target, entry.name);
    if (entry.isDirectory()) yield* walk(abs);
    else if (/\\.(tsx?|jsx?|mjs)$/.test(entry.name)) yield abs;
  }
}

const declared = new Set();
const envExample = path.join(ROOT, ".env.example");
if (fs.existsSync(envExample)) {
  for (const line of fs.readFileSync(envExample, "utf8").split("\\n")) {
    const m = line.match(/^\\s*#?\\s*([A-Z][A-Z0-9_]+)=/);
    if (m) declared.add(m[1]);
  }
}

const missing = new Map();
for (const dir of SCAN_DIRS) {
  for (const file of walk(dir)) {
    const src = fs.readFileSync(file, "utf8");
    for (const m of src.matchAll(/process\\.env\\.([A-Z][A-Z0-9_]+)/g)) {
      const key = m[1];
      if (BUILTINS.has(key) || declared.has(key)) continue;
      if (!missing.has(key)) missing.set(key, path.relative(ROOT, file));
    }
  }
}

if (missing.size > 0) {
  console.error("[check-env] env vars read by the app but not declared in .env.example:");
  for (const [key, file] of missing) console.error(\`  \${key}  (first read: \${file})\`);
  console.error("Declare them (with a placeholder or comment) in .env.example.");
  process.exit(1);
}
console.log(\`[check-env] OK — all env reads declared in .env.example (\${declared.size} declared).\`);
`,
);

// D5 fix (docs/09-plans/overnight-decisions-2026-07-11.md): package.json's test:coverage and
// test:structured-logs scripts (above) call scripts/check-coverage-ratchet.mjs and
// scripts/check-structured-logs.mjs, but until this block was added neither script was ever
// emitted here — verify-scaffold's Step 0.5 (scripts-must-resolve) rightfully failed every
// scaffold/regen, and the same gap left the two scripts unresolvable for any app run with
// `pnpm --filter <app> test:coverage` from inside the monorepo (not just standalone exports).
// Both scripts (plus check-structured-logs.mjs's scripts/lib/baseline-gate.mjs dependency) are
// shipped byte-for-byte from the monorepo's own scripts/ — read here at generation time rather
// than duplicated as a template literal, so the emitted copy can never drift from the real
// implementation and there remains exactly one copy of each script's logic. export-standalone.sh's
// step 2a copies the same three files into a fresh standalone export for the same reason.
for (const scriptRelPath of [
  "scripts/check-coverage-ratchet.mjs",
  "scripts/check-structured-logs.mjs",
  "scripts/lib/baseline-gate.mjs",
]) {
  writeFile(scriptRelPath, fs.readFileSync(path.join(REPO_ROOT, scriptRelPath), "utf8"));
}

// ── Standalone CI parity (Increment H, docs/09-plans/minimum-test-plan-build-spec-2026-07-07.md) ──
// The monorepo's dbp-pipeline.yml runs a11y/bundle/coverage-ratchet/structured-logs gates in
// warn-baseline mode (adoption mode: scripts exit 0 unless run with --strict). This block gives
// every generated/exported standalone the same gates, in the same mode, so `pnpm verify` parity
// extends to the full pr-checks.yml. probe-tenant-rls.mjs is NOT re-implemented/emitted here —
// it is shipped only via export-standalone.sh's copy list (same split as the scaffold/regen
// toolchain in step 2a of that script).
// a11y (N5) and coverage (N9) additionally need a standalone-scoped e2e spec + size-limit config,
// because the monorepo's own e2e/a11y.spec.ts and .size-limit.json hardcode apps/dws-01 paths that
// don't exist in a standalone (the standalone IS the app root). Those are generated here, not
// copied, for the same reason next.config.ts/tailwind.config.mjs are generated rather than copied.
// F4/F5/F8/N9-matrix-driven checks (check-test-requirements.mjs + quality-matrix.json) are
// deliberately NOT shipped to standalones in this increment — that matrix is keyed to monorepo
// path conventions (packages/feature-*, packages/ui/*) that don't describe a standalone's layout,
// and Increment H's CI-wiring scope (build spec §5) lists only a11y/bundle/coverage/structured-logs
// for standalone parity.

writeFile(
  "e2e/a11y.spec.ts",
  `// Generated by scaffold-solution — do not edit.
// N5 a11y smoke gate (warn-baseline). Scans this solution's own key pages with
// @axe-core/playwright and fails only if violations exceed the committed baseline
// (infra/05-policy/a11y-baseline.json). Mirrors the monorepo's e2e/a11y.spec.ts, scoped to
// this app's own root instead of apps/dws-01.
import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import baseline from "../infra/05-policy/a11y-baseline.json" with { type: "json" };

const ROUTES: Array<{ key: keyof typeof baseline; path: string }> = [
  { key: "/login", path: "/login" },
];

for (const { key, path } of ROUTES) {
  test(\`a11y smoke — \${key}\`, async ({ page }) => {
    await page.goto(path);
    const results = await new AxeBuilder({ page }).analyze();

    const expected = baseline[key];
    expect(
      expected,
      \`No a11y-baseline.json entry for "\${key}" — add one before scanning a new route.\`,
    ).toBeDefined();

    test.info().annotations.push({
      type: "note",
      description: \`\${key}: \${results.violations.length} violation(s) — \${results.violations
        .map((v) => v.id)
        .join(", ") || "none"}\`,
    });

    // Warn-baseline: fail only if violations exceed the committed baseline count.
    expect(
      results.violations.length,
      \`a11y violations for \${key} increased beyond baseline (\${expected.violationCount}): \${JSON.stringify(
        results.violations.map((v) => ({ id: v.id, impact: v.impact })),
      )}\`,
    ).toBeLessThanOrEqual(expected.violationCount);
  });
}
`,
);

writeFile(
  "playwright.a11y.config.ts",
  `// Generated by scaffold-solution — do not edit.
// N5 a11y smoke gate config. Standalone version of the monorepo's playwright.a11y.config.ts —
// this repo IS the app root, so the webServer runs from "." instead of an apps/<id> subdir.
import { defineConfig, devices } from "@playwright/test";

const PORT = 3231;
const BASE_URL = \`http://localhost:\${PORT}\`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: "a11y.spec.ts",
  fullyParallel: false,
  forbidOnly: !!process.env["CI"],
  retries: 0,
  workers: 1,
  reporter: [["list"]],
  use: {
    baseURL: BASE_URL,
    trace: "on-first-retry",
  },
  outputDir: "workspace/a11y-artifacts",
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
  ],
  webServer: {
    command: \`node node_modules/next/dist/bin/next start -p \${PORT}\`,
    cwd: ".",
    url: \`\${BASE_URL}/login\`,
    reuseExistingServer: true,
    timeout: 120_000,
    stdout: "pipe",
    stderr: "pipe",
    env: {
      DBP_AUTH_SESSION_SECRET: "a11y-gate-dev-secret-not-for-production-0000000000",
    },
  },
});
`,
);

// N5 baseline starts empty — a standalone's actual routes/violations are unrelated to the
// monorepo's apps/dws-01 baseline. Fresh solutions start at zero recorded violations for
// "/login"; add more routes + baseline entries as the solution grows real pages.
writeFile(
  "infra/05-policy/a11y-baseline.json",
  JSON.stringify({ "/login": { violationCount: 0 } }, null, 2) + "\n",
);

// N6 bundle/build budget — standalone's own build output, not apps/dws-01's. No prior
// measurement exists at generation time, so the budget starts generous (5 MB) rather than
// guessing a baseline; the solution owner tightens it once they have a real build to measure
// (mirrors the monorepo's "baseline + 20% headroom" ratchet-down intent from Increment D).
writeFile(
  "size-limit.json",
  JSON.stringify(
    [
      {
        name: "standalone .next/static bundle (N6, warn-baseline; no prior build measured at generation time — tighten this budget once a real build size is known)",
        path: ".next/static/**/*.js",
        limit: "5 MB",
      },
    ],
    null,
    2,
  ) + "\n",
);

// ── next.config.ts ────────────────────────────────────────────────────────────

const transpilePackages = [
  "@dbp/contracts",
  "@dbp/ui",
  "@dbp/design-tokens",
  ...servicePackages,
  ...shellPackages,
  ...featurePackages,
];

// G6: in postgres mode, the DB adapter packages must not be bundled by webpack for
// the edge/instrumentation compile — externalize them the same way @node-saml etc. are.
const dbServerExternalPackages = isPersistentStorage ? ["postgres", "@dbp/platform-db", "drizzle-orm"] : [];
const dbWebpackExternals = isPersistentStorage
  ? `
        { "postgres": "commonjs postgres" },
        { "@dbp/platform-db": "commonjs @dbp/platform-db" },
        { "drizzle-orm": "commonjs drizzle-orm" },`
  : "";

writeFile(
  "next.config.ts",
  `import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ${JSON.stringify([...new Set(transpilePackages)], null, 2)},
  // @node-saml uses Node.js built-ins (crypto, querystring) that webpack cannot
  // bundle. Mark it as a server-only external so Next.js leaves it as a require().
  serverExternalPackages: ${JSON.stringify(["@node-saml/node-saml", "@azure/msal-node", "ldapts", ...dbServerExternalPackages])},
  webpack(config, { isServer }) {
    if (isServer) {
      const prev = Array.isArray(config.externals) ? config.externals : config.externals ? [config.externals] : [];
      config.externals = [
        ...prev,
        { "@node-saml/node-saml": "commonjs @node-saml/node-saml" },
        { "@azure/msal-node": "commonjs @azure/msal-node" },
        { "ldapts": "commonjs ldapts" },${dbWebpackExternals}
      ];
    }
    return config;
  },
  // This is generated glue code ("do not edit"). It is NOT the place type-safety is
  // enforced — the platform packages (@dbp/*) are type-checked in the monorepo via
  // \`turbo run typecheck\`, and feature configs are validated at runtime with Zod
  // (safeParse). The generated pages cast configs through loose feature input types
  // (e.g. \`Record<string, unknown>\`), which surfaces as build-time \`unknown\` type
  // errors that are not real defects. Ignore both ESLint and TS at the app build so a
  // config permutation never fails a production build. (Matches the standalone repos.)
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  // Workspace TypeScript packages use .js extension in imports (ESM convention).
  // extensionAlias lets webpack resolve .js → .ts/.tsx for transpiled packages.
  experimental: {
    extensionAlias: {
      ".js": [".ts", ".tsx", ".js"],
      ".jsx": [".tsx", ".jsx"],
    },
    // Rewrite barrel imports to per-module imports so dev compiles only what's
    // used. lucide-react is barrel-imported across the app and @dbp/ui re-exports
    // a wide index; without this both pull their whole module graph into dev.
    optimizePackageImports: ["lucide-react", "@dbp/ui"],
  },
};

export default nextConfig;
`,
);

// ── postcss.config.mjs ────────────────────────────────────────────────────────

writeFile(
  "postcss.config.mjs",
  `export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
`,
);

// ── tailwind.config.mjs ───────────────────────────────────────────────────────

// Collect workspace package directories for content globs.
// De-dupe: multiple legacy shell ids resolve to the same canonical shell dir
// (e.g. SH.01/02/03/04 → transaction), so without a Set the same glob repeats.
const shellContentGlobs = [
  ...new Set(
    [...usedShells].map(
      (id) => `../../packages/stack/app-scaffolds/shells/${SHELL_META[resolveShellId(id)]?.dir}/**/*.{ts,tsx}`,
    ),
  ),
];
// One wholesale glob, NOT a per-feature enumeration. The enumerated form
// silently missed packages mounted outside the module-features path (the
// capabilities-mounted command palette shipped with its arbitrary Tailwind
// classes — top-[12vh] — never compiled, rendering the palette off-viewport).
// Scanning unused feature sources costs a little CSS-build time and nothing
// at runtime; missing one costs an invisible component in production.
const featureContentGlobs = ["../../packages/stack/app-scaffolds/features/**/*.{ts,tsx}"];

writeFile(
  "tailwind.config.mjs",
  `import presetModule from "@dbp/config/tailwind";

// Defensive ESM interop (THE FIX, 2026-07-26): depending on the loader
// (tailwind CLI's jiti vs the Storybook/Vite pipeline), this import arrives
// either as the preset object itself or as a module namespace
// \`{ default: preset }\`. In the namespace case \`presets: [namespace]\` silently
// contributes NOTHING — no error, the theme extension is just dropped — which
// killed every preset-named utility (bg-surface-content, rounded-card,
// bg-primary, rounded-pill, …) in Storybook for its entire life while the same
// config worked via the Tailwind CLI. Unwrap both shapes explicitly. The same
// hazard applies to the root tailwind.config.mjs importing
// "./packages/config/tailwind/preset.mjs" — fix travels there separately.
const preset = presetModule?.theme ? presetModule : (presetModule?.default ?? presetModule);

/** @type {import('tailwindcss').Config} */
export default {
  presets: [preset],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./solution/**/*.{ts,tsx}",
    "../../packages/shared/ui/**/*.{ts,tsx}",
${[...shellContentGlobs, ...featureContentGlobs].map((g) => `    "${g}",`).join("\n")}
    // Exclude nested node_modules — '**' otherwise descends into each workspace
    // package's pnpm symlinks, making Tailwind scan the whole dep tree (240s+ compiles).
    "!../../packages/**/node_modules/**",
    "!./node_modules/**",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
`,
);

// ── CSS ───────────────────────────────────────────────────────────────────────

// Build theme-overrides.css from manifest.theme
let themeOverridesContent = "";
if (manifest.theme && Object.keys(manifest.theme).length > 0) {
  // Enforce the brand-as-accent + neutral-surface policy before emitting tokens.
  assertThemeColours(manifest.theme, manifest.solution, { die, warn });
  const overrides = Object.entries(manifest.theme)
    .map(([k, v]) => `  ${k}: ${String(v)};`)
    .join("\n");
  themeOverridesContent = `:root {\n${overrides}\n}\n`;
}
writeFile(
  "app/theme-overrides.css",
  themeOverridesContent || "/* No theme overrides declared in this solution manifest. */\n",
);

writeFile(
  "app/globals.css",
  `@import "@dbp/design-tokens/base.css";
@import "@dbp/design-tokens/theme.css";
@import "./theme-overrides.css";

@tailwind base;
@tailwind components;
@tailwind utilities;

/* ── App-level token supplements ──────────────────────────────────────────────
 * --mesh-hero-dark is referenced by @dbp/ui LoginPage but is not yet in the
 * shared design-tokens package. Defined here until it is promoted upstream. */
:root {
  --mesh-hero-dark: radial-gradient(
    ellipse at 20% 80%,
    oklch(0.22 0.06 264 / 0.9) 0%,
    oklch(0.18 0.05 264) 40%,
    oklch(0.12 0.04 264) 70%,
    oklch(0.10 0.03 264) 100%
  );
}

/* ── Thin scrollbar (DQ minimal aesthetic) ────────────────────────────────────
 * 3 px wide, transparent track, 12 % opacity navy thumb. Matches the minimal
 * brand aesthetic across Chrome/Edge/Safari (webkit) and Firefox. */
::-webkit-scrollbar { width: 3px; height: 3px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: oklch(0.13 0.04 264 / 0.12); border-radius: 99px; }
::-webkit-scrollbar-thumb:hover { background: oklch(0.13 0.04 264 / 0.25); }
* { scrollbar-width: thin; scrollbar-color: oklch(0.13 0.04 264 / 0.12) transparent; }

/* === @dbp package overrides ================================================
 * Local overrides of styles shipped by an @dbp package. KEEP THIS SECTION
 * EMPTY unless absolutely necessary — every override here is design debt that
 * the upstream package should eventually absorb.
 *
 * RULE: every override MUST carry a comment with (1) WHAT it overrides,
 * (2) WHY, and (3) a tracking issue link so it can be removed upstream.
 *
 * Template (copy, fill in, uncomment):
 *
 *   OVERRIDE: @dbp/ui Button — tighten padding for dense admin tables.
 *   WHY: shared default is too tall in the 13-row list archetype.
 *   ISSUE: https://github.com/DQ-SDO/dbp/issues/NNNN
 *   .dbp-button { padding-block: 0.375rem; }
 * ========================================================================== */
`,
);

// ── App icon (favicon) — Next.js app-dir convention: app/icon.svg ─────────────
// Simple DQ mark: rounded square in the solution primary colour (falls back to
// DQ navy #030F35) with an abstract orange "Q" mark (#FB5535). Resolves the
// favicon 404 every generated app otherwise hits.
const DQ_NAVY = "#030F35";
const DQ_ORANGE = "#FB5535";
const iconBg =
  (manifest.theme && manifest.theme["--color-primary"]) || DQ_NAVY;
// SP-MANIFEST-SOT: brand.favicon_accent overrides the default DQ orange accent on the favicon.
const iconAccent = manifest.brand?.favicon_accent ?? DQ_ORANGE;
writeFile(
  "app/icon.svg",
  `<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${manifest.solution}">
  <rect width="64" height="64" rx="14" fill="${iconBg}"/>
  <circle cx="32" cy="31" r="13" stroke="${iconAccent}" stroke-width="5" fill="none"/>
  <rect x="36" y="35" width="11" height="5" rx="2.5" transform="rotate(45 36 35)" fill="${iconAccent}"/>
</svg>
`,
);

// ── providers.tsx ─────────────────────────────────────────────────────────────

// Build configure calls — client SDKs expose configureXxxClient({ baseUrl })
// Determine the configure function name per service by convention:
//   PS.AUTH → configureAuthClient from @dbp/ps-auth/client
//   PS.DATA → configureDataClient (but data uses configureDataService on server side — client uses configureDataClient)
const SERVICE_CLIENT_CONFIG = {
  "PS.AUTH": { fn: "configureAuthClient", pkg: "@dbp/ps-auth/client" },
  "PS.DATA": { fn: "configureDataClient", pkg: "@dbp/ps-data/client" },
  "PS.NOTIF": { fn: "configureNotifClient", pkg: "@dbp/ps-notif/client" },
  "PS.SEARCH": { fn: "configureSearchClient", pkg: "@dbp/ps-search/client" },
  "PS.WORKFLOW": { fn: "configureWorkflowClient", pkg: "@dbp/ps-workflow/client" },
  "PS.RBAC": { fn: "configureRbacClient", pkg: "@dbp/ps-rbac/client" },
  "PS.AUDIT": { fn: "configureAuditClient", pkg: "@dbp/ps-audit/client" },
  "PS.AI": { fn: "configureAiClient", pkg: "@dbp/ps-ai/client" },
  "PS.EVENTS": { fn: "configureEventsClient", pkg: "@dbp/ps-events/client" },
  "PS.APIGW": { fn: "configureApigwClient", pkg: "@dbp/ps-apigw/client" },
};

// Check actual exported configure functions from the client packages
const clientConfigFns = consumedServices
  .map((id) => SERVICE_CLIENT_CONFIG[id])
  .filter(Boolean);

const importLines = clientConfigFns
  .map(({ fn, pkg }) => `import { ${fn} } from "${pkg}";`)
  .join("\n");

// Tenant-aware clients must be bound to the seed tenant at boot, else they
// default to tenant "default" (empty) and every data/workflow/audit/search/
// ai query returns 0 rows (or, for PS.AI, a hard 400 — its server handlers
// require x-tenant-id and have no per-request session-derived fallback,
// unlike notif/rbac/events). (Auth runs pre-session.)
const TENANT_AWARE_SERVICES = new Set([
  "PS.DATA",
  "PS.WORKFLOW",
  "PS.AUDIT",
  "PS.SEARCH",
  "PS.AI",
]);
const anyTenantAware = consumedServices.some((id) =>
  TENANT_AWARE_SERVICES.has(id),
);

writeFile(
  "app/providers.tsx",
  `"use client";

import * as React from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
${importLines}

${anyTenantAware ? `// Seed tenant — tenant-aware clients (data/workflow/audit/search) bind to this\n// at boot so queries resolve to seeded data rather than the empty "default" tenant.\n// SP-MANIFEST-SOT: tenant id sourced from manifest.dev.tenant_id (default: tenant-alpha).\nconst TENANT_ID = "${manifest.dev?.tenant_id ?? "tenant-alpha"}";\n\n` : ""}// Configure all wired platform service clients once, at app boot.
// baseUrl points to the generated API mount in this app (app/api/platform/<dir>).
${consumedServices.map((id) => {
  const meta = SERVICE_META[id];
  const cfg = SERVICE_CLIENT_CONFIG[id];
  if (!meta || !cfg) return `// ${id}: configure call omitted (no known configure fn)`;
  const tenantArg = TENANT_AWARE_SERVICES.has(id) ? `, tenantId: TENANT_ID` : "";
  return `${cfg.fn}({ baseUrl: "${meta.basePath}"${tenantArg} });`;
}).join("\n")}

export function Providers({ children }: { children: React.ReactNode }) {
  // useState so Fast Refresh doesn't recreate the client on every code edit,
  // which would clear the session cache and cause a spurious logout redirect.
  const [queryClient] = React.useState(() => new QueryClient());
  return (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  );
}
`,
);

// ── app/layout.tsx ────────────────────────────────────────────────────────────

// Emit a thin "use client" toaster wrapper — importing @dbp/ui directly in a
// server-component layout triggers the full barrel (incl. AssistantPanel hooks).
// The wrapper creates a client boundary so layout.tsx stays a server component.
writeFile(
  "app/toaster-mount.tsx",
  `"use client";
// Thin client-side wrapper that mounts the Toaster from @dbp/ui.
// Imported by layout.tsx (server component) — the "use client" boundary here
// prevents Next.js from trying to run @dbp/ui's client hooks on the server.
import { Toaster } from "@dbp/ui";

export function ToasterMount() {
  return <Toaster />;
}
`,
);

writeFile(
  "app/layout.tsx",
  `import type { ReactNode } from "react";
import { Providers } from "./providers";
import { ToasterMount } from "./toaster-mount";
import "./globals.css";

export const metadata = {
  title: "${manifest.name}",
  description: "${manifest.brand?.meta_description ?? `Generated by DBP scaffold-solution — ${manifest.solution}`}",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body style={{ backgroundColor: "var(--color-surface)", color: "var(--color-text)" }}>
        <Providers>{children}</Providers>
        <ToasterMount />
      </body>
    </html>
  );
}
`,
);

// ── Route segment for a module (DWS.04.M01 → m01) ─────────────────────────────
// Defined early so middleware derivation (below) can reference it. The page-route
// loop later in this file uses the same helper for path consistency.
//
// When the manifest declares an explicit `route` field (e.g. "/marketplace/discern"),
// that value is used verbatim (leading slash stripped) so the generator writes
// nested Next.js app-dir paths like app/marketplace/discern/page.tsx.
// Otherwise, the id-derived fallback (DWS.01.M01 → m01) is used.
function moduleRouteSegment(mod) {
  if (mod.route) {
    // Strip the required leading slash so callers get a bare segment/path string.
    // e.g. "/marketplace/discern" → "marketplace/discern"
    return mod.route.replace(/^\//, "");
  }
  const parts = mod.id.split(".");
  return parts[parts.length - 1].toLowerCase();
}

// ── Protected path prefixes — DERIVED from the routes actually emitted ────────
// Public routes ("/" landing, "/login") are NEVER protected. Everything else
// behind auth: archetype routes (/home, /marketplace, /copilot) when their
// blocks are present, plus every module route (/m01, /m02, …). The set is
// de-duped and sorted for a stable, diff-friendly emit.
const protectedPrefixes = new Set();
if (hasHome) protectedPrefixes.add("/home");
// P1 dual-surface (DXP): /marketplace is the PUBLIC-composed marketplace (PublicNavHeader +
// LandingFooter, no sidebar) — external visitors browse offerings without a session, the
// same way "/" is the public orientation surface. The authenticated in-shell catalogue is
// the standard-menu catalogue route(s). For non-DXP solutions /marketplace stays in-shell
// (auth-gated) exactly as before.
if (hasMarketplace && !isDXP) protectedPrefixes.add("/marketplace"); // covers /marketplace/[id]
if (hasCopilot) protectedPrefixes.add("/copilot");
for (const mod of manifest.modules) {
  // Public-shell modules (SH.00 / SH.PUBLIC) must NOT be added to protectedPrefixes
  // — they are public pages that must be reachable without an authenticated session.
  if (resolveShellId(mod.scaffold) === "SH.PUBLIC") continue;
  protectedPrefixes.add(`/${moduleRouteSegment(mod)}`);
}
// ── Full emitted-route set (nav href validation) ───────────────────────────────
// Superset of protectedPrefixes: every module's route (incl. SH.PUBLIC ones,
// which are emitted but not auth-protected) plus archetype-block routes and
// the always-present public routes.
const knownRoutePrefixes = new Set(protectedPrefixes);
knownRoutePrefixes.add("/");
knownRoutePrefixes.add("/login");
for (const mod of manifest.modules) {
  knownRoutePrefixes.add(`/${moduleRouteSegment(mod)}`);
}

// ── UX audit harness (agentic brief + deterministic Playwright shell audit) ────
// Every generated app ships a "naive end-user UX audit" enforcement pair, wired
// once here so no solution reimplements it:
//   1. e2e/ux-audit-brief.md — an agentic prompt (Sharavi's harsh-first-time-user
//      template) parameterized from the manifest, run by a FRESH agent session with
//      no project context. Not executed by CI — it is handed to an agent by a human
//      (or a scheduled agent run) after a deploy.
//   2. e2e/ux-shell-audit.spec.ts — deterministic Playwright coverage of the same
//      surface (login, every nav route loads, no console errors, no placeholder
//      content, list pages have data, at least one enabled primary action per page).
//      Routes are read from protectedPrefixes/manifest.modules — the SAME nav model
//      the generator synthesizes elsewhere in this file — never hand-listed.
// See docs/03-features/specs/ux-audit-harness-2026-07-17.md for the CI plan.
if (HAS_AUTH) {
  const uxRouteLabels = { "/home": "Home", "/marketplace": "Marketplace", "/copilot": "AI Cockpit" };
  const uxRoutes = [...protectedPrefixes].sort().map((prefix) => {
    const mod = manifest.modules.find((m) => `/${moduleRouteSegment(m)}` === prefix);
    return { path: prefix, label: mod ? mod.name : (uxRouteLabels[prefix] ?? prefix) };
  });

  // Demo accounts — same fallback/override logic as the login page's quick-fill
  // list (manifest.dev.seed_users, else the two accounts InMemoryIdentityProvider
  // seeds). Kept as a small local projection rather than importing the login page's
  // computed value, since that value is built inside a separate `if` block below.
  const devSeedUsersForUx = manifest.dev?.seed_users;
  const uxDemoAccounts = devSeedUsersForUx && devSeedUsersForUx.length > 0
    ? devSeedUsersForUx.map((u) => ({ label: u.label, email: u.email, password: manifest.dev?.password ?? "dbp-dev-password" }))
    : [
        { label: "Platform Admin", email: "platform-admin@alpha.dev.local", password: "dbp-dev-password" },
        { label: "Demo User", email: "user-01@alpha.dev.local", password: "dbp-dev-password" },
      ];

  // 2-3 concrete user journeys, derived from the manifest's modules/features — the
  // first feature's config.entityType (when present) names a real record type so
  // the journey reads as "find a <thing>, open it, look for actions" instead of a
  // generic "poke around" instruction.
  const uxJourneys = [];
  for (const mod of manifest.modules) {
    if (uxJourneys.length >= 3) break;
    const route = `/${moduleRouteSegment(mod)}`;
    const entityType = (mod.features ?? []).map((f) => f?.config?.entityType).find(Boolean);
    uxJourneys.push(
      entityType
        ? `Open **${mod.name}** (${route}) — find a ${entityType} record in the list, open its detail view, and look for the actions a real employee doing this job would expect (edit, approve, escalate, comment, export). Note anything that looks like a placeholder, does nothing when clicked, or is missing data.`
        : `Open **${mod.name}** (${route}) — explore what's there. Does the data look real/seeded or empty/fake? Try every button and link you can find and note what actually happens.`,
    );
  }
  if (uxJourneys.length === 0) {
    uxJourneys.push("Explore whatever pages you can reach from the main navigation and report what you find.");
  }

  const uxPort = manifest.dev?.port ?? 3000;
  const uxAppUrl = `http://localhost:${uxPort}`;
  const uxDemoAccountsMd = uxDemoAccounts
    .map((a) => `- **${a.label}** — \`${a.email}\` / \`${a.password}\``)
    .join("\n");
  const uxJourneysMd = uxJourneys.map((j, i) => `${i + 1}. ${j}`).join("\n");

  writeFile(
    "e2e/ux-audit-brief.md",
    `<!-- Generated by scaffold-solution — do not edit. Regenerate to pick up manifest changes. -->
# UX Audit Brief — ${manifest.name} (${manifest.solution})

**Run this brief in a FRESH agent session with zero project context.** Do not paste in
this repo's code, this generator's output, or any prior audit history — the whole point
is to see the app the way a real first-time end user would. If you already know how this
app is built, you are the wrong reviewer for this brief.

You are a real end user evaluating a live web application for the first time — **NOT a
code reviewer.** You have no prior context on this app, its codebase, or how it was
built. You only have a browser. Do not read source code, do not open a repository, do
not ask for implementation details. Everything you learn, you learn by looking at the
rendered pages.

## 1. Navigate and log in

Go to **${uxAppUrl}**.

Demo accounts (password shown is literal, not a placeholder):

${uxDemoAccountsMd}

**If login fails, is broken, or does not land you somewhere useful — that is a CRITICAL
finding.** Stop treating this as a minor bug: a real user who can't log in never sees
anything else the app offers, and the audit report must lead with this.

## 2. Broad exploration first

Before diving into any specific task, click around. Open every item in the main
navigation. Get a feel for what this app claims to do and who it's for. Take
screenshots as you go — you'll need them as evidence in your report.

## 3. Specific journeys

Once you have a feel for the app, run these journeys end to end:

${uxJourneysMd}

## 4. Evaluate every page you visit against this checklist

- **Real vs. shell** — is this a working feature, or an empty shell with a title and
  nothing else?
- **Populated vs. blank** — do lists, tables, and charts show actual rows/data, or are
  they empty with no explanation?
- **Do buttons do something** — click every visible button and interactive control.
  Does it do what its label implies? Does it silently no-op?
- **Crashes, spinners, dead ends** — did anything throw a visible error, spin forever,
  or navigate you to a 404/blank page?
- **The bottom-line question** — could a real employee in this role actually do their
  job today using only what's on screen, or would they immediately go back to email/
  spreadsheets?

## 5. Evidence

For every page you evaluate, capture a screenshot AND the page's rendered text (not
source HTML). For every defect you find, write concrete repro steps: what you clicked,
what you expected, what actually happened.

## 6. Be harsh and honest

You are not here to be encouraging. Do not soften findings to be polite. If a page is a
shell with no real functionality, say "this is a shell with no real functionality" — not
"this could use some polish." Assume this report will be used to decide whether the app
is production-ready, and your job is to try to prove it is NOT — the fewer holes you
can poke in it, the more confidence the decision-makers should have.

## 7. Final message

End your session with a full audit report as your final message (not a file no one will
read): a page-by-page verdict, the defects you found with repro steps, and an overall
production-readiness verdict with your reasoning.
`,
  );

  const uxRoutesJson = JSON.stringify(uxRoutes, null, 2).replace(/\n/g, "\n  ").replace(/"([a-zA-Z][a-zA-Z0-9]*)":/g, '$1:');
  const uxDemoAccountLiteral = `{ email: ${JSON.stringify(uxDemoAccounts[0].email)}, password: ${JSON.stringify(uxDemoAccounts[0].password)} }`;

  writeFile(
    "e2e/ux-shell-audit.spec.ts",
    `// Generated by scaffold-solution — do not edit.
// Deterministic companion to e2e/ux-audit-brief.md's agentic audit. Proves the
// authenticated shell is real, not a demo shell: login succeeds, every synthesized
// nav route loads without a console error, main content is not a placeholder, list
// pages return seeded data, and each page exposes at least one enabled primary
// action. Routes come from the SAME nav model the generator synthesizes elsewhere
// in scaffold-solution.mjs (protectedPrefixes/manifest.modules) — never hand-listed.
import { test, expect, type Page } from "@playwright/test";

const DEMO_ACCOUNT = ${uxDemoAccountLiteral};

const ROUTES: Array<{ path: string; label: string }> = ${uxRoutesJson};

const PLACEHOLDER_PATTERNS = [/\\bTODO\\b/i, /\\bplaceholder\\b/i, /\\blorem ipsum\\b/i];
const MIN_CONTENT_LENGTH = 40;

async function login(page: Page) {
  await page.goto("/login");
  await page.getByLabel(/email/i).fill(DEMO_ACCOUNT.email);
  await page.getByLabel(/password/i).fill(DEMO_ACCOUNT.password);
  await page.getByRole("button", { name: /sign in|log in/i }).click();
  // Login must land somewhere other than /login within a bounded timeout — a
  // broken login is a critical finding for the agentic brief and a hard test
  // failure here.
  await page.waitForURL((url) => !url.pathname.startsWith("/login"), { timeout: 10_000 });
}

test.describe("UX shell audit", () => {
  test("demo login succeeds", async ({ page }) => {
    await login(page);
    await expect(page).not.toHaveURL(/\\/login$/);
  });

  for (const route of ROUTES) {
    test(\`\${route.label} (\${route.path}) — loads with real, non-placeholder content\`, async ({ page }) => {
      const consoleErrors: string[] = [];
      page.on("console", (msg) => {
        if (msg.type() === "error") consoleErrors.push(msg.text());
      });

      await login(page);
      await page.goto(route.path);

      // A perpetual spinner/skeleton is a defect: give it a few seconds to resolve,
      // then assert it's gone.
      const spinner = page.locator("[role='status'], [data-loading='true'], .animate-spin");
      if (await spinner.count() > 0) {
        await expect(spinner.first()).toBeHidden({ timeout: 5_000 });
      }

      // Poll rather than one-shot: client-rendered list pages can pass "load"
      // before their data fetch resolves, briefly rendering only the chrome.
      const readText = async () =>
        (await page.locator("main").innerText().catch(() => page.locator("body").innerText())) ?? "";
      await expect
        .poll(async () => (await readText()).trim().length, {
          message: \`\${route.path} rendered suspiciously little content\`,
          timeout: 15_000,
        })
        .toBeGreaterThan(MIN_CONTENT_LENGTH);
      const bodyText = await readText();
      for (const pattern of PLACEHOLDER_PATTERNS) {
        expect(bodyText, \`\${route.path} contains literal placeholder text (\${pattern})\`).not.toMatch(pattern);
      }

      expect(consoleErrors, \`\${route.path} logged uncaught console errors: \${consoleErrors.join("; ")}\`).toHaveLength(0);

      // At least one primary action (enabled button) should exist on an
      // authenticated workspace page — a page with zero enabled controls is a
      // dead end for a real user.
      const enabledButtons = page.locator("button:not([disabled]), a[href]:not([aria-disabled='true'])");
      expect(
        await enabledButtons.count(),
        \`\${route.path} exposes no enabled primary action\`,
      ).toBeGreaterThan(0);
    });
  }

  test("at least one list page shows seeded data rows", async ({ page }) => {
    await login(page);
    let sawRows = false;
    for (const route of ROUTES) {
      await page.goto(route.path);
      const rows = page.locator("table tbody tr, [role='row'], [data-testid='list-row']");
      if ((await rows.count()) > 0) {
        sawRows = true;
        break;
      }
    }
    expect(sawRows, "No route showed any list/table rows — seeded data may be missing").toBe(true);
  });
});
`,
  );

  writeFile(
    "playwright.ux.config.ts",
    `// Generated by scaffold-solution — do not edit.
// UX shell audit config — standalone version, this repo IS the app root. Separate
// from playwright.a11y.config.ts because this gate needs a full authenticated
// walkthrough (login + every nav route), not just the unauthenticated /login page.
import { defineConfig, devices } from "@playwright/test";

const PORT = ${uxPort + 1};
const BASE_URL = \`http://localhost:\${PORT}\`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: "ux-shell-audit.spec.ts",
  fullyParallel: false,
  forbidOnly: !!process.env["CI"],
  retries: 0,
  workers: 1,
  reporter: [["list"]],
  use: {
    baseURL: BASE_URL,
    trace: "on-first-retry",
  },
  outputDir: "workspace/ux-audit-artifacts",
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
  ],
  webServer: {
    command: \`node node_modules/next/dist/bin/next start -p \${PORT}\`,
    cwd: ".",
    url: \`\${BASE_URL}/login\`,
    reuseExistingServer: true,
    timeout: 120_000,
    stdout: "pipe",
    stderr: "pipe",
    env: {
      DBP_AUTH_SESSION_SECRET: "ux-audit-gate-dev-secret-not-for-production-0000000000",
    },
  },
});
`,
  );
}

// ── middleware.ts ─────────────────────────────────────────────────────────────
// Security contract:
//   1. Strip inbound x-dbp-session unconditionally — internal-only header, any
//      caller-supplied value is forged identity.
//   2. Verify JWT via the app's own PS.AUTH verify endpoint (plain fetch — no
//      server import; middleware runs in the edge runtime).
//   3. On success, inject x-dbp-session = base64(JSON(session)) as all downstream
//      platform services expect per their SERVICE.md contracts.
//   4. Auth mount path excluded from verify loop (no recursion).
//   5. (GAP-BRS-5, H1/H2 Table 3) App-level rate-limit enforcement — defence-in-depth
//      only, WAF/API-gateway remains the primary control (architecture-faq.md Q19).
//      Generator branch: manifest.rateLimit.enabled (default true, computed above as
//      rateLimitEnabled) controls whether this block is emitted at all.
//      spec-deployment-hardening-2026-07-10.md §2.1.

writeFile(
  "middleware.ts",
  `import { type NextRequest, NextResponse } from "next/server";
${rateLimitEnabled ? `import { InMemoryRateLimitStorageAdapter, checkRateLimit, isRateLimitedRoute } from "@dbp/ps-apigw/server";` : ""}

const SESSION_COOKIE = "dbp_session";
const AUTH_VERIFY_PATH = "/api/platform/auth/verify";
${rateLimitEnabled ? `
// Module-scope singleton — one edge-function instance per deployment (middleware.ts,
// unlike API routes, is not split into per-route chunks), so this is safe without the
// globalThis-store pattern ps-audit/ps-data use to survive Next.js route-chunk isolation.
// In-memory only (single-instance semantics) — see rate-limit-storage.ts doc comment for
// the multi-instance caveat; a Drizzle/Redis adapter is a v2 (spec §3 out-of-scope).
const rateLimiter = new InMemoryRateLimitStorageAdapter();

const RATE_LIMIT_DEFAULTS = {
  enabled: process.env.DBP_RATE_LIMIT_ENABLED !== "false",
  authWindowSeconds: Number(process.env.DBP_RATE_LIMIT_AUTH_WINDOW_S ?? 60),
  authMaxRequests: Number(process.env.DBP_RATE_LIMIT_AUTH_MAX ?? 10),
  defaultWindowSeconds: Number(process.env.DBP_RATE_LIMIT_DEFAULT_WINDOW_S ?? 60),
  defaultMaxRequests: Number(process.env.DBP_RATE_LIMIT_DEFAULT_MAX ?? 120),
};
` : ""}

/**
 * DBP session middleware — session-verify and tenant-resolve only.
 *
 * Security contract:
 *   1. Strip inbound x-dbp-session unconditionally — it is an internal-only header
 *      that only this middleware may set. Any caller-supplied value is forged identity.
 *   2. If a dbp_session cookie or Authorization bearer is present, call the app's own
 *      PS.AUTH verify endpoint (POST /api/platform/auth/verify) to validate the JWT.
 *      On success, set x-dbp-session = base64(JSON.stringify(session)) as PS.RBAC,
 *      PS.WORKFLOW, and PS.NOTIF expect per their SERVICE.md contracts.
 *      On failure, treat as unauthenticated.
 *   3. Auth enforcement (redirect to /login for unauthenticated requests to protected
 *      routes) is delegated to the app/(authenticated)/layout.tsx server component.
 *      Middleware no longer enumerates protected prefixes (ADR-0027).
 *   4. Tenant is resolved from dbp_tenant cookie or x-tenant-id header and
 *      forwarded as x-dbp-tenant for downstream platform services.
 *
 * Cannot import @dbp/ps-auth/server — middleware runs in the edge runtime (Node subset).
 * Plain fetch to the app's own auth endpoint is the only legal verification path.
 *
 * Performance note: the per-request verify subrequest adds one loopback HTTP call.
 * This is acceptable for the blueprint. A cached in-memory verifier is a future optimisation.
 */
export async function middleware(req: NextRequest): Promise<NextResponse> {
  const { pathname } = req.nextUrl;

  // Always start from a clean header set — strip any caller-supplied x-dbp-session
  // and x-dbp-pathname (both are internal-only; caller-supplied values are forged).
  const headers = new Headers(req.headers);
  headers.delete("x-dbp-session");
  headers.delete("x-dbp-pathname");
  // Forward the request path so the server-side auth gate in
  // app/(authenticated)/layout.tsx can preserve the intended destination.
  headers.set("x-dbp-pathname", pathname + req.nextUrl.search);

  // Auth mount itself must not trigger a recursive verify subrequest.
  if (pathname.startsWith("/api/platform/auth/")) {
    return NextResponse.next({ request: { headers } });
  }

  const token =
    req.cookies.get(SESSION_COOKIE)?.value ??
    req.headers.get("authorization")?.replace(/^[Bb]earer\\s+/, "") ??
    null;

  let session: Record<string, unknown> | null = null;

  if (token) {
    try {
      const verifyUrl = \`\${req.nextUrl.origin}\${AUTH_VERIFY_PATH}\`;
      const verifyRes = await fetch(verifyUrl, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token }),
      });
      if (verifyRes.ok) {
        const body = (await verifyRes.json()) as { valid: boolean; session: Record<string, unknown> | null };
        if (body.valid && body.session !== null) {
          session = body.session;
        }
      }
    } catch {
      // Verify subrequest failed (app not ready, network error) — treat as unauthenticated.
    }
  }

  if (session !== null) {
    headers.set("x-dbp-session", Buffer.from(JSON.stringify(session)).toString("base64"));
  }

  // Resolve tenant: prefer dbp_tenant cookie, fall back to x-tenant-id header.
  const tenant =
    req.cookies.get("dbp_tenant")?.value ??
    req.headers.get("x-tenant-id") ??
    null;
  if (tenant) {
    headers.set("x-dbp-tenant", tenant);
  }

  // Auth enforcement (redirect to /login for unauthenticated requests to protected
  // routes) is handled by app/(authenticated)/layout.tsx — NOT here. This keeps
  // the middleware thin and avoids maintaining an enumerated prefix list.
${rateLimitEnabled ? `
  // (GAP-BRS-5) App-level rate limiting — defence-in-depth only, WAF/API-gateway
  // remains the primary control. Two coarse classes (auth vs. everything else under
  // /api/platform/*); per-route granular limits are a v2 (spec §3 out-of-scope).
  if (RATE_LIMIT_DEFAULTS.enabled && isRateLimitedRoute(pathname)) {
    const sessionUserId =
      session && typeof session["userId"] === "string" ? (session["userId"] as string) : undefined;
    const clientKey = sessionUserId ?? req.headers.get("x-forwarded-for") ?? "anonymous";
    const decision = await checkRateLimit(rateLimiter, {
      tenantId: tenant ?? "default",
      clientKey,
      pathname,
      defaults: RATE_LIMIT_DEFAULTS,
    });
    if (decision.limited) {
      return new NextResponse(JSON.stringify({ error: "rate_limited" }), {
        status: 429,
        headers: { "content-type": "application/json", "retry-after": String(decision.windowSeconds) },
      });
    }
  }
` : ""}
  return NextResponse.next({ request: { headers } });
}

export const config = {
  // Match all routes except Next.js internals and static assets.
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
`,
);

// ── API mounts — one per consumed service ────────────────────────────────────
// These are the sanctioned server-import seam: apps/*/app/api/platform/**
// is the ONLY zone allowed to import @dbp/ps-*/server.

// Auth dispatch is manual (routes array but no dispatch() helper in auth server)
function generateAuthRouteHandler() {
  return `// Generated API mount — PS.AUTH
// This file is the ONLY place in this app that imports @dbp/ps-auth/server.
// The narrow ESLint exception in packages/config/eslint/index.mjs covers
// apps/*/app/api/platform/** exclusively.
//
// Per-route bootstrap seam: Next.js production builds isolate route chunks (and on
// serverless platforms like Vercel each route is its own function), so the identity
// provider seeded in instrumentation.ts is NOT visible here — its in-memory store
// lives in a different chunk. Without seeding THIS chunk, loginHandler authenticates
// against an empty provider and every demo login returns 401. So this route seeds its
// own identity provider from the shared solution/fixtures/demo-identities.ts module
// (idempotent, memoized), mirroring how the PS.DATA route self-bootstraps its seed.
import { loginHandler, logoutHandler, sessionHandler, verifyHandler, providerHandler, authorizeHandler, callbackHandler, switchTenantHandler, usersHandler, AUTH_BASE_PATH, bootstrapAuthProvider, configureIdentityProvider, InMemoryIdentityProvider, configureMembershipProvider } from "@dbp/ps-auth/server";
import { type NextRequest } from "next/server";

type Handler = (req: Request) => Promise<Response>;

let _authBootstrap: Promise<void> | undefined;
async function bootstrapAuth(): Promise<void> {
  await bootstrapAuthProvider(process.env as Record<string, string | undefined>);
  try {
    // Shared demo accounts — same source the login page hints + instrumentation use.
    const mod = await import("../../../../../solution/fixtures/demo-identities.js");
    const identities = (mod as { DEMO_IDENTITIES?: unknown }).DEMO_IDENTITIES;
    if (Array.isArray(identities) && identities.length > 0) {
      configureIdentityProvider(new InMemoryIdentityProvider(identities as never));
      // Multitenant demo data (T4 ruling): derive the membership provider from the
      // SAME fixture so the workspace/tenant switcher works in this route's own
      // chunk, not just in instrumentation.ts (which isn't visible cross-chunk).
      const membershipsById: Record<string, string[]> = {};
      for (const entry of identities as Array<{ user: { id: string; memberships?: string[] } }>) {
        if (entry.user.memberships && entry.user.memberships.length > 1) {
          membershipsById[entry.user.id] = entry.user.memberships;
        }
      }
      configureMembershipProvider({
        getMemberships: async (userId: string) => membershipsById[userId] ?? [],
      });
    }
  } catch {
    // No demo-identities module (e.g. a real-IdP solution) — leave the provider as-is.
  }
}
function ensureAuthBootstrap(): Promise<void> {
  if (!_authBootstrap) _authBootstrap = bootstrapAuth();
  return _authBootstrap;
}

const ROUTES: Record<string, Partial<Record<string, Handler>>> = {
  [AUTH_BASE_PATH + "/login"]:          { POST: loginHandler },
  [AUTH_BASE_PATH + "/logout"]:         { POST: logoutHandler },
  [AUTH_BASE_PATH + "/session"]:        { GET: sessionHandler },
  [AUTH_BASE_PATH + "/verify"]:         { POST: verifyHandler },
  [AUTH_BASE_PATH + "/provider"]:       { GET: () => providerHandler() },
  [AUTH_BASE_PATH + "/authorize"]:      { GET: authorizeHandler },
  [AUTH_BASE_PATH + "/callback"]:       { GET: callbackHandler },
  [AUTH_BASE_PATH + "/switch-tenant"]:  { POST: switchTenantHandler },
  [AUTH_BASE_PATH + "/users"]:          { GET: usersHandler },
};

async function handle(req: NextRequest): Promise<Response> {
  await ensureAuthBootstrap();
  const { pathname } = new URL(req.url);
  const handler = ROUTES[pathname]?.[req.method];
  if (!handler) return new Response(null, { status: 404 });
  return handler(req as unknown as Request);
}

export { handle as GET, handle as POST, handle as DELETE, handle as PATCH, handle as PUT };
`;
}

// PS.RBAC route handler — needs a per-chunk admin-repository bootstrap (Next.js
// isolates route chunks, so the repository seeded in instrumentation.ts is NOT
// visible here). Mirrors the PS.AUTH route's self-bootstrap seam above: seed an
// InMemoryAdminRepository from the same solution/fixtures/demo-identities.ts
// module used for auth, idempotent and memoized.
function generateRbacRouteHandler() {
  return `// Generated API mount — PS.RBAC
// This file is the ONLY place in this app that imports @dbp/ps-rbac/server.
// Covered by the narrow ESLint exception in packages/config/eslint/index.mjs.
//
// Per-route bootstrap seam: PS.RBAC's admin API requires setAdminRepository()
// at startup. instrumentation.ts seeds one for the Node runtime, but Next.js
// isolates route chunks (each route is its own function on serverless
// platforms), so that repository is NOT visible here — mirrors the PS.AUTH
// route's self-bootstrap below. Storage backend selection (RBAC_ADMIN_STORAGE
// env var — "drizzle" | unset/"memory") goes through bootstrapAdminStorage(),
// the same selection seam as PS.AUDIT/PS.NOTIF; in-memory mode additionally
// seeds demo-identity role assignments so the admin UI has something to show.
import { dispatch, setAdminRepository, InMemoryAdminRepository, bootstrapAdminStorage, selectRbacAdminStorage } from "@dbp/ps-rbac/server";
import { type NextRequest } from "next/server";

let _rbacBootstrap: Promise<void> | undefined;
async function bootstrapRbac(): Promise<void> {
  await bootstrapAdminStorage(process.env as Record<string, string | undefined>);
  if (selectRbacAdminStorage(process.env as Record<string, string | undefined>).kind === "drizzle") {
    // bootstrapAdminStorage() already wired the Drizzle-backed repository.
    return;
  }
  try {
    const mod = await import("../../../../../solution/fixtures/demo-identities.js");
    const identities = (mod as { DEMO_IDENTITIES?: Array<{ user: { id: string; roles?: string[] } }> }).DEMO_IDENTITIES;
    const adminRepo = new InMemoryAdminRepository();
    if (Array.isArray(identities)) {
      adminRepo.seedUserRoles(
        identities.flatMap((entry) => (entry.user.roles ?? []).map((roleId) => ({ userId: entry.user.id, roleId }))),
      );
    }
    setAdminRepository(adminRepo);
  } catch {
    // No demo-identities module — seed an empty repository so admin mutations
    // at least don't 500 (real deployments wire RBAC_ADMIN_STORAGE=drizzle).
    setAdminRepository(new InMemoryAdminRepository());
  }
}
function ensureRbacBootstrap(): Promise<void> {
  if (!_rbacBootstrap) _rbacBootstrap = bootstrapRbac();
  return _rbacBootstrap;
}

async function handle(req: NextRequest): Promise<Response> {
  await ensureRbacBootstrap();
  return dispatch(req as unknown as Request);
}

export { handle as GET, handle as POST, handle as DELETE, handle as PATCH, handle as PUT };
`;
}

// Generic dispatch-based handler for services with a dispatch() export
function generateDispatchRouteHandler(psId) {
  const meta = SERVICE_META[psId];
  const pkgName = meta.packageName;
  return `// Generated API mount — ${psId}
// This file is the ONLY place in this app that imports ${pkgName}/server.
// Covered by the narrow ESLint exception in packages/config/eslint/index.mjs.
import { dispatch } from "${pkgName}/server";
import { type NextRequest } from "next/server";

async function handle(req: NextRequest): Promise<Response> {
  return dispatch(req as unknown as Request);
}

export { handle as GET, handle as POST, handle as DELETE, handle as PATCH, handle as PUT };
`;
}

/**
 * PS.DATA route template — SOLUTION-OWNED (create-if-missing).
 *
 * This is the first-scaffold template ONLY. The platform-data route path is
 * classified solution-owned (see isSolutionOwned), so the generator writes this
 * template once on a fresh scaffold and NEVER overwrites it on a --force regen.
 *
 * When manifest.entities is declared, the template is filled: bootstrapData() calls
 * registerAndSeedData() from solution/fixtures/seed.ts (the shared source of truth
 * that also runs in instrumentation.ts). This eliminates the "entity type X is not
 * registered" error that occurs because Next.js isolates route chunks.
 *
 * When manifest.entities is absent, the template ships with a clearly-marked seed
 * seam so the developer knows exactly where to add entity registration + seed rows.
 * Pattern reference: apps/dws-01/app/api/platform/data/[[...path]]/route.ts.
 *
 * @param {boolean} hasEntities - true when manifest.entities is declared (filled bootstrap)
 */
function generateDataRouteTemplate(hasEntities, isPersistentStorage = false) {
  if (hasEntities) {
    // G9: in postgres mode, the DB adapter must be wired into PS.DATA before
    // getDataService() is called — mirrors the drizzleBlock in instrumentation.ts.
    // Next.js isolates route chunks in production builds, so this chunk's
    // getDataService() would otherwise resolve the stale in-memory singleton.
    const drizzleInit = isPersistentStorage
      ? `  // ── 0. Drizzle / Postgres bootstrap (storage_mode: postgres) ────────────────
  // Must run before getDataService() below, or this chunk resolves the in-memory
  // service instead of the Postgres-backed one. See instrumentation.ts for details.
  // NOTE: no webpackIgnore here -- @dbp/ps-data is already in transpilePackages and
  // this import path is a static string literal, so webpack can bundle it normally.
  // webpackIgnore forces Node's own runtime loader to handle it instead, and Node
  // (22.6+) refuses to strip types for any .ts file under node_modules, throwing
  // ERR_UNSUPPORTED_NODE_MODULES_TYPE_STRIPPING and 500-ing every request that hits
  // this bootstrap in postgres mode. Found while verifying DWS.03's ADR-0039 pilot.
  const { initializePlatformDatabase } = await import("@dbp/ps-data/server/init-database");
  await initializePlatformDatabase();

`
      : "";
    return `// PS.DATA route mount — SOLUTION-OWNED (hand-edit me; never overwritten by --force).
// This file is the ONLY place in this app that imports @dbp/ps-data/server.
// Covered by the narrow ESLint exception in packages/config/eslint/index.mjs.
//
// Per-route bootstrap seam: Next.js production builds isolate route chunks, so the
// in-memory data service in this chunk is distinct from instrumentation.ts. Both
// this route and instrumentation.ts call registerAndSeedData() from the shared
// solution/fixtures/seed.ts module — the single source of truth for entity schemas
// and demo seed data. This guarantees both chunks see the same data on first request.
import { dispatch, getDataService } from "@dbp/ps-data/server";
import { type NextRequest } from "next/server";

let _dataBootstrap: Promise<void> | null = null;
async function bootstrapData(): Promise<void> {
${drizzleInit}  // Import the shared seed module — generated from manifest.entities.
  // Both this chunk and instrumentation.ts call this; each chunk gets its own
  // in-memory store (Next.js isolation), so registration + seeding is idempotent.
  const { registerAndSeedData } = await import("../../../../../solution/fixtures/seed.js");
  await registerAndSeedData(getDataService() as Parameters<typeof registerAndSeedData>[0]);
}

async function handle(req: NextRequest): Promise<Response> {
  if (!_dataBootstrap) {
    _dataBootstrap = bootstrapData().catch((e) => {
      _dataBootstrap = null;
      throw e;
    });
  }
  await _dataBootstrap;
  // ── PS.DATA interception seam ────────────────────────────────────────────────
  // Most requests pass straight through to the platform data service. To run
  // solution-specific logic on a write — enforce a lifecycle transition guard,
  // stamp an audit event, fan out a notification, recompute a derived field —
  // intercept BEFORE dispatch(). Keep the platform contract intact: return the
  // same Response shape dispatch() would, or fall through to it.
  //
  //   if (req.method === "PATCH" && req.nextUrl.pathname.includes("/entities/<type>/")) {
  //     // 1. read the pending patch:    const body = await req.clone().json();
  //     // 2. guard the transition:      assertTransitionAllowed(current.status, body.data.status);
  //     // 3. emit side-effects:         await audit(...); await notify(...);
  //   }
  //
  // Pattern guide: docs/03-Features/specs/PS-DATA-PATTERNS.md (interception seam).
  // Lifecycle guards belong in solution/adapters/<type>-lifecycle.ts (see GAP-10 / Wave 2).
  return dispatch(req as unknown as Request);
}

export { handle as GET, handle as POST, handle as DELETE, handle as PATCH, handle as PUT };
`;
  }

  return `// PS.DATA route mount — SOLUTION-OWNED (hand-edit me; never overwritten by --force).
// This file is the ONLY place in this app that imports @dbp/ps-data/server.
// Covered by the narrow ESLint exception in packages/config/eslint/index.mjs.
//
// SOLUTION-OWNED FILE CONTRACT: the generator wrote this template on first scaffold
// and will NOT regenerate it. Add your solution's entity-schema registration and
// demo seed rows in bootstrapData() below — they survive every \`--force\` regen.
// Pattern reference: apps/dws-01/app/api/platform/data/[[...path]]/route.ts.
import { dispatch, getDataService } from "@dbp/ps-data/server";
import { type NextRequest } from "next/server";

// Per-route bootstrap seam: Next.js production builds isolate route chunks, so the
// in-memory data service in this chunk is distinct from instrumentation.ts. Register
// schemas + seed here (idempotent) so this chunk's store is populated on first call.
let _dataBootstrap: Promise<void> | null = null;
async function bootstrapData(): Promise<void> {
  const dataSvc = getDataService();
  void dataSvc;
  // 1. Register solution entity schemas:
  //    const { myEntityTypeDefinition } = await import("../../../../../solution/entities/my-entity.js");
  //    try { dataSvc.registry.register(myEntityTypeDefinition as Parameters<typeof dataSvc.registry.register>[0]); } catch { /* already registered */ }
  // 2. Seed demo rows (idempotent — skip if already present):
  //    const existing = await dataSvc.storage.list(TENANT, "my-entity", { page: 1, pageSize: 1 });
  //    if (existing.total === 0) { /* seed rows via dataSvc.storage.put(TENANT, row) */ }
}

async function handle(req: NextRequest): Promise<Response> {
  if (!_dataBootstrap) {
    _dataBootstrap = bootstrapData().catch((e) => {
      _dataBootstrap = null;
      throw e;
    });
  }
  await _dataBootstrap;
  // ── PS.DATA interception seam ────────────────────────────────────────────────
  // Most requests pass straight through to the platform data service. To run
  // solution-specific logic on a write — enforce a lifecycle transition guard,
  // stamp an audit event, fan out a notification, recompute a derived field —
  // intercept BEFORE dispatch(). Keep the platform contract intact: return the
  // same Response shape dispatch() would, or fall through to it.
  //
  //   if (req.method === "PATCH" && req.nextUrl.pathname.includes("/entities/<type>/")) {
  //     // 1. read the pending patch:    const body = await req.clone().json();
  //     // 2. guard the transition:      assertTransitionAllowed(current.status, body.data.status);
  //     // 3. emit side-effects:         await audit(...); await notify(...);
  //   }
  //
  // Pattern guide: docs/03-Features/specs/PS-DATA-PATTERNS.md (interception seam).
  // Lifecycle guards belong in solution/adapters/<type>-lifecycle.ts (see GAP-10 / Wave 2).
  return dispatch(req as unknown as Request);
}

export { handle as GET, handle as POST, handle as DELETE, handle as PATCH, handle as PUT };
`;
}

// ── Manifest-driven entity + seed emission ─────────────────────────────────────
//
// When manifest.entities is declared, the generator emits:
//   solution/entities/<type>.ts     — Zod schema + JSON-schema entity-type definition
//   solution/entities/extensions.ts — GG-01 per-type extension overlays (create-if-missing)
//   solution/fixtures/seed.ts       — registerAndSeedData() shared module (OVERWRITTEN on regen)
//   instrumentation.ts              — host-seam bootstrap (create-if-missing)
//
// OWNERSHIP RULES:
//   solution/entities/<type>.ts : ALWAYS OVERWRITTEN for each listed type (direct
//                                 fs.writeFileSync, bypassing the writeFile()/isSolutionOwned
//                                 create-if-missing contract that governs everything else under
//                                 solution/entities/). Hand-authored entities NOT in
//                                 manifest.entities are untouched. The manifest stays the source
//                                 of truth for the base schema on every regen — GG-01: a solution
//                                 field NOT in manifest.entities[].fields must go in
//                                 solution/entities/extensions.ts instead of being hand-added
//                                 here, or it is silently reverted on the next --force regen.
//   solution/entities/extensions.ts : CREATE-IF-MISSING (solution-owned, via writeFile()).
//                                 GG-01 extension seam — see generateExtensionsFileContent().
//                                 Each generated <type>.ts does BaseSchema.merge(Extensions),
//                                 so a field declared here survives Schema.parse() instead of
//                                 being silently stripped as an unrecognised key. A field name
//                                 here colliding with a manifest.entities[].fields name for the
//                                 same type fails generation (see the collision check at the
//                                 manifest-entity emission call site).
//   solution/fixtures/seed.ts   : ALWAYS OVERWRITTEN when manifest.entities is present.
//                                 This file IS the generated data layer — it must reflect the
//                                 current manifest state to prevent drift. Omitted entirely when
//                                 manifest.entities is absent (no interference with hand-authored seed).
//   instrumentation.ts          : CREATE-IF-MISSING (solution-owned per isSolutionOwned).
//                                 If an app already has a hand-authored instrumentation.ts, it is
//                                 left untouched. The generated template calls registerAndSeedData()
//                                 plus the standard auth/search/workflow/events wiring seams.

/**
 * Convert a camelCase or kebab-case field name to PascalCase (for type names).
 * @param {string} name
 * @returns {string}
 */
function toPascalCase(name) {
  return name
    .replace(/-([a-z])/g, (_, c) => c.toUpperCase())
    .replace(/^([a-z])/, (_, c) => c.toUpperCase());
}

/**
 * Emit a Zod schema + JSON-schema entity-type definition file for one entity.
 *
 * The emitted shape mirrors apps/dws-01/solution/entities/task.ts exactly:
 *   - A named Zod schema (<TypePascalCase>Schema)
 *   - A <type>EntityTypeDefinition const with { type, schema: { $schema, type, properties, required, additionalProperties } }
 *
 * OWNERSHIP: CREATE-IF-MISSING for each type. If a hand-authored file already exists,
 * it is preserved (the writeFile() solution-owned contract handles this).
 *
 * @param {{ type: string, fields: Array<{name:string, type:string, enum?:string[], required?:boolean}> }} entityDef
 */
function generateEntityFileContent(entityDef) {
  const { type, fields, slugField } = entityDef;
  const typePascal = toPascalCase(type);
  const defVarName = `${type.replace(/-([a-z])/g, (_, c) => c.toUpperCase())}EntityTypeDefinition`;

  // Zod field lines
  const zodFields = fields.map((f) => {
    let zodType;
    if (f.type === "string") {
      zodType = "z.string()";
    } else if (f.type === "number") {
      zodType = "z.number()";
    } else if (f.type === "boolean") {
      zodType = "z.boolean()";
    } else if (f.type === "enum" && f.enum?.length) {
      zodType = `z.enum(${JSON.stringify(f.enum)})`;
    } else if (f.type === "string_array") {
      zodType = "z.array(z.string())";
    } else if (f.type === "json") {
      // Opaque object column — PS.DATA stores it schemalessly; validation stays
      // with the owning organism's own Zod schema (see 'json' field type doc).
      zodType = "z.record(z.string(), z.unknown())";
    } else {
      zodType = "z.unknown()";
    }
    const opt = f.required ? "" : ".optional()";
    return `  ${f.name}: ${zodType}${opt},`;
  });

  // JSON-schema properties
  const jsonProps = fields.map((f) => {
    let jsonType;
    if (f.type === "enum" && f.enum?.length) {
      jsonType = `{ type: "string", enum: ${JSON.stringify(f.enum)} }`;
    } else if (f.type === "number") {
      jsonType = `{ type: "number" }`;
    } else if (f.type === "boolean") {
      jsonType = `{ type: "boolean" }`;
    } else if (f.type === "string_array") {
      jsonType = `{ type: "array", items: { type: "string" } }`;
    } else if (f.type === "json") {
      jsonType = `{ type: "object" }`;
    } else {
      jsonType = `{ type: "string" }`;
    }
    return `      ${f.name}: ${jsonType},`;
  });

  const requiredFields = fields.filter((f) => f.required).map((f) => JSON.stringify(f.name));
  const requiredLine = requiredFields.length
    ? `    required: [${requiredFields.join(", ")}],`
    : "    required: [],";

  // SP-DATA-PATTERNS (AC-2): emit resolveByIdOrSlug helper when slugField is declared.
  const slugHelperSection = slugField
    ? `
// SP-DATA-PATTERNS: slug-routing helper.
// Use this in detail pages to accept either a UUID or a "${slugField}" slug in the URL.
// UUID check: crypto.randomUUID() produces the RFC 4122 format (8-4-4-4-12 hex digits).
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Resolve an entity by UUID or by the "${slugField}" field value.
 * @param records - array of ${typePascal} EntityRecords to search
 * @param idOrSlug - either a UUID (primary lookup) or a "${slugField}" value (slug lookup)
 * @returns the matching record, or undefined if not found
 */
export function resolveByIdOrSlug(
  records: Array<{ id: string; data: Partial<${typePascal}> }>,
  idOrSlug: string,
): { id: string; data: Partial<${typePascal}> } | undefined {
  if (UUID_RE.test(idOrSlug)) {
    return records.find((r) => r.id === idOrSlug);
  }
  return records.find((r) => r.data.${slugField} === idOrSlug);
}
`
    : "";

  return `// ${typePascal} entity schema — generated from manifest.entities.
// GENERATOR-DRIVEN FILE: re-emitted on --force regen when manifest.entities lists this type.
// To customise, either: (a) remove this type from manifest.entities and hand-author the file,
// or (b) update manifest.entities — the generator will regenerate from the new declaration.
//
// GG-01 extension seam: fields the solution needs but the manifest doesn't declare go in
// solution/entities/extensions.ts (create-if-missing, solution-owned) as \`${typePascal}Extensions\`.
// They are merged onto the base schema below, so Schema.parse() keeps them instead of
// silently stripping them. See docs/09-plans/stcb-generator-gaps-triage-2026-07-25.md GG-01.
import { z } from "zod";
import { ${typePascal}Extensions } from "./extensions.js";

const ${typePascal}BaseSchema = z.object({
${zodFields.join("\n")}
});

export const ${typePascal}Schema = ${typePascal}BaseSchema.merge(${typePascal}Extensions);

export type ${typePascal} = z.infer<typeof ${typePascal}Schema>;

export const ${defVarName} = {
  type: ${JSON.stringify(type)},
  schema: {
    $schema: "http://json-schema.org/draft-07/schema#",
    type: "object",
    properties: {
${jsonProps.join("\n")}
    },
${requiredLine}
    additionalProperties: false,
  },
} as const;
${slugHelperSection}`;
}

/**
 * Emit solution/entities/extensions.ts — the GG-01 solution-owned extension seam.
 *
 * One `<TypePascal>Extensions` z.object() per manifest.entities entry, empty by default.
 * The generated `solution/entities/<type>.ts` merges this onto its base schema
 * (`BaseSchema.merge(Extensions)`), so a field declared here survives Schema.parse()
 * instead of being silently stripped as an unrecognised key.
 *
 * OWNERSHIP: CREATE-IF-MISSING (solution-owned, via the normal writeFile() contract) —
 * hand-added fields are never touched by a regen. New entity types added to the manifest
 * later get a fresh (empty) block appended only if the file doesn't already exist; if it
 * does, the existing file — including any type it doesn't yet cover — is left untouched
 * (the solution author adds the new type's block by hand, mirroring instrumentation.ts).
 *
 * See docs/09-plans/stcb-generator-gaps-triage-2026-07-25.md GG-01.
 *
 * @param {Array<{type:string}>} entities
 */
function generateExtensionsFileContent(entities) {
  const blocks = entities.map((e) => {
    const typePascal = toPascalCase(e.type);
    return `// ${typePascal} extension overlay — add solution-specific fields here that
// manifest.entities[].fields for "${e.type}" doesn't declare. A field name here MUST NOT
// collide with a "${e.type}" manifest field name — the generator errors at generation
// time if it does.
export const ${typePascal}Extensions = z.object({
  // Example: maturityLevel: z.string().optional(),
});
`;
  });

  return `// solution/entities/extensions.ts — SOLUTION-OWNED (create-if-missing; hand-edit freely).
// GG-01 extension seam: declare fields here that a solution needs on an entity but that
// manifest.entities doesn't (yet) capture. Every generated solution/entities/<type>.ts
// merges the matching \`<TypePascal>Extensions\` schema onto its manifest-derived base
// schema, so these fields survive Schema.parse() on every write instead of being
// silently stripped. See docs/09-plans/stcb-generator-gaps-triage-2026-07-25.md GG-01.
import { z } from "zod";

${blocks.join("\n")}`;
}

/**
 * Best-effort extraction of the top-level field names declared inside a
 * `<TypePascal>Extensions = z.object({ ... })` block in an (existing, possibly
 * hand-edited) extensions.ts file — used only for the GG-01 collision check below.
 * Not a TS parser: it scans line-by-line between the block's opening and its
 * matching `});`, skipping comments, which is sufficient for the flat single-level
 * shape extensions.ts is documented to contain.
 *
 * @param {string} extensionsFileContent
 * @param {string} typePascal
 * @returns {string[]}
 */
function extractExtensionFieldNames(extensionsFileContent, typePascal) {
  const marker = `${typePascal}Extensions = z.object({`;
  const start = extensionsFileContent.indexOf(marker);
  if (start === -1) return [];
  const bodyStart = start + marker.length;
  const end = extensionsFileContent.indexOf("});", bodyStart);
  if (end === -1) return [];
  const body = extensionsFileContent.slice(bodyStart, end);
  const names = [];
  for (const line of body.split("\n")) {
    const trimmed = line.trim();
    if (trimmed === "" || trimmed.startsWith("//")) continue;
    const m = trimmed.match(/^(\w+)\s*:/);
    if (m) names.push(m[1]);
  }
  return names;
}

/**
 * Emit solution/fixtures/seed.ts — the shared registerAndSeedData() module.
 *
 * This file is imported by BOTH instrumentation.ts (server boot) AND the PS.DATA
 * route chunk (per-chunk bootstrap). Next.js isolates route chunks, so each chunk
 * must register schemas + seed its own in-memory store. Keeping seed data here
 * prevents drift between the two bootstrap sites.
 *
 * OWNERSHIP: ALWAYS OVERWRITTEN when manifest.entities is present. This is the
 * generated data layer — it must reflect the current manifest state on every regen.
 *
 * @param {Array<{type:string, fields:Array<any>, seed?:Array<any>}>} entities
 * @param {string} solutionId
 * @param {string} tenantId - SP-MANIFEST-SOT: from manifest.dev.tenant_id (default: "tenant-alpha")
 */
function generateSeedFileContent(entities, solutionId, tenantId = "tenant-alpha") {
  const defImports = entities.map((e) => {
    const defVarName = `${e.type.replace(/-([a-z])/g, (_, c) => c.toUpperCase())}EntityTypeDefinition`;
    const fileName = e.type + ".js";
    return `import { ${defVarName} } from "../entities/${fileName}";`;
  });

  const seedArrays = entities.map((e) => {
    const arrName = e.type.replace(/-([a-z])/g, (_, c) => c.toUpperCase()) + "Seed";
    if (!e.seed?.length) {
      return `export const ${arrName}: EntityRecord[] = [];`;
    }
    const rows = e.seed.map((row, i) => {
      const id = row.id ?? `generated-${e.type}-${String(i + 1).padStart(4, "0")}`;
      const ts = row.createdAt ?? "2026-01-01T00:00:00.000Z";
      // Seed rows author their fields under a `data:` key. Use that directly as
      // the entity payload; fall back to the meta-stripped rest for rows authored
      // flat (no `data` wrapper). Avoids the double-nesting (`data.data.<field>`)
      // that breaks every field read + filter downstream.
      const rest = { ...row };
      delete rest.id;
      delete rest.createdAt;
      delete rest.updatedAt;
      delete rest.type;
      delete rest.tenantId;
      const data = rest.data !== undefined ? rest.data : rest;
      return `  { id: ${JSON.stringify(id)}, type: ${JSON.stringify(e.type)}, tenantId: TENANT, createdAt: ${JSON.stringify(ts)}, updatedAt: ${JSON.stringify(ts)}, data: ${JSON.stringify(data)} },`;
    });
    return `export const ${arrName}: EntityRecord[] = [\n${rows.join("\n")}\n];`;
  });

  const registerCalls = entities.map((e) => {
    const defVarName = `${e.type.replace(/-([a-z])/g, (_, c) => c.toUpperCase())}EntityTypeDefinition`;
    // G3/G5 fix: await the (possibly async, Drizzle-backed) registration and narrow
    // the catch to SchemaConflictError so real DB failures surface instead of being
    // silently discarded on hot-reload / second chunk.
    return `    try { await dataSvc.registry.register(${defVarName}); } catch (err) { if (!(err instanceof SchemaConflictError)) throw err; }`;
  });

  // standard-menu-scaffold.mjs's buildDetailDrawerConfig() gives every entity with
  // fields.length > 0 a "comments" tab wired to the `<type>-note` PS.DATA sub-entity
  // (record-drawer/index.tsx's CommentsTab derives noteType = `${entityType}-note`
  // unconditionally). That tab is emitted independent of manifest declarations, so the
  // matching `<type>-note` schema must be registered here unconditionally too — otherwise
  // every entity's Comments tab 404s at runtime with 'entity type "<type>-note" is not
  // registered'. Mirrors the same entity/comments-tab condition so the two generators
  // can't drift out of sync again.
  const noteEntities = entities.filter((e) => Array.isArray(e.fields) && e.fields.length > 0);
  const noteDefs = noteEntities.map((e) => {
    const noteType = `${e.type}-note`;
    const defVarName = `${e.type.replace(/-([a-z])/g, (_, c) => c.toUpperCase())}NoteEntityTypeDefinition`;
    return `const ${defVarName} = {
  type: ${JSON.stringify(noteType)},
  schema: {
    $schema: "http://json-schema.org/draft-07/schema#",
    type: "object",
    properties: {
      recordId: { type: "string" },
      body: { type: "string" },
      author: { type: "string" },
      createdAt: { type: "string" },
    },
    required: ["recordId", "body"],
    additionalProperties: false,
  },
} as const;`;
  });
  const noteRegisterCalls = noteEntities.map((e) => {
    const defVarName = `${e.type.replace(/-([a-z])/g, (_, c) => c.toUpperCase())}NoteEntityTypeDefinition`;
    return `    try { await dataSvc.registry.register(${defVarName}); } catch (err) { if (!(err instanceof SchemaConflictError)) throw err; }`;
  });

  const seedCalls = entities.map((e) => {
    const arrName = e.type.replace(/-([a-z])/g, (_, c) => c.toUpperCase()) + "Seed";
    const policy = e.seedPolicy === "always" ? "always" : "once";
    return `  await seedData(dataSvc, ${JSON.stringify(e.type)}, ${arrName}, ${JSON.stringify(policy)});`;
  });

  return `// solution/fixtures/seed.ts — GENERATED from manifest.entities (${solutionId}).
// GENERATOR-DRIVEN FILE: re-emitted on every --force regen when manifest.entities is declared.
// To customise seed data: update manifest.entities.seed[] — the generator will regenerate.
// To opt out of generation: remove manifest.entities and hand-author this file instead.
//
// Imported by BOTH instrumentation.ts (server boot) AND the PS.DATA route handler chunk.
// Next.js isolates route chunks, so each chunk must register entity schemas + seed its own
// in-memory store. Keeping both in sync here prevents the "entity type X not registered" error.

import type { EntityRecord } from "@dbp/contracts/entity";
import { SchemaConflictError } from "@dbp/ps-data/server";
${defImports.join("\n")}

// SP-MANIFEST-SOT: tenant id from manifest.dev.tenant_id (defaults to "tenant-alpha").
export const TENANT = "${tenantId}";

// <type>-note sub-entities backing each entity's record-drawer Comments tab
// (see registerAndSeedData's note-registration comment below for why these exist).
${noteDefs.join("\n\n")}

${seedArrays.join("\n\n")}

type DataSvc = {
  registry: { register: (def: unknown) => unknown };
  storage: {
    put: (tenantId: string, record: EntityRecord) => Promise<void>;
    list: (tenantId: string, entityType: string, opts: { page: number; pageSize: number }) => Promise<{ total: number; rows: EntityRecord[] }>;
    transaction?: <T>(fn: (tx: DataSvc["storage"]) => Promise<T>) => Promise<T>;
  };
};

/**
 * Register all entity schemas and seed demo data into the given data service instance.
 * Idempotent: schema registration awaits the (possibly Drizzle-backed) write and only
 * swallows SchemaConflictError; other failures propagate. Seeding is row-existence-gated
 * per entity type (see seedData()) — adapter-symmetric, no longer memory-only. Safe to
 * call from both instrumentation.ts and the PS.DATA route handler chunk (each chunk has
 * its own in-memory store).
 */
export async function registerAndSeedData(dataSvc: DataSvc): Promise<void> {
  // Register ALL entity schemas into this chunk's registry (idempotent — swallows SchemaConflictError).
${registerCalls.join("\n")}

  // Register the <type>-note sub-entity backing each entity's record-drawer Comments
  // tab. standard-menu-scaffold.mjs emits that tab unconditionally for every entity
  // with fields, so its storage must be registered unconditionally here too — see
  // generateSeedFileContent()'s noteEntities comment for the full rationale.
${noteRegisterCalls.join("\n")}

  // Seed each entity type independently.
${seedCalls.join("\n")}
}

// SP-DATA-PATTERNS (AC-1): atomic seed via transaction when the adapter supports it.
// If storage.transaction() is available, wraps all puts in a single transaction so a
// mid-seed failure leaves zero partial rows. Falls back to sequential puts on adapters
// without transaction support (e.g. custom adapters not yet upgraded).
//
// GG-06/GG-07 fix: seeding is gated by a single bulk list() per entity type (not a
// per-record get() — remote Postgres round-trips are too slow for that, see
// docs/09-plans/seed-migration-ownership-design-2026-07-25.md OQ4) whose ids are
// diffed against the fixture set client-side; only rows whose id is absent for this
// TYPE are put(). This is adapter-symmetric (fixes the Postgres-only clobber where
// storage.put() unconditionally upserted every boot) and correctly relies on the
// composite (type, id) upsert target added in @dbp/platform-db 0.1.5 — without that,
// a fixture id colliding with a different type's id would clobber the wrong row while
// still probing "absent" under a type-scoped list().
//
// policy: "once" (default) applies the row-existence gate above — a row, once present
// (from fixture OR migration OR runtime write), is never re-written by seed again.
// "always" (manifest.entities[].seedPolicy) restores unconditional upsert-every-boot
// for entity types a solution author has confirmed will never be migration-managed.
async function seedData(
  dataSvc: DataSvc,
  gateType: string,
  records: EntityRecord[],
  policy: "once" | "always" = "once",
): Promise<void> {
  if (records.length === 0) return;
  let pending = records;
  if (policy === "once") {
    const existing = await dataSvc.storage.list(TENANT, gateType, { page: 1, pageSize: Math.max(records.length, 1) });
    const existingIds = new Set(existing.rows.map((row) => row.id));
    pending = records.filter((record) => !existingIds.has(record.id));
    if (pending.length === 0) return;
  }
  if (typeof dataSvc.storage.transaction === "function") {
    await dataSvc.storage.transaction(async (tx) => {
      for (const record of pending) {
        await tx.put(TENANT, record);
      }
    });
  } else {
    for (const record of pending) {
      await dataSvc.storage.put(TENANT, record);
    }
  }
}
`;
}

/**
 * Emit instrumentation.ts — the Next.js host-seam bootstrap file.
 *
 * This file is the ONLY non-route location allowed to import @dbp/ps-<svc>/server.
 * It runs once at server boot and wires all consumed platform services.
 *
 * OWNERSHIP: CREATE-IF-MISSING (solution-owned). If a hand-authored instrumentation.ts
 * already exists, it is left completely untouched. Only written on first scaffold.
 *
 * The generated template calls registerAndSeedData() from solution/fixtures/seed.ts
 * (when manifest.entities is present) plus includes seam stubs for auth, search,
 * workflow, and events wiring — the operator fills in the blanks.
 *
 * @param {object} manifest - the validated solution manifest
 * @param {Set<string>} consumedSvcSet - set of consumed PS.* ids
 * @param {boolean} hasEntitiesBlock - true when manifest.entities is declared
 */
/**
 * isPersistentStorage — true when manifest.storage_mode === "postgres"
 * isFederatedAuth     — true when manifest.iam?.identity?.provider is "entra" or "oidc"
 *
 * Both default to false → byte-identical to legacy output (backward-compatible).
 */
function generateInstrumentationContent(manifest, consumedSvcSet, hasEntitiesBlock, isPersistentStorage = false, isFederatedAuth = false) {
  const hasAuth = consumedSvcSet.has("PS.AUTH");
  const hasWorkflow = consumedSvcSet.has("PS.WORKFLOW");
  const hasSearch = consumedSvcSet.has("PS.SEARCH");
  const hasEvents = consumedSvcSet.has("PS.EVENTS");
  const hasData = consumedSvcSet.has("PS.DATA");

  const imports = [];
  if (hasData) imports.push(`    { getDataService },`);
  if (hasWorkflow) imports.push(`    { getWorkflowService },`);
  if (hasSearch) imports.push(`    { getSearchService },`);
  if (hasEvents) imports.push(`    { getEventsService },`);
  // Always import bootstrapAuthProvider for env-var-driven provider selection.
  if (hasAuth && !isFederatedAuth) imports.push(`    { assertSessionSecret, bootstrapAuthProvider, configureIdentityProvider, InMemoryIdentityProvider, configureMembershipProvider },`);
  if (hasAuth && isFederatedAuth) imports.push(`    { assertSessionSecret, bootstrapAuthProvider, configureIdentityProvider },`);
  if (hasEntitiesBlock && hasData) imports.push(`    { registerAndSeedData },`);

  const importSources = [];
  if (hasData) importSources.push(`    import("@dbp/ps-data/server"),`);
  if (hasWorkflow) importSources.push(`    import("@dbp/ps-workflow/server"),`);
  if (hasSearch) importSources.push(`    import("@dbp/ps-search/server"),`);
  if (hasEvents) importSources.push(`    import("@dbp/ps-events/server"),`);
  if (hasAuth) importSources.push(`    import("@dbp/ps-auth/server"),`);
  if (hasEntitiesBlock && hasData) importSources.push(`    import("./solution/fixtures/seed.js"),`);

  const svcInit = [];
  if (hasData) svcInit.push(`  const dataSvc = getDataService();`);
  if (hasWorkflow) svcInit.push(`  const workflowSvc = getWorkflowService();`);
  if (hasSearch) svcInit.push(`  const searchSvc = getSearchService();`);
  if (hasEvents) svcInit.push(`  const eventsSvc = getEventsService();`);

  const dataBlock = hasData && hasEntitiesBlock
    ? `
  // ── 1. Register entity schemas + seed demo data (shared source of truth) ──
  // registerAndSeedData() is generated from manifest.entities and shared with the
  // PS.DATA route chunk — each chunk has its own in-memory store (Next.js isolation).
  await registerAndSeedData(dataSvc as Parameters<typeof registerAndSeedData>[0]);
`
    : hasData
    ? `
  // ── 1. Register entity schemas + seed demo data ────────────────────────────
  // TODO: import your entity type definitions and call dataSvc.registry.register()
  // then seed demo rows. See apps/dws-01/solution/fixtures/seed.ts for the pattern.
  void dataSvc;
`
    : "";

  const workflowBlock = hasWorkflow
    ? `
  // ── 2. Workflow definition registration ────────────────────────────────────
  // TODO: import your workflow definition(s) and register:
  //   const { myWorkflow } = await import("./solution/workflows/my-workflow.js");
  //   try { await workflowSvc.storage.putDefinition(TENANT, myWorkflow); } catch { /* already registered */ }
  void workflowSvc;
`
    : "";

  // ── SP-GEN-PERSIST-MODE: Drizzle bootstrap block (postgres arm) ────────────
  // G4 fix: this MUST run — and be awaited — before svcInit's getDataService()
  // call below, otherwise svcInit captures the stale in-memory service.
  // configureDataService() (called inside initializePlatformDatabase()) replaces
  // the module-level singleton rather than mutating it in place, so a reference
  // captured before this resolves stays wired to the in-memory adapter forever.
  const drizzleBlock = hasData && isPersistentStorage
    ? `
  // ── 0. Drizzle / Postgres bootstrap (storage_mode: postgres) ────────────────
  // Ensure DATABASE_URL is set in your runtime environment (Supabase / Azure Postgres).
  // Wires DrizzleEntityStorageAdapter + DrizzleSchemaRegistry into PS.DATA. Must
  // run before getDataService() is called below. If DATABASE_URL is absent the
  // service throws (fail-loud, no silent in-memory fallback in postgres mode).
  //
  // Run migrations before first boot:
  //   pnpm --filter @dbp/platform-db db:migrate
  //
  // Required env vars:
  //   DATABASE_URL  — pooled connection string (Supabase/PgBouncer, role dbp_app)
  //   DIRECT_URL    — direct connection string (migrations only, role dbp_owner)
  const { initializePlatformDatabase } = await import("@dbp/ps-data/server/init-database");
  await initializePlatformDatabase();
`
    : "";

  // Auth block — SP-GEN-PERSIST-MODE: branch on isFederatedAuth
  const iamRoles = manifest.iam?.roles ?? [];
  const roleIds = iamRoles.map((r) => r.id);
  // Federated arm: Entra / OIDC — emit env-var checklist + FederatedIdentityProvider stub
  const authBlockFederated = hasAuth && isFederatedAuth
    ? `
  // ── 3. Auth identity provider — Entra / OIDC federated (auth_mode: ${manifest.iam?.identity?.provider ?? "entra"}) ─────
  // The FederatedIdentityProvider seam is in @dbp/ps-auth/server/federated-identity.ts.
  // Wire a concrete implementation (Entra OIDC, Supabase Auth, WorkOS, etc.) here.
  //
  // Required env vars:
  //   ENTRA_TENANT_ID      — Azure AD tenant GUID (for Entra)
  //   ENTRA_CLIENT_ID      — App registration client ID
  //   ENTRA_CLIENT_SECRET  — App registration client secret
  //   SESSION_SECRET       — 32+ char random string for JWT signing (assertSessionSecret())
  //
  // Example (replace with your concrete FederatedIdentityProvider impl):
  //   const { myEntraProvider } = await import("./solution/auth/entra-provider.js");
  //   configureIdentityProvider(myEntraProvider);
  //
  // Until a concrete provider is wired, this solution falls back to the platform default.
  // See @dbp/ps-auth/server/federated-identity.ts for the FederatedIdentityProvider interface.
`
    : "";
  // SP-MANIFEST-SOT / FN-1 fix: seed demo accounts for InMemoryIdentityProvider.
  // Derived from manifest.dev.seed_users when declared; otherwise the SAME default accounts
  // the login page quick-fill shows. This eliminates the FN-1 mismatch where instrumentation
  // seeded platform-admin/user-01 but login showed finance-clerk/finance-approver.
  const devTenantIdForAuth = manifest.dev?.tenant_id ?? "tenant-alpha";
  const devSeedUsersForAuth = manifest.dev?.seed_users;
  // Tracks { userId → memberships[] } for whichever seed user carries a `memberships`
  // field, so configureMembershipProvider below can be derived from the SAME source
  // as the seed accounts (SP-MANIFEST-SOT) instead of a second hand-maintained list.
  const demoMembershipsById = {};
  const inMemoryUsers = devSeedUsersForAuth && devSeedUsersForAuth.length > 0
    ? devSeedUsersForAuth.map((u, idx) => {
        const id = u.id ?? `usr-${u.email.replace(/[^a-z0-9]/g, "-")}`;
        const displayName = u.label;
        const password = u.password ?? "dbp-dev-password";
        const defaultRoles = idx === 0 ? [`"platform-admin"`, ...roleIds.map((r) => JSON.stringify(r))] : [`"user"`, ...roleIds.slice(0, 1).map((r) => JSON.stringify(r))];
        const roles = u.roles ? u.roles.map((r) => JSON.stringify(r)) : defaultRoles;
        if (u.memberships && u.memberships.length > 1) demoMembershipsById[id] = u.memberships;
        return `      { user: { id: ${JSON.stringify(id)}, email: ${JSON.stringify(u.email)}, displayName: ${JSON.stringify(displayName)}, roles: [${roles.join(", ")}], tenantId: ${JSON.stringify(devTenantIdForAuth)} }, password: ${JSON.stringify(password)} }`;
      })
    : [
        // displayName is a real person-shaped name — humaniseRole(roles[0]) already
        // derives the role label shown alongside it in the top bar; a displayName
        // equal to the role label rendered the same string twice (Option 1 shell fix).
        // Amira Khalid carries a second membership (tenant-beta-demo) so the shell's
        // multitenant workspace switcher is demoable out of the box (T4 ruling).
        `      { user: { id: "usr-alpha-platform-admin", email: "platform-admin@alpha.dev.local", displayName: "Amira Khalid", roles: ["platform-admin"${roleIds.length ? ', ' + roleIds.map((r) => JSON.stringify(r)).join(', ') : ''}], tenantId: ${JSON.stringify(devTenantIdForAuth)}, memberships: [${JSON.stringify(devTenantIdForAuth)}, "tenant-beta-demo"] }, password: "dbp-dev-password" }`,
        `      { user: { id: "usr-alpha-user-01",         email: "user-01@alpha.dev.local",         displayName: "Demo User",       roles: ["user"${roleIds.length ? ', ' + roleIds.slice(0, 1).map((r) => JSON.stringify(r)).join(', ') : ''}],                  tenantId: ${JSON.stringify(devTenantIdForAuth)} }, password: "dbp-dev-password" }`,
      ];
  if (!(devSeedUsersForAuth && devSeedUsersForAuth.length > 0)) {
    demoMembershipsById["usr-alpha-platform-admin"] = [devTenantIdForAuth, "tenant-beta-demo"];
  }
  const demoMembershipsEntries = Object.entries(demoMembershipsById)
    .map(([id, tenants]) => `    ${JSON.stringify(id)}: ${JSON.stringify(tenants)},`)
    .join("\n");

  const authBlockInMemory = hasAuth && !isFederatedAuth
    ? `
  // ── 3. Auth identity provider ─────────────────────────────────────────────
  // Fail-fast: assertSessionSecret() throws at boot if DBP_AUTH_SESSION_SECRET is
  // unset or < 32 chars — surfaces the misconfig here, not as a 500 at first login.
  assertSessionSecret();
  // bootstrapAuthProvider is async (the DB session-store path dynamically imports the
  // driver). It reads DBP_IDP_PROVIDER and wires the correct provider. When unset or
  // "password", the in-memory demo accounts below are seeded; for ldap/entra/entra-external
  // the provider is wired from env vars. MUST be awaited or the store may not be ready.
  await bootstrapAuthProvider(process.env as Record<string, string | undefined>);

  if (!process.env.DBP_IDP_PROVIDER || process.env.DBP_IDP_PROVIDER === "password") {
    // SP-MANIFEST-SOT / FN-1: accounts derived from manifest.dev.seed_users (or default).
    // These MUST match app/login/page.tsx SEED_USERS — both derive from the same source.
    try {
      configureIdentityProvider(new InMemoryIdentityProvider([
${inMemoryUsers.join(",\n")}
      ]));
    } catch { /* already configured */ }
    // Multitenant demo data (T4 ruling): at least one seed identity carries 2+
    // memberships so the shell's workspace/tenant switcher is demoable. Wired
    // from the SAME seed source above — see SP-MANIFEST-SOT.
    const DEMO_MEMBERSHIPS: Record<string, string[]> = {
${demoMembershipsEntries}
    };
    try {
      configureMembershipProvider({
        getMemberships: async (userId: string) => DEMO_MEMBERSHIPS[userId] ?? [],
      });
    } catch { /* already configured */ }
  }
`
    : "";
  const authBlock = authBlockFederated || authBlockInMemory;

  const searchBlock = hasSearch
    ? `
  // ── 5. Index seeded data → PS.SEARCH ─────────────────────────────────────
  // TODO: iterate your seeded records and call searchSvc.adapter.index({ id, entityType, tenantId, title, body, fields }).
  void searchSvc;
`
    : "";

  const eventsBlock = hasEvents
    ? `
  // ── 6. Register event producers (events→notif bridge) ─────────────────────
  for (const type of ["workflow.advanced", "workflow.rejected"] as const) {
    try {
      eventsSvc.bus.registerProducer(type, "ps-workflow-mount");
    } catch { /* already registered */ }
  }
`
    : "";

  const hasAnyImport = imports.length > 0;

  // drizzleBlock is emitted BEFORE destructuredImports/svcInit (see below), not here —
  // getDataService() in svcInit must run after initializePlatformDatabase() resolves.
  const bodyLines = [dataBlock, workflowBlock, authBlock, searchBlock, eventsBlock]
    .filter(Boolean)
    .join("");

  const destructuredImports = hasAnyImport
    ? `  const [
${imports.join("\n")}
  ] = await Promise.all([
${importSources.join("\n")}
  ]);

${svcInit.join("\n")}
`
    : "";

  // SPLIT ON PURPOSE (see instrumentation.ts dispatcher below): instrumentation.ts is
  // compiled by Next.js for BOTH the nodejs and edge runtimes (since register() must be
  // callable from either). If the node-only imports (drizzle-orm, @dbp/ps-auth/server →
  // @node-saml/node-saml/ldapts/@azure/msal-node, etc.) live in the SAME file as the
  // exported register(), Next.js's edge-runtime compile still statically resolves those
  // dynamic import() specifiers into the edge bundle — even though a runtime check like
  // `if (process.env.NEXT_RUNTIME === "edge") return;` makes them logically unreachable —
  // and the Vercel Edge Function ships with "unsupported modules" build errors as a result
  // (that edge bundle then gets merged with middleware.ts's edge function). Moving the
  // actual bootstrap body into a separate instrumentation.node.ts file, dynamically
  // imported ONLY behind `if (process.env.NEXT_RUNTIME === "nodejs")`, lets Next.js's
  // known dead-code-elimination for that exact idiom drop the import from the edge
  // compile entirely — the edge bundle for instrumentation.ts never resolves
  // instrumentation.node.ts at all.
  const nodeContent = `// instrumentation.node.ts — Next.js Node-runtime instrumentation body for ${manifest.solution}.
// GENERATED TEMPLATE — solution-owned (create-if-missing; never overwritten by --force regen).
//
// HOST SEAM: The ONLY file outside app/api/platform/** allowed to import @dbp/ps-<svc>/server.
// ESLint boundary exception in packages/config/eslint/index.mjs covers this path.
//
// NOTE: Next.js isolates route chunks, so registering schemas/data here does NOT
// populate the PS.DATA route handler's chunk. The PS.DATA route handler bootstraps
// itself from solution/fixtures/seed.ts (same module, different chunk).
// See apps/dws-01/instrumentation.node.ts for the proven reference shape.
//
// Kept in a separate file from instrumentation.ts on purpose — see the comment in
// instrumentation.ts for why (edge-runtime bundle must never resolve this module).

export async function registerNode() {
  console.log(\`[${manifest.solution} instrumentation] registerNode() called\`);

${drizzleBlock}${destructuredImports}${bodyLines}}
`;

  const dispatcherContent = `// instrumentation.ts — Next.js instrumentation entry point for ${manifest.solution}.
// GENERATED TEMPLATE — solution-owned (create-if-missing; never overwritten by --force regen).
//
// Thin dispatcher ONLY. Next.js compiles this file for BOTH the nodejs and edge
// runtimes; the actual Node-only bootstrap logic (drizzle-orm, @dbp/ps-auth/server,
// etc.) lives in instrumentation.node.ts and must stay dynamically imported behind
// this exact \`NEXT_RUNTIME === "nodejs"\` check so the edge compile of this file never
// resolves it — otherwise those node-only packages leak into the Edge Function bundle
// (which Next.js merges with middleware.ts's edge function) and the Vercel build fails
// with "unsupported modules" for the "middleware" Edge Function. Do NOT inline any
// node-only import here, and do NOT change this to an early-return-on-edge pattern.
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { registerNode } = await import("./instrumentation.node.js");
    await registerNode();
  }
}
`;

  return { dispatcherContent, nodeContent };
}

/**
 * Audit + Events + Notif bridge — platform asset, not solution logic.
 *
 * When PS.WORKFLOW and PS.NOTIF are consumed, the generated workflow mount
 * wraps the dispatch() response. After a successful advance or reject, it:
 *   1. Appends an audit event via PS.AUDIT (if PS.AUDIT consumed): actor from
 *      x-dbp-session, action workflow.advanced / workflow.rejected, target =
 *      the workflow instance id, delta = {fromStep, toStep, status}.
 *   2. Publishes a DomainEvent on the in-process PS.EVENTS bus (if PS.EVENTS consumed).
 *   3. Sends a PS.NOTIF in-app notification to the instance's requester (from
 *      workflow context.submittedBy / requestedBy) when the actor is NOT the
 *      requester. Skip when actor === requester (approver != submitter guard).
 *
 * This is mount-seam code only — zero solution-side notification logic.
 * Failures in each leg are caught and logged; they must NOT fail the workflow
 * response. Acceptable audit-loss trade-off for the blueprint; production would
 * use the transactional outbox pattern for guaranteed delivery.
 * Guard: generated only when PS.WORKFLOW + PS.NOTIF appear in consumes_platform_services.
 */

/**
 * SP-5: scan solution/workflows/*.ts for `export const <name>: WorkflowDefinition = {...}`
 * so the generator can synthesise chunk-local bootstrap registration without a manifest
 * `workflows:` block (none exists — solution/workflows/** is hand-authored, scanned at
 * generation time same as solution/entities/** conventions elsewhere in this file).
 *
 * @param {string} solutionWorkflowsDir - absolute path to <app>/solution/workflows
 * @returns {{ file: string, exportName: string }[]}
 */
function scanSolutionWorkflows(solutionWorkflowsDir) {
  if (!fs.existsSync(solutionWorkflowsDir)) return [];
  const found = [];
  for (const entry of fs.readdirSync(solutionWorkflowsDir, { withFileTypes: true })) {
    if (!entry.isFile() || !entry.name.endsWith(".ts") || entry.name.endsWith(".d.ts")) continue;
    const abs = path.join(solutionWorkflowsDir, entry.name);
    const src = fs.readFileSync(abs, "utf8");
    const re = /export const (\w+)\s*:\s*WorkflowDefinition\b/g;
    let m;
    while ((m = re.exec(src))) {
      found.push({ file: entry.name.replace(/\.ts$/, ""), exportName: m[1] });
    }
  }
  return found;
}

/**
 * SP-5: builds the bootstrapWorkflow() body that imports + putDefinition()s every
 * discovered solution workflow, chunk-locally (route-chunk-bootstrap rule). Storage is
 * resolved first (ensureWorkflowStorage) so registration lands in the adapter production
 * will actually use, not the in-memory default. Idempotent re-registration is a no-op
 * (storage.putDefinition itself handles identical-shape 200/no-op); a changed shape at the
 * same version throws DEFINITION_VERSION_EXISTS — deliberately NOT caught here, so it
 * propagates to logs/500 at boot in persistent mode per SP-5/SP-7.
 *
 * @param {{ definition: object, instances: object[] } | null} demoKanbanWorkflow - when the
 *   standard menu synthesized an APP.F04 Kanban page (see standard-menu-scaffold.mjs's
 *   demoWorkflow()), its definition + demo instances are registered inline here too —
 *   same chunk-local seam as solution/workflows/*.ts, no new bootstrap path. Memory-adapter
 *   storage resets per chunk, so this re-seeds the board on every cold start; if omitted
 *   (no synthesized kanban page), nothing kanban-related is registered and the board falls
 *   back to its documented empty state.
 */
function generateWorkflowBootstrapBody(workflowDefs, tenantId, demoKanbanWorkflow = null) {
  const demoBlock = demoKanbanWorkflow
    ? `  // Demo data for the standard-menu APP.F04 Kanban page (standard-menu-scaffold.mjs demoWorkflow()).
  await wfSvc.storage.putDefinition(TENANT, ${JSON.stringify(demoKanbanWorkflow.definition)} as WorkflowDefinition);
  for (const inst of ${JSON.stringify(demoKanbanWorkflow.instances)} as WorkflowInstance[]) {
    await wfSvc.storage.putInstance(TENANT, inst);
  }`
    : "";
  if (workflowDefs.length === 0 && !demoKanbanWorkflow) {
    return `  const wfSvc = getWorkflowService();
  // No solution/workflows/*.ts definitions found — nothing to register.
  void wfSvc;`;
  }
  const imports = workflowDefs
    .map((d) => `  const { ${d.exportName} } = await import("../../../../../solution/workflows/${d.file}.js");`)
    .join("\n");
  const registrations = workflowDefs
    .map((d) => `  await wfSvc.storage.putDefinition(TENANT, ${d.exportName});`)
    .join("\n");
  return `  const { ensureWorkflowStorage } = await import("@dbp/ps-workflow/server/bootstrap");
  await ensureWorkflowStorage();
  const wfSvc = getWorkflowService();
  const TENANT = "${tenantId}";
${imports}
${registrations}
${demoBlock}`;
}

function generateWorkflowRouteHandlerWithBridge(hasAudit, hasEvents, hasNotifSvc, workflowDefs, tenantId, demoKanbanWorkflow = null) {
  const bootstrapBody = generateWorkflowBootstrapBody(workflowDefs, tenantId, demoKanbanWorkflow);
  const demoWorkflowTypeImport = demoKanbanWorkflow
    ? `import type { WorkflowDefinition, WorkflowInstance } from "@dbp/ps-workflow/client";`
    : "";
  const auditImport = hasAudit
    ? `import { getAuditService } from "@dbp/ps-audit/server";
import { ensureAuditStorage } from "@dbp/ps-audit/server/bootstrap";`
    : "";
  const eventsImport = hasEvents
    ? `import { getEventsService } from "@dbp/ps-events/server";`
    : "";
  const auditAppend = hasAudit
    ? `
      // Resolve entity target: prefer context.entityId so the invoice's ActivityFeed
      // shows this event by invoice id. Fallback to workflowId for traceability.
      const auditEntityId = typeof context.entityId === "string" ? context.entityId : workflowId;
      const auditEntityType = typeof context.entityType === "string" ? context.entityType
        : typeof context.entityId === "string" ? "invoice" : "workflow-instance";

      // ── 1. PS.AUDIT append ────────────────────────────────────────────────
      if (session) {
        try {
          const displayName = session.email.split("@")[0] ?? session.userId;
          await ensureAuditStorage();
          const auditSvc = getAuditService();
          await auditSvc.storage.append(tenantId, {
            id: crypto.randomUUID(),
            ts: new Date().toISOString(),
            actor: { userId: session.userId, email: session.email, displayName },
            action: mutAction === "advance" ? "workflow.advanced" : "workflow.rejected",
            target: { entityType: auditEntityType, entityId: auditEntityId },
            delta: { fromStep, toStep, status: newStatus },
            tenantId,
          });
        } catch (err) { logBridgeFailure("audit-append", tenantId, workflowId, mutAction, body.transitionId, err); }
      }`
    : "";
  const eventsPublish = hasEvents
    ? `
      // ── 2. PS.EVENTS publish ──────────────────────────────────────────────
      try {
        const bus = getEventsService().bus;
        // Register producer idempotently (may already be registered from instrumentation).
        try { bus.registerProducer(eventType, "ps-workflow-mount"); } catch { /* already registered */ }
        await bus.publish({ type: eventType, id: crypto.randomUUID(), tenantId, source: "ps-workflow-mount", payload: { workflowId, tenantId, action: mutAction, fromStep, toStep }, ts: new Date().toISOString(), correlationId: crypto.randomUUID() });
      } catch (err) { logBridgeFailure("events-publish", tenantId, workflowId, mutAction, body.transitionId, err); }`
    : "";

  const notifImport = hasNotifSvc
    ? `import { getNotifService } from "@dbp/ps-notif/server";`
    : "";
  const notifSend = hasNotifSvc
    ? `
      // ── 3. PS.NOTIF send to requester (skip when actor IS the requester) ──
      const requester = typeof context.submittedBy === "string" ? context.submittedBy
        : typeof context.requestedBy === "string" ? context.requestedBy : null;
      const invoiceNumber = typeof context.number === "string" ? context.number
        : typeof context.invoiceNumber === "string" ? context.invoiceNumber : workflowId;
      const actorId = session?.userId ?? null;
      if (requester && requester !== actorId) {
        try {
          const notifSvc = getNotifService();
          const message = mutAction === "advance"
            ? \`Invoice \${invoiceNumber} has been approved.\`
            : \`Invoice \${invoiceNumber} has been rejected.\`;
          const notif = { id: crypto.randomUUID(), to: requester, type: eventType, message, channel: "in-app" as const, status: "unread" as const, ts: new Date().toISOString(), tenantId };
          await notifSvc.storage.put(tenantId, notif);
          notifSvc.broadcast(tenantId, requester, notif);
        } catch (err) { logBridgeFailure("notif-send", tenantId, workflowId, mutAction, body.transitionId, err); }
      }`
    : "";

  const importsBlock = [demoWorkflowTypeImport, auditImport, eventsImport, notifImport].filter(Boolean).join("\n");
  const importedServices = ["@dbp/ps-workflow/server", hasAudit ? "@dbp/ps-audit/server" : null, hasEvents ? "@dbp/ps-events/server" : null, hasNotifSvc ? "@dbp/ps-notif/server" : null, "@dbp/ps-scheduler/server"]
    .filter(Boolean).join(", ");

  return `// Generated API mount — PS.WORKFLOW (with audit + events + notif bridge)
// This file is the ONLY place in this app that imports ${importedServices}.
// Covered by the narrow ESLint exception in packages/config/eslint/index.mjs.
//
// Bridge (platform asset): after a successful advance or reject:
//   1. PS.AUDIT append (actor from x-dbp-session, target = workflow instance id).
//   2. PS.EVENTS publish domain event on the in-process bus.
//   3. PS.NOTIF in-app notification to the requester (skip when actor === requester).
//   4. PS.SCHEDULER: if the landed step declares an sla, schedule a durable timer
//      (no-op when Inngest is not configured — ADR-0037 demo-mode lazy fallback).
// Legs 1–3 emit only when the corresponding service is consumed; the bootstrap
// registration (SP-5) and scheduler leg are unconditional for PS.WORKFLOW.
// Failures in each leg are caught; they must NOT fail the workflow response.
import { dispatch, getWorkflowService } from "@dbp/ps-workflow/server";
${importsBlock ? importsBlock + "\n" : ""}import { scheduleSlaTimer } from "@dbp/ps-scheduler/server";
import { SessionSchema } from "@dbp/contracts/session";
import { type NextRequest } from "next/server";

// Bootstrap workflow definitions into THIS chunk's module-scoped service instance
// (route-chunk-bootstrap rule — registration must happen in the same chunk that
// serves requests). Storage is resolved first so registration lands in the
// adapter this deployment actually uses (SP-1/SP-7). A changed shape at the same
// (id, version) throws DEFINITION_VERSION_EXISTS — intentionally NOT caught, so
// it fails loudly at boot in persistent mode rather than silently diverging.
let _wfBootstrap: Promise<void> | null = null;
async function bootstrapWorkflow(): Promise<void> {
${bootstrapBody}
}

const ADVANCE_PATH_RE = /^\\/api\\/platform\\/workflow\\/instances\\/([^/]+)\\/advance$/;
const REJECT_PATH_RE  = /^\\/api\\/platform\\/workflow\\/instances\\/([^/]+)\\/reject$/;

function decodeSession(req: NextRequest) {
  const raw = req.headers.get("x-dbp-session");
  if (!raw) return null;
  try {
    const parsed = SessionSchema.safeParse(JSON.parse(Buffer.from(raw, "base64").toString("utf8")));
    return parsed.success ? parsed.data : null;
  } catch { return null; }
}

// SP-10: bridge failures are non-transactional (see SERVICE.md caveat) — every
// failure must log tenantId, instanceId, action, transitionId, and an error
// code so they are greppable / SIEM-forwardable for later reconciliation.
function logBridgeFailure(leg: string, tenantId: string, instanceId: string | null, action: string | null, transitionId: unknown, err: unknown) {
  const code = err instanceof Error ? err.name : "UNKNOWN_ERROR";
  console.error("[workflow-bridge]", JSON.stringify({
    leg, tenantId, instanceId, action,
    transitionId: typeof transitionId === "string" ? transitionId : null,
    code,
    message: err instanceof Error ? err.message : String(err),
  }));
}

async function handle(req: NextRequest): Promise<Response> {
  if (!_wfBootstrap) _wfBootstrap = bootstrapWorkflow();
  await _wfBootstrap;

  const { pathname } = new URL(req.url);
  const advanceMatch = req.method === "POST" ? ADVANCE_PATH_RE.exec(pathname) : null;
  const rejectMatch  = req.method === "POST" ? REJECT_PATH_RE.exec(pathname)  : null;
  const mutAction = advanceMatch ? "advance" : rejectMatch ? "reject" : null;
  const workflowId = advanceMatch?.[1] ?? rejectMatch?.[1] ?? null;
  const tenantId = req.headers.get("x-tenant-id") ?? "unknown";

  // Capture actor and fromStep BEFORE dispatch (pre-transition state).
  const session = decodeSession(req);
  let fromStep: string | null = null;
  if (mutAction && workflowId && session) {
    try {
      const inst = await getWorkflowService().storage.getInstance(tenantId, workflowId);
      fromStep = inst?.currentStep ?? null;
    } catch { /* non-fatal */ }
  }

  const response = await dispatch(req as unknown as Request);

  // Bridge fires only on successful mutations (2xx) that move a workflow instance.
  if (mutAction && workflowId && response.status >= 200 && response.status < 300) {
    try {
      const body = await response.clone().json() as Record<string, unknown>;
      const context = (body.context ?? {}) as Record<string, unknown>;
      ${hasAudit || hasNotifSvc ? "" : "void context; // context consumed only by the audit/notif legs\n      "}${hasNotifSvc || hasEvents ? 'const eventType = mutAction === "advance" ? "workflow.advanced" : "workflow.rejected";' : '// eventType unused when neither PS.EVENTS nor PS.NOTIF consumed'}
      const toStep = typeof body.currentStep === "string" ? body.currentStep
        : typeof body.status === "string" ? body.status : null;
      ${hasAudit ? 'const newStatus = typeof body.status === "string" ? body.status : null;' : '// newStatus unused when PS.AUDIT not consumed'}
${auditAppend}
${eventsPublish}${notifSend}
      // ── 4. PS.SCHEDULER: durable SLA timer for the step just landed on ─────
      // No-op when Inngest is not configured (ADR-0037 demo-mode lazy fallback
      // handles breach evaluation on next read/transition instead).
      const slaDueAt = typeof body.slaDueAt === "string" ? body.slaDueAt : null;
      const slaTimerKey = typeof body.slaTimerKey === "string" ? body.slaTimerKey : null;
      if (slaDueAt && slaTimerKey && toStep) {
        try {
          await scheduleSlaTimer({ tenantId, workflowId, stepId: toStep, dueAt: slaDueAt, timerKey: slaTimerKey });
        } catch (err) { logBridgeFailure("scheduler-sla-timer", tenantId, workflowId, mutAction, body.transitionId, err); }
      }
    } catch (err) { logBridgeFailure("bridge", tenantId, workflowId, mutAction, undefined, err); }
  }

  return response;
}

export { handle as GET, handle as POST, handle as DELETE, handle as PATCH, handle as PUT };
`;
}

const hasNotif = consumedSet.has("PS.NOTIF");
const hasAuditService = consumedSet.has("PS.AUDIT");
const hasEventsService = consumedSet.has("PS.EVENTS");
const hasDataService = consumedSet.has("PS.DATA");
// SP-MANIFEST-SOT: tenant id from manifest.dev.tenant_id (default: tenant-alpha) — same
// convention used for seed.ts/instrumentation.ts elsewhere in this file.
const devTenantId = manifest.dev?.tenant_id ?? "tenant-alpha";

// manifest.entities block — drives entity file, seed.ts, and instrumentation.ts emission.
const manifestEntities = Array.isArray(manifest.entities) ? manifest.entities : [];
const hasManifestEntities = manifestEntities.length > 0;

for (const psId of consumedServices) {
  const meta = SERVICE_META[psId];
  if (!meta) continue;
  const routePath = `app/api/platform/${meta.dir}/[[...path]]/route.ts`;
  let content;
  if (psId === "PS.AUTH") {
    content = generateAuthRouteHandler();
  } else if (psId === "PS.RBAC") {
    content = generateRbacRouteHandler();
  } else if (psId === "PS.WORKFLOW") {
    // Generate the enriched mount with audit + events + notif bridge legs (each
    // conditional on its service being consumed), plus SP-5 auto-registration of
    // every solution/workflows/*.ts definition (scanned — no manifest workflows:
    // block exists; solution/workflows/** is hand-authored) and the SP-8
    // scheduler leg. Bootstrap + scheduler are UNCONDITIONAL for PS.WORKFLOW:
    // a manifest wiring PS.WORKFLOW without PS.NOTIF must still register its
    // definitions (AC-12) — the plain dispatch handler has no bootstrap seam.
    const workflowDefs = scanSolutionWorkflows(path.join(outDirBase, "solution/workflows"));
    // Standard-menu demo pages that reuse the same demoWorkflow() definition +
    // instances: APP.F04 Kanban (featKanban()), APP.F06 approval queue (P1a,
    // featApprovalQueue()), and ANL.F05 SLA Tracking (P1b, featSla()). Detected
    // by config.definitionId so a solution-authored page wired to a real
    // workflow (different definitionId) never gets this demo data injected.
    const hasDemoKanbanPage = (manifest.modules ?? []).some((m) =>
      (m.features ?? []).some(
        (f) =>
          (f.id === "APP.F04" || f.id === "APP.F06" || f.id === "ANL.F05") &&
          f.config?.definitionId === KANBAN_DEFINITION_ID,
      ),
    );
    const demoKanbanWorkflow = hasDemoKanbanPage ? demoWorkflow() : null;
    content = generateWorkflowRouteHandlerWithBridge(hasAuditService, hasEventsService, hasNotif, workflowDefs, devTenantId, demoKanbanWorkflow);
  } else if (psId === "PS.DATA") {
    // DATA-ROUTE-WRITE: conditional ownership based on manifest.entities.
    //
    // When manifest.entities is PRESENT: the filled template (registerAndSeedData) is
    // OVERWRITTEN on every regen — same always-overwrite contract as solution/fixtures/seed.ts.
    // The manifest is the source of truth; both files must stay in sync. We bypass writeFile()
    // and write directly so the solution-owned guard in isSolutionOwned() is skipped.
    //
    // When manifest.entities is ABSENT: create-if-missing via the normal writeFile() path.
    // isSolutionOwned() returns true for this path, so an existing hand-authored route is
    // preserved byte-for-byte (original option-a contract for apps that manage their own seed).
    content = generateDataRouteTemplate(hasManifestEntities, isPersistentStorage);
    // DEF-9: a manifest-declared solutionOwnedOverrides entry for this route always wins —
    // skip the always-overwrite bypass and fall through to writeFile() (create-if-missing).
    if (hasManifestEntities && !(manifest.solutionOwnedOverrides ?? []).includes(routePath)) {
      // Always-overwrite: bypass writeFile() so the solution-owned guard is skipped.
      const abs = path.join(outDirBase, routePath);
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, content, "utf8");
      emittedGeneratorOwned.add(routePath.replace(/\\/g, "/"));
      console.log(`  emitted (data-route, overwrite — entities present): ${routePath}`);
      continue;
    }
    // Fall through to writeFile() below for the create-if-missing case (no-entities, OR
    // the solution has taken this route over via solutionOwnedOverrides).
  } else {
    content = generateDispatchRouteHandler(psId);
  }
  writeFile(routePath, content);
}

// ── PS.SCHEDULER mount (SP-8/ADR-0037) ─────────────────────────────────────
// Mounted at /api/platform/scheduler/inngest whenever PS.WORKFLOW is
// consumed. fetchInstance bridges to this app's own
// PS.WORKFLOW GET /instances/:id — the scheduler package cannot import
// @dbp/ps-workflow/server directly per the platform-services import-boundary
// rule (only @dbp/contracts). Returns 404 for every method when Inngest env
// is absent (ADR-0037 demo-mode: no "inngest" import happens in that case).
if (consumedSet.has("PS.WORKFLOW")) {
  const schedulerRoutePath = "app/api/platform/scheduler/inngest/route.ts";
  const schedulerContent = `// Generated API mount — PS.SCHEDULER (SP-8 / ADR-0037)
// This file is the ONLY place in this app that imports @dbp/ps-scheduler/server
// for the scheduler mount. Covered by the narrow ESLint exception in
// packages/config/eslint/index.mjs.
//
// fetchInstance bridges to this app's own PS.WORKFLOW dispatch (GET
// /instances/:id) — @dbp/ps-scheduler cannot import @dbp/ps-workflow/server
// directly (platform services may import only @dbp/contracts).
import { dispatch } from "@dbp/ps-workflow/server";
import { createRouteHandlers } from "@dbp/ps-scheduler/server";

const fetchInstance = (tenantId: string, workflowId: string): Promise<Response> =>
  dispatch(
    new Request(\`http://internal/api/platform/workflow/instances/\${workflowId}\`, {
      headers: { "x-tenant-id": tenantId },
    }) as unknown as Request,
  );

export const { GET, POST, PUT } = createRouteHandlers(fetchInstance);
`;
  writeFile(schedulerRoutePath, schedulerContent);
}

// ── Manifest-driven entity files (solution/entities/<type>.ts) ────────────────
// OWNERSHIP: Each listed entity file is OVERWRITTEN on regen (manifest is source of truth
// for generated entities). Hand-authored entity files NOT in manifest.entities are untouched
// because writeFile's solution-owned contract (create-if-missing) handles all paths under
// solution/entities/. We bypass that contract here by writing directly for manifest-listed
// types — the manifest author accepted that regen will update their generated entities.
if (hasManifestEntities && hasDataService) {
  // GG-01 extension seam: solution/entities/extensions.ts is create-if-missing
  // (solution-owned) — write it via writeFile() BEFORE the entity files that import
  // it, and collision-check each manifest entity's fields against whatever extension
  // fields will actually end up on disk (the existing hand-authored file if present,
  // otherwise the freshly generated empty stub).
  const extensionsRelPath = "solution/entities/extensions.ts";
  const extensionsAbs = path.join(outDirBase, extensionsRelPath);
  const generatedExtensionsContent = generateExtensionsFileContent(manifestEntities);
  const effectiveExtensionsContent = fs.existsSync(extensionsAbs)
    ? fs.readFileSync(extensionsAbs, "utf8")
    : generatedExtensionsContent;

  for (const entityDef of manifestEntities) {
    const typePascal = toPascalCase(entityDef.type);
    const extensionFields = extractExtensionFieldNames(effectiveExtensionsContent, typePascal);
    const baseFieldNames = new Set(entityDef.fields.map((f) => f.name));
    const collisions = extensionFields.filter((f) => baseFieldNames.has(f));
    if (collisions.length > 0) {
      throw new Error(
        `GG-01: solution/entities/extensions.ts declares field(s) [${collisions.join(", ")}] on ` +
        `"${typePascal}Extensions" that already exist in manifest.entities[].fields for type ` +
        `"${entityDef.type}". Remove the field from extensions.ts (the manifest already owns ` +
        `it) or rename it — an extension field must not shadow a manifest-declared field.`,
      );
    }
  }
  writeFile(extensionsRelPath, generatedExtensionsContent);

  for (const entityDef of manifestEntities) {
    const relPath = `solution/entities/${entityDef.type}.ts`;
    const abs = path.join(outDirBase, relPath);
    const content = generateEntityFileContent(entityDef);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, content, "utf8");
    console.log(`  emitted (manifest-entity): ${relPath}`);
  }

  // ── solution/fixtures/seed.ts — OVERWRITTEN when manifest.entities present, UNLESS the
  // solution has declared it in manifest.solutionOwnedOverrides (DEF-9). GG-22 fix: this
  // used to bypass writeFile()/isSolutionOwned() unconditionally, so a declared override
  // had no effect. Now mirrors the DATA-ROUTE-WRITE override check above.
  const seedRelPath = "solution/fixtures/seed.ts";

  // GG-collision guard: fail generation if any fixture id repeats across ALL of this
  // app's manifest.entities seed arrays (not just within one type). On Postgres, a
  // colliding id across two different entity types upserts onto the same (type, id)
  // conflict target only if both types agree — but a stale pre-0.1.5 platform-db, or
  // any adapter still conflict-targeting `id` alone, silently clobbers the wrong row's
  // `data` while `type` stays unchanged, and because reads are type-filtered the
  // clobbered row then probes "absent" forever. Cheap to check at generation time
  // regardless of adapter version. See docs/09-plans/seed-migration-ownership-design-2026-07-25.md.
  {
    const seenIds = new Map(); // id -> type
    const collisions = [];
    for (const entityDef of manifestEntities) {
      for (const row of entityDef.seed ?? []) {
        const id = row.id ?? null;
        if (id === null) continue; // generated-id rows can't collide by construction
        const priorType = seenIds.get(id);
        if (priorType !== undefined && priorType !== entityDef.type) {
          collisions.push(`(${priorType}, ${id}) vs (${entityDef.type}, ${id})`);
        } else {
          seenIds.set(id, entityDef.type);
        }
      }
    }
    if (collisions.length > 0) {
      throw new Error(
        `Fixture id collision across manifest.entities seed arrays — the same id is used by ` +
        `more than one entity type, which defeats the seed row-existence gate on Postgres:\n` +
        collisions.map((c) => `  - ${c}`).join("\n") +
        `\nGive each fixture row a unique id across ALL entity types in this app's manifest.`,
      );
    }
  }

  if (!(manifest.solutionOwnedOverrides ?? []).includes(seedRelPath)) {
    // Always-overwrite: bypass writeFile() so the solution-owned guard is skipped.
    const seedAbs = path.join(outDirBase, seedRelPath);
    // SP-MANIFEST-SOT: pass tenant_id so TENANT const in seed.ts matches providers.tsx TENANT_ID.
    const seedContent = generateSeedFileContent(manifestEntities, manifest.solution, manifest.dev?.tenant_id ?? "tenant-alpha");
    fs.mkdirSync(path.dirname(seedAbs), { recursive: true });
    fs.writeFileSync(seedAbs, seedContent, "utf8");
    console.log(`  emitted (manifest-seed, overwrite): ${seedRelPath}`);
  } else {
    // Solution has taken this file over via solutionOwnedOverrides — fall through to
    // writeFile()'s create-if-missing path. The solution now owns 100% of seed.ts
    // content, including re-adding any manifest-derived seed arrays by hand if the
    // manifest changes afterward.
    const placeholderContent = generateSeedFileContent(manifestEntities, manifest.solution, manifest.dev?.tenant_id ?? "tenant-alpha");
    writeFile(seedRelPath, placeholderContent);
  }
}

// ── instrumentation.ts — create-if-missing (solution-owned) ──────────────────
// Emitted as a working template whenever PS.DATA is consumed (the most common case
// needing a host-seam bootstrap). When manifest.entities is declared, the template
// calls registerAndSeedData() from solution/fixtures/seed.ts.
// If a hand-authored instrumentation.ts already exists, it is left completely untouched.
if (hasDataService) {
  // SP-GEN-PERSIST-MODE: resolve mode flags from the validated manifest.
  // isPersistentStorage is hoisted near the next.config.ts emission (G6) and reused here.
  const persistAuthProvider = manifest.iam?.identity?.provider;
  const isFederatedAuth = persistAuthProvider === "entra" || persistAuthProvider === "oidc";

  // writeFile respects the solution-owned contract (create-if-missing) for
  // instrumentation.ts / instrumentation.node.ts (kept as two files — see the
  // comment inside generateInstrumentationContent for why the split is required).
  const { dispatcherContent, nodeContent } = generateInstrumentationContent(manifest, consumedSet, hasManifestEntities, isPersistentStorage, isFederatedAuth);
  writeFile("instrumentation.ts", dispatcherContent);
  writeFile("instrumentation.node.ts", nodeContent);

  // Auth-bootstrap smoke test (solution-owned, create-if-missing) — STCB test-gap
  // reinforcement lever 3: asserts the host-seam bootstrap resolves without throwing,
  // catching BC-1-class regressions (auth provider wiring, session-secret assert) on
  // every blueprint bump. Skipped in postgres mode: register() needs a live database
  // there, which unit CI does not have.
  writeFile(
    "solution/__tests__/auth-bootstrap.test.ts",
    `// SOLUTION-OWNED bootstrap smoke test — emitted once by scaffold-solution.
// Proves instrumentation.node.ts registerNode() resolves: schema registration, seed
// wiring, and auth-provider bootstrap all succeed against the in-memory platform
// services. Imports registerNode() directly (not instrumentation.ts's register()
// dispatcher) since the dispatcher only calls through when NEXT_RUNTIME==="nodejs",
// which vitest does not set — importing the dispatcher here would make this test a
// silent no-op.
import { describe, it, expect } from "vitest";

describe("instrumentation bootstrap", () => {
  it${isPersistentStorage ? ".skip" : ""}("registerNode() resolves without throwing", async () => {
    // Session-secret fail-fast (BC-1) needs a value before the module loads.
    process.env.DBP_AUTH_SESSION_SECRET ??= "test-only-session-secret-0123456789abcdef";
    const { registerNode } = await import("../../instrumentation.node");
    await expect(registerNode()).resolves.not.toThrow();
  });
});
`,
  );
}

// ── Shared demo identities (PS.AUTH) ──────────────────────────────────────────
// Emitted whenever PS.AUTH is consumed. Generator-owned (a pure projection of the
// manifest accounts/roles, like seed.ts) so it stays in sync on every regen. The
// PS.AUTH route imports this from its OWN chunk to seed the identity provider —
// instrumentation.ts is not visible across Next.js route-chunk isolation / serverless
// functions, which is why demo login returned 401 on Vercel. See generateAuthRouteHandler().
if (HAS_AUTH) {
  const demoRoleIds = (manifest.iam?.roles ?? []).map((r) => r.id);
  const adminRoles = [...new Set(["platform-admin", ...demoRoleIds])];
  const userRoles = [...new Set(["user", ...demoRoleIds.slice(0, 1)])];
  writeFile(
    "solution/fixtures/demo-identities.ts",
    `// Demo identity accounts — shared source of truth for the login page hints,
// instrumentation.ts, and the PS.AUTH route's per-chunk bootstrap. Generator-owned
// (projected from the manifest); to change demo accounts, edit the manifest iam: block.
// Amira Khalid carries a second membership (tenant-beta-demo) so the shell's
// multitenant workspace switcher is demoable out of the box (T4 ruling).
export const DEMO_IDENTITIES = [
  { user: { id: "usr-alpha-platform-admin", email: "platform-admin@alpha.dev.local", displayName: "Amira Khalid", roles: ${JSON.stringify(adminRoles)}, tenantId: "tenant-alpha", memberships: ["tenant-alpha", "tenant-beta-demo"] }, password: "dbp-dev-password" },
  { user: { id: "usr-alpha-user-01", email: "user-01@alpha.dev.local", displayName: "Demo User", roles: ${JSON.stringify(userRoles)}, tenantId: "tenant-alpha" }, password: "dbp-dev-password" },
];
`,
  );
}

// ── Post-login redirect target ────────────────────────────────────────────────
// Prefer /home when a home archetype is emitted; else the first module route.
// (Never a public route — there is always at least one module.)
const defaultPostLoginRoute = hasHome
  ? "/home"
  : `/${moduleRouteSegment(manifest.modules[0])}`;

// ── Logout route (ported from master generator) ──────────────────────────────
// Emit app/logout/route.ts whenever PS.AUTH is consumed. The transaction shell
// sidebar hardcodes <a href="/logout"> — this handler clears the session cookie
// via logoutHandler and 302-redirects to /login. (Replaces the legacy client
// app/logout/page.tsx stopgap — a page.tsx + route.ts cannot coexist at a path.)
if (consumedSet.has("PS.AUTH")) {
  writeFile(
    "app/(public)/logout/route.ts",
    `import { NextResponse } from "next/server";

// Stateless JWT session: clearing the dbp_session cookie IS the logout. We do it
// here (not via @dbp/ps-auth/server) so app/* never imports a service's /server
// internals — the import boundary forbids that outside the api/platform mount seam.
export async function GET(request: Request) {
  const response = NextResponse.redirect(new URL("/login", request.url), { status: 302 });
  response.cookies.delete("dbp_session");
  return response;
}
`,
  );
}

// ── Login page (DQ prototype standard) ───────────────────────────────────────
// Emit a /login page using the shared LoginPage from @dbp/ui whenever PS.AUTH is consumed.

if (consumedSet.has("PS.AUTH")) {
  // SP-MANIFEST-SOT / FN-1 fix: derive SEED_USERS from manifest.dev.seed_users when present;
  // otherwise fall back to the SAME two accounts that InMemoryIdentityProvider seeds — NOT the
  // old finance-domain emails (finance-clerk / finance-approver) that were never actually seeded.
  // This ensures login quick-fill always matches what instrumentation actually seeds.
  const devSeedUsers = manifest.dev?.seed_users;
  const devTenantId = manifest.dev?.tenant_id ?? "tenant-alpha";
  const loginSeedUsers = devSeedUsers && devSeedUsers.length > 0
    ? devSeedUsers.map((u) => ({ label: u.label, email: u.email }))
    : [
        { label: `Platform Admin (${devTenantId})`, email: "platform-admin@alpha.dev.local" },
        { label: `Demo User (${devTenantId})`, email: "user-01@alpha.dev.local" },
      ];
  const seedUsersJson = JSON.stringify(loginSeedUsers, null, 2)
    .replace(/\n/g, "\n  "); // indent for template literal

  // SP-MANIFEST-SOT: login page copy — all fields fall back to current defaults.
  const loginProductName = manifest.login?.product_name ?? "Your governed platform workspace.";
  const loginTagline = manifest.login?.tagline ?? `Sign in to access ${manifest.name} — powered by the DBP platform factory.`;
  const loginSubtitle = manifest.login?.subtitle ?? `Use your DigitalQatalyst credentials to access ${manifest.solution}.`;

  // SP-MANIFEST-SOT: login features — manifest overrides drop icons; default keeps PS icons.
  const manifestLoginFeatures = manifest.login?.features;
  const loginFeaturesDecl = manifestLoginFeatures
    ? `const LOGIN_FEATURES = ${JSON.stringify(manifestLoginFeatures.map((f) => ({ title: f.title, description: f.description ?? "" })), null, 2)
        .replace(/\n/g, "\n")};`
    : `const LOGIN_FEATURES = [
  {
    icon: <ShieldCheck size={20} strokeWidth={1.5} />,
    title: "Role-based access control",
    description: "Roles and permissions governed by PS.RBAC — zero custom auth code.",
  },
  {
    icon: <Users size={20} strokeWidth={1.5} />,
    title: "Multi-tenant isolation",
    description: "Each tenant's data is fully isolated at the platform service layer.",
  },
  {
    icon: <Lock size={20} strokeWidth={1.5} />,
    title: "Governed platform security",
    description: "Auth, sessions, and audit wired from Layer 06 platform services.",
  },
];`;

  // Icon import only needed for default features (manifest features have no icon)
  const loginIconImport = manifestLoginFeatures
    ? ""
    : `import { ShieldCheck, Lock, Users } from "lucide-react";\n`;

  // Federated-locked mode (gaps-log #1 "entra-only scaffold mode"): when the
  // MANIFEST declares an entra/entra-external identity provider, the emitted
  // login page is SSO-only and FAIL-CLOSED — no credential form, no demo seed
  // users, no runtime provider probe that falls back to password when env is
  // misconfigured. Password-mode solutions keep the runtime-adaptive page.
  const manifestIdpProvider = manifest.iam?.identity?.provider;
  const federatedLocked = manifestIdpProvider === "entra" || manifestIdpProvider === "entra-external";

  writeFile(
    "app/(public)/login/page.tsx",
    federatedLocked
      ? `"use client";
// ${manifest.solution} Login Page — federated SSO only (manifest-locked: iam.identity.provider=${manifestIdpProvider}).
// FAIL-CLOSED: no credential form is emitted for federated solutions. A regen
// can never reintroduce password/demo login here — change the manifest to change auth.
import * as React from "react";
import { useSearchParams } from "next/navigation";
import { LoginPage, MicrosoftSignInButton } from "@dbp/ui";
${loginIconImport}
export default function LoginRoute() {
  return (
    <React.Suspense>
      <LoginPageInner />
    </React.Suspense>
  );
}

${loginFeaturesDecl}

function LoginPageInner() {
  const searchParams = useSearchParams();
  const redirect = searchParams.get("redirect") ?? "${defaultPostLoginRoute}";

  return (
    <LoginPage
      productCode="${manifest.solution}"
      productName="${loginProductName}"
      tagline="${loginTagline}"
      leftOverline="Authenticated access · ${manifest.solution}"
      features={LOGIN_FEATURES}
      rightOverline="Platform access"
      title="Sign in to ${manifest.name}"
      subtitle="Sign in with your Microsoft account to continue."
    >
      <MicrosoftSignInButton
        authorizeUrl={\`/api/platform/auth/authorize?redirect=\${encodeURIComponent(redirect)}\`}
        label="${manifestIdpProvider === "entra-external" ? "Sign in with your Microsoft account" : "Sign in with Microsoft"}"
      />
    </LoginPage>
  );
}
`
      : `"use client";
// ${manifest.solution} Login Page — DQ prototype standard.
// SP-MANIFEST-SOT: copy and seed users sourced from manifest.login / manifest.dev.
// Auth submit flow: PS.AUTH client SDK via /api/platform/auth.
import * as React from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { login } from "@dbp/ps-auth/client";
import { useQueryClient } from "@tanstack/react-query";
import { LoginPage, LoginCredentialsForm, MicrosoftSignInButton } from "@dbp/ui";
${loginIconImport}
export default function LoginRoute() {
  return (
    <React.Suspense>
      <LoginPageInner />
    </React.Suspense>
  );
}

// SP-MANIFEST-SOT / FN-1: SEED_USERS is derived from manifest.dev.seed_users when declared,
// otherwise from the same platform-admin + user-01 accounts that instrumentation.ts seeds.
// These must always match — the manifest is the single source of truth.
const SEED_USERS = ${seedUsersJson} as const;

const DEV_PASSWORD = "dbp-dev-password";

${loginFeaturesDecl}

// Session query key must match the key in useAuth() so setQueryData hits the same cache slot.
const SESSION_QUERY_KEY = ["dbp", "ps-auth", "session"] as const;

type ProviderKind = "password" | "ldap" | "entra" | "entra-external" | null;

async function fetchProvider(): Promise<ProviderKind> {
  try {
    const res = await fetch("/api/platform/auth/provider");
    if (!res.ok) return "password";
    const data = (await res.json()) as { provider: ProviderKind };
    return data.provider ?? "password";
  } catch {
    return "password";
  }
}

function LoginPageInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirect = searchParams.get("redirect") ?? "${defaultPostLoginRoute}";
  const queryClient = useQueryClient();

  const [provider, setProvider] = React.useState<ProviderKind>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    fetchProvider().then(setProvider);
  }, []);

  async function handleSubmit({ email, password }: { email: string; password: string }) {
    setError(null);
    setLoading(true);
    try {
      const response = await login({ email, password });
      // Update the React Query session cache BEFORE navigating. Without this,
      // AuthenticatedLayout renders with the stale {user:null} cache from before
      // login and immediately redirects back to /login.
      queryClient.setQueryData(SESSION_QUERY_KEY, {
        session: response.session,
        user: response.user,
      });
      router.push(redirect);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed. Please check your credentials.");
    } finally {
      setLoading(false);
    }
  }

  const isFederated = provider === "entra" || provider === "entra-external";
  const subtitle = isFederated
    ? "Sign in with your Microsoft account to continue."
    : "${loginSubtitle}";

  return (
    <LoginPage
      productCode="${manifest.solution}"
      productName="${loginProductName}"
      tagline="${loginTagline}"
      leftOverline="Authenticated access · ${manifest.solution}"
      features={LOGIN_FEATURES}
      rightOverline="Platform access"
      title="Sign in to ${manifest.name}"
      subtitle={subtitle}
    >
      {isFederated ? (
        <MicrosoftSignInButton
          authorizeUrl={\`/api/platform/auth/authorize?redirect=\${encodeURIComponent(redirect)}\`}
          label={provider === "entra-external" ? "Sign in with your Microsoft account" : "Sign in with Microsoft"}
          loading={loading}
        />
      ) : (
        <LoginCredentialsForm
          onSubmit={handleSubmit}
          loading={loading}
          error={error}
          seedUsers={SEED_USERS}
          seedPassword={DEV_PASSWORD}
        />
      )}
    </LoginPage>
  );
}
`,
  );
}

// ── Page routes ───────────────────────────────────────────────────────────────

// Shell component names: derived from package names
// Keyed on CANONICAL shell ids (SH.PUBLIC / SH.WORKSPACE).
// Legacy ids (SH.00–SH.04) must be normalised via resolveShellId() before lookup.
const SHELL_COMPONENT = {
  // ── Canonical two-shell model ───────────────────────────────────────────────
  "SH.PUBLIC":    { name: "LandingShell",      importFrom: "@dbp/shell-landing" },
  "SH.WORKSPACE": { name: "TransactionShell",  importFrom: "@dbp/shell-transaction" },
  // ── Legacy ids kept for any direct look-ups (back-compat) ──────────────────
  // SH.01/03/04 removed with their packages (two-shell consolidation); they are
  // normalised to SH.WORKSPACE by resolveShellId() before any look-up here.
  "SH.00": { name: "LandingShell",        importFrom: "@dbp/shell-landing" },
  "SH.02": { name: "TransactionShell",    importFrom: "@dbp/shell-transaction" },
};

const FEATURE_COMPONENT = {
  "APP.F01": { name: "EntityList", importFrom: "@dbp/organisms/entity-list" },
  "APP.F02": { name: "EntityDetail", importFrom: "@dbp/organisms/entity-detail" },
  "APP.F03": { name: "FormBuilder", importFrom: "@dbp/organisms/form-builder" },
  "APP.F04": { name: "Kanban", importFrom: "@dbp/organisms/kanban" },
  "APP.F05": { name: "CalendarScheduler", importFrom: "@dbp/organisms/calendar" },
  "APP.F06": { name: "ApprovalSurface", importFrom: "@dbp/organisms/approval-surface" },
  "APP.F07": { name: "SelfServiceDashboard", importFrom: "@dbp/organisms/self-service-dashboard" },
  "APP.F08": { name: "CaseWorkspace", importFrom: "@dbp/organisms/case-workspace" },
  "APP.F09": { name: "WorkbenchSurface", importFrom: "@dbp/organisms/workbench-surface" },
  "ANL.F01": { name: "WidgetGrid", importFrom: "@dbp/organisms/widget-grid" },
  "ANL.F02": { name: "ChartPanel", importFrom: "@dbp/organisms/chart-panel" },
  "ANL.F03": { name: "KpiScorecard", importFrom: "@dbp/organisms/kpi-scorecard" },
  "ANL.F04": { name: "AlertView", importFrom: "@dbp/organisms/alert-view" },
  "ANL.F05": { name: "SlaTracking", importFrom: "@dbp/organisms/sla-tracking" },
  "ANL.F06": { name: "ExampleReport", importFrom: "@dbp/organisms/example-report" },
  // Archetype features (all default exports).
  "APP.F10": { name: "CatalogGrid", importFrom: "@dbp/organisms/catalog-grid" },
  "APP.F11": { name: "MarketplaceItemDetail", importFrom: "@dbp/organisms/marketplace-item-detail" },
  "APP.F13": { name: "ContactForm", importFrom: "@dbp/organisms/contact-form" },
  "APP.F15": { name: "CopilotPage", importFrom: "@dbp/organisms/copilot-page" },
  // LVE Workspace (APP.F19) — list-view-edit unified workspace.
  "APP.F19": { name: "LveWorkspace", importFrom: "@dbp/organisms/lve-workspace" },
  // Service Catalog (APP.F20) — client-faceted tab-isolated catalogue grid.
  "APP.F20": { name: "ServiceCatalog", importFrom: "@dbp/organisms/service-catalog" },
  // Workspace Dashboard (APP.F21) — composed personal "My Dashboard".
  "APP.F21": { name: "WorkspaceDashboard", importFrom: "@dbp/organisms/workspace-dashboard" },
  // Notification Inbox (APP.F29 — PROVISIONAL, not a confirmed catalogue ID;
  // see docs/09-plans/notification-inbox-pattern-2026-07-17.md). Thin list
  // surface for PS.NOTIF, built in place of an LVE preset (ruling N3).
  "APP.F29": { name: "NotificationInbox", importFrom: "@dbp/organisms/notification-inbox" },
  // Record Form (APP.F24) — config-driven single-page record-creation form,
  // mounted into the "form-basic" layout (record-form-spec-2026-07-12.md).
  "APP.F24": { name: "RecordForm", importFrom: "@dbp/organisms/record-form" },
  // Multi-step Form (APP.F27) — config-driven guided wizard, mounts form-guided.
  "APP.F27": { name: "MultiStepForm", importFrom: "@dbp/organisms/multi-step-form" },
};

// Warn at startup for any feature package on disk that has no FEATURE_COMPONENT
// entry — ensures new features are never silently ignored.
for (const [registryId] of Object.entries(FEATURE_PKG)) {
  if (!FEATURE_COMPONENT[registryId]) {
    console.warn(
      `[scaffold] WARNING: feature package "${FEATURE_PKG[registryId]}" (${registryId}) is on disk ` +
        `but has no entry in FEATURE_COMPONENT — add it to get JSX emission. ` +
        `Until then any module referencing ${registryId} will emit a no-op placeholder.`,
    );
  }
}

// Module URL path: DWS.04.M01 → m01. Delegates to moduleRouteSegment (defined
// near the middleware derivation) so route-segment logic lives in one place.
function moduleRoutePath(mod) {
  return moduleRouteSegment(mod);
}

// Per-solution sidebar-nav constant name: DIA.02 → DIA02_NAV, DXP.01A → DXP01A_NAV.
const navConstName = `${manifest.solution.toUpperCase().replace(/[^A-Z0-9]/g, "")}_NAV`;

/**
 * Build the per-module sidebar-nav constant from `mod.nav` (optional).
 *
 * Returns { constDecl, needsBreadcrumb } or null when the module declares no
 * nav. The emitted shape mirrors the hand-authored DIA02_NAV / DWS05_NAV /
 * DXP01A_NAV constants so a `--force` regen reproduces them byte-for-byte:
 *   - logo (optional)       → styled <span>
 *   - items (required)      → one-per-line { id, label, href[, active] }
 *   - breadcrumb (optional) → <Breadcrumb items={…} /> (needs the @dbp/ui import)
 */
function buildModuleNav(mod) {
  // The connected chrome (enriched top bar) is mounted whenever PS.AUTH is wired,
  // regardless of whether the module declares its own nav block — every
  // authenticated module page inherits the same session + capability driven bar.
  const useChrome = HAS_AUTH;
  if (!mod.nav && !useChrome) return null;

  const lines = [];
  let needsChrome = false;
  if (useChrome) {
    needsChrome = true;
    // topBar OWNS the bar; when present the bespoke logo is part of the chrome,
    // so we omit the per-module logo span to avoid a duplicate brand mark.
    lines.push(`  topBar: <SolutionChrome />,`);
    // Full-width workspace footer, inherited by every authenticated page.
    lines.push(`  footer: <SolutionFooter />,`);
  } else if (mod.nav?.logo) {
    lines.push(
      `  logo: <span className="text-sm font-semibold text-[var(--color-text)]">${mod.nav.logo}</span>,`,
    );
  }

  if (mod.nav) {
    if (mod.nav.sections?.length) {
      // ── Nested sections path (section → group → child) ──────────────────────
      // Validate each nav child href against the FULL set of emitted routes
      // (every module's own route prefix, plus archetype-block routes like
      // /home, /marketplace, /copilot) — not just the declaring module's own
      // prefix, since sidebar sections routinely link across modules.
      const isKnownRoute = (href) =>
        [...knownRoutePrefixes].some((prefix) => href === prefix || href.startsWith(`${prefix}/`));
      for (const section of mod.nav.sections) {
        for (const group of section.items) {
          if (group.href && !isKnownRoute(group.href)) {
            console.warn(
              `[scaffold] nav section group href ${JSON.stringify(group.href)} in module ${mod.id} does not match any emitted route.`,
            );
          }
          for (const child of group.children ?? []) {
            if (child.href && !isKnownRoute(child.href)) {
              console.warn(
                `[scaffold] nav section child href ${JSON.stringify(child.href)} in module ${mod.id} does not match any emitted route.`,
              );
            }
          }
        }
      }
      lines.push(`  sections: ${JSON.stringify(mod.nav.sections, null, 2).replace(/^/gm, "  ").trimStart()},`);
      if (Array.isArray(manifest.customNavSections) && manifest.customNavSections.length > 0) {
        lines.push(`  allowedExtraSectionIds: ${JSON.stringify(manifest.customNavSections)},`);
      }
    } else {
      // ── Flat items path (backward-compatible) ────────────────────────────────
      const itemLines = mod.nav.items
        .map(
          (it) =>
            `    { id: ${JSON.stringify(it.id)}, label: ${JSON.stringify(it.label)}, href: ${JSON.stringify(it.href)}${it.active ? ", active: true" : ""} },`,
        )
        .join("\n");
      lines.push(`  items: [\n${itemLines}\n  ],`);
    }
  }

  let needsBreadcrumb = false;
  // The top-bar breadcrumb is suppressed by the shell when topBar is present
  // (the page's PageHeader carries the breadcrumb instead), so only emit a
  // top-bar breadcrumb in the legacy (no-chrome) layout.
  if (mod.nav?.breadcrumb && !useChrome) {
    needsBreadcrumb = true;
    const crumbs = mod.nav.breadcrumb
      .map((c) => `{ label: ${JSON.stringify(c.label)}${c.href ? `, href: ${JSON.stringify(c.href)}` : ""} }`)
      .join(", ");
    lines.push(`  breadcrumb: <Breadcrumb items={[${crumbs}]} />,`);
  }
  return {
    constDecl: `const ${navConstName} = {\n${lines.join("\n")}\n};`,
    needsBreadcrumb,
    needsChrome,
  };
}

// Slot name → TransactionShell canonical slot.
// When a module's resolved shell is SH.WORKSPACE, legacy slot names from the
// old 5-shell model are remapped: primary content → "main", secondary → "context".
const WORKSPACE_SLOT_REMAP = {
  // SH.01 (marketplace)
  catalog:        "main",
  // SH.03 (delivery-admin) — queue/detailContent are both primary
  queue:          "main",
  detailContent:  "main",
  detailTabs:     "main",
  // SH.04 (workbench)
  workbench:      "main",
  // Secondary / side-panel slot
  inspector:      "context",
  context:        "context",
  // "main" passes through unchanged
  main:           "main",
};

/** Title-case an UPPERCASE nav section label for the sentence-case breadcrumb. */
function titleCaseLabel(s) {
  return String(s).toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
}

/**
 * Build the page breadcrumb as a REAL ancestor trail from the sidebar nav:
 *   Solution(→home) › Section › Group › Page(current, no href).
 * Section/group are wayfinding labels (no href); only the solution root links and
 * the final crumb is the current page. Falls back to Solution › Page when the
 * route is not found in the nav. The breadcrumb is rendered muted by @dbp/ui, so
 * the final crumb repeating the H1 is fine (it reads as "you are here").
 */
function moduleBreadcrumbTrail(mod, routeSegment) {
  const route = `/${routeSegment}`;
  const sections = manifest.nav?.sections?.length
    ? manifest.nav.sections
    : manifest.modules.find((m) => m.nav?.sections?.length)?.nav?.sections;
  if (sections?.length) {
    for (const section of sections) {
      for (const group of section.items ?? []) {
        if (group.href === route) {
          return [{ label: titleCaseLabel(section.label) }, { label: mod.name }];
        }
        const leaf = (group.children ?? []).find((c) => c.href === route);
        if (leaf) {
          return [
            { label: titleCaseLabel(section.label) },
            { label: group.label },
            { label: mod.name },
          ];
        }
      }
    }
  }
  return [{ label: mod.name }];
}

// ── Route group layouts (ADR-0026) ────────────────────────────────────────────
// app/(public)/layout.tsx  — passthrough; pages: /login, / (landing for non-DXP)
// app/(authenticated)/layout.tsx — mounts TransactionShell ONCE with SOLUTION_NAV
//   so per-module pages can be body-only (no per-page shell instantiation needed).
//
// NOTE: the (authenticated)/layout.tsx nav constant is built from the manifest's
// nav sections (same source as per-page nav). Per-page files still carry their own
// nav for backward-compat with the current flat structure; once pages are moved
// under (authenticated)/ they should drop the per-page shell wrapper.

writeFile(
  "app/(public)/layout.tsx",
  `import type { ReactNode } from "react";

// Public route-group layout — passthrough wrapper.
// Pages under app/(public)/** (e.g. /login) are rendered without the
// TransactionShell so unauthenticated users see only the page content.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
export default function PublicLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
`,
);

// Build the full solution nav constant for the (authenticated) layout.
// This mirrors the per-module nav but scoped to the whole solution so the shell
// is mounted once and all modules inherit it.
const authLayoutNavSections = manifest.modules
  .filter((m) => resolveShellId(m.scaffold) !== "SH.PUBLIC")
  .reduce((acc, m) => {
    if (m.nav?.sections) {
      for (const sec of m.nav.sections) {
        if (!acc.find((s) => s.id === sec.id)) acc.push(sec);
      }
    }
    return acc;
  }, []);

const authLayoutNavJson = authLayoutNavSections.length
  ? JSON.stringify(authLayoutNavSections, null, 2)
  : "[]";

// Build the gated module nav entries — flat list of nav groups that carry gating
// metadata. Only includes modules that declare nav.gating. Used to emit the
// RAW_MODULE_NAV constant and useGatedNav() call in the authenticated layout.
const gatedModules = (manifest.modules ?? []).filter(
  (m) => resolveShellId(m.scaffold) !== "SH.PUBLIC" && m.nav?.gating,
);

const hasGatedNav = gatedModules.length > 0;

// For each gated module, find the nav group ID. The group ID is taken from the
// module's nav sections (first group in first section) or from the flat items list.
function gatedNavGroupId(m) {
  if (m.nav?.sections?.length) return m.nav.sections[0].items[0]?.id ?? m.id;
  if (m.nav?.items?.length) return m.nav.items[0]?.id ?? m.id;
  return m.id;
}

const rawModuleNavLiteral = hasGatedNav
  ? `\nconst RAW_MODULE_NAV: GatableNavItem[] = [\n${gatedModules
      .map((m) => {
        const gid = gatedNavGroupId(m);
        const modes = Array.isArray(m.nav.gating) ? m.nav.gating : [m.nav.gating];
        const gating = {
          modes,
          ...(m.nav.requiredPermission ? { requiredPermission: m.nav.requiredPermission } : {}),
          ...(m.nav.featureFlag ? { featureFlag: m.nav.featureFlag } : {}),
          hiddenBehavior: m.nav.hiddenBehavior ?? "hide",
        };
        const href = m.nav?.items?.[0]?.href ?? m.nav?.sections?.[0]?.items?.[0]?.href ?? `/${m.id}`;
        return `  { id: ${JSON.stringify(gid)}, label: ${JSON.stringify(m.label ?? m.id)}, href: ${JSON.stringify(href)}, gating: ${JSON.stringify(gating)} },`;
      })
      .join("\n")}\n];\n`
  : "";

const gatedNavImport = hasGatedNav
  ? `import { useGatedNav, type GatableNavItem } from "@dbp/nav-gating";\n`
  : "";

function flattenNavToCommandSources(sections) {
  return sections
    .map((sec) => {
      const items = [];
      for (const group of sec.items ?? []) {
        for (const child of group.children ?? []) {
          if (child.href) items.push({ id: child.href, label: child.label });
        }
        if (group.href) items.push({ id: group.href, label: group.label });
      }
      return { id: sec.id, group: sec.id, groupLabel: sec.label, items };
    })
    .filter((s) => s.items.length > 0);
}

const commandPaletteConfigJson = hasCommandPalette
  ? JSON.stringify({ sources: flattenNavToCommandSources(authLayoutNavSections) }, null, 2)
  : "";

const gatedNavHook = hasGatedNav
  ? `  const visibleModuleNav = useGatedNav(RAW_MODULE_NAV);
  const visibleGroupIds = new Set(visibleModuleNav.map((m) => m.id));
  const filteredSections = SOLUTION_NAV.sections
    .map((sec) => ({ ...sec, items: sec.items.filter((g) => !RAW_MODULE_NAV.some((m) => m.id === g.id) || visibleGroupIds.has(g.id)) }))
    .filter((sec) => sec.items.length > 0);
  const activeNav = { ...SOLUTION_NAV, sections: filteredSections };`
  : "";

const navProp = hasGatedNav ? "activeNav" : "SOLUTION_NAV";

writeFile(
  "app/(authenticated)/layout.tsx",
  `// Authenticated route-group layout — SERVER-SIDE auth gate (ADR-0027 + DWS.01 audit 2.3).
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
//
// Enforcement happens HERE, on the server, before any authenticated markup is
// rendered: middleware.ts verifies the session against PS.AUTH and forwards it
// as x-dbp-session (plus the request path as x-dbp-pathname). No header = not
// authenticated = redirect to /login. The client shell's useAuth() redirect is
// UX-only (session expiry during navigation), never the security boundary.
import type { ReactNode } from "react";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import AuthenticatedClientShell from "./authenticated-client-shell";

export default async function AuthenticatedLayout({ children }: { children: ReactNode }) {
  const h = await headers();
  if (!h.get("x-dbp-session")) {
    const intended = h.get("x-dbp-pathname") ?? "";
    redirect(intended ? \`/login?redirect=\${encodeURIComponent(intended)}\` : "/login");
  }
  return <AuthenticatedClientShell>{children}</AuthenticatedClientShell>;
}
`,
);

writeFile(
  "app/(authenticated)/authenticated-client-shell.tsx",
  `"use client";
// Authenticated client shell — mounts TransactionShell ONCE for the route group.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
//
// SECURITY NOTE: server-side auth enforcement lives in layout.tsx (the server
// gate reading the middleware-verified x-dbp-session header). The useAuth()
// guard below is UX-only — it catches session expiry during client navigation
// and avoids a flash of stale chrome; it is NOT the security boundary.
//
// The SOLUTION_NAV constant is built once here; pages in this group are
// body-only (no per-page shell wrapper needed).
import * as React from "react";
import type { ReactNode } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@dbp/ps-auth/client";
import TransactionShell from "@dbp/shell-transaction";
import { SolutionChrome, SolutionSidebarSwitcher } from "../solution-chrome";
import { SolutionFooter } from "../solution-footer";
import { BreadcrumbProvider } from "@dbp/ui";
${gatedNavImport}${hasCommandPalette ? `import { useShortcuts } from "@dbp/ui";
import CommandPalette, { type CommandPaletteConfig } from "@dbp/organisms/command-palette";
` : ""}
const SOLUTION_NAV = {
  topBar: <SolutionChrome />,
  footer: <SolutionFooter />,
  // N30 ruling (supersedes N27's static identity block): the sidebar identity
  // block IS the workspace/tenant switcher — active tenant on the primary line,
  // solution name as the subtitle, popover with memberships + sign out.
  identitySlot: (collapsed: boolean) => <SolutionSidebarSwitcher collapsed={collapsed} />,
  sections: ${authLayoutNavJson},${
    Array.isArray(manifest.customNavSections) && manifest.customNavSections.length > 0
      ? `\n  allowedExtraSectionIds: ${JSON.stringify(manifest.customNavSections)},`
      : ""
  }
};
${rawModuleNavLiteral}${hasCommandPalette ? `
// APP.F26 Command Palette — sourced from the solution's own nav (SOLUTION_NAV
// above), never hand-authored. See capability-keyboard-shortcuts-spec-2026-07-10.md §3.
const COMMAND_PALETTE_CONFIG: CommandPaletteConfig = ${commandPaletteConfigJson};

// Mounted INSIDE TransactionShell's slots.main — ShortcutProvider (the mod+k
// registry) lives inside TransactionShell, so this must be a descendant of
// TransactionShell, not a sibling of it.
function CommandPaletteMount() {
  const router = useRouter();
  const [open, setOpen] = React.useState(false);
  useShortcuts(
    [
      { keys: "mod+k", description: "Open command palette", group: "Navigation", handler: () => setOpen(true) },
      { keys: "/", description: "Open command palette", group: "Navigation", handler: () => setOpen(true) },
    ],
    { scope: "global" },
  );
  return (
    <CommandPalette
      open={open}
      onClose={() => setOpen(false)}
      config={COMMAND_PALETTE_CONFIG}
      onRun={(item) => router.push(item.id)}
    />
  );
}
` : ""}
export default function AuthenticatedClientShell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const { user, status } = useAuth();
${gatedNavHook}
  React.useEffect(() => {
    if (status !== "loading" && !user) {
      // Session gone client-side (expiry mid-navigation) — bounce to login, preserving destination.
      const redirect = encodeURIComponent(window.location.pathname + window.location.search);
      router.replace(\`/login?redirect=\${redirect}\`);
    }
  }, [user, status, router]);

  // While loading or redirecting, render nothing to avoid a flash of shell chrome.
  if (status === "loading" || !user) return null;

  // N36: BreadcrumbProvider wraps both the top bar (SolutionChrome, mounted
  // via nav.topBar) and the page body — pages call useBreadcrumbOverride() to
  // replace the top-bar breadcrumb's terminal crumb with the loaded record's
  // display name once it resolves.
  return (
    <BreadcrumbProvider>
      <TransactionShell
        nav={${navProp}}
        slots={{
          main: (
            <>
              {children}${hasCommandPalette ? `
              <CommandPaletteMount />` : ""}
            </>
          ),
        }}
        // ADR-0040: shell-rendered anchors (collapsed nav strip, help link) get
        // client-side routing instead of full page reloads.
        linkComponent={Link}
      />
    </BreadcrumbProvider>
  );
}
`,
);

writeFile(
  "app/(authenticated)/error.tsx",
  `"use client";
// app/(authenticated)/error.tsx — segment error boundary for authenticated routes.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
import { useEffect } from "react";

export default function AuthenticatedError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[${manifest.solution}] authenticated segment error:", error);
  }, [error]);

  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "60vh", padding: "2rem", color: "var(--color-text)" }}>
      <div style={{ textAlign: "center", maxWidth: 420 }}>
        <p style={{ fontSize: "11px", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "monospace", color: "var(--color-text-disabled)", marginBottom: "0.75rem" }}>
          ${manifest.solution} · Error
        </p>
        <h2 style={{ fontSize: "1.25rem", fontWeight: 600, marginBottom: "0.5rem" }}>Something went wrong</h2>
        <p style={{ fontSize: "0.875rem", color: "var(--color-text-secondary)", marginBottom: "1.25rem" }}>
          An error occurred while loading this page.
          {error.digest && <> Ref: <code style={{ fontFamily: "monospace", fontSize: "0.75rem" }}>{error.digest}</code></>}
        </p>
        <button
          onClick={reset}
          style={{ padding: "0.4rem 1rem", fontSize: "0.875rem", fontWeight: 500, borderRadius: "var(--radius-button, 6px)", border: "1px solid var(--color-border)", backgroundColor: "var(--color-surface)", color: "var(--color-text)", cursor: "pointer" }}
        >
          Try again
        </button>
      </div>
    </div>
  );
}
`,
);

writeFile(
  "app/(authenticated)/loading.tsx",
  `// app/(authenticated)/loading.tsx — shell-level Suspense skeleton.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
export default function AuthenticatedLoading() {
  return (
    <div aria-label="Loading" aria-busy="true" style={{ padding: "1.5rem", display: "flex", flexDirection: "column", gap: "0.75rem" }}>
      <div style={{ height: "20px", width: "30%", borderRadius: "4px", background: "color-mix(in srgb, var(--color-border) 60%, var(--color-surface))", animation: "pulse 1.5s ease-in-out infinite" }} />
      {[80, 65, 72, 55].map((w, i) => (
        <div key={i} style={{ height: "14px", width: \`\${w}%\`, borderRadius: "4px", background: "color-mix(in srgb, var(--color-border) 60%, var(--color-surface))", animation: \`pulse 1.5s ease-in-out \${i * 0.1}s infinite\` }} />
      ))}
      <style>{\`@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }\`}</style>
    </div>
  );
}
`,
);

// Public segment gets the same boundaries (DWS.01 audit 2.12): every route group
// the scaffold creates ships error + loading states, not just (authenticated).
writeFile(
  "app/(public)/error.tsx",
  `"use client";
// app/(public)/error.tsx — segment error boundary for public routes.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
import { useEffect } from "react";

export default function PublicError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[${manifest.solution}] public segment error:", error);
  }, [error]);

  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "60vh", padding: "2rem", color: "var(--color-text)" }}>
      <div style={{ textAlign: "center", maxWidth: 420 }}>
        <p style={{ fontSize: "11px", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "monospace", color: "var(--color-text-disabled)", marginBottom: "0.75rem" }}>
          ${manifest.solution} · Error
        </p>
        <h2 style={{ fontSize: "1.25rem", fontWeight: 600, marginBottom: "0.5rem" }}>Something went wrong</h2>
        <p style={{ fontSize: "0.875rem", color: "var(--color-text-secondary)", marginBottom: "1.25rem" }}>
          An error occurred while loading this page.
          {error.digest && <> Ref: <code style={{ fontFamily: "monospace", fontSize: "0.75rem" }}>{error.digest}</code></>}
        </p>
        <button
          onClick={reset}
          style={{ padding: "0.4rem 1rem", fontSize: "0.875rem", fontWeight: 500, borderRadius: "var(--radius-button, 6px)", border: "1px solid var(--color-border)", backgroundColor: "var(--color-surface)", color: "var(--color-text)", cursor: "pointer" }}
        >
          Try again
        </button>
      </div>
    </div>
  );
}
`,
);

writeFile(
  "app/(public)/loading.tsx",
  `// app/(public)/loading.tsx — public-segment Suspense skeleton.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
export default function PublicLoading() {
  return (
    <div aria-label="Loading" aria-busy="true" style={{ padding: "1.5rem", display: "flex", flexDirection: "column", gap: "0.75rem" }}>
      <div style={{ height: "20px", width: "30%", borderRadius: "4px", background: "color-mix(in srgb, var(--color-border) 60%, var(--color-surface))", animation: "pulse 1.5s ease-in-out infinite" }} />
      {[80, 65, 72, 55].map((w, i) => (
        <div key={i} style={{ height: "14px", width: \`\${w}%\`, borderRadius: "4px", background: "color-mix(in srgb, var(--color-border) 60%, var(--color-surface))", animation: \`pulse 1.5s ease-in-out \${i * 0.1}s infinite\` }} />
      ))}
      <style>{\`@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }\`}</style>
    </div>
  );
}
`,
);

writeFile(
  "app/global-error.tsx",
  `"use client";
// app/global-error.tsx — root-level error boundary (must include own html/body).
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
import { useEffect } from "react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error("[${manifest.solution}] global-error:", error); }, [error]);
  return (
    <html lang="en">
      {/* eslint-disable-next-line dbp-local-hex/no-raw-design-values -- root-layout crash boundary: layout.tsx (which loads the token CSS) may itself have failed to render, so this cannot depend on --color-* custom properties being defined. */}
      <body style={{ fontFamily: "system-ui, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", minHeight: "100vh", margin: 0, backgroundColor: "#f8f9fa", color: "#1a1a2e" }}>
        <div style={{ textAlign: "center", maxWidth: 480, padding: "2rem" }}>
          {/* eslint-disable-next-line dbp-local-hex/no-raw-design-values -- see body tag above: token CSS may not be loaded in this boundary. */}
          <p style={{ fontSize: "11px", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "monospace", color: "#6b7280", marginBottom: "1rem" }}>${manifest.solution} · Platform error</p>
          <h1 style={{ fontSize: "1.5rem", fontWeight: 600, marginBottom: "0.75rem" }}>Something went wrong</h1>
          {/* eslint-disable-next-line dbp-local-hex/no-raw-design-values -- see body tag above: token CSS may not be loaded in this boundary. */}
          <p style={{ fontSize: "0.875rem", color: "#6b7280", marginBottom: "1.5rem" }}>
            An unexpected error occurred.{error.digest && <> Error ID: <code style={{ fontFamily: "monospace" }}>{error.digest}</code></>}
          </p>
          {/* eslint-disable-next-line dbp-local-hex/no-raw-design-values -- see body tag above: token CSS may not be loaded in this boundary. */}
          <button onClick={reset} style={{ padding: "0.5rem 1.25rem", fontSize: "0.875rem", fontWeight: 500, borderRadius: "6px", border: "none", backgroundColor: "#030F35", color: "#fff", cursor: "pointer" }}>Try again</button>
        </div>
      </body>
    </html>
  );
}
`,
);

writeFile(
  "app/not-found.tsx",
  `// app/not-found.tsx — 404 page for ${manifest.solution}.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
import Link from "next/link";

export default function NotFound() {
  return (
    <div style={{ fontFamily: "system-ui, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", minHeight: "100vh", backgroundColor: "var(--color-surface)", color: "var(--color-text)" }}>
      <div style={{ textAlign: "center", maxWidth: 480, padding: "2rem" }}>
        <p style={{ fontSize: "11px", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "monospace", color: "var(--color-text-disabled)", marginBottom: "1rem" }}>${manifest.solution} · 404</p>
        <h1 style={{ fontSize: "1.5rem", fontWeight: 600, marginBottom: "0.75rem" }}>Page not found</h1>
        <p style={{ fontSize: "0.875rem", color: "var(--color-text-secondary)", marginBottom: "1.5rem" }}>The page you are looking for does not exist or has been moved.</p>
        <Link href="/home" style={{ display: "inline-block", padding: "0.5rem 1.25rem", fontSize: "0.875rem", fontWeight: 500, borderRadius: "6px", backgroundColor: "var(--color-primary)", color: "var(--color-primary-foreground)", textDecoration: "none" }}>Return to Home</Link>
      </div>
    </div>
  );
}
`,
);

writeFile(
  "app/(authenticated)/[...slug]/page.tsx",
  `// app/(authenticated)/[...slug]/page.tsx — catch-all for nav items without a page yet.
// Body-only — TransactionShell provided by app/(authenticated)/layout.tsx.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
import Link from "next/link";

export default async function CatchAllPage({
  params,
}: {
  params: Promise<{ slug: string[] }>;
}) {
  const { slug } = await params;
  const path = "/" + slug.join("/");

  return (
    <div className="flex flex-col items-center justify-center text-center px-6" style={{ minHeight: "60vh" }}>
      <p className="font-mono tracking-[0.14em] uppercase text-[var(--color-text-disabled)] mb-4" style={{ fontSize: "11px" }}>
        {path}
      </p>
      <h1 className="text-xl font-semibold mb-2 text-[var(--color-text)]">
        Coming soon
      </h1>
      <p className="text-sm text-[var(--color-text-secondary)] mb-6 max-w-sm">
        This section is being built out. Check back soon or return to the home page.
      </p>
      <Link
        href="/home"
        className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md bg-[var(--color-primary)] text-white hover:opacity-90 transition-opacity"
      >
        Return to Home
      </Link>
    </div>
  );
}
`,
);

writeFile(
  "app/api/health/route.ts",
  `// app/api/health/route.ts — liveness probe for ${manifest.solution}.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
import { NextResponse } from "next/server";

export const runtime = "edge";

export function GET() {
  return NextResponse.json(
    { status: "ok", solution: "${manifest.solution}", timestamp: new Date().toISOString() },
    { status: 200, headers: { "Cache-Control": "no-store" } },
  );
}
`,
);

// ── lib/env.ts — validated environment variables (ADR-0028) ───────────────────
writeFile(
  "lib/env.ts",
  `// lib/env.ts — Validated environment variables for ${manifest.solution}.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
// Uses @t3-oss/env-nextjs to validate env vars at build time and runtime.
import { createEnv } from "@t3-oss/env-nextjs";
import { z } from "zod";

export const env = createEnv({
  server: {
    DBP_AUTH_SESSION_SECRET: z.string().min(32, "DBP_AUTH_SESSION_SECRET must be at least 32 characters"),
    DBP_IDP_PROVIDER: z.enum(["password", "ldap", "entra", "entra-external"]).default("password"),
    DATABASE_URL: z.string().url().optional(),
    // Entra ID (workforce) — used when DBP_IDP_PROVIDER=entra
    ENTRA_TENANT_ID: z.string().optional(),
    ENTRA_CLIENT_ID: z.string().optional(),
    ENTRA_CLIENT_SECRET: z.string().optional(),
    ENTRA_REDIRECT_URI: z.string().url().optional(),
    // Entra External ID (CIAM) — used when DBP_IDP_PROVIDER=entra-external
    ENTRA_EXTERNAL_TENANT_NAME: z.string().optional(),
    ENTRA_EXTERNAL_CLIENT_ID: z.string().optional(),
    ENTRA_EXTERNAL_CLIENT_SECRET: z.string().optional(),
    ENTRA_EXTERNAL_REDIRECT_URI: z.string().url().optional(),
    // LDAP / on-prem Active Directory — used when DBP_IDP_PROVIDER=ldap
    LDAP_URL: z.string().optional(),
    LDAP_BIND_DN: z.string().optional(),
    LDAP_BIND_PASSWORD: z.string().optional(),
    LDAP_BASE_DN: z.string().optional(),
    LDAP_USER_FILTER: z.string().optional(),
    // PS.NOTIF env surface — names match what @dbp/ps-notif/server/transport.ts
    // actually reads (SMTP_URL connection string + MSGRAPH_* — NOT SMTP_HOST/PORT
    // or NOTIF_MS_GRAPH_*, which nothing reads).
    NOTIF_EMAIL_TRANSPORT: z.enum(["smtp", "msgraph"]).default("smtp"),
    NOTIF_EMAIL_CAPTURE: z.coerce.boolean().optional(),
    SMTP_URL: z.string().optional(),
    SMTP_FROM: z.string().email().optional(),
    MSGRAPH_TENANT_ID: z.string().optional(),
    MSGRAPH_CLIENT_ID: z.string().optional(),
    MSGRAPH_CLIENT_SECRET: z.string().optional(),
    MSGRAPH_SENDER_UPN: z.string().optional(),
    NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
${rateLimitEnabled ? `    // (GAP-BRS-5, H1 Table 3) App-level rate-limit tunables — documented, env-overridable
    // defaults (auth: 10 req/60s, other platform routes: 120 req/60s). See middleware.ts.
    DBP_RATE_LIMIT_ENABLED: z.coerce.boolean().default(true),
    DBP_RATE_LIMIT_AUTH_WINDOW_S: z.coerce.number().int().positive().default(60),
    DBP_RATE_LIMIT_AUTH_MAX: z.coerce.number().int().positive().default(10),
    DBP_RATE_LIMIT_DEFAULT_WINDOW_S: z.coerce.number().int().positive().default(60),
    DBP_RATE_LIMIT_DEFAULT_MAX: z.coerce.number().int().positive().default(120),
` : ""}${(manifest.feature_flags ?? []).map((f) => `    ${flagEnvVar(f.id)}: z.coerce.boolean().optional(),`).join("\n")}
  },
  client: {
    NEXT_PUBLIC_APP_URL: z.string().url().optional(),
  },
  runtimeEnv: {
    DBP_AUTH_SESSION_SECRET: process.env.DBP_AUTH_SESSION_SECRET,
    DBP_IDP_PROVIDER: process.env.DBP_IDP_PROVIDER,
    DATABASE_URL: process.env.DATABASE_URL,
    ENTRA_TENANT_ID: process.env.ENTRA_TENANT_ID,
    ENTRA_CLIENT_ID: process.env.ENTRA_CLIENT_ID,
    ENTRA_CLIENT_SECRET: process.env.ENTRA_CLIENT_SECRET,
    ENTRA_REDIRECT_URI: process.env.ENTRA_REDIRECT_URI,
    ENTRA_EXTERNAL_TENANT_NAME: process.env.ENTRA_EXTERNAL_TENANT_NAME,
    ENTRA_EXTERNAL_CLIENT_ID: process.env.ENTRA_EXTERNAL_CLIENT_ID,
    ENTRA_EXTERNAL_CLIENT_SECRET: process.env.ENTRA_EXTERNAL_CLIENT_SECRET,
    ENTRA_EXTERNAL_REDIRECT_URI: process.env.ENTRA_EXTERNAL_REDIRECT_URI,
    LDAP_URL: process.env.LDAP_URL,
    LDAP_BIND_DN: process.env.LDAP_BIND_DN,
    LDAP_BIND_PASSWORD: process.env.LDAP_BIND_PASSWORD,
    LDAP_BASE_DN: process.env.LDAP_BASE_DN,
    LDAP_USER_FILTER: process.env.LDAP_USER_FILTER,
    NOTIF_EMAIL_TRANSPORT: process.env.NOTIF_EMAIL_TRANSPORT,
    NOTIF_EMAIL_CAPTURE: process.env.NOTIF_EMAIL_CAPTURE,
    SMTP_URL: process.env.SMTP_URL,
    SMTP_FROM: process.env.SMTP_FROM,
    MSGRAPH_TENANT_ID: process.env.MSGRAPH_TENANT_ID,
    MSGRAPH_CLIENT_ID: process.env.MSGRAPH_CLIENT_ID,
    MSGRAPH_CLIENT_SECRET: process.env.MSGRAPH_CLIENT_SECRET,
    MSGRAPH_SENDER_UPN: process.env.MSGRAPH_SENDER_UPN,
    NODE_ENV: process.env.NODE_ENV,
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
${rateLimitEnabled ? `    DBP_RATE_LIMIT_ENABLED: process.env.DBP_RATE_LIMIT_ENABLED,
    DBP_RATE_LIMIT_AUTH_WINDOW_S: process.env.DBP_RATE_LIMIT_AUTH_WINDOW_S,
    DBP_RATE_LIMIT_AUTH_MAX: process.env.DBP_RATE_LIMIT_AUTH_MAX,
    DBP_RATE_LIMIT_DEFAULT_WINDOW_S: process.env.DBP_RATE_LIMIT_DEFAULT_WINDOW_S,
    DBP_RATE_LIMIT_DEFAULT_MAX: process.env.DBP_RATE_LIMIT_DEFAULT_MAX,
` : ""}${(manifest.feature_flags ?? []).map((f) => `    ${flagEnvVar(f.id)}: process.env.${flagEnvVar(f.id)},`).join("\n")}
  },
  skipValidation: !!process.env.SKIP_ENV_VALIDATION,
});
`,
);

// ── solution/flags/config.ts — typed feature flag defaults ────────────────────
// Emitted when manifest declares a feature_flags: block. Consumed by getFeatureFlags()
// from @dbp/flags/server to resolve env overrides at request time.
const flagEntries = manifest.feature_flags ?? [];
writeFile(
  "solution/flags/config.ts",
  `// solution/flags/config.ts — Feature flag defaults for ${manifest.solution}.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
// Import featureFlagDefaults into a Server Component and pass to getFeatureFlags().
${flagEntries.length === 0 ? "// No feature_flags declared in manifest. All useFeatureFlag() calls return false." : ""}
export const featureFlagDefaults = {
${flagEntries.map((f) => `  ${JSON.stringify(f.id)}: ${f.enabled},`).join("\n")}
} as const;

export type FeatureFlagId = keyof typeof featureFlagDefaults;
`,
);

// Shell v2 Option 2 (breadcrumb-in-topbar): a route → breadcrumb-trail map, built
// from the SAME moduleBreadcrumbTrail() used per-page below, so AppChrome's top-bar
// breadcrumb and PageHeader's (now-hidden) breadcrumb never diverge. Emitted once as
// app/route-breadcrumbs.ts and consumed by solution-chrome.tsx via usePathname().
const routeBreadcrumbEntries = [];

for (const mod of manifest.modules) {
  const canonicalShellId = resolveShellId(mod.scaffold);
  const shellMeta = SHELL_COMPONENT[canonicalShellId];
  if (!shellMeta) continue;

  const routeSegment = moduleRoutePath(mod);
  const isWorkspace = canonicalShellId === "SH.WORKSPACE";
  routeBreadcrumbEntries.push([`/${routeSegment}`, moduleBreadcrumbTrail(mod, routeSegment)]);

  // ── R1 page-component seam (manifest `pageComponent`) ─────────────────────────
  // A module may override its generated body with a SOLUTION-OWNED component instead
  // of the default feature/EntityList scaffold. The component lives under
  // solution/pages/** (preserved across regens). This is the sanctioned alternative
  // to hand-editing the generator-owned page — the wiring is declared in the manifest,
  // so it survives every regen. The generated wrapper page is a thin server component
  // that renders the solution component; the layout/nav chrome still comes from
  // app/(authenticated)/layout.tsx (these are body-only pages).
  if (mod.pageComponent) {
    if (!isWorkspace) {
      warn(`Module ${mod.id}: "pageComponent" is only supported for SH.WORKSPACE modules; ignoring.`);
    } else {
      const spec = String(mod.pageComponent).replace(/\.(tsx?|jsx?)$/, "");
      if (!spec.startsWith("solution/pages/")) {
        die(`Module ${mod.id}: "pageComponent" must point under solution/pages/ (got "${mod.pageComponent}").`);
      }
      // PascalCase the filename: a kebab/snake-cased pageComponent (executive-dashboard)
      // must not become a lowercase identifier, or JSX reads `<executivedashboard />` as an
      // intrinsic HTML element instead of a component reference and typecheck fails.
      const compFile = spec.split("/").pop() || "SolutionPage";
      const compName =
        compFile
          .split(/[^a-zA-Z0-9]+/)
          .filter(Boolean)
          .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
          .join("") || "SolutionPage";
      // Relative path from app/(authenticated)/<routeSegment>/page.tsx up to repo root,
      // then into the solution path. Dir segments = app + (authenticated) + routeSegment parts.
      const importSpec = "../".repeat(2 + routeSegment.split("/").length) + spec;
      writeFile(
        `app/(authenticated)/${routeSegment}/page.tsx`,
        `// Module: ${mod.id} — ${mod.name}
// Layout: pageComponent
// Body-only page — TransactionShell provided by app/(authenticated)/layout.tsx.
// Body overridden by manifest "pageComponent" → ${spec} (SOLUTION-OWNED, preserved on regen).
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
import ${compName} from "${importSpec}";

export default function ${mod.name.replace(/[^a-zA-Z0-9]/g, "")}Page() {
  return <${compName} />;
}
`,
      );
      // Create-if-missing stub so the build resolves before the developer fills it in.
      // solution/pages/** is solution-owned (see isSolutionOwned) → never overwritten.
      // G-SEAM/P1: when the module declares `composesOrganism`, the stub is a
      // composition-only skeleton around the registered organism instead of freeform
      // placeholder JSX — this is the seam that stops a builder from hand-rolling a
      // bespoke reimplementation of a registered organism in a solution-owned page.
      let stubBody;
      if (mod.composesOrganism) {
        const organismEntry = Object.values(FEATURE_COMPONENT).find(
          (entry) => entry.importFrom === `@dbp/organisms/${mod.composesOrganism}`,
        );
        if (!organismEntry) {
          die(
            `Module ${mod.id}: "composesOrganism: ${mod.composesOrganism}" does not resolve to a ` +
              `registered organism (no FEATURE_COMPONENT entry with importFrom ` +
              `"@dbp/organisms/${mod.composesOrganism}"). Check the slug against FEATURE_COMPONENT.`,
          );
        }
        stubBody = `// SOLUTION-OWNED page component for module ${mod.id} (${mod.name}).
// Wired into app/(authenticated)/${routeSegment}/page.tsx via the manifest "pageComponent" field.
// Preserved across regens. Composes the registered organism per "composesOrganism" — keep this
// file to prop-wiring only; hand-rolling a bespoke replacement here defeats the seam (G-SEAM).
// composes: @dbp/organisms/${mod.composesOrganism}
// Imported under an alias: the organism and this page component often share a name
// (EntityList, WidgetGrid), and an unaliased import would collide with the local
// declaration below.
import { default as ${organismEntry.name}Organism } from "@dbp/organisms/${mod.composesOrganism}";

export default function ${compName}() {
  // wire props here
  return <${organismEntry.name}Organism />;
}
`;
      } else {
        stubBody = `// SOLUTION-OWNED page component for module ${mod.id} (${mod.name}).
// Wired into app/(authenticated)/${routeSegment}/page.tsx via the manifest "pageComponent" field.
// Preserved across regens — implement your custom workspace UI here. Add "use client"
// at the top if you use hooks/state.
export default function ${compName}() {
  return (
    <div className="p-6">
      <h1 className="text-lg font-semibold">${mod.name}</h1>
      <p className="mt-1 text-sm text-[var(--color-text-muted)]">
        Replace this stub with the ${mod.name} workspace. This component is solution-owned.
      </p>
    </div>
  );
}
`;
      }
      writeFile(`${spec}.tsx`, stubBody);
      // Create-if-missing smoke-test stub alongside the page stub (solution-owned).
      // Every custom page starts life with a render test — the STCB test-gap
      // reinforcement lever 1: builders extend it instead of starting from zero.
      writeFile(
        `solution/pages/__tests__/${compName}.test.tsx`,
        `// @vitest-environment jsdom
// SOLUTION-OWNED smoke test for ${spec}.tsx (module ${mod.id}).
// Emitted once by scaffold-solution; extend with real assertions as the page grows.
import { describe, it, expect } from "vitest";
import { render } from "@testing-library/react";
import ${compName} from "../${compFile}";

describe("${compName}", () => {
  it("renders without throwing", () => {
    const { container } = render(<${compName} />);
    expect(container.firstChild).not.toBeNull();
  });
});
`,
      );
      continue; // override is total — skip the default feature/slot emission for this module
    }
  }

  // Catalogue card → detail wiring (APP.F10). A wired card MUST land on a real
  // detail route, so when a module renders a catalog grid we navigate to a
  // co-located /[id] page and emit that page (MarketplaceItemDetail) below.
  const catalogueFeat = mod.features.find((f) => f.id === "APP.F10");
  const hasCatalogueCard = !!catalogueFeat;
  const catalogueDetailBase = `/${routeSegment}`;

  // Per-module sidebar nav (optional). Drives the emitted <SOL>_NAV constant,
  // the @dbp/ui Breadcrumb import, and the shell's nav={…} prop.
  const navInfo = buildModuleNav(mod);

  // ── Slot resolution ─────────────────────────────────────────────────────────
  // For SH.WORKSPACE (TransactionShell), all content lands in either "main" or
  // "context". Legacy slot names from the old 5-shell model (catalog, queue,
  // detailContent, detailTabs, workbench, inspector) are remapped uniformly.
  function resolveSlot(feat) {
    const regEntry = featureMap.get(feat.id);
    const rawSlot = feat.slot ?? (Array.isArray(regEntry?.slot) ? regEntry.slot[0] : regEntry?.slot) ?? "main";
    if (isWorkspace) {
      return WORKSPACE_SLOT_REMAP[rawSlot] ?? "main";
    }
    return rawSlot;
  }

  // Group features by their RESOLVED slot.
  const bySlot = new Map();
  for (const feat of mod.features) {
    const slot = resolveSlot(feat);
    if (!bySlot.has(slot)) bySlot.set(slot, []);
    bySlot.get(slot).push(feat);
  }

  // Collect unique feature imports for this module
  const featureImports = new Map();
  for (const feat of mod.features) {
    if (!featureImports.has(feat.id)) {
      featureImports.set(feat.id, FEATURE_COMPONENT[feat.id]);
    }
  }

  // ── Master-detail detection ───────────────────────────────────────────────
  // When a module pairs an EntityList (APP.F01, master) with an EntityDetail
  // (APP.F02, detail), the list dispatches `dbp:entity-list:row-select` and the
  // detail's entityId is driven from page state (replacing the "placeholder").
  const masterFeat = mod.features.find((f) => f.id === "APP.F01");
  const detailFeat = mod.features.find((f) => f.id === "APP.F02");
  const masterDetail =
    masterFeat && detailFeat
      ? { entityType: detailFeat.config?.entityType ?? masterFeat.config?.entityType ?? "" }
      : null;

  // Determine primary content slot for PageHeader injection.
  // All workspace modules use "main" (legacy SH.03 detailContent is now remapped to main).
  const PRIMARY_SLOT_FOR_HEADER = "main";

  // PS-WORKFLOW-UI §5b: set true by featureJsx() when an emitted LVE/EntityList
  // surface is wired to @dbp/organisms/workflow-binding — drives the page's import line.
  let usesWorkflowBinding = false;
  // Set true when this page renders a demo-record LVE stub via buildDemoLveConfig()
  // — drives the lib/demo-lve-config import line.
  let usesDemoLveConfig = false;
  // DEF-6 fix: layouts whose main-slot branch never renders the `{lveListMode ? ... : ...}`
  // header ternary (defined once here, hoisted above featureJsx() so both it and the later
  // hook-declaration check share the identical set — a second, independently-drifting copy
  // is exactly how this bug happened: featureJsx() kept emitting the onViewChange callback's
  // `setLveListMode(...)` call for these layouts after the hook itself stopped being declared).
  const LVE_TERNARY_LAYOUTS = new Set(["canvas-bare", "overview-content", "config-form-custom", "collection-table", "collection-board", "form-basic", "form-guided", "config-form-single", "config-form-tabs", "canvas-workspace"]);

  function featureJsx(feat) {
    const comp = FEATURE_COMPONENT[feat.id];
    if (!comp) {
      console.warn(
        `[scaffold] WARNING: no FEATURE_COMPONENT entry for ${feat.id} (role: ${feat.role}) ` +
          `in module ${mod.id} — emitting no-op placeholder. Add ${feat.id} to FEATURE_COMPONENT to fix.`,
      );
      return `        {/* ${feat.id} (${feat.role}): no component mapping */}`;
    }
    const cfg = { ...feat.config };
    // CopilotPage (APP.F15) and LveWorkspace (APP.F19) are body-only inside a layout.
    if (feat.id === "APP.F15") cfg.externalHeader = true;
    if (feat.id === "APP.F19") {
      // ── Lifecycle-aware LVE config synthesis (Path A) ──────────────────────
      // Helper functions (mirrors standard-menu-scaffold.mjs equivalents).
      const _toLabel = (str) =>
        str.replace(/(^|[-_])([a-z])/g, (_, sep, c) => (sep ? " " : "") + c.toUpperCase());

      const _stateTone = (state) => {
        if (/done|closed|complet|approv|activ|success/.test(state)) return "success";
        if (/progress|pending|processing|in.review|fulfil/.test(state)) return "warning";
        if (/review|waiting|hold|return/.test(state)) return "gray";
        if (/cancel|reject|error|fail/.test(state)) return "danger";
        return "info";
      };

      const _actionIcon = (target) => {
        const t = (target ?? "").toLowerCase();
        if (/approv/.test(t)) return "Check";
        if (/submit/.test(t)) return "Send";
        if (/reject/.test(t)) return "X";
        if (/complet/.test(t)) return "CheckCircle";
        if (/review|in.review/.test(t)) return "Eye";
        return "ArrowRight";
      };

      // Look up the manifest entity whose type matches feat.config.entityType.
      const _lveEntityType = feat.config?.entityType;
      const _lveEntity = _lveEntityType
        ? (manifest.entities ?? []).find((e) => e.type === _lveEntityType)
        : null;

      // DEFECT 4 (naive-UX-audit): a manifest entity with NO lifecycle block (e.g.
      // "capability") used to fall straight to the `else` branch below and render a
      // read-only detail rail with zero actions — the editable-Overview synthesis was
      // gated on `.lifecycle` even though field-level editability has nothing to do
      // with whether the entity has a lifecycle. Any declared entity now gets the
      // derived columns + editable Overview detail tab; only lifecycle-specific
      // extras (stage bar, quick actions, bulk actions, per-state list tabs) require
      // an actual lifecycle block. An entity can opt out entirely via `readOnly: true`
      // in its manifest 'entities:' declaration.
      if (_lveEntity && _lveEntity.readOnly !== true) {
        const lc = _lveEntity.lifecycle ?? null;
        const lcStates = lc?.states ?? [];

        // Determine the stage field.
        const stageField =
          _lveEntity.fields?.find((f) => f.name === "status")?.name ??
          _lveEntity.fields?.find(
            (f) => f.type === "enum" && f.enum?.some((v) => lcStates.includes(v)),
          )?.name ??
          "status";

        // Badge tones map.
        const tones = Object.fromEntries(lcStates.map((s) => [s, _stateTone(s)]));

        // Columns — use manifest-provided columns or derive from entity fields (≤6).
        const derivedColumns =
          feat.config?.columns && feat.config.columns.length > 0
            ? feat.config.columns
            : (_lveEntity.fields ?? []).slice(0, 6).map((f) => {
                const isStatus = f.name === stageField;
                const isDate = /updatedAt|createdAt|updated|created|date/.test(f.name);
                return {
                  field: f.name,
                  label: _toLabel(f.name),
                  sortable: true,
                  ...(isStatus && lcStates.length > 0
                    ? {
                        format: "badge",
                        badgeTones: tones,
                        editable: true,
                        editType: "select",
                        editOptions: lcStates.map((s) => ({ value: s, label: _toLabel(s) })),
                      }
                    : {}),
                  ...(isDate ? { format: "date" } : {}),
                };
              });
        if (derivedColumns.length === 0) derivedColumns.push({ field: "name", label: "Name", sortable: true });

        // List tabs: "All" sentinel + one per lifecycle state.
        const listTabs = [
          { id: "all", label: "All" },
          ...lcStates.map((s) => ({ id: s, label: _toLabel(s), filter: { field: stageField, value: s } })),
        ];

        // Stages bar.
        const stages = lcStates.map((s) => ({ id: s, label: _toLabel(s), tone: _stateTone(s) }));

        // Quick actions from lifecycle transitions.
        const quickActions = (lc?.transitions ?? []).map((t) => ({
          id: `action-${t.to}`,
          label: t.label ?? _toLabel(t.to),
          icon: _actionIcon(t.to),
          when: [{ field: stageField, op: "is", value: t.from }],
          patch: { [stageField]: t.to },
        }));

        // Bulk actions — transitions from the last active state.
        const lastActiveState = lcStates.at(-1);
        const bulkActions = (lc?.transitions ?? [])
          .filter((t) => t.from === lastActiveState)
          .map((t) => ({ id: `bulk-${t.to}`, label: `Mark ${_toLabel(t.to)}`, patch: { [stageField]: t.to } }));

        // Header slot.
        const firstNonIdField = derivedColumns.find((c) => c.field !== "id")?.field ?? "name";
        const header = {
          titleField: firstNonIdField,
          statusField: stageField,
          ...(derivedColumns.length >= 3 ? { subtitleField: derivedColumns[1]?.field } : {}),
        };

        // Detail overview — DERIVE REAL EDITABLE FIELDS from the entity's Zod field
        // types (universal field-layer ruling: LVE's edit pane must render actual
        // editable fields, not read-only rows). Every derived column becomes a
        // DetailField in a single "Overview" section, with editType inferred from
        // the manifest entity field's declared type. Fields with no schema match
        // (synthetic/computed) fall back to read-only.
        const detailFields = derivedColumns.map((c) => {
          if (c.editable) {
            // Already resolved above (the lifecycle status column) — reuse as-is.
            return {
              field: c.field,
              label: c.label,
              ...(c.format ? { format: c.format } : {}),
              editable: true,
              editType: c.editType,
              ...(c.editOptions ? { editOptions: c.editOptions } : {}),
            };
          }
          const srcField = (_lveEntity.fields ?? []).find((f) => f.name === c.field);
          if (!srcField) {
            return { field: c.field, label: c.label, ...(c.format ? { format: c.format } : {}) };
          }
          if (srcField.type === "enum" && srcField.enum) {
            return {
              field: c.field,
              label: c.label,
              editable: true,
              editType: "select",
              editOptions: srcField.enum.map((v) => ({ value: v, label: _toLabel(v) })),
            };
          }
          if (srcField.type === "number") {
            return { field: c.field, label: c.label, editable: true, editType: "number" };
          }
          if (srcField.type === "boolean") {
            return {
              field: c.field,
              label: c.label,
              editable: true,
              editType: "select",
              editOptions: [
                { value: "true", label: "True" },
                { value: "false", label: "False" },
              ],
            };
          }
          if (srcField.type === "string_array") {
            // No multi-value editor in the LVE field layer yet — read-only until one exists.
            return { field: c.field, label: c.label };
          }
          return { field: c.field, label: c.label, editable: true, editType: "text" };
        });
        const detailTabs = [
          { id: "details", label: "Details", sections: [{ title: "Overview", fields: detailFields }] },
        ];

        // GAP 1 (creation) — synthesise createConfig from the same detailFields
        // derivation above, mirroring the editable-detailTabs synthesis pattern:
        // one CreateField per editable detail field, `required` taken from the
        // manifest entity field's own `required` flag (falls back to false —
        // the manifest is the source of truth here, this does not invent
        // requiredness the schema doesn't declare). The lifecycle status field
        // is excluded — new records get the lifecycle's initial state via
        // `defaults`, not a user-facing dropdown on create. Entities opted out
        // via `readOnly: true` never reach this branch, so they get no
        // createConfig and no "+ New" button (LveWorkspaceTemplate gates the
        // button on `Boolean(config.createConfig)`).
        const createFields = detailFields
          .filter((f) => f.editable && f.field !== stageField)
          .map((f) => {
            const srcField = (_lveEntity.fields ?? []).find((sf) => sf.name === f.field);
            return {
              field: f.field,
              label: f.label,
              editType: f.editType ?? "text",
              ...(f.editOptions ? { editOptions: f.editOptions } : {}),
              required: srcField?.required === true,
            };
          });
        const createConfig =
          createFields.length > 0
            ? {
                title: `New ${header.titleField ? _toLabel(_lveEntityType) : _lveEntityType}`,
                fields: createFields,
                ...(lc?.initial ? { defaults: { [stageField]: lc.initial } } : {}),
              }
            : undefined;

        // Synthesised base — manifest's explicit feat.config keys WIN over synthesised defaults.
        const synthesised = {
          entityType: _lveEntityType,
          externalHeader: true,
          columns: derivedColumns,
          listTabs,
          ...(stages.length > 0 ? { stageField, stages } : {}),
          ...(quickActions.length > 0 ? { quickActions } : {}),
          ...(bulkActions.length > 0 ? { bulkActions } : {}),
          header,
          detailTabs,
          ...(createConfig ? { createConfig } : {}),
        };
        // Spread order: synthesised base → manifest overrides → always-on flags.
        Object.assign(cfg, synthesised, feat.config, { externalHeader: true });
      } else {
        // No entity or no lifecycle — original behaviour (serialise feat.config verbatim).
        cfg.externalHeader = true;
      }
      // ── End lifecycle synthesis ─────────────────────────────────────────────
      // ── PS-WORKFLOW-UI §5b: workflow-bound stepper wiring (Pattern A) ───────
      // When this LVE's bound entity declares workflows[] AND the solution
      // consumes PS.WORKFLOW, emit the same detailExtras wiring as the
      // apps/wfd-01 ApprovalsWorkspace.tsx reference: stepper, header actions,
      // and a "Progress History" extra tab — all bound via recordId + config.
      const _lveWorkflowIds = _lveEntity?.workflows;
      const hasWorkflowBinding =
        consumedServices.includes("PS.WORKFLOW") && Array.isArray(_lveWorkflowIds) && _lveWorkflowIds.length > 0;
      if (hasWorkflowBinding) {
        usesWorkflowBinding = true;
      }
      const workflowConfigLiteral = hasWorkflowBinding
        ? `{ definitionIds: ${JSON.stringify(_lveWorkflowIds)}, entityType: ${JSON.stringify(_lveEntityType)} }`
        : null;
      // Demo-record stubs (unbuilt pages): emit a one-line helper call instead of
      // the byte-identical inline blob. The blob varies only by `title` — verified
      // by diffing emitted demo pages. Real-entity configs still serialise inline.
      const isDemoLveStub = cfg?.entityType === "demo-record";
      if (isDemoLveStub) {
        usesDemoLveConfig = true;
        if (!demoLveCanonicalCfg) demoLveCanonicalCfg = { ...cfg };
      }
      const configStr = isDemoLveStub
        ? `buildDemoLveConfig(${JSON.stringify(cfg.title ?? mod.name)})`
        : JSON.stringify(cfg, null, 8);
      const detailExtrasProp = hasWorkflowBinding
        ? `\n          detailExtras={{\n` +
          `            stepper: (record) => (\n` +
          `              <RecordWorkflowStepper recordId={String(record.id)} config={${workflowConfigLiteral}} />\n` +
          `            ),\n` +
          `            headerActions: (record) => (\n` +
          `              <RecordWorkflowActions recordId={String(record.id)} config={${workflowConfigLiteral}} />\n` +
          `            ),\n` +
          `            extraTab: {\n` +
          `              label: "Progress History",\n` +
          `              content: (record) => (\n` +
          `                <RecordProgressHistory recordId={String(record.id)} config={${workflowConfigLiteral}} />\n` +
          `              ),\n` +
          `            },\n` +
          `          }}`
        : "";
      // Full-bleed: negate shell gutter so the LVE table runs edge-to-edge.
      // ADR-0040: typed onViewChange callback drives the page's list/split header
      // toggle (replaces the deprecated dbp:lve:view-change DOM listener).
      // DEF-6: only wire the callback when the surrounding layout actually declares the
      // `lveListMode`/`setLveListMode` hook (see LVE_TERNARY_LAYOUTS above) — layouts like
      // "collection-table" (e.g. admin/* routes forced there by ADMIN_ARCHETYPE_MAP) never
      // render the header ternary, so `setLveListMode` would be an undeclared reference
      // (TS2304) with nothing to receive the mode change.
      const callbacksProp = LVE_TERNARY_LAYOUTS.has(layoutType)
        ? ""
        : `\n          callbacks={{ onViewChange: (mode) => setLveListMode(mode === "list") }}`;
      return `        <div className="-mx-[var(--shell-gutter)] -mb-[var(--shell-gutter)] h-[calc(100%+var(--shell-gutter))] flex flex-col">\n          <${comp.name}\n          key="${feat.role}"\n          {...(${configStr} as Parameters<typeof ${comp.name}>[0])}${callbacksProp}${detailExtrasProp}\n        /></div>`;
    }
    // Master-detail wiring: list becomes selectable; detail's id is page state.
    if (masterDetail && feat.id === "APP.F01") {
      if (cfg.selectable === undefined) cfg.selectable = true;
    }
    if (masterDetail && feat.id === "APP.F02") {
      // entityId is supplied at runtime from selectedId — inject the binding below.
      delete cfg.entityId;
      const configStr = JSON.stringify(cfg, null, 8);
      return `        <${comp.name}\n          key="${feat.role}"\n          {...({ ...(${configStr} as Parameters<typeof ${comp.name}>[0]), entityId: selectedId })}\n        />`;
    }
    // ── PS-WORKFLOW-UI §5b: workflow-bound stepper wiring (Pattern B) ─────────
    // A standalone EntityList (APP.F01, not master-detail-paired) rendering a
    // workflow-bound entity gets its detail drawer opened (detailDrawer: true
    // when not already configured) and drawerExtras wired with a compact
    // RecordWorkflowStepper + a footer (RecordWorkflowActions + Progress
    // History link) — the drawer-scoped equivalent of the LVE detailExtras
    // emission above, kept data-driven and minimal per the spec.
    if (feat.id === "APP.F01" && !masterDetail) {
      const _entityListEntityType = cfg.entityType;
      const _entityListEntity = _entityListEntityType
        ? (manifest.entities ?? []).find((e) => e.type === _entityListEntityType)
        : null;
      const _entityListWorkflowIds = _entityListEntity?.workflows;
      const hasEntityListWorkflowBinding =
        consumedServices.includes("PS.WORKFLOW") &&
        Array.isArray(_entityListWorkflowIds) &&
        _entityListWorkflowIds.length > 0;
      if (hasEntityListWorkflowBinding) {
        usesWorkflowBinding = true;
        if (cfg.detailDrawer === undefined) cfg.detailDrawer = true;
        const workflowConfigLiteral = `{ definitionIds: ${JSON.stringify(_entityListWorkflowIds)}, entityType: ${JSON.stringify(_entityListEntityType)} }`;
        const configStr = JSON.stringify(cfg, null, 8);
        const drawerExtrasProp =
          `\n          drawerExtras={{\n` +
          `            stepper: (record) => (\n` +
          `              <RecordWorkflowStepper recordId={String(record.id)} config={${workflowConfigLiteral}} />\n` +
          `            ),\n` +
          `            footer: (record) => (\n` +
          `              <>\n` +
          `                <RecordWorkflowActions recordId={String(record.id)} config={${workflowConfigLiteral}} />\n` +
          `                <RecordProgressHistory recordId={String(record.id)} config={${workflowConfigLiteral}} />\n` +
          `              </>\n` +
          `            ),\n` +
          `          }}`;
        return `        <${comp.name}\n          key="${feat.role}"\n          {...(${configStr} as Parameters<typeof ${comp.name}>[0])}${drawerExtrasProp}\n        />`;
      }
    }
    const configStr = JSON.stringify(cfg, null, 8);
    if (feat.id === "APP.F10") {
      // Wire the catalog card → co-located detail route (router declared in the
      // page; the [id] page is emitted by emitCatalogueDetailRoute below).
      const navTo = JSON.stringify(catalogueDetailBase + "/");
      return `        <${comp.name}\n          key="${feat.role}"\n          {...(${configStr} as Parameters<typeof ${comp.name}>[0])}\n          onCardClick={(_t, id) => router.push(${navTo} + encodeURIComponent(id))}\n        />`;
    }
    // APP.F13 ContactForm takes a single `config` prop (types.ts:
    // `{ config }: { config: ContactFormConfig }`) rather than spreading
    // feat.config as top-level props like every other FEATURE_COMPONENT.
    if (feat.id === "APP.F13" || feat.id === "APP.F29") {
      return `        <${comp.name}\n          key="${feat.role}"\n          config={${configStr} as Parameters<typeof ${comp.name}>[0]["config"]}\n        />`;
    }
    // APP.F04 Kanban is NOT given a page-level searchQuery — the board owns
    // its own search box (KanbanToolbar) entirely; see hasKanbanSearch above.
    // It IS given onCardClick — opens the task detail drawer (design-audit
    // 2026-07-17 P1c item 1) via page-level selectedTaskId state (declared
    // below, gated on hasKanbanSearch), mirroring the master-detail
    // selectedId pattern above.
    if (feat.id === "APP.F04") {
      usesWorkflowBinding = true;
      return `        <${comp.name}\n          key="${feat.role}"\n          onCardClick={(id) => setSelectedTaskId(id)}\n          {...(${configStr} as Parameters<typeof ${comp.name}>[0])}\n        />`;
    }
    return `        <${comp.name}\n          key="${feat.role}"\n          {...(${configStr} as Parameters<typeof ${comp.name}>[0])}\n        />`;
  }

  // ── Page layout selection (Phase 6) ───────────────────────────────────────
  // The primary (main) slot is wrapped in one of the factory-locked layout
  // components from @dbp/shell-transaction/layouts, so every page is visually
  // uniform with zero per-page layout decisions. Explicit `mod.layout` wins;
  // otherwise the type is inferred from the module's feature mix:
  //   - APP.F19 (LVE)                     → lve-split (CanvasLayout + LveWorkspace, externalHeader)
  //   - all features ANL.*               → analytics-dashboard (chart-dominant + filter bar)
  //   - else                             → object-page-detail (header + content) [DEFAULT]
  // ("collection-grid" layout remains available via an explicit mod.layout override.)
  // Self-headered features render their own title block, so wrapping them in a
  // header-bearing layout would double the header — they map to overview-content.
  // APP.F15 (CopilotPage) uses object-page-detail, and APP.F19 (LVE) uses lve-split —
  // both with externalHeader: true — the layout owns the PageHeader; the feature renders body-only.
  // LVE additionally wraps its content in -mx/mb-[var(--shell-gutter)] for full-bleed tables.
  // APP.F07 (Onboarding) and APP.F10 (CatalogGrid) removed 2026-07-09 — F07 routes to
  // form-guided, F10 routes to collection-grid; neither is self-headered anymore.
  const SELF_HEADERED_FEATURES = new Set([]);
  const FULL_BLEED_FEATURES = new Set([/* APP.F19 moved to working+externalHeader */]);
  // Sibling admin routes derived from the full manifest — used to build the
  // settings nav rail for Type 7 Settings layout pages.
  const adminSiblingRoutes = manifest.modules
    .filter((m) => {
      const seg = moduleRouteSegment(m);
      return seg === "admin" || seg.startsWith("admin/");
    })
    .map((m) => ({ label: m.name, href: `/${moduleRouteSegment(m)}` }));
  // Admin archetype map — explicit route-segment → archetype classification.
  // config-tabs entries carry a canonical default tab-set.
// ─── Admin form specs ────────────────────────────────────────────────────────
// Data-driven field specs for known admin config routes.
// fieldType: "text" | "password" | "url" | "email" | "number" | "switch" | "select"
// For select: options is [{ value, label }], defaultValue is a value string.
// For switch: defaultChecked is boolean.
// For text/password/url/email/number: placeholder and defaultValue are strings.
const ADMIN_FORM_SPECS = {
  "admin/auth": {
    type: "config-form-tabs",
    tabs: [
      {
        id: "general",
        label: "General",
        formId: "auth-general",
        fields: [
          { name: "session-timeout", label: "Session timeout (minutes)", fieldType: "number", defaultValue: "60" },
          { name: "max-sessions", label: "Max concurrent sessions", fieldType: "select", defaultValue: "5", options: [{ value: "1", label: "1" }, { value: "3", label: "3" }, { value: "5", label: "5" }, { value: "10", label: "10" }, { value: "unlimited", label: "Unlimited" }] },
          { name: "require-mfa", label: "Require multi-factor authentication", fieldType: "switch", defaultChecked: true },
          { name: "password-complexity", label: "Enforce password complexity", fieldType: "switch", defaultChecked: true },
        ],
      },
      {
        id: "oauth-2-0",
        label: "OAuth 2.0",
        formId: "auth-oauth-2-0",
        fields: [
          { name: "oauth-client-id", label: "Client ID", fieldType: "text" },
          { name: "oauth-secret", label: "Client secret", fieldType: "password" },
          { name: "oauth-redirect", label: "Allowed redirect URI", fieldType: "url" },
          { name: "token-lifetime", label: "Access token lifetime", fieldType: "select", defaultValue: "3600", options: [{ value: "900", label: "15 min" }, { value: "3600", label: "1 hour" }, { value: "86400", label: "24 hours" }, { value: "604800", label: "7 days" }] },
        ],
      },
      {
        id: "saml-2-0",
        label: "SAML 2.0",
        formId: "auth-saml-2-0",
        fields: [
          { name: "saml-entity-id", label: "SP Entity ID", fieldType: "text" },
          { name: "saml-idp-url", label: "IdP metadata URL", fieldType: "url" },
          { name: "saml-nameid", label: "NameID format", fieldType: "select", defaultValue: "email", options: [{ value: "email", label: "Email" }, { value: "persistent", label: "Persistent" }, { value: "transient", label: "Transient" }, { value: "unspecified", label: "Unspecified" }] },
          { name: "sign-requests", label: "Sign authentication requests", fieldType: "switch", defaultChecked: false },
        ],
      },
    ],
  },
  "admin/organisation": {
    type: "config-form-tabs",
    tabs: [
      {
        id: "general",
        label: "General",
        formId: "org-general",
        fields: [
          { name: "org-name", label: "Organisation name", fieldType: "text" },
          { name: "display-name", label: "Display name", fieldType: "text" },
          { name: "timezone", label: "Timezone", fieldType: "select", defaultValue: "Asia/Riyadh", options: [{ value: "Asia/Riyadh", label: "Asia/Riyadh" }, { value: "Asia/Dubai", label: "Asia/Dubai" }, { value: "Europe/London", label: "Europe/London" }, { value: "UTC", label: "UTC" }] },
        ],
      },
      {
        id: "branding",
        label: "Branding",
        formId: "org-branding",
        fields: [
          { name: "logo-url", label: "Logo URL", fieldType: "url" },
          { name: "primary-colour", label: "Primary colour (hex)", fieldType: "text" },
        ],
      },
      {
        id: "billing",
        label: "Billing",
        formId: "org-billing",
        fields: [
          { name: "plan", label: "Plan", fieldType: "select", defaultValue: "growth", options: [{ value: "starter", label: "Starter" }, { value: "growth", label: "Growth" }, { value: "enterprise", label: "Enterprise" }] },
          { name: "billing-email", label: "Billing email", fieldType: "email" },
        ],
      },
      {
        id: "locales",
        label: "Locales",
        formId: "org-locales",
        fields: [
          { name: "default-language", label: "Default language", fieldType: "select", defaultValue: "en", options: [{ value: "en", label: "English" }, { value: "ar", label: "Arabic" }] },
          { name: "date-format", label: "Date format", fieldType: "select", defaultValue: "dd-mm-yyyy", options: [{ value: "dd-mm-yyyy", label: "DD/MM/YYYY" }, { value: "mm-dd-yyyy", label: "MM/DD/YYYY" }, { value: "iso", label: "ISO" }] },
        ],
      },
    ],
  },
  // admin/access-control now renders AdminAccessMatrix (real PS.RBAC /matrix data —
  // see ADMIN_DEFERRED_ROUTES/ADMIN_RBAC_COMPONENT below), not a config form. Left
  // ADMIN_ARCHETYPE_MAP.tabs for admin/organisation/admin/auth intact — this spec
  // entry is gone since nothing references it any more.
  "admin/workspace-settings": {
    type: "config-form-single",
    formId: "admin-workspace-settings",
    sections: [
      { title: "Workspace", fields: [
        { name: "workspace-name", label: "Workspace name", fieldType: "text" },
        { name: "default-landing", label: "Default landing page", fieldType: "select", defaultValue: "/home", options: [{ value: "/home", label: "Home" }, { value: "/dashboard", label: "My Dashboard" }, { value: "/my-work", label: "My Work" }] },
        { name: "allow-personal-views", label: "Allow personal saved views", fieldType: "switch", defaultChecked: true },
      ] },
    ],
  },
  "admin/branding": {
    type: "config-form-single",
    formId: "admin-branding",
    sections: [
      { title: "Brand", fields: [
        { name: "logo-url", label: "Logo URL", fieldType: "url" },
        { name: "primary-colour", label: "Primary colour (hex)", fieldType: "text" },
        { name: "favicon-url", label: "Favicon URL", fieldType: "url" },
      ] },
    ],
  },
  "admin/regional": {
    type: "config-form-single",
    formId: "admin-regional",
    sections: [
      { title: "Regional & language", fields: [
        { name: "default-language", label: "Default language", fieldType: "select", defaultValue: "en", options: [{ value: "en", label: "English" }, { value: "ar", label: "Arabic" }] },
        { name: "timezone", label: "Timezone", fieldType: "select", defaultValue: "Asia/Riyadh", options: [{ value: "Asia/Riyadh", label: "Asia/Riyadh" }, { value: "Asia/Dubai", label: "Asia/Dubai" }, { value: "Europe/London", label: "Europe/London" }, { value: "UTC", label: "UTC" }] },
        { name: "date-format", label: "Date format", fieldType: "select", defaultValue: "dd-mm-yyyy", options: [{ value: "dd-mm-yyyy", label: "DD/MM/YYYY" }, { value: "mm-dd-yyyy", label: "MM/DD/YYYY" }, { value: "iso", label: "ISO" }] },
      ] },
    ],
  },
  "admin/business-hours": {
    type: "config-form-single",
    formId: "admin-business-hours",
    sections: [
      { title: "Business hours", fields: [
        { name: "working-days", label: "Working days", fieldType: "select", defaultValue: "sun-thu", options: [{ value: "sun-thu", label: "Sunday – Thursday" }, { value: "mon-fri", label: "Monday – Friday" }] },
        { name: "day-start", label: "Day start", fieldType: "text", placeholder: "08:00" },
        { name: "day-end", label: "Day end", fieldType: "text", placeholder: "17:00" },
        { name: "observe-public-holidays", label: "Observe public holidays", fieldType: "switch", defaultChecked: true },
      ] },
    ],
  },
  "admin/defaults": {
    type: "config-form-single",
    formId: "admin-defaults",
    sections: [
      { title: "Default values", fields: [
        { name: "default-priority", label: "Default priority", fieldType: "select", defaultValue: "medium", options: [{ value: "low", label: "Low" }, { value: "medium", label: "Medium" }, { value: "high", label: "High" }] },
        { name: "default-page-size", label: "Default list page size", fieldType: "select", defaultValue: "25", options: [{ value: "10", label: "10" }, { value: "25", label: "25" }, { value: "50", label: "50" }] },
        { name: "auto-assign", label: "Auto-assign new records to reporter's team", fieldType: "switch", defaultChecked: false },
      ] },
    ],
  },
  "admin/data-import": {
    type: "config-form-single",
    formId: "admin-settings",
    sections: [
      {
        title: "Source",
        fields: [
          { name: "source-type", label: "Source type", fieldType: "select", defaultValue: "csv", options: [{ value: "csv", label: "CSV upload" }, { value: "rest", label: "REST endpoint" }, { value: "db", label: "Database" }] },
          { name: "endpoint-url", label: "Endpoint URL", fieldType: "url" },
        ],
      },
      {
        title: "Mapping",
        fields: [
          { name: "mapping-profile", label: "Mapping profile", fieldType: "text" },
        ],
      },
      {
        title: "Schedule",
        fields: [
          { name: "frequency", label: "Frequency", fieldType: "select", defaultValue: "manual", options: [{ value: "manual", label: "Manual" }, { value: "hourly", label: "Hourly" }, { value: "daily", label: "Daily" }, { value: "weekly", label: "Weekly" }] },
        ],
      },
    ],
  },
};


  // admin/form-builder, admin/workflow-builder, admin/rules, admin/users: ruled-deferred
  // capabilities (decision pack N13/N14 + backlog deferral register) or blocked on a
  // missing platform API (admin/users — PS.RBAC/PS.AUTH expose no "list all users"
  // endpoint, only per-user-id role lookups). These render an honest "Coming soon"
  // body (ADMIN_DEFERRED_ROUTES below) instead of a fake demo-record binding.
  const ADMIN_ARCHETYPE_MAP = {
    "admin/form-builder":     { type: "collection-table" },
    "admin/workflow-builder": { type: "collection-table" },
    "admin/data-flows":       { type: "canvas-workspace" },
    "admin/data-model":       { type: "canvas-workspace" },
    "admin/organisation":     { type: "config-form-tabs", tabs: ["General", "Branding", "Billing", "Locales"] },
    "admin/workspace-settings": { type: "config-form-single" },
    "admin/branding":         { type: "config-form-single" },
    "admin/regional":         { type: "config-form-single" },
    "admin/business-hours":   { type: "config-form-single" },
    "admin/defaults":         { type: "config-form-single" },
    "admin/access-control":   { type: "collection-table" },
    "admin/auth":             { type: "config-form-tabs", tabs: ["General", "OAuth 2.0", "SAML 2.0"] },
    "admin/data-import":      { type: "config-form-single" },
    "admin/rules":            { type: "collection-table" },
    "admin/users":            { type: "collection-table" },
    "admin/roles":            { type: "collection-table" },
    "admin/security-logs":    { type: "collection-table" },
    "admin/apis":             { type: "collection-table" },
    "admin/connectors":       { type: "collection-table" },
    "admin/policies":         { type: "collection-table" },
    "admin/controls":         { type: "collection-table" },
    "admin/risks":            { type: "collection-table" },
    "admin/master-data":      { type: "collection-table" },
    "admin/reference-data":   { type: "collection-table" },
    "admin/data-quality":     { type: "collection-table" },
    "admin/data-lineage":     { type: "collection-table" },
  };
  const adminArchetype = ADMIN_ARCHETYPE_MAP[routeSegment] ?? null;
  // admin/users is real when PS.AUTH demo identities exist (the identity source
  // the auth route itself uses); with a real IdP and no fixture, it falls back to
  // the honest deferred body — PS.AUTH has no list-users endpoint yet.
  const ADMIN_DEFERRED_ROUTES = new Set(["admin/form-builder", "admin/workflow-builder", "admin/rules", ...(HAS_AUTH ? [] : ["admin/users"])]);
  const HAS_AUDIT = consumedServices.includes("PS.AUDIT");
  // admin/security-logs: real PS.AUDIT activity feed (AdminAuditLog), not the
  // generic collection-table archetype's KpiScorecard+ChartPanel placeholder
  // (design-audit-2026-07-17 P1c item 2 — that placeholder was mislabeled
  // "security logs" while charting fake capability-status counts).
  const ADMIN_RBAC_COMPONENT = {
    "admin/roles": "AdminRoleList",
    "admin/access-control": "AdminAccessMatrix",
    ...(HAS_AUTH ? { "admin/users": "AdminUserList" } : {}),
    ...(HAS_AUDIT ? { "admin/security-logs": "AdminAuditLog" } : {}),
  };
  // Promoted (2026-07-21, Bindings/Admin resolution) ADMIN_RBAC_COMPONENT entries
  // that now live in @dbp/organisms instead of @dbp/ui. AdminAuditLog is not in
  // this map — it stayed in @dbp/ui.
  const ADMIN_RBAC_ORGANISM_SLUG = {
    AdminRoleList: "admin-role-list",
    AdminAccessMatrix: "admin-access-matrix",
    AdminUserList: "admin-user-list",
  };
  function chooseLayout() {
    // Admin archetype map: for admin/* routes the explicit per-route classification wins
    // over both the standard-menu scaffold layout (mod._standardDemo) and the legacy
    // "config-form-custom" catch-all. Explicit non-demo mod.layout still wins above this.
    if (routeSegment === "admin" || routeSegment.startsWith("admin/")) {
      if (mod.layout && !mod._standardDemo) return mod.layout;
      if (adminArchetype) return adminArchetype.type;
      console.warn(`[scaffold] No admin archetype for route "${routeSegment}" — defaulting to config-form-single`);
      return "config-form-single";
    }
    if (mod.layout) return mod.layout;
    // Standard-menu map (section + menuItem) — wins over feature-mix inference for non-admin routes.
    const fromMenu = layoutFromStandardMenu(mod);
    if (fromMenu) return fromMenu;
    const ids = mod.features.map((f) => f.id);
    if (ids.some((id) => SELF_HEADERED_FEATURES.has(id))) return "overview-content";
    if (ids.some((id) => FULL_BLEED_FEATURES.has(id))) return "canvas-bare";
    if (ids.includes("APP.F21")) return "overview-grid";
    if (ids.includes("APP.F19")) return "lve-split";
    if (ids.length > 0 && ids.every((id) => id.startsWith("ANL."))) return "analytics-dashboard";
    if (ids.includes("APP.F10")) return "collection-grid";
    if (ids.includes("APP.F07")) return "form-guided";
    return "object-page-detail";
  }
  const layoutType = chooseLayout();
  // collection-board + APP.F04 Kanban: whether this module configures the real,
  // PS.WORKFLOW-backed Kanban board feature (mounted as CollectionBoardLayout
  // children, no page-level search — the board owns its own toolbar; see the
  // "collection-board" mainInner branch below) vs. the generic column-wrap
  // fallback. Declared here (not nearer its one remaining use below) because
  // featureJsx() — which runs before that point — needs it too.
  const hasKanbanSearch = layoutType === "collection-board" && mod.features.some((f) => f.id === "APP.F04");
  // Task detail drawer (APP.F04 Kanban card click → WorkflowStatusSummary +
  // stage pipeline + progress history — design-audit-2026-07-17 P1c item 1).
  const kanbanFeat = hasKanbanSearch ? mod.features.find((f) => f.id === "APP.F04") : null;
  const taskDrawerHook = kanbanFeat
    ? `
  const [selectedTaskId, setSelectedTaskId] = React.useState<string | null>(null);
`
    : "";
  const taskWorkflowConfigLiteral = kanbanFeat
    ? `{ definitionIds: ${JSON.stringify([kanbanFeat.config?.definitionId])}, entityType: "task" }`
    : "";
  const taskDrawerJsx = kanbanFeat
    ? `\n      <Sheet open={selectedTaskId !== null} onOpenChange={(open) => !open && setSelectedTaskId(null)}>\n` +
      `        <SheetContent side="right" className="w-full sm:max-w-lg overflow-y-auto">\n` +
      `          <SheetHeader>\n            <SheetTitle>Task detail</SheetTitle>\n          </SheetHeader>\n` +
      `          {selectedTaskId && (\n` +
      `            <div className="mt-4 flex flex-col gap-4">\n` +
      `              <TaskWorkflowStatus taskId={selectedTaskId} />\n` +
      `              <RecordWorkflowStepper recordId={selectedTaskId} config={${taskWorkflowConfigLiteral}} />\n` +
      `              <RecordWorkflowActions recordId={selectedTaskId} config={${taskWorkflowConfigLiteral}} />\n` +
      `              <RecordProgressHistory recordId={selectedTaskId} config={${taskWorkflowConfigLiteral}} />\n` +
      `            </div>\n` +
      `          )}\n` +
      `        </SheetContent>\n` +
      `      </Sheet>`
    : "";
  const taskWorkflowStatusHelper = kanbanFeat
    ? `\nfunction TaskWorkflowStatus({ taskId }: { taskId: string }) {\n` +
      `  const wf = useRecordWorkflow(taskId, ${taskWorkflowConfigLiteral});\n` +
      `  if (!wf.instance) return null;\n` +
      `  return <WorkflowStatusSummary instance={wf.instance} variant="drawer" />;\n` +
      `}\n`
    : "";
  // Layouts accept a header slot — pages pass <PageHeader ... /> via it.
  // Keys are the canonical LAYOUT_IDS (page-vocabulary.ts). An id declarable
  // via LAYOUT_IDS but absent here is a documented GAP (page-vocabulary.test.ts
  // ratchets the exact list) — guarded below rather than silently falling back.
  const LAYOUT_COMPONENT = {
    "object-page-detail":            "CanvasLayout",
    "analytics-dashboard":           "AnalyticsLayout",
    "collection-grid":               "CatalogueLayout",
    "collection-marketplace-grid":   "CatalogueLayout",
    "collection-marketplace-detail": "CanvasLayout",       // CanvasLayout + MarketplaceItemDetail composition
    "overview-content":              "ContentLandingLayout",
    "config-form-custom":            "SettingsLayout",      // legacy / explicit mod.layout override
    "config-form-single":            "SettingsLayout",      // admin archetype alias
    "config-form-tabs":              "ConfigTabsLayout",
    "collection-table":              "CanvasLayout",         // CanvasLayout + EntityList slot
    "lve-split":                     "CanvasLayout",         // CanvasLayout + APP.F19 LveWorkspace, externalHeader
    "collection-board":              "CollectionBoardLayout",
    "form-basic":                    "FormBasicLayout",
    "form-guided":                   "FormGuidedLayout",
    "canvas-workspace":              "BuilderLayout",        // admin builder EntityList archetype
    "overview-grid":                 "OverviewGridLayout",
  };
  const layoutComponentName = LAYOUT_COMPONENT[layoutType]; // undefined for "canvas-bare"
  if (layoutComponentName === undefined && layoutType !== "canvas-bare") {
    die(
      `Module ${mod.id}: layout "${layoutType}" is declared in the canonical vocabulary ` +
        `(page-vocabulary.ts LAYOUT_IDS) but not yet implemented by the generator — ` +
        `implemented layouts: ${Object.keys(LAYOUT_COMPONENT).join(", ")}.`,
    );
  }
  // Build slot JSX — wrap the primary slot's features in the chosen layout.
  const slotEntries = [];
  // Set true by any archetype branch below that emits a content-body toolbar
  // row (div.flex justify-end gap-2 mb-4 + Button) in place of the removed
  // PageHeader `action` CTA — drives the Button import below.
  let usesBodyToolbar = false;
  for (const [slot, feats] of bySlot) {
    const featsJsx = feats.map(featureJsx).join("\n");
    // Multi-feature content stacks vertically with a consistent gap.
    const featsBlock =
      feats.length > 1
        ? `        <div className="flex flex-col gap-6">\n${featsJsx}\n        </div>`
        : featsJsx;

    if (slot !== PRIMARY_SLOT_FOR_HEADER) {
      // Secondary slots (e.g. context) render raw — no layout chrome.
      slotEntries.push(`    ${slot}: (\n      <>\n${featsJsx}\n      </>\n    )`);
      continue;
    }

    let mainInner;
    if (ADMIN_DEFERRED_ROUTES.has(routeSegment)) {
      // Ruled-deferred capability / blocked-on-missing-API admin leaf — honest
      // "Coming soon" body, not a fake demo-record binding (see ADMIN_ARCHETYPE_MAP
      // comment above).
      mainInner =
        `      <CanvasLayout>\n` +
        `        <div className="flex flex-col items-center justify-center py-24 text-center px-6">\n` +
        `          <p className="text-xs font-mono tracking-widest uppercase text-[var(--color-text-muted)] mb-4">Deferred capability</p>\n` +
        `          <h2 className="text-lg font-semibold mb-2 text-[var(--color-text)]">Coming soon</h2>\n` +
        `          <p className="text-sm text-[var(--color-text-secondary)] max-w-sm">This capability is not yet available in this environment.</p>\n` +
        `        </div>\n` +
        `      </CanvasLayout>`;
    } else if (ADMIN_RBAC_COMPONENT[routeSegment]) {
      // Users & Access leaves bound to real platform-service data — PS.RBAC
      // /matrix (roles + permission matrix) and, for admin/users, the PS.AUTH
      // demo-identity source + PS.RBAC admin role-assignment hooks. See
      // admin-user-list.tsx / admin-role-list.tsx / admin-access-matrix.tsx in @dbp/ui.
      const compName = ADMIN_RBAC_COMPONENT[routeSegment];
      const compJsx = compName === "AdminUserList"
        ? `<AdminUserList users={DEMO_IDENTITIES.map((entry) => entry.user)} />`
        : `<${compName} />`;
      mainInner =
        `      <CanvasLayout>\n` +
        `        ${compJsx}\n` +
        `      </CanvasLayout>`;
    } else if (layoutType === "canvas-bare") {
      // Self-contained, full-bleed feature owns its own header/scroll.
      // Negate the shell gutter so the feature runs edge-to-edge.
      mainInner = `      <div className="-m-[var(--shell-gutter)] flex h-full flex-col">\n${featsJsx}\n      </div>`;
    } else if (layoutType === "overview-content") {
      mainInner = `      <ContentLandingLayout>\n${featsBlock}\n      </ContentLandingLayout>`;
    } else if (layoutType === "config-form-custom") {
      // Type 7 Settings layout — nav rail of sibling admin links + content area.
      // SettingsNav (@dbp/ui) instead of an inline <nav>: GATE.06 forbids raw
      // chrome elements / design-class internals inside emitted pages.
      const settingsNavJsx = `{<SettingsNav links={${JSON.stringify(adminSiblingRoutes.map((r) => ({ href: r.href, label: r.label })))}} />}`;
      mainInner =
        `      <SettingsLayout\n` +
        `        nav=${settingsNavJsx}\n` +
        `      >\n${featsBlock}\n      </SettingsLayout>`;
    } else if (layoutType === "collection-table") {
      // Admin list archetype — CanvasLayout; "New record" CTA moves into a
      // content-body toolbar (Amendment D-2 (component-architecture-standard.md §7b) — no page-level PageHeader).
      usesBodyToolbar = true;
      const toolbarJsx = `        <div className="flex justify-end gap-2 mb-4">\n          <Button variant="navy" onClick={() => {}}>New record</Button>\n        </div>\n`;
      mainInner =
        `      <CanvasLayout>\n` +
        toolbarJsx +
        `${featsBlock}\n      </CanvasLayout>`;
    } else if (layoutType === "collection-board") {
      // CollectionBoardLayout takes either `columns` (structured per-column data)
      // or `children` (a self-contained board feature). When the module configures
      // APP.F04 Kanban — the real, PS.WORKFLOW-backed board feature — mount it in
      // children mode with NO page-level `filters` toolbar: the real Kanban board
      // owns its own search + filter-chip toolbar (KanbanToolbar), so a second,
      // page-level search box would just duplicate it (SINGLE SEARCH fix,
      // 2026-07-11 — the live review found "Search cards…" at the page level AND
      // "Search cases…" in the board, plus an "8 of 8 cases" count on a Tasks
      // board). Page copy (title) still comes from the module label, e.g.
      // "Tasks", never a hardcoded noun. Otherwise (no Kanban-shaped feature
      // configured), fall back to wrapping whatever features ARE configured into
      // a single default column — a functional, non-crashing fallback, not a
      // real board.
      mainInner = hasKanbanSearch
        ? `      <>\n      <CollectionBoardLayout>\n${featsBlock}\n      </CollectionBoardLayout>${taskDrawerJsx}\n      </>`
        : `      <CollectionBoardLayout\n` +
          `        columns={[{ id: "all", title: ${JSON.stringify(mod.name)}, children: (\n${featsBlock}\n        ) }]}\n` +
          `      />`;
    } else if (layoutType === "form-basic") {
      // FormBasicLayout takes a `sections: FormBasicSection[]` prop, not `children` —
      // it cannot use the generic header+children emission below. APP.F24 RecordForm
      // (record-form-spec-2026-07-12.md) owns its own header/validation-summary/footer
      // chrome (single-header-features-body-only), so a module wiring APP.F24 renders
      // it self-headered directly rather than being wrapped in FormBasicLayout's
      // synthetic single-section shell — that fallback remains for any other feature
      // mix mounted on this layout (no dedicated fields/sections-from-config feature
      // exists for those).
      if (mod.features.some((f) => f.id === "APP.F24")) {
        mainInner = `      <div className="mx-auto flex w-full max-w-3xl flex-col gap-6">\n${featsBlock}\n      </div>`;
      } else {
        // "Submit" CTA moves into a content-body toolbar (Amendment D-2 (component-architecture-standard.md §7b) — no
        // page-level PageHeader).
        usesBodyToolbar = true;
        mainInner =
          `      <div className="flex flex-col gap-4">\n` +
          `        <div className="flex justify-end gap-2">\n          <Button variant="navy" onClick={() => {}}>Submit</Button>\n        </div>\n` +
          `        <FormBasicLayout\n` +
          `          sections={[{ id: "default", title: ${JSON.stringify(mod.name)}, fields: [{ id: "body", span: 12, content: (\n${featsBlock}\n          ) }] }]}\n` +
          `        />\n` +
          `      </div>`;
      }
    } else if (layoutType === "form-guided") {
      // APP.F27 (multi-step-form) owns genuine step-navigation CLIENT STATE
      // (step transitions, per-step validation, conditional steps, review) —
      // when a module configures it, mount it directly, full-page, with no
      // FormGuidedLayout wrapper (the organism is full-page-only by spec
      // decision — no drawer/modal placement — and renders its own step-nav
      // chrome, so wrapping it in another step shell would double it up).
      const hasWizard = feats.some((f) => f.id === "APP.F27");
      if (hasWizard) {
        mainInner = `      <div className="flex flex-col gap-6">\n${featsBlock}\n      </div>`;
      } else {
        // No guided-form feature configured — configured features render as a
        // single, non-navigable step, a functional, non-crashing fallback.
        // "Save draft" CTA moves into a content-body toolbar (Amendment D-2 (component-architecture-standard.md §7b)
        // — no page-level PageHeader).
        usesBodyToolbar = true;
        mainInner =
          `      <FormGuidedLayout\n` +
          `        steps={[{ id: "default", label: ${JSON.stringify(mod.name)}, title: ${JSON.stringify(mod.name)} }]}\n` +
          `        currentStep={0}\n` +
          `        onContinue={() => {}}\n` +
          `      >\n` +
          `        <div className="flex justify-end gap-2 mb-4">\n          <Button variant="navy" onClick={() => {}}>Save draft</Button>\n        </div>\n` +
          `${featsBlock}\n      </FormGuidedLayout>`;
      }
    } else if (layoutType === "config-form-single") {
      // Admin config-single archetype — SettingsLayout with real form body.
      // "Save changes" CTA moves into a content-body toolbar (Amendment D-2 (component-architecture-standard.md §7b)
      // — no page-level PageHeader). SettingsNav (@dbp/ui) instead of an
      // inline <nav> — see config-form-custom note above.
      const settingsNavJsx = `{<SettingsNav links={${JSON.stringify(adminSiblingRoutes.map((r) => ({ href: r.href, label: r.label })))}} />}`;
      const formSpec = ADMIN_FORM_SPECS[routeSegment];
      const formId = formSpec?.formId ?? "admin-settings";
      const sections = formSpec?.sections ?? [
        { title: "General", fields: [{ name: "name", label: "Name", fieldType: "text" }, { name: "enabled", label: "Enabled", fieldType: "switch", defaultChecked: true }] },
      ];
      // AdminSettingsFormField is 1:1 with ADMIN_FORM_SPECS field shape — serialize directly.
      const sectionsLiteral = JSON.stringify(sections, null, 8);
      usesBodyToolbar = true;
      mainInner =
        `      <SettingsLayout\n` +
        `        nav=${settingsNavJsx}\n` +
        `      >\n` +
        `        <div className="flex justify-end gap-2 mb-4">\n          <Button variant="navy" onClick={() => (document.getElementById(${JSON.stringify(formId)}) as HTMLFormElement | null)?.requestSubmit()}>Save changes</Button>\n        </div>\n` +
        `        <AdminSettingsForm formId=${JSON.stringify(formId)} sections={${sectionsLiteral} as AdminSettingsFormSection[]} />\n` +
        `      </SettingsLayout>`;
    } else if (layoutType === "config-form-tabs") {
      // Admin config-tabs archetype — ConfigTabsLayout (no page-level PageHeader,
      // Amendment D-2 (component-architecture-standard.md §7b); per-tab Save buttons are owned by the layout itself).
      const formSpec = ADMIN_FORM_SPECS[routeSegment];
      const tabDefs = formSpec?.type === "config-form-tabs"
        ? formSpec.tabs
        : (adminArchetype?.tabs ?? ["General"]).map((tabLabel) => {
            const tabId = tabLabel.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
            const tabFormId = `${routeSegment.replace(/\//g, "-")}-${tabId}`;
            return { id: tabId, label: tabLabel, formId: tabFormId, fields: [{ name: "setting", label: "Setting", fieldType: "text" }] };
          });
      const tabsJsx = tabDefs.map((tab) => {
        const tabId = tab.id;
        const tabFormId = tab.formId ?? `${routeSegment.replace(/\//g, "-")}-${tabId}`;
        const tabLabel = tab.label;
        const fields = tab.fields ?? [{ name: "setting", label: "Setting", fieldType: "text" }];
        // AdminSettingsFormField is 1:1 with ADMIN_FORM_SPECS field shape — serialize directly.
        // AdminSettingsForm renders its own <form id={formId}> — ConfigTabsLayout's Save button
        // already submits it via the HTML `form` attribute (see config-tabs.tsx), so no wrapper needed.
        const fieldsLiteral = JSON.stringify(fields, null, 10);
        return (
          `        {\n` +
          `          id: ${JSON.stringify(tabId)},\n` +
          `          label: ${JSON.stringify(tabLabel)},\n` +
          `          formId: ${JSON.stringify(tabFormId)},\n` +
          `          saveLabel: "Save changes",\n` +
          `          content: (\n` +
          `            <AdminSettingsForm formId=${JSON.stringify(tabFormId)} fields={${fieldsLiteral} as AdminSettingsFormField[]} />\n` +
          `          ),\n` +
          `        }`
        );
      }).join(",\n");
      const firstTabId = tabDefs[0].id;
      mainInner =
        `      <ConfigTabsLayout\n` +
        `        defaultTab=${JSON.stringify(firstTabId)}\n` +
        `        tabs={[\n${tabsJsx}\n        ]}\n` +
        `      />`;
    } else if (layoutType === "canvas-workspace") {
      // Admin builder archetype — list-first pattern (ADR-0035): CanvasLayout + EntityList → [id] detail.
      // Prefix with "admin-" but strip a leading "admin/" first so admin routes
      // don't double up (was "admin-admin-form-builder-list"; folded from a prior
      // hand-fix, 2026-07-09).
      const routeKey = `admin-${routeSegment.replace(/^admin\//, "").replace(/\//g, "-")}`;
      // "New <record>" CTA moves into a content-body toolbar (Amendment D-2 (component-architecture-standard.md §7b)
      // — no page-level PageHeader).
      usesBodyToolbar = true;
      const newLabel = `New ${mod.name.replace(/s$/, "")}`;
      mainInner =
        `      <CanvasLayout>\n` +
        `        <div className="flex justify-end gap-2 mb-4">\n          <Button variant="navy" onClick={() => {}}>${newLabel}</Button>\n        </div>\n` +
        `        <EntityList\n` +
        `          key="${routeKey}-list"\n` +
        `          {...({\n` +
        `            entityType: "demo-record",\n` +
        `            columns: [\n` +
        `              { field: "name", label: "Name", sortable: true },\n` +
        `              { field: "status", label: "Status", sortable: true, format: "badge", badgeTones: { active: "success", invited: "info", disabled: "gray", suspended: "warning" } },\n` +
        `              { field: "owner", label: "Owner", sortable: true },\n` +
        `              { field: "updated", label: "Last Modified", sortable: true, format: "date" },\n` +
        `            ],\n` +
        `            pageSize: 20,\n` +
        `            enableSearch: true,\n` +
        `            listTabs: [\n` +
        `              { key: "all", label: "All", where: [] },\n` +
        `              { key: "open", label: "Open", where: [{ field: "status", op: "is", value: "active" }] },\n` +
        `              { key: "in-progress", label: "In Progress", where: [{ field: "status", op: "is", value: "invited" }] },\n` +
        `              { key: "review", label: "Review", where: [{ field: "status", op: "is", value: "disabled" }] },\n` +
        `              { key: "done", label: "Done", where: [{ field: "status", op: "is", value: "suspended" }] },\n` +
        `            ],\n` +
        `            detailHref: "/${routeSegment}",\n` +
        `            detailDrawer: false,\n` +
        `          } as Parameters<typeof EntityList>[0])}\n` +
        `        />\n` +
        `      </CanvasLayout>`;
    } else if (layoutType === "overview-grid") {
      // OverviewGridLayout — WorkspaceDashboard (APP.F21) renders body-only (no
      // internal greeting header, per its own header-ownership design); its
      // config.actions (Ask AI / New Task / ...) move into a content-body
      // toolbar (Amendment D-2 (component-architecture-standard.md §7b) — no page-level PageHeader) via
      // WorkspaceDashboardActions, reused unchanged as the toolbar's actions.
      const f21 = mod.features.find((f) => f.id === "APP.F21");
      const toolbarExpr = f21
        ? `        <div className="flex justify-end gap-2 mb-4">\n          <WorkspaceDashboardActions actions={${JSON.stringify(f21.config?.actions ?? [], null, 8)}} />\n        </div>\n`
        : "";
      mainInner =
        `      <OverviewGridLayout>\n` +
        toolbarExpr +
        `${featsBlock}\n      </OverviewGridLayout>`;
    } else {
      // working / analytics / catalogue — no page-level PageHeader (Amendment
      // D-2, component-architecture-standard.md §7b); the top bar's
      // breadcrumb terminal crumb is now the page title.
      // LVE pages (APP.F19) previously showed a compact breadcrumb-only bar in
      // split/detail mode (lve-compact-breadcrumb-detail-mode); superseded by
      // Shell v3.1 (N29) — the top-bar breadcrumb (AppChrome, always rendered)
      // is now the ONLY breadcrumb, so no in-content breadcrumb is emitted here.
      const hasLve = mod.features.some((f) => f.id === "APP.F19");
      const headerExpr = "";
      mainInner =
        `      <${layoutComponentName}\n` +
        (headerExpr ? `        header=${headerExpr}\n` : ``) +
        (hasLve ? `        fullBleed\n` : ``) +
        `      >\n${featsBlock}\n      </${layoutComponentName}>`;
    }
    slotEntries.push(`    ${slot}: (\n${mainInner}\n    )`);
  }

  // Determine which layout components need importing (may differ from layoutComponentName
  // when config-tabs/builder use a component not equal to layoutComponentName).
  // The builder archetype emits a CanvasLayout list page; BuilderLayout is reserved for the
  // [id] detail page, which is not yet emitted by the generator.
  //
  // form-basic (APP.F24 self-headered) and form-guided (APP.F27 full-page-only) each
  // have a fallback branch above that renders FormBasicLayout/FormGuidedLayout, but
  // when the archetype-owning feature is actually mounted they render body-only into
  // a plain <div> instead (see the form-basic/form-guided branches above) — importing
  // the layout component in that case leaves it unused.
  const formBasicSelfHeadered = layoutType === "form-basic" && mod.features.some((f) => f.id === "APP.F24");
  const formGuidedSelfHeadered = layoutType === "form-guided" && mod.features.some((f) => f.id === "APP.F27");
  const layoutImportName =
    layoutType === "canvas-workspace"
      ? "CanvasLayout"
      : formBasicSelfHeadered || formGuidedSelfHeadered
      ? undefined
      : layoutComponentName;
  const importLines2 = [
    // React namespace import only when the master-detail hook needs useState/useEffect.
    ...(masterDetail ? [`import * as React from "react";`] : []),
    // useRouter only when a catalog card navigates to its detail route.
    ...(hasCatalogueCard ? [`import { useRouter } from "next/navigation";`] : []),
    `import ${shellMeta.name} from "${shellMeta.importFrom}";`,
    // Page layout wrapper (Phase 6) — "canvas-bare" pages import nothing.
    // No page-level PageHeader import (Amendment D-2 (component-architecture-standard.md §7b)) — the top bar's
    // breadcrumb terminal crumb is now the page title.
    ...(layoutImportName
      ? [`import { ${layoutImportName} } from "${shellMeta.importFrom}/layouts";`]
      : []),
    // Content-body toolbar — replaces the removed PageHeader `action` CTA for
    // the archetypes that had one (Amendment D-2 (component-architecture-standard.md §7b)).
    ...(usesBodyToolbar ? [`import { Button } from "@dbp/ui";`] : []),
    // Admin form archetypes — real RHF+Zod form component (config-single + config-tabs).
    ...(layoutType === "config-form-single"
      ? [`import { AdminSettingsForm } from "@dbp/ui";`, `import type { AdminSettingsFormSection } from "@dbp/ui";`]
      : layoutType === "config-form-tabs"
      ? [`import { AdminSettingsForm } from "@dbp/ui";`, `import type { AdminSettingsFormField } from "@dbp/ui";`]
      : []),
    // Settings-rail nav component (GATE.06 — no raw <nav> in emitted pages).
    ...(layoutType === "config-form-single" || layoutType === "config-form-custom"
      ? [`import { SettingsNav } from "@dbp/ui";`]
      : []),
    // Legacy top-bar Breadcrumb — only when the module nav declares one (no-chrome path).
    ...(navInfo?.needsBreadcrumb ? [`import { Breadcrumb } from "@dbp/ui";`] : []),
    // Connected chrome (enriched top bar) — imported when PS.AUTH is wired so the
    // module page mounts the session + capability driven bar via nav.topBar.
    ...(navInfo?.needsChrome
      ? [
          `import { SolutionChrome } from "${"../".repeat(routeSegment.split("/").length)}solution-chrome";`,
          `import { SolutionFooter } from "${"../".repeat(routeSegment.split("/").length)}solution-footer";`,
        ]
      : []),
    ...[...featureImports.values()]
      .filter(Boolean)
      .map((f) => `import ${f.name} from "${f.importFrom}";`),
    // WorkspaceDashboardActions — sidebar action pills rendered in the layout's aside slot.
    ...(mod.features.some((f) => f.id === "APP.F21")
      ? [`import { WorkspaceDashboardActions } from "@dbp/organisms/workspace-dashboard";`]
      : []),
    // PS-WORKFLOW-UI §5b: workflow-bound stepper wiring (Pattern A/B) — see featureJsx().
    // Only emitted for layouts that actually render featsBlock/featsJsx — the
    // config-single/config-tabs/builder archetypes build their own hardcoded
    // form/list JSX and never reference these components even when the flag
    // is set (featureJsx() runs unconditionally to compute featsJsx, which
    // those archetypes then discard).
    ...(usesWorkflowBinding && !["config-form-single", "config-form-tabs", "canvas-workspace"].includes(layoutType)
      ? [
          `import { RecordProgressHistory, RecordWorkflowActions, RecordWorkflowStepper } from "@dbp/organisms/workflow-binding";`,
        ]
      : []),
    // Demo-record LVE stub — shared config helper (unbuilt page marker).
    ...(usesDemoLveConfig
      ? [`import { buildDemoLveConfig } from "${"../".repeat(2 + routeSegment.split("/").length)}lib/demo-lve-config";`]
      : []),
  ].join("\n");

  // LVE view-mode tracking hook — historically hid the in-content breadcrumb
  // bar in list mode (superseded by Shell v3.1 / N29: no in-content breadcrumb
  // is emitted at all now, see the main-slot `else` branch above). The state
  // is kept (underscore-prefixed) only to feed the still-useful
  // `callbacks.onViewChange` wiring on `<LveWorkspace>` — nothing reads it.
  // (LVE_TERNARY_LAYOUTS itself is declared once, above featureJsx() — see DEF-6 note there.)
  const hasLveFeature = mod.features.some((f) => f.id === "APP.F19") && !LVE_TERNARY_LAYOUTS.has(layoutType);
  const lveHook = hasLveFeature
    ? `
  // Track LVE view mode — feeds callbacks.onViewChange on <LveWorkspace> (ADR-0040).
  const [, setLveListMode] = React.useState(true);
`
    : "";

  // NOTE: collection-board + APP.F04 Kanban used to declare page-level
  // client-side search state here, wired into a page-level CollectionToolbar
  // AND Kanban's searchQuery prop — removed 2026-07-11 (SINGLE SEARCH fix):
  // the board owns its own search box, so a page-level one only duplicated
  // it. hasKanbanSearch (declared earlier, right after layoutType) now only
  // decides the CollectionBoardLayout mount mode (children vs column-wrap).

  // Master-detail state + listener block (only when both halves are present).
  const masterDetailHook = masterDetail
    ? `
  // Master-detail: EntityList (queue) dispatches \`dbp:entity-list:row-select\`;
  // we hold the picked id and feed it to EntityDetail (replacing "placeholder").
  // Until a row is selected, EntityDetail shows a "Select a record" empty state.
  const [selectedId, setSelectedId] = React.useState("");
  React.useEffect(() => {
    function onRowSelect(e: Event) {
      const detail = (e as CustomEvent<{ entityType: string; id: string }>).detail;
      if (detail?.entityType === ${JSON.stringify(masterDetail.entityType)} && typeof detail.id === "string") {
        setSelectedId(detail.id);
      }
    }
    document.addEventListener("dbp:entity-list:row-select", onRowSelect);
    return () => document.removeEventListener("dbp:entity-list:row-select", onRowSelect);
  }, []);
`
    : "";

  // Nav constant declaration (blank-line delimited) + shell nav={…} prop —
  // both emitted only when the module declares a nav block.
  const navBlock = navInfo ? `\n${navInfo.constDecl}\n` : "";
  const navAttrLine = navInfo ? `      nav={${navConstName}}\n` : "";

  // Router hook — declared when a catalog card needs to navigate to its detail.
  const routerHook = hasCatalogueCard ? `\n  const router = useRouter();` : "";

  // ── Route-group path (ADR-0026) ─────────────────────────────────────────────
  // SH.WORKSPACE modules go under app/(authenticated)/ so they inherit the
  // TransactionShell from the route-group layout.tsx (mounted once, not per-page).
  // SH.PUBLIC modules go under app/(public)/ (passthrough layout).
  const routeGroupPrefix = isWorkspace ? "(authenticated)" : "(public)";

  // Strip the TransactionShell wrapper from workspace module pages — the shell is
  // now provided once by app/(authenticated)/layout.tsx. Public pages keep their
  // own shell (LandingShell) since they are outside the (authenticated) group.
  let pageContent;
  if (isWorkspace) {
    // Body-only: render the slot contents directly (no shell wrapper).
    // The (authenticated)/layout.tsx provides TransactionShell + nav.
    // We strip the shell import, nav constant, and shell JSX entirely.
    // Build the imports without shell + nav-related items.
    const bodyImportLines = [
      ...((masterDetail || hasLveFeature || kanbanFeat) ? [`import * as React from "react";`] : []),
      ...(hasCatalogueCard ? [`import { useRouter } from "next/navigation";`] : []),
      ...(kanbanFeat
        ? [`import { Sheet, SheetContent, SheetHeader, SheetTitle, WorkflowStatusSummary } from "@dbp/ui";`]
        : []),
      // Page layout wrapper — header-bearing layouts still needed.
      // Use layoutImportName (not layoutComponentName) so the builder archetype's list page
      // imports CanvasLayout (what the JSX uses) rather than BuilderLayout.
      // No PageHeader import here (Amendment D-2 (component-architecture-standard.md §7b)) — the top bar's breadcrumb
      // terminal crumb is now the page title; body-only pages never render one.
      ...(layoutImportName
        ? [`import { ${layoutImportName} } from "@dbp/shell-transaction/layouts";`]
        : []),
      // Content-body toolbar — replaces the removed PageHeader `action` CTA
      // (Amendment D-2, component-architecture-standard.md §7b). The legacy
      // full-shell import list (importLines2) has always carried this; the
      // body-only path did not, so every archetype emitting a toolbar <Button>
      // produced a page referencing an unimported identifier.
      ...(usesBodyToolbar ? [`import { Button } from "@dbp/ui";`] : []),
      // Admin form archetypes — real RHF+Zod form component (config-single + config-tabs).
      ...(layoutType === "config-form-single"
        ? [`import { AdminSettingsForm } from "@dbp/ui";`, `import type { AdminSettingsFormSection } from "@dbp/ui";`]
        : layoutType === "config-form-tabs"
        ? [`import { AdminSettingsForm } from "@dbp/ui";`, `import type { AdminSettingsFormField } from "@dbp/ui";`]
        : []),
      // Settings-rail nav component (GATE.06 — no raw <nav> in emitted pages).
      ...(layoutType === "config-form-single" || layoutType === "config-form-custom"
        ? [`import { SettingsNav } from "@dbp/ui";`]
        : []),
      // Users & Access leaves bound to real PS.RBAC data — see ADMIN_RBAC_COMPONENT.
      // AdminAccessMatrix/AdminRoleList/AdminUserList are @dbp/organisms (promoted
      // 2026-07-21, Bindings/Admin resolution — they own PS.RBAC/PS.AUTH fetch state);
      // AdminAuditLog is still a @dbp/ui presentation component.
      ...(ADMIN_RBAC_COMPONENT[routeSegment]
        ? [
            ADMIN_RBAC_ORGANISM_SLUG[ADMIN_RBAC_COMPONENT[routeSegment]]
              ? `import { ${ADMIN_RBAC_COMPONENT[routeSegment]} } from "@dbp/organisms/${ADMIN_RBAC_ORGANISM_SLUG[ADMIN_RBAC_COMPONENT[routeSegment]]}";`
              : `import { ${ADMIN_RBAC_COMPONENT[routeSegment]} } from "@dbp/ui";`,
          ]
        : []),
      // admin/users renders the PS.AUTH identity source (same fixture the auth route seeds).
      ...(ADMIN_RBAC_COMPONENT[routeSegment] === "AdminUserList"
        ? [`import { DEMO_IDENTITIES } from "${"../".repeat(2 + routeSegment.split("/").length)}solution/fixtures/demo-identities";`]
        : []),
      ...(navInfo?.needsBreadcrumb ? [`import { Breadcrumb } from "@dbp/ui";`] : []),
      // Suppress feature imports for admin archetypes that don't render featsBlock.
      ...(layoutType === "config-form-single" || layoutType === "config-form-tabs" || ADMIN_DEFERRED_ROUTES.has(routeSegment) || ADMIN_RBAC_COMPONENT[routeSegment]
        ? []
        : [...featureImports.values()]
            .filter(Boolean)
            .map((f) => `import ${f.name} from "${f.importFrom}";`)),
      // Guard: only add EntityList for builder archetype if not already emitted via featureImports.
      ...(layoutType === "canvas-workspace" && !featureImports.has("APP.F01")
        ? [`import EntityList from "@dbp/organisms/entity-list";`]
        : []),
      // WorkspaceDashboardActions — sidebar action pills rendered in the layout's aside slot.
      ...(mod.features.some((f) => f.id === "APP.F21")
        ? [`import { WorkspaceDashboardActions } from "@dbp/organisms/workspace-dashboard";`]
        : []),
      // PS-WORKFLOW-UI §5b: workflow-bound stepper wiring (Pattern A/B) — see featureJsx().
      // See body-import-1 comment above: gate out archetypes that discard featsBlock.
      ...(usesWorkflowBinding && !["config-form-single", "config-form-tabs", "canvas-workspace"].includes(layoutType)
        ? [
            `import { RecordProgressHistory, RecordWorkflowActions, RecordWorkflowStepper${kanbanFeat ? ", useRecordWorkflow" : ""} } from "@dbp/organisms/workflow-binding";`,
          ]
        : []),
    ].join("\n");

    // Build the page body: the main slot content rendered directly as the return value.
    // For workspace pages the (authenticated)/layout provides the shell;
    // pages are body-only — they return their content JSX directly.
    // slotEntries format: "    main: (\n<mainInner>\n    )"
    // We extract the inner JSX and wrap it in return (...).
    const mainSlotEntry = slotEntries.find((e) => e.trim().startsWith("main:"));
    let mainBody = "";
    if (mainSlotEntry) {
      const innerMatch = mainSlotEntry.match(/^\s*main:\s*\(\n([\s\S]*)\n\s*\)\s*$/);
      const innerJsx = innerMatch ? innerMatch[1] : "    <></>";
      mainBody = `  return (\n${innerJsx}\n  );`;
    } else if (slotEntries.length > 0) {
      // Fallback: wrap all slot content in a fragment
      const allJsx = slotEntries.map((e) => {
        const m = e.match(/^\s*\w+:\s*\(\n([\s\S]*)\n\s*\)\s*$/);
        return m ? m[1] : `    <></>`;
      }).join("\n");
      mainBody = `  return (\n    <>\n${allJsx}\n    </>\n  );`;
    } else {
      mainBody = `  return null;`;
    }

    pageContent = `"use client";
// Module: ${mod.id} — ${mod.name}
// Shell: ${mod.scaffold}  Journey stage: ${mod.journey}
// Layout: ${layoutType}
// Body-only page — TransactionShell provided by app/(authenticated)/layout.tsx
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
${bodyImportLines}

export default function ${mod.name.replace(/[^a-zA-Z0-9]/g, "")}Page() {${lveHook}${masterDetailHook}${routerHook}${taskDrawerHook}
${mainBody}
}
${taskWorkflowStatusHelper}`;
  } else {
    // Public pages (SH.PUBLIC / LandingShell) keep the full shell wrapper.
    pageContent = `"use client";
// Module: ${mod.id} — ${mod.name}
// Shell: ${mod.scaffold}  Journey stage: ${mod.journey}
// Layout: ${layoutType}
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
${importLines2}
${navBlock}
export default function ${mod.name.replace(/[^a-zA-Z0-9]/g, "")}Page() {${masterDetailHook}${routerHook}
  return (
    <${shellMeta.name}
${navAttrLine}      slots={{
${slotEntries.join(",\n")}
      }}
    />
  );
}
`;
  }

  writeFile(
    `app/${routeGroupPrefix}/${routeSegment}/page.tsx`,
    pageContent,
  );

  // A wired catalog card must land on a real detail page — emit the co-located
  // [id] route mounting MarketplaceItemDetail for this module's catalogue entity.
  if (hasCatalogueCard) emitCatalogueDetailRoute(mod, routeSegment, catalogueFeat);

  // canvas-workspace (admin builder archetype): the list page's EntityList rows link
  // to `${detailHref}/${id}` — emit that co-located [id] route so the link resolves
  // to a real page instead of a 404. See emitBuilderDetailRoute below.
  if (layoutType === "canvas-workspace") emitBuilderDetailRoute(mod, routeSegment);
}

/**
 * canvas-workspace [id] detail route — mounts APP.F02 EntityDetail (real PS.DATA
 * fetch, sectioned field grid, PS.AUDIT activity tab) inside BuilderLayout. Read-only:
 * EntityDetail has no edit/update capability today, so BuilderLayout's optional
 * saveFormId/Publish button is deliberately left unset rather than wired to a fake
 * no-op — an honest read-only detail view, not a fabricated "Save" button with
 * nothing behind it. The list page always uses the hardcoded "demo-record" entity
 * type (see the canvas-workspace mainInner branch above), so this route does too.
 */
function emitBuilderDetailRoute(mod, routeSegment) {
  const compName = `${mod.name.replace(/[^a-zA-Z0-9]/g, "")}DetailPage`;
  writeFile(
    `app/(authenticated)/${routeSegment}/[id]/page.tsx`,
    `"use client";
// Admin builder detail — ${mod.id} (${mod.name}).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { useParams } from "next/navigation";
import { BuilderLayout } from "@dbp/shell-transaction/layouts";
import EntityDetail from "@dbp/organisms/entity-detail";

// Single-header rule (ADR-0034): EntityDetail's own EntityHeader renders the
// record's title/status below, so no page-level header is rendered at all —
// the top-bar breadcrumb (AppChrome, always rendered) is the ONLY breadcrumb
// (Shell v3.1 / N29; a second full PageHeader with a second title, or a
// second breadcrumb bar, would double-stack). The "Details" section below is
// also relabelled "Record Fields" so it doesn't repeat the "Details" tab
// label EntityDetail already renders (showActivity's Details/Activity tabs).
// N36: EntityHeader also overrides the top-bar breadcrumb's terminal crumb
// with the loaded record's name once it resolves (useBreadcrumbOverride).
export default function ${compName}() {
  const params = useParams<{ id: string }>();
  const id = typeof params?.id === "string" ? params.id : "";
  return (
    <BuilderLayout>
      <EntityDetail
        entityType="demo-record"
        entityId={id}
        header={{ titleField: "name", statusField: "status" }}
        sections={[
          {
            title: "Record Fields",
            fields: [
              { field: "status", label: "Status", format: "badge" },
              { field: "priority", label: "Priority", format: "badge" },
              { field: "owner", label: "Owner" },
              { field: "category", label: "Category" },
              { field: "updated", label: "Last Modified", format: "date" },
            ],
          },
        ]}
        showActivity={true}
      />
    </BuilderLayout>
  );
}
`,
  );
}

// ── Root index page — landing (SH.00 when manifest.landing present) ───────────

emitLandingPage();

// ── Contact page + API route (when manifest.contact is present) ──────────────

if (hasContact) {
  emitContactPage();
  emitContactApiRoute();
}

// ── Legal pages (hub + terms + privacy + faq, when manifest.legal is present) ─

if (hasLegal) {
  emitLegalHub();
  if (manifest.legal.terms) emitLegalContentPage("terms");
  if (manifest.legal.privacy) emitLegalContentPage("privacy");
  if (manifest.legal.faq) emitLegalFaqPage();
}

// ── Public canvas page (when manifest.canvasPublic is present) ───────────────

if (hasCanvasPublic) emitCanvasPublicPage();

/**
 * Emit app/page.tsx.
 *
 * When `manifest.landing` is present, mount SH.00 LandingShell with PublicNavHeader
 * in the nav, and the landing UI primitives (LandingHero / LandingFeatures /
 * LandingHowItWorks / LandingCta / LandingFooter) in the hero/features/proof/cta/
 * footer slots — all driven by manifest.landing + manifest.nav. Slots whose config
 * is omitted are passed `undefined` so the shell's empty-slot collapse engages
 * (PLAN §G2 — never empty fragments).
 *
 * When `manifest.landing` is absent, fall back to the legacy bespoke DQ hero so
 * existing solutions that have not adopted the `landing:` block keep their page.
 */
/**
 * Emit app/page.tsx for a NON-DXP solution: a server redirect inward.
 *
 * Authenticated users land on /home (when present); the middleware bounces an
 * unauthenticated /home back to /login, so "/" → /login for signed-out users and
 * "/" → /home for signed-in users with a single redirect target. When there is no
 * /home route, redirect straight to /login. "/" stays public (not in the
 * protected-prefix set), so the redirect always resolves.
 */
function emitPublicRedirectToLogin() {
  const target = hasHome ? "/home" : "/login";
  writeFile(
    "app/page.tsx",
    `// Root index — non-DXP solution: no public landing, redirect inward.
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { redirect } from "next/navigation";

export default function IndexPage() {
  redirect(${JSON.stringify(target)});
}
`,
  );
}

function emitLandingPage() {
  // Non-DXP solutions never get a public landing — "/" redirects inward and only
  // /login is public. (hasLanding && !isDXP already hard-failed above.)
  if (!isDXP) {
    emitPublicRedirectToLogin();
    return;
  }
  if (!hasLanding) {
    emitLegacyLandingPage();
    return;
  }

  const landing = manifest.landing;
  const nav = manifest.nav ?? {};
  // Sign-in CTA defaults to /login when a nav.sign_in is not declared.
  const signIn = nav.sign_in ?? { label: "Sign in", href: "/login" };

  // PublicNavHeader nav links → JSON literal. Empty when none declared.
  const headerLinks = JSON.stringify(nav.links ?? []);

  // ── Hero ──
  const hero = landing.hero;
  const heroTrust = JSON.stringify(hero.trust_bullets ?? []);

  // ── Optional sections → serialized data (or null) ──
  const features = landing.features ?? null;
  const howItWorks = landing.how_it_works ?? null;
  const cta = landing.cta ?? null;
  const footer = landing.footer ?? null;

  const featuresItems = features ? JSON.stringify(features.items) : "[]";
  const howSteps = howItWorks ? JSON.stringify(howItWorks.steps) : "[]";
  const footerColumns = footer ? JSON.stringify(footer.columns ?? []) : "[]";
  // Only declare FEATURE_ITEMS/HOW_STEPS when the manifest actually configures
  // features:/how_it_works: — the features/proof slots below render `undefined`
  // (not FEATURE_ITEMS/HOW_STEPS) when absent, so an unconditional declaration
  // was landing as an unused-var lint error on every solution without these blocks.
  const featureItemsDecl = features
    ? `const FEATURE_ITEMS = (${featuresItems} as Array<{ icon?: string; title: string; description?: string }>).map((f) => ({
  icon: icon(f.icon),
  title: f.title,
  description: f.description ?? "",
}));

`
    : "";
  const howStepsDecl = howItWorks
    ? `const HOW_STEPS = (${howSteps} as Array<{ step?: string; title: string; description?: string; icon?: string }>).map((s) => ({
  step: s.step ?? "",
  title: s.title,
  description: s.description ?? "",
  icon: icon(s.icon),
}));

`
    : "";

  writeFile(
    "app/page.tsx",
    `"use client";
// Root landing page — SH.00 LandingShell composition.
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import * as LucideIcons from "lucide-react";
import LandingShell from "@dbp/shell-landing";
import {
  LandingHero,
  LandingFeatures,
  LandingHowItWorks,
  LandingCta,
  LandingFooter,
} from "@dbp/ui";

// Resolve a lucide icon name → rendered element (1.5 stroke). Unknown / absent
// names render nothing so the icon slot simply collapses.
function icon(name?: string): React.ReactNode {
  if (!name) return undefined;
  const Cmp = (LucideIcons as unknown as Record<string, React.ComponentType<{ size?: number; strokeWidth?: number }>>)[name];
  return Cmp ? <Cmp size={16} strokeWidth={1.5} /> : undefined;
}

const NAV_LINKS = ${headerLinks} as Array<{ label: string; href: string }>;
const NAV_ACTIONS = [${JSON.stringify(signIn)}] as Array<{ label: string; href: string }>;

const HERO_TRUST = (${heroTrust} as Array<{ icon?: string; label: string }>).map((b) => ({
  icon: icon(b.icon),
  label: b.label,
}));

${featureItemsDecl}${howStepsDecl}const FOOTER_COLUMNS = ${footerColumns} as Array<{ heading: string; links: Array<{ label: string; href: string }> }>;

export default function IndexPage(): React.ReactElement {
  return (
    <LandingShell
      nav={{
        // TopBarNav renders a standard code/name lockup. (logo-image support via the
        // nav.logo ReactNode slot can be re-added when a manifest sets nav.logo_url.)
        code: ${JSON.stringify(manifest.solution)},
        name: ${JSON.stringify(manifest.name)},
        links: NAV_LINKS,
        actions: NAV_ACTIONS,
      }}
      slots={{
        hero: (
          <LandingHero
            overline={${JSON.stringify(hero.overline ?? `${manifest.platform} Platform · ${manifest.solution}`)}}
            headline={${JSON.stringify(hero.headline)}}
            headlineAccent={${JSON.stringify(hero.headline_accent ?? "")}}
            body={${JSON.stringify(hero.body ?? "")}}
            ${hero.primary_cta ? `primaryCta={${JSON.stringify(hero.primary_cta)}}` : ""}
            ${hero.secondary_cta ? `secondaryCta={${JSON.stringify(hero.secondary_cta)}}` : ""}
            trustBullets={HERO_TRUST}
          />
        ),
        features: ${features ? `(
          <LandingFeatures
            overline={${JSON.stringify(features.overline ?? "")}}
            headline={${JSON.stringify(features.headline ?? "")}}
            headlineAccent={${JSON.stringify(features.headline_accent ?? "")}}
            body={${JSON.stringify(features.body ?? "")}}
            items={FEATURE_ITEMS}
          />
        )` : "undefined"},
        proof: ${howItWorks ? `(
          <LandingHowItWorks
            overline={${JSON.stringify(howItWorks.overline ?? "")}}
            headline={${JSON.stringify(howItWorks.headline ?? "")}}
            body={${JSON.stringify(howItWorks.body ?? "")}}
            steps={HOW_STEPS}
          />
        )` : "undefined"},
        cta: ${cta ? `(
          <LandingCta
            headline={${JSON.stringify(cta.headline ?? "")}}
            headlineAccent={${JSON.stringify(cta.headline_accent ?? "")}}
            body={${JSON.stringify(cta.body ?? "")}}
            ${cta.primary_cta ? `primaryCta={${JSON.stringify(cta.primary_cta)}}` : ""}
            ${cta.secondary_cta ? `secondaryCta={${JSON.stringify(cta.secondary_cta)}}` : ""}
          />
        )` : "undefined"},
        footer: ${footer ? `(
          <LandingFooter
            productCode=${JSON.stringify(manifest.solution)}
            productName=${JSON.stringify(manifest.name)}
            tagline={${JSON.stringify(footer.tagline ?? "")}}
            columns={FOOTER_COLUMNS}
            ${footer.legal ? `legal={${JSON.stringify(footer.legal)}}` : ""}
          />
        )` : "undefined"},
      }}
    />
  );
}
`,
  );
}

function emitContactPage() {
  if (!hasContact) return;
  const c = manifest.contact;
  const s = publicShellScaffold();

  // RSC wrapper — sets metadata, imports the client component.
  writeFile(
    "app/(public)/contact/page.tsx",
    `// Contact page — RSC wrapper; delegates interactive form to _client.tsx.
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import type { Metadata } from "next";
import ContactClientPage from "./_client";

export const metadata: Metadata = {
  title: ${JSON.stringify(c.headline ?? "Contact Us")},
};

export default function ContactPage() {
  return <ContactClientPage />;
}
`,
  );

  // Client component — "use client" boundary; mounts LandingShell + PublicContactForm.
  writeFile(
    "app/(public)/contact/_client.tsx",
    `"use client";
// Contact page client component — SH.00 LandingShell + PublicContactForm.
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import LandingShell from "@dbp/shell-landing";
import { PublicNavHeader, PublicContactForm, PublicPageHeader${s.footerImport} } from "@dbp/ui";

const NAV_LINKS = ${s.headerLinks} as Array<{ label: string; href: string }>;
const SIGN_IN = ${s.signIn} as { label: string; href: string };${s.footerConst}

export default function ContactClientPage(): React.ReactElement {
  return (
    <LandingShell
      nav={{
${s.navJsx}
      }}
      slots={{
        hero: (
          <>
            {/* A1 PublicPageHeader (gray band) → A3 white form section */}
            <PublicPageHeader
              eyebrow="Contact"
              title={${JSON.stringify(c.headline ?? "Tell us what you need.")}}
              subtitle={${JSON.stringify(c.body ?? "We'll help you get started.")}}
            />
            <PublicContactForm
              showHeader={false}
              surfaceClassName="bg-white border-t border-gray-200"
              headline={${JSON.stringify(c.headline ?? "Tell us what you need.")}}
              body={${JSON.stringify(c.body ?? "We'll help you get started.")}}
              email={${JSON.stringify(c.email ?? "info@digitalqatalyst.com")}}
              ${c.phone ? `phone={${JSON.stringify(c.phone)}}` : ""}
              ${c.address ? `address={${JSON.stringify(c.address)}}` : ""}
              interestOptions={${JSON.stringify(c.interest_options ?? [])}}
              needOptions={${JSON.stringify(c.need_options ?? [])}}
              action="/api/platform/notify/contact"
              privacyHref="/legal/privacy"
            />
          </>
        ),
${s.footerJsx}
      }}
    />
  );
}
`,
  );
}

function emitContactApiRoute() {
  if (!hasContact) return;
  const c = manifest.contact;
  const contactEmail = c.email ?? "info@digitalqatalyst.com";

  writeFile(
    "app/api/platform/notify/contact/route.ts",
    `// Contact form submission — emails via PS.NOTIF transport.
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { getEmailTransport } from "@dbp/ps-notif/server";

export const runtime = "nodejs";

const CONTACT_EMAIL = ${JSON.stringify(contactEmail)};

type ContactBody = {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  organisation?: string;
  role?: string;
  interest?: string;
  need?: string;
  message?: string;
  consent?: boolean;
  website?: string; // honeypot
};

function escapeHtml(v: unknown): string {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function formatContact(b: ContactBody): string {
  const rows: Array<[string, unknown]> = [
    ["Name", \`\${b.firstName ?? ""} \${b.lastName ?? ""}\`.trim()],
    ["Email", b.email],
    ["Phone", b.phone],
    ["Organisation", b.organisation],
    ["Role", b.role],
    ["Interest", b.interest],
    ["Need", b.need],
    ["Message", b.message],
  ];
  const body = rows
    .filter(([, v]) => v != null && String(v).trim() !== "")
    .map(([k, v]) => \`<p><strong>\${escapeHtml(k)}:</strong> \${escapeHtml(v)}</p>\`)
    .join("\\n");
  return \`<h2>Contact form submission</h2>\\n\${body}\`;
}

export async function POST(req: Request): Promise<Response> {
  let body: ContactBody;
  try {
    body = (await req.json()) as ContactBody;
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }

  // Honeypot — bots fill the hidden \`website\` field. Silently accept + discard.
  if (body.website && body.website.trim() !== "") {
    return Response.json({ ok: true });
  }

  if (!body.consent) {
    return Response.json({ error: "Consent required" }, { status: 400 });
  }

  if (!body.email || !body.message) {
    return Response.json({ error: "email and message are required" }, { status: 400 });
  }

  try {
    await getEmailTransport().send({
      to: CONTACT_EMAIL,
      subject: \`Contact form submission — \${body.firstName ?? ""} \${body.lastName ?? ""}\`.trim(),
      html: formatContact(body),
    });
  } catch (err) {
    console.error("[contact] email send failed", err);
    return Response.json({ error: "Submission failed, please email us directly." }, { status: 502 });
  }

  return Response.json({ ok: true });
}
`,
  );
}

// ── Legal pages (hub + terms + privacy + faq) ─────────────────────────────────

/**
 * Shared helper — builds the nav/footer scaffold fragments used by all legal
 * pages so each emit function stays focused on its own content.
 */
function publicShellScaffold() {
  const nav = manifest.nav ?? {};
  const signIn = nav.sign_in ?? { label: "Sign in", href: "/login" };
  const headerLinks = JSON.stringify(nav.links ?? []);
  const footer = manifest.landing?.footer ?? null;
  const footerColumns = footer ? JSON.stringify(footer.columns ?? []) : "[]";
  const footerImport = footer ? ", LandingFooter" : "";
  const footerConst = footer
    ? `\nconst FOOTER_COLUMNS = ${footerColumns} as Array<{ heading: string; links: Array<{ label: string; href: string }> }>;`
    : "";
  const footerJsx = footer
    ? `        footer: (
          <LandingFooter
            productCode=${JSON.stringify(manifest.solution)}
            productName=${JSON.stringify(manifest.name)}
            tagline={${JSON.stringify(footer.tagline ?? "")}}
            columns={FOOTER_COLUMNS}
            ${footer.legal ? `legal={${JSON.stringify(footer.legal)}}` : ""}
          />
        ),`
    : "";
  const navJsx = `        logo: (
          <PublicNavHeader
            productCode=${JSON.stringify(manifest.solution)}
            productName=${JSON.stringify(manifest.name)}
            links={NAV_LINKS}
            signIn={SIGN_IN}
          />
        ),`;
  return {
    headerLinks,
    signIn: JSON.stringify(signIn),
    footerImport,
    footerConst,
    footerJsx,
    navJsx,
  };
}

/**
 * Public full-bleed canvas page (manifest.canvasPublic). PublicCanvasLayout owns
 * its own TopBarNav directly (no LandingShell slot composition — see
 * public-canvas.tsx's anatomy comment), so this is simpler than emitContactPage:
 * no LandingShell wrapper, no footer.
 *
 * No dedicated "canvas-public feature" package exists yet (this is a genuinely
 * new, bring-your-own-content archetype — unlike collection-board/APP.F04, there
 * is no matching platform feature to mount), so the body is an honest placeholder
 * naming the real follow-up, not a fabricated feature.
 */
function emitCanvasPublicPage() {
  const c = manifest.canvasPublic;
  const routePath = c.route.replace(/^\//, "");
  writeFile(
    `app/(public)/${routePath}/page.tsx`,
    `"use client";
// Public canvas page — SH.00-adjacent, full-bleed (PublicCanvasLayout).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { PublicCanvasLayout } from "@dbp/shell-landing/layouts";

export default function CanvasPublicPage() {
  return (
    <PublicCanvasLayout>
      <div className="flex h-full w-full items-center justify-center bg-[var(--color-surface)]">
        <div className="rounded-xl border border-[var(--color-border)] bg-white px-6 py-5 text-center shadow-sm">
          <p className="text-base font-semibold text-[var(--color-text)]">{${JSON.stringify(c.title)}}</p>
          <p className="mt-2 text-sm text-[var(--color-text-muted)]">
            No canvas-public feature is configured yet — set solution/pages to mount your own
            full-bleed content here (see AGENTS.md "File ownership contract").
          </p>
        </div>
      </div>
    </PublicCanvasLayout>
  );
}
`,
  );
}

function emitLegalHub() {
  if (!hasLegal) return;
  const legal = manifest.legal;
  const s = publicShellScaffold();

  const cards = [];
  if (legal.terms) cards.push({ title: legal.terms.title ?? "Terms of Use", href: "/legal/terms", desc: legal.terms.subtitle ?? "" });
  if (legal.privacy) cards.push({ title: legal.privacy.title ?? "Privacy Policy", href: "/legal/privacy", desc: legal.privacy.subtitle ?? "" });
  if (legal.faq) cards.push({ title: legal.faq.title ?? "Frequently Asked Questions", href: "/legal/faq", desc: legal.faq.subtitle ?? "" });

  writeFile(
    "app/(public)/legal/page.tsx",
    `// Legal hub — public-composed surface (SH.00 LandingShell, no sidebar).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import LandingShell from "@dbp/shell-landing";
import { PublicNavHeader, PublicPageHeader${s.footerImport} } from "@dbp/ui";

const NAV_LINKS = ${s.headerLinks} as Array<{ label: string; href: string }>;
const SIGN_IN = ${s.signIn} as { label: string; href: string };${s.footerConst}
const CARDS = ${JSON.stringify(cards)} as Array<{ title: string; href: string; desc: string }>;

export default function LegalHubPage(): React.ReactElement {
  return (
    <LandingShell
      nav={{
${s.navJsx}
      }}
      slots={{
        hero: (
          <>
            {/* A1 PublicPageHeader (gray band) → A3 white body */}
            <PublicPageHeader
              eyebrow="Legal"
              title="Legal & policies"
              subtitle="The documents governing your use of this platform."
            />
            <section className="border-t border-gray-200 bg-white px-5 py-14 md:px-8 md:py-20 lg:px-10">
              <div className="mx-auto max-w-[1200px]">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {CARDS.map((c) => (
                    <a
                      key={c.href}
                      href={c.href}
                      className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md"
                    >
                      <h3 className="text-lg font-semibold text-primary">{c.title}</h3>
                      {c.desc ? <p className="mt-2 text-sm text-[var(--color-text-secondary)]">{c.desc}</p> : null}
                    </a>
                  ))}
                </div>
              </div>
            </section>
          </>
        ),
${s.footerJsx}
      }}
    />
  );
}
`,
  );
}

function emitLegalContentPage(type) {
  if (!hasLegal) return;
  const legal = manifest.legal;
  const doc = legal[type];
  if (!doc) return;
  const s = publicShellScaffold();
  const contactEmail = manifest.contact?.email ?? "info@digitalqatalyst.com";
  const sections = JSON.stringify(doc.sections ?? []);

  writeFile(
    `app/(public)/legal/${type}/page.tsx`,
    `// Legal ${type} — public-composed surface (SH.00 LandingShell, no sidebar).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import LandingShell from "@dbp/shell-landing";
import { PublicNavHeader, LegalPageLayout${s.footerImport} } from "@dbp/ui";
import type { LegalSection } from "@dbp/ui";

const NAV_LINKS = ${s.headerLinks} as Array<{ label: string; href: string }>;
const SIGN_IN = ${s.signIn} as { label: string; href: string };${s.footerConst}
const SECTIONS = ${sections} as LegalSection[];

export default function Legal${type[0].toUpperCase() + type.slice(1)}Page(): React.ReactElement {
  return (
    <LandingShell
      nav={{
${s.navJsx}
      }}
      slots={{
        hero: (
          <LegalPageLayout
            eyebrow="LEGAL"
            title={${JSON.stringify(doc.title ?? "")}}
            subtitle={${JSON.stringify(doc.subtitle ?? "")}}
            lastUpdated={${JSON.stringify(legal.last_updated ?? "")}}
            sections={SECTIONS}
            contactEmail={${JSON.stringify(contactEmail)}}
          />
        ),
${s.footerJsx}
      }}
    />
  );
}
`,
  );
}

function emitLegalFaqPage() {
  if (!hasLegal || !manifest.legal.faq) return;
  const faq = manifest.legal.faq;
  const s = publicShellScaffold();
  const items = JSON.stringify(faq.items ?? []);

  writeFile(
    "app/(public)/legal/faq/page.tsx",
    `// Legal FAQ — public-composed surface (SH.00 LandingShell, no sidebar).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import LandingShell from "@dbp/shell-landing";
import { PublicNavHeader, PublicPageHeader${s.footerImport} } from "@dbp/ui";

const NAV_LINKS = ${s.headerLinks} as Array<{ label: string; href: string }>;
const SIGN_IN = ${s.signIn} as { label: string; href: string };${s.footerConst}
const ITEMS = ${items} as Array<{ question: string; answer: string }>;

export default function LegalFaqPage(): React.ReactElement {
  return (
    <LandingShell
      nav={{
${s.navJsx}
      }}
      slots={{
        hero: (
          <>
            {/* A1 PublicPageHeader (gray band) → A3 white body */}
            <PublicPageHeader eyebrow="FAQ" title={${JSON.stringify(faq.title ?? "Frequently Asked Questions")}} />
            <section className="border-t border-gray-200 bg-white px-5 py-14 md:px-8 md:py-20 lg:px-10">
              <div className="mx-auto max-w-[760px]">
                <div className="divide-y divide-[var(--color-border-subtle)]">
                  {ITEMS.map((item) => (
                    <details key={item.question} className="group py-5">
                      <summary className="flex cursor-pointer list-none items-center justify-between text-[16px] font-semibold text-primary">
                        {item.question}
                        <span aria-hidden className="ml-4 text-[var(--color-text-secondary)] transition-transform group-open:rotate-45">
                          +
                        </span>
                      </summary>
                      <p className="mt-3 text-[15px] leading-relaxed text-[var(--color-text-secondary)]">
                        {item.answer}
                      </p>
                    </details>
                  ))}
                </div>
              </div>
            </section>
          </>
        ),
${s.footerJsx}
      }}
    />
  );
}
`,
  );
}

/** Legacy bespoke DQ landing hero — emitted when no `landing:` block is declared. */
function emitLegacyLandingPage() {
  const moduleCardData = manifest.modules
    .map((mod) => {
      const route = moduleRoutePath(mod);
      return `  {\n    code: "${mod.id.split(".").pop()}",\n    label: "${mod.name}",\n    href: "/${route}",\n    description: "Stage ${mod.journey} module — ${mod.scaffold} shell.",\n  }`;
    })
    .join(",\n");

  const primaryModuleRoute = "/" + moduleRoutePath(manifest.modules[0]);
  const primaryModuleLabel = manifest.modules[0].name;

  writeFile(
    "app/page.tsx",
    `// Root landing page — DQ prototype standard (legacy bespoke hero)
// Generated by scaffold-solution. Server component — no client hooks needed.
import * as React from "react";
import Link from "next/link";
import { ArrowRight, ShieldCheck, UserCheck, Users } from "lucide-react";

const MODULES = [
${moduleCardData}
];

const TRUST_BULLETS = [
  { icon: ShieldCheck, label: "Governed & audited" },
  { icon: UserCheck, label: "Role-based access" },
  { icon: Users, label: "Multi-tenant ready" },
];

export default function IndexPage(): React.ReactElement {
  return (
    <div
      className="min-h-screen"
      style={{ backgroundColor: "var(--color-surface)" }}
    >
      {/* Top strip */}
      <header
        className="border-b px-6 py-4"
        style={{
          backgroundColor: "var(--color-surface-2)",
          borderColor: "var(--color-border-subtle)",
        }}
      >
        <div className="mx-auto flex max-w-[1280px] items-center gap-2">
          <span
            className="text-[18px] font-bold"
            style={{ color: "var(--color-primary)" }}
          >
            ${manifest.solution}
          </span>
          <span
            className="text-[15px] font-medium"
            style={{ color: "var(--color-text-muted)" }}
          >
            / ${manifest.name}
          </span>
        </div>
      </header>

      {/* Hero */}
      <section className="relative isolate overflow-hidden">
        <div
          aria-hidden
          className="absolute inset-0 -z-10"
          style={{ background: "var(--mesh-hero-light)" }}
        />
        <div aria-hidden className="hero-grid absolute inset-0 -z-10 opacity-40" />

        <div className="relative mx-auto max-w-[1280px] px-6 pb-16 pt-12 lg:px-8 lg:pb-24 lg:pt-16">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-[1fr_1.05fr] lg:gap-14">
            <div className="max-w-xl">
              <p className="dq-overline animate-fade-in-up">
                ${manifest.platform} Platform · ${manifest.solution}
              </p>

              <h1
                className="animate-fade-in-up animation-delay-100 mt-4 text-[40px] font-semibold leading-[1.08] tracking-[-0.03em] sm:text-[48px] lg:text-[52px]"
                style={{ color: "var(--color-primary)" }}
              >
                ${manifest.name}.{" "}
                <span style={{ color: "var(--color-secondary)" }}>
                  Built on the platform.
                </span>
              </h1>

              <p
                className="animate-fade-in-up animation-delay-200 mt-5 max-w-lg text-base leading-7 sm:text-[17px]"
                style={{ color: "var(--color-text-muted)" }}
              >
                Zero-rebuild solution — auth, RBAC, data, notifications, and
                workflow wired by ID from Layer 06 platform services.
              </p>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
                <Link
                  href="${primaryModuleRoute}"
                  className="group relative inline-flex h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-full px-6 text-sm font-semibold text-white sm:w-auto"
                  style={{
                    backgroundColor: "var(--color-primary)",
                    boxShadow: "var(--glow-navy-md)",
                  }}
                >
                  <span
                    aria-hidden
                    className="absolute inset-0 -translate-x-full bg-gradient-to-r from-[var(--color-secondary)] to-[#e04020] transition-transform duration-500 group-hover:translate-x-0"
                  />
                  <span className="relative">${primaryModuleLabel}</span>
                  <ArrowRight size={16} strokeWidth={1.5} className="relative" />
                </Link>
              </div>

              <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:flex-wrap sm:gap-6">
                {TRUST_BULLETS.map(({ icon: Icon, label }) => (
                  <div key={label} className="flex items-center gap-2.5">
                    <div
                      className="flex h-8 w-8 items-center justify-center rounded-xl"
                      style={{ backgroundColor: "var(--color-navy-50)", color: "var(--color-primary)" }}
                    >
                      <Icon size={16} strokeWidth={1.5} />
                    </div>
                    <span className="text-sm font-medium" style={{ color: "var(--color-text-secondary)" }}>
                      {label}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Module quick-link card */}
            <div className="animate-fade-in-up animation-delay-300">
              <div className="dq-card max-w-sm lg:ml-auto">
                <p className="dq-overline mb-4">Module overview</p>
                <ul className="space-y-3">
                  {MODULES.map((mod) => (
                    <li key={mod.code}>
                      <Link
                        href={mod.href}
                        className="dq-card-clickable flex items-start gap-4 rounded-[var(--radius-card)] border p-4 transition"
                        style={{
                          borderColor: "var(--color-border-subtle)",
                          backgroundColor: "var(--color-surface)",
                        }}
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold" style={{ color: "var(--color-primary)" }}>
                            {mod.label}
                          </p>
                          <p className="mt-0.5 text-xs leading-relaxed" style={{ color: "var(--color-text-muted)" }}>
                            {mod.description}
                          </p>
                        </div>
                        <ArrowRight size={16} strokeWidth={1.5} className="mt-0.5 shrink-0" style={{ color: "var(--color-text-disabled)" }} />
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
`,
  );
}

// ─── Connected app chrome (enriched top bar) ──────────────────────────────────
//
// THE reusable mechanism, emitted ONCE per app and inherited by every shell-
// mounting page. `app/solution-chrome.tsx` is a "use client" wrapper that:
//   • reads the CURRENT authenticated identity from PS.AUTH via useSessionIdentity()
//     (display name / primary role / roles / tenant — never hardcoded),
//   • mounts @dbp/organisms/search-bar and @dbp/organisms/notification-bell into
//     @dbp/ui's <AppChrome> search/notifications slot props, conditionally on
//     HAS_SEARCH/HAS_NOTIF (derived purely from consumes_platform_services) —
//     AppChrome itself stays organism-free (Layer 06/07 boundary),
//   • and renders @dbp/ui's <AppChrome> with the manifest product lockup.
//
// Pages mount <SolutionChrome /> into their shell's `nav.topBar`. A future
// solution that wires PS.SEARCH gets search with zero extra page code — the flag
// flows from the manifest through this one component.
//
// Generator-owned: it is a pure projection of the manifest + consumed services,
// so a --force regen reproduces it byte-for-byte. The HAS_AUTH / HAS_SEARCH /
// HAS_NOTIF capability flags are declared earlier (near consumedServices).

/**
 * Emitted once (regardless of PS.AUTH) — a route → breadcrumb-trail map built from
 * the same moduleBreadcrumbTrail() output used per-page, so the AppChrome top-bar
 * breadcrumb (Shell v2 Option 2) never diverges from the (now hidden) PageHeader trail.
 */
function emitRouteBreadcrumbs() {
  writeFile(
    "app/route-breadcrumbs.ts",
    `// Route → breadcrumb-trail map — Shell v2 Option 2 (breadcrumb-in-topbar).
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
import type { BreadcrumbItem } from "@dbp/ui";

export const ROUTE_BREADCRUMBS: Record<string, BreadcrumbItem[]> = ${JSON.stringify(
      Object.fromEntries(routeBreadcrumbEntries),
      null,
      2,
    )};

/** Longest-prefix match against ROUTE_BREADCRUMBS (handles /route/:id sub-paths). */
export function resolveBreadcrumb(pathname: string): BreadcrumbItem[] | undefined {
  if (ROUTE_BREADCRUMBS[pathname]) return ROUTE_BREADCRUMBS[pathname];
  const candidates = Object.keys(ROUTE_BREADCRUMBS)
    .filter((route) => pathname.startsWith(route + "/"))
    .sort((a, b) => b.length - a.length);
  const best = candidates[0];
  return best !== undefined ? ROUTE_BREADCRUMBS[best] : undefined;
}
`,
  );
}

/** Emitted only when PS.AUTH is wired — the chrome's identity comes from it. */
function emitSolutionChrome() {
  if (!HAS_AUTH) return;
  writeFile(
    "app/solution-chrome.tsx",
    `"use client";
// Connected app chrome — the enriched, session + capability driven top bar.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
//
// Built ONCE and inherited by every shell-mounting page (home / marketplace /
// copilot / modules). Nothing is hardcoded:
//   • identity      ← PS.AUTH session via useSessionIdentity()
//   • search        ← @dbp/organisms/search-bar mounted into AppChrome's search
//     slot only when PS.SEARCH is wired (HAS_SEARCH below) — AppChrome itself
//     never imports the organism (Layer 06/07 boundary; component-architecture-
//     standard.md §7b / Amendment D-2 rollout, 2026-07-21).
//   • bell          ← @dbp/organisms/notification-bell mounted into AppChrome's
//     notifications slot only when PS.NOTIF is wired (HAS_NOTIF below)
//   • lockup        ← solution code + name from the manifest
//   • breadcrumb    ← derived from the current pathname via ROUTE_BREADCRUMBS
//     (Shell v2 Option 2 — see docs/09-plans/shell-v2-option2-implementation-2026-07-17.md)
import * as React from "react";
import { ${HAS_SEARCH ? "useRouter, " : ""}usePathname } from "next/navigation";
import { useSessionIdentity } from "@dbp/ps-auth/client";
import { AppChrome } from "@dbp/ui";
import { TenantSwitcher } from "@dbp/organisms/tenant-switcher";
${HAS_SEARCH ? 'import { SearchBar } from "@dbp/organisms/search-bar";' : ""}
${HAS_NOTIF ? 'import { NotificationBell } from "@dbp/organisms/notification-bell";' : ""}
import { resolveBreadcrumb } from "./route-breadcrumbs";

const PRODUCT_CODE = ${JSON.stringify(manifest.nav?.topBar?.productCode ?? manifest.solution)};
const PRODUCT_NAME = ${JSON.stringify(manifest.nav?.topBar?.productName ?? manifest.name)};
${manifest.nav?.topBar?.logoSrc ? `const LOGO_SRC = ${JSON.stringify(manifest.nav.topBar.logoSrc)};` : ""}
${manifest.nav?.topBar?.logoAlt ? `const LOGO_ALT = ${JSON.stringify(manifest.nav.topBar.logoAlt)};` : ""}

export interface SolutionChromeProps {
  /** Optional global-search placeholder override (per route). */
  searchPlaceholder?: string;
}

export function SolutionChrome(${HAS_SEARCH ? "{ searchPlaceholder }" : "_props"}: SolutionChromeProps) {
  ${HAS_SEARCH ? "const router = useRouter();" : ""}
  const pathname = usePathname();
  const { identity } = useSessionIdentity();
  const breadcrumb = resolveBreadcrumb(pathname ?? "");
  return (
    <AppChrome
      productCode={PRODUCT_CODE}
      productName={PRODUCT_NAME}
      ${manifest.nav?.topBar?.logoSrc ? "logoSrc={LOGO_SRC}" : ""}
      ${manifest.nav?.topBar?.logoAlt ? "logoAlt={LOGO_ALT}" : ""}
      session={identity}
      {...(breadcrumb !== undefined ? { breadcrumb } : {})}
      ${
        HAS_SEARCH
          ? `search={
        <SearchBar
          {...(searchPlaceholder !== undefined ? { placeholder: searchPlaceholder } : {})}
          onSelect={(hit) => router.push("/marketplace/" + encodeURIComponent(hit.id))}
        />
      }`
          : ""
      }
      ${HAS_NOTIF ? "notifications={<NotificationBell />}" : ""}
    />
  );
}

// N30 ruling: the sidebar identity block IS the workspace/tenant switcher —
// mounted via TransactionShell's nav.identitySlot (see authenticated-client-shell.tsx).
// @dbp/ui stays auth-free; this wrapper supplies the session-derived tenant id,
// same pattern as SolutionChrome above.
export function SolutionSidebarSwitcher({ collapsed }: { collapsed?: boolean }) {
  const { identity } = useSessionIdentity();
  if (!identity) return null;
  return (
    <TenantSwitcher
      currentTenantId={identity.tenantId}
      solutionName={PRODUCT_NAME}
      {...(collapsed !== undefined ? { collapsed } : {})}
    />
  );
}
`,
  );
}

emitSolutionChrome();

// ── solution-footer.tsx ───────────────────────────────────────────────────────
//
// The full-width workspace footer, emitted ONCE and inherited by every
// authenticated page via `nav.footer` (mirrors solution-chrome). A pure
// projection of manifest.footer (+ manifest.name fallback), so a --force regen
// reproduces it byte-for-byte. No auto current-year is injected — that would
// make regen output drift over time; supply `footer.year`/`footer.copyright`
// in the manifest for a dated copyright.

/** Emitted only when PS.AUTH is wired — the footer is workspace chrome. */
function emitSolutionFooter() {
  if (!HAS_AUTH) return;
  const f = manifest.footer ?? {};
  const productName = f.productName ?? manifest.name;
  const copyright =
    f.copyright ?? (f.year ? `© ${f.year} ${productName}` : `© ${productName}`);

  const hasShortcuts = Array.isArray(f.shortcuts) && f.shortcuts.length > 0;

  const propLines = [
    `      productName={${JSON.stringify(productName)}}`,
    `      copyright={${JSON.stringify(copyright)}}`,
  ];
  if (f.version) propLines.push(`      version={${JSON.stringify(f.version)}}`);
  if (f.env) propLines.push(`      env={${JSON.stringify(f.env)}}`);
  if (hasShortcuts) propLines.push(`      shortcuts={SHORTCUTS}`);
  // Legal links (Privacy/Terms) are DXP-only chrome (ruled 2026-07-16, Shell/T5) —
  // workspace apps drop them from the compact status-bar footer even if the
  // manifest declares footer.links; only a DXP solution's workspace footer keeps them.
  if (f.links?.length && isDXP) propLines.push(`      links={${JSON.stringify(f.links)}}`);

  // When shortcuts are declared, the footer also INSTALLS them globally via
  // useKeyboardShortcuts (⌘K → focus search; "G then H" etc → router.push(href)).
  const shortcutsConst = hasShortcuts
    ? `\nconst SHORTCUTS = ${JSON.stringify(f.shortcuts, null, 2)};\n`
    : "";
  const imports = hasShortcuts
    ? `import { useRouter } from "next/navigation";\nimport { AppFooter, useKeyboardShortcuts } from "@dbp/ui";`
    : `import { AppFooter } from "@dbp/ui";`;
  const hookBody = hasShortcuts
    ? `  const router = useRouter();\n  useKeyboardShortcuts(SHORTCUTS, { onNavigate: (href) => router.push(href) });\n`
    : "";

  writeFile(
    "app/solution-footer.tsx",
    `"use client";
// Connected app footer — the full-width workspace status bar.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
//
// Built ONCE and inherited by every shell-mounting page via nav.footer.
// Content is a pure projection of manifest.footer (productName falls back to the
// solution name). Keep it compact and muted — workspace chrome, not marketing.
// When manifest.footer.shortcuts are declared, the SAME list both renders the
// hints AND is installed as live keyboard shortcuts.
${imports}
${shortcutsConst}
export function SolutionFooter() {
${hookBody}  return (
    <AppFooter
${propLines.join("\n")}
    />
  );
}
`,
  );
}

emitSolutionFooter();

// ─── Emit archetype routes: /home, /marketplace, /marketplace/[id], /copilot ──

emitHomeRoute();
emitMarketplaceRoutes();
emitCopilotRoute();
emitRouteBreadcrumbs();

/**
 * /home → the APP.F12 authenticated-home rebuild
 * (`docs/09-plans/app-f12-home-redo-2026-07-27/design-spec.md`): four fixed
 * sections — WorkspaceHomeHero → WorkspaceHomePlatform → WorkspaceHomeJourney → WorkspaceHomeClosing.
 * No greeting card, preview panel, KPI row, activity feed, quick-links deck,
 * or search input (design-spec §7 — explicit non-features).
 *
 * Hero copy comes from `manifest.home.hero` (preferred) or `manifest.landing.hero`
 * (fallback). Platform/Journey/Closing come from `manifest.home.{features,howItWorks,cta}`
 * (preferred) or `manifest.landing.{features,how_it_works,cta}` (fallback, DXP only).
 * firstName comes from the PS.AUTH session (resolved client-side) but is no
 * longer rendered — kept unused would be a lint error, so it's dropped.
 * Emitted only when manifest.home is present.
 */
function emitHomeRoute() {
  if (!hasHome) {
    // No manifest.home block — emit a minimal welcome page so this route is
    // always generator-owned regardless of manifest configuration.
    writeFile(
      "app/(authenticated)/home/page.tsx",
      `"use client";
// Home/Welcome page — auto-emitted (no manifest.home block configured).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import { PageHeader } from "@dbp/ui";

export default function HomePage() {
  return (
    <CanvasLayout header={<PageHeader title="Welcome" />}>
      <p className="text-sm text-[var(--color-text-muted)]">Configure a <code>home:</code> block in SOLUTION.md to customise this page.</p>
    </CanvasLayout>
  );
}
`,
    );
    return;
  }
  const home = manifest.home;
  const landing = manifest.landing ?? null;

  // Resolve the in-app hero: home.hero (camelCase) wins; else landing.hero
  // (snake_case) is normalised; else a minimal headlinePrefix from the
  // solution name. `headlinePrefix` carries the un-accented line — when the
  // source only has a plain `headline` (no split), it's used as the prefix.
  const hero = home.hero
    ? {
        overline: home.hero.overline,
        headlinePrefix: home.hero.headlinePrefix ?? home.hero.headline,
        headlineAccent: home.hero.headlineAccent,
        headlineSuffix: home.hero.headlineSuffix,
        body: home.hero.body,
        primaryAction: home.hero.primaryCta,
        secondaryAction: home.hero.secondaryCta,
        trustSignals: (home.hero.trustBullets ?? []).map((b) => b.label),
        artwork: home.hero.artwork,
        artworkAlt: home.hero.artworkAlt,
      }
    : landing?.hero
      ? {
          overline: landing.hero.overline,
          headlinePrefix: landing.hero.headline,
          headlineAccent: landing.hero.headline_accent,
          headlineSuffix: undefined,
          body: landing.hero.body,
          primaryAction: landing.hero.primary_cta,
          secondaryAction: landing.hero.secondary_cta,
          trustSignals: (landing.hero.trust_bullets ?? []).map((b) => b.label),
          artwork: undefined,
          artworkAlt: undefined,
        }
      : { headlinePrefix: manifest.name, trustSignals: [] };

  // Platform/Journey/Closing sections. manifest.home.* (camelCase) wins;
  // manifest.landing.* (snake_case, DXP only) is the fallback, normalised to
  // the same camelCase shape — fields with no landing.* equivalent (kind,
  // chips, lead, headingAccent, support, badge, metricValue/Label, label,
  // outcomes) are simply undefined when sourced from landing.
  const platformSrc = home.features ?? null;
  const platformFromLanding = !home.features && landing?.features ? landing.features : null;
  const journeySrc = home.howItWorks ?? null;
  const journeyFromLanding = !home.howItWorks && landing?.how_it_works ? landing.how_it_works : null;
  const closingSrc = home.cta ?? null;
  const closingFromLanding = !home.cta && landing?.cta ? landing.cta : null;

  const platform = platformSrc || platformFromLanding
    ? {
        label: (platformSrc?.overline ?? platformFromLanding?.overline) ?? "PLATFORM",
        heading: (platformSrc?.headline ?? platformFromLanding?.headline) ?? "",
        lead: platformSrc?.lead,
        items: platformSrc?.items ?? platformFromLanding?.items ?? [],
      }
    : null;
  const journey = journeySrc || journeyFromLanding
    ? {
        label: (journeySrc?.overline ?? journeyFromLanding?.overline) ?? "HOW IT WORKS",
        heading: (journeySrc?.headline ?? journeyFromLanding?.headline) ?? "",
        headingAccent: journeySrc?.headingAccent,
        support: journeySrc?.support ?? journeySrc?.body ?? journeyFromLanding?.body ?? "",
        steps: journeySrc?.steps ?? journeyFromLanding?.steps ?? [],
      }
    : null;
  const closing = closingSrc || closingFromLanding
    ? {
        label: closingSrc?.label,
        heading: (closingSrc?.headline ?? closingFromLanding?.headline) ?? "",
        body: (closingSrc?.body ?? closingFromLanding?.body) ?? "",
        primaryAction: (closingSrc?.primaryCta ?? closingFromLanding?.primary_cta) ?? undefined,
        secondaryAction: (closingSrc?.secondaryCta ?? closingFromLanding?.secondary_cta) ?? undefined,
        outcomes: closingSrc?.outcomes,
      }
    : null;

  // WorkspaceHomePlatform.capabilities requires `kind` — rotate repository →
  // collaboration → analytics by position when the manifest item omits it.
  const KIND_ROTATION = ["repository", "collaboration", "analytics"];
  const platformCapabilities = (platform?.items ?? []).map((item, i) => ({
    kind: item.kind ?? KIND_ROTATION[i % KIND_ROTATION.length],
    index: item.index ?? String(i + 1).padStart(2, "0"),
    title: item.title,
    description: item.description ?? "",
    chips: item.chips ?? [],
  }));
  // WorkspaceHomePlatform.feature is required — fall back to the section heading
  // when the manifest has no explicit `features.lead`.
  const platformFeature = platform
    ? {
        index: platform.lead?.index ?? "00",
        title: platform.lead?.title ?? platform.heading,
        description: platform.lead?.description ?? "",
      }
    : null;
  // WorkspaceHomeJourney.steps requires `badge`/`stage` — derive "STEP 0N" and a
  // zero-padded stage number from position when the manifest omits them.
  const journeySteps = (journey?.steps ?? []).map((step, i) => ({
    badge: step.badge ?? `STEP ${String(i + 1).padStart(2, "0")}`,
    stage: step.step ?? String(i + 1).padStart(2, "0"),
    title: step.title,
    description: step.description ?? "",
    metricValue: step.metricValue ?? "",
    metricLabel: step.metricLabel ?? "",
  }));

  // @dbp/ui named imports — only pull in the section components actually used.
  const uiNamed = ["WorkspaceHomeHero"];
  if (platform) uiNamed.push("WorkspaceHomePlatform");
  if (journey) uiNamed.push("WorkspaceHomeJourney");
  if (closing) uiNamed.push("WorkspaceHomeClosing");

  const heroJsx = `      <WorkspaceHomeHero
        overline={${JSON.stringify(hero.overline ?? "")}}
        ${hero.headlinePrefix ? `headlinePrefix={${JSON.stringify(hero.headlinePrefix)}}` : ""}
        headlineAccent={${JSON.stringify(hero.headlineAccent ?? "")}}
        ${hero.headlineSuffix ? `headlineSuffix={${JSON.stringify(hero.headlineSuffix)}}` : ""}
        body={${JSON.stringify(hero.body ?? "")}}
        ${hero.primaryAction ? `primaryAction={${JSON.stringify(hero.primaryAction)}}` : ""}
        ${hero.secondaryAction ? `secondaryAction={${JSON.stringify(hero.secondaryAction)}}` : ""}
        trustSignals={${JSON.stringify(hero.trustSignals ?? [])}}
        ${hero.artwork ? `artwork={${JSON.stringify(hero.artwork)}}` : ""}
        ${hero.artworkAlt ? `artworkAlt={${JSON.stringify(hero.artworkAlt)}}` : ""}
      />`;

  const platformJsx = platform
    ? `
      <WorkspaceHomePlatform
        label={${JSON.stringify(platform.label)}}
        heading={${JSON.stringify(platform.heading)}}
        feature={${JSON.stringify(platformFeature)}}
        capabilities={${JSON.stringify(platformCapabilities)} as { kind: "repository" | "collaboration" | "analytics"; index: string; title: string; description: string; chips: string[] }[]}
        ${hero.artwork ? `imageUrl={${JSON.stringify(hero.artwork)}}` : ""}
      />`
    : "";
  const journeyJsx = journey
    ? `
      <WorkspaceHomeJourney
        label={${JSON.stringify(journey.label)}}
        heading={${JSON.stringify(journey.heading)}}
        ${journey.headingAccent ? `headingAccent={${JSON.stringify(journey.headingAccent)}}` : ""}
        support={${JSON.stringify(journey.support)}}
        steps={${JSON.stringify(journeySteps)}}
      />`
    : "";
  const closingJsx = closing
    ? `
      <WorkspaceHomeClosing
        ${closing.label ? `label={${JSON.stringify(closing.label)}}` : ""}
        heading={${JSON.stringify(closing.heading)}}
        body={${JSON.stringify(closing.body)}}
        ${closing.primaryAction ? `primaryAction={${JSON.stringify(closing.primaryAction)}}` : ""}
        ${closing.secondaryAction ? `secondaryAction={${JSON.stringify(closing.secondaryAction)}}` : ""}
        ${closing.outcomes ? `outcomes={${JSON.stringify(closing.outcomes)}}` : ""}
      />`
    : "";

  writeFile(
    "app/(authenticated)/home/page.tsx",
    `"use client";
// Authenticated home — APP.F12 rebuild (fixed 4-section composition).
// Body-only page — TransactionShell provided by app/(authenticated)/layout.tsx
// WorkspaceHomeHero → WorkspaceHomePlatform → WorkspaceHomeJourney → WorkspaceHomeClosing. No
// greeting card, preview panel, KPI row, activity feed, quick-links deck, or
// search input (design-spec §7 — explicit non-features). No PageHeader.
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { ${uiNamed.join(", ")} } from "@dbp/ui";

export default function HomePage() {
  return (
    <div className="min-h-full -m-[var(--shell-gutter)]">
${heroJsx}${platformJsx}${journeyJsx}${closingJsx}
    </div>
  );
}
`,
  );
}

/**
 * /marketplace → SH.02 TransactionShell with @dbp/organisms/catalog-grid (APP.F10)
 * in the `main` slot. Card clicks navigate to /marketplace/[id]. When
 * manifest.marketplace.detail is present, also emit the routed detail page
 * mounting @dbp/organisms/marketplace-item-detail (APP.F11) reading the [id] param.
 */
/**
 * Emit the co-located detail route for a standard-menu catalogue module:
 *   app/<routeSegment>/[id]/page.tsx  → MarketplaceItemDetail (APP.F11)
 * reading the [id] param for the module's catalogue entity. The detail config is
 * synthesised from the catalog grid's cardFields so the H1/summary/badges track
 * the card. Called once per module that renders a catalog grid (APP.F10).
 */
function emitCatalogueDetailRoute(mod, routeSegment, catalogueFeat) {
  const cfg = catalogueFeat?.config ?? {};
  const entityType = cfg.entityType;
  if (!entityType) {
    // No entityType configured — emit a placeholder detail page so the route
    // always exists (wired catalogue cards must land somewhere). Data will be
    // empty until entityType is configured in the manifest.
    const resolvedEntityType = routeSegment.split("/").pop() + "-item";
    const compNamePlaceholder = `${mod.name.replace(/[^a-zA-Z0-9]/g, "")}DetailPage`;
    writeFile(
      `app/(authenticated)/${routeSegment}/[id]/page.tsx`,
      `"use client";
// Catalogue item detail — placeholder (no entityType configured for ${mod.id}).
// Layout: collection-marketplace-detail
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { useParams, useRouter } from "next/navigation";
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import MarketplaceItemDetail from "@dbp/organisms/marketplace-item-detail";

const DETAIL_CONFIG = { titleField: "name", summaryField: "summary", breadcrumb: [{ label: ${JSON.stringify(mod.name)}, href: "/${routeSegment}" }], badgeFields: [], tabs: [{ id: "overview", label: "Overview" }] };

export default function ${compNamePlaceholder}() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = typeof params?.id === "string" ? params.id : "";
  return (
    <CanvasLayout
    >
      <MarketplaceItemDetail
        entityType="${resolvedEntityType}"
        entityId={id}
        suppressHeader={true}
        titleRowAction={{ label: "Submit Enquiry", onClick: () => router.push(\`/${routeSegment}/\${id}/request\`) }}
        onNavigate={(href) => router.push(href)}
        {...(DETAIL_CONFIG as Omit<Parameters<typeof MarketplaceItemDetail>[0], "entityType" | "entityId">)}
      />
    </CanvasLayout>
  );
}
`,
    );
    writeFile(
      `app/(authenticated)/${routeSegment}/[id]/request/page.tsx`,
      `"use client";
// Catalogue listing request — placeholder for ${mod.id} (${mod.name}).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import { toast } from "@dbp/ui";
import SubmitRequestForm from "@dbp/organisms/service-offering-request";

export default function ${mod.name.replace(/[^a-zA-Z0-9]/g, "")}RequestPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = typeof params?.id === "string" ? params.id : "";

  function handleSuccess(requestId: string) {
    toast({ title: "Request submitted", description: \`Reference: \${requestId}\` });
    router.push(\`/${routeSegment}/\${id}\`);
  }

  return (
    <div className="mx-auto max-w-lg py-8">
      <SubmitRequestForm
        serviceId={id}
        onSuccess={handleSuccess}
        onCancel={() => router.push(\`/${routeSegment}/\${id}\`)}
      />
    </div>
  );
}
`,
    );
    return;
  }
  const cardFields = cfg.cardFields ?? {};
  const detailConfig = {
    titleField: cardFields.title || "name",
    summaryField: cardFields.description || "summary",
    // Two-level breadcrumb: section-parent → module (list page).
    // Both crumbs link to the list route — the parent crumb uses the first URL
    // segment as a section label (e.g. "Marketplace" for "marketplace/discern").
    // When the route is a single segment the parent crumb is omitted.
    // Every crumb MUST carry an href (BreadcrumbCrumb schema requires it).
    breadcrumb: (() => {
      const segments = routeSegment.split("/");
      const parentLabel = segments.length >= 2
        ? segments[0].charAt(0).toUpperCase() + segments[0].slice(1)
        : null;
      return [
        ...(parentLabel ? [{ label: parentLabel, href: `/${segments[0]}` }] : []),
        { label: mod.name, href: `/${routeSegment}` },
      ];
    })(),
    badgeFields: [
      ...(cardFields.typeLabel ? [{ field: cardFields.typeLabel, style: "pill" }] : []),
      ...(cardFields.status ? [{ field: cardFields.status, style: "pill" }] : []),
    ],
    tabs: [{ id: "overview", label: "Overview" }],
  };
  // Hold this GENERATOR-SYNTHESISED config to the same contract as manifest-authored
  // configs (Step 3). Without this gate a generator bug here ships green and only
  // fails at runtime, client-side, after login — which is exactly how the label-only
  // breadcrumb crumb escaped. APP.F11 = MarketplaceItemDetail.
  //
  // Validate the SAME object the component receives: the emitted page passes
  // `entityType` as a separate prop and spreads DETAIL_CONFIG, so the runtime config
  // the feature safeParses is { entityType, ...detailConfig } — `entityId`/`onNavigate`
  // are render-time props outside the Zod config schema and are excluded here.
  // See docs/01-Architecture/GENERATOR-REVIEW-marketplace-detail-breadcrumb.md.
  const detailValidation = validateFeatureConfig("APP.F11", { entityType, ...detailConfig });
  if (detailValidation.ok === false) {
    die(
      `Catalogue detail route for module ${mod.id} (${mod.name}) → APP.F11 ` +
        `MarketplaceItemDetail config (generator-synthesised in emitCatalogueDetailRoute) ` +
        `failed validation:\n${formatConfigIssues(detailValidation.issues)}\n` +
        `  This is a generator bug, not a manifest error — fix emitCatalogueDetailRoute.`,
    );
  }
  const detailCfg = JSON.stringify(detailConfig, null, 2);
  const compName = `${mod.name.replace(/[^a-zA-Z0-9]/g, "")}DetailPage`;
  // Catalogue detail lives under (authenticated)/ — body-only, shell from layout.tsx.
  // No page-level PageHeader (Amendment D-2 (component-architecture-standard.md §7b)) — the top bar's breadcrumb terminal
  // crumb is the page title; the "Submit Enquiry" CTA moves into a content-body
  // toolbar. suppressHeader={true} prevents MarketplaceItemDetail from rendering
  // its own bespoke hero block.
  writeFile(
    `app/(authenticated)/${routeSegment}/[id]/page.tsx`,
    `"use client";
// Catalogue item detail — APP.F11 (MarketplaceItemDetail) for ${mod.id} (${mod.name}).
// A wired catalog card on /${routeSegment} navigates here.
// Layout: collection-marketplace-detail
// Body-only page — TransactionShell provided by app/(authenticated)/layout.tsx
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { useParams, useRouter } from "next/navigation";
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import MarketplaceItemDetail from "@dbp/organisms/marketplace-item-detail";

const DETAIL_CONFIG = ${detailCfg};

export default function ${compName}() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = typeof params?.id === "string" ? params.id : "";
  return (
    <CanvasLayout
    >
      <MarketplaceItemDetail
        entityType=${JSON.stringify(entityType)}
        entityId={id}
        suppressHeader={true}
        titleRowAction={{ label: "Submit Enquiry", onClick: () => router.push(\`/${routeSegment}/\${id}/request\`) }}
        onNavigate={(href) => router.push(href)}
        {...(DETAIL_CONFIG as Omit<Parameters<typeof MarketplaceItemDetail>[0], "entityType" | "entityId">)}
      />
    </CanvasLayout>
  );
}
`,
  );

  // Every catalogue listing is requestable — emit the /request sub-route unconditionally.
  // When the entity also has requestable: true in the manifest the solution-owned form
  // (solution/features/<type>-request.tsx) overrides this default at runtime.
  writeFile(
    `app/(authenticated)/${routeSegment}/[id]/request/page.tsx`,
    `"use client";
// Catalogue listing request — APP.F22 for ${mod.id} (${mod.name}).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import { toast } from "@dbp/ui";
import SubmitRequestForm from "@dbp/organisms/service-offering-request";

export default function ${mod.name.replace(/[^a-zA-Z0-9]/g, "")}RequestPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = typeof params?.id === "string" ? params.id : "";

  function handleSuccess(requestId: string) {
    toast({ title: "Request submitted", description: \`Reference: \${requestId}\` });
    router.push(\`/${routeSegment}/\${id}\`);
  }

  return (
    <div className="mx-auto max-w-lg py-8">
      <SubmitRequestForm
        serviceId={id}
        onSuccess={handleSuccess}
        onCancel={() => router.push(\`/${routeSegment}/\${id}\`)}
      />
    </div>
  );
}
`,
  );
}

/**
 * P1 dual-surface (DXP only): emit the PUBLIC-composed marketplace.
 *
 * Mirrors the public landing ("/") composition — SH.00 LandingShell with a
 * PublicNavHeader in the nav and a LandingFooter, no workspace sidebar/chrome. The
 * CatalogGrid (APP.F10) renders inside a full-bleed white band on a 1200px rail.
 * Card clicks route to the public /marketplace/[id] detail (also public-composed).
 * Data still resolves to the boot-bound tenant (configureDataClient at app boot),
 * so offerings render without an authenticated session.
 */
function emitPublicMarketplaceRoutes(listing, listingCfg, detail) {
  const nav = manifest.nav ?? {};
  const signIn = nav.sign_in ?? { label: "Sign in", href: "/login" };
  const headerLinks = JSON.stringify(nav.links ?? []);
  const footer = manifest.landing?.footer ?? null;
  const footerColumns = footer ? JSON.stringify(footer.columns ?? []) : "[]";
  const mp = manifest.marketplace ?? {};
  const listingKicker = mp.kicker ?? "MARKETPLACE";
  const listingHeadline = mp.headline ?? `Browse ${manifest.name}`;
  const listingSubtitle = mp.subtitle ?? "";
  const itemLabel = mp.itemLabel ?? "items";

  // New optional feature flags
  const heroSearch = !!mp.heroSearch;
  const featuredCarousel = mp.featuredCarousel ?? null;
  const promoBand = mp.promoBand ?? null;

  const footerJsx = footer
    ? `        footer: (
          <LandingFooter
            productCode=${JSON.stringify(manifest.solution)}
            productName=${JSON.stringify(manifest.name)}
            tagline={${JSON.stringify(footer.tagline ?? "")}}
            columns={FOOTER_COLUMNS}
            ${footer.legal ? `legal={${JSON.stringify(footer.legal)}}` : ""}
          />
        ),`
    : "";

  const footerImport = footer ? ", LandingFooter" : "";
  const footerConst = footer
    ? `\nconst FOOTER_COLUMNS = ${footerColumns} as Array<{ heading: string; links: Array<{ label: string; href: string }> }>;`
    : "";

  // Optional imports are all bundled into the main @dbp/ui import below

  // Collect additional named @dbp/ui imports needed
  const extraUiImports = [
    featuredCarousel ? "FeaturedCarousel" : "",
    promoBand ? "LandingCta" : "",
  ].filter(Boolean).join(", ");
  const extraUiImportStr = extraUiImports ? `, ${extraUiImports}` : "";

  // Hero search bar JSX (placed inside hero div, after the h1 block)
  const heroSearchJsx = heroSearch
    ? `
                <HeroSearchBar itemLabel={${JSON.stringify(itemLabel)}} />`
    : "";

  // FeaturedCarousel JSX — white section with kicker + large title
  const featuredCarouselJsx = featuredCarousel
    ? `
            <FeaturedCarousel
              entityType=${JSON.stringify(mp.entityType)}
              ${featuredCarousel.kicker ? `kicker=${JSON.stringify(featuredCarousel.kicker)}` : `kicker="CURATED SELECTION"`}
              title=${JSON.stringify(featuredCarousel.title)}
              ${featuredCarousel.lede ? `lede=${JSON.stringify(featuredCarousel.lede)}` : ""}
              ${featuredCarousel.limit != null ? `limit={${featuredCarousel.limit}}` : ""}
              featuredField=${JSON.stringify(featuredCarousel.featuredField)}
              cardFields={${JSON.stringify(mp.cardFields ?? {})}}
              onCardClick={(id) => router.push("/marketplace/" + encodeURIComponent(id))}
            />`
    : "";

  // PromoBand JSX — dark LandingCta band
  const promoBandJsx = promoBand
    ? `
            <LandingCta
              ${promoBand.kicker ? `kicker=${JSON.stringify(promoBand.kicker)}` : ""}
              ${promoBand.title ? `headlineAccent=${JSON.stringify(promoBand.title)}` : ""}
              ${promoBand.body ? `body=${JSON.stringify(promoBand.body)}` : ""}
              ${promoBand.cta ? `primaryCta={${JSON.stringify(promoBand.cta)}}` : ""}
            />`
    : "";

  // Hero title lines — split headline across lines for display-scale two-tone effect.
  // The first word becomes line 1, the last word becomes line 3, everything in between
  // is the orange accent on line 2. Falls back gracefully for short titles.
  const titleWords = listingHeadline.trim().replace(/\.$/, "").split(/\s+/);
  let heroTitleJsx;
  if (titleWords.length <= 2) {
    // Short title: first word dark, rest orange
    heroTitleJsx = `${titleWords[0]}<br /><span className="text-[var(--color-secondary)]">${titleWords.slice(1).join(" ")}.</span>`;
  } else {
    // 3+ words: line1 dark, middle orange, last word dark
    const mid = titleWords.slice(1, -1).join(" ");
    heroTitleJsx = `${titleWords[0]}<br /><span className="text-[var(--color-secondary)]">${mid}</span><br />${titleWords[titleWords.length - 1]}.`;
  }

  // Hero search bar component — inlined in the page file
  const heroSearchComponent = heroSearch
    ? `
// Inline hero search bar — navigates to ?q= to seed CatalogGrid
function HeroSearchBar({ itemLabel }: { itemLabel: string }) {
  const router = useRouter();
  const [query, setQuery] = React.useState("");
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = query.trim();
    if (trimmed) router.push("/marketplace?q=" + encodeURIComponent(trimmed));
  };
  return (
    <form
      onSubmit={handleSubmit}
      className="mx-auto mt-8 flex w-full max-w-2xl items-center gap-2"
    >
      <div className="relative flex-1">
        <svg
          className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-text-muted)]"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <circle cx="11" cy="11" r="8" />
          <line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={\`Search \${itemLabel} by name, category, or keyword…\`}
          className="h-12 w-full rounded-full border border-[var(--color-border)] bg-white pl-10 pr-4 text-sm text-[var(--color-text)] shadow-md outline-none focus:ring-2 focus:ring-[var(--color-primary)]/30 placeholder:text-[var(--color-text-disabled,#9ca3af)]"
        />
      </div>
      <button
        type="submit"
        className="h-12 shrink-0 rounded-full bg-[var(--color-secondary)] px-6 text-sm font-semibold text-white transition-opacity hover:opacity-90"
      >
        Search
      </button>
    </form>
  );
}
`
    : "";

  writeFile(
    "app/marketplace/page.tsx",
    `"use client";
// Marketplace listing — P1 public-composed surface (SH.00 LandingShell, no sidebar).
// External visitors browse offerings without a session; the authenticated in-shell
// catalogue is the standard-menu catalogue route.
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import { useRouter } from "next/navigation";
import LandingShell from "@dbp/shell-landing";
import { MeshSection${extraUiImportStr}${footerImport} } from "@dbp/ui";
import CatalogGrid from "@dbp/organisms/catalog-grid";

const CATALOG_CONFIG = ${listingCfg} as Parameters<typeof CatalogGrid>[0];
const NAV_LINKS = ${headerLinks} as Array<{ label: string; href: string }>;
const NAV_ACTIONS = [${JSON.stringify(signIn)}] as Array<{ label: string; href: string }>;${footerConst}
${heroSearchComponent}
export default function MarketplacePage() {
  const router = useRouter();
  return (
    <LandingShell
      nav={{
        code: ${JSON.stringify(manifest.solution)},
        name: ${JSON.stringify(manifest.name)},
        links: NAV_LINKS,
        actions: NAV_ACTIONS,
      }}
      slots={{
        hero: (
          <>
            <MeshSection variant="heroLight" grid className="px-5 pb-24 pt-28 md:px-8 md:pt-36 md:pb-32 lg:px-10">
              <div className="mx-auto max-w-[1200px] text-center">
                <p className="dq-overline mb-6 text-[var(--color-secondary)]">${listingKicker}</p>
                <h1 className="text-[clamp(2.75rem,7.5vw,5.5rem)] font-bold leading-[1.05] tracking-[-0.02em] text-[var(--color-text)]">
                  ${heroTitleJsx}
                </h1>
                ${listingSubtitle ? `<p className="mx-auto mt-6 max-w-[560px] text-base leading-relaxed text-[var(--color-text-secondary)]">${listingSubtitle}</p>` : ""}${heroSearchJsx}
              </div>
            </MeshSection>${featuredCarouselJsx}${promoBandJsx}
            <section className="bg-[var(--color-surface)] py-12 lg:py-16">
              <div className="mx-auto max-w-[1200px] px-5 md:px-8 lg:px-10">
                <CatalogGrid
                  {...CATALOG_CONFIG}
                  onCardClick={(_entityType, id) => router.push("/marketplace/" + encodeURIComponent(id))}
                />
              </div>
            </section>
          </>
        ),
${footerJsx}
      }}
    />
  );
}
`,
  );

  if (detail == null) return;

  const detailVariant = mp.detailVariant ?? "ops";
  const detailMarketing = mp.detailMarketing ?? null;

  const titleFieldFromListing = listing.cardFields?.title ?? "name";
  const detailMerged = {
    titleField: titleFieldFromListing,
    ...detail,
    ...(detailMarketing
      ? {
          ...(detailMarketing.priceFromField != null && { priceFromField: detailMarketing.priceFromField }),
          ...(detailMarketing.timelineField != null && { timelineField: detailMarketing.timelineField }),
          ...(detailMarketing.idealForField != null && { idealForField: detailMarketing.idealForField }),
          ...(detailMarketing.outcomesField != null && { outcomesField: detailMarketing.outcomesField }),
          ...(detailMarketing.showRelated != null && { showRelated: detailMarketing.showRelated }),
          ...(detailMarketing.ctaBand != null && { ctaBand: detailMarketing.ctaBand }),
        }
      : {}),
  };
  const detailCfg = JSON.stringify(detailMerged, null, 2);

  const detailHeroJsx = detailVariant === "marketing"
    ? `        hero: (
          <MarketplaceItemDetail
            entityType=${JSON.stringify(manifest.marketplace.entityType)}
            entityId={id}
            detailVariant="marketing"
            {...(DETAIL_CONFIG as Omit<Parameters<typeof MarketplaceItemDetail>[0], "entityType" | "entityId" | "detailVariant">)}
          />
        ),`
    : `        hero: (
          <section className="bg-[var(--color-surface)] py-10 lg:py-14">
            <div className="mx-auto max-w-[1200px] px-5 md:px-8 lg:px-10">
              <MarketplaceItemDetail
                entityType=${JSON.stringify(manifest.marketplace.entityType)}
                entityId={id}
                {...(DETAIL_CONFIG as Omit<Parameters<typeof MarketplaceItemDetail>[0], "entityType" | "entityId">)}
              />
            </div>
          </section>
        ),`;

  // detail nav links climb one level deeper for footer columns const reuse — none here.
  writeFile(
    "app/marketplace/[id]/page.tsx",
    `"use client";
// Marketplace item detail — P1 public-composed surface (SH.00 LandingShell, no sidebar).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import { useParams } from "next/navigation";
import LandingShell from "@dbp/shell-landing";
import { ${footerImport ? "LandingFooter" : ""} } from "@dbp/ui";
import MarketplaceItemDetail from "@dbp/organisms/marketplace-item-detail";

const DETAIL_CONFIG = ${detailCfg};
const NAV_LINKS = ${headerLinks} as Array<{ label: string; href: string }>;
const NAV_ACTIONS = [${JSON.stringify(signIn)}] as Array<{ label: string; href: string }>;${footerConst}

export default function MarketplaceItemPage() {
  const params = useParams<{ id: string }>();
  const id = typeof params?.id === "string" ? params.id : "";
  return (
    <LandingShell
      nav={{
        code: ${JSON.stringify(manifest.solution)},
        name: ${JSON.stringify(manifest.name)},
        links: NAV_LINKS,
        actions: NAV_ACTIONS,
      }}
      slots={{
${detailHeroJsx}
${footerJsx}
      }}
    />
  );
}
`,
  );
}

function emitMarketplaceRoutes() {
  if (!hasMarketplace) return;

  // Listing config = the marketplace block minus the nested `detail` sub-key.
  // headline/lede are stripped from CATALOG_CONFIG on all paths — CatalogGrid is
  // body-only; the title is owned by the shell (MeshSection hero on DXP public,
  // PageHeader on TransactionShell in-shell pages).
  const { detail, ...listing } = manifest.marketplace;
  // `lede` (subtitle) is dropped here — Amendment D-2 (component-architecture-standard.md §7b):
  // PageHeader's subtitle is accepted-but-ignored, so there's nothing to interpolate it into.
  const { headline: mpHeadline, lede: _mpLede, ...listingWithoutHeader } = listing;
  const listingCfg = JSON.stringify(listingWithoutHeader, null, 2);

  // P1 dual-surface (DXP): the public-composed marketplace — PublicNavHeader + a
  // full-bleed CatalogGrid band + LandingFooter, no workspace sidebar. The
  // authenticated in-shell catalogue is the standard-menu catalogue route. For
  // non-DXP solutions /marketplace stays in-shell (the original emit below).
  if (isDXP) {
    emitPublicMarketplaceRoutes(listing, listingCfg, detail);
    return;
  }

  writeFile(
    "app/(authenticated)/marketplace/page.tsx",
    `"use client";
// Marketplace listing — APP.F10. Body-only page.
// Layout: collection-marketplace-grid
// TransactionShell provided by app/(authenticated)/layout.tsx
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@dbp/ui";
import CatalogGrid from "@dbp/organisms/catalog-grid";

const CATALOG_CONFIG = ${listingCfg} as Parameters<typeof CatalogGrid>[0];

export default function MarketplacePage() {
  const router = useRouter();
  return (
    <>
      <PageHeader title=${JSON.stringify(mpHeadline ?? manifest.name)} />
      <CatalogGrid
        {...CATALOG_CONFIG}
        onCardClick={(_entityType, id) => router.push("/marketplace/" + encodeURIComponent(id))}
      />
    </>
  );
}
`,
  );

  if (detail == null) return;

  // Derive titleField from the listing's cardFields.title so the detail H1
  // always uses the same field as the catalog card title. Fall back to "name".
  const titleFieldFromListing = listing.cardFields?.title ?? "name";
  const detailWithTitle = { titleField: titleFieldFromListing, ...detail };
  const detailCfg = JSON.stringify(detailWithTitle, null, 2);
  // No page-level PageHeader (Amendment D-2 (component-architecture-standard.md §7b)) — the top bar's breadcrumb terminal
  // crumb is the page title; the "Submit Enquiry" CTA moves into a content-body
  // toolbar. suppressHeader={true} removes the bespoke hero block from
  // MarketplaceItemDetail.
  writeFile(
    "app/(authenticated)/marketplace/[id]/page.tsx",
    `"use client";
// Marketplace item detail — APP.F11. Body-only page.
// Layout: collection-marketplace-detail
// TransactionShell provided by app/(authenticated)/layout.tsx
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { useParams, useRouter } from "next/navigation";
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import MarketplaceItemDetail from "@dbp/organisms/marketplace-item-detail";
import { Button } from "@dbp/ui";

const DETAIL_CONFIG = ${detailCfg};

export default function MarketplaceItemPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = typeof params?.id === "string" ? params.id : "";
  return (
    <CanvasLayout
    >
      <div className="flex justify-end gap-2 mb-4">
        <Button variant="navy" onClick={() => router.push(\`/marketplace/\${id}/request\`)}>Submit Enquiry</Button>
      </div>
      <MarketplaceItemDetail
        entityType=${JSON.stringify(manifest.marketplace.entityType)}
        entityId={id}
        suppressHeader={true}
        onNavigate={(href) => router.push(href)}
        {...(DETAIL_CONFIG as Omit<Parameters<typeof MarketplaceItemDetail>[0], "entityType" | "entityId">)}
      />
    </CanvasLayout>
  );
}
`,
  );

  // Every marketplace listing is requestable — emit the /request sub-route unconditionally.
  writeFile(
    "app/(authenticated)/marketplace/[id]/request/page.tsx",
    `"use client";
// Marketplace listing request — APP.F22.
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import { toast } from "@dbp/ui";
import SubmitRequestForm from "@dbp/organisms/service-offering-request";

export default function MarketplaceRequestPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = typeof params?.id === "string" ? params.id : "";

  function handleSuccess(requestId: string) {
    toast({ title: "Request submitted", description: \`Reference: \${requestId}\` });
    router.push(\`/marketplace/\${id}\`);
  }

  return (
    <div className="mx-auto max-w-lg py-8">
      <SubmitRequestForm
        serviceId={id}
        onSuccess={handleSuccess}
        onCancel={() => router.push(\`/marketplace/\${id}\`)}
      />
    </div>
  );
}
`,
  );
}

/**
 * /copilot → SH.02 TransactionShell with @dbp/organisms/copilot-page (APP.F15) in the
 * `main` slot. Type 6 Conversational layout: context panel suppressed (no AssistantPanel
 * slot), sidebar collapsed to icon-only via nav.defaultCollapsed = true.
 * Emitted only when manifest.copilot is present.
 */
function emitCopilotRoute() {
  routeBreadcrumbEntries.push(["/copilot", [{ label: manifest.solution, href: "/" }, { label: "AI Cockpit" }]]);
  if (!hasCopilot) {
    // No manifest.copilot block — emit a placeholder AI cockpit page so this
    // route is always generator-owned regardless of manifest configuration.
    writeFile(
      "app/(authenticated)/copilot/page.tsx",
      `"use client";
// AI Cockpit — auto-emitted placeholder (no manifest.copilot block configured).
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import { PageHeader } from "@dbp/ui";

export default function CopilotPage() {
  return (
    <CanvasLayout header={<PageHeader title="AI Cockpit" />}>
      <p className="text-sm text-[var(--color-text-muted)]">Configure a <code>copilot:</code> block in SOLUTION.md to enable this feature.</p>
    </CanvasLayout>
  );
}
`,
    );
    return;
  }
  const cfg = JSON.stringify(manifest.copilot, null, 2);
  writeFile(
    "app/(authenticated)/copilot/page.tsx",
    `"use client";
// Copilot page — APP.F15. Body-only page (single-header rule §4.4, Amendment D-2:
// the breadcrumb terminal crumb IS the page title — see app/route-breadcrumbs.ts
// for the "AI Cockpit" label; do not pass a deprecated CanvasLayout header here).
// TransactionShell provided by app/(authenticated)/layout.tsx
// Generated by scaffold-solution — do not edit (run with --force to regenerate)
import * as React from "react";
import { CanvasLayout } from "@dbp/shell-transaction/layouts";

import CopilotPage, { type CopilotPageConfig } from "@dbp/organisms/copilot-page";

// Cast to the component's exported config TYPE (the real contract), not its param
// type — the param is Record<string, unknown>, which would make COPILOT_CONFIG.title
// 'unknown'.
const COPILOT_CONFIG = { ...(${cfg}) } as CopilotPageConfig;

export default function CopilotRoute() {
  return (
    <CanvasLayout
    >
      <CopilotPage {...COPILOT_CONFIG} />
    </CanvasLayout>
  );
}
`,
  );
}

// ─── Step 5: Write resolved solution/_arch/SOLUTION.md ───────────────────────

const blueprintVersion = registry.blueprint_version ?? "platform/v1.5.0";

// Generator provenance — identifies WHICH generator produced this app.
// blueprint_version (e.g. platform/v1.0.0) is the same on every app regardless
// of which generator commit emitted it, so it cannot tell you why two apps
// diverged. The generator's own git short-SHA can: apps with different
// `generator_rev` were emitted by different generator code and may differ
// structurally. Re-running --force re-stamps it. Best-effort — falls back to
// "unknown" outside a git checkout (e.g. a published tarball).
let generatorRev = "unknown";
try {
  generatorRev = execFileSync("git", ["rev-parse", "--short", "HEAD"], {
    cwd: REPO_ROOT,
    encoding: "utf8",
  }).trim();
} catch {
  // not a git checkout — leave as "unknown"
}
// One timestamp for the whole emit so every stamped file agrees.
const generatedAt = new Date().toISOString();

const resolvedModules = manifest.modules.map((mod) => {
  const shellMeta = SHELL_META[resolveShellId(mod.scaffold)];
  return {
    id: mod.id,
    name: mod.name,
    journey_stage: mod.journey,
    scaffold: mod.scaffold,
    shell_package: shellMeta?.packageName ?? "unknown",
    route: `/${moduleRoutePath(mod)}`,
    features: mod.features.map((f) => ({
      id: f.id,
      role: f.role,
      slot: f.slot ?? featureMap.get(f.id)?.slot ?? "main",
      package: FEATURE_PKG[f.id] ?? "unknown",
      wires: f.wires,
    })),
  };
});

const resolvedServices = consumedServices.map((id) => {
  const meta = SERVICE_META[id];
  return {
    id,
    package: meta?.packageName ?? "unknown",
    mount_path: meta?.basePath ?? "unknown",
    route_handler: `app/api/platform/${meta?.dir ?? id.toLowerCase()}/[[...path]]/route.ts`,
  };
});

const resolvedFrontmatter = {
  platform: manifest.platform,
  solution: manifest.solution,
  name: manifest.name,
  blueprint_version: blueprintVersion,
  platform_version: blueprintVersion,
  generated_at: generatedAt,
  generator_rev: generatorRev,
  deploy_layer: manifest.deploy_layer,
  journey_stages: manifest.journey_stages,
  app_package: appName,
  app_dir: `apps/${solutionDir}`,
  consumes_platform_services: resolvedServices,
  modules: resolvedModules,
  theme_applied: manifest.theme ?? null,
};

const resolvedYaml = YAML.stringify(resolvedFrontmatter, { defaultStringType: "PLAIN" });

const resolvedSolutionMd = `---
${resolvedYaml}---

# Resolved Solution Architecture — ${manifest.name}

This file is **generated** by \`scaffold-solution\`. It records what was actually wired,
not what was declared in the input manifest. Do not edit by hand — re-run the generator.

## Platform Services Wired (Layer 06)

${resolvedServices
  .map(
    (s) =>
      `- **${s.id}** → \`${s.package}\` mounted at \`${s.mount_path}\` via \`${s.route_handler}\``,
  )
  .join("\n")}

## Modules Scaffolded (Layer 07)

${resolvedModules
  .map(
    (m) =>
      `### ${m.id} — ${m.name}\n- Shell: \`${m.scaffold}\` (\`${m.shell_package}\`) | Stage: ${m.journey_stage} | Route: \`${m.route}\`\n` +
      m.features
        .map((f) => `- Feature \`${f.id}\` as \`${f.role}\` in slot \`${f.slot}\` → \`${f.package}\` wires \`${f.wires.join(", ")}\``)
        .join("\n"),
  )
  .join("\n\n")}

## Theme

${manifest.theme ? Object.entries(manifest.theme).map(([k, v]) => `- \`${k}\`: \`${v}\``).join("\n") : "No overrides — using @dbp/design-tokens defaults."}
`;

writeFile("solution/_arch/SOLUTION.md", resolvedSolutionMd);

// ─── Step 5a(b): Emit developer-experience files (solution-owned: create-if-missing) ──
// These are generated once from manifest data as a useful starting point.
// Operators customise them in place; --force regen never overwrites them.

const servicesList = resolvedServices
  .map((s) => `- **${s.id}** → \`${s.package}\` at \`${s.mount_path}\``)
  .join("\n");

const modulesList = resolvedModules
  .map((m) => `- **${m.route}** — ${m.name} (\`${m.scaffold}\`)`)
  .join("\n");

const envVarsList = [
  ...(consumedServices.includes("PS.AUTH")
    ? [
        "DBP_AUTH_SESSION_SECRET=<generate with: openssl rand -hex 32>",
        "# Entra SSO (optional — only needed for Microsoft OIDC login):",
        "ENTRA_TENANT_ID=",
        "ENTRA_CLIENT_ID=",
        "ENTRA_CLIENT_SECRET=",
      ]
    : []),
  ...(consumedServices.includes("PS.DATA")
    ? ["DATABASE_URL=postgresql://localhost:5432/${solutionDir}"]
    : []),
  ...(consumedServices.includes("PS.NOTIF")
    ? [
        "NOTIF_EMAIL_TRANSPORT=smtp   # or: msgraph",
        "SMTP_URL=smtp://user:pass@mailhost:587",
        "SMTP_FROM=noreply@example.com",
        "# MS Graph transport:",
        "MSGRAPH_TENANT_ID=",
        "MSGRAPH_CLIENT_ID=",
        "MSGRAPH_CLIENT_SECRET=",
        "MSGRAPH_SENDER_UPN=",
      ]
    : []),
].join("\n");

// .env.example — generator-owned (always re-emitted so it stays in sync with services)
const envExampleContent = `# ${manifest.name} — Environment Variables
# Copy this file to .env.local and fill in real values before running.
# Generated by scaffold-solution — re-emitted on every regen.
#
# REQUIRED ─────────────────────────────────────────────────────────────────────
${consumedServices.includes("PS.AUTH") ? `
# Auth secret — must be a strong random string (32+ hex chars).
# Generate: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
DBP_AUTH_SESSION_SECRET=
` : ""}${consumedServices.includes("PS.DATA") ? `
# Postgres — TWO connection strings (Supabase/Azure standard):
#   DATABASE_URL — POOLED (PgBouncer/Supavisor, port 6543 on Supabase), app runtime.
#                  @dbp/platform-db connects with prepare:false for pooler mode.
#                  Leave empty to use the in-memory adapter (dev only).
#   DIRECT_URL   — DIRECT connection (port 5432), migrations/drizzle-kit ONLY.
#                  Never point the app runtime at it (Supabase direct is
#                  IPv6-only; IPv4-only hosts like Vercel cannot reach it).
DATABASE_URL=postgresql://localhost:5432/${solutionDir}
DIRECT_URL=
` : ""}
# OPTIONAL ─────────────────────────────────────────────────────────────────────
${consumedServices.includes("PS.AUTH") ? `
# Identity provider selection (default: password — dev in-memory form).
# Set to one of: password | ldap | entra | entra-external
DBP_IDP_PROVIDER=password

# --- Entra ID (workforce) — DBP_IDP_PROVIDER=entra ---
ENTRA_TENANT_ID=
ENTRA_CLIENT_ID=
ENTRA_CLIENT_SECRET=
# Optional: override the OIDC redirect URI (defaults to NEXT_PUBLIC_APP_URL/api/platform/auth/callback)
ENTRA_REDIRECT_URI=

# --- Entra External ID / CIAM — DBP_IDP_PROVIDER=entra-external ---
ENTRA_EXTERNAL_TENANT_NAME=
ENTRA_EXTERNAL_CLIENT_ID=
ENTRA_EXTERNAL_CLIENT_SECRET=
ENTRA_EXTERNAL_REDIRECT_URI=

# --- On-prem Active Directory via LDAP — DBP_IDP_PROVIDER=ldap ---
LDAP_URL=ldap://dc01.corp.local
LDAP_BIND_DN=CN=svc-dbp,DC=corp,DC=local
LDAP_BIND_PASSWORD=
LDAP_BASE_DN=DC=corp,DC=local
# Optional: override the user search filter (default: (mail={{email}}))
LDAP_USER_FILTER=
` : ""}${consumedServices.includes("PS.NOTIF") ? `
# Notification transport: smtp (default) | msgraph
# (Names below match what @dbp/ps-notif actually reads.)
NOTIF_EMAIL_TRANSPORT=smtp
# Capture emails in memory instead of sending (dev/test):
NOTIF_EMAIL_CAPTURE=
# SMTP transport (connection string):
SMTP_URL=smtp://user:pass@mailhost:587
SMTP_FROM=noreply@example.com
# MS Graph transport:
MSGRAPH_TENANT_ID=
MSGRAPH_CLIENT_ID=
MSGRAPH_CLIENT_SECRET=
MSGRAPH_SENDER_UPN=
` : ""}${rateLimitEnabled ? `
# App-level rate limiting (GAP-BRS-5) — defence-in-depth only; WAF/API-gateway
# rate limiting remains the primary control. Two coarse route classes.
DBP_RATE_LIMIT_ENABLED=true
DBP_RATE_LIMIT_AUTH_WINDOW_S=60
DBP_RATE_LIMIT_AUTH_MAX=10
DBP_RATE_LIMIT_DEFAULT_WINDOW_S=60
DBP_RATE_LIMIT_DEFAULT_MAX=120
` : ""}
NEXT_PUBLIC_APP_URL=http://localhost:3000
NODE_ENV=development
# Set to 1 to skip lib/env.ts validation (CI/build escape hatch):
SKIP_ENV_VALIDATION=
`;

// .env.local — solution-owned (create-if-missing on first scaffold; NEVER overwritten).
// Pre-fills a generated dev secret so the app starts immediately without manual setup.
const devSecret = randomBytes(32).toString("hex");
const envLocalContent = `# ${manifest.name} — Local dev environment (auto-generated, gitignored)
# This file was created by scaffold-solution on first run.
# It is NEVER overwritten on --force regen — edit freely.
#
${consumedServices.includes("PS.AUTH") ? `DBP_AUTH_SESSION_SECRET=${devSecret}` : ""}
${consumedServices.includes("PS.DATA") ? `DATABASE_URL=postgresql://localhost:5432/${solutionDir}` : ""}
NOTIF_EMAIL_TRANSPORT=console
NODE_ENV=development
NEXT_PUBLIC_APP_URL=http://localhost:3000
`;

const agentsMd = `# ${manifest.name} — Agent Rules

Generated by DBP scaffold-solution for **${manifest.solution}**. Update as the solution evolves.

## File ownership contract

### Generator-owned — do NOT hand-edit

Running \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\` overwrites these:

- \`app/\` — all Next.js pages, API route mounts, chrome, providers, middleware
- \`solution/_arch/SOLUTION.md\` — resolved wiring record
- \`package.json\`, \`next.config.ts\`, \`tsconfig.json\`, PostCSS, Tailwind configs

> ⚠️ **DATA-LOSS WARNING — \`--force\` overwrites and deletes generator-owned files.**
> Any hand-edit to an \`app/\` page is **permanently destroyed** on the next regen, and a
> page dropped from the manifest is deleted outright. Do **not** inject custom UI by editing
> a generated page. Instead, give the module a \`pageComponent\` in the manifest pointing at a
> \`solution/pages/<name>.tsx\` component — that file is solution-owned and survives every regen.
> The generator runs a safety check and will **refuse** to overwrite a generator-owned page whose
> \`// Generated by scaffold-solution\` header is missing (i.e. one you hand-replaced); pass
> \`--allow-dirty\` only if you intend to discard those edits.

### Solution-owned — edit freely, never overwritten

- \`instrumentation.ts\` — bootstrap: schema, workflow, and seed registration
- \`solution/entities/**\` — Zod entity schemas (source of truth for data shape)
- \`solution/workflows/**\` — workflow definitions
- \`solution/modules/**\` — module configs
- \`app/api/platform/data/[[...path]]/route.ts\` — data route (hand-seeded data)
- \`AGENTS.md\`, \`CLAUDE.md\`, \`.ai/context.md\`, \`docs/\`

> **docs/ emit-once contract:** every file under \`docs/\` (the STCB-shaped vault spine —
> 00-MOC through 10-Solutions, HLAD, LLAD, guides, runbooks) is written ONCE on first
> scaffold and never again — \`--force\` never overwrites or deletes an existing
> \`docs/**\` file, even a generator-emitted one. Edit any of them freely; a regen only
> fills in files that don't exist yet (e.g. a newly-added module's folder).

## Platform services wired (Layer 06)

Never reimplement these — they are provided and wired by ID:

${servicesList}

## Routes scaffolded (Layer 07)

${modulesList}

## Dev rules

- Zod schemas in \`solution/entities/\` are the source of truth. TypeScript types via \`z.infer<typeof Schema>\` only.
- After any regen with PS.DATA, verify data endpoints: \`curl http://localhost:3000/api/platform/data/entities/<type> -H "x-tenant-id: tenant-alpha"\`
- Stale \`instrumentation.ts\` that references removed seed exports will break the build — grep for the old name and update.
- Run \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\` to regenerate; never use \`git clean\` at the repo root (kills sibling worktrees).
${isPersistentStorage ? `
## Database migrations (non-negotiable)

- **Every database change ships as a committed migration file.** No schema lives only in a
  running database or a one-off SQL command — if it isn't a migration in the repo, it can't be
  replayed to staging/prod and it doesn't exist. This applies to tables, columns, indexes,
  constraints, RLS policies, triggers, functions, grants, and seed-of-record data.
- **Layout:** solution schema → \`db/migrations/${solutionDir}/NNNN_description.sql\` (forward-only,
  numbered, idempotent where possible). Platform baseline (\`data\`/\`platform\`/\`audit\`/… schemas,
  RLS, \`dbp_app\`) is **vendored** into \`db/migrations/platform/\` — verbatim copies owned by
  \`@dbp/platform-db\`, kept in sync via \`scripts/sync-platform-migrations.mjs\` (re-run + commit on
  package bump). **Never hand-edit those** — request a platform change and re-sync.
- **Replay any environment** from the repo with \`scripts/db-migrate.mjs\` (env-agnostic — reads
  \`DATABASE_URL\`/\`DIRECT_URL\`; applies platform baseline then \`db/migrations/**\`). This is how a
  real dev/staging/prod DB is stood up.
- **Ordering (G7 — fixed):** the vendored \`0007_entity_id_text\` drops and recreates the
  \`api.entities\` view around its \`data.entity.id\` type change, so migrations apply cleanly in
  plain numeric order (\`0000\`→\`0006\`). \`scripts/db-migrate.mjs\` applies platform files in numeric
  order — no special-casing needed.
- First-time setup: run \`pnpm db:snapshot\` once against a real Postgres to generate the
  committed \`db/schema.sql\` baseline (requires \`pg_dump\`; see \`scripts/db-snapshot.sh\`). Until it
  exists the CI snapshot-diff step no-ops (green); once committed it becomes a hard gate.

### Separation of concerns — schema vs data

| Kind | Where | Runs in prod? | Rule |
|---|---|---|---|
| **Schema (DDL)** — tables, columns, indexes, constraints, RLS, triggers, functions, views | \`db/migrations/${solutionDir}/NNNN_description.sql\` | ✅ every env | DDL only — no business-data \`INSERT/UPDATE/DELETE\`. |
| **Data of record** — canonical/reference data prod needs (lookups, frameworks) | \`db/migrations/${solutionDir}/NNNN_data_description.sql\` (or a \`data/\` subdir) | ✅ every env | DML only — no DDL. Named \`*_data_*\` so it's visibly separate and reviewed as data. |
| **Dev/test/demo seed** | \`solution/fixtures/*\` (app bootstrap, idempotent) | ❌ never | Not a migration. Seeds via \`registerAndSeedData()\`; do NOT put demo data in \`db/migrations/**\`. |

\`scripts/check-migrations.mjs\` enforces this: a schema migration containing data DML, or a data
migration containing DDL, fails the check (locally + in CI).

### How this is enforced (not just documented)

1. **The app cannot do DDL.** The runtime role \`dbp_app\` has no \`CREATE\`/\`ALTER\`/\`DROP\` and owns
   no objects — it can only run tenant-scoped DML under RLS. Structural change is *only* possible
   by applying a migration as the DB owner (\`DIRECT_URL\`). Ad-hoc schema drift from the app is
   physically impossible.
2. **CI gate** (\`.github/workflows/db-migrations.yml\`, on any \`db/**\` change): platform-drift
   check → migration-hygiene lint → **replay all migrations on a fresh DB** → **schema-snapshot
   diff**. \`db/schema.sql\` is a committed \`pg_dump --schema-only\` of a fresh replay; any structural
   change must regenerate it (\`pnpm db:snapshot\`), so the **DDL delta shows up in the PR diff**
   and CI fails if it isn't captured — i.e. structural changes are flagged for review by
   construction.
3. **Review gate:** \`.github/CODEOWNERS\` routes every \`db/**\` change to the DB owners (set the real
   team + enable "Require review from Code Owners" in branch protection, plus require the
   \`db-migrations\` check to pass before merge).
` : ""}`;

const claudeMd = `# ${manifest.name} — Claude Code Rules

See **AGENTS.md** for the full file ownership contract and platform rules.

## Quick reference

| What | Where |
|---|---|
| Regenerate app | \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\` |
| Entity schemas | \`solution/entities/\` — Zod, source of truth |
| Bootstrap seam | \`instrumentation.ts\` — hand-edit, never overwritten |
| Docs | \`docs/\` — hand-edit, never overwritten |

## Solution

- ID: \`${manifest.solution}\`  Platform: \`${manifest.platform}\`  Blueprint: \`${blueprintVersion}\`
- Deploy layer: ${manifest.deploy_layer ?? "L07"}
- Generated: \`${generatedAt}\` from generator \`${generatorRev}\` — if two apps behave differently, compare this line; different \`generator_rev\` = different generation, re-run \`--force\` to converge.

## Non-negotiables

- Layer 06 platform services are never reimplemented in solution code.
- Generator-owned files (\`app/\`, configs) are not hand-edited — change the manifest and regen. ⚠️ \`--force\` **destroys** hand-edits to \`app/\` pages. To inject custom UI, set a module's \`pageComponent\` to a \`solution/pages/<name>.tsx\` component (solution-owned, survives regen) — never edit the generated page. See AGENTS.md "File ownership contract".
- Analysis output goes to \`docs/\`, not chat. Plans to \`docs/plans/\`.
`;

// Generated Control Slice items #1/#2: the portable subset of the monorepo's own
// non-negotiables (docs/03-features/specs/spec-generated-control-slice-2026-07-11.md
// §1c/§2). Deliberately excludes the monorepo's "subagent isolation & the
// destructive generator" section (worktree/sibling-branch guidance with zero
// relevance inside a standalone repo — §1c explicitly flags it as a non-travel
// item) and monorepo-only mechanisms with no standalone analog (Storybook,
// the ops-map file, the organism catalogue).
const factoryNonNegotiablesBlock = `## Platform non-negotiables (from the DBP Blueprint factory)

This solution was generated by the DBP Blueprint factory. These rules travel with
every solution the factory produces — they are refreshed on every \`--force\` regen,
so keep hand-edits out of this block (see AGENTS.md "File ownership contract" for
what is safe to edit).

- **Layer 06 platform services are never reimplemented.** Auth, RBAC, audit,
  notifications, search, and workflow are provided and wired by ID — solution code
  calls them, it does not rebuild them.
- **Zod schemas are the source of truth.** TypeScript types come from
  \`z.infer<typeof Schema>\` — never hand-authored interfaces for data models.
- **Import-boundary rules are a build failure, not a warning.** \`@dbp/config/eslint\`
  enforces the layer split; \`pnpm lint\`/\`pnpm verify\` must be green before merge.
- **The manifest must match the built product.** If \`solution/_arch/SOLUTION.md\`
  (or the source \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`) no longer
  describes what this repo actually does, reconcile it — don't let it silently drift.
- **Supersede, don't duplicate.** When you change documented behavior, find and mark
  the old claim superseded (in \`docs/\`) rather than leaving two conflicting versions.
- **Analysis and plans are durable output, not chat.** Audits, gap analyses, and
  design decisions go in \`docs/\`; implementation plans go in \`docs/plans/\`; only
  genuine throwaway (scratch commands, debug dumps) belongs outside version control.
- **Update \`PROGRESS.md\` every session.** See that file's header for the entry
  format. This is the running narrative of the build — keeping it current is part
  of "done".`;

const aiContextMd = `---
solution: ${manifest.solution}
name: ${manifest.name}
platform: ${manifest.platform}
blueprint_version: ${blueprintVersion}
generated_at: ${generatedAt}
generator_rev: ${generatorRev}
---

# AI Context — ${manifest.name}

This file gives AI agents working in this app enough context to make good decisions without reading the full codebase.

## What this app is

${manifest.name} (\`${manifest.solution}\`) is a ${manifest.platform} solution built on the DBP Blueprint.
It is a **generated app** — the \`app/\` directory and config files are owned by the scaffold generator.
Hand-authored code lives in \`solution/\` and \`instrumentation.ts\`.

## Platform services in scope

${servicesList}

## Routes

${modulesList}

## File ownership

- **Generator-owned** (regen with \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\`): \`app/\`, \`package.json\`, \`next.config.ts\`, \`middleware.ts\`, \`solution/_arch/\`
- **Solution-owned** (hand-edit freely): \`solution/entities/\`, \`solution/workflows/\`, \`instrumentation.ts\`, \`docs/\`, this file

## Key patterns

- Entity types are declared in \`solution/entities/<type>.ts\` as Zod schemas. Never hand-write TypeScript interfaces for data models.
- The data bootstrap (\`instrumentation.ts\`) calls \`registerAndSeedData(dataSvc)\` from the generated seed module. This is the ONLY entry point — do not call removed exports.
- All platform capabilities (auth, RBAC, audit, search, workflow, notifications) arrive via \`/api/platform/<service>/\` mounts — never re-derive them.
`;

const gettingStartedMd = `# Getting Started — ${manifest.name}

## Prerequisites

- Node.js 20+, pnpm 9+
- Access to the \`dbp_blueprint_build\` monorepo
${consumedServices.includes("PS.DATA") ? "- PostgreSQL instance (or configure DATABASE_URL to a hosted service)" : ""}
${consumedServices.includes("PS.AUTH") ? "- Microsoft Entra app registration (optional — local dev uses the credential form fallback)" : ""}

## Environment setup

Copy \`.env.example\` to \`.env.local\` and fill in the values:

\`\`\`bash
cp .env.example .env.local
\`\`\`

Required variables:

\`\`\`env
${envVarsList || "# No environment variables required"}
\`\`\`

## Running locally (in the monorepo)

\`\`\`bash
# From the repo root — install all packages
pnpm install

# Start this app only
pnpm --filter @dbp/app-${solutionDir} dev

# Or start all apps
pnpm dev
\`\`\`

The app starts at \`http://localhost:3000\` (port may differ if running multiple apps).

## Regenerating the scaffold

Generator-owned files (\`app/\`, configs) should not be hand-edited. To update them:

1. Edit \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\` (the solution manifest)
2. Run: \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\`
3. Verify data endpoints still return rows (if PS.DATA is wired)

## Running tests

\`\`\`bash
pnpm --filter @dbp/app-${solutionDir} test
\`\`\`

## Building

\`\`\`bash
pnpm --filter @dbp/app-${solutionDir} build
\`\`\`

## See also

- [Overview & docs index](00-overview/README.md)
- [Architecture](01-architecture/README.md)
- [Customization guide](02-guides/customization.md)
- [Runbooks](03-runbooks/)
- [Resolved architecture](../solution/_arch/SOLUTION.md)
`;

const solutionOverviewMd = `# Solution Overview — ${manifest.name}

**ID:** \`${manifest.solution}\`  |  **Platform:** \`${manifest.platform}\`  |  **Blueprint:** \`${blueprintVersion}\`

## Purpose

_Update this section with the business purpose of this solution._

## Journey stages

${manifest.journey_stages.map((s) => `- Stage ${s}`).join("\n")}

## Platform services (Layer 06)

These are wired, not built. Each service is a platform capability consumed via its API mount:

${resolvedServices
  .map(
    (s) =>
      `### ${s.id}\n- Package: \`${s.package}\`\n- Mount: \`${s.mount_path}\`\n- Handler: \`${s.route_handler}\``,
  )
  .join("\n\n")}

## Modules (Layer 07)

${resolvedModules
  .map(
    (m) =>
      `### ${m.name} (\`${m.id}\`)\n- Route: \`${m.route}\`  Shell: \`${m.scaffold}\`\n` +
      m.features.map((f) => `- Feature \`${f.id}\` (\`${f.role}\`) → \`${f.package}\``).join("\n"),
  )
  .join("\n\n")}

## Theme

${manifest.theme ? Object.entries(manifest.theme).map(([k, v]) => `- \`${k}\`: \`${v}\``).join("\n") : "Using @dbp/design-tokens defaults (DQ canonical brand)."}
`;

const customizationGuideMd = `# Customization Guide — ${manifest.name}

## What you can change

### Safe to hand-edit (solution-owned)

| Path | What it controls |
|---|---|
| \`solution/entities/<type>.ts\` | Zod schema + seed data for an entity type |
| \`solution/workflows/\` | Workflow definitions |
| \`solution/modules/\` | Module-level configs |
| \`instrumentation.ts\` | App bootstrap (schema/seed registration) |
| \`docs/\` | Project documentation |
| \`AGENTS.md\`, \`CLAUDE.md\`, \`.ai/context.md\` | AI agent context |

### Change via the manifest (then regen)

Edit \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\` and run \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\` to update:

- Adding or removing modules (pages, routes)
- Changing features on a module (entity-list, LVE, analytics, etc.)
- Adding or removing platform services
- Theme tokens (primary colour, accent, font, radius)
- Home page composition (hero, features, how-it-works, CTA)
- Marketplace configuration

### Do NOT hand-edit

These are generator-owned and will be overwritten on the next regen:

- \`app/\` — all Next.js pages, API route mounts, chrome, providers, middleware
- \`package.json\`, \`next.config.ts\`, \`tsconfig.json\`, PostCSS/Tailwind configs
- \`solution/_arch/SOLUTION.md\` — this is generated output, not an input

## Adding a new entity type

1. Add an \`entities:\` block to \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`:
   \`\`\`yaml
   entities:
     - type: my-entity
       label: My Entity
       fields:
         - { name: title, type: string, label: Title }
       seed:
         - { id: "1", title: "Example" }
   \`\`\`
2. Regen: \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\`
3. A Zod schema is emitted to \`solution/entities/my-entity.ts\` (solution-owned from that point)

## Adding a custom adapter

For domain data not in the generic entity store (e.g. a discovery catalogue), add a solution-owned adapter:

1. Create \`solution/adapters/<name>.ts\` with your domain schema + data
2. Import and register it in \`app/api/platform/data/[[...path]]/route.ts\` (solution-owned)
3. Wire your page to the adapter's entity type

## Theming

Set theme tokens in the manifest \`theme:\` block and regen. Tokens available:

- \`primary\` — primary brand colour (hex)
- \`accent\` — accent colour (hex)
- \`font-sans\` — body font family
- \`radius\` — base border radius

See \`docs/01-Architecture/\` in the monorepo for the full token reference.
`;

// ─── Numbered docs spine (mirrors the DQ Blueprint Factory docs convention) ───
// Numbered folders = clear, stable locations. Every generated solution ships the
// same spine: overview · architecture · guides · runbooks · templates · decisions.

const pageFrameContractMd = `# Page-Frame Contract

One rule that keeps every page consistent: **the shell/layout owns the page frame;
features render body-only.**

- The shell (\`@dbp/shell-transaction\`) provides the top bar, sidebar, footer, and —
  via \`CanvasLayout\`/\`CatalogueLayout\` — the \`PageHeader\` (title + breadcrumb).
- Do **not** add a second \`PageHeader\` inside a feature mounted in \`slots.main\`.
- Custom pages rendered directly in \`slots.main\` (no layout) SHOULD render their own
  \`PageHeader\` with a breadcrumb (see the detail/queue templates in \`04-templates/\`).

## Gotchas the templates already handle

- \`FilterBar\` takes props (\`searchValue\`, \`chips\`, …) — it does NOT wrap children.
- \`Pagination\` takes \`{ page, pageSize, total, onPageChange }\` — not \`totalPages\`.
- Don't use \`FieldLabel\` for form inputs (it renders uppercase). Use a plain
  \`<label className="text-sm font-medium">\`.
- Filtering uses the SegmentedControl pills (with count badges). KPI scorecards are
  display-only metrics — never status-count duplicates of the tabs.
`;

const deploymentRunbookMd = `# Runbook — Deployment

**Solution:** ${manifest.name} (\`${manifest.solution}\`)

## Prerequisites
- Node 20+, pnpm
- Env vars set (see \`.env.example\`): ${HAS_AUTH ? "`DBP_AUTH_SESSION_SECRET`, " : ""}${consumedServices.includes("PS.DATA") ? "`DATABASE_URL` (when persistent), " : ""}plus any provider keys.

## Build & deploy
\`\`\`bash
pnpm --filter @dbp/app-${solutionDir} build
# deploy the build output via your platform (Vercel/containers/etc.)
\`\`\`

## Post-deploy verification
1. App boots without errors (\`/\` and \`/login\` return 200).
${consumedServices.includes("PS.DATA") ? "2. Data endpoints return rows — curl `/api/platform/data/entities/<type>` with the tenant header.\n" : ""}3. Auth flow works (sign in, session persists across reload).

## Rollback
Redeploy the previous build artefact / git tag. No destructive data migrations run on deploy by default.
`;

const incidentRunbookMd = `# Runbook — Incident Response

**Solution:** ${manifest.name} (\`${manifest.solution}\`)

## Triage
1. Confirm scope — one page, one service, or app-wide?
2. Check the platform-service mounts (\`/api/platform/*\`) for 5xx.
3. Check recent deploys / config changes first.

## Common failure modes
- **"Entity not registered"** → the route chunk didn't bootstrap schemas/seed. Verify \`instrumentation.ts\` and the data route self-bootstrap.
- **Auth logout loop** → session shape mismatch; \`/session\` must return \`{ session, user }\`.
- **Empty surfaces** → entity declared but not seeded; check the manifest \`entities:\` block.

## Escalation
Capture the failing request (URL, status, response body) and the deploy SHA before escalating.
`;

const declaredFlags = manifest.feature_flags ?? [];
const featureFlagsRunbookMd = `# Runbook — Feature Flags & Configuration

**Solution:** ${manifest.name} (\`${manifest.solution}\`)

Most behaviour is manifest-driven (\`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`) and applied at generation
time. Runtime configuration lives in environment variables.

| Concern | Where | Notes |
|---------|-------|-------|
| Modules / pages | manifest \`modules:\` | Regen to apply |
| Platform services | manifest \`consumes_platform_services:\` | Regen to apply |
| Theme | manifest \`theme:\` | Regen to apply |
| Footer / shortcuts | manifest \`footer:\` | Regen to apply |
| Secrets / DB | \`.env\` | Runtime; never commit |
| Feature flags | \`feature_flags:\` block + env vars (below) | Manifest default regen; env var is runtime |

To change manifest-driven config: edit the manifest, run \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\`, verify.

## Feature Flags

${declaredFlags.length === 0
  ? "_No feature flags declared in this solution's manifest._"
  : `Flags are evaluated server-side via \`getFeatureFlags()\` from \`@dbp/flags/server\`.
Env var overrides take precedence over manifest defaults. Coercion: \`"false"\`, \`"0"\`, \`""\` → false; anything else → true.

| Flag ID | Label | Manifest Default | Env Var Override |
|---------|-------|-----------------|-----------------|
${declaredFlags.map((f) => `| \`${f.id}\` | ${f.label} | \`${f.enabled}\` | \`${flagEnvVar(f.id)}\` |`).join("\n")}

### Usage

\`\`\`tsx
// Server Component — resolve flags and provide to client tree
import { getFeatureFlags } from "@dbp/flags/server";
import { featureFlagDefaults } from "@/solution/flags/config";
import { FeatureFlagsProvider } from "@dbp/flags";

const flags = getFeatureFlags(featureFlagDefaults, process.env);
return <FeatureFlagsProvider value={flags}>{children}</FeatureFlagsProvider>;

// Client Component — consume a flag
import { useFeatureFlag } from "@dbp/flags";
const isEnabled = useFeatureFlag("APP.F01");

// Declarative gate
import { FeatureGate } from "@dbp/flags";
<FeatureGate flag="APP.F01"><MyFeature /></FeatureGate>
\`\`\`

To toggle a flag at runtime: set \`DBP_FLAG_<ID>=true|false\` in your environment and restart.
To change a manifest default: edit \`feature_flags:\` in the manifest and regen with \`--force\`.`
}
`;

const adrTemplateMd = `# ADR-NNNN: <short title>

- **Status:** Proposed | Accepted | Superseded
- **Date:** YYYY-MM-DD
- **Deciders:** <names>

## Context
What is the issue / forces at play?

## Decision
What we decided, and why.

## Consequences
Trade-offs, follow-ups, what this rules out.
`;

const runbookTemplateMd = `# Runbook — <operation>

**Solution:** ${manifest.name}

## When to use
<trigger / symptom>

## Prerequisites
<access, tools, env>

## Steps
1. …
2. …

## Verification
How to confirm success.

## Rollback / escalation
What to do if it fails.
`;

const pageSpecTemplateMd = `# Page Spec — <page name>

- **Route:** /<path>
- **Shell / layout:** CanvasLayout | CatalogueLayout | custom
- **Feature(s):** APP.Fxx (entity-list / lve / catalog-grid / …)

## Purpose
One line: what the user does here.

## Data
Entity type(s), filters, key fields.

## Layout
Header (breadcrumb + title) · body (table/cards/form) · optional rail.
Reuse the code templates in \`solution/templates/\` and follow \`02-guides/page-frame-contract.md\`.

## States
Loading · empty · error · the happy path.
`;

const adrIndexMd = `# Architecture Decision Records

Record significant decisions here, one file per decision: \`ADR-0001-<slug>.md\`.
Copy [the template](../Templates/adr-template.md) to start.

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| _none yet_ | | | |
`;

// ─── Handover docs (sdo-01 parity) + MOC index + features/testing ────────────
const realModulesForDocs = (manifest.modules ?? []).filter((m) => !m._standardDemo);
const bespokeEntityTypes = (manifest.entities ?? []).filter(
  (e) => e.type !== "demo-record" && e.type !== "demo-catalog-item",
);

const homeMocMd = `# ${manifest.name}

**ID:** \`${manifest.solution}\`  ·  **Platform:** \`${manifest.platform}\`  ·  **Blueprint:** \`${blueprintVersion}\`

Map of Content for this solution's documentation. Generated by the DBP factory; the
team owns and extends these docs.

## Spine

| # | Section | What's inside |
|---|---------|---------------|
| 01 | [Architecture](01-Architecture/README.md) | Layers, platform services wired, modules, theme |
| 02 | [Guides](02-Guides/) | Getting started, customization, the page-frame contract |
| 03 | [Features](03-Features/README.md) | Modules + features this solution ships |
| 04 | [Testing](04-Testing/README.md) | How to build, test, and verify data |
| 05 | [Decisions](05-Decisions/README.md) | ADR index — record significant choices |
| 06 | [Operations](06-Operations/) | Deployment, incident response, feature flags |
| 07 | [Handover](07-Handover/TEAM-HANDOFF.md) | Team handoff + builder guide |
| — | [Extending](EXTENDING.md) | Task-by-task how-do-I guide (add an entity, a page, a migration, …) |
| — | [Templates](Templates/) | ADR / runbook / page-spec templates to copy |

## Start here

- **New to the solution?** → [07-Handover/TEAM-HANDOFF.md](07-Handover/TEAM-HANDOFF.md)
- **Extending it?** → [EXTENDING.md](EXTENDING.md) (task-by-task) or [07-Handover/BUILDER-GUIDE.md](07-Handover/BUILDER-GUIDE.md) (reference tables)
`;

const featuresCatalogMd = `# Features — ${manifest.name}

This solution ships **${realModulesForDocs.length}** bespoke module(s) on top of the
standard navigation menu (demo pages).

## Bespoke modules

${
  realModulesForDocs.length
    ? realModulesForDocs
        .map(
          (m) =>
            `### ${m.name} (\`${m.id}\`)\n- Route: \`${m.route ?? ""}\`  ·  Shell: \`${m.scaffold}\`\n- Features: ${m.features.map((f) => `\`${f.id}\``).join(", ")}`,
        )
        .join("\n\n")
    : "_None — this solution uses the standard menu only._"
}

## Entities

${
  bespokeEntityTypes.length
    ? bespokeEntityTypes
        .map((e) => `- \`${e.type}\` — ${e.fields.length} fields, ${(e.seed ?? []).length} seed rows`)
        .join("\n")
    : "_No bespoke entities declared._"
}

> The rest of the navigation is the standard DBP Feature menu (demo pages). Refine or
> remove per the [Builder Guide](../07-Handover/BUILDER-GUIDE.md).
`;

const testingGuideMd = `# Testing — ${manifest.name}

\`\`\`bash
pnpm install
pnpm build          # production build (type-checks the app)
pnpm test           # vitest (passes with no tests)
\`\`\`

## Verify data at runtime

A green build does NOT prove data survived. Start the app and confirm the platform-data
plane returns seeded rows:

\`\`\`bash
node node_modules/next/dist/bin/next start -p 9030
${(bespokeEntityTypes.slice(0, 3).length ? bespokeEntityTypes.slice(0, 3) : [{ type: "<type>" }])
  .map((e) => `curl -H "x-tenant-id: tenant-alpha" http://localhost:9030/api/platform/data/entities/${e.type}`)
  .join("\n")}
\`\`\`

## UAT sign-off

Automated tests (above) cover functional/NFR gates the factory enforces. Business
sign-off is a separate, manual activity — see the generated
[UAT Checklist](UAT-CHECKLIST.md).
`;

// ── UAT checklist scaffold (Increment J, docs/09-plans/minimum-test-plan-build-spec-2026-07-07.md §2) ──
// UAT is a human sign-off activity against THIS deployed solution's specific business
// stakeholders — the factory cannot automate it. This doc gives the solution owner a
// pre-populated starting checklist derived from the manifest's actual declared roles and
// journeys/pages, instead of a blank page. Zero UAT automation in CI (approved 2026-07-07).
// Re-emitted on every regen (generator-owned) so it stays current with the manifest —
// role/page names come straight from realModulesForDocs/manifest.iam, not invented here.
const uatRoles = manifest.iam?.roles ?? [];
const uatPermissions = manifest.iam?.permissions ?? [];
const uatChecklistMd = `# UAT Checklist — ${manifest.name} (${manifest.solution})

**Generated:** _fill in the deployment date before circulating_
**Status:** starting draft — edit freely, this is not a completed checklist

## What this is

This is a **starting point**, not a finished test plan. It is pre-populated from what
\`${manifest.solution}\`'s manifest actually declares — its roles and its pages/modules —
so the solution owner doesn't start from a blank page. Before circulating it to
stakeholders, review every row: rename vague checks, add the specific business
scenarios only a human familiar with this deployment would know, and remove anything
that doesn't apply.

**Who should use this:** the solution owner and the business stakeholders who will
give manual sign-off before go-live — not an automated test suite. UAT is inherently
a human activity against a specific deployed solution; nothing here runs in CI.

For the factory's overall test strategy and where UAT sits relative to the automated
gates, see the DBP factory's \`docs/04-testing/minimum-test-plan.md\` (monorepo doc —
this solution ships without a copy of that repo, so it's referenced by path, not link).

---

## Role-based checks

${
  uatRoles.length
    ? uatRoles
        .map(
          (r) => `### As a **${r.label ?? r.id}** (\`${r.id}\`)

- [ ] Can sign in and land on the correct home experience for this role.
${
  uatPermissions.length
    ? uatPermissions
        .map((p) => `- [ ] Verify you can/cannot **${p.action} ${p.resource}** — ${p.description ?? "fill in the specific expected behaviour for this role"}.`)
        .join("\n")
    : "- [ ] Fill in the specific capability checks for this role (no `iam.permissions` declared in the manifest to seed from)."
}
- [ ] Verify actions outside this role's permissions are correctly blocked or hidden.`,
        )
        .join("\n\n")
    : "_No `iam.roles` declared in the manifest — add role-based checks here once roles exist._"
}

---

## Journey / page checks

${
  realModulesForDocs.length
    ? realModulesForDocs
        .map(
          (m) =>
            `### ${m.name} (\`${m.route ?? ""}\`)

- [ ] Page loads without error for each role expected to use it.
- [ ] Primary action(s) on this page complete successfully end-to-end.
- [ ] Data shown matches what the business expects for a real (non-demo) tenant.
- [ ] Fill in any solution-specific business scenario for this page.`,
        )
        .join("\n\n")
    : "_No bespoke modules declared — this solution uses the standard menu only; add checks per page as it's customised._"
}

---

## Sign-off

| Stakeholder | Role | Date | Outcome |
|---|---|---|---|
| | | | |
`;

// ── Per-solution test plan (Increment M, docs/09-plans/minimum-test-plan-build-spec-2026-07-07.md §6a) ──
// Manifest-derived — states exactly which factory-global gates THIS solution inherits (not a
// generic list of everything that theoretically exists), derived from the same consumedSet /
// manifest.dev / bespokeEntityTypes already in scope for this generation pass. Re-emitted on
// every regen so it stays current with the manifest, same pattern as UAT-CHECKLIST.md above.
const inheritsTenantIsolation = Boolean(manifest.dev?.tenant_id) || consumedSet.has("PS.DATA");
const inheritsRbacMatrix = consumedSet.has("PS.RBAC");
const inheritsStructuredLogs = true; // every generated app has server routes / instrumentation.ts
const inheritedGates = [
  "F1 — unit test per feature package",
  "F2 — render test + story per @dbp/ui component",
  "F7 — regen idempotence (byte-identical generator surface)",
  "F8 — negative-case heuristic (≥1 deny/invalid/error-shaped test per feature package)",
  "N4 — secret + dependency scan",
  "N5 — a11y smoke (`pnpm test:a11y`, warn-baseline)",
  "N6 — bundle/build budget (`pnpm test:bundle`, warn-baseline)",
  "N9 — coverage ratchet, fixed 98% floor (`pnpm test:coverage`, adoption mode)",
  ...(inheritsStructuredLogs ? ["N7 — structured logging present (`pnpm test:structured-logs`, adoption mode)"] : []),
  ...(inheritsTenantIsolation ? ["N2 — tenant isolation, mocked contract"] : []),
  ...(inheritsRbacMatrix ? ["N8 — RBAC exhaustive matrix (role × action), auto-derived from the manifest"] : []),
  ...(consumedSet.size ? [`F5 — E2E business-journey spec (required: consumes ${consumedSet.size} platform service(s))`] : []),
];
const testPlanMd = `# Test Plan — ${manifest.name} (${manifest.solution})

This solution inherits the DBP factory's minimum test plan automatically — no setup required.
This document states exactly which gates apply to **this solution**, derived from its own
manifest (\`consumes_platform_services\`: ${manifest.consumes_platform_services.join(", ") || "(none)"}${
  manifest.dev?.tenant_id ? `; \`dev.tenant_id\`: \`${manifest.dev.tenant_id}\`` : ""
}), not a generic checklist of everything the factory could theoretically enforce.

## Gates this solution inherits

${inheritedGates.map((g) => `- ${g}`).join("\n")}

These run via \`pnpm verify\` (functional + build) and the standalone-parity commands
(\`pnpm test:a11y\`, \`pnpm test:bundle\`, \`pnpm test:coverage\`, \`pnpm test:structured-logs\`)
wired into this repo's own \`.github/workflows/pr-checks.yml\`. All NFR gates run in
warn-baseline/adoption mode today — they report gaps but do not fail CI until a solution owner
deliberately flips a gate to \`--strict\`.

## What's not covered here

- **Business/role-based sign-off (UAT)** is a human activity this factory cannot automate. See
  the generated [UAT Checklist](UAT-CHECKLIST.md) for a manifest-derived starting checklist to
  circulate to stakeholders before go-live.
- **Compliance/regulatory, third-party integration, or data-migration testing** specific to
  this solution's real-world deployment are per-solution extensions, not factory gates. Copy
  the \`third-party-integration\` and \`compliance\` \`EXTENSION\`-type worked examples from
  \`quality-matrix.json\` into your own exported copy and adapt them. For compliance work, the
  factory ships a starter script (\`scripts/check-compliance-starter.mjs\`) as a working
  template — it is not run by this solution's own CI until you wire it in deliberately.

## Full context

For the factory's complete minimum test plan — the full functional/non-functional checklist,
the applicability rule, and the factory-global vs per-solution-extension line — see the DBP
Blueprint factory's minimum test plan for full context
(\`docs/04-testing/minimum-test-plan.md\` in the factory monorepo; this solution ships as a
separate repo without a copy of that file, so it's referenced by path, not link).
`;

const teamHandoffMd = `# ${manifest.name} — Team Handoff

**Solution:** ${manifest.solution} — ${manifest.name}
**Built on:** Digital Business Platform (DBP) factory
**Source of truth:** the manifest (\`solution/_arch/SOLUTION.md\`; authored in the monorepo as \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`)

---

## 1. Links

| What | Where |
|---|---|
| **Builder guide** | \`docs/07-Handover/BUILDER-GUIDE.md\` |
| **Architecture** | \`docs/01-Architecture/README.md\` |
| **Features** | \`docs/03-Features/README.md\` |
| **Agent rules** | \`AGENTS.md\` |
| **Overview** | \`README.md\` |

**Demo login:** \`platform-admin@alpha.dev.local\` / \`dbp-dev-password\`
> Only \`/login\` is public; everything else needs a session. \`/\` redirects to \`/home\`.

## 2. What's built

- **${realModulesForDocs.length}** bespoke module(s) + the full standard navigation menu (demo pages).
- **${bespokeEntityTypes.length}** bespoke entity type(s): ${bespokeEntityTypes.map((e) => `\`${e.type}\``).join(", ") || "none"}.
- Platform services wired (not built): ${manifest.consumes_platform_services.map((s) => `\`${s}\``).join(", ")}.

## 3. Run it

\`\`\`bash
pnpm install
pnpm build
node node_modules/next/dist/bin/next start -p 9030   # http://localhost:9030
\`\`\`

## 4. How it's structured

- \`app/\` — generated Next.js routes + API mounts (generator-owned; do not hand-edit).
- \`solution/\` — entity schemas, fixtures/seed, \`_arch\` manifest (solution-owned).
- \`docs/\` — this spine (solution-owned; extend freely).

To change pages/features/theme, edit the manifest and regenerate — see the [Builder Guide](BUILDER-GUIDE.md).
`;

// ── Nav-configuration section, extracted from the canonical monorepo doc so the
// generated builder guide never drifts out of sync with docs/02-guides/00-getting-
// started/builder-guide.md §5 "Nav Configuration" — single source of truth, one copy
// interpolated here instead of a second hand-maintained copy of the same prose.
function extractNavGuideSection() {
  const monorepoGuidePath = path.join(__dirname, "..", "docs/02-guides/00-getting-started/builder-guide.md");
  const raw = fs.readFileSync(monorepoGuidePath, "utf8");
  const start = raw.indexOf("## 5. Nav Configuration");
  const end = raw.indexOf("## 6. Reference Solutions");
  if (start === -1 || end === -1 || end <= start) {
    throw new Error(
      "scaffold-solution.mjs: could not extract '## 5. Nav Configuration' from " +
      "docs/02-guides/00-getting-started/builder-guide.md — section headings changed; " +
      "update extractNavGuideSection()'s markers to match.",
    );
  }
  return raw.slice(start, end).replace("## 5. Nav Configuration", "## 3. Nav configuration").trim();
}
const navGuideSection = extractNavGuideSection();

const builderGuideMd = `# Solution Builder Guide — ${manifest.solution} (${manifest.name})

How to evolve this solution. This is a **generated artifact** — the source of truth is the
**manifest** (\`solution/_arch/SOLUTION.md\`, authored in the monorepo as
\`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`). Refine the manifest and regenerate; do not
hand-edit \`app/\` routes.

## 1. The model: standard menu → refine

Every DBP solution starts from the standard navigation menu (all Feature Areas → Groups →
Features), scaffolded as demo pages. A manifest module OVERRIDES a standard slot by route (your
real feature wins). Refine or remove demo pages as you go.

## 2. Common changes (edit manifest, then regen)

| Want to… | Manifest change |
|---|---|
| Add / remove a page | add/remove a \`modules:\` entry (id, route, scaffold, features) |
| Change a page's feature | edit \`modules[].features[].config\` |
| Add an entity + seed | add an \`entities:\` block (type / fields / seed) |
| Rebrand | edit \`theme:\` tokens (brand = accent; \`--color-primary\` stays dark) |
| Home page | \`home:\` block — \`hero\`/\`greetingCard\` + \`features\`/\`howItWorks\` render the landing-page home |

Regenerate (in an isolated git worktree — the generator is destructive):

\`\`\`bash
pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force
\`\`\`

${navGuideSection}

## 4. Rules

- Layer-06 services are wired by ID, never reimplemented.
- Zod schemas are the source of truth (\`z.infer\` for types).
- Solution-owned files (\`solution/\`, \`instrumentation.ts\`, \`docs/\`) are preserved on regen; \`app/\` is overwritten.
- Always verify data at runtime after a regen (curl an entity endpoint) — a green build doesn't prove data survived.
`;

// ── Generated Control Slice item #13 (docs/03-features/specs/spec-generated-control-
// slice-2026-07-11.md): root README.md — a shipped standalone had NO entry-point
// document at all (Sharavi directive, 2026-07-11 night). Every fact below is derived
// from the manifest / ownership contract already resolved for this generation pass —
// nothing here is invented prose a team would need to keep in sync by hand. That is
// exactly why this file is GENERATOR-OWNED (always re-emitted, NOT added to
// isSolutionOwned()): the ownership map and service/module lists must stay accurate as
// the manifest evolves, and a seed-once/hand-edited README would silently go stale the
// same way the rest of this gap describes. publish-blueprint.mjs already lists
// "README.md" in its SYNC_FILES (line 39) expecting a generator-owned file here — this
// closes that latent gap.
const readmeMd = `# ${manifest.name}

**Generated DBP solution** (\`${manifest.solution}\`, platform \`${manifest.platform}\`) — built by the DBP
Blueprint factory. This repo is not hand-built from scratch: most of \`app/\` and its config
files are emitted from a manifest, on top of reusable Layer 06 platform services.

**Provenance:** if this repo was produced by \`export-standalone.sh\`, the machine-readable
record of exactly which platform version, \`@dbp\` package versions, and generator revision
produced it is in \`blueprint-release.json\` at the repo root (human-readable notes for each
release are under \`docs/06-Releases/\`). If this is a scaffold-only app with no export yet,
the same provenance lives in \`solution/_arch/SOLUTION.md\`'s frontmatter instead.

## 60-second orientation

\`\`\`bash
pnpm install
pnpm --filter @dbp/app-${solutionDir} dev     # run locally (see docs/02-Guides/getting-started.md)
pnpm --filter @dbp/app-${solutionDir} verify  # typecheck + lint + test + quality gates
\`\`\`

- Business logic (entities, workflows, RBAC deltas, custom pages) — \`solution/\`
- Generated app shell (routes, API mounts, chrome) — \`app/\` (do not hand-edit)
- Full docs spine — \`docs/\`, start at \`docs/Home.md\`

## Ownership map

| Path | Owner | On \`--force\` regen |
|---|---|---|
| \`app/\`, \`package.json\`, \`next.config.ts\`, \`middleware.ts\`, \`solution/_arch/\` | Generator | Overwritten |
| \`solution/entities/\`, \`solution/workflows/\`, \`solution/modules/\`, \`solution/rbac/\`, \`solution/adapters/\`, \`solution/pages/\` | You | Preserved |
| \`instrumentation.ts\` | You | Preserved |
| \`docs/\` (this spine — extend freely) | You | Preserved |
| \`AGENTS.md\` / \`CLAUDE.md\` | Shared | Only the \`FACTORY-NON-NEGOTIABLES\`-delimited block is refreshed; everything else is yours |
| \`PROGRESS.md\`, \`quality-ratchet.json\`, \`.env.local\` | You | Created once, never regenerated |
${isPersistentStorage ? `| \`db/migrations/platform/\`, migration scripts/CI | Generator | Overwritten |
| \`db/migrations/${solutionDir}/\` (your schema) | You | Preserved |
` : ""}
This is the same contract \`scripts/scaffold-solution.mjs\`'s \`isSolutionOwned()\` enforces at
generation time — see \`AGENTS.md\` "File ownership contract" for the full list.

## How updates arrive

Two channels, see \`docs/07-Handover/BUILDER-GUIDE.md\`:

1. **Package bump** — \`@dbp/*\` tarball/dependency versions move (bug fixes, design-token or
   platform-service internals). No file in this repo changes and no regen runs.
2. **Regen** — edit \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\` (the manifest) and run
   \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\` (or \`pnpm regen\`
   inside a standalone repo). Carries page/route/nav/theme changes. Always verify data at
   runtime afterward — a green build does not prove data survived.

## The rules

- **Don't hand-edit generator-owned files** (see Ownership map above) — the next regen
  overwrites them. Need custom UI on a generated page? Set the module's \`pageComponent\` to a
  \`solution/pages/<name>.tsx\` component instead.
- **Schema changes go through migrations, never hand-edited SQL.**${isPersistentStorage
    ? ` See \`db/migrations/platform/README.md\` and AGENTS.md's "Database migrations" section for the policy this repo enforces.`
    : " This solution runs in prototype (non-persistent) storage mode — no migration toolchain is emitted."}
- **Quality gates are not optional.** \`pnpm verify\` runs the same checks the factory itself
  requires before this solution shipped — don't \`--no-verify\` past a red one.

## More

- [Docs index](docs/Home.md) — the full spine (architecture, guides, testing, decisions, operations, handover)
- [Team handoff](docs/07-Handover/TEAM-HANDOFF.md) — what's built, how to run it, demo login
- [Extending this solution](docs/EXTENDING.md) — task-by-task how-do-I guide
`;

// ── Generated Control Slice item #13 (same spec as readmeMd above): docs/EXTENDING.md —
// the task-shaped companion to docs/07-Handover/BUILDER-GUIDE.md's reference-table format.
// SOLUTION-OWNED (falls under isSolutionOwned()'s existing `docs/` prefix rule — create-
// if-missing, never overwritten) because a team extending this solution will want to add
// their own task entries here over time, the same way the rest of docs/ works today.
const extendingMd = `# Extending ${manifest.name}

Task-by-task guide for the changes a solution builder actually makes. Each task names the
exact file(s) to touch, what NOT to touch, and how to verify. For the reference-table version
of the same rules, see \`docs/07-Handover/BUILDER-GUIDE.md\`; for the full ownership contract,
see the root \`README.md\`.

## Add an entity

1. Add an \`entities:\` block entry to \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`
   (type, label, fields, seed rows).
2. Regen: \`pnpm scaffold -- docs/10-Solutions/${manifest.solution}-SOLUTION.md --force\`.
3. A Zod schema is emitted to \`solution/entities/<type>.ts\` — solution-owned from that point;
   hand-edit it freely (add fields, validation) without re-running the manifest step again.
4. **Don't** hand-write a TypeScript \`interface\` for the entity — \`z.infer<typeof Schema>\` is
   the only source of truth.
5. Verify: \`curl -H "x-tenant-id: ${manifest.dev?.tenant_id ?? "tenant-alpha"}" http://localhost:9030/api/platform/data/entities/<type>\`
   returns the seeded rows.

## Add a page / feature config

1. Add or edit a \`modules:\` entry in \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`
   (\`id\`, \`route\`, \`scaffold\`, \`features\`).
2. Regen with \`--force\` (same command as above).
3. **Don't** hand-edit the emitted route under \`app/\` — it is overwritten on the next regen.
   For custom page bodies, set that module's \`pageComponent\` to a component under
   \`solution/pages/<name>.tsx\` instead (solution-owned, survives regen).
4. Verify: the new route returns 200 and renders inside the standard shell (no duplicate
   \`PageHeader\` — see \`docs/02-Guides/page-frame-contract.md\`).

## Change navigation

1. Adding/removing a bespoke page changes the nav automatically (driven by \`modules:\`).
2. To rename or reorder standard-menu entries, edit the relevant \`modules:\` override in the
   manifest — the standard menu is the generator's default, and a manifest module overrides a
   standard slot by matching \`route\`.
3. **Don't** hand-edit the generated nav/shell wiring under \`app/\`.
4. Verify: the item appears/moves in the rendered sidebar at the expected route.

## Add a workflow

1. Add a workflow definition under \`solution/workflows/\` (solution-owned — create it directly,
   no manifest step required for the definition itself).
2. Wire the module that should surface it via the manifest's \`features\` config for that module.
3. **Don't** reimplement PS.WORKFLOW's engine or state machine — the workflow definition
   describes states/transitions; the platform service runs them.
4. Verify: the workflow's actions appear on the bound record and transitions persist across a
   reload.

## Add a migration${isPersistentStorage ? "" : " (not applicable — prototype storage mode)"}

${isPersistentStorage ? `1. Create \`db/migrations/${solutionDir}/NNNN_description.sql\` for schema (DDL) changes, or
   \`NNNN_data_description.sql\` for data-of-record (DML) changes — never mix DDL and DML in one
   file (\`scripts/check-migrations.mjs\` enforces this).
2. **Don't** hand-edit anything under \`db/migrations/platform/\` — that's the vendored platform
   baseline, generator-owned and overwritten on every regen; a platform schema fix arrives via
   the normal package-bump/regen channel, never by hand.
3. **Don't** put demo/seed data in \`db/migrations/**\` — that belongs in \`solution/fixtures/*\`
   via \`registerAndSeedData()\`.
4. Verify: \`node scripts/db-migrate.mjs\` replays cleanly against a fresh database, then
   \`pnpm db:snapshot\` to update the committed schema baseline if the change is structural.` : `This solution runs in prototype (non-persistent JSONB) storage mode, so no migration
toolchain is emitted. If this solution needs a real database, that's a manifest change
(\`storage_mode: postgres\`) followed by a regen — not something to hand-build here.`}

## Request a platform update

Platform-service fixes and \`@dbp/*\` internals arrive via the package-bump channel, not by
hand-patching anything under \`node_modules\`/vendored packages. Raise the change against the
DBP Blueprint factory (the monorepo this solution was generated from) — see
\`docs/02-Guides/getting-started.md\` "Regenerating the scaffold" and the root \`README.md\`'s
"How updates arrive" section for the two channels.
`;

// ── G8: migration-governance toolchain (postgres mode only) ─────────────────
// Generator-owned: scripts, CI workflow, CODEOWNERS, platform migration vendor copies.
// Solution-owned (create-if-missing): db/migrations/<slug>/ (the app's own migrations).
if (isPersistentStorage) {
  emitMigrationGovernance(solutionDir);
}

// ── ADR-0039 Wave 4: typed BFF route seam (data_model: relational only) ─────
// Emits a reference Tier-2 route handler demonstrating the withTenant() + Drizzle
// typed-access pattern (docs/03-Features/specs/SP-DATA-TYPED-ACCESS.md). Solution-
// owned, create-if-missing — the developer adapts it to their domain or deletes it.
// Prototype (JSONB) apps get nothing here; they use the PS.DATA route.
if (isRelationalDataModel) {
  const bffRel = "app/api/example-catalog/route.ts";
  const bffAbs = path.join(outDirBase, bffRel);
  if (!fs.existsSync(bffAbs)) {
    fs.mkdirSync(path.dirname(bffAbs), { recursive: true });
    fs.writeFileSync(
      bffAbs,
      `// REFERENCE Tier-2 typed-access route (ADR-0039) — SOLUTION-OWNED, create-if-missing.
// Adapt to your domain or delete. Pattern: docs/03-Features/specs/SP-DATA-TYPED-ACCESS.md.
// SERVER-ONLY: imports @dbp/platform-db (instantiates a postgres pool). Never import from a client component.
//
// TWO CONTRACTS this reference encodes — keep them when adapting:
//   1. VALIDATE AT THE BOUNDARY: every handler parses its input with a Zod schema
//      (safeParse → 400). Never feed raw req.json() into a query.
//   2. ATOMIC MULTI-WRITES: withTenant() runs its callback inside ONE database
//      transaction — put ALL writes of a logical operation inside a single
//      withTenant call and they commit or roll back together. Splitting an
//      operation across multiple withTenant calls (or hand-rolled connections)
//      is how orphaned rows happen. Never build your own postgres connection —
//      @dbp/platform-db owns the pool.
import { withTenant, listings, marketplaces } from "@dbp/platform-db";
import { and, eq } from "drizzle-orm";
import { type NextRequest, NextResponse } from "next/server";
import { CreateListingSchema } from "./schema";

// Resolve tenant/user from your PS.AUTH session (header/cookie). Inline demo shown.
function sessionOf(req: NextRequest) {
  const userId = req.headers.get("x-user-id");
  return {
    tenantId: req.headers.get("x-tenant-id") ?? ${JSON.stringify(manifest.dev?.tenant_id ?? "tenant-alpha")},
    // OMIT userId when the header is absent — do not set it to \`undefined\`.
    // TenantSession declares \`userId?: string\`, and a consumer tsconfig with
    // \`exactOptionalPropertyTypes: true\` rejects \`userId: string | undefined\`
    // against an optional-but-not-nullable property. The monorepo does not set
    // that flag, so this only ever fails in the consumer's repo, where it reads
    // as their bug rather than ours.
    ...(userId ? { userId } : {}),
  };
}

// GET /api/example-catalog?marketplace=<key> — published listings, RLS-scoped to the tenant.
export async function GET(req: NextRequest) {
  const session = sessionOf(req);
  const key = new URL(req.url).searchParams.get("marketplace");
  const rows = await withTenant(session, (tx) =>
    tx
      .select({ id: listings.id, title: listings.title, status: listings.status })
      .from(listings)
      .innerJoin(marketplaces, eq(marketplaces.id, listings.marketplace_id))
      .where(and(eq(listings.status, "published"), key ? eq(marketplaces.key, key) : undefined)),
  );
  return NextResponse.json({ rows });
}

// POST /api/example-catalog — create a listing under the caller's tenant (RLS WITH CHECK enforces tenant_id).
export async function POST(req: NextRequest) {
  const session = sessionOf(req);
  const parsed = CreateListingSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid request body", issues: parsed.error.issues }, { status: 400 });
  }
  const body = parsed.data;
  // Single withTenant call = single transaction. If this operation grows more
  // writes (e.g. insert listing + insert audit row), keep them in THIS callback.
  const [row] = await withTenant(session, (tx) =>
    tx
      .insert(listings)
      .values({
        id: body.id,
        tenant_id: session.tenantId,
        marketplace_id: body.marketplaceId,
        title: body.title,
        slug: body.slug,
      })
      .returning(),
  );
  return NextResponse.json({ row }, { status: 201 });
}
`,
      "utf8",
    );
    console.log(`  emitted (relational BFF seam, create-if-missing): ${bffRel}`);
  }

  // Boundary schema in a sibling file — route.ts may only export route handlers
  // (Next validates route exports), and the colocated test needs to import it.
  const bffSchemaAbs = path.join(outDirBase, "app/api/example-catalog/schema.ts");
  if (!fs.existsSync(bffSchemaAbs)) {
    fs.writeFileSync(
      bffSchemaAbs,
      `// SOLUTION-OWNED boundary schema for /api/example-catalog — emitted once.
// route.ts files may only export route handlers, so schemas live beside them.
import { z } from "zod";

export const CreateListingSchema = z.object({
  id: z.string().min(1),
  marketplaceId: z.string().min(1),
  title: z.string().min(1),
  slug: z.string().min(1),
});
`,
      "utf8",
    );
  }

  // Colocated route-test skeleton (create-if-missing) — the pattern every new
  // API route should copy: at minimum, the boundary schema has tests. Schema-level
  // so it runs in unit CI without a database.
  const bffTestAbs = path.join(outDirBase, "app/api/example-catalog/route.test.ts");
  if (!fs.existsSync(bffTestAbs)) {
    fs.writeFileSync(
      bffTestAbs,
      `// SOLUTION-OWNED route-test skeleton — emitted once by scaffold-solution.
// Every API route ships at least boundary-contract tests. Extend with handler
// tests (mock @dbp/platform-db) as the route grows.
import { describe, it, expect } from "vitest";
import { CreateListingSchema } from "./schema";

describe("example-catalog boundary contract", () => {
  it("accepts a valid create payload", () => {
    expect(
      CreateListingSchema.safeParse({ id: "l1", marketplaceId: "m1", title: "T", slug: "t" }).success,
    ).toBe(true);
  });

  it("rejects a payload with missing fields", () => {
    expect(CreateListingSchema.safeParse({ title: "T" }).success).toBe(false);
  });
});
`,
      "utf8",
    );
    console.log("  emitted (relational BFF route test, create-if-missing): app/api/example-catalog/route.test.ts");
  }
}

writeMergeAppendFile("AGENTS.md", factoryNonNegotiablesBlock, agentsMd);
writeMergeAppendFile("CLAUDE.md", factoryNonNegotiablesBlock, claudeMd);
// Generated Control Slice item #13 — root README.md, generator-owned (always re-emitted,
// see the comment above readmeMd's definition). publish-blueprint.mjs's SYNC_FILES already
// expected a README.md here (line 39) — this is what makes that expectation real.
writeFile("README.md", readmeMd);
writeFile(".ai/context.md", aiContextMd);
// PROGRESS.md — Generated Control Slice item #3: seed-once (writeFile's solution-owned
// create-if-missing path — see isSolutionOwned() — so session history is never clobbered).
writeFile(
  "PROGRESS.md",
  `# Progress Log — ${manifest.name}

At the end of every working session, append an entry below (newest last).

Each entry: \`## YYYY-MM-DD — <title>\`, then **goal**, **what changed**, **status**,
**known-remaining**, and **next steps**. Keep it concise.
`,
);
// .env.example — always re-emitted (generator-owned, documents all required vars)
writeFile(".env.example", envExampleContent);
// .env.local — create-if-missing only (solution-owned, pre-filled dev secret, gitignored)
writeFile(".env.local", envLocalContent);

// ─── STCB-vault sub-structure additions (2026-07-17): HLAD (01.2) + cross-cutting
// LLAD (01.3), manifest-derived, no invented prose. Both fall under docs/ so
// isSolutionOwned() already makes them create-if-missing / emit-once like the
// rest of the docs spine below — see docs/03-features/specs/
// solution-docs-skeleton-2026-07-17.md for the full reconciliation record.

const PS_PURPOSE = {
  "PS.AUTH": "Authenticate users, issue and verify sessions, federate identity.",
  "PS.DATA": "Entity persistence, query, and schema registry — the canonical data plane.",
  "PS.RBAC": "Authorize actions against roles and resource scopes.",
  "PS.WORKFLOW": "Define and run multi-step workflows, approvals, and state machines.",
  "PS.AUDIT": "Records who did what to which entity, immutably; serves activity feeds.",
  "PS.NOTIF": "Deliver and manage notifications across channels (in-app, email, sms).",
  "PS.SEARCH": "Index and query entities across the solution.",
  "PS.EVENTS": "Publish/subscribe domain events asynchronously across services and solutions.",
  "PS.AI": "Single AI surface for DBP solutions: assistant conversations, RAG-backed answers.",
  "PS.APIGW": "Gateway config-as-code: the authoritative registry of exposed API paths.",
};

// Env contract per service — the vars that service's own package actually reads
// (packages/stack/platform-services/<dir>/server/*.ts), not a generic guess.
const PS_ENV = {
  "PS.AUTH": ["DBP_AUTH_SESSION_SECRET (required, 32+ hex chars)", "DBP_IDP_PROVIDER (password|ldap|entra|entra-external, default password)"],
  "PS.DATA": isPersistentStorage ? ["DATABASE_URL (pooled)", "DIRECT_URL (migrations only)"] : ["none — in-memory adapter (prototype storage mode)"],
  "PS.AUDIT": ["AUDIT_STORAGE (memory|drizzle, default memory; drizzle requires DATABASE_URL)"],
  "PS.NOTIF": ["NOTIF_EMAIL_TRANSPORT (smtp|msgraph|console)", "SMTP_URL / SMTP_FROM or MSGRAPH_* (per transport)"],
  "PS.WORKFLOW": isPersistentStorage ? ["DATABASE_URL (drizzle storage)"] : ["none — in-memory adapter"],
  "PS.RBAC": ["none — session-derived (x-dbp-session header set by PS.AUTH's verify step)"],
  "PS.SEARCH": ["none — in-memory index, seeded at bootstrap"],
  "PS.EVENTS": ["none — in-process bus"],
  "PS.AI": ["provider keys per configured model (see solution/_arch/SOLUTION.md ai: block, if declared)"],
  "PS.APIGW": ["none — static config-as-code"],
};

// Wiring seam per service: instrumentation.ts (server-boot bootstrap, invisible across
// Next.js route-chunk isolation) vs. the route's own per-chunk self-bootstrap. PS.AUTH
// and PS.DATA self-bootstrap per chunk (see generateAuthRouteHandler / the PS.DATA
// route template); the rest register once from instrumentation.node.ts at server boot.
const PS_SEAM = {
  "PS.AUTH": "per-route-chunk self-bootstrap (own chunk seeds DEMO_IDENTITIES; instrumentation.ts is not visible across chunk isolation)",
  "PS.DATA": hasManifestEntities ? "per-route-chunk self-bootstrap (registerAndSeedData() re-run per chunk)" : "instrumentation.ts (registerAndSeedData at server boot)",
};
function seamFor(id) {
  return PS_SEAM[id] ?? "instrumentation.ts (registered once at server boot via instrumentation.node.ts)";
}

const hladServiceRows = resolvedServices
  .map((s) => `| ${s.id} | ${PS_PURPOSE[s.id] ?? "—"} | \`${s.mount_path}\` |`)
  .join("\n");

const hladModuleRows = resolvedModules
  .map(
    (m) =>
      `| ${m.id} | ${m.name} | \`${m.route}\` | ${m.journey_stage} | ${m.features.map((f) => f.id).join(", ") || "—"} |`,
  )
  .join("\n");

const hladEntitiesSection = (manifest.entities ?? []).length
  ? (manifest.entities ?? [])
      .map((e) => `- **${e.type}** — fields: ${(e.fields ?? []).map((f) => f.name).join(", ") || "—"}${e.lifecycle ? ` (lifecycle: ${(e.lifecycle.states ?? []).join(" → ")})` : ""}`)
      .join("\n")
  : "No entities declared in the manifest.";

const workflowFeatureIds = resolvedModules
  .flatMap((m) => m.features)
  .filter((f) => (f.wires ?? []).includes("PS.WORKFLOW"))
  .map((f) => f.id);
const hladWorkflowsSection = workflowFeatureIds.length
  ? `Wired via features: ${workflowFeatureIds.join(", ")} (definitions under \`solution/workflows/\`).`
  : "No feature wires PS.WORKFLOW in this manifest.";

const hladMermaid = `graph LR
  subgraph Modules
${resolvedModules.map((m) => `    ${m.id.replace(/[^A-Za-z0-9]/g, "_")}["${m.id}<br/>${m.route}"]`).join("\n")}
  end
  subgraph "Layer 06 — Platform Services"
${resolvedServices.map((s) => `    ${s.id.replace(/[^A-Za-z0-9]/g, "_")}["${s.id}"]`).join("\n")}
  end
${resolvedModules
  .flatMap((m) => m.features.flatMap((f) => (f.wires ?? []).map((w) => `  ${m.id.replace(/[^A-Za-z0-9]/g, "_")} --> ${w.replace(/[^A-Za-z0-9]/g, "_")}`)))
  .filter((v, i, arr) => arr.indexOf(v) === i)
  .join("\n")}`;

const hladMd = `# High-Level Architecture Design — ${manifest.name}

**Solution ID:** \`${manifest.solution}\` · **Platform:** \`${manifest.platform}\` · **Blueprint:** \`${blueprintVersion}\` · **Deploy layer:** ${manifest.deploy_layer ?? "L07"}
**Generated:** ${generatedAt} by generator \`${generatorRev}\` from \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`. Derived from the manifest — re-run \`pnpm scaffold -- ... --force\` to refresh \`solution/_arch/SOLUTION.md\`; this HLAD itself is create-if-missing and NOT auto-refreshed (edit it by hand as the solution evolves).

## 1. Module map (Layer 07)

| Module | Name | Route | Journey stage | Features |
|---|---|---|---|---|
${hladModuleRows}

## 2. Platform services wired (Layer 06)

| Service | Provides | Mounted at |
|---|---|---|
${hladServiceRows}

Layer 06 platform services are built once by the factory and are never reimplemented in solution code — see \`AGENTS.md\` "File ownership contract".

## 3. Module ↔ service diagram

\`\`\`mermaid
${hladMermaid}
\`\`\`

## 4. Entities

${hladEntitiesSection}

## 5. Workflows

${hladWorkflowsSection}

## 6. Shells

${[...new Set(resolvedModules.map((m) => `\`${m.shell_package}\` (${m.scaffold})`))].join(", ") || "No modules declared."}

## 7. Demo identities & tenancy

- Seeded accounts (PS.AUTH consumed: ${HAS_AUTH ? "yes" : "no"}): \`platform-admin@alpha.dev.local\` and \`user-01@alpha.dev.local\`, password \`dbp-dev-password\` — see \`solution/fixtures/demo-identities.ts\`.
- Primary tenant: \`${manifest.dev?.tenant_id ?? "tenant-alpha"}\`. The platform-admin identity also carries a \`tenant-beta-demo\` membership, demonstrating the workspace tenant switcher.
- Storage mode: ${isPersistentStorage ? "persistent (Postgres via `DATABASE_URL`)" : "prototype (in-memory, non-persistent)"}.

## 8. Deploy layer

\`${manifest.deploy_layer ?? "L07"}\` — see \`docs/06-Operations/deployment.md\` for the deployment runbook.
`;

// ─── LLAD — cross-cutting platform-services layer, as wired into THIS solution ──

const llaServiceSections = resolvedServices
  .map((s) => {
    const routeSurface =
      s.id === "PS.DATA"
        ? `\`${s.mount_path}/entities/<type>\` (list/create), \`${s.mount_path}/entities/<type>/<id>\` (get/update/delete)`
        : `\`${s.mount_path}/*\` (handled by \`${s.route_handler}\`)`;
    return `### ${s.id}

- **Provides:** ${PS_PURPOSE[s.id] ?? "—"}
- **Package:** \`${s.package}\`
- **Route surface:** ${routeSurface}
- **Env contract:** ${(PS_ENV[s.id] ?? ["none"]).join("; ")}
- **Wiring seam:** ${seamFor(s.id)}`;
  })
  .join("\n\n");

const llaMermaid = `sequenceDiagram
  participant B as Browser
  participant R as Next.js route (app/api/platform/*)
${resolvedServices.map((s) => `  participant ${s.id.replace(/[^A-Za-z0-9]/g, "_")} as ${s.id}`).join("\n")}
  participant St as Storage adapter (memory or Drizzle/Postgres)
  B->>R: HTTP request
${resolvedServices.map((s) => `  R->>${s.id.replace(/[^A-Za-z0-9]/g, "_")}: dispatch (${s.mount_path})`).join("\n")}
${resolvedServices.map((s) => `  ${s.id.replace(/[^A-Za-z0-9]/g, "_")}->>St: read/write`).join("\n")}
  St-->>B: response`;

const llaMd = `# Low-Level Design — Platform Services (Layer 06, cross-cutting) — ${manifest.name}

**Solution ID:** \`${manifest.solution}\` · **Blueprint:** \`${blueprintVersion}\`
**Generated:** ${generatedAt} by generator \`${generatorRev}\`. Covers only the PS.* services this manifest declares under \`consumes_platform_services\`; undeclared services are omitted, not stubbed. Create-if-missing — hand-edit as the solution evolves.

## 1. Services wired

${llaServiceSections}

## 2. Session & tenancy model

- PS.AUTH issues a session JWT carrying \`memberships\` (tenant IDs the user belongs to) and an active \`tenantId\`. Tenant switch re-issues the session with a new active \`tenantId\` from the existing memberships — no re-authentication.
- On each request, the calling route verifies the session (\`POST ${SERVICE_META["PS.AUTH"]?.basePath ?? "/api/platform/auth"}/verify\`) and sets \`x-dbp-session = base64(JSON.stringify(session))\`, which PS.RBAC, PS.WORKFLOW, and PS.NOTIF read per their SERVICE.md contracts — RBAC checks and data scoping are session-derived, never re-derived per service.

## 3. Request path through the cross-cutting layer

\`\`\`mermaid
${llaMermaid}
\`\`\`

## 4. Non-negotiable

Layer 06 platform services are built once by the factory. Solutions never reimplement auth, RBAC, audit, notifications, search, or workflow — they call the services above by ID and consume them.
`;

// Docs spine — Title-Case numbered folders matching the DQ vault convention,
// plus a Home.md MOC index and a 07-Handover pair (TEAM-HANDOFF + BUILDER-GUIDE,
// sdo-01 parity). All solution-owned (create-if-missing, preserved on regen).
writeFile("docs/Home.md", homeMocMd);
// 01 — architecture (services + modules + theme)
writeFile("docs/01-Architecture/README.md", solutionOverviewMd);
// 01.2/01.3 — STCB-shaped HLAD + cross-cutting LLAD sub-structure (new, additive)
writeFile("docs/01-Architecture/01.2-High-Level-Design/HLAD.md", hladMd);
writeFile("docs/01-Architecture/01.3-Low-Level-Design/LLAD-platform-services.md", llaMd);
// 02 — guides
writeFile("docs/02-Guides/getting-started.md", gettingStartedMd);
writeFile("docs/02-Guides/customization.md", customizationGuideMd);
writeFile("docs/02-Guides/page-frame-contract.md", pageFrameContractMd);
writeFile(
  "docs/02-Guides/entity-playbook.md",
  `# Entity Playbook — the one-file workflow

> **You should almost never build a screen by hand.** This solution is generated
> from ONE file: \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\` (the
> manifest). Describe your data there, regenerate, and the screens follow.

## Add a new entity (e.g. "control")

1. Open \`docs/10-Solutions/${manifest.solution}-SOLUTION.md\`.
2. In the \`entities:\` block, add your entity — name it, list its fields,
   and (optionally) its lifecycle:

   \`\`\`yaml
   entities:
     - type: control
       fields:
         - { name: title,  type: string, required: true }
         - { name: owner,  type: string }
         - { name: status, type: enum, enum: [draft, active, retired] }
       lifecycle:
         states: [draft, active, retired]
         transitions:
           - { from: draft, to: active, action: activate }
   \`\`\`

3. Wire it to a screen — give a module's list feature the entity:

   \`\`\`yaml
   features:
     - id: APP.F19        # LVE workspace (list-view-edit)
       role: controls
       wires: [PS.DATA]
       config: { entityType: control }
   \`\`\`

4. Run:

   \`\`\`bash
   pnpm regen --dry-run   # PREVIEW: exactly what would be created/overwritten/deleted
   pnpm regen             # regenerates the app from the manifest
   pnpm verify            # typecheck + lint + tests + quality gates
   pnpm dev               # spot-check the affected screens
   \`\`\`

Your hand-written files are SAFE across a regen — \`solution/**\`,
\`instrumentation.ts\`, tests, and docs are never overwritten (see the file
ownership contract in AGENTS.md). Only generated chrome/pages/config refresh.

## Change or remap an entity

Edit the same block (rename a field, change the lifecycle, point at a different
entity) and run \`pnpm regen\` again. Screens, columns, tabs, and stage bars are
all projections of the manifest — they follow automatically.

## What regen can and cannot do here

- ✅ Entities, fields, lifecycles, module configs, nav, theme tokens, feature
  wiring — all manifest-driven, regenerate freely.
- ⚠️ Adding a NEW platform feature (a new \`APP.F*\` id this repo has never
  used) may need a package this repo doesn't carry — \`pnpm regen\` will tell
  you and the platform team ships it via a blueprint re-export.
- ✋ Business rules for CHANGING data across multiple tables (approvals,
  multi-step saves) stay hand-written — copy the pattern in
  \`app/api/example-catalog/route.ts\` (validate at the boundary, all writes in
  one transaction). That code lives in solution-owned files and survives regens.

## If you are about to hand-edit a generated page — stop

Set the module's \`pageComponent\` in the manifest to a component under
\`solution/pages/\` instead (see docs/02-Guides/page-wiring.md). Hand-edits to
generated pages are destroyed by the next regen; \`solution/pages/**\` is yours
forever.
`,
);
// 03 — features (modules + entities this solution ships)
writeFile("docs/03-Features/README.md", featuresCatalogMd);
// 04 — testing
writeFile("docs/04-Testing/README.md", testingGuideMd);
// UAT checklist scaffold (Increment J) — manifest-derived starting point for manual business sign-off.
writeFile("docs/04-Testing/UAT-CHECKLIST.md", uatChecklistMd);
// Per-solution test plan (Increment M) — which factory-global gates this solution inherits.
writeFile("docs/04-Testing/test-plan.md", testPlanMd);
// 05 — decisions
writeFile("docs/05-Decisions/README.md", adrIndexMd);
// 06 — operations (runbooks)
writeFile("docs/06-Operations/deployment.md", deploymentRunbookMd);
writeFile("docs/06-Operations/incident-response.md", incidentRunbookMd);
writeFile("docs/06-Operations/feature-flags.md", featureFlagsRunbookMd);
// 07 — handover (team handoff + builder guide)
writeFile("docs/07-Handover/TEAM-HANDOFF.md", teamHandoffMd);
writeFile("docs/07-Handover/BUILDER-GUIDE.md", builderGuideMd);
// Generated Control Slice item #13 — task-by-task extension guide, solution-owned
// (falls under isSolutionOwned()'s `docs/` prefix rule — create-if-missing).
writeFile("docs/EXTENDING.md", extendingMd);
// Templates (copy-to-author)
writeFile("docs/Templates/adr-template.md", adrTemplateMd);
writeFile("docs/Templates/runbook-template.md", runbookTemplateMd);
writeFile("docs/Templates/page-spec-template.md", pageSpecTemplateMd);
// 09 — working notes (STCB sub-structure addition; placeholder until the solution has one)
writeFile(
  "docs/09-Working-Notes/README.md",
  "# Working Notes\n\nIn-progress plans and specs, not yet confirmed. Not yet populated.\n",
);

// ─── Solution composition seam scaffolds (GAP-2, GAP-3, GAP-4, GAP-7, GAP-8, GAP-UI-2) ──
// These files are solution-owned (create-if-missing). The generator writes them once on first
// scaffold and never overwrites them. They establish the seams the DWS.01 real build had to
// hand-author: RBAC policy, external adapters, typed data client, lifecycle action components.
// See isSolutionOwned() for the matching path prefixes.
{
  // Computed identifiers for this solution.
  // solutionConst: SCREAMING_SNAKE form, e.g. "dws-01" → "DWS_01"
  const solutionConst = manifest.solution.toUpperCase().replace(/-/g, "_").replace(/[^A-Z0-9_]/g, "");

  // ── GAP-2: solution/rbac/ — subjects + personas + policy + can.ts + test ──────
  // Real, working ability compiler generated from this solution's own manifest —
  // entities become CASL subjects, iam.roles become scoped tier assignments.
  // Layer 06 (@dbp/ps-rbac) owns the tier-generation engine
  // (generateCapabilityMatrix/compileScopedAbilityFromAssignments); these files
  // only declare this solution's subjects/personas and compose the engine on
  // top — see Storybook: Layer 06 — Platform Services/PS.RBAC/Ability Model Guide.
  {
    const entityTypes = (manifest.entities ?? []).map((e) => e.type);
    const DEFAULT_ENTITY_VERBS = JSON.stringify(["read", "create", "update-own", "submit", "approve"]);

    // ── subjects: one entry per declared entity, default verb set ──────────────
    writeFile(
      `solution/rbac/${manifest.solution}-subjects.ts`,
      `// ── ${manifest.solution} RBAC subjects — SOLUTION-OWNED ─────────────────────────
// One entry per entity declared in this solution's manifest (manifest.entities[].type).
// generateCapabilityMatrix() (@dbp/ps-rbac) expands each subject's verb array into
// the viewer < contributor < reviewer < approver tier ladder. The default verb set
// below is a generic lifecycle-record shape — trim verbs an entity doesn't need
// (e.g. drop "submit"/"approve" for a reference/lookup entity with no approval
// flow), or add "retire" (dead-record close-out), "waive" (exception grant),
// "map"/"test"/"assess" (execution actions) where the entity needs them.
import type { SubjectVerbMap } from "@dbp/ps-rbac/server";

export const ${solutionConst}_SUBJECTS: SubjectVerbMap = {
${entityTypes.map((t) => `  "${t}": ${DEFAULT_ENTITY_VERBS},`).join("\n") || "  // No entities declared yet — add one per manifest.entities[].type."}
};
`,
    );

    // ── personas: one entry per declared role, default tier assignment ─────────
    const manifestRoles = manifest.iam?.roles ?? [];
    const defaultTierFor = (roleId) => (roleId === "platform-admin" ? "admin" : roleId === "viewer" ? "viewer" : "contributor");
    const personaEntries = manifestRoles.length
      ? manifestRoles.map((r) => `  "${r.id}": [{ role: "${defaultTierFor(r.id)}" }],`).join("\n")
      : `  "platform-admin": [{ role: "admin" }],\n  viewer: [{ role: "viewer" }],`;
    writeFile(
      `solution/rbac/${manifest.solution}-personas.ts`,
      `// ── ${manifest.solution} RBAC personas — SOLUTION-OWNED ─────────────────────────
// Maps this solution's declared roles (manifest.iam.roles) to a scoped
// capability-tier assignment ({ role, domain?, entityId?, orgUnitPath? }). A role
// id here is a persona name; the actual grant comes from the CapabilityRole tier
// (and optional domain/entityId/orgUnitPath scope) it's assigned below — never
// add permissions by inventing a new persona-named CASL role, always assign an
// existing tier with a scope.
// "platform-admin" -> admin and "viewer" -> viewer are the only two roles the
// generator defaults confidently; every other declared role defaults to an
// unscoped "contributor" — narrow it to "reviewer"/"approver" and/or add a
// domain/entityId/orgUnitPath scope as the solution's real persona needs it.
// orgUnitPath ("acme/engineering") is a department/business-unit hierarchy scope —
// a prefix match, not a nested-Group mechanism (see the Storybook guide: Layer 06
// — Platform Services/PS.RBAC/Tenants, Groups & Roles).
import type { RoleAssignment } from "@dbp/ps-rbac/server";

export const ${solutionConst}_PERSONAS: Record<string, RoleAssignment[]> = {
${personaEntries}
};
`,
    );

    // ── policy: composes the engine — no more "not yet wired" stub ─────────────
    writeFile(
      `solution/rbac/${manifest.solution}-policy.ts`,
      `// ── ${manifest.solution} RBAC policy — SOLUTION-OWNED ───────────────────────────
// Composes @dbp/ps-rbac's tiered-ability engine over this solution's own
// subjects (${manifest.solution}-subjects.ts) and personas (${manifest.solution}-personas.ts).
// Never reimplement generateCapabilityMatrix/compileScopedAbilityFromAssignments
// here — extend the subjects/personas files instead.
import {
  generateCapabilityMatrix,
  compileScopedAbilityFromAssignments,
  resolveEffectiveAssignments,
  getGroupRoleResolver,
  getUserRoleResolver,
  type AbilityContext,
  type GroupRoleResolver,
  type UserRoleResolver,
} from "@dbp/ps-rbac/server";
import { ${solutionConst}_SUBJECTS } from "./${manifest.solution}-subjects";
import { ${solutionConst}_PERSONAS } from "./${manifest.solution}-personas";

export type Ability = ReturnType<typeof compileScopedAbilityFromAssignments>;

/** The full generated capability matrix for this solution's declared subjects. */
export const ${solutionConst}_MATRIX = generateCapabilityMatrix(${solutionConst}_SUBJECTS);

/**
 * Compiles a ready-to-use Ability for a session's flat roles[]. Direct roles
 * are merged with Group-inherited and directly-user-assigned roles (via
 * @dbp/ps-rbac's resolveEffectiveAssignments — the Groups-aware primitive),
 * then resolved through ${manifest.solution}-personas.ts into scoped
 * assignments, before compiling against ctx's userId/tenantId (ownership +
 * tenant-scoping conditions).
 *
 * groupResolver/userResolver default to whatever this process last passed to
 * setGroupRoleResolver()/setUserRoleResolver() (@dbp/ps-rbac/server) — under
 * RBAC_ADMIN_STORAGE=drizzle, bootstrapAdminStorage() wires those
 * automatically, so Groups work with zero extra code here. Pass an explicit
 * resolver only to override that default (e.g. in a test).
 */
export async function compileSolutionAbility(
  roles: readonly string[],
  ctx: AbilityContext = {},
  groupResolver: GroupRoleResolver | undefined = getGroupRoleResolver(),
  userResolver: UserRoleResolver | undefined = getUserRoleResolver(),
): Promise<Ability> {
  const assignments = await resolveEffectiveAssignments(
    roles,
    ctx.userId ?? "",
    ctx.tenantId ?? "",
    ${solutionConst}_PERSONAS,
    groupResolver,
    userResolver,
  );
  return compileScopedAbilityFromAssignments(${solutionConst}_MATRIX, assignments, ctx);
}
`,
    );

    // ── RBAC-SPEC.md: builder-adaptable spec, pre-filled from the manifest ─────
    // Distinct from the code files above: this documents WHY this solution's
    // subjects/personas are scoped the way they are, for the humans building
    // and reviewing this solution — not consumed by any code path. Lives under
    // docs/ (solution-owned, create-if-missing) so it survives regens and is
    // the builder's to extend per client, same discipline as -subjects.ts/
    // -personas.ts.
    writeFile(
      "docs/03-Features/platform-services/ps-rbac/RBAC-SPEC.md",
      `# ${manifest.name} — RBAC Spec

Builder-owned spec for this solution's RBAC model. Generated once from
\`SOLUTION.md\` at first scaffold (create-if-missing — edit freely, it will
never be overwritten). For the general design pattern this implements
(subjects/verbs/tiers, tenancy, Groups, scoping) see the DBP factory's
Storybook guides: **Layer 06 — Platform Services/PS.RBAC/Ability Model
Guide** and **.../Tenants, Groups & Roles**. This file is the solution-
specific counterpart — what THIS solution actually declared, and why.

## Declared subjects (\`solution/rbac/${manifest.solution}-subjects.ts\`)

One row per entity in \`manifest.entities\`. The verb set is the generator's
generic default — trim/extend it here in prose first, then in the \`.ts\`
file, so the two stay in sync.

| Subject | Default verbs | Notes (fill in) |
|---|---|---|
${
  entityTypes.length
    ? entityTypes.map((t) => `| \`${t}\` | read, create, update-own, submit, approve | _—_ |`).join("\n")
    : "| _none declared yet_ | — | Add entities to \`manifest.entities\`, then re-scaffold. |"
}

## Declared personas (\`solution/rbac/${manifest.solution}-personas.ts\`)

One row per role in \`manifest.iam.roles\`. \`platform-admin\`/\`viewer\` get a
confident default; every other persona defaults to an **unscoped
contributor** — this is a safe floor, not this client's real model. Fill in
the actual scope (\`domain\`, \`entityId\`, or \`orgUnitPath\` for department/
business-unit hierarchy) before this solution ships.

| Persona role id | Default tier | Real scope (fill in) |
|---|---|---|
${
  manifestRoles.length
    ? manifestRoles.map((r) => `| \`${r.id}\` | ${defaultTierFor(r.id)} | _—_ |`).join("\n")
    : "| \`platform-admin\` | admin | _—_ |\n| \`viewer\` | viewer | _—_ |"
}

## Client-specific notes

_Fill in for this deployment: the client's actual org structure (departments/
business units, if using \`orgUnitPath\`), any personas beyond \`manifest.iam.roles\`
that need a Group instead of a direct role, and any compliance/segregation-of-
duties requirements specific to this client._

## Extension checklist

1. Edit the subjects/personas tables above, then mirror the same change into
   the \`.ts\` files — the tables here are documentation, not a build input.
2. Set \`RBAC_ADMIN_STORAGE=drizzle\` + \`DATABASE_URL\` before relying on Groups
   in this deployment — see the Tenants, Groups & Roles guide §0 for the full
   runbook (tenant provisioning, env vars, admin onboarding).
3. Call \`compileSolutionAbility(session.roles, { userId, tenantId })\` from
   any route handler/server action that needs a domain/entity/org-unit-scoped
   check; keep \`useCan\`/\`Gate\` for simple tenant/ownership-scoped UI gating.
`,
    );
  }

  // ── Shared Role union (DWS.01 audit 2.7) — one typed source for role names ────
  // Projected from the manifest iam.roles at first scaffold. Solution code imports
  // Role/ROLES from here instead of scattering magic strings across files.
  {
    const manifestRoleIds = (manifest.iam?.roles ?? []).map((r) => r.id);
    const allRoles = [...new Set(["platform-admin", "user", ...manifestRoleIds])];
    writeFile(
      "solution/rbac/roles.ts",
      `// ── ${manifest.solution} canonical roles — SOLUTION-OWNED ────────────────────────
// Single typed source for role names (projected from the manifest iam: block at
// first scaffold). Import Role/ROLES from here — never retype role strings inline.
export const ROLES = ${JSON.stringify(allRoles)} as const;
export type Role = (typeof ROLES)[number];

export function isRole(value: string): value is Role {
  return (ROLES as readonly string[]).includes(value);
}
`,
    );
  }

  writeFile(
    "solution/rbac/can.ts",
    `// ── ${manifest.solution} ability surface — SOLUTION-OWNED ───────────────────────
// Public RBAC entry point for this solution. Pages/components import from here,
// never from @dbp/ps-rbac directly, so the composition seam stays in one place.
//
// Two ability paths coexist, same as the platform base package itself:
//   - compileSolutionAbility() — this solution's generated, domain/entity-scoped
//     tiered ability (server-side; call it from route handlers/server actions).
//   - useCan/Gate — the platform's flat, session-scoped packed-rules ability
//     (client-side; wired to the PS.RBAC HTTP API, tenant/ownership-only scope).
// Use the scoped path once a feature needs domain/entity conditions; the flat
// client path remains the default for simple action-gating in "use client" code.
export { compileSolutionAbility, ${solutionConst}_MATRIX, type Ability } from "./${manifest.solution}-policy";
export { ${solutionConst}_SUBJECTS } from "./${manifest.solution}-subjects";
export { ${solutionConst}_PERSONAS } from "./${manifest.solution}-personas";
export { can, compileAbility } from "@dbp/ps-rbac/server";
// Client-side helpers (use inside "use client" components):
export { useCan, useAbility, Gate } from "@dbp/ps-rbac/client";
// Canonical role names (typed) — never retype role strings inline.
export { ROLES, isRole, type Role } from "./roles";
`,
  );

  writeFile(
    `solution/rbac/${manifest.solution}-policy.test.ts`,
    `import { describe, it, expect } from "vitest";
// DEF-8 (blueprint-2026-07-05-release-defects.md): import directly from the policy
// module this test exercises, not via "./can" — can.ts is create-if-missing like every
// other file here, so on a solution that already has its own solution/rbac/can.ts
// (a real, wired RBAC engine under this same conventional filename), the generator
// preserves it untouched while still additively creating this test — and a test that
// depended on "./can" would then be silently coupled to whatever THAT file happens to
// export, which need not match this freshly-scaffolded policy at all.
import { ${solutionConst}_MATRIX, compileSolutionAbility } from "./${manifest.solution}-policy";
import { ROLES } from "./roles";

describe("${manifest.solution} RBAC policy", () => {
  it("generates a capability matrix from the declared subjects", () => {
    expect(Array.isArray(${solutionConst}_MATRIX)).toBe(true);
  });

  it("compiles an ability for every declared role without throwing", async () => {
    for (const role of ROLES) {
      const ability = await compileSolutionAbility([role], { userId: "u1", tenantId: "tenant-alpha" });
      expect(ability).toBeDefined();
    }
  });

  it("denies an unknown subject/verb for a freshly compiled ability", async () => {
    const ability = await compileSolutionAbility(["viewer"], { tenantId: "tenant-alpha" });
    expect(ability.can("manage", "not-a-real-subject-or-verb")).toBe(false);
  });
});
`,
  );

  // ── GAP-3: solution/adapters/ — external adapter contract stub ───────────────
  writeFile(
    "solution/adapters/example.ts",
    `// ── Solution adapter (example) — SOLUTION-OWNED ──────────────────────────────
// Adapters translate between a Layer 06 platform port and a solution-specific
// concern (an external system, a derived projection, a transition guard).
//
// CONTRACT:
//   • An adapter NEVER reimplements a platform service — it composes one.
//   • It exposes a narrow, typed function surface; callers depend on the
//     function signature, not on the platform package directly.
//   • Side-effects (audit, notify) go through the platform services, not ad hoc.
//
// Delete this example and add real adapters (e.g. <entity>-lifecycle.ts) as the
// solution grows. Lifecycle guards have a dedicated template (see GAP-10 / Wave 2).
export interface ExampleAdapter {
  /** Replace with the real port this adapter wraps. */
  describe(): string;
}

export function createExampleAdapter(): ExampleAdapter {
  return {
    describe: () => "Replace solution/adapters/example.ts with a real adapter.",
  };
}
`,
  );

  // ── GAP-8: solution/lib/data-client.ts — typed PS.DATA wrapper ───────────────
  writeFile(
    "solution/lib/data-client.ts",
    `// ── Typed PS.DATA client — SOLUTION-OWNED ────────────────────────────────────
// Thin, typed wrappers over @dbp/ps-data/client so solution pages get
// entity-typed list/get/create/update without restating the entity type string
// at every call site. Add one typed helper per entity as the solution grows.
//
// The platform client is the source of truth; this file only narrows generics.
import {
  listEntities,
  getEntity,
  createEntity,
  updateEntity,
  deleteEntity,
  type EntityData,
  type EntityRecord,
  type EntityRef,
  type ListEntitiesOptions,
  type EntityListResult,
} from "@dbp/ps-data/client";

/** List entities of a given type, typed to T. */
export function listEntitiesTyped<T extends EntityData>(
  type: EntityRef,
  options?: ListEntitiesOptions,
): Promise<EntityListResult<T>> {
  return listEntities<T>(type, options ?? {});
}

/** Fetch a single entity by id, typed to T. */
export function getEntityTyped<T extends EntityData>(
  type: EntityRef,
  id: string,
): Promise<EntityRecord<T>> {
  return getEntity<T>(type, id);
}

/** Create an entity, typed to T. */
export function createEntityTyped<T extends EntityData>(
  type: EntityRef,
  data: T,
): Promise<EntityRecord<T>> {
  return createEntity<T>(type, data);
}

/** Patch an entity (PS.DATA update is a PATCH), typed to T. */
export function updateEntityTyped<T extends EntityData>(
  type: EntityRef,
  id: string,
  patch: Partial<T>,
): Promise<EntityRecord<T>> {
  return updateEntity<T>(type, id, patch);
}

/** Delete an entity by id. */
export function deleteEntityTyped(type: EntityRef, id: string): Promise<void> {
  return deleteEntity(type, id);
}

// Per-entity convenience example (uncomment + define your entity data type):
//   export interface TaskData extends EntityData { title: string; status: string; }
//   export const listTasks = (o?: ListEntitiesOptions) => listEntitiesTyped<TaskData>("task", o);
`,
  );

  // ── GAP-UI-2: solution/features/example-actions.tsx — lifecycle-actions stub ─
  writeFile(
    "solution/features/example-actions.tsx",
    `"use client";
// ── Example lifecycle actions — SOLUTION-OWNED ───────────────────────────────
// Renders lifecycle transition buttons for a single entity record and drives
// the transition through the platform services:
//   PS.WORKFLOW  → records the transition as a workflow event (audit trail of state)
//   PS.DATA      → PATCH the entity to the new state
//   React Query  → invalidates the entity query so the UI reflects the new state
//
// Wave 1 ships this as a fixed EXAMPLE (entity type and states are placeholders).
// Wave 2 (GAP-10) re-emits per-entity versions with real states + transitions
// derived from manifest.entities[].lifecycle.
//
// Usage: copy this file to solution/features/<entity-type>-actions.tsx and fill in
// the entity type, NEXT_STATE map, and query keys to match your entity's lifecycle.
import { useQueryClient } from "@tanstack/react-query";
import { updateEntityTyped } from "../lib/data-client";

// Replace with the real lifecycle states (e.g. { open: "in-progress", "in-progress": "done" }).
const NEXT_STATE: Record<string, string | undefined> = {
  // open: "in-progress",
  // "in-progress": "review",
  // review: "done",
};

// Replace "example" with the real entity type key used in manifest.entities.
const ENTITY_TYPE = "example" as const;

export function ExampleActions({
  id,
  status,
}: {
  id: string;
  status: string;
}) {
  const qc = useQueryClient();
  const next = NEXT_STATE[status];

  async function advance() {
    if (!next) return;
    // 1. (PS.WORKFLOW) record the transition as a workflow event — wire to the
    //    workflow instance for this entity once the workflow is defined.
    //    await startOrAdvanceWorkflow(ENTITY_TYPE, id, { from: status, to: next });
    // 2. (PS.DATA) persist the new state (PATCH).
    await updateEntityTyped<{ status: string }>(ENTITY_TYPE, id, { status: next });
    // 3. (PS.AUDIT) the data write is audited by the platform; add a domain event
    //    here if the solution needs a richer audit record.
    // 4. (React Query) invalidate so the detail view and list re-fetch.
    await qc.invalidateQueries({ queryKey: ["entity", ENTITY_TYPE, id] });
    await qc.invalidateQueries({ queryKey: ["entity-list", ENTITY_TYPE] });
  }

  if (!next) return null;
  return (
    <button type="button" onClick={advance} className="dbp-button dbp-button--primary">
      Advance to {next}
    </button>
  );
}
`,
  );

  // ── T2.2 + T2.4 (GAP-10 Wave 2): per-entity lifecycle adapter + actions stubs ──
  // For each entity in manifest.entities that declares a lifecycle, emit:
  //   • solution/adapters/<type>-lifecycle.ts  — transition-guard stub (T2.2)
  //   • solution/features/<type>-actions.tsx   — real lifecycle actions component (T2.4)
  // Both are solution-owned (create-if-missing), so they survive --force regen.
  for (const entity of (manifest.entities ?? [])) {
    if (!entity.lifecycle) continue;

    const { type: entityType, lifecycle } = entity;
    const { states, initial, transitions } = lifecycle;

    // Capitalise entity type for use as a TypeScript identifier.
    const EntityPascal = entityType.replace(/(^|[-_])([a-z])/g, (_, _sep, c) => c.toUpperCase());
    // Status field: first enum field whose values include lifecycle states, or "status".
    const stageField =
      entity.fields?.find((f) => f.name === "status")?.name ??
      entity.fields?.find((f) => f.type === "enum" && f.enum?.some((v) => states.includes(v)))?.name ??
      "status";

    // Build the ALLOWED_TRANSITIONS map literal.
    const transitionMap = {};
    for (const t of transitions) {
      if (!transitionMap[t.from]) transitionMap[t.from] = [];
      transitionMap[t.from].push(t.to);
    }
    const transitionMapLiteral =
      "{\n" +
      Object.entries(transitionMap)
        .map(([from, tos]) => `    ${JSON.stringify(from)}: [${tos.map((t) => JSON.stringify(t)).join(", ")}],`)
        .join("\n") +
      "\n  }";

    // Build quickActions for the React component.
    const quickActionsCases = transitions.map((t) => {
      const label = t.action
        ? t.action.replace(/(^|[-_])([a-z])/g, (_, _s, c) => (_s ? " " : "") + c.toUpperCase())
        : `Move to ${t.to.replace(/(^|[-_])([a-z])/g, (_, _s, c) => (_s ? " " : "") + c.toUpperCase())}`;
      return `  if (${stageField} === ${JSON.stringify(t.from)}) {
    buttons.push(
      <button key="${t.action ?? `to-${t.to}`}" type="button"
        className="dbp-button dbp-button--primary"
        onClick={() => advance(${JSON.stringify(t.to)})}>
        ${label}
      </button>,
    );
  }`;
    }).join("\n");

    // ── T2.2: lifecycle adapter stub ─────────────────────────────────────────
    writeFile(
      `solution/adapters/${entityType}-lifecycle.ts`,
      `// ── ${entityType} lifecycle adapter — SOLUTION-OWNED ────────────────────────────
// Transition guard for the ${entityType} entity. Enforce business rules BEFORE
// PS.DATA persists a state change. Called from the PS.DATA route interception
// seam in app/api/platform/data/[...path]/route.ts.
//
// Entity: ${entityType}
// Initial state: ${JSON.stringify(initial)}
// States: ${JSON.stringify(states)}
//
// Usage:
//   import { assertTransitionAllowed } from "../../adapters/${entityType}-lifecycle";
//   assertTransitionAllowed(currentRecord.data.${stageField}, patch.${stageField});
//   // throws → PS.DATA route returns 422 with the error message

/** Map of allowed state transitions for ${entityType}. */
export const ALLOWED_TRANSITIONS: Record<string, string[]> = ${transitionMapLiteral};

/**
 * Assert that a transition from 'from' to 'to' is permitted.
 * Throws a descriptive Error if the transition is invalid; callers should catch
 * and return a 422 response so the client receives a clear error message.
 *
 * @param from  Current lifecycle state (from the persisted record).
 * @param to    Requested target state (from the incoming PATCH body).
 */
export function assertTransitionAllowed(from: string | undefined, to: string | undefined): void {
  if (!to) return; // no state change requested
  if (!from) {
    // New record — only the initial state is allowed.
    if (to !== ${JSON.stringify(initial)}) {
      throw new Error(
        "${entityType}: new records must start in state '${initial}', got '" + to + "'",
      );
    }
    return;
  }
  const allowed = ALLOWED_TRANSITIONS[from] ?? [];
  if (!allowed.includes(to)) {
    const targets = allowed.length ? allowed.join(", ") : "(none — terminal state)";
    throw new Error(
      "${entityType}: transition '" + from + "' to '" + to + "' is not allowed. Allowed from '" + from + "': " + targets,
    );
  }
}
`,
    );

    // ── T2.4: lifecycle actions component ────────────────────────────────────
    writeFile(
      `solution/features/${entityType}-actions.tsx`,
      `"use client";
// ── ${EntityPascal} lifecycle actions — SOLUTION-OWNED ───────────────────────
// Renders the allowed lifecycle transition buttons for a single ${entityType} record.
// Drives transitions through platform services:
//   PS.DATA      → PATCH the entity to the new state
//   React Query  → invalidates entity queries so the UI reflects the new state
//
// Entity:       ${entityType}
// Stage field:  ${stageField}
// States:       ${JSON.stringify(states)}
//
// To add PS.WORKFLOW recording, uncomment the startOrAdvanceWorkflow call below
// and wire the workflow instance id from the entity record or a workflow lookup.
import { useQueryClient } from "@tanstack/react-query";
import { updateEntityTyped } from "../lib/data-client";

const ENTITY_TYPE = ${JSON.stringify(entityType)} as const;

export function ${EntityPascal}Actions({
  id,
  ${stageField},
}: {
  id: string;
  ${stageField}: string;
}) {
  const qc = useQueryClient();

  async function advance(to: string) {
    // 1. (PS.WORKFLOW) optionally record the transition as a workflow event.
    //    await startOrAdvanceWorkflow(ENTITY_TYPE, id, { from: ${stageField}, to });
    // 2. (PS.DATA) persist the new state.
    await updateEntityTyped<{ ${stageField}: string }>(ENTITY_TYPE, id, { ${stageField}: to });
    // 3. (React Query) invalidate so list + detail views re-fetch.
    await qc.invalidateQueries({ queryKey: ["entity", ENTITY_TYPE, id] });
    await qc.invalidateQueries({ queryKey: ["entity-list", ENTITY_TYPE] });
  }

  const buttons: React.ReactNode[] = [];
${quickActionsCases}

  if (buttons.length === 0) return null;
  return <div className="flex gap-2">{buttons}</div>;
}
`,
    );
  }

  // ── GAP-UI-10: service-catalog request pattern ───────────────────────────────
  // For each entity with requestable: true, emit the 5-page scaffold + solution-owned stubs.
  // The paired request entity is identified by the convention <catalogType>-request,
  // or the first lifecycle entity if no matching name exists.
  for (const catalogEntity of (manifest.entities ?? [])) {
    if (!catalogEntity.requestable) continue;

    const catalogType = catalogEntity.type;
    const CatalogPascal = catalogType.replace(/(^|[-_])([a-z])/g, (_, _s, c) => c.toUpperCase());
    const requestType = `${catalogType}-request`;
    const RequestPascal = requestType.replace(/(^|[-_])([a-z])/g, (_, _s, c) => c.toUpperCase());

    // Find the paired request entity (by naming convention or first lifecycle entity).
    const requestEntity = (manifest.entities ?? []).find((e) => e.type === requestType)
      ?? (manifest.entities ?? []).find((e) => e.lifecycle);

    const requestLifecycle = requestEntity?.lifecycle;
    const requestStates = requestLifecycle?.states ?? ["draft", "submitted", "in-review", "approved", "rejected"];
    const requestInitial = requestLifecycle?.initial ?? "draft";
    const requestTransitions = requestLifecycle?.transitions ?? [
      { from: "draft", to: "submitted", label: "Submit" },
      { from: "submitted", to: "in-review", label: "Begin Review" },
      { from: "in-review", to: "approved", label: "Approve" },
      { from: "in-review", to: "rejected", label: "Reject" },
    ];

    // Request form fields — from requestForm.fields or a minimal default.
    const formFields = catalogEntity.requestForm?.fields ?? [
      { name: "description", type: "textarea", label: "Description", required: true },
    ];

    // ── solution/features/<type>-request.tsx (solution-owned, create-if-missing) ─
    writeFile(
      `solution/features/${requestType}.tsx`,
      `"use client";
// ── ${RequestPascal} form — SOLUTION-OWNED ──────────────────────────────────
// Request submission form for the ${catalogType} service-catalog pattern (GAP-UI-10).
// Edit this file freely — it is never overwritten by the generator.
//
// PS integrations:
//   PS.DATA     → creates the ${requestType} entity
//   PS.WORKFLOW → startOrAdvanceWorkflow on submit (see TODO below)
//   PS.AUDIT    → logs the submission event
//   PS.NOTIF    → notification on submit (configure in instrumentation.ts)
import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import {
  Alert,
  Button,
  FormField,
  Input,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@dbp/ui";
import { createEntityTyped } from "../lib/data-client";

const REQUEST_ENTITY_TYPE = ${JSON.stringify(requestType)} as const;

const ${RequestPascal}FormSchema = z.object({
${formFields.map((f) => {
  const base = f.type === "number" ? "z.number()" : f.type === "boolean" || f.type === "checkbox" ? "z.boolean()" : `z.string()`;
  const optional = f.required ? "" : ".optional()";
  return `  ${f.name}: ${base}${optional},`;
}).join("\n")}
});
type ${RequestPascal}FormData = z.infer<typeof ${RequestPascal}FormSchema>;

export function ${RequestPascal}Form({ serviceId, onSuccess }: { serviceId: string; onSuccess?: () => void }) {
  const qc = useQueryClient();
  const [submitError, setSubmitError] = useState<string | null>(null);
  const { register, control, handleSubmit, formState: { errors, isSubmitting } } = useForm<${RequestPascal}FormData>({
    resolver: zodResolver(${RequestPascal}FormSchema),
  });

  async function onSubmit(data: ${RequestPascal}FormData) {
    setSubmitError(null);
    try {
      // 1. Create the request entity via PS.DATA.
      const created = await createEntityTyped<${RequestPascal}FormData & { serviceId: string; status: string }>(
        REQUEST_ENTITY_TYPE,
        { ...data, serviceId, status: ${JSON.stringify(requestInitial)} },
      );
      // 2. TODO: start a PS.WORKFLOW instance for this request.
      //    const wf = await startWorkflow("${requestType}-workflow", { entityId: created.id });
      //    await updateEntityTyped(REQUEST_ENTITY_TYPE, created.id, { workflowInstanceId: wf.instanceId });
      // 3. TODO: call PS.AUDIT to record the submission.
      //    await audit({ action: "submit", entityType: REQUEST_ENTITY_TYPE, entityId: created.id });
      void created;
      await qc.invalidateQueries({ queryKey: ["entity-list", REQUEST_ENTITY_TYPE] });
      onSuccess?.();
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : "Submission failed. Please try again.");
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5">
      {submitError && <Alert tone="danger">{submitError}</Alert>}
${formFields.map((f) => {
  const label = f.label ?? f.name.replace(/([A-Z])/g, " $1").replace(/^./, (c) => c.toUpperCase());
  const errSpread = `...(errors.${f.name}?.message ? { error: errors.${f.name}?.message } : {})`;
  if (f.type === "textarea") {
    return `      <FormField label="${label}"${f.required ? " required" : ""} {${errSpread}}>
        <textarea
          {...register(${JSON.stringify(f.name)})}
          rows={4}
          disabled={isSubmitting}
          className="w-full resize-y rounded-md border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2 text-sm text-[var(--color-text)] placeholder:text-[var(--color-text-muted)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] disabled:opacity-50"
        />
      </FormField>`;
  }
  if (f.type === "select") {
    const items = (f.options ?? []).map((o) => `          <SelectItem value="${o}">${o.charAt(0).toUpperCase() + o.slice(1)}</SelectItem>`).join("\n");
    return `      <FormField label="${label}"${f.required ? " required" : ""} {${errSpread}}>
        <Controller
          name={${JSON.stringify(f.name)}}
          control={control}
          render={({ field }) => (
            <Select value={field.value ?? ""} onValueChange={field.onChange} disabled={isSubmitting}>
              <SelectTrigger>
                <SelectValue placeholder="Select…" />
              </SelectTrigger>
              <SelectContent>
${items}
              </SelectContent>
            </Select>
          )}
        />
      </FormField>`;
  }
  return `      <FormField label="${label}"${f.required ? " required" : ""} {${errSpread}}>
        <Input
          type="${f.type === "number" ? "number" : f.type === "date" ? "date" : "text"}"
          {...register(${JSON.stringify(f.name)})}
          disabled={isSubmitting}
        />
      </FormField>`;
}).join("\n")}
      <div className="flex justify-end pt-1">
        <Button type="submit" loading={isSubmitting} disabled={isSubmitting}>
          {isSubmitting ? "Submitting…" : "Submit Request"}
        </Button>
      </div>
    </form>
  );
}
`,
    );

    // ── solution/workflows/<type>-request.ts (solution-owned, create-if-missing) ─
    const workflowTransitionsLiteral = requestTransitions
      .map((t) => `  { from: ${JSON.stringify(t.from)}, to: ${JSON.stringify(t.to)}, label: ${JSON.stringify(t.label ?? t.to)} },`)
      .join("\n");

    writeFile(
      `solution/workflows/${requestType}.ts`,
      `// ── ${requestType} workflow definition — SOLUTION-OWNED ──────────────────────
// PS.WORKFLOW definition for the ${catalogType} service-catalog request pattern (GAP-UI-10).
// Register this workflow in instrumentation.ts via:
//   import { ${RequestPascal}WorkflowDef } from "./solution/workflows/${requestType}";
//   await workflow.registerDefinition(${RequestPascal}WorkflowDef);
//
// Edit freely — not overwritten by the generator.

export const ${RequestPascal}WorkflowDef = {
  id: ${JSON.stringify(`${requestType}-workflow`)},
  name: ${JSON.stringify(`${CatalogPascal} Request Workflow`)},
  entityType: ${JSON.stringify(requestType)},
  initialState: ${JSON.stringify(requestInitial)},
  states: ${JSON.stringify(requestStates)},
  transitions: [
${workflowTransitionsLiteral}
  ],
  // Notification hooks — configure PS.NOTIF here or in instrumentation.ts.
  // Example:
  //   on: {
  //     submitted: async ({ entityId }) => notif.send({ template: "request-submitted", entityId }),
  //     approved:  async ({ entityId }) => notif.send({ template: "request-approved",  entityId }),
  //     rejected:  async ({ entityId }) => notif.send({ template: "request-rejected",  entityId }),
  //   },
} as const;
`,
    );

    // ── 5 generator-owned page files ─────────────────────────────────────────

    // Page 1: /catalog — browse catalog items
    writeFile(
      "app/(authenticated)/catalog/page.tsx",
      `// Catalog browse page — generator-owned (GAP-UI-10). Do not hand-edit.
// To customise, override in solution/features/${catalogType}-catalog-overrides.tsx.
"use client";
import { useRouter } from "next/navigation";
import { PageHeader } from "@dbp/ui";
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import EntityList from "@dbp/organisms/entity-list";

export default function CatalogPage() {
  const router = useRouter();
  return (
    <CanvasLayout header={<PageHeader title="Service Catalog" />}>
      <EntityList
        entityType=${JSON.stringify(catalogType)}
        detailHref="/catalog"
        selectable
        columns={[
          { field: "name", label: "Name" },
          { field: "summary", label: "Summary" },
          { field: "status", label: "Status", format: "badge" as const },
        ]}
        rowAction={{
          label: "Request",
          onClick: (row) => router.push(\`/catalog/\${row.id}/request\`),
        }}
      />
    </CanvasLayout>
  );
}
`,
    );

    // Page 2: /catalog/[id] — service detail + request CTA
    writeFile(
      "app/(authenticated)/catalog/[id]/page.tsx",
      `// Catalog detail page — generator-owned (GAP-UI-10). Do not hand-edit.
"use client";
import { use } from "react";
import Link from "next/link";
import { PageHeader } from "@dbp/ui";
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import { EntityDetail } from "@dbp/stack/features/entity-detail";

export default function CatalogDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return (
    <CanvasLayout
      header={
        <PageHeader
          title="Service Detail"
          actions={<Link href={\`/catalog/\${id}/request\`} className="dbp-button dbp-button--primary">Request this service</Link>}
        />
      }
    >
      <EntityDetail entityType=${JSON.stringify(catalogType)} entityId={id} />
    </CanvasLayout>
  );
}
`,
    );

    // Page 3: /catalog/[id]/request — submit request form
    writeFile(
      "app/(authenticated)/catalog/[id]/request/page.tsx",
      `// Request submission page — generator-owned (GAP-UI-10). Do not hand-edit.
"use client";
import { use } from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@dbp/ui";
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import { ${RequestPascal}Form } from "../../../../../solution/features/${requestType}";

export default function RequestPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  return (
    <CanvasLayout header={<PageHeader title="Submit Request" />}>
      <div className="max-w-xl">
        <${RequestPascal}Form serviceId={id} onSuccess={() => router.push("/transactions/requests")} />
      </div>
    </CanvasLayout>
  );
}
`,
    );

    // NOTE: No /my-requests page emitted. The existing /transactions/requests
    // module is the RBAC-scoped personal request list — no duplicate needed.

    // Page 4: /admin/requests — admin request queue (gated)
    writeFile(
      "app/(authenticated)/admin/requests/page.tsx",
      `// Admin request queue — generator-owned (GAP-UI-10). Do not hand-edit.
// Nav entry for this page is gated via nav.gating: rbac (requiredPermission: ${requestType}.manage).
"use client";
import { PageHeader } from "@dbp/ui";
import { CanvasLayout } from "@dbp/shell-transaction/layouts";
import EntityList from "@dbp/organisms/entity-list";

export default function AdminRequestsPage() {
  return (
    <CanvasLayout header={<PageHeader title="Request Queue" />}>
      <EntityList
        entityType=${JSON.stringify(requestType)}
        detailHref="/admin/requests"
        columns={[
          { field: "serviceId",  label: "Service" },
          { field: "status",     label: "Status", format: "badge" as const },
          { field: "createdAt",  label: "Submitted", format: "date" as const },
        ]}
      />
    </CanvasLayout>
  );
}
`,
    );
  }
}

// ── GAP-4: app/api/solution/README.md — solution route namespace marker ──────
// Generator-owned (always re-emitted). Documents the /api/solution/* namespace.
writeFile(
  "app/api/solution/README.md",
  `# \`/api/solution/\` — solution-owned route namespace

This namespace is reserved for **solution-specific** API routes that are NOT
provided by a Layer 06 platform service. Platform services already mount under
\`/api/platform/*\` (auth, data, notif, workflow, …) — never duplicate those here.

## When to add a route here

- A bespoke aggregation or projection the solution needs that no platform
  service exposes.
- A solution-specific webhook receiver or integration callback.
- A composition endpoint that orchestrates several platform services for one
  solution-specific operation.

## When NOT to add a route here

- Anything that is generic CRUD over an entity — use PS.DATA (\`/api/platform/data\`).
- Anything that should be reusable across solutions — it belongs in a platform
  service (Layer 06), not here.

## Convention

Create \`app/api/solution/<name>/route.ts\`. Import platform services via their
public \`@dbp/ps-*\` packages; never import another solution's internals.

> This file is documentation only — it does not register a route.
`,
);

// ─── Step 5a(c): Shared demo-LVE config helper (gaps-log #3) ──────────────────
// Emitted only when at least one demo-record LVE stub page exists. Captured from
// the first stub's fully-synthesised config; pages differ only by title.
if (demoLveCanonicalCfg) {
  const { title: _dropTitle, ...demoBase } = demoLveCanonicalCfg;
  writeFile(
    "lib/demo-lve-config.ts",
    `// lib/demo-lve-config.ts — shared config for DEMO-RECORD stub pages.
// Generated by scaffold-solution — do not edit (run with --force to regenerate).
// A page importing buildDemoLveConfig() is an UNBUILT stub: grep for
// "buildDemoLveConfig" to list every page still awaiting a real entity binding
// (bind one via the manifest entities: block or a module pageComponent).
const DEMO_LVE_BASE = ${JSON.stringify(demoBase, null, 2)};

export function buildDemoLveConfig(title: string) {
  return { ...DEMO_LVE_BASE, title };
}
`,
  );
}

// ─── Step 5b: Sweep stale generator-owned files (regen only) ──────────────────
// Remove generator-owned files left by a PREVIOUS regen that this run did not
// re-emit (e.g. a module route for a since-removed module). Provably never touches
// solution-owned paths — see sweepStaleGeneratorOwned().
sweepStaleGeneratorOwned();

// ─── Step 5b(i-report): Preserved-unknown-files report (sweep-ownership-authority fix) ──
// Files the sweep declined to delete because they are neither re-emitted this run nor
// provably a generator artifact from a prior run (see sweepStaleGeneratorOwned()). This
// must never fail the run — it is informational only, telling the builder that these
// files need to become either declared solution-owned or a real manifest module output.
if (preservedUnknownFiles.length > 0) {
  const sortedPreserved = [...preservedUnknownFiles].sort();
  const CAP = 20;
  console.log(`\n  ── Preserved unknown files (${sortedPreserved.length}) ─────────────────────`);
  console.log(
    "  Not deleted — neither re-emitted this run nor listed in the prior run's " +
      "solution/_arch/generator-owned.json, so they cannot be proven to be stale " +
      "generator artifacts. If these are hand-added on purpose, declare them in " +
      "manifest.solutionOwnedOverrides or author a manifest module that emits them.",
  );
  for (const rel of sortedPreserved.slice(0, CAP)) console.log(`    ${rel}`);
  if (sortedPreserved.length > CAP) console.log(`    + ${sortedPreserved.length - CAP} more`);
  console.log("  ──────────────────────────────────────────────────────────");
}

// ─── Step 5b(ii): Machine-readable ownership manifest ────────────────────────
// The exact generator-owned file list for THIS emission, sorted. Consumers:
// scripts/check-app-drift.mjs (regen-and-diff drift gate) and any tooling that
// must distinguish "regenerate freely" from "hand-authored — do not touch"
// without re-deriving the ownership predicate. Written after the sweep so the
// list matches what is actually on disk (it includes itself).
{
  const ownershipRel = "solution/_arch/generator-owned.json";
  emittedGeneratorOwned.add(ownershipRel);
  const ownedList = [...emittedGeneratorOwned].sort();
  fs.mkdirSync(path.join(outDirBase, "solution/_arch"), { recursive: true });
  fs.writeFileSync(path.join(outDirBase, ownershipRel), JSON.stringify(ownedList, null, 2) + "\n", "utf8");
}

// ─── Step 5c: Post-emit conformance gate (errors FAIL the generation) ────────
// ERROR-class findings (e.g. double headers) abort with exit 1 so a nonconformant
// scaffold can never be reported as a success — a builder scaffolding at 6pm does
// not read the console block. Warnings never block. Escape hatch: --allow-nonconformant.
try {
  const { checkGeneratedConformance } = await import("./check-generated-conformance.mjs");
  const { errors: confErrors, warnings: confWarnings } = checkGeneratedConformance(outDirBase);
  console.log("\n  ── Conformance check ─────────────────────────────────────");
  if (confErrors.length === 0 && confWarnings.length === 0) {
    console.log("  ✓ pages conform — no errors or warnings");
  } else {
    const confSummary = `${confErrors.length} error${confErrors.length !== 1 ? "s" : ""}, ${confWarnings.length} warning${confWarnings.length !== 1 ? "s" : ""}`;
    console.log(`  ${confSummary}`);
    for (const e of confErrors) console.log(`  ERROR   ${e}`);
    for (const w of confWarnings) console.log(`  warn    ${w}`);
  }
  console.log("  ──────────────────────────────────────────────────────────");
  if (confErrors.length > 0 && !allowNonconformant) {
    die(
      `Post-emit conformance gate: ${confErrors.length} ERROR-class finding(s) above. ` +
        `The emitted files are on disk for inspection, but this generation is NOT a success. ` +
        `Fix the generator/template (or re-run with --allow-nonconformant to accept the debt).`,
    );
  }
} catch (confErr) {
  // A crash in the CHECKER itself must not mask a completed generation — but say so loudly.
  console.warn("  [conformance-check] checker error (generation still succeeded):", confErr.message);
}

// ─── Step 6: Print summary ────────────────────────────────────────────────────

const elapsed = ((Date.now() - startMs) / 1000).toFixed(1);

console.log(`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  DBP Scaffold Generator — ${manifest.name} (${manifest.solution})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Platform:       ${manifest.platform}
  Solution:       ${manifest.solution}
  Modules:        ${manifest.modules.map((m) => `${m.id} (${m.name})`).join(", ")}
  Journey stages: ${manifest.journey_stages.join(", ")}

  Layer 06 — WIRING (not building):
${consumedServices.map((id) => `    ${id}  ${SERVICE_META[id]?.packageName ?? id}  → ${SERVICE_META[id]?.basePath ?? ""}`).join("\n")}

  Layer 07 — SCAFFOLDING:
${manifest.modules.map((m) => `    ${m.scaffold}→${resolveShellId(m.scaffold)} ${SHELL_META[resolveShellId(m.scaffold)]?.packageName ?? m.scaffold}  (${m.name}, stage ${m.journey})`).join("\n")}
${manifest.modules.flatMap((m) => m.features.map((f) => `      ${f.id} as ${f.role} [${f.slot ?? featureMap.get(f.id)?.slot ?? "main"}] wires ${f.wires.join(",")}`)    ).join("\n")}

  Output:         ${outDirBase}
  Resolved arch:  ${path.join(outDirBase, "solution/_arch/SOLUTION.md")}

  Time:           ${elapsed}s

  Build time saved: auth, RBAC, audit, notifications, search, workflow,
                    AI, data, events, apigw — NOT rebuilt, wired by ID.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`);
