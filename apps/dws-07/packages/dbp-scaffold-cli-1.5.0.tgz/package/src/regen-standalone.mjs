#!/usr/bin/env node
/**
 * regen-standalone — the builder's "one file" workflow, inside a standalone repo.
 *
 *   1. Edit docs/10-Solutions/<ID>-SOLUTION.md   (add/change an entity, module, …)
 *   2. pnpm regen
 *   3. pnpm verify   (and pnpm install first, if the regen reports new packages)
 *
 * What it does:
 *   • Runs the shipped generator (scripts/scaffold-solution.mjs, standalone mode)
 *     over the repo root with --force. The ownership contract applies: your
 *     hand-authored files (solution/**, instrumentation.ts, docs, tests) are
 *     preserved; generator-owned chrome/pages/config are refreshed.
 *   • PRESERVES the standalone-flavoured package.json / next.config.ts /
 *     pnpm-workspace.yaml (the generator emits the monorepo flavour — those
 *     three are snapshotted before the regen and restored after).
 *   • Merges any NEWLY-required @dbp dependencies into the restored package.json
 *     as file: tarball refs — or warns when the tarball is missing (a manifest
 *     change that pulls a NEW platform feature needs a blueprint re-export).
 *
 * Usage:  node scripts/regen-standalone.mjs [--allow-dirty] [--allow-nonconformant]
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";
import { checkVersionSkew } from "./lib/version-skew.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const passthrough = process.argv.slice(2).filter((a) => ["--allow-dirty", "--allow-nonconformant"].includes(a));
const dryRun = process.argv.includes("--dry-run");

// ── WS-7: version-skew guard ───────────────────────────────────────────────────
// Ruling: regen only with a matching blueprint_version (bump @dbp/scaffold-cli and
// blueprint_version together). Read the CLI's own installed version (this script
// ships INSIDE the @dbp/scaffold-cli package once installed — see its package.json
// two directories up) and compare against this standalone's stamped blueprint_version.
{
  let cliVersion = null;
  try {
    const cliPkgPath = path.join(ROOT, "node_modules", "@dbp", "scaffold-cli", "package.json");
    cliVersion = JSON.parse(fs.readFileSync(cliPkgPath, "utf8")).version ?? null;
  } catch {
    // not installed yet, or not running from inside the installed package — fails closed below.
  }
  let blueprintVersion = null;
  try {
    const releasePath = path.join(ROOT, "blueprint-release.json");
    blueprintVersion = JSON.parse(fs.readFileSync(releasePath, "utf8")).blueprint_version ?? null;
  } catch {
    // missing blueprint-release.json — fails closed below.
  }
  const skew = checkVersionSkew({ cliVersion, blueprintVersion });
  if (!skew.ok) {
    console.error(`ERROR: regen refused — ${skew.reason}`);
    process.exit(1);
  }
}

// ── Locate the shipped manifest ───────────────────────────────────────────────
const manifestDir = path.join(ROOT, "docs", "10-Solutions");
const manifests = fs.existsSync(manifestDir)
  ? fs.readdirSync(manifestDir).filter((f) => f.endsWith("-SOLUTION.md"))
  : [];
if (manifests.length !== 1) {
  console.error(
    manifests.length === 0
      ? "ERROR: no manifest found at docs/10-Solutions/<ID>-SOLUTION.md — this repo predates the shipped-manifest export; ask the platform team for a re-export."
      : `ERROR: expected exactly one manifest in docs/10-Solutions/, found ${manifests.length}: ${manifests.join(", ")}`,
  );
  process.exit(1);
}
const manifestPath = path.join(manifestDir, manifests[0]);

// ── Dry-run: print the deletion/overwrite manifest and stop ───────────────────
if (dryRun) {
  execFileSync(
    process.execPath,
    [path.join(ROOT, "scripts", "scaffold-dry-run.mjs"), manifestPath, "--target", ROOT],
    { cwd: ROOT, stdio: "inherit" },
  );
  process.exit(0);
}

// ── Snapshot the standalone-flavoured config files ────────────────────────────
// These are generator-owned (regen overwrites them with the MONOREPO flavour:
// workspace:* deps, monorepo next.config). The standalone flavour was produced
// by export-standalone.sh and must survive the regen.
const PRESERVE = ["package.json", "next.config.ts", "pnpm-workspace.yaml"];
const snapshots = new Map();
for (const rel of PRESERVE) {
  const abs = path.join(ROOT, rel);
  if (fs.existsSync(abs)) snapshots.set(rel, fs.readFileSync(abs, "utf8"));
}

// ── Run the generator over the repo root ──────────────────────────────────────
console.log(`\n[regen] ${manifests[0]} → repo root (standalone mode)\n`);
try {
  execFileSync(
    process.execPath,
    [path.join(ROOT, "scripts", "scaffold-solution.mjs"), manifestPath, "--out-dir", ROOT, "--force", ...passthrough],
    { cwd: ROOT, stdio: "inherit" },
  );
} catch {
  // Generator failed (conformance gate, pre-regen safety check, …). Restore the
  // standalone config files so a half-regen never leaves the repo unbuildable.
  for (const [rel, content] of snapshots) fs.writeFileSync(path.join(ROOT, rel), content, "utf8");
  console.error("\n[regen] generator failed — standalone package.json/next.config restored unchanged.");
  process.exit(1);
}

// ── Restore standalone flavour + merge new deps ───────────────────────────────
const regenPkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
for (const [rel, content] of snapshots) fs.writeFileSync(path.join(ROOT, rel), content, "utf8");

// ── Quality-ratchet schema sync (WS-4.6) ───────────────────────────────────────
// The generator just regenerated scripts/check-ratchet.mjs in place (taxonomy is
// factory-owned and travels with every regen). quality-ratchet.json is
// solution-owned and untouched by the regen above — reconcile any taxonomy drift
// now. See scripts/lib/ratchet-merge.mjs for the ownership rule.
try {
  execFileSync(process.execPath, [path.join(ROOT, "scripts", "reconcile-ratchet.mjs"), ROOT], { cwd: ROOT, stdio: "inherit" });
} catch {
  console.error("\n[regen] quality-ratchet sync FAILED — check scripts/check-ratchet.mjs and quality-ratchet.json by hand.");
  process.exit(1);
}

const pkgPath = path.join(ROOT, "package.json");
const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
const pkgsDir = path.join(ROOT, "packages");
const tgzFor = (name) => {
  if (!fs.existsSync(pkgsDir)) return null;
  const prefix = name.replace(/^@/, "").replace(/\//g, "-") + "-";
  const hit = fs
    .readdirSync(pkgsDir)
    .filter((f) => f.startsWith(prefix) && /-[0-9]+\.[0-9]+\.[0-9]+\.tgz$/.test(f))
    .sort()
    .pop();
  return hit ? `file:packages/${hit}` : null;
};

let added = 0;
const missingTarballs = [];
for (const section of ["dependencies", "devDependencies"]) {
  for (const [name, ver] of Object.entries(regenPkg[section] ?? {})) {
    if (pkg[section]?.[name]) continue; // already present in the standalone flavour
    if (ver === "workspace:*") {
      const ref = tgzFor(name);
      if (ref) {
        pkg[section] = pkg[section] ?? {};
        pkg[section][name] = ref;
        added++;
        console.log(`[regen] new dependency ${name} → ${ref}`);
      } else {
        missingTarballs.push(name);
      }
    } else {
      pkg[section] = pkg[section] ?? {};
      pkg[section][name] = ver;
      added++;
      console.log(`[regen] new dependency ${name} → ${ver}`);
    }
  }
}
if (added > 0) {
  for (const s of ["dependencies", "devDependencies"]) {
    if (pkg[s]) pkg[s] = Object.fromEntries(Object.entries(pkg[s]).sort(([a], [b]) => a.localeCompare(b)));
  }
  fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n");
}

// ── Wrap up ───────────────────────────────────────────────────────────────────
console.log(`\n[regen] done — standalone package.json/next.config preserved${added > 0 ? `, ${added} new dependenc${added === 1 ? "y" : "ies"} merged` : ""}.`);
if (missingTarballs.length > 0) {
  console.warn(
    `\n[regen] ⚠ the manifest now requires ${missingTarballs.length} @dbp package(s) with NO local tarball:\n` +
      missingTarballs.map((n) => `    ${n}`).join("\n") +
      "\n  Entity/config changes never need this — it means the manifest pulled in a NEW platform feature.\n  Ask the platform team for a blueprint re-export (which ships the tarball), then re-run pnpm regen.",
  );
}
console.log(`\nNext steps:${added > 0 ? "\n  pnpm install" : ""}\n  pnpm verify\n  pnpm dev   (spot-check the affected screens)\n`);
