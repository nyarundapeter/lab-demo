#!/usr/bin/env node
/**
 * reconcile-ratchet.mjs — WS-4.6 (quality-ratchet schema sync between factory
 * apps and standalone exports). See scripts/lib/ratchet-merge.mjs for the full
 * ownership rule; this file is the impure driver: it reads the freshly
 * (re)generated scripts/check-ratchet.mjs in a target repo, diffs its taxonomy
 * against the target's existing quality-ratchet.json, and reconciles them —
 * new keys are seeded at their MEASURED local count (never at 0, which would
 * fail the very next `pnpm verify` for pre-existing debt), keys the taxonomy
 * no longer counts are dropped with a note, and every existing key's value is
 * left untouched.
 *
 * Called from both:
 *   - export-standalone.sh, right after publish-blueprint.mjs (step 2) has
 *     copied the app's freshly generated scripts/check-ratchet.mjs across.
 *   - regen-standalone.mjs, right after scaffold-solution.mjs --force has
 *     regenerated scripts/check-ratchet.mjs in place.
 *
 * Usage: node scripts/reconcile-ratchet.mjs <target-dir>
 * No-ops (exit 0) if the target has no check-ratchet.mjs or no
 * quality-ratchet.json yet — nothing to reconcile on a first-ever scaffold,
 * since scaffold-solution.mjs already writes a taxonomy-matched baseline
 * from scratch in that case.
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { parseRatchetTaxonomy, mergeRatchetTaxonomy } from "./lib/ratchet-merge.mjs";

const target = process.argv[2];
if (!target) {
  console.error("usage: node scripts/reconcile-ratchet.mjs <target-dir>");
  process.exit(1);
}

const checkRatchetPath = path.join(target, "scripts", "check-ratchet.mjs");
const baselinePath = path.join(target, "quality-ratchet.json");
if (!fs.existsSync(checkRatchetPath) || !fs.existsSync(baselinePath)) {
  process.exit(0); // nothing to reconcile
}

const taxonomyKeys = parseRatchetTaxonomy(fs.readFileSync(checkRatchetPath, "utf8"));
const oldBaseline = JSON.parse(fs.readFileSync(baselinePath, "utf8"));

const seededCandidates = taxonomyKeys.filter((k) => !Object.prototype.hasOwnProperty.call(oldBaseline, k));

// Measure real local counts for candidate new keys ONLY — never for keys already
// in oldBaseline (those are solution-owned and must not be re-measured/reset).
// check-ratchet.mjs has no "measure only" mode, so this runs it once against a
// temporary all-zero baseline: every key with a nonzero count then logs
// "[ratchet] KEY: N > baseline 0" to stderr, which is parsed back out. Keys not
// mentioned are 0 (which is already check-ratchet.mjs's own default via `?? 0`,
// so no seeding is needed for those regardless).
function measureCounts(keys) {
  if (keys.length === 0) return {};
  const original = fs.readFileSync(baselinePath, "utf8");
  fs.writeFileSync(baselinePath, "{}\n");
  let stderr = "";
  try {
    execFileSync(process.execPath, [checkRatchetPath], { cwd: target, encoding: "utf8", stdio: ["ignore", "ignore", "pipe"] });
  } catch (err) {
    stderr = err.stderr ?? "";
  } finally {
    fs.writeFileSync(baselinePath, original);
  }
  const measured = {};
  for (const key of keys) {
    const m = stderr.match(new RegExp(`\\[ratchet\\] ${key}: (\\d+) > baseline`));
    measured[key] = m ? Number(m[1]) : 0;
  }
  return measured;
}

const measured = measureCounts(seededCandidates);
const { merged, seeded, dropped } = mergeRatchetTaxonomy(oldBaseline, taxonomyKeys, measured);

if (seeded.length === 0 && dropped.length === 0) {
  console.log("[ratchet-sync] taxonomy already in sync — quality-ratchet.json unchanged");
  process.exit(0);
}

fs.writeFileSync(baselinePath, JSON.stringify(merged, null, 2) + "\n");
for (const key of seeded) {
  console.log(`[ratchet-sync] seeded new debt class '${key}' at measured baseline ${merged[key]} (solution-owned from here on)`);
}
for (const key of dropped) {
  console.log(`[ratchet-sync] dropped '${key}' — no longer part of the factory taxonomy (was ${oldBaseline[key]})`);
}
