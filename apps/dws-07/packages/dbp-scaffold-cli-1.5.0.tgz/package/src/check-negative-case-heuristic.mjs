#!/usr/bin/env node
/**
 * check-negative-case-heuristic — F8, docs/09-plans/minimum-test-plan-build-spec-2026-07-07.md
 * Increment E.
 *
 * Heuristic, not exhaustive: for each feature-package artifact's test file(s), greps test/describe
 * block names for at least one deny/invalid/error/reject-shaped case alongside the existing
 * happy-path unit-test requirement. A package can pass this check with a test named e.g.
 * "renders config-error when severityMap is missing" without that test necessarily covering a real
 * negative code path — it is a naming-convention proxy, intended to catch the common case of a
 * package with zero deny/invalid/error-shaped tests at all, not to verify test quality.
 *
 * Invoked by check-test-requirements.mjs via the "check" field on a requires[] entry (see
 * quality-matrix.json feature-package.requires[] "negative-case" row) — this script is called
 * once per artifact directory passed as argv[2].
 *
 * Exit code: 0 if at least one negative-case-shaped test name is found, 1 otherwise.
 *
 * Usage:
 *   node scripts/check-negative-case-heuristic.mjs <artifact-relative-dir>
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { globSync } from "node:fs";

const REPO_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const NEGATIVE_CASE_PATTERN = /deny|invalid|error|reject|throw|fail/i;
const TEST_NAME_CALL = /\b(?:it|test|describe)\s*\(\s*(["'`])((?:\\.|(?!\1).)*)\1/g;

function toPosix(p) {
  return p.replaceAll("\\", "/");
}

export function hasNegativeCaseTest(artifactDir) {
  const testFiles = globSync("**/*.test.{ts,tsx}", { cwd: path.join(REPO_ROOT, artifactDir), nodir: true });
  for (const rel of testFiles) {
    const text = fs.readFileSync(path.join(REPO_ROOT, artifactDir, rel), "utf8");
    for (const match of text.matchAll(TEST_NAME_CALL)) {
      if (NEGATIVE_CASE_PATTERN.test(match[2])) {
        return { found: true, file: toPosix(path.join(artifactDir, rel)), name: match[2] };
      }
    }
  }
  return { found: false };
}

// ─── CLI entry point ────────────────────────────────────────────────────────

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);
if (isMain) {
  const artifactDir = process.argv[2];
  if (!artifactDir) {
    console.error("Usage: node scripts/check-negative-case-heuristic.mjs <artifact-relative-dir>");
    process.exit(1);
  }
  const result = hasNegativeCaseTest(artifactDir);
  if (result.found) {
    console.log(`PASS  ${artifactDir}: negative-case test found (${result.file}: "${result.name}")`);
    process.exit(0);
  }
  console.error(`FAIL  ${artifactDir}: no deny/invalid/error/reject-shaped test name found`);
  process.exit(1);
}
