# db/verify/ and db/regression/ conventions

Added as part of **WS-4.1 + WS-6.5** (db-governance unification, 2026-07-26), generalising
dws-01's `db/verify/0001..0004.mjs` and `db/regression/*.sql` into factory-owned runners.

## db/verify/*.mjs — post-migration invariant checks

A migration replay (`scripts/db-migrate.mjs`) proves the SQL applied without error; it does not
prove the resulting schema/data looks the way the app expects. `db/verify/*.mjs` is where a
solution asserts that separately — e.g. "does `workspace.requests` have a `status` column",
"is the seeded org tree non-empty".

- Each file is a standalone Node script: connects to `DIRECT_URL`/`DATABASE_URL` itself, exits
  `0` on success and `1` (with a message on stderr) on failure. No shared imports required — the
  contract is just "exits nonzero on failure".
- Run the whole suite with `node scripts/db-verify.mjs` (runs `db/verify/*.mjs` in filename
  order, in its own process each, and reports a pass/fail summary).
- No-op (green) until the solution adds files under `db/verify/`.

## db/regression/*.sql — regression checks and one-off remediation

Two related uses seen in the field:

- **Regression check** — a read-only query that should return an expected result (e.g. "no
  orphaned rows after the last release"). Run via `node scripts/db-regression.mjs`, which wraps
  each file in its own transaction and **always rolls back** — safe to run in CI, never persists
  anything.
- **Remediation script** — a deliberate one-off data fix outside the migration ledger (e.g.
  dws-01's `db/regression/positions.sql`, which assigns VSM position roles). Run it for real with
  `node scripts/db-regression.mjs --commit <file>` — never wired into CI, a human runs this
  on purpose.

## Generator wiring — known follow-up

`scripts/scaffold-solution.mjs`'s `emitMigrationGovernance()` copies the other
`db-governance-templates/*` files verbatim into every generated solution's `scripts/`, but does
**not yet** create empty `db/verify/` and `db/regression/` directories or copy `db-verify.mjs` /
`db-regression.mjs` — that file is owned by another workstream at the time this convention landed.
Until that wiring lands, a solution adopting this convention copies `db-verify.mjs` and
`db-regression.mjs` from this directory by hand and creates its own `db/verify/`, `db/regression/`
dirs. Tracked in `docs/plans/consumer-app-audit-2026-07-25/factory-improvement-plan.md` (WS-4.1 +
WS-6.5 row).
