/**
 * db-migrate.test.mjs
 *
 * WS-4.1 + WS-6.5 (db-governance unification, 2026-07-26): unit tests for the checksum-journaled
 * ledger logic in db-migrate.mjs (sha256 / planRun / sortReleaseNames). These are pure functions —
 * no DB connection, no filesystem — so a real-Postgres integration test isn't needed to cover the
 * ledger/checksum/baseline decision logic itself; a real-Postgres round-trip (CREATE TABLE, actual
 * apply, actual drift against a live DB) is not covered here and should run in CI against the
 * pgvector/pgvector:pg17 service already wired in db-migrations.yml (replay step) — noted as a
 * follow-up, not blocking, since planRun/sha256 fully determine what that replay would do.
 *
 * Run with: node --test scripts/db-governance-templates/db-migrate.test.mjs
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { sha256, sortReleaseNames, planRun } from "./db-migrate.mjs";

describe("sha256", () => {
  it("is deterministic for identical content", () => {
    assert.equal(sha256("select 1;"), sha256("select 1;"));
  });

  it("differs when content changes by even one character", () => {
    assert.notEqual(sha256("select 1;"), sha256("select 2;"));
  });
});

describe("sortReleaseNames", () => {
  it("orders rNN- folders numerically, not lexically", () => {
    assert.deepEqual(
      sortReleaseNames(["r02-2026-07-11", "r10-2026-08-01", "r01-2026-07-08"]),
      ["r01-2026-07-08", "r02-2026-07-11", "r10-2026-08-01"],
    );
  });

  it("places rNN- folders before non-prefixed names, and falls back to locale order otherwise", () => {
    assert.deepEqual(sortReleaseNames(["zzz", "r01-x"]), ["r01-x", "zzz"]);
    assert.deepEqual(sortReleaseNames(["b", "a"]), ["a", "b"]);
  });
});

describe("planRun", () => {
  const files = [
    { label: "platform/0000_init", content: "create table if not exists a();" },
    { label: "__SOLUTION_SCHEMA__/0001_x", content: "create table if not exists b();" },
    { label: "__SOLUTION_SCHEMA__/0002_y", content: "create table if not exists c();" },
  ];

  it("marks every file 'apply' when the journal is empty", () => {
    const plan = planRun(files, new Map());
    assert.deepEqual(plan.map((p) => p.action), ["apply", "apply", "apply"]);
  });

  it("marks a file 'skip' when its recorded checksum matches on-disk content", () => {
    const journal = new Map([["platform/0000_init", sha256(files[0].content)]]);
    const plan = planRun(files, journal);
    assert.equal(plan.find((p) => p.label === "platform/0000_init").action, "skip");
    assert.equal(plan.find((p) => p.label === "__SOLUTION_SCHEMA__/0001_x").action, "apply");
  });

  it("marks a file 'drift' when its recorded checksum no longer matches on-disk content — GG-25 fix", () => {
    const journal = new Map([["platform/0000_init", "stale-checksum-from-before-the-file-changed"]]);
    const plan = planRun(files, journal);
    assert.equal(plan.find((p) => p.label === "platform/0000_init").action, "drift");
  });

  it("marks a PENDING file 'baseline' (not 'apply') when it matches the --baseline prefix", () => {
    const plan = planRun(files, new Map(), "platform/");
    assert.equal(plan.find((p) => p.label === "platform/0000_init").action, "baseline");
    assert.equal(plan.find((p) => p.label === "__SOLUTION_SCHEMA__/0001_x").action, "apply");
  });

  it("never baselines an already-applied file — recorded checksum still governs skip/drift", () => {
    const journal = new Map([["platform/0000_init", sha256(files[0].content)]]);
    const plan = planRun(files, journal, "platform/");
    assert.equal(plan.find((p) => p.label === "platform/0000_init").action, "skip");
  });
});
