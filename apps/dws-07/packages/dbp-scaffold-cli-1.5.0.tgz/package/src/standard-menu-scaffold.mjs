/**
 * standard-menu-scaffold — builds the DEFAULT full standard menu for a solution.
 *
 * Reads scripts/standard-menu.json (the curated menu = docs/01-Architecture/
 * Standard-Navigation-and-Layout-Map.md §2.3) and produces, for a manifest:
 *   - navSections:   the full 3-level sidebar (areas → groups → features)
 *   - demoEntities:  generic seeded entities backing the demo pages
 *   - modules:       one synthetic module + demo page per Feature, in its layout
 *
 * These are MERGED into the manifest by the generator: the standard menu is the
 * baseline every solution gets; the manifest's own modules OVERRIDE a standard
 * slot by route (real feature wins) and may add solution-specific groups. Builders
 * refine from there. See docs/plans/2026-06-18-standard-menu-demo-scaffold.md.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const MENU = JSON.parse(fs.readFileSync(path.join(__dirname, "standard-menu.json"), "utf8"));

// Doc layout name → generator emit id. standard-menu-layout-map.json now uses
// the canonical LAYOUT_IDS directly (Tier 2 rename, 2026-07-07); keys here match
// except lve/conversational, kept as distinct DOC-level markers (real semantic
// info) even though the generator normalises both to a shared implementation.
const LAYOUT_EMIT = {
  "overview-content": "overview-content",
  "object-page-detail": "object-page-detail",
  "analytics-dashboard": "analytics-dashboard",
  // CatalogueLayout gives the standard factory PageHeader (breadcrumb + title +
  // module subtitle) — kept for consistency with every other page. CatalogGrid's
  // own headline/lede are suppressed (omitted from featCatalogue) so there is a
  // SINGLE header. See ARCHETYPE-REFERENCE-SPEC §4.4.
  "collection-grid": "collection-grid",
  "config-form-custom": "config-form-custom",
  // LVE under the object-page-detail layout (standard PageHeader) + externalHeader
  // (above) so the list view follows the standard; the detail/3-panel opens within
  // the framed content area. "conversational" is not a layout — it is the copilot
  // feature (APP.F15) composed USING overview-grid (its insight cards are a grid
  // overview); the OverviewGridLayout hosts the feature with a standard PageHeader.
  lve: "object-page-detail",
  conversational: "overview-grid",
  // The workspace dashboard (APP.F21) renders under OverviewGridLayout — the
  // dedicated widget-grid archetype (Pick 3 GAP build, 2026-07-07) — which still
  // carries the same breadcrumb + PageHeader title as every other page; the
  // WorkspaceDashboard body remains header-less (single-header contract), its
  // action pills promoted into the PageHeader aside via WorkspaceDashboardActions.
  dashboard: "overview-grid",
  // Manage Work > Tasks (kanban/board archetype, 2026-07-11) — collection-board
  // is already a real, generator-implemented layout (CollectionBoardLayout);
  // identity mapping, no normalization needed.
  "collection-board": "collection-board",
};

// Archetype → the platform services its feature needs. A page is only synthesized
// when the solution consumes them (avoids feature.wires ⊄ consumes failures).
const ARCH_WIRES = {
  content: ["PS.DATA"],
  working: ["PS.DATA"],
  lve: ["PS.DATA"],
  analytics: ["PS.DATA"],
  catalogue: ["PS.DATA"],
  conversational: ["PS.AI"],
  dashboard: ["PS.DATA"],
  // APP.F04 Kanban wires PS.WORKFLOW (workflow-step columns), not PS.DATA — the
  // demo page is only synthesized for solutions that consume PS.WORKFLOW, same
  // gating pattern as `conversational`/PS.AI above.
  board: ["PS.WORKFLOW"],
  // APP.F06 approval queue (P1a) — real approve/reject over the demo workflow.
  "approval-queue": ["PS.WORKFLOW", "PS.RBAC"],
  // ANL.F05 SLA Tracking reads workflow instances via PS.WORKFLOW (GET
  // /instances/:id), same gating pattern as `board` above.
  sla: ["PS.WORKFLOW"],
};

const RECORD = "demo-record";
const CATALOG = "demo-catalog-item";
const REMINDER = "reminder";

// APP.F04 Kanban demo workflow — id referenced by featKanban() below AND by
// scaffold-solution.mjs, which registers this definition + its instances into
// PS.WORKFLOW storage (same chunk-local bootstrap seam solution/workflows/*.ts
// definitions use) whenever the standard menu synthesizes an APP.F04 page.
export const KANBAN_DEFINITION_ID = "standard-menu-tasks";
const KANBAN_DEFINITION_VERSION = "1.0.0";

// The demo actor's roles the kanban organism itself calls advance/reject with
// (see packages/stack/app-scaffolds/features/kanban/index.tsx's DEMO_SESSION/
// DEMO_ACTOR_ROLES) AND the two identities scaffold-solution.mjs actually
// seeds into PS.AUTH for every generated solution ("platform-admin"/"user" —
// see its DEV_USERS block). Every step here must include at least one of
// these or Advance/Reject 403 forever on the generated demo page (this was
// the root cause of the persistent permission banner Sharavi hit on
// /manage-work/tasks — the old ["member"] role matched neither identity).
const KANBAN_DEMO_ROLES = ["platform-admin", "user"];

/**
 * The demo WorkflowDefinition (steps mirror featKanban's board columns) + a
 * seeded WorkflowInstance per column, so the generated board has data instead
 * of the "No instance IDs configured" empty state. Registered by
 * scaffold-solution.mjs's PS.WORKFLOW bootstrap seam — memory-adapter storage
 * resets per chunk (route-chunk-bootstrap rule), so re-registering here on
 * every chunk cold-start is what keeps the board populated; it degrades to
 * the existing empty-state UI if that registration is ever skipped.
 *
 * Context carries the full BoardCard anatomy featKanban()'s cardFields maps —
 * assignee, a status label distinct from the column, a category (metaField),
 * a due date per instance (one clearly overdue), and exactly one locked
 * compliance-hold card with a reason — so the generated board matches the
 * accepted vendor-pipeline design ref out of the box (see
 * docs/03-features/specs/assets/design-refs/kanban-board-vendor-pipeline-ACCEPTED.jsx.txt).
 */
export function demoWorkflow() {
  const ts = "2026-06-01T08:00:00.000Z";
  const owners = ["Ahmed Al-Mansoori", "Fatima Al-Rashid", "Omar Al-Hashimi", "Sara Al-Zaabi"];
  const categories = ["Operations", "Finance", "IT & Security", "Support"];
  const priorities = ["low", "medium", "high"];
  const stepIds = ["open", "in-progress", "review", "done"];
  const statusLabels = {
    open: "New request",
    "in-progress": "In progress",
    review: "Awaiting review",
    done: "Completed",
  };
  // Index-aligned with the 8 instances below — step-entry timestamp for the
  // instance's CURRENT step (used by ANL.F05 SLA Tracking's stepEntryTs to
  // compute elapsed time). null for terminal ("done") instances, which skip
  // SLA verdict entirely (see sla-math.ts computeSlaRow). Combined with
  // featSla()'s slas targets and nowIso ("2026-06-01T10:00:00.000Z", 2h after
  // the base ts), these are hand-picked so the seeded set demonstrates all
  // three SlaStatus values across the running instances: 0/5 breached,
  // 1/6 warning, 2/4 ok.
  const stepEntryTimes = [
    "2026-06-01T08:00:00.000Z", // 0 open (target 60m): elapsed 120m → breached
    "2026-06-01T08:20:00.000Z", // 1 in-progress (target 120m): elapsed 100m → warning
    "2026-06-01T09:45:00.000Z", // 2 review (target 90m): elapsed 15m → ok
    null, // 3 done — terminal, no SLA verdict
    "2026-06-01T09:50:00.000Z", // 4 open (target 60m): elapsed 10m → ok
    "2026-06-01T08:00:00.000Z", // 5 in-progress (target 120m): elapsed 120m → breached
    "2026-06-01T08:45:00.000Z", // 6 review (target 90m): elapsed 75m → warning
    null, // 7 done — terminal, no SLA verdict
  ];
  // Index-aligned with the 8 instances below — index 0 is deliberately in the
  // past (overdue), "done" instances (index 3, 7) carry no due date.
  const dueDates = [
    "2026-06-20T00:00:00.000Z", // overdue
    "2026-07-25T00:00:00.000Z",
    "2026-08-01T00:00:00.000Z",
    null,
    "2026-08-10T00:00:00.000Z",
    "2026-07-22T00:00:00.000Z",
    "2026-08-05T00:00:00.000Z",
    null,
  ];

  const definition = {
    id: KANBAN_DEFINITION_ID,
    name: "Standard Menu Tasks",
    version: KANBAN_DEFINITION_VERSION,
    initialStep: "open",
    steps: [
      { id: "open", name: "Open", type: "task", assigneeRoles: KANBAN_DEMO_ROLES, next: "in-progress" },
      { id: "in-progress", name: "In Progress", type: "task", assigneeRoles: KANBAN_DEMO_ROLES, next: "review" },
      { id: "review", name: "Review", type: "approval", assigneeRoles: KANBAN_DEMO_ROLES, next: "done", onReject: "in-progress" },
      { id: "done", name: "Done", type: "end", assigneeRoles: KANBAN_DEMO_ROLES },
    ],
  };

  const instances = Array.from({ length: 8 }, (_, i) => {
    const n = i + 1;
    const stepId = stepIds[i % stepIds.length];
    const locked = n === 6; // exactly one locked compliance-hold card
    const category = categories[i % categories.length];
    const priority = priorities[i % priorities.length];
    // Card #tag chips (design-audit-2026-07-17 kanban item 4) — a category
    // tag on every card, plus "urgent" on high-priority ones.
    const tags = priority === "high" ? [category.toLowerCase(), "urgent"] : [category.toLowerCase()];
    const actor = { userId: "u-demo-user", roles: KANBAN_DEMO_ROLES, tenantId: "tenant-alpha" };
    // "open" entry ts: the hand-picked stepEntryTimes value when currentStep IS
    // "open" (so ANL.F05's stepEntryTs reads it directly), else the base ts.
    const openTs = stepId === "open" && stepEntryTimes[i] ? stepEntryTimes[i] : ts;
    const history = [{ stepId: "open", action: "start", actor, ts: openTs }];
    // Non-"open" running steps get their own "start" entry so ANL.F05 SLA
    // Tracking's stepEntryTs (which matches on stepId, not just history[0])
    // finds a real entry timestamp for the instance's current step.
    if (stepId !== "open" && stepId !== "done" && stepEntryTimes[i]) {
      history.push({ stepId, action: "start", actor, ts: stepEntryTimes[i] });
    }
    return {
      workflowId: `wf000000-00${n.toString().padStart(2, "0")}-4000-8000-0000000000${n.toString().padStart(2, "0")}`,
      definitionId: definition.id,
      definitionVersion: definition.version,
      tenantId: "tenant-alpha",
      status: stepId === "done" ? "completed" : "running",
      currentStep: stepId,
      steps: history,
      context: {
        // Self-referential recordId — these demo tasks have no backing PS.DATA
        // entity, so the workflow instance IS the "record" useRecordWorkflow()
        // binds to (its entityRecordId/context.recordId match, see
        // use-record-workflow.ts's useWorkflowData) — lets the task detail
        // drawer (manage-work/tasks/page.tsx) reuse RecordWorkflowStepper/
        // Actions/ProgressHistory + WorkflowStatusSummary unmodified.
        recordId: `wf000000-00${n.toString().padStart(2, "0")}-4000-8000-0000000000${n.toString().padStart(2, "0")}`,
        name: `Demo Task ${n.toString().padStart(2, "0")}`,
        owner: owners[i % owners.length],
        category,
        priority,
        status: statusLabels[stepId],
        dueDate: dueDates[i],
        tags,
        locked,
        ...(locked ? { lockReason: "Awaiting compliance sign-off before this task can continue." } : {}),
      },
      createdAt: ts,
      updatedAt: ts,
      revision: 1,
      assignedUserId: null,
      sortOrder: null,
    };
  });

  return { definition, instances };
}

// ── Entity-aware helpers (T2.3 — GAP-UI-1) ───────────────────────────────────

/** Capitalise hyphen/underscore-separated words (e.g. "in-progress" → "In Progress"). */
function toLabel(str) {
  return str.replace(/(^|[-_])([a-z])/g, (_, sep, c) => (sep ? " " : "") + c.toUpperCase());
}

/** Kebab-case → PascalCase, no spaces (e.g. "case-workspace" → "CaseWorkspace"). */
function toPascal(str) {
  return toLabel(str).replace(/\s+/g, "");
}

/**
 * Pluralize a label (e.g. "Capability" → "Capabilities", "Box" → "Boxes").
 * Minimal English rules — consonant+y → ies, s/x/z/ch/sh → es, else + s.
 */
export function pluralize(label) {
  if (/[^aeiou]y$/i.test(label)) return label.slice(0, -1) + "ies";
  if (/(s|x|z|ch|sh)$/i.test(label)) return label + "es";
  return label + "s";
}

/** Assign a badge tone to a lifecycle state name by pattern matching. */
function stateTone(state) {
  if (/done|closed|complet|approv|activ|success/.test(state)) return "success";
  if (/progress|pending|processing|in.review|fulfil/.test(state)) return "warning";
  if (/review|waiting|hold|return/.test(state)) return "gray";
  if (/cancel|reject|error|fail/.test(state)) return "danger";
  return "info";
}

/**
 * Build a LveWorkspace feature config from a real manifest entity.
 * Falls back to the demo-record config when entity is null/undefined.
 *
 * @param {object|null} entity  - Manifest entity declaration (may include .lifecycle)
 * @param {string}      role    - Feature role string
 * @param {string}      label   - Page label
 */
function buildEntityLveConfig(entity, role, label) {
  if (!entity) {
    // No real entity — use demo-record defaults (full config in featLve below).
    return null;
  }

  const entityType = entity.type;
  const entityLabel = toLabel(entityType);

  // Determine which field is the status/stage field.
  // Priority: field named "status", then first enum field whose values overlap with lifecycle states.
  const lc = entity.lifecycle;
  const lcStates = lc?.states ?? [];
  const stageField =
    entity.fields?.find((f) => f.name === "status")?.name ??
    entity.fields?.find((f) => f.type === "enum" && f.enum?.some((v) => lcStates.includes(v)))?.name ??
    "status";

  // Column set from entity fields (cap at 6 for readability).
  const statusField = entity.fields?.find((f) => f.name === stageField);
  const tones = Object.fromEntries(lcStates.map((s) => [s, stateTone(s)]));
  const columns = (entity.fields ?? []).slice(0, 6).map((f) => {
    const isStatus = f.name === stageField;
    const isDate = f.name === "updatedAt" || f.name === "updated" || f.name === "createdAt" || f.name === "date";
    return {
      field: f.name,
      label: toLabel(f.name),
      sortable: true,
      ...(isStatus && lcStates.length > 0 ? { format: "badge", badgeTones: tones } : {}),
      ...(isDate ? { format: "date" } : {}),
    };
  });
  if (columns.length === 0) columns.push({ field: "name", label: "Name", sortable: true });

  // List tabs from lifecycle states (+ "All" sentinel).
  const listTabs = lc
    ? [
        { key: "all", label: "All", where: [] },
        ...lcStates.map((s) => ({ key: s, label: toLabel(s), where: [{ field: stageField, op: "is", value: s }] })),
      ]
    : [{ key: "all", label: "All", where: [] }];

  // Stages bar from lifecycle states.
  const stages = lcStates.map((s) => ({ id: s, label: toLabel(s), tone: stateTone(s) }));

  // Quick actions from lifecycle transitions.
  const ACTION_ICONS = { approve: "Check", reject: "X", close: "XCircle", submit: "Send", assign: "UserPlus", start: "Play", complete: "CheckCircle", review: "Eye" };
  const quickActions = (lc?.transitions ?? []).map((t) => {
    const actionKey = (t.action ?? t.to).toLowerCase();
    const icon = Object.entries(ACTION_ICONS).find(([k]) => actionKey.includes(k))?.[1] ?? "ArrowRight";
    return {
      action: t.action ?? `to-${t.to}`,
      label: t.action ? toLabel(t.action) : `Move to ${toLabel(t.to)}`,
      icon,
      when: [{ field: stageField, op: "is", value: t.from }],
      patch: { [stageField]: t.to },
    };
  });

  // Status enum options for editable columns.
  const statusOpts = lcStates.map((s) => ({ value: s, label: toLabel(s) }));
  if (statusField && lcStates.length > 0) {
    const col = columns.find((c) => c.field === stageField);
    if (col) Object.assign(col, { editable: true, editType: "select", editOptions: statusOpts });
  }

  return {
    entityType,
    entityLabel,
    title: label,
    externalHeader: true,
    columns,
    pageSize: 25,
    enableSearch: true,
    enableSort: true,
    sortFields: columns.map((c) => c.field).slice(0, 4),
    showTabCounts: true,
    listTabs,
    detailMode: "list",
    enableViewToggle: true,
    enableRecordPager: true,
    showSaveStatus: true,
    ...(stages.length > 0 ? {
      stageVariant: "numbered",
      stageField,
      stages,
    } : {}),
    ...(quickActions.length > 0 ? { quickActions } : {}),
    header: { titleField: columns[0]?.field ?? "name", statusField: stageField },
    detailTabs: [
      {
        id: "details",
        label: "Details",
        sections: [
          {
            title: "Overview",
            fields: columns.slice(0, 4).map((c) => ({
              field: c.field,
              label: c.label,
              ...(c.format === "badge" ? { format: "badge" } : {}),
              editable: true,
              editType: c.editType ?? "text",
              ...(c.editOptions ? { editOptions: c.editOptions } : {}),
            })),
          },
        ],
      },
    ],
    detailRail: [
      {
        title: "Details",
        kind: "fields",
        fields: columns.slice(4).map((c) => ({ field: c.field, label: c.label, ...(c.format ? { format: c.format } : {}) })),
      },
    ].filter((r) => r.fields.length > 0),
    enableBulkActions: true,
    bulkActions: stages.length > 0
      ? [{ action: `bulk-${lcStates.at(-1)}`, label: `Mark ${toLabel(lcStates.at(-1) ?? "done")}`, patch: { [stageField]: lcStates.at(-1) } }]
      : [],
  };
}

/** The two generic demo entities (registered + seeded so every demo page has data). */
export function demoEntities() {
  const ts = "2026-06-01T08:00:00.000Z";
  const mk = (id, data) => ({ id, type: RECORD, tenantId: "tenant-alpha", createdAt: ts, updatedAt: ts, data });
  const owners = ["Ahmed Al-Mansoori", "Fatima Al-Rashid", "Omar Al-Hashimi", "Sara Al-Zaabi", "Khalid Al-Nuaimi", "Hessa Al-Maktoum"];
  const statuses = ["open", "in-progress", "review", "done"];
  const priorities = ["low", "medium", "high"];
  const categories = ["Operations", "Finance", "Customer", "Compliance", "Technology"];
  const recordSeed = Array.from({ length: 14 }, (_, i) => {
    const n = i + 1;
    return mk(`dr000000-00${n.toString().padStart(2, "0")}-4000-8000-0000000000${n.toString().padStart(2, "0")}`, {
      name: `Demo Record ${n.toString().padStart(2, "0")}`,
      status: statuses[i % statuses.length],
      owner: owners[i % owners.length],
      priority: priorities[i % priorities.length],
      category: categories[i % categories.length],
      updated: `2026-06-${(10 + (i % 18)).toString().padStart(2, "0")}`,
    });
  });
  const catTs = "2026-06-01T08:00:00.000Z";
  const catSeed = Array.from({ length: 12 }, (_, i) => {
    const n = i + 1;
    const cats = ["platform", "integration", "security", "data", "service"];
    return {
      // "cd" = catalog-demo. Namespaced away from the plain `c0000000-` block because
      // that is the obvious prefix for any manifest-authored entity starting with "c"
      // (capability, ea-standard, …), and a collision here is fatal: the seed
      // row-existence gate hard-fails the whole generation when two entity types
      // share a fixture id. Generator-owned demo fixtures keep their own namespace.
      id: `cd000000-00${n.toString().padStart(2, "0")}-4000-8000-0000000000${n.toString().padStart(2, "0")}`,
      type: CATALOG, tenantId: "tenant-alpha", createdAt: catTs, updatedAt: catTs,
      data: {
        name: `Demo Offering ${n.toString().padStart(2, "0")}`,
        summary: "A sample marketplace offering generated for the standard-menu demo.",
        category: cats[i % cats.length],
        status: i % 3 === 0 ? "coming-soon" : "available",
        code: `OFF-${n.toString().padStart(3, "0")}`,
      },
    };
  });
  return [
    {
      type: RECORD,
      fields: [
        { name: "name", type: "string", required: true },
        { name: "status", type: "enum", enum: statuses, required: true },
        { name: "owner", type: "string", required: false },
        { name: "priority", type: "enum", enum: priorities, required: false },
        { name: "category", type: "string", required: false },
        { name: "updated", type: "string", required: false },
      ],
      seed: recordSeed,
    },
    {
      type: CATALOG,
      fields: [
        { name: "name", type: "string", required: true },
        { name: "summary", type: "string", required: false },
        { name: "category", type: "string", required: false },
        { name: "status", type: "enum", enum: ["available", "coming-soon"], required: true },
        { name: "code", type: "string", required: false },
      ],
      seed: catSeed,
    },
  ];
}

// ── Feature-instance templates (minimal-valid, modelled on SDO.01) ────────────

// Status/priority tones mirroring featLve for visual consistency across all list pages.
const STATUS_BADGE_TONES = {
  open: "info",
  "in-progress": "warning",
  review: "gray",
  done: "success",
};
const PRIORITY_BADGE_TONES = {
  low: "gray",
  medium: "info",
  high: "warning",
};

/**
 * Derive EntityList column definitions from a manifest entity's fields.
 * Falls back to the hardcoded demo-record defaults when entity has no fields.
 */
function buildEntityListColumns(entity) {
  const fields = entity?.fields;
  if (!fields || fields.length === 0) {
    return {
      columns: [
        { field: "name", label: "Name", sortable: true },
        { field: "status", label: "Status", sortable: true, format: "badge", badgeTones: STATUS_BADGE_TONES },
        { field: "owner", label: "Owner", sortable: true },
        { field: "priority", label: "Priority", sortable: true, format: "badge", badgeTones: PRIORITY_BADGE_TONES },
        { field: "category", label: "Category", sortable: true },
        { field: "updated", label: "Updated", sortable: true, format: "date" },
      ],
      listTabs: [
        { key: "all", label: "All", where: [] },
        { key: "open", label: "Open", where: [{ field: "status", op: "is", value: "open" }] },
        { key: "in-progress", label: "In Progress", where: [{ field: "status", op: "is", value: "in-progress" }] },
        { key: "review", label: "Review", where: [{ field: "status", op: "is", value: "review" }] },
        { key: "done", label: "Done", where: [{ field: "status", op: "is", value: "done" }] },
      ],
    };
  }

  // Identify the status field (for badge formatting and list tabs).
  const lc = entity.lifecycle;
  const lcStates = lc?.states ?? [];
  const stageField =
    fields.find((f) => f.name === "status")?.name ??
    fields.find((f) => f.type === "enum" && f.enum?.some((v) => lcStates.includes(v)))?.name ??
    fields.find((f) => f.type === "enum")?.name ??
    null;

  const tones = Object.fromEntries(lcStates.map((s) => [s, stateTone(s)]));

  // DEFECT 4 (naive-UX-audit): the detail drawer used to be entirely read-only
  // regardless of the entity's declared field types. Derive editable/editType/
  // editOptions the same way the LVE synthesis does (scaffold-solution.mjs), for
  // ANY entity — not just ones with a lifecycle block — unless explicitly opted
  // out via `readOnly: true` in the manifest entity declaration.
  const editableAllowed = entity.readOnly !== true;
  const columns = fields.slice(0, 6).map((f) => {
    const isStatus = stageField && f.name === stageField;
    const isDate = /^(updatedAt|createdAt|updated|created|date)$/.test(f.name);
    const edit = !editableAllowed
      ? {}
      : isStatus && f.type === "enum" && f.enum
        ? { editable: true, editType: "select", editOptions: f.enum.map((v) => ({ value: v, label: toLabel(v) })) }
        : f.type === "enum" && f.enum
          ? { editable: true, editType: "select", editOptions: f.enum.map((v) => ({ value: v, label: toLabel(v) })) }
          : f.type === "number"
            ? { editable: true, editType: "number" }
            : f.type === "string"
              ? { editable: true, editType: "text" }
              : {};
    return {
      field: f.name,
      label: toLabel(f.name),
      sortable: true,
      ...(isStatus && lcStates.length > 0 ? { format: "badge", badgeTones: tones } : {}),
      ...(isDate ? { format: "date" } : {}),
      ...edit,
    };
  });
  if (columns.length === 0) columns.push({ field: "id", label: "ID", sortable: true });

  // List tabs from lifecycle states when available, else a bare "All" tab.
  const statusEnumValues = stageField
    ? (fields.find((f) => f.name === stageField)?.enum ?? lcStates)
    : [];
  const listTabs =
    statusEnumValues.length > 0
      ? [
          { key: "all", label: "All", where: [] },
          ...statusEnumValues.map((s) => ({
            key: s,
            label: toLabel(s),
            where: [{ field: stageField, op: "is", value: s }],
          })),
        ]
      : [{ key: "all", label: "All", where: [] }];

  return { columns, listTabs };
}

function featRecordList(role, entity) {
  const { columns, listTabs } = buildEntityListColumns(entity);
  return {
    id: "APP.F01", role, slot: "main", wires: ["PS.DATA"],
    config: {
      entityType: entity?.type ?? RECORD,
      columns,
      pageSize: 15,
      enableSearch: true,
      listTabs,
      // W6: row click opens Sheet drawer instead of dispatching CustomEvent.
      // N37: synthesize the full overlay-system-reference drawer anatomy when
      // the entity's fields are known (else the organism's `true` default).
      detailDrawer: buildDetailDrawerConfig(entity),
    },
  };
}

/**
 * N37 — full RecordDrawerConfig synthesis (overlay-system reference parity):
 * eyebrow entity label + code, status chip, status-dot renderer for the enum
 * status field, description paragraph from a real summary/description field,
 * kebab headerMenu + footer quickActions from real enum states (wired-only
 * patches). No invented data: person/date renderers are emitted only when a
 * matching real field exists, and no SLA renderer is synthesized (no
 * target-date field convention exists in manifest entities).
 */
function buildDetailDrawerConfig(entity) {
  const fields = entity?.fields;
  if (!fields || fields.length === 0) return true;
  const stringField = (n) => fields.find((f) => f.name === n && f.type === "string");
  const titleField = stringField("name")?.name ?? fields.find((f) => f.type === "string")?.name ?? "id";
  const codeField = stringField("code")?.name;
  const statusF = fields.find((f) => f.name === "status" && f.type === "enum") ?? fields.find((f) => f.type === "enum");
  const states = statusF?.enum ?? [];
  const tones = Object.fromEntries(states.map((s) => [s, stateTone(s)]));
  const descriptionField = stringField("summary")?.name ?? stringField("description")?.name;
  const ownerField = fields.find((f) => /^(owner|assignee)$/.test(f.name) && f.type === "string")?.name;
  const sectionFields = fields.slice(0, 8).map((f) => ({
    id: f.name,
    label: toLabel(f.name),
    format: f.type === "enum" && f.name !== statusF?.name ? "badge" : "text",
    ...(statusF && f.name === statusF.name ? { render: "status-dot", badgeTones: tones } : {}),
    ...(ownerField && f.name === ownerField ? { render: "person" } : {}),
    ...(/^(updatedAt|createdAt|updated|created|date|dueDate)$/.test(f.name) ? { render: "date" } : {}),
    editable: false,
  }));
  const [primaryState, ...restStates] = states;
  return {
    titleField,
    subtitleFields: codeField ? [codeField] : [],
    entityLabel: toLabel(entity.type),
    ...(statusF ? { statusField: statusF.name, statusTones: tones } : {}),
    ...(codeField ? { codeField } : {}),
    ...(descriptionField ? { descriptionField } : {}),
    ...(primaryState && statusF
      ? {
          quickActions: [
            { id: `mark-${primaryState}`, label: `Mark ${toLabel(primaryState).toLowerCase()}`, patch: { [statusF.name]: primaryState } },
          ],
        }
      : {}),
    ...(restStates.length > 0 && statusF
      ? {
          headerMenu: restStates.map((s) => ({
            id: `mark-${s}`,
            label: `Mark ${toLabel(s).toLowerCase()}`,
            patch: { [statusF.name]: s },
          })),
        }
      : {}),
    variants: {},
    labels: {},
    defaultSections: [{ id: "overview", title: "Overview", fields: sectionFields }],
    tabs: [
      { id: "overview", label: "Overview", kind: "fields" },
      { id: "comments", label: "Comments", kind: "comments" },
      { id: "audit", label: "Audit", kind: "audit" },
    ],
    comments: { entityType: entity.type },
    deepLink: true,
    expandable: true,
  };
}

function featAnalytics(roleBase, entity) {
  const entityType = entity?.type ?? RECORD;
  const lc = entity?.lifecycle;
  const states = lc?.states ?? ["open", "in-progress", "review", "done"];
  const stageField =
    entity?.fields?.find((f) => f.name === "status")?.name ??
    entity?.fields?.find((f) => f.type === "enum")?.name ??
    "status";
  const categoryFieldName = entity?.fields?.find((f) => f.name === "category" || f.name === "type")?.name ?? "category";
  const icons = ["Activity", "Hash", "Target", "TrendingUp"];
  // DR-7 fidelity fix: the operational/executive scorecard KPIs (Open/In Progress/
  // Review/Done) always read the demo-record entity, which is what actually
  // carries that open/in-progress/review/done lifecycle (see solution/entities/
  // demo-record.ts). The chart entityType stays on the manifest's primary real
  // entity — only the scorecard's work-item counters are pinned to demo-record.
  const isWorkItemDashboard = roleBase.includes("-operational-dashboards") || roleBase.includes("-executive-dashboards");
  const scorecardEntityType = isWorkItemDashboard ? RECORD : entityType;
  const scorecardStates = isWorkItemDashboard ? ["open", "in-progress", "review", "done"] : states;
  const scorecardStageField = isWorkItemDashboard ? "status" : stageField;
  return [
    {
      id: "ANL.F03", role: `${roleBase}-scorecard`, slot: "main", wires: ["PS.DATA"],
      config: {
        layout: "grid",
        kpis: scorecardStates.slice(0, 4).map((s, i) => ({
          id: `${roleBase}-${s}`,
          label: toLabel(s),
          entityType: scorecardEntityType,
          metric: { aggregate: "count" },
          filters: { [scorecardStageField]: s },
          format: "number",
          icon: icons[i % icons.length],
        })),
      },
    },
    {
      id: "ANL.F02", role: `${roleBase}-chart`, slot: "main", wires: ["PS.DATA"],
      config: {
        title: `${toLabel(entityType)} by ${toLabel(categoryFieldName)}`,
        entityType,
        chartType: "bar",
        categoryField: categoryFieldName,
        series: [{ valueField: "id", label: pluralize(toLabel(entityType)), aggregate: "count" }],
        height: 300,
      },
    },
    // DR-7 fidelity: the operational and executive dashboards are the same
    // "analytics" archetype but must genuinely differ per audience (operational
    // leads track the day-to-day pipeline; executives read portfolio health).
    // Every other "analytics" module (ad-hoc/trend/root-cause/... ) stays at
    // the KPI+bar baseline above — this extra widget is scoped to just these two.
    ...(roleBase.includes("-operational-dashboards")
      ? [
          {
            id: "ANL.F02", role: `${roleBase}-funnel`, slot: "main", wires: ["PS.DATA"],
            config: {
              title: `${toLabel(entityType)} Pipeline`,
              entityType,
              chartType: "funnel",
              categoryField: stageField,
              series: [{ valueField: "id", label: pluralize(toLabel(entityType)), aggregate: "count" }],
              height: 220,
            },
          },
          {
            id: "ANL.F02", role: `${roleBase}-ranking`, slot: "main", wires: ["PS.DATA"],
            config: {
              title: `${toLabel(categoryFieldName)} Ranking`,
              entityType,
              chartType: "ranking",
              categoryField: categoryFieldName,
              series: [{ valueField: "id", label: pluralize(toLabel(entityType)), aggregate: "count" }],
              height: 220,
            },
          },
        ]
      : []),
    ...(roleBase.includes("-executive-dashboards")
      ? [
          {
            id: "ANL.F02", role: `${roleBase}-heatmap`, slot: "main", wires: ["PS.DATA"],
            config: {
              title: `${toLabel(entityType)} ${toLabel(categoryFieldName)} × ${toLabel(stageField)}`,
              entityType,
              chartType: "heatmap",
              categoryField: stageField,
              rowField: categoryFieldName,
              series: [{ valueField: "id", label: pluralize(toLabel(entityType)), aggregate: "count" }],
              height: 260,
            },
          },
          {
            id: "ANL.F02", role: `${roleBase}-summary`, slot: "main", wires: ["PS.DATA"],
            config: {
              title: `${toLabel(entityType)} Portfolio`,
              entityType,
              chartType: "summary",
              categoryField: stageField,
              series: [{ valueField: "id", label: pluralize(toLabel(entityType)), aggregate: "count" }],
              height: 160,
            },
          },
        ]
      : []),
  ];
}

function featCatalogue(role) {
  return {
    id: "APP.F10", role, slot: "main", wires: ["PS.DATA"],
    config: {
      entityType: CATALOG,
      // No headline/lede: CatalogueLayout already renders the factory PageHeader, so
      // CatalogGrid renders header-less (search + tabs + grid only) — single header.
      // Sub-marketplaces rendered as a tab strip above the grid. No "All" tab —
      // the first declared category is the default landing tab (ruling: "all is
      // never a sub marketplace").
      categories: [
        { id: "platform", label: "Platform" },
        { id: "integration", label: "Integration" },
        { id: "security", label: "Security" },
        { id: "data", label: "Data & Analytics" },
        { id: "service", label: "Services" },
      ],
      categoryField: "category",
      cardFields: { title: "name", description: "summary", typeLabel: "category", status: "status", statusTone: "success", footerId: "code" },
      filterFields: [{ field: "status", label: "Status" }],
    },
  };
}

function featCopilot(role, entity) {
  const entityType = entity?.type ?? RECORD;
  const entityLabel = entity ? toLabel(entityType) : "Record";
  return {
    id: "APP.F15", role, slot: "main", wires: ["PS.AI"],
    config: {
      eyebrow: "AI Assistant · standard-menu demo",
      title: "AI Assistant",
      description: "Ask questions about your data — a standard-menu demo conversational surface.",
      insightCards: [
        { id: "open", title: `Open ${pluralize(entityLabel)}`, valueMetric: { entityType, aggregate: "count" }, icon: "Hash" },
        { id: "high", title: `High Priority`, valueMetric: { entityType, aggregate: "count" }, icon: "Activity" },
      ],
      composerPlaceholder: "Ask a question…",
      submitLabel: "Send",
      suggestedPrompts: [`Summarise open ${pluralize(entityLabel).toLowerCase()}`, `Which category has the most ${pluralize(entityLabel).toLowerCase()}?`, "Show high-priority items"],
      entityType,
    },
  };
}

function featContent(role, entity) {
  const entityType = entity?.type ?? RECORD;
  const entityLabel = entity ? toLabel(entityType) : "Record";
  return {
    id: "APP.F07", role, slot: "main", wires: ["PS.DATA"],
    config: {
      title: "Getting Started",
      subtitle: "A sample orientation page generated for the standard-menu demo.",
      myItems: [{
        id: "my-records", title: `My ${pluralize(entityLabel)}`, entityType,
        columns: [
          { field: "name", label: "Name" },
          { field: "status", label: "Status" },
          { field: "priority", label: "Priority" },
        ],
        limit: 5, emptyText: "No records yet.",
      }],
      quickActions: [
        { id: "go-tasks", label: "Tasks", href: "/manage-work/tasks", icon: "CheckSquare", tone: "navy" },
        { id: "go-dashboards", label: "Dashboards", href: "/dashboards/operational", icon: "BarChart3", tone: "navy" },
      ],
    },
  };
}

// Real List-View-Edit (APP.F19) over the demo-record entity — the 3-panel workspace
// (list rail + tabbed detail + slide-in edit), with status stages + quick actions.
// When a real manifest entity is passed, buildEntityLveConfig() produces an entity-aware
// config; otherwise the demo-record defaults below are used (backward-compat).
const STATUS_OPTS = [
  { value: "open", label: "Open" },
  { value: "in-progress", label: "In Progress" },
  { value: "review", label: "Review" },
  { value: "done", label: "Done" },
];
function featLve(role, label, entity) {
  const entityConfig = buildEntityLveConfig(entity, role, label);
  return {
    id: "APP.F19", role, slot: "main", wires: ["PS.DATA"],
    config: entityConfig ?? {
      entityType: RECORD,
      entityLabel: "Record",
      title: label,
      // Host layout (working) renders the factory PageHeader; suppress the LVE's
      // own list header so there's ONE standard header (single-header rule).
      externalHeader: true,
      columns: [
        { field: "name", label: "Name", sortable: true },
        { field: "status", label: "Status", sortable: true, format: "badge",
          badgeTones: { open: "info", "in-progress": "warning", review: "gray", done: "success" },
          editable: true, editType: "select", editOptions: STATUS_OPTS },
        { field: "priority", label: "Priority", sortable: true, format: "badge",
          badgeTones: { low: "gray", medium: "info", high: "warning" } },
        { field: "owner", label: "Owner", sortable: true },
        { field: "category", label: "Category", sortable: true },
        { field: "updated", label: "Updated", sortable: true, format: "date" },
      ],
      pageSize: 25,
      enableSearch: true,
      enableSort: true,
      sortFields: ["updated", "name", "status", "priority"],
      showTabCounts: true,
      listTabs: [
        { key: "all", label: "All", where: [] },
        { key: "open", label: "Open", where: [{ field: "status", op: "is", value: "open" }] },
        { key: "in-progress", label: "In Progress", where: [{ field: "status", op: "is", value: "in-progress" }] },
        { key: "review", label: "Review", where: [{ field: "status", op: "is", value: "review" }] },
        { key: "done", label: "Done", where: [{ field: "status", op: "is", value: "done" }] },
      ],
      detailMode: "list",
      enableViewToggle: true,
      enableRecordPager: true,
      showSaveStatus: true,
      stageVariant: "numbered",
      stageField: "status",
      stages: [
        { id: "open", label: "Open", tone: "info" },
        { id: "in-progress", label: "In Progress", tone: "warning" },
        { id: "review", label: "Review", tone: "gray" },
        { id: "done", label: "Done", tone: "success" },
      ],
      quickActions: [
        { action: "start", label: "Start", icon: "Play", when: [{ field: "status", op: "is", value: "open" }], patch: { status: "in-progress" } },
        { action: "to-review", label: "Send to Review", icon: "ArrowUp", when: [{ field: "status", op: "is", value: "in-progress" }], patch: { status: "review" } },
        { action: "complete", label: "Mark Done", icon: "Check", when: [{ field: "status", op: "is", value: "review" }], patch: { status: "done" } },
      ],
      header: { titleField: "name", subtitleField: "owner", statusField: "status" },
      detailTabs: [
        { id: "details", label: "Details", sections: [
          { title: "Overview", fields: [
            { field: "name", label: "Name", editable: true, editType: "text" },
            { field: "status", label: "Status", format: "badge", editable: true, editType: "select", editOptions: STATUS_OPTS },
            { field: "priority", label: "Priority", format: "badge", editable: true, editType: "select",
              editOptions: [{ value: "low", label: "Low" }, { value: "medium", label: "Medium" }, { value: "high", label: "High" }] },
            { field: "category", label: "Category", editable: true, editType: "text" },
          ] },
        ] },
      ],
      detailRail: [
        { title: "Assignment", kind: "linked", fields: [{ field: "owner", label: "Owner" }] },
        { title: "Details", kind: "fields", fields: [{ field: "updated", label: "Updated", format: "date" }] },
      ],
      enableBulkActions: true,
      bulkActions: [{ action: "bulk-done", label: "Mark Done", patch: { status: "done" } }],
    },
  };
}

// APP.F04 — Kanban / Pipeline Board (Manage Work > Tasks, 2026-07-11). Wires
// PS.WORKFLOW, not PS.DATA. instanceIds is seeded from demoWorkflow() (above) —
// scaffold-solution.mjs registers that same definition + instance set into
// PS.WORKFLOW storage via the chunk-local bootstrap seam (see its PS.WORKFLOW
// route generation), so the board mounts for real (CollectionBoardLayout + the
// real APP.F04 Kanban component) with a populated board instead of the
// "No instance IDs configured" empty state (features/kanban/FEATURE.md §States).
/**
 * APP.F06 approval queue (P1a, design-audit remediation) — the real approval
 * surface over the same demo workflow the kanban board renders. approvalStepIds
 * is derived here from the definition's approval-type steps so the client
 * needs no definition fetch.
 */
function featApprovalQueue(role) {
  const { definition } = demoWorkflow();
  const approvalStepIds = definition.steps.filter((s) => s.type === "approval").map((s) => s.id);
  return {
    id: "APP.F06", role, slot: "main", wires: ["PS.WORKFLOW", "PS.RBAC"],
    config: {
      definitionId: definition.id,
      approvalStepIds,
      approveAction: "task.approve",
      requireComment: "on-reject",
      showHistory: true,
    },
  };
}

function featKanban(role) {
  const { definition, instances } = demoWorkflow();
  return {
    id: "APP.F04", role, slot: "main", wires: ["PS.WORKFLOW"],
    config: {
      definitionId: definition.id,
      instanceIds: instances.map((i) => i.workflowId),
      columns: [
        { stepId: "open", label: "Open", tone: "neutral" },
        { stepId: "in-progress", label: "In Progress", tone: "warning", wipLimit: 3 },
        { stepId: "review", label: "Review", tone: "info" },
        { stepId: "done", label: "Done", tone: "success" },
      ],
      // Full BoardCard anatomy — assignee avatar, category meta line, risk
      // chip, status chip, due date (+ overdue styling), and the locked
      // compliance-hold state — matches demoWorkflow()'s seeded context above.
      // DR-7 reference fidelity: the card has NO on-card Advance/Reject
      // buttons — allowAdvance/allowReject below stay valid config (schema
      // unchanged) but no longer gate any button UI; advancing is via drag,
      // ←→ keyboard, or the kebab "Move to…" menu (all still PS.WORKFLOW-
      // legal-target-constrained). See kanban/components/kanban-card.tsx.
      cardFields: {
        titleField: "name",
        metaField: "category",
        riskField: "priority",
        statusField: "status",
        assigneeField: "owner",
        dueDateField: "dueDate",
        lockField: "locked",
        lockReasonField: "lockReason",
        tagsField: "tags",
      },
      allowAdvance: true,
      allowReject: true,
      // "My items" (item 8) is session-aware — it needs a currentUserId prop,
      // not manifest config — see featKanban()'s caller / the tasks page
      // component, which wires currentUserId alongside this config.
      filterChips: [
        { id: "high-priority", label: "High priority", kind: "equals", field: "priority", value: "high" },
        { id: "overdue", label: "Overdue", kind: "overdue" },
        { id: "my-items", label: "My items", kind: "me", field: "owner" },
      ],
      labels: {
        searchPlaceholder: "Search tasks…",
        itemNoun: "tasks",
        emptyColumn: "No tasks here yet",
        emptyColumnFiltered: "No matching tasks",
        emptyBoardTitle: "All caught up",
        emptyBoardBody: "No tasks in the board right now.",
      },
      // Table/Board view toggle (item 9) — a flat table alternative over the
      // same instance data, no PS.DATA entity-list pairing needed.
      showViewToggle: true,
    },
  };
}

// ANL.F05 — SLA Tracking (Monitor Work > SLA Tracking, 2026-07-17). Wires
// PS.WORKFLOW, not PS.DATA — reuses the same demoWorkflow() definition +
// instances as featKanban() (APP.F04) so a solution consuming both gets a
// single registered demo workflow; scaffold-solution.mjs's PS.WORKFLOW
// bootstrap seam registers it whenever either page is synthesized. slas'
// targetMinutes + nowIso are matched to demoWorkflow()'s stepEntryTimes so
// the seeded instances demonstrate all three SlaStatus values (ok/warning/
// breached) without any Date.now() in generated output.
function featSla(role) {
  const { definition, instances } = demoWorkflow();
  return {
    id: "ANL.F05", role, slot: "main", wires: ["PS.WORKFLOW"],
    config: {
      title: "SLA Tracking",
      // Detected by scaffold-solution.mjs the same way featKanban()'s
      // config.definitionId is — stripped by SlaTrackingConfig's zod schema
      // (unknown keys are dropped), harmless at runtime.
      definitionId: definition.id,
      instanceIds: instances.map((i) => i.workflowId),
      slas: [
        { stepId: "open", label: "Open", targetMinutes: 60 },
        { stepId: "in-progress", label: "In Progress", targetMinutes: 120 },
        { stepId: "review", label: "Review", targetMinutes: 90 },
      ],
      warnAtPercent: 75,
      cardFields: { titleField: "name", subtitleField: "owner" },
      nowIso: "2026-06-01T10:00:00.000Z",
    },
  };
}

// APP.F21 — composed personal "My Dashboard" (greeting + grouped tasks + projects
// + calendar + goals + reminders). My Tasks ALWAYS reads the demo-record entity
// (RECORD), never the caller's `entity` — taskGroups/taskFields below are hardcoded
// to demo-record's status vocabulary (open/in-progress/review) and field names
// (name/priority/updated/status). A bespoke solution entity (e.g. "capability", whose
// status enum is active/draft) does not share that vocabulary, so every group's
// filter matches zero rows and the panel silently renders empty despite loaded data.
// See naive-UX-audit DEFECT 2.
// Only "Ask AI" and "Connect apps" have no real backend yet (no model wired, no
// integrations plane) — they render as honest disabled/"coming soon" pills (see
// greeting-header.tsx) instead of silently no-opping.
function featWorkspaceDashboard(role, _entity) {
  return {
    id: "APP.F21", role, slot: "main", wires: ["PS.DATA"],
    config: {
      // N34 (Sharavi 2026-07-17): no disabled placeholder actions in the toolbar —
      // emit only actions that actually work. Ask AI routes to the live /copilot
      // page (PS.AI streaming); the reference's other quick-actions return when
      // their capabilities exist.
      actions: [
        { label: "Ask AI", primary: true, href: "/copilot" },
      ],
      tasksEntityType: RECORD,
      taskGroups: [
        { key: "in-progress", label: "In Progress", statuses: ["in-progress"] },
        { key: "to-do", label: "To Do", statuses: ["open"] },
        { key: "upcoming", label: "Upcoming", statuses: ["review"] },
      ],
      taskFields: { name: "name", priority: "priority", dueDate: "updated", status: "status" },
      goals: [
        { label: "Check emails and messages", context: "Product launch · My Projects", value: 73 },
        { label: "Prepare a brief status update to the client", context: "Product launch · My Projects", value: 11 },
        { label: "Update project documentation", context: "Team brainstorm · My Projects", value: 63 },
      ],
      projects: [
        { name: "Product launch", tasks: 6, teammates: 12, icon: "P", tone: "primary" },
        { name: "Team brainstorm", tasks: 2, teammates: 32, icon: "T", tone: "info" },
        { name: "Branding launch", tasks: 4, teammates: 9, icon: "B", tone: "success" },
      ],
      calendar: {
        month: "July",
        days: [
          { dow: "Fri", day: 4 }, { dow: "Sat", day: 5 }, { dow: "Sun", day: 6 },
          { dow: "Mon", day: 7, active: true }, { dow: "Tue", day: 8 }, { dow: "Wed", day: 9 }, { dow: "Thu", day: 10 },
        ],
        events: [
          { title: "Meeting with VP", time: "Today · 10:00 – 11:00 am", provider: "Google Meet", attendees: 5 },
        ],
      },
      remindersEntityType: REMINDER,
    },
  };
}

/**
 * Prefer the marketplace request entity for the requester + ops request queues.
 * Other standard-menu pages keep the solution primary entity (lifecycle-first).
 * See docs/plans/marketplace-spine-2026-07-30-plan.md Phase A.
 */
const MARKETPLACE_REQUEST_ROUTES = new Set([
  "/transactions/requests",
  "/manage-services/requests",
]);

function entityForStandardMenuFeature(feature, realEntities, primaryEntity) {
  if (MARKETPLACE_REQUEST_ROUTES.has(feature.route)) {
    const requestEntity = realEntities.find((e) => e.type === "service-offering-request");
    if (requestEntity) return requestEntity;
  }
  return primaryEntity;
}

function featuresFor(archetype, role, label, entity) {
  switch (archetype) {
    case "working": return [featRecordList(role, entity)];
    case "lve": return [featLve(role, label, entity)];
    case "settings": return [featRecordList(role, entity)];
    case "analytics": return featAnalytics(role, entity);
    case "catalogue": return [featCatalogue(role)];
    case "conversational": return [featCopilot(role, entity)];
    case "content": return [featContent(role, entity)];
    case "dashboard": return [featWorkspaceDashboard(role, entity)];
    case "board": return [featKanban(role)];
    case "approval-queue": return [featApprovalQueue(role)];
    case "sla": return [featSla(role)];
    default: return [featRecordList(role, entity)];
  }
}

/** Full sidebar NavSection[] from the menu (areas → groups → features). */
export function buildNavSections(labels = {}) {
  return MENU.areas.map((a) => ({
    id: a.id,
    label: (labels[a.id] ?? a.label).toUpperCase(),
    items: a.groups.map((g) => ({
      id: g.id,
      label: g.label,
      icon: g.icon,
      children: g.features.map((f) => ({ id: f.id, label: f.label, href: f.route })),
    })),
  }));
}

/**
 * Build synthetic modules for every Feature whose archetype services the solution
 * consumes, skipping routes already owned by a real manifest module (real wins) and
 * the archetype routes (/home, /copilot) emitted by manifest.home/copilot.
 */
export function buildModules(manifest, navSections) {
  const consumes = new Set(manifest.consumes_platform_services ?? []);
  const realRoutes = new Set((manifest.modules ?? []).map((m) => m.route).filter(Boolean));
  const archetypeRoutes = new Set(["/home", "/copilot", "/onboarding"]);

  // Wave 2 mount seam: manifest `standard_menu_organisms` overrides (schema at
  // packages/shared/contracts/src/solution-manifest.ts). Route → override lookup,
  // applied per-synthesized-module below so it carries pageComponent/composesOrganism
  // through the SAME scaffold-solution.mjs seam a hand-authored module uses (that
  // generator merges these synthetic modules straight into manifest.modules — see
  // `manifest.modules = [...synth, ...manifest.modules]`).
  const organismOverrides = new Map(
    (manifest.standard_menu_organisms ?? []).map((o) => [o.route, o]),
  );
  const matchedOverrideRoutes = new Set();

  // T2.3 (GAP-UI-1): use the solution's primary real entity for standard-menu demo pages
  // instead of hardcoded demo-record. Selection priority:
  //   1. First entity with lifecycle declared (has a state machine → richest LVE config)
  //   2. First real entity (not a demo placeholder)
  //   3. null → fall back to demo-record defaults (backward-compat for solutions with no entities block)
  const realEntities = (manifest.entities ?? []).filter(
    (e) => e.type !== "demo-record" && e.type !== "demo-catalog-item",
  );
  const primaryEntity = realEntities.find((e) => e.lifecycle) ?? realEntities[0] ?? null;

  const mods = [];
  let n = 0;
  for (const a of MENU.areas) {
    for (const g of a.groups) {
      for (const f of g.features) {
        if (realRoutes.has(f.route) || archetypeRoutes.has(f.route)) continue;
        const wires = ARCH_WIRES[f.archetype] ?? ["PS.DATA"];
        if (!wires.every((w) => consumes.has(w))) continue; // skip if service not consumed
        n += 1;
        const role = `${a.id}-${f.id}`;
        const mod = {
          id: `${manifest.solution}.S${n.toString().padStart(2, "0")}`,
          name: f.label,
          journey: 2,
          scaffold: "SH.02",
          route: f.route,
          layout: LAYOUT_EMIT[f.layout] ?? "object-page-detail",
          section: a.id,
          menuItem: f.label,
          features: featuresFor(f.archetype, role, f.label, entityForStandardMenuFeature(f, realEntities, primaryEntity)),
          nav: {
            logo: manifest.solution,
            items: [{ id: f.id, label: f.label, href: f.route, active: true }],
            sections: navSections,
          },
          _standardDemo: true,
        };
        const override = organismOverrides.get(f.route);
        if (override) {
          matchedOverrideRoutes.add(f.route);
          mod.pageComponent = override.pageComponent ?? `solution/pages/${toPascal(override.composesOrganism)}`;
          mod.composesOrganism = override.composesOrganism;
        }
        mods.push(mod);
      }
    }
  }
  for (const route of organismOverrides.keys()) {
    if (!matchedOverrideRoutes.has(route)) {
      console.warn(
        `standard_menu_organisms: override for route "${route}" did not match any standard-menu-` +
          `synthesized route (already owned by a hand-authored module, gated PS service not consumed, ` +
          `or route not in scripts/standard-menu.json) — ignoring.`,
      );
    }
  }
  return mods;
}

export const STANDARD_MENU = MENU;
