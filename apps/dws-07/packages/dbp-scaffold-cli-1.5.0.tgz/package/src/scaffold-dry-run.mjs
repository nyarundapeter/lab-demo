#!/usr/bin/env node
/**
 * scaffold-dry-run — preview EXACTLY what a `--force` regen would do, before it does it.
 *
 * The STCB merge report's worst-case: "a silent fast-forward that deletes 82 files".
 * This prints the full deletion/overwrite manifest first. Nothing in the target is
 * touched — the generator runs into a temp directory and the result is diffed.
 *
 * Usage:
 *   node scripts/scaffold-dry-run.mjs <path-to-SOLUTION.md> [--target <dir>]
 *   (in a standalone repo: pnpm regen --dry-run)
 *
 * Report classes:
 *   CREATE     — file the regen would add (not in the target today)
 *   OVERWRITE  — generator-owned file whose content would change
 *   DELETE     — generator-owned file from a PREVIOUS regen the new emission no
 *                longer produces (the sweep would remove it)
 *   preserved  — solution-owned files are never listed: the ownership contract
 *                guarantees they are untouched (create-if-missing only)
 *
 * DELETE detection needs the target's solution/_arch/generator-owned.json (written
 * by every regen since 2026-07-04). Without it, stale-file deletion cannot be
 * predicted and the report says so explicitly rather than staying silent.
 */

import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const SCRIPTS_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(SCRIPTS_DIR, "..");

const args = process.argv.slice(2);
const manifestArg = args.find((a) => !a.startsWith("--"));
const targetFlag = args.includes("--target") ? args[args.indexOf("--target") + 1] : null;
if (!manifestArg) {
  console.error("Usage: node scripts/scaffold-dry-run.mjs <path-to-SOLUTION.md> [--target <dir>]");
  process.exit(1);
}
const manifestPath = path.resolve(manifestArg);

// Default target: the app dir the generator would write to. In a standalone repo
// (no apps/ tree) that is the repo root; in the monorepo it is apps/<slug>.
function defaultTarget() {
  if (targetFlag) return path.resolve(targetFlag);
  const m = fs.readFileSync(manifestPath, "utf8").match(/^solution:\s*(\S+)/m);
  const slug = m ? m[1].toLowerCase().replace(/\./g, "-") : null;
  const monorepoTarget = slug ? path.join(ROOT, "apps", slug) : null;
  if (monorepoTarget && fs.existsSync(monorepoTarget)) return monorepoTarget;
  return ROOT; // standalone: app lives at the repo root
}
const target = defaultTarget();

// ── Generate into a temp dir (the real generator, zero risk to the target) ────
const tmpOut = fs.mkdtempSync(path.join(os.tmpdir(), "dbp-dry-run-"));
console.log(`\n[dry-run] generating preview from ${path.basename(manifestPath)} ...`);
try {
  execFileSync(
    process.execPath,
    [path.join(SCRIPTS_DIR, "scaffold-solution.mjs"), manifestPath, "--out-dir", tmpOut, "--force", "--allow-dirty", "--allow-nonconformant"],
    { cwd: ROOT, stdio: ["ignore", "ignore", "pipe"], maxBuffer: 1024 * 1024 * 64 },
  );
} catch (e) {
  const stderr = String(e.stderr ?? e);
  const lines = stderr.split("\n");
  const tail = lines.slice(-50).join("\n");
  console.error(`[dry-run] generator failed (exit code ${e.status ?? "unknown"}):\n${tail}`);
  fs.rmSync(tmpOut, { recursive: true, force: true });
  process.exit(1);
}

const owned = JSON.parse(fs.readFileSync(path.join(tmpOut, "solution", "_arch", "generator-owned.json"), "utf8"));

const creates = [];
const overwrites = [];
for (const rel of owned) {
  const freshFile = path.join(tmpOut, rel);
  if (!fs.existsSync(freshFile)) continue;
  const targetFile = path.join(target, rel);
  if (!fs.existsSync(targetFile)) {
    creates.push(rel);
    continue;
  }
  const fresh = fs.readFileSync(freshFile, "utf8").replace(/\r\n/g, "\n");
  const existing = fs.readFileSync(targetFile, "utf8").replace(/\r\n/g, "\n");
  if (fresh !== existing) overwrites.push(rel);
}

// DELETE prediction: old ownership manifest ∖ new emission set.
const oldManifestPath = path.join(target, "solution", "_arch", "generator-owned.json");
let deletes = null;
if (fs.existsSync(oldManifestPath)) {
  const oldOwned = new Set(JSON.parse(fs.readFileSync(oldManifestPath, "utf8")));
  const newOwned = new Set(owned);
  deletes = [...oldOwned].filter((rel) => !newOwned.has(rel) && fs.existsSync(path.join(target, rel)));
}

fs.rmSync(tmpOut, { recursive: true, force: true });

// ── Report ────────────────────────────────────────────────────────────────────
console.log(`\n[dry-run] a --force regen of ${target} would:\n`);
console.log(`  CREATE     ${creates.length} file(s)`);
for (const f of creates.slice(0, 40)) console.log(`    + ${f}`);
if (creates.length > 40) console.log(`    … and ${creates.length - 40} more`);
console.log(`  OVERWRITE  ${overwrites.length} generator-owned file(s)`);
for (const f of overwrites.slice(0, 40)) console.log(`    ~ ${f}`);
if (overwrites.length > 40) console.log(`    … and ${overwrites.length - 40} more`);
if (deletes === null) {
  console.log(
    `  DELETE     UNKNOWN — the target has no solution/_arch/generator-owned.json\n` +
      `             (predates the ownership manifest). The first --force regen will\n` +
      `             write it; until then stale-file deletion cannot be previewed.`,
  );
} else {
  console.log(`  DELETE     ${deletes.length} stale generator-owned file(s)`);
  for (const f of deletes) console.log(`    - ${f}`);
}
console.log(
  `\n  Solution-owned files (solution/**, instrumentation.ts, docs, tests, …) are\n` +
    `  NEVER deleted or overwritten — the ownership contract preserves them.\n`,
);
process.exit(0);
