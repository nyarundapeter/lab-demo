/**
 * check-generated-conformance.mjs
 *
 * Post-emit conformance gate for DBP scaffold-generated pages.
 * Exports: checkGeneratedConformance(appDir) → { errors: string[], warnings: string[] }
 * CLI:     node scripts/check-generated-conformance.mjs <appDir>
 *
 * Checks (regex-based, no TS parsing):
 *  ERROR   — Double header: page uses a header-bearing layout AND imports PageHeader/BreadcrumbBar
 *  WARNING — Missing breadcrumb: page uses a header-bearing layout but has no breadcrumb={
 *  WARNING — Self-headed (no layout): page uses no header-bearing layout (bare/content-landing);
 *            logged so operator can confirm it is intentional
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const REPO_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// ── Layout names that render their own PageHeader ────────────────────────────
const HEADER_BEARING_LAYOUTS = [
  "CanvasLayout",
  "WorkingLayout",
  "CatalogueLayout",
  "AnalyticsLayout",
  "SettingsLayout",
];

// Regex: matches <WorkingLayout, <CatalogueLayout, etc. in JSX
const LAYOUT_USAGE_RE = new RegExp(
  `<(${HEADER_BEARING_LAYOUTS.join("|")})[\\s/>]`,
);

// Regex: import of PageHeader or BreadcrumbBar from @dbp/ui
const SELF_HEADING_IMPORT_RE =
  /import\s+[^;]*\b(PageHeader|BreadcrumbBar)\b[^;]*from\s+['"]@dbp\/ui['"]/;

/**
 * ADR-0035 header-slot rule: PageHeader/BreadcrumbBar may ONLY be rendered inside
 * a layout's `header={...}` slot prop — never as freestanding JSX. Mirrors
 * pageHeaderOnlyInHeaderSlot() in admin-archetype-conformance.test.ts: each
 * occurrence must be immediately preceded by `header={` (whitespace/paren allowed).
 * @param {string} src
 * @returns {string[]} component names rendered OUTSIDE a header slot
 */
function freestandingHeaderComponents(src) {
  const offenders = [];
  for (const name of ["PageHeader", "BreadcrumbBar"]) {
    const re = new RegExp(`<${name}\\b`, "g");
    let m;
    while ((m = re.exec(src)) !== null) {
      // Slot-bound if `header={` opens directly before (multi-line slot JSX) …
      const before = src.slice(Math.max(0, m.index - 80), m.index);
      if (/header=\{\s*\(?\s*$/.test(before)) continue;
      // … or earlier on the SAME line (conditional slots: header={cond ? <PageHeader …).
      const lineStart = src.lastIndexOf("\n", m.index) + 1;
      if (src.slice(lineStart, m.index).includes("header={")) continue;
      offenders.push(name);
      break;
    }
  }
  return offenders;
}

// Regex: breadcrumb prop present in JSX
const BREADCRUMB_PROP_RE = /breadcrumb=\{/;

// ── Recursive page collector ──────────────────────────────────────────────────

/**
 * Recursively collect all *page.tsx files under `dir`,
 * skipping node_modules and .next.
 * @param {string} dir
 * @param {string[]} [acc]
 * @returns {string[]}
 */
function collectPageFiles(dir, acc = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return acc;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === "node_modules" || entry.name === ".next") continue;
      collectPageFiles(full, acc);
    } else if (entry.isFile() && entry.name.endsWith("page.tsx")) {
      acc.push(full);
    }
  }
  return acc;
}

/**
 * Recursively collect files matching `predicate` under `dir`, skipping
 * node_modules/.next/__tests__/*.stories.tsx.
 * @param {string} dir
 * @param {(name: string) => boolean} predicate
 * @param {string[]} [acc]
 * @returns {string[]}
 */
function collectFiles(dir, predicate, acc = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return acc;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === "node_modules" || entry.name === ".next" || entry.name === "__tests__") continue;
      collectFiles(full, predicate, acc);
    } else if (entry.isFile() && predicate(entry.name)) {
      acc.push(full);
    }
  }
  return acc;
}

// ── G-HEADER extension (a): pageComponent-referenced solution/pages/*.tsx ────
//
// Per docs/09-plans/design-ingestion-approach-2026-07-18/quality-gates-and-conformance.md
// G-HEADER row: extend the same freestanding-header regex logic used for
// app/**/page.tsx to the solution-owned page components a manifest's
// `pageComponent` field wires in (survive `--force` regen, never
// generator-emitted — see the SOLUTION-OWNED header comment convention).
// REPORT-ONLY: pushed to `warnings`, never `errors` — this is new-check
// surface against an existing tree, and scaffold-solution.mjs's post-emit
// gate `die()`s on any `errors` entry, so a new error here would newly fail
// generation. Mirrors the existing SELF-HEADED/MISSING BREADCRUMB checks,
// which are already warning-level for the same reason.
/**
 * Brace-balance-aware slot check: is the JSX node at `tagIndex` still inside
 * the nearest preceding `header={...}` prop value? More permissive than
 * freestandingHeaderComponents()'s fixed-window regex (which only recognises
 * `header={<Tag` or `header={(<Tag` immediately adjacent) — solution-owned
 * pages route conditional headers through a ternary (`header={cond ? (<Tag`),
 * which the fixed-window regex misses and would falsely flag.
 * @param {string} src
 * @param {number} tagIndex
 * @returns {boolean}
 */
function isInsideHeaderSlot(src, tagIndex) {
  const headerIdx = src.lastIndexOf("header={", tagIndex);
  if (headerIdx === -1) return false;
  const between = src.slice(headerIdx + "header=".length, tagIndex); // starts with "{"
  let depth = 0;
  for (const ch of between) {
    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth <= 0) return false; // the header={...} slot closed before reaching the tag
    }
  }
  return depth > 0;
}

function checkSolutionPagesHeaders(appDir, warnings) {
  const solutionPagesDir = path.resolve(appDir, "solution", "pages");
  const files = collectFiles(solutionPagesDir, (name) => name.endsWith(".tsx"));
  for (const filePath of files) {
    let src;
    try {
      src = fs.readFileSync(filePath, "utf8");
    } catch {
      continue;
    }
    const rel = path.relative(appDir, filePath).replace(/\\/g, "/");
    const usesHeaderLayout = LAYOUT_USAGE_RE.test(src);
    const importsSelfHeading = SELF_HEADING_IMPORT_RE.test(src);
    if (!usesHeaderLayout || !importsSelfHeading) continue;

    const offenders = [];
    for (const name of ["PageHeader", "BreadcrumbBar"]) {
      const re = new RegExp(`<${name}\\b`, "g");
      let m;
      while ((m = re.exec(src)) !== null) {
        if (!isInsideHeaderSlot(src, m.index)) {
          offenders.push(name);
          break;
        }
      }
    }
    if (offenders.length > 0) {
      warnings.push(
        `[SOLUTION PAGE DOUBLE HEADER] ${rel} — renders ${offenders.join("/")} outside the layout's header={...} slot (ADR-0035)`,
      );
    }
  }
}

// ── G-HEADER extension (b): organism double-padding signal ───────────────────
//
// A "double padding" defect: an organism (packages/stack/app-scaffolds/features/
// <slug>/index.tsx or components/**) applies its own outer page padding/max-width
// on its outermost returned JSX node — duplicating the layout's own page-frame
// padding (§7c). Regex/light-AST heuristic, not full layout computation —
// necessarily approximate (false negatives expected), same posture as the
// G-ELEVATION heuristic. REPORT-ONLY.
// Requires BOTH a max-w-* token AND a page-padding token (p-/px-/py-) on the
// SAME className — the page-wrapper signature (§7c's actual example: `mx-auto
// max-w-[1200px] ... px-5 py-7`). Either alone is common and legitimate on an
// ordinary card/panel (e.g. `p-5` on a card, `max-w-full` on a flex child) and
// produced too many false positives when checked independently.
const MAX_WIDTH_CLASS_RE = /(?:^|["'\s])max-w-[^\s"'{}]+/;
const PAGE_PADDING_CLASS_RE = /(?:^|["'\s])p[xy]?-[^\s"'{}]+/;

/**
 * Find the last `return (\s*<Tag ...>` inside the (heuristically located)
 * default-exported component function body — the happy-path root render,
 * since guard/early-return JSX typically appears earlier in the function.
 * @param {string} src
 * @returns {{ tag: string, className: string } | null}
 */
function outermostReturnedJsx(src) {
  const fnMatch = /export\s+default\s+function\s+\w*\s*\([^)]*\)[^{]*\{/.exec(src);
  const bodyStart = fnMatch ? fnMatch.index + fnMatch[0].length : 0;
  const body = fnMatch ? src.slice(bodyStart) : src;

  const returnJsxRe = /return\s*\(\s*\n?\s*<([A-Za-z][\w.]*)\b((?:[^>]|\n)*?)>/g;
  let m;
  let last = null;
  while ((m = returnJsxRe.exec(body)) !== null) {
    last = { tag: m[1], attrs: m[2] };
  }
  if (!last) return null;

  const classMatch = /className\s*=\s*"([^"]*)"/.exec(last.attrs);
  return { tag: last.tag, className: classMatch ? classMatch[1] : "" };
}

function checkOrganismDoublePadding(warnings) {
  const featuresDir = path.resolve(REPO_ROOT, "packages/stack/app-scaffolds/features");
  // Only the organism's default-export root (index.tsx) is ever mounted
  // directly under a layout, so it's the only file that can duplicate the
  // layout's page frame. `components/**` sub-components (cards, drawers,
  // document sheets, etc.) legitimately own their own local width/padding
  // for their own visual purpose — e.g. a fixed side panel or a centered
  // "paper" sheet inside a report — and are never mounted as page content
  // themselves, so scanning them produced false positives (report-sheet.tsx,
  // workflow-side-panel.tsx). See D7/§7c.
  const files = collectFiles(
    featuresDir,
    (name) => name.endsWith(".tsx") && !name.endsWith(".stories.tsx") && !name.endsWith(".test.tsx"),
  ).filter((f) => path.basename(f) === "index.tsx");

  for (const filePath of files) {
    let src;
    try {
      src = fs.readFileSync(filePath, "utf8");
    } catch {
      continue;
    }
    const root = outermostReturnedJsx(src);
    if (!root || !root.className) continue;
    if (MAX_WIDTH_CLASS_RE.test(root.className) && PAGE_PADDING_CLASS_RE.test(root.className)) {
      const rel = path.relative(REPO_ROOT, filePath).replace(/\\/g, "/");
      warnings.push(
        `[ORGANISM DOUBLE PADDING] ${rel} — outermost <${root.tag}> className applies page-level padding/width ("${root.className}"); the layout owns page padding/max-width, not the organism`,
      );
    }
  }
}

// ── Main checker ─────────────────────────────────────────────────────────────

/**
 * @param {string} appDir  Absolute or cwd-relative path to the app root
 *                         (the dir that contains `app/`)
 * @returns {{ errors: string[], warnings: string[] }}
 */
export function checkGeneratedConformance(appDir) {
  const errors = [];
  const warnings = [];

  const appRouteDir = path.resolve(appDir, "app");
  if (!fs.existsSync(appRouteDir)) {
    warnings.push(`app/ directory not found under ${appDir} — skipping`);
    return { errors, warnings };
  }

  // ── Auth-guard drift check (the (authenticated)/layout.tsx session guard) ────
  // useAuth() returns { user, status }, NOT { loading }. A hand-edit that
  // destructures `loading` makes it permanently `undefined`, collapsing the
  // guard to "redirect whenever user is null" — which fires mid-session-fetch
  // and logs the user out on navigation. The guard MUST gate on the real
  // loading state via `status === "loading"`. (See docs reference 2026-06-25.)
  // The guard historically lived in layout.tsx; the server-gate split (audit 2.3)
  // moved the client-side useAuth() UX guard to authenticated-client-shell.tsx.
  // Scan whichever of the two carries it.
  const authLayout = [
    path.resolve(appRouteDir, "(authenticated)", "authenticated-client-shell.tsx"),
    path.resolve(appRouteDir, "(authenticated)", "layout.tsx"),
  ].find((p) => fs.existsSync(p) && fs.readFileSync(p, "utf8").includes("useAuth("));
  if (authLayout) {
    let layoutSrc = "";
    try {
      layoutSrc = fs.readFileSync(authLayout, "utf8");
    } catch {
      warnings.push(`Could not read ${path.relative(appDir, authLayout).replace(/\\/g, "/")}`);
    }
    if (layoutSrc.includes("useAuth(")) {
      const rel = path.relative(appDir, authLayout).replace(/\\/g, "/");
      // useAuth() exposes no `loading` field — destructuring it is the bug.
      if (/\{[^}]*\bloading\b[^}]*\}\s*=\s*useAuth\(/.test(layoutSrc)) {
        errors.push(
          `[AUTH GUARD DRIFT] ${rel} — destructures \`loading\` from useAuth(), which returns no such field (always undefined). Use \`status\` and gate on \`status === "loading"\`.`,
        );
      }
      // The guard must wait for the session query before redirecting.
      if (!layoutSrc.includes('status === "loading"') && !layoutSrc.includes("status === 'loading'")) {
        errors.push(
          `[AUTH GUARD DRIFT] ${rel} — session guard does not gate on \`status === "loading"\`; it will redirect to /login while the session is still loading, logging users out on navigation.`,
        );
      }
    }
  }

  const pages = collectPageFiles(appRouteDir);

  for (const filePath of pages) {
    let src;
    try {
      src = fs.readFileSync(filePath, "utf8");
    } catch {
      warnings.push(`Could not read ${filePath}`);
      continue;
    }

    const rel = path.relative(appDir, filePath).replace(/\\/g, "/");
    const usesHeaderLayout = LAYOUT_USAGE_RE.test(src);
    const importsSelfHeading = SELF_HEADING_IMPORT_RE.test(src);
    const hasBreadcrumb = BREADCRUMB_PROP_RE.test(src);

    if (usesHeaderLayout) {
      // ERROR: double-header — the layout owns the header region. Importing
      // PageHeader/BreadcrumbBar is fine ONLY when every render sits inside the
      // layout's `header={...}` slot (the sanctioned ADR-0035 pattern); a
      // freestanding render paints a second header.
      if (importsSelfHeading) {
        const offenders = freestandingHeaderComponents(src);
        if (offenders.length > 0) {
          errors.push(
            `[DOUBLE HEADER] ${rel} — renders ${offenders.join("/")} outside the layout's header={...} slot (ADR-0035: the slot is the only sanctioned place)`,
          );
        }
      }
      // WARNING: layout is present but no breadcrumb prop
      if (!hasBreadcrumb) {
        warnings.push(
          `[MISSING BREADCRUMB] ${rel} — uses a header-bearing layout but no breadcrumb={...} prop found`,
        );
      }
    } else {
      // WARNING: no header-bearing layout (bare/content-landing) — flag for operator review
      warnings.push(
        `[SELF-HEADED / NO LAYOUT] ${rel} — no header-bearing layout detected; confirm this is intentional (bare/content-landing/special page)`,
      );
    }
  }

  // G-HEADER extension (a): pageComponent-referenced solution/pages/*.tsx — warn-only.
  checkSolutionPagesHeaders(appDir, warnings);
  // G-HEADER extension (b): organism double-padding signal — repo-wide (organisms
  // are shared across apps, not per-appDir), warn-only.
  checkOrganismDoublePadding(warnings);

  return { errors, warnings };
}

// ── CLI entry point ───────────────────────────────────────────────────────────

if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === path.resolve(import.meta.url.replace(/^file:\/\/\//, "").replace(/^file:\/\//, ""))
) {
  const appDir = process.argv[2];
  if (!appDir) {
    console.error("Usage: node scripts/check-generated-conformance.mjs <appDir>");
    process.exit(1);
  }

  const { errors, warnings } = checkGeneratedConformance(appDir);

  console.log("\n  ── Conformance check ─────────────────────────────────────");
  if (errors.length === 0 && warnings.length === 0) {
    console.log("  ✓ pages conform — no errors or warnings");
  } else {
    const summary =
      errors.length === 0 && warnings.length > 0
        ? `0 errors, ${warnings.length} warnings`
        : errors.length > 0 && warnings.length === 0
          ? `${errors.length} errors, 0 warnings`
          : `${errors.length} errors, ${warnings.length} warnings`;
    console.log(`  ${summary}`);
    console.log("");
    for (const e of errors) {
      console.log(`  ERROR   ${e}`);
    }
    for (const w of warnings) {
      console.log(`  warn    ${w}`);
    }
  }
  console.log("  ──────────────────────────────────────────────────────────\n");
}
