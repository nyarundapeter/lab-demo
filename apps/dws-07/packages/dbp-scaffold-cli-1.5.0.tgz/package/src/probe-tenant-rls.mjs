#!/usr/bin/env node
/**
 * probe-tenant-rls.mjs — N3, docs/09-plans/minimum-test-plan-build-spec-2026-07-07.md
 * Increment G.
 *
 * Live-DB tenant-isolation probe. The mocked test at
 * packages/stack/platform-db/src/__tests__/tenant-isolation.test.ts validates only the
 * TypeScript withTenant() call contract — it never touches a real database, so it cannot
 * prove Postgres RLS actually blocks cross-tenant reads. This script closes that gap: it
 * connects to a REAL Postgres, seeds two tenants' rows in the RLS-protected `data.entity`
 * table (packages/stack/platform-db/migrations/0001_platform_rls.sql § data.entity —
 * `tenant_isolation` policy: `tenant_id = platform.current_tenant_id()`), and asserts a
 * session scoped to tenant-A cannot read tenant-B's rows (and can read its own).
 *
 * Connection: `RLS_DB_URL` (not DATABASE_URL — that name is reserved for a real dev/app DB
 * and this script seeds + deletes rows, so it must never accidentally point at one).
 *
 * Assumption: RLS_DB_URL already has the platform migrations applied (0000-0002 minimum,
 * for schemas/RLS policies/roles + the seed tenant). This script does not run migrations
 * itself — the nightly CI job runs scripts/db-governance-templates/db-migrate.mjs (via
 * DIRECT_URL) against the same services:postgres container first. Document this rather than
 * re-running migrations here to keep the probe fast and side-effect-free beyond its own rows.
 *
 * The probing connection uses `SET LOCAL ROLE dbp_app` inside a transaction to switch to the
 * RLS-enforced role. dbp_app is NOLOGIN (a group role — see 0001_platform_rls.sql), so a
 * direct client connection as dbp_app is not possible; `SET ROLE` from a superuser/owner
 * connection is the standard way to exercise RLS as that role without needing a concrete
 * per-substrate login credential.
 *
 * Adoption mode: exits 0 unless --strict is passed. Skipping (no RLS_DB_URL) is NOT a
 * failure at any strictness level — only an actual cross-tenant read (a real isolation
 * breach) fails --strict.
 *
 * Usage:
 *   RLS_DB_URL=postgres://user:pass@host:5432/db node scripts/probe-tenant-rls.mjs [--strict]
 */
const STRICT = process.argv.includes("--strict");
const CONN = process.env.RLS_DB_URL;

if (!CONN) {
  console.log("[probe-tenant-rls] SKIP — RLS_DB_URL is not set — skipping live-DB RLS probe (set RLS_DB_URL to a real Postgres to run it).");
  process.exit(0);
}

// Lazily resolved: `postgres` is a dependency of @dbp/platform-db, not the repo root, so a
// plain `import "postgres"` from scripts/ can fail to resolve under pnpm's strict linking.
// Resolve it relative to @dbp/platform-db's own node_modules instead, falling back to a
// plain import in case hoisting makes it root-resolvable in some install layouts.
let postgres;
try {
  const { createRequire } = await import("node:module");
  const { pathToFileURL } = await import("node:url");
  const require = createRequire(
    new URL("../packages/stack/platform-db/package.json", import.meta.url),
  );
  const postgresEntry = require.resolve("postgres");
  ({ default: postgres } = await import(pathToFileURL(postgresEntry).href));
} catch {
  try {
    ({ default: postgres } = await import("postgres"));
  } catch (err) {
    console.error(`[probe-tenant-rls] FAIL — RLS_DB_URL is set but the "postgres" package could not be resolved: ${err?.message ?? err}`);
    process.exit(STRICT ? 1 : 0);
  }
}

const TENANT_A = `probe-tenant-a-${Date.now()}`;
const TENANT_B = `probe-tenant-b-${Date.now()}`;
const ENTITY_TYPE = `probe-type-${Date.now()}`;
const ROW_A = `probe-row-a-${Date.now()}`;
const ROW_B = `probe-row-b-${Date.now()}`;

const sql = postgres(CONN, { max: 1, prepare: false, onnotice: () => {} });

async function withTenantRole(tenantId, fn) {
  return sql.begin(async (tx) => {
    await tx`select set_config('app.tenant_id', ${tenantId}, true)`;
    await tx.unsafe("set local role dbp_app");
    return fn(tx);
  });
}

async function cleanup() {
  // Runs as the connecting (owner/superuser) role, which bypasses RLS — needed to clean up
  // rows seeded under both tenants regardless of which tenant context is currently active.
  await sql`delete from data.entity where tenant_id in (${TENANT_A}, ${TENANT_B})`;
  await sql`delete from data.entity_type where type = ${ENTITY_TYPE}`;
  await sql`delete from iam.tenant where id in (${TENANT_A}, ${TENANT_B})`;
}

// Runs the probe end-to-end and returns { status: "pass"|"fail", message }.
// Never calls process.exit() itself so the caller can always release the connection first.
async function runProbe() {
  // ── Setup: two tenants + a shared entity_type + one row per tenant ──────────
  await sql`insert into iam.tenant (id, name) values (${TENANT_A}, 'RLS Probe Tenant A') on conflict (id) do nothing`;
  await sql`insert into iam.tenant (id, name) values (${TENANT_B}, 'RLS Probe Tenant B') on conflict (id) do nothing`;
  await sql`
    insert into data.entity_type (type, json_schema)
    values (${ENTITY_TYPE}, '{}'::jsonb)
    on conflict (type) do nothing
  `;

  await withTenantRole(TENANT_A, (tx) =>
    tx`
      insert into data.entity (id, tenant_id, type, data)
      values (${ROW_A}, ${TENANT_A}, ${ENTITY_TYPE}, '{"probe":"a"}'::jsonb)
      on conflict (id) do nothing
    `,
  );
  await withTenantRole(TENANT_B, (tx) =>
    tx`
      insert into data.entity (id, tenant_id, type, data)
      values (${ROW_B}, ${TENANT_B}, ${ENTITY_TYPE}, '{"probe":"b"}'::jsonb)
      on conflict (id) do nothing
    `,
  );

  // ── Assertion 1: tenant-A session CANNOT read tenant-B's row ────────────────
  const crossTenantRows = await withTenantRole(TENANT_A, (tx) =>
    tx`select id from data.entity where id = ${ROW_B}`,
  );
  if (crossTenantRows.length > 0) {
    return {
      status: "fail",
      message:
        `RLS ISOLATION BREACH — tenant-A session read ${crossTenantRows.length} row(s) belonging to tenant-B (row id=${ROW_B}). ` +
        "RLS policy data.entity.tenant_isolation is not enforcing.",
    };
  }

  // ── Assertion 2: tenant-A session CAN read its own row ──────────────────────
  const ownTenantRows = await withTenantRole(TENANT_A, (tx) =>
    tx`select id from data.entity where id = ${ROW_A}`,
  );
  if (ownTenantRows.length !== 1) {
    return {
      status: "fail",
      message: `tenant-A session could not read its own row (id=${ROW_A}, found ${ownTenantRows.length}) — probe setup or RLS policy is broken (false-positive risk).`,
    };
  }

  return {
    status: "pass",
    message: "tenant-A session correctly isolated from tenant-B's row and correctly read its own row (data.entity.tenant_isolation policy enforced).",
  };
}

let result;
try {
  result = await runProbe();
} catch (err) {
  result = { status: "fail", message: `error during probe: ${err?.message ?? err}` };
}

try {
  await cleanup();
} catch (cleanupErr) {
  console.error(`[probe-tenant-rls] warning — cleanup failed: ${cleanupErr?.message ?? cleanupErr}`);
}

await sql.end({ timeout: 5 });

if (result.status === "pass") {
  console.log(`[probe-tenant-rls] PASS — ${result.message}`);
  process.exit(0);
} else {
  console.error(`[probe-tenant-rls] FAIL — ${result.message}`);
  process.exit(STRICT ? 1 : 0);
}
