// theme-policy.mjs — pure theme-token policy used by scaffold-solution.mjs.
//
// Extracted so it can be unit-tested without booting the CLI generator. No file
// I/O, no process state — just validation of a manifest `theme` block.
//
// Enforces (Corrections 1 + 1b, docs/01-Architecture/Standard-Navigation-and-Layout-Map.md):
//   (i)   --color-primary must NOT be the brand hue (stays dark navy/near-black).
//   (ii)  --color-surface / --color-border must be neutral grey/white (no brand tint).
//   (iii) --font-body / --font-display must not pin a font the design system does
//         not @import (the Arial-fallback trap).
//   (iv)  --radius below 6px gets an advisory warning (dated hard corner).
// (i)–(iii) are hard build failures; (iv) is advisory.

export const CHROMATIC_C = 0.15;   // chroma below this ⇒ neutral grey/navy/black
export const SAME_HUE_DEG = 20;    // primary & secondary within this hue band ⇒ same colour
export const SURFACE_C_MAX = 0.10; // surface/border chroma above this near the brand ⇒ tinted
export const SURFACE_HUE_DEG = 40; // ...and within this hue band of the accent

// base.css @imports ONLY these webfonts. A manifest that pins --font-body to any
// other NAMED family ships a font the browser cannot load → it silently falls back
// to Arial (the "old-school" look). Generic keywords are fine as fallbacks. So the
// FIRST family in a font override must be a loaded webfont or a generic keyword.
export const LOADED_FONT_FAMILIES = new Set(["plus jakarta sans", "jetbrains mono"]);
export const GENERIC_FONT_KEYWORDS = new Set([
  "system-ui", "ui-sans-serif", "ui-serif", "ui-monospace",
  "sans-serif", "serif", "monospace", "cursive", "fantasy",
  "-apple-system", "blinkmacsystemfont", "segoe ui",
]);
export const MIN_RADIUS_PX = 6; // radii below this read as a hard "Bootstrap-3" corner

/**
 * Parse a #rgb / #rrggbb string to {h(0-360), c(0-1 chroma), l(0-1)} or null.
 *
 * `c` (chroma = (max-min)/255) is the robust neutrality measure: near-white and
 * near-grey colours have tiny chroma regardless of lightness, unlike HSL
 * saturation which inflates toward white/black and false-flags neutral surfaces.
 */
export function hexToHsl(hex) {
  if (typeof hex !== "string") return null;
  let m = hex.trim().replace(/^#/, "");
  if (m.length === 3) m = m.split("").map((c) => c + c).join("");
  if (!/^[0-9a-fA-F]{6}$/.test(m)) return null;
  const r = parseInt(m.slice(0, 2), 16) / 255;
  const g = parseInt(m.slice(2, 4), 16) / 255;
  const b = parseInt(m.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  const d = max - min;
  let h = 0;
  if (d !== 0) {
    switch (max) {
      case r: h = ((g - b) / d) % 6; break;
      case g: h = (b - r) / d + 2; break;
      default: h = (r - g) / d + 4; break;
    }
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, c: d, l };
}

/** Smallest absolute angular distance between two hues (degrees, 0-180). */
export function hueDistance(a, b) {
  const d = Math.abs(a - b) % 360;
  return d > 180 ? 360 - d : d;
}

/** First family token of a CSS font-family value, lowercased, quotes stripped. */
export function firstFontFamily(value) {
  if (typeof value !== "string") return null;
  const first = value.split(",")[0] ?? "";
  return first.trim().replace(/^['"]|['"]$/g, "").trim().toLowerCase() || null;
}

/**
 * Validate a manifest `theme` block.
 *
 * @param theme       the manifest.theme object (or undefined)
 * @param solutionId  for error messages
 * @param handlers    { die(msg): never, warn(msg): void } — injected so the
 *                     generator can process.exit/console.warn while tests can
 *                     throw/collect. Defaults to throw-on-fail / console.warn.
 */
export function assertThemeColours(theme, solutionId, handlers = {}) {
  const die = handlers.die || ((msg) => { throw new Error(msg); });
  const warn = handlers.warn || ((msg) => console.warn(`WARN: ${msg}`));
  if (!theme) return;

  const primary = hexToHsl(theme["--color-primary"]);
  const secondary = hexToHsl(theme["--color-secondary"]);
  const surface = hexToHsl(theme["--color-surface"]);
  const border = hexToHsl(theme["--color-border"]);

  // (i) primary must not BE the brand hue. Only enforced when both are genuinely
  // chromatic (a near-neutral dark primary — navy/black — always passes) and
  // their hues are essentially the same colour.
  if (primary && secondary && primary.c >= CHROMATIC_C && secondary.c >= CHROMATIC_C) {
    if (hueDistance(primary.h, secondary.h) <= SAME_HUE_DEG) {
      die(
        `Theme colour policy (${solutionId}): --color-primary (${theme["--color-primary"]}) is the ` +
        `same colour as --color-secondary (${theme["--color-secondary"]}). The brand hue must be ` +
        `the ACCENT (--color-secondary); --color-primary stays a dark navy/near-black. ` +
        `See docs/01-Architecture/Standard-Navigation-and-Layout-Map.md (Correction 1).`,
      );
    }
  }

  // (ii) surface / border must be a neutral grey/white — not a tint of the brand.
  // Chroma (not HSL saturation) so legitimate near-white surfaces with a faint
  // cool cast (e.g. #F5F8F9) pass; a visibly brand-tinted field is rejected.
  for (const [name, col] of [["--color-surface", surface], ["--color-border", border]]) {
    if (col && secondary && col.c > SURFACE_C_MAX && hueDistance(col.h, secondary.h) <= SURFACE_HUE_DEG) {
      die(
        `Theme colour policy (${solutionId}): ${name} (${theme[name]}) is a tint of the brand ` +
        `accent --color-secondary. The page background must be a neutral grey/white shade (Rule 1b). ` +
        `See docs/01-Architecture/Standard-Navigation-and-Layout-Map.md.`,
      );
    }
  }

  // (iii) Font policy — reject a font override whose FIRST family is a named font
  // the design system does not load (the Arial-fallback trap). Omitting the override
  // inherits the DQ default (Plus Jakarta Sans) from theme.css.
  for (const name of ["--font-body", "--font-display"]) {
    const fam = firstFontFamily(theme[name]);
    if (fam && !LOADED_FONT_FAMILIES.has(fam) && !GENERIC_FONT_KEYWORDS.has(fam)) {
      die(
        `Theme font policy (${solutionId}): ${name} (${theme[name]}) pins "${fam}", which the design ` +
        `system does not @import (only Plus Jakarta Sans + JetBrains Mono are loaded). It would silently ` +
        `fall back to the system default (Arial). Pin a loaded font, or omit ${name} to inherit the DQ ` +
        `default (Plus Jakarta Sans).`,
      );
    }
  }

  // (iv) Radius nudge — a very tight radius reads as a dated hard corner. Advisory
  // only; solutions may still set it intentionally.
  if (typeof theme["--radius"] === "string") {
    const px = parseFloat(theme["--radius"]);
    if (Number.isFinite(px) && /px\s*$/.test(theme["--radius"].trim()) && px < MIN_RADIUS_PX) {
      warn(
        `Theme radius (${solutionId}): --radius (${theme["--radius"]}) is below ${MIN_RADIUS_PX}px — this ` +
        `reads as a hard, dated corner. The DQ default is 8px (cards resolve to 12px). Consider omitting it.`,
      );
    }
  }
}
