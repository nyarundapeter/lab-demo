import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { PublicCanvasLayout } from "../layouts/public-canvas.js";

// ─── Mock helpers ────────────────────────────────────────────────────────────────

/** Placeholder full-bleed body — stands in for a public interactive tool/configurator. */
function PublicCanvasMockBody() {
  return (
    <div className="flex h-full w-full items-center justify-center bg-[var(--color-surface)]">
      <div className="rounded-xl border border-[var(--color-border)] bg-white px-[var(--space-6)] py-[var(--space-5)] text-center shadow-sm">
        <p className="text-[var(--text-base)] font-semibold text-[var(--color-text)]">
          Public interactive canvas
        </p>
        <p className="mt-[var(--space-2)] text-[var(--text-sm)] text-[var(--color-text-muted)]">
          The feature owns this full-bleed surface — no page header, no site footer.
        </p>
      </div>
    </div>
  );
}

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof PublicCanvasLayout> = {
  title: "Layer 07 — App Scaffolds/Layouts/PublicCanvasLayout",
  component: PublicCanvasLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**PublicCanvasLayout** — the public counterpart of BuilderLayout / ConversationalLayout.

Props: \`children: ReactNode\` only (ADR-0035 structural seam).

Renders the public shell's \`TopBarNav\` for wayfinding, then a full-bleed,
\`overflow-hidden\` canvas that the feature owns entirely — no PageHeader, no
LandingShell hero/features/proof/cta/footer slot stack, no site footer.

**Status:** catalogue entry \`canvas / canvas-public\` is \`"bespoke"\` — declared via
\`manifest.canvasPublic\` (DXP-only), emitted at \`app/(public)/<route>/page.tsx\` by
\`emitCanvasPublicPage()\` in \`scaffold-solution.mjs\`. No dedicated canvas-public
feature package exists yet, so the emitted body is an honest placeholder naming
\`solution/pages\` as the real follow-up.

Use for: public-facing embeddable interactive tools (configurators, calculators,
wizards) that need the whole canvas edge-to-edge with no site chrome getting in
the way, while still giving the visitor a way back to the rest of the site.
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof PublicCanvasLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/** Full-bleed public canvas — top nav only, no page header, edge-to-edge body. */
export const Default: Story = {
  name: "Default (full-bleed, no page header)",
  render: () => (
    <div style={{ height: "640px" }}>
      <PublicCanvasLayout>
        <PublicCanvasMockBody />
      </PublicCanvasLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "TopBarNav for wayfinding, then a full-bleed overflow-hidden body — the feature manages its own internal scroll, exactly like BuilderLayout's body region.",
      },
    },
  },
};
