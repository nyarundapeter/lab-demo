import type { Meta, StoryObj } from "@storybook/react";
import React from "react";
import { SlotFrame } from "@dbp/ui";
import LandingShell from "../index.js";

const meta: Meta<typeof LandingShell> = {
  title: "Layer 07 — App Scaffolds/Shells/SH.PUBLIC — Public Shell (Landing)",
  component: LandingShell,
  parameters: {
    layout: "fullscreen",
  },
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj<typeof LandingShell>;

/**
 * Empty shell — all five slots visible as SlotFrame placeholders.
 *
 * At RUNTIME unfilled slots collapse (render nothing); this story passes
 * SlotFrame placeholders EXPLICITLY so the slot layout is visible in Storybook.
 * Switch theme in the toolbar to confirm zero structural change.
 */
export const EmptyShell: Story = {
  name: "Empty shell",
  args: {
    slots: {
      hero: <SlotFrame slotName="hero" isEmpty />,
      features: <SlotFrame slotName="features" isEmpty />,
      proof: <SlotFrame slotName="proof" isEmpty />,
      cta: <SlotFrame slotName="cta" isEmpty />,
      footer: <SlotFrame slotName="footer" isEmpty />,
    },
  },
};

/**
 * Populated shell — sample content in every slot.
 */
export const PopulatedShell: Story = {
  name: "Populated shell",
  args: {
    nav: {
      logo: <span style={{ fontWeight: 700, fontSize: "1.125rem" }}>Acme Co.</span>,
      links: [
        { label: "Product", href: "#product" },
        { label: "Pricing", href: "#pricing" },
        { label: "About", href: "#about" },
      ],
      actions: [{ label: "Get started", href: "#start" }],
    },
    slots: {
      hero: (
        <div style={{ textAlign: "center", padding: "3rem 1rem" }}>
          <h1 style={{ fontSize: "2.25rem", fontWeight: 700, marginBottom: "1rem" }}>
            Build faster. Ship smarter.
          </h1>
          <p style={{ fontSize: "1.125rem", opacity: 0.7, marginBottom: "2rem" }}>
            The DBP Landing Shell — composable, themeable, ready for PS.DATA.
          </p>
          <a
            href="#start"
            style={{
              display: "inline-block",
              padding: "0.75rem 2rem",
              background: "var(--color-primary)",
              color: "var(--color-primary-foreground)",
              borderRadius: "var(--radius, 6px)",
              fontWeight: 600,
              textDecoration: "none",
            }}
          >
            Get started
          </a>
        </div>
      ),
      features: (
        <div style={{ padding: "2rem 0" }}>
          <h2
            style={{
              fontSize: "1.5rem",
              fontWeight: 700,
              marginBottom: "1.5rem",
              textAlign: "center",
            }}
          >
            Features
          </h2>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
              gap: "1.5rem",
            }}
          >
            {["PS.DATA integration", "PS.AI personalisation", "9-token theming"].map((f) => (
              <div
                key={f}
                style={{
                  padding: "1.5rem",
                  border: "1px solid var(--color-border)",
                  borderRadius: "var(--radius, 6px)",
                }}
              >
                <p style={{ fontWeight: 600 }}>{f}</p>
                <p style={{ opacity: 0.6, fontSize: "0.875rem", marginTop: "0.5rem" }}>
                  Placeholder feature copy.
                </p>
              </div>
            ))}
          </div>
        </div>
      ),
      proof: (
        <div style={{ padding: "2rem 0", textAlign: "center" }}>
          <p style={{ opacity: 0.6, fontSize: "0.875rem", marginBottom: "1rem" }}>
            TRUSTED BY TEAMS AT
          </p>
          <div style={{ display: "flex", gap: "2rem", justifyContent: "center", flexWrap: "wrap" }}>
            {["Acme", "Globex", "Initech", "Umbrella"].map((name) => (
              <span
                key={name}
                style={{ fontWeight: 700, fontSize: "1.25rem", opacity: 0.4 }}
              >
                {name}
              </span>
            ))}
          </div>
        </div>
      ),
      cta: (
        <div
          style={{
            textAlign: "center",
            padding: "3rem 1rem",
            background: "color-mix(in srgb, var(--color-primary) 8%, transparent)",
            borderRadius: "var(--radius, 6px)",
          }}
        >
          <h2 style={{ fontSize: "1.875rem", fontWeight: 700, marginBottom: "1rem" }}>
            Ready to get started?
          </h2>
          <a
            href="#start"
            style={{
              display: "inline-block",
              padding: "0.75rem 2rem",
              background: "var(--color-primary)",
              color: "var(--color-primary-foreground)",
              borderRadius: "var(--radius, 6px)",
              fontWeight: 600,
              textDecoration: "none",
            }}
          >
            Start for free
          </a>
        </div>
      ),
      footer: (
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "1rem",
            opacity: 0.6,
            fontSize: "0.875rem",
          }}
        >
          <span>© 2026 Acme Co. All rights reserved.</span>
          <nav aria-label="Footer navigation" style={{ display: "flex", gap: "1.5rem" }}>
            {["Privacy", "Terms", "Contact"].map((l) => (
              <a key={l} href={`#${l.toLowerCase()}`}>
                {l}
              </a>
            ))}
          </nav>
        </div>
      ),
    },
  },
};

/**
 * Mobile viewport — nav links collapse into dropdown menu.
 */
export const MobileViewport: Story = {
  name: "Mobile viewport",
  parameters: {
    viewport: { defaultViewport: "mobile1" },
  },
  args: {
    nav: {
      logo: <span style={{ fontWeight: 700 }}>Acme Co.</span>,
      links: [
        { label: "Product", href: "#product" },
        { label: "Pricing", href: "#pricing" },
        { label: "About", href: "#about" },
      ],
      actions: [{ label: "Sign in", href: "#signin" }],
    },
    slots: {},
  },
};
