import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import LandingShell from "../index.js";
import { SHELL_SLOTS } from "../slots.js";

afterEach(() => {
  cleanup();
});

// ---------------------------------------------------------------------------
// 1. Empty slots COLLAPSE — no dashed dev placeholder / empty section at runtime
// ---------------------------------------------------------------------------
describe("SH.00 LandingShell — empty slots collapse", () => {
  it("renders NO slot placeholders by default (unfilled slots collapse)", () => {
    const { container } = render(<LandingShell />);
    // Unfilled optional slots must render nothing at runtime — no dashed
    // placeholder, no empty padded section band.
    expect(container.querySelectorAll("[data-slot-name]").length).toBe(0);
    for (const slot of SHELL_SLOTS) {
      expect(screen.queryByLabelText(`Empty slot: ${slot}`)).toBeNull();
    }
  });

  it("renders only the filled slots, each once", () => {
    const { container } = render(
      <LandingShell slots={{ hero: <div data-testid="hero">Hero</div> }} />,
    );
    const slots = container.querySelectorAll("[data-slot-name]");
    expect(slots.length).toBe(1);
    expect(slots[0]?.getAttribute("data-slot-name")).toBe("hero");
  });
});

// ---------------------------------------------------------------------------
// 2. Structure stable across theme-class swap
// ---------------------------------------------------------------------------
describe("SH.00 LandingShell — theme-class swap", () => {
  it("filled slots remain present and named after dbp-theme-alt swap", () => {
    const { container } = render(
      <div className="dbp-theme-alt">
        <LandingShell
          slots={{
            hero: <div>Hero</div>,
            features: <div>Features</div>,
            proof: <div>Proof</div>,
            cta: <div>CTA</div>,
            footer: <div>Footer</div>,
          }}
        />
      </div>,
    );
    const slots = container.querySelectorAll("[data-slot-name]");
    expect(slots.length).toBe(SHELL_SLOTS.length);
    const names = Array.from(slots).map((el) => el.getAttribute("data-slot-name"));
    for (const slot of SHELL_SLOTS) {
      expect(names, `slot "${slot}" missing after theme swap`).toContain(slot);
    }
  });
});

// ---------------------------------------------------------------------------
// 3. Shell renders without errors when children are provided to every slot
// ---------------------------------------------------------------------------
describe("SH.00 LandingShell — populated slots", () => {
  it("renders children in every slot without throwing", () => {
    const { container } = render(
      <LandingShell
        slots={{
          hero: <div data-testid="hero-content">Hero</div>,
          features: <div data-testid="features-content">Features</div>,
          proof: <div data-testid="proof-content">Proof</div>,
          cta: <div data-testid="cta-content">CTA</div>,
          footer: <div data-testid="footer-content">Footer</div>,
        }}
      />,
    );
    expect(container.querySelector("[data-testid='hero-content']")).not.toBeNull();
    expect(container.querySelector("[data-testid='features-content']")).not.toBeNull();
    expect(container.querySelector("[data-testid='proof-content']")).not.toBeNull();
    expect(container.querySelector("[data-testid='cta-content']")).not.toBeNull();
    expect(container.querySelector("[data-testid='footer-content']")).not.toBeNull();
    // No empty-state labels should be present
    for (const slot of SHELL_SLOTS) {
      expect(screen.queryByText(`slot:${slot}`), `unexpected empty label for slot "${slot}"`).toBeNull();
    }
  });
});

// ---------------------------------------------------------------------------
// 4. Nav keyboard navigation
// ---------------------------------------------------------------------------
describe("SH.00 LandingShell — nav keyboard navigation", () => {
  it("renders nav links as focusable anchors in the desktop nav", () => {
    render(
      <LandingShell
        nav={{
          links: [
            { label: "Product", href: "#product" },
            { label: "Pricing", href: "#pricing" },
          ],
          actions: [{ label: "Get started", href: "#start" }],
        }}
      />,
    );
    // All links should be in the document
    expect(screen.getAllByRole("link", { name: "Product" }).length).toBeGreaterThan(0);
    expect(screen.getAllByRole("link", { name: "Pricing" }).length).toBeGreaterThan(0);
    expect(screen.getAllByRole("link", { name: "Get started" }).length).toBeGreaterThan(0);
  });

  it("renders a mobile menu button with an accessible label", () => {
    render(
      <LandingShell
        nav={{
          links: [{ label: "Product", href: "#product" }],
        }}
      />,
    );
    // getAllByRole in case Radix renders an additional hidden trigger in the portal
    const menuBtns = screen.getAllByRole("button", { name: /open navigation menu/i });
    expect(menuBtns.length).toBeGreaterThan(0);
  });

  it("mobile menu button is keyboard-activatable (Enter opens dropdown)", async () => {
    const user = userEvent.setup();
    render(
      <LandingShell
        nav={{
          links: [{ label: "Docs", href: "#docs" }],
        }}
      />,
    );
    // Take the first visible trigger button
    const [menuBtn] = screen.getAllByRole("button", { name: /open navigation menu/i });
    menuBtn?.focus();
    await user.keyboard("{Enter}");
    // After Enter the DropdownMenuContent should be visible — Radix renders it in the DOM
    expect(screen.getByRole("menuitem", { name: "Docs" })).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// 5. Top bar uses the CSS var structural height (smoke-check the attribute)
// ---------------------------------------------------------------------------
describe("SH.00 LandingShell — structural header height", () => {
  it("top bar header has the var(--shell-header-h) height style", () => {
    const { container } = render(<LandingShell />);
    const header = container.querySelector("header[role='banner']");
    expect(header).not.toBeNull();
    expect(header?.getAttribute("style")).toContain("var(--shell-header-h)");
  });
});
