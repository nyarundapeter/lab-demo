import * as React from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@dbp/ui";
import type { NavLink } from "./slots.js";

interface TopBarNavProps {
  /** Logo area — arbitrary ReactNode (image, custom lockup). Takes precedence over code/name. */
  logo?: React.ReactNode;
  /** Solution code rendered bold-primary (e.g. "DXP.01A"). Renders a standard product lockup when provided. */
  code?: string;
  /** Solution name rendered muted after the code (e.g. "Digital Channels Web"). */
  name?: string;
  /** Navigation links displayed in the top bar */
  links?: NavLink[];
  /** Action items (e.g. "Sign in", "Get started") displayed at the trailing end */
  actions?: NavLink[];
}

/**
 * Top-bar navigation for SH.00 Landing Shell.
 *
 * Desktop (≥ md): logo | links | actions — all visible inline.
 * Mobile (< md): logo | [hamburger menu button] — links collapse into a DropdownMenu.
 *
 * Keyboard: fully tab-navigable; menu button activates on Enter/Space (Radix primitive).
 * Reduced-motion: dropdown open/close animation gated behind prefers-reduced-motion.
 */
export function TopBarNav({ logo, code, name, links = [], actions = [] }: TopBarNavProps) {
  const lockup = logo ?? (code ? (
    <a
      href="/"
      className="flex items-baseline gap-1.5 hover:opacity-80 motion-safe:transition-opacity focus-visible:outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-secondary)] rounded"
      aria-label={`${code}${name ? ` — ${name}` : ""} home`}
    >
      <span className="text-lg font-bold leading-none text-[var(--color-primary)]">{code}</span>
      {name && (
        <span className="text-base font-medium leading-none text-[var(--color-text-muted)]">
          / {name}
        </span>
      )}
    </a>
  ) : (
    <span className="text-[var(--text-base)] font-semibold text-[var(--color-text)]">DBP</span>
  ))

  return (
    <header
      role="banner"
      style={{ height: "var(--shell-header-h)", zIndex: "var(--z-sticky)" }}
      className="sticky top-0 flex w-full items-center border-b border-[var(--color-border-subtle)] bg-[var(--color-surface-content)]"
    >
      <div
        className="mx-auto flex w-full max-w-[var(--shell-content-max-w)] items-center gap-[var(--space-6)] px-[var(--shell-gutter)]"
      >
        {/* Logo / product lockup */}
        <div className="flex shrink-0 items-center">
          {lockup}
        </div>

        {/* Desktop nav links — hidden below md */}
        {links.length > 0 && (
          <nav
            aria-label="Main navigation"
            className="hidden md:flex md:flex-1 md:items-center md:gap-[var(--space-1)]"
          >
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={[
                  "rounded px-[var(--space-3)] py-[var(--space-2)]",
                  "text-[var(--text-sm)] font-medium text-[var(--color-text-muted)]",
                  "motion-safe:transition-colors",
                  "hover:text-[var(--color-primary)]",
                  "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-secondary)]",
                ].join(" ")}
              >
                {link.label}
              </a>
            ))}
          </nav>
        )}

        {/* Spacer to push actions to the trailing edge */}
        <div className="flex-1 md:flex-none" aria-hidden="true" />

        {/* Desktop action links — hidden below md */}
        {actions.length > 0 && (
          <div className="hidden md:flex md:items-center md:gap-[var(--space-2)]">
            {actions.map((action) => (
              <a
                key={action.href}
                href={action.href}
                className={[
                  "rounded-[var(--radius-pill)] px-[var(--space-4)] py-[var(--space-2)]",
                  "text-[var(--text-sm)] font-semibold",
                  "bg-[var(--color-secondary)] text-white",
                  "motion-safe:transition-colors",
                  "hover:opacity-90",
                  "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-secondary)]",
                ].join(" ")}
              >
                {action.label}
              </a>
            ))}
          </div>
        )}

        {/* Mobile menu — visible below md only */}
        {(links.length > 0 || actions.length > 0) && (
          <div className="flex items-center md:hidden">
            <DropdownMenu>
              <DropdownMenuTrigger
                aria-label="Open navigation menu"
                className={[
                  "flex h-9 w-9 items-center justify-center rounded",
                  "text-[var(--color-text)]",
                  "hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)]",
                  "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-primary)]",
                ].join(" ")}
              >
                {/* Hamburger icon — three horizontal bars */}
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  aria-hidden="true"
                >
                  <rect y="2" width="18" height="2" rx="1" fill="currentColor" />
                  <rect y="8" width="18" height="2" rx="1" fill="currentColor" />
                  <rect y="14" width="18" height="2" rx="1" fill="currentColor" />
                </svg>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {links.map((link) => (
                  <DropdownMenuItem key={link.href} asChild>
                    <a
                      href={link.href}
                      className="w-full"
                    >
                      {link.label}
                    </a>
                  </DropdownMenuItem>
                ))}
                {actions.map((action) => (
                  <DropdownMenuItem key={action.href} asChild>
                    <a
                      href={action.href}
                      className="w-full font-medium"
                    >
                      {action.label}
                    </a>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </div>
    </header>
  );
}
