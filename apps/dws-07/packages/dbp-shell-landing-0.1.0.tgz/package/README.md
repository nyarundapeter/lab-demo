# @dbp/shell-landing

registryId: `SH.00`

SH.00 Landing Shell — the public marketing page shell (journey stage 0, Discover). A fixed vertical stack (top-bar nav + `hero` / `features` / `proof` / `cta` / `footer` slots) that renders `<SlotFrame>` for filled slots and nothing for unfilled ones. The shell has zero data-fetching logic; solutions compose PS.DATA (content) and optionally PS.AI (personalization) into the slots at the solution layer. Structure (header height, section stacking, content max-width, gutter) is fixed and never theme-overridable — only the 9 theme tokens (`--color-*`, `--font-*`, `--radius`, `--density`) affect appearance.

**Tier:** shell

## Exports
| Export | Path |
|---|---|
| `.` | `./index.tsx` — default export `LandingShell` |
| `./slots` | `./slots.ts` — `SHELL_SLOTS`, `SlotName`, `SLOT_METADATA`, `NavLinkSchema`/`NavConfigSchema` |
| `./nav` | `./nav.tsx` — `TopBarNav` |
| `./layouts` | `./layouts/index.ts` — includes `PublicCanvasLayout` |

No `publishConfig.exports` override — package publishes source directly (no dist split); `publishConfig` only sets registry/access.

## Config schema
`slots.ts` defines `NavLinkSchema` and `NavConfigSchema` (Zod) for the nav-links/actions data shape passed to `TopBarNav`. No config schema for slot content itself — slots accept arbitrary `React.ReactNode`.

## Consumed by

Generator emit + app direct import. `scripts/scaffold-solution.mjs` maps registry IDs `SH.PUBLIC`/`SH.00` to `packageName: "@dbp/shell-landing"` and `importFrom: "@dbp/shell-landing"` for generated pages (lines ~970–977, ~3774–3779), and canvas-public pages import `PublicCanvasLayout` from `@dbp/shell-landing/layouts` (~6142). Generated apps import `LandingShell` directly from `@dbp/shell-landing` in multiple public-route pages, e.g. `apps/dxp-01a/app/page.tsx`, `apps/dxp-01a/app/marketplace/page.tsx`, `apps/dxp-01a/app/(public)/legal/**`.

## Shipping

Within the monorepo, `@dbp/shell-landing` resolves via normal pnpm workspace linking (`workspace:*`). For standalone/client delivery it ships as a packed tarball via the tarball + `.pnpmfile.cjs` mechanism described in `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history. See [SHELL.md](./SHELL.md) for the shell structure/slot/breakpoint spec.
