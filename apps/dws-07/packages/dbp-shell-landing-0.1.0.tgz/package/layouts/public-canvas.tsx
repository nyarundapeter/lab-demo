import * as React from 'react'
import { TopBarNav } from '../nav.js'

/**
 * PublicCanvasLayout — the public counterpart of BuilderLayout / ConversationalLayout.
 *
 * Anatomy (A3 "full-bleed / canvas-owned" per archetype-reference-spec.md §3):
 *   TopBarNav (kept)  →  full-bleed, overflow-hidden canvas (feature-owned)
 *
 * Chrome decisions:
 * - TopBarNav is KEPT. A public full-bleed tool still needs a way back to the rest
 *   of the site — without it a user landing on an embedded canvas is stranded with
 *   no wayfinding. This mirrors the "no page header, but shell chrome stays" shape
 *   BuilderLayout/ConversationalLayout use for their authenticated TransactionShell
 *   chrome (nav/menu stays; PageHeader does not).
 * - No PageHeader/breadcrumb/title — the A3 rule is "no page header"; the feature
 *   owns all in-canvas chrome (its own title, controls, etc. if it needs any).
 * - No LandingShell slot stack (hero/features/proof/cta/footer) — those are a fixed
 *   vertical marketing composition; a canvas is a single full-bleed surface, so this
 *   layout renders TopBarNav directly rather than composing LandingShell.
 * - No footer — full-bleed tools (configurators, calculators) are meant to be used
 *   in place; a footer would reintroduce scroll/chrome the feature doesn't own.
 *
 * Structural ReactNode seam (ADR-0035): the layout exposes ONLY `children`.
 */
export function PublicCanvasLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen w-full flex-col overflow-hidden bg-[var(--color-background)]">
      <TopBarNav />
      <div className="flex-1 min-h-0 overflow-hidden">
        {children}
      </div>
    </div>
  )
}
