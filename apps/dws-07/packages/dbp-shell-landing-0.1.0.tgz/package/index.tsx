import * as React from "react";
import { SlotFrame, ShortcutProvider } from "@dbp/ui";
import { TopBarNav } from "./nav.js";
import type { SlotName } from "./slots.js";

/**
 * Render a named slot's content, or NOTHING when it is unfilled.
 *
 * Unfilled optional slots must not surface the dashed `slot:<name>` dev
 * placeholder at runtime (see commit fe92b7c precedent + UI audit). SlotFrame
 * is reserved for Storybook stories that pass `isEmpty`/placeholders explicitly.
 */
function Slot({ name, children }: { name: SlotName; children?: React.ReactNode }) {
  if (children == null) return null;
  return <SlotFrame slotName={name}>{children}</SlotFrame>;
}

interface NavConfig {
  /** Logo area — arbitrary ReactNode. Takes precedence over code/name when provided. */
  logo?: React.ReactNode;
  /** Solution code rendered bold-primary (e.g. "DXP.01A"). */
  code?: string;
  /** Solution name rendered muted after the code (e.g. "Digital Channels Web"). */
  name?: string;
  /** Navigation links — data-driven; shape validated in slots.ts NavLinkSchema */
  links?: Array<{ label: string; href: string }>;
  /** Action items at the trailing end of the top bar */
  actions?: Array<{ label: string; href: string }>;
}

interface LandingShellProps {
  /**
   * Slot content. Slot names: hero | features | proof | cta | footer.
   * Unfilled slots render nothing at runtime — no dashed dev placeholder and no
   * empty padded section band. Storybook stories pass placeholders explicitly.
   */
  slots?: Partial<Record<SlotName, React.ReactNode>>;
  /** Top-bar navigation configuration */
  nav?: NavConfig;
}

/**
 * SH.00 — Landing Shell (Stage 0 Discover).
 *
 * Fixed structure (never theme-overridable):
 *   top bar (h: --shell-header-h = 44px, sticky)
 *   → hero section
 *   → features section
 *   → proof section
 *   → cta section
 *   → footer
 *
 * Theme tokens (--color-*, --font-*, --radius, --density) cascade in from the
 * solution root and affect appearance only — structure is invariant.
 *
 * Phase 3: slots are empty frames. Solutions compose PS.DATA and PS.AI into
 * the slots at the solution layer; the shell never fetches data directly.
 */
export default function LandingShell({ slots = {}, nav = {} }: LandingShellProps) {
  return (
    <ShortcutProvider>
    <div className="flex min-h-screen flex-col bg-[var(--color-background)] text-[var(--color-text)]">
      {/* Top bar — fixed structural height via CSS var */}
      <TopBarNav
        {...(nav.logo !== undefined ? { logo: nav.logo } : {})}
        {...(nav.code !== undefined ? { code: nav.code } : {})}
        {...(nav.name !== undefined ? { name: nav.name } : {})}
        {...(nav.links !== undefined && { links: nav.links })}
        {...(nav.actions !== undefined && { actions: nav.actions })}
      />

      {/* Main content — full-bleed stacked sections. Each landing component
          (LandingHero, LandingFeatures, etc.) owns its own <section> tag,
          background, vertical padding, and max-w container. The shell must NOT
          add an extra container div or the components get double-padded. */}
      <main id="main-content" className="flex flex-1 flex-col">
        {slots.hero != null && <Slot name="hero">{slots.hero}</Slot>}
        {slots.features != null && <Slot name="features">{slots.features}</Slot>}
        {slots.proof != null && <Slot name="proof">{slots.proof}</Slot>}
        {slots.cta != null && <Slot name="cta">{slots.cta}</Slot>}
      </main>

      {/* footer — outside <main> per landmark semantics.
          Full-bleed: no max-w constraint here so injected footer components
          can own their own background (e.g. white or navy) across the full
          viewport width, matching CORPWEB Footer which self-manages its
          container and padding internally. */}
      {slots.footer != null && (
        <footer aria-label="Site footer" className="w-full">
          <Slot name="footer">{slots.footer}</Slot>
        </footer>
      )}
    </div>
    </ShortcutProvider>
  );
}
