import { z } from "zod";

/**
 * Canonical slot names for SH.00 Landing Shell.
 * Order here is the visual render order (top-to-bottom after the nav bar).
 */
export const SHELL_SLOTS = ["hero", "features", "proof", "cta", "footer"] as const;

export type SlotName = (typeof SHELL_SLOTS)[number];

/** Metadata for each slot — consumed by tooling and documentation. */
export interface SlotMeta {
  /** Slot identifier */
  name: SlotName;
  /** Human-readable purpose */
  purpose: string;
  /** Render order (0-based, after the top bar) */
  order: number;
  /** Which PS.* services typically supply content here at solution time */
  typicallyComposedBy: ReadonlyArray<string>;
}

export const SLOT_METADATA: Record<SlotName, SlotMeta> = {
  hero: {
    name: "hero",
    purpose: "Primary value-proposition section — headline, subtext, primary CTA",
    order: 0,
    typicallyComposedBy: ["PS.DATA", "PS.AI"],
  },
  features: {
    name: "features",
    purpose: "Feature grid or benefit list",
    order: 1,
    typicallyComposedBy: ["PS.DATA"],
  },
  proof: {
    name: "proof",
    purpose: "Social proof — testimonials, logos, stats",
    order: 2,
    typicallyComposedBy: ["PS.DATA"],
  },
  cta: {
    name: "cta",
    purpose: "Secondary call-to-action band",
    order: 3,
    typicallyComposedBy: ["PS.DATA", "PS.AI"],
  },
  footer: {
    name: "footer",
    purpose: "Site footer — links, copyright, legal",
    order: 4,
    typicallyComposedBy: ["PS.DATA"],
  },
} as const;

/** Zod schema for the nav links array — used as the data-driven nav config */
export const NavLinkSchema = z.object({
  label: z.string().min(1),
  href: z.string().min(1),
});
export type NavLink = z.infer<typeof NavLinkSchema>;

/** Zod schema for the full nav config object */
export const NavConfigSchema = z.object({
  /** Logo node is ReactNode, passed as a prop — not Zod-validated */
  links: z.array(NavLinkSchema).default([]),
  /** Action items label + href for nav CTA buttons */
  actions: z.array(NavLinkSchema).default([]),
});
export type NavConfig = z.infer<typeof NavConfigSchema>;
