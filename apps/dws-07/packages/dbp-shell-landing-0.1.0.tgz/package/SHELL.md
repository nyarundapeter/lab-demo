---
shell_id: SH.00
name: Landing Shell
journey_stage: 0
journey_role: Discover
fixed_dims:
  header_h: var(--shell-header-h)   # 44px — structural, never theme-overridable
slots: [hero, features, proof, cta, footer]
composes: [PS.DATA, PS.AI]
---

# SH.00 — Landing Shell

Public marketing surface. Fixed vertical stack with top-bar navigation.

## Structure

```
┌─────────────────────────────┐
│  Top bar  [h: --shell-header-h = 44px]  z-sticky
├─────────────────────────────┤
│  hero     [full-width section]
├─────────────────────────────┤
│  features [full-width section]
├─────────────────────────────┤
│  proof    [full-width section]
├─────────────────────────────┤
│  cta      [full-width section]
├─────────────────────────────┤
│  footer   [full-width section]
└─────────────────────────────┘
```

## Breakpoints

| Breakpoint | Behaviour |
|---|---|
| `< 768px` (below `md`) | Single column; nav links collapse into dropdown-menu under a menu button |
| `768px – 1023px` (md–lg) | Two-column feature grid; full nav visible |
| `≥ 1024px` (lg+) | Content constrained to `--shell-content-max-w` (1440px) with `--shell-gutter` (24px) side padding |

## Slots

| Name | Purpose |
|---|---|
| `hero` | Primary value-prop section — typically a headline, subtext, and primary CTA |
| `features` | Feature grid or benefit list |
| `proof` | Social proof — testimonials, logos, stats |
| `cta` | Secondary call-to-action band |
| `footer` | Site footer — links, copyright, legal |

All slots render `<SlotFrame>` when empty (visible in Storybook empty-shell story).

## PS.* Composition Contract

Phase 3 ships slots as empty frames. At solution time:

- **PS.DATA** — supplies content fragments into `hero`, `features`, and `proof` via the client SDK
  (`useContent(slotName)` hook pattern). The shell never fetches directly.
- **PS.AI** (optional) — personalization overlay for `hero` and `cta` slots via `usePersonalize`.
  When absent the slots render static content without modification.

The shell itself contains zero data-fetching logic. Solutions compose these services in the
feature/page layer that mounts into the shell slots.

## Theme

Only the 9 tokens affect appearance (`--color-*`, `--font-*`, `--radius`, `--density`).
Structure — header height, section stacking, content max-width, gutter — is identical across
all theme swaps.
