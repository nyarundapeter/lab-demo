# @dbp/ps-notif

A notification platform service covering in-app notifications and transactional email. The client SDK exposes `getNotifications`, `send`, `markRead`/`markAllRead`, and `sendEmail`, plus TanStack Query hooks (`useNotifications`, `useSend`, `useSendEmail`). The server side (`server/transport.ts`, `server/adapters.ts`) provides an env-selectable email transport (see `getEmailTransport`) alongside in-app notification storage.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `client/index.ts` (dist: `dist/client/index.js`) |
| `./server` | `server/index.ts` (dist: `dist/server/index.js`) |

`publishConfig.exports` points both subpaths at the built `dist/` output (with `.d.ts` types) instead of the `.ts` sources used in the workspace.

## Config schema
N/A — no standalone Zod config-schema file; client configuration is a plain `NotifClientConfig` object set via `configureNotifClient` (`client/config.ts`); email transport is configured via environment variables read in `server/transport.ts`.

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` wires `PS.NOTIF` into every scaffolded solution's `/api/platform/notif/[[...path]]` route and calls `configureNotifClient` from `@dbp/ps-notif/client`; also adds `@dbp/ps-notif` as a dependency whenever a solution has a contact form (`hasContact`), since the generated contact API route imports `getEmailTransport` from `@dbp/ps-notif/server`. Bespoke import — `apps/dxp-01a/app/api/platform/notify/contact/route.ts` imports `getEmailTransport` directly for its contact-form handler.

## Shipping
Inside this monorepo, apps resolve `@dbp/ps-notif` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed `.tgz` tarball, resolved through `.pnpmfile.cjs` rewriting the `@dbp/ps-notif` dependency to `file:packages/dbp-ps-notif-<version>.tgz`. See `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
