# @dbp/config

Shared build tooling configuration for the DBP Blueprint monorepo: ESLint flat configs (base + Next.js), a base `tsconfig.json`, and a Tailwind preset. Every `@dbp/*` package and every generated solution app extends these instead of hand-rolling its own lint/TS/Tailwind setup, so the import-boundary rules (Layer 06/07 split) and design-token wiring stay consistent factory-wide.

**Tier:** shared

## Exports
| Export | Path |
|---|---|
| `./eslint` | `./eslint/index.mjs` |
| `./eslint/nextjs` | `./eslint/nextjs.mjs` |
| `./tsconfig/base.json` | `./tsconfig/base.json` |
| `./tailwind` | `./tailwind/preset.mjs` |

No `publishConfig.exports` override — the same paths ship to the registry as raw source (this package has no build step; `.mjs`/`.json` files are consumed directly).

## Config schema
N/A — no config schema in this package (it exports build tooling config, not a Zod-validated runtime schema).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` writes `"@dbp/config": "workspace:*"` into every generated solution's `package.json` devDependencies, and every other `@dbp/*` package in this monorepo depends on it as a devDependency for its own lint/TS setup.

## Shipping
Workspace package during monorepo development (`workspace:*`). For standalone repos, it ships as a committed tarball (`file:packages/dbp-config-0.1.0.tgz`) resolved via `.pnpmfile.cjs` — see `docs/08-contributing/package-distribution.md` for the full tarball/registry model.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
