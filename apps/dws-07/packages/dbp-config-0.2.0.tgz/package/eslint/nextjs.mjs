import { FlatCompat } from "@eslint/eslintrc";
import tseslint from "typescript-eslint";

const compat = new FlatCompat({ baseDirectory: import.meta.dirname });

/**
 * Next.js-specific lint rules for app-level configs.
 * Layer AFTER @dbp/config/eslint so boundary rules stay intact.
 * Covers @next/next/* rules + core-web-vitals hints.
 */
export default [
  ...compat.extends("next/core-web-vitals"),
  {
    name: "dbp/nextjs/ignores",
    ignores: ["**/.next/**", "**/next-env.d.ts"],
  },
  // FlatCompat-wrapped `next/core-web-vitals` applies a non-type-aware parser to
  // all files, which makes @typescript-eslint/no-unused-vars miss type-only
  // usages (e.g. `import type { ReactNode }` used only in annotations gets
  // flagged as unused). Restore the typescript-eslint parser for TS files so the
  // app-level lint matches the type-aware root `pnpm lint`.
  {
    name: "dbp/nextjs/ts-parser-restore",
    files: ["**/*.{ts,tsx,mts,cts}"],
    languageOptions: { parser: tseslint.parser },
  },
];
