import eslintJs from "@eslint/js";
import globals from "globals";
import tseslint from "typescript-eslint";
import reactHooks from "eslint-plugin-react-hooks";
import noRawDesignValues from "./rules/no-raw-design-values.js";
import noFreeformSolutionPage from "./rules/no-freeform-solution-page.js";

const SRC = "*.{js,jsx,mjs,cjs,ts,tsx,mts,cts}";

/*
 * Import-boundary matrix from docs/TECH-DECISIONS.md §Import Boundary Rules.
 * Patterns match literal import specifiers (minimatch), so each FORBIDDEN line
 * is covered both as a workspace-package specifier and as a relative path.
 *
 * Workspace naming convention these patterns encode (binding for later phases):
 *   @dbp/ps-<service>      packages/stack/platform-services/<service>  (exports ./client, ./server)
 *   @dbp/organisms/<name>   packages/stack/app-scaffolds/features/<name> (single index export,
 *                           one subpath export per organism from the @dbp/organisms package)
 *   @dbp/shell-<name>      packages/stack/app-scaffolds/shells/<name>
 *   @dbp/ui | @dbp/contracts | @dbp/design-tokens   packages/shared/*
 */
const PS_SERVER_PATTERNS = [
  "@dbp/ps-*/server",
  "@dbp/ps-*/server/**",
  "**/platform-services/*/server",
  "**/platform-services/*/server/**",
  "**/platform-services/*/src/server",
  "**/platform-services/*/src/server/**",
];

const FEATURE_INTERNAL_PATTERNS = [
  // Block reaching PAST a public sub-export into an organism's files (3+ segments,
  // e.g. @dbp/organisms/entity-list/components/Foo, .../hooks/use-foo). The 2-segment
  // form (@dbp/organisms/<slug>/<sub>) is a DECLARED public sub-export governed by the
  // package `exports` map itself (form-builder/multi-step-form legitimately expose
  // /types, /hooks, /logic, /renderer) — only the exports map may add those, so ESLint
  // need not (and must not) block them or it forbids blessed cross-organism composition.
  "@dbp/organisms/*/*/**",
  "**/app-scaffolds/features/*/src/**",
];

const psServerViolation = (zone) => ({
  group: PS_SERVER_PATTERNS,
  message: `BOUNDARY: ${zone} must never import a platform service's server internals — wire via the client SDK (@dbp/ps-*/client).`,
});

const featureInternalViolation = {
  group: FEATURE_INTERNAL_PATTERNS,
  message:
    "BOUNDARY: a feature exposes exactly one typed contract — import the feature package root, never its internals.",
};

// API-mount seam exception — Phase 5 scaffold generator (P5).
//
// The generated Next.js app route handlers at apps/<sol>/app/api/platform/<svc>/
// are the ONLY sanctioned place in the apps/ layer that may import
// @dbp/ps-SVCNAME/server. This is the host-mount seam: each generated catch-all
// route dispatches incoming HTTP requests directly into the service's handler,
// acting as the network boundary. Every other file inside apps/ (pages,
// components, hooks, providers, middleware) is still forbidden.
//
// The narrow pattern `apps/*/app/api/platform/**` matches only the generated
// route handlers, leaving the general apps/** restriction fully intact.
//
// Evidence that the restriction still holds for all other app code:
//   FORBIDDEN: apps/__boundary-fixtures__/app-imports-ps-server.ts (must FAIL)
//   ALLOWED:   apps/__boundary-fixtures__/app/api/platform/auth/route.fixture.ts (must PASS)
export const API_MOUNT_SEAM_EXCEPTION = {
  name: "dbp/boundaries/apps-api-mount-seam",
  // Matches ONLY the generated API mount directory — not pages, hooks, components, etc.
  files: [`apps/*/app/api/platform/**/${SRC}`],
  rules: {
    // Override: ps-SVCNAME/server imports are explicitly allowed here, nowhere else in apps/.
    "no-restricted-imports": "off",
  },
};

// Instrumentation seam exception — Phase 6 DWS.04 (P6).
//
// Next.js instrumentation.ts runs at server start in the Node runtime. It is the
// designated bootstrap hook for registering entity schemas, seeding data, and
// configuring auth — concerns that must be centralised in the host process.
// It may import @dbp/ps-*/server directly.
//
// This is NARROW: only apps/*/instrumentation.ts|.node.ts match.
// All other app files (pages, components, hooks, middleware) remain forbidden.
//
// Boundary proof: scripts/check-boundaries.mjs ALLOWED fixture:
//   apps/__boundary-fixtures__/instrumentation.ts  (filename must match the seam pattern)
// FORBIDDEN fixture (proves restriction holds for non-seam app files):
//   apps/__boundary-fixtures__/page-imports-ps-server.fixture.ts
export const INSTRUMENTATION_SEAM_EXCEPTION = {
  name: "dbp/boundaries/apps-instrumentation-seam",
  files: [`apps/*/instrumentation.ts`, `apps/*/instrumentation.node.ts`],
  rules: {
    "no-restricted-imports": "off",
  },
};

// Test-only seam exception — reliability/integration tests that inject a real
// failure into a real PS.* singleton (e.g. breaking PS.AUDIT's storage adapter
// via its own configureAuditService() seam to prove a catch-and-continue trade-off
// holds at runtime) legitimately need direct @dbp/ps-*/server access — the client
// SDK has no way to break server internals on purpose. This is NARROW: only
// apps/*/tests/** match; all other app files (pages, components, hooks, the
// production route handlers themselves) remain forbidden from importing
// @dbp/ps-*/server, same as the general apps boundary.
export const APPS_TESTS_SEAM_EXCEPTION = {
  name: "dbp/boundaries/apps-tests-seam",
  files: [`apps/*/tests/**/${SRC}`],
  rules: {
    "no-restricted-imports": "off",
  },
};

// Test-only seam exception — same rationale as APPS_TESTS_SEAM_EXCEPTION above, for
// organism/feature-level tests under packages/stack/app-scaffolds/features/**/tests/**
// (e.g. notification-inbox's reliability test breaking PS.NOTIF's server singleton via
// resetNotifService()). NARROW: only feature tests/** match; non-test feature files
// remain forbidden from importing @dbp/ps-*/server, same as the general app-scaffolds
// boundary.
export const FEATURES_TESTS_SEAM_EXCEPTION = {
  name: "dbp/boundaries/app-scaffolds-features-tests-seam",
  files: [`packages/stack/app-scaffolds/features/**/tests/**/${SRC}`],
  rules: {
    "no-restricted-imports": "off",
  },
};

export const boundaryConfigs = [
  // shared/ui may import ps-*/client but NEVER ps-*/server.
  {
    name: "dbp/boundaries/shared-ui",
    files: [`packages/shared/ui/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            psServerViolation("shared/ui"),
            {
              group: ["**/apps/**", "**/app-scaffolds/**"],
              message:
                "BOUNDARY: shared/ui bindings must not import from solutions or scaffolds.",
            },
          ],
        },
      ],
    },
  },
  {
    name: "dbp/boundaries/apps",
    files: [`apps/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        { patterns: [psServerViolation("apps/*"), featureInternalViolation] },
      ],
    },
  },
  {
    name: "dbp/boundaries/app-scaffolds",
    files: [`packages/stack/app-scaffolds/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            psServerViolation("app-scaffolds/*"),
            featureInternalViolation,
            {
              group: ["**/apps/**"],
              message: "BOUNDARY: Layer 07 scaffolds never import from solutions.",
            },
          ],
        },
      ],
    },
  },
  {
    name: "dbp/boundaries/platform-services",
    files: [`packages/stack/platform-services/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["@dbp/*", "!@dbp/contracts", "!@dbp/contracts/**"],
              message:
                "BOUNDARY: platform services may import only @dbp/contracts from the workspace.",
            },
            {
              group: [
                "**/app-scaffolds/**",
                "**/apps/**",
                "**/shared/ui/**",
                "**/shared/design-tokens/**",
              ],
              message:
                "BOUNDARY: platform services may import only shared contracts — never UI, scaffolds, or solutions.",
            },
          ],
        },
      ],
    },
  },
  // Deliberate narrower override for platform-service TEST files only — placed after
  // dbp/boundaries/platform-services so it wins for overlapping files (ESLint 9 flat
  // config replaces, not merges, a same-named rule on overlapping files; see the
  // GATE.01 enforcement-hole note in docs/04-testing/quality-checklist.md for the
  // failure mode this pattern deliberately exploits on purpose here). Restates the
  // same restrictions as the block above, plus an explicit @dbp/test-kit exception —
  // a test-only shared helper (measureP95 etc.) with no production/runtime surface.
  // Production server/ code is unaffected; it never matches this narrower glob.
  {
    name: "dbp/boundaries/platform-services-tests",
    files: [`packages/stack/platform-services/**/tests/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["@dbp/*", "!@dbp/contracts", "!@dbp/contracts/**", "!@dbp/test-kit"],
              message:
                "BOUNDARY: platform-service tests may import only @dbp/contracts and @dbp/test-kit from the workspace.",
            },
            {
              group: [
                "**/app-scaffolds/**",
                "**/apps/**",
                "**/shared/ui/**",
                "**/shared/design-tokens/**",
              ],
              message:
                "BOUNDARY: platform services may import only shared contracts — never UI, scaffolds, or solutions.",
            },
          ],
        },
      ],
    },
  },
];

// ─── Design-system compliance (ARCHETYPE-REFERENCE-SPEC §2.5) ────────────────
//
// Solution code (apps/**) composes from @dbp/ui — never raw HTML form controls
// where a library component exists. Enforced via no-restricted-syntax on the JSX
// opening element. Error-level (escalated from warn 2026-07-18 — G-RAWCONTROL in
// docs/09-plans/design-ingestion-approach-2026-07-18/quality-gates-and-conformance.md,
// per docs/plans/2026-06-18-layout-shell-locking.md Task 7 — the tree was confirmed
// clean, zero violations, before flipping).
//
// SCOPE NOTE: the className-content checks the plan also calls for — no raw hex /
// rgb(), no Tailwind arbitrary spacing (`p-[13px]`) or type sizes (`text-[14px]`)
// in apps/** — cannot be expressed with core ESLint AST selectors (they match
// node shape, not string content). They need `eslint-plugin-tailwindcss` or a
// small custom rule and are deferred (see the plan). This block ships the part
// that IS cleanly enforceable today.
const rawControl = (tag, repl) => ({
  selector: `JSXOpeningElement[name.name='${tag}']`,
  message: `DESIGN SYSTEM: use <${repl}> from @dbp/ui, not a raw <${tag}>. Pages compose only from @dbp/ui + dq-* classes (ARCHETYPE-REFERENCE-SPEC §2.5).`,
});

export const designSystemConfigs = [
  {
    name: "dbp/design-system/apps-no-raw-controls",
    files: [`apps/**/${SRC}`],
    rules: {
      "no-restricted-syntax": [
        "error",
        rawControl("button", "Button"),
        rawControl("input", "Input"),
        rawControl("select", "Select"),
        rawControl("textarea", "Input/textarea (dq-textarea)"),
      ],
    },
  },
];

/**
 * DQ design-system hard rules for SOLUTION code (DWS.01 audit 1.1–1.3).
 * A factory because the file scope differs by context: the monorepo root applies
 * it to `apps/**` (via the default export below), while an emitted standalone app
 * (app at repo root — no apps/ dir, so the apps/** globs in this file never match)
 * applies it to its own `app/**`/`solution/**` trees via the generated
 * eslint.config.mjs. String literals and template literals are both matched —
 * unlike the raw-hex checks in the SCOPE NOTE above, these fixed class names ARE
 * expressible as esquery attribute-regex selectors.
 *
 *   1. Orange (--color-secondary / #FB5535) is an accent, never a background fill.
 *   2. Raw Tailwind grays (bg|text|border-gray-N) bypass the token system.
 *   3. Fonts come from @dbp/design-tokens — next/font/google is banned.
 *
 * @param {string[]} files  flat-config file globs the rules apply to
 */
export function dqDesignRules(files) {
  const ORANGE_FILL = String.raw`bg-\[var\(--color-secondary\)\]|bg-\[#[Ff][Bb]5535`;
  const RAW_GRAY = String.raw`(?:^|["'\s])(?:bg|text|border)-gray-[0-9]`;
  const restricted = (pattern, message) => [
    { selector: `Literal[value=/${pattern}/]`, message },
    { selector: `TemplateElement[value.raw=/${pattern}/]`, message },
  ];
  return [
    {
      name: "dbp/design-system/dq-token-rules",
      files,
      ignores: ["**/*.stories.tsx", "**/*.test.ts", "**/*.test.tsx"],
      rules: {
        "no-restricted-syntax": [
          "error",
          ...restricted(
            ORANGE_FILL,
            "DQ design system: orange (--color-secondary) is an accent colour, never a background fill — use --color-primary for filled CTAs.",
          ),
          ...restricted(
            RAW_GRAY,
            "DQ design system: raw Tailwind grays bypass the token system — use the --color-* tokens (e.g. border-[var(--color-border-subtle)], text-[var(--color-text-muted)]).",
          ),
        ],
        "no-restricted-imports": [
          "error",
          {
            paths: [
              {
                name: "next/font/google",
                message: "Fonts ship via @dbp/design-tokens only — never per-app Google Fonts.",
              },
            ],
          },
        ],
      },
    },
  ];
}

/**
 * G-TOKEN (raw hex) + G-SCALE (arbitrary Tailwind px) detection — the custom-rule half of the
 * SCOPE NOTE above `dqDesignRules()` that core AST selectors can't express. See
 * docs/09-plans/design-ingestion-approach-2026-07-18/quality-gates-and-conformance.md §2, §5.
 *
 * This factory ships the G-SCALE (arbitrary-px) check at `warn` for the non-blocking
 * `pnpm lint:design` report (packages/config/eslint/design.mjs). arbitrary-px stays warn-only
 * permanently — verbatim reference ports (e.g. packages/shared/ui/src/components/
 * catalog-card.tsx's text-[9.5px]) intentionally use exact pixel values to match a design
 * reference pixel-for-pixel, so it is never promoted to error.
 *
 * checkRawHex is OFF here (moved to `error` in the blocking default export via
 * rawHexErrorConfig() below) — design.mjs still surfaces raw-hex findings in its report
 * because it spreads the full blocking default export (`...dbpConfig`) ahead of this factory,
 * so rawHexErrorConfig()'s error-level check runs there too. Do not re-enable checkRawHex
 * here — that would register the same rule twice under two different severities/plugin keys
 * for the same files, which is redundant now that rawHexErrorConfig() covers it.
 *
 * @param {string[]} files  flat-config file globs the rule applies to
 */
export function rawDesignValueConfigs(files) {
  return [
    {
      name: "dbp/design-system/no-raw-design-values",
      files,
      ignores: ["**/*.stories.tsx", "**/*.test.ts", "**/*.test.tsx"],
      plugins: { "dbp-local": { rules: { "no-raw-design-values": noRawDesignValues } } },
      rules: {
        "dbp-local/no-raw-design-values": ["warn", { checkRawHex: false, checkArbitraryPx: true }],
      },
    },
  ];
}

/**
 * G-TOKEN (raw hex) blocking gate — the error-level counterpart to rawDesignValueConfigs()
 * above. Backlog D6 cleaned every apps/dbp + organism raw-hex literal (see
 * docs/09-plans/design-ingestion-approach-2026-07-18/quality-gates-and-conformance.md §5) and
 * flipped this check from report-only to enforced. checkArbitraryPx stays OFF here — that
 * check remains a permanent warn-only exception (see rawDesignValueConfigs()'s doc comment)
 * and must not be promoted to error.
 *
 * Part of the blocking default flat-config (see the default export below) — `pnpm lint` runs
 * `--max-warnings 0`, so this is `error`, not `warn`.
 *
 * @param {string[]} files  flat-config file globs the rule applies to
 */
export function rawHexErrorConfig(files) {
  return [
    {
      name: "dbp/design-system/no-raw-design-values-hex-blocking",
      files,
      ignores: ["**/*.stories.tsx", "**/*.test.ts", "**/*.test.tsx"],
      // Distinct plugin key from rawDesignValueConfigs()'s "dbp-local" — flat config
      // rejects two configs redefining the same plugin key with different object
      // identities, and design.mjs spreads both this default export AND
      // rawDesignValueConfigs() together, so they cannot share a key.
      plugins: { "dbp-local-hex": { rules: { "no-raw-design-values": noRawDesignValues } } },
      rules: {
        "dbp-local-hex/no-raw-design-values": ["error", { checkRawHex: true, checkArbitraryPx: false }],
      },
    },
  ];
}

// ─── G-SEAM/P2: solution/pages/** composition-only shape (quality-gates-and-conformance.md §2 P2, §4) ──
//
// Non-blocking detection counterpart to the P1 generator constraint on the `pageComponent`
// create-if-missing stub (scaffold-solution.mjs). Ships only in the `pnpm lint:design` report
// (design.mjs) — same posture as rawDesignValueConfigs() above, NOT part of the default export
// consumed by `pnpm lint` (--max-warnings 0 would fail on any warn-level finding here).
//
// @param {string[]} files  flat-config file globs the rule applies to
export function noFreeformSolutionPageConfigs(files) {
  return [
    {
      name: "dbp/design-system/no-freeform-solution-page",
      files,
      ignores: ["**/__tests__/**"],
      plugins: { "dbp-local-seam": { rules: { "no-freeform-solution-page": noFreeformSolutionPage } } },
      rules: {
        "dbp-local-seam/no-freeform-solution-page": "warn",
      },
    },
  ];
}

// ─── File-size ratchet (Generated Control Slice item #5, spec-generated-control-slice-2026-07-11) ──
//
// Ported verbatim from DWS-01's hand-rolled eslint.config.mjs (lines 27-31) so the
// rule ships as a factory default instead of being re-invented per repo. warn-level,
// matching DWS-01's own posture — see the spec's H15 for the ratchet-family framing.
// A factory (like dqDesignRules) because the file scope differs by context: the
// monorepo root applies it to apps/** (via the default export below), while an
// emitted standalone app (no apps/ dir) applies it to its own app/**/solution/**
// trees via the generated eslint.config.mjs.
//
// @param {string[]} files  flat-config file globs the rule applies to
export function maxLinesConfig(files) {
  return [
    {
      name: "dbp/quality/max-lines",
      files,
      rules: {
        "max-lines": ["warn", { max: 400, skipBlankLines: true, skipComments: true }],
      },
    },
  ];
}

export default tseslint.config(
  {
    name: "dbp/ignores",
    ignores: [
      "**/node_modules/**",
      "**/.turbo/**",
      "**/dist/**",
      "**/.next/**",
      "**/next-env.d.ts",
      "**/coverage/**",
      "**/__boundary-fixtures__/**",
      "docs/**",
      "workspace/**",
      "storybook-static/**",
      // Legacy apps dropped from the pnpm workspace by the U4 restructure (2026-07-18):
      // out of the active workspace, regenerated fresh at v1.5. Kept on disk but not
      // linted — their stale @dbp/organism-* imports + pre-restructure code are not the
      // current baseline. `dbp` is the sole active showcase app. See deferred-backlog D2.
      "apps/dia-03/**",
      "apps/dws-01/**",
      "apps/dws-03/**",
      "apps/dxp-01a/**",
      "apps/sdo-01/**",
      "apps/sdo/**",
      "apps/wfd-01/**",
    ],
  },
  eslintJs.configs.recommended,
  tseslint.configs.recommended,
  {
    name: "dbp/language-options",
    languageOptions: {
      globals: { ...globals.node, ...globals.browser },
    },
  },
  {
    name: "dbp/react-hooks",
    plugins: { "react-hooks": reactHooks },
    rules: {
      "react-hooks/exhaustive-deps": "warn",
    },
  },
  {
    // Honour the `_`-prefix convention for intentionally-unused bindings — e.g.
    // placeholder params (`_input`) and destructure-omit (`const { x: _omitted, ...rest }`).
    name: "dbp/unused-vars",
    rules: {
      "@typescript-eslint/no-unused-vars": [
        "error",
        {
          argsIgnorePattern: "^_",
          varsIgnorePattern: "^_",
          caughtErrorsIgnorePattern: "^_",
          destructuredArrayIgnorePattern: "^_",
        },
      ],
    },
  },
  ...boundaryConfigs,
  ...designSystemConfigs,
  // DQ token hard rules for solution code in the monorepo (apps/**). Standalone
  // apps get the same rules scoped to their own trees via the emitted config.
  ...dqDesignRules([`apps/**/${SRC}`]),
  // G-SCALE (arbitrary px) stays OUT of the blocking default — `pnpm lint` runs
  // `--max-warnings 0`, and arbitrary-px is a permanent warn-only exception (see
  // rawDesignValueConfigs() above). It ships only via the non-blocking `pnpm lint:design`
  // report (packages/config/eslint/design.mjs). Do not re-add rawDesignValueConfigs(...) here.
  // G-TOKEN (raw hex) IS part of the blocking default (backlog D6) — every apps/dbp +
  // organism raw-hex literal has been cleaned, so this is now enforced at error.
  ...rawHexErrorConfig([
    `apps/dbp/**/${SRC}`,
    `packages/stack/app-scaffolds/features/**/${SRC}`,
  ]),
  // File-size ratchet for HAND-AUTHORED solution code only (apps/*/solution/**,
  // instrumentation). Deliberately excludes apps/*/app/** — per ADR-0050
  // (docs/05-decisions/adr-0050-generated-apps-version-control-boundary.md),
  // app/** is generator-owned chrome/pages/route config, regenerated verbatim by
  // `scaffold-solution.mjs --force` on every regen. A human can neither fix a
  // max-lines warning there (next regen reverts it) nor is the file meant to be
  // edited (see the "Generated by scaffold-solution — do not edit" header the
  // generator stamps on every emitted file). Ratcheting solution/** still holds
  // hand-authored code (entities, workflows, tests) to the same bar as the rest
  // of the repo. Standalone apps get the equivalent scope via the emitted config.
  ...maxLinesConfig([`apps/*/solution/**/${SRC}`, `apps/*/instrumentation.ts`, `apps/*/instrumentation.node.ts`]),
  // The API-mount seam exception must come AFTER the general apps boundary so
  // it overrides for the narrow api/platform path while leaving the general rule intact.
  API_MOUNT_SEAM_EXCEPTION,
  // The instrumentation seam exception must also come after the general apps boundary.
  INSTRUMENTATION_SEAM_EXCEPTION,
  // The apps-tests seam exception must also come after the general apps boundary.
  APPS_TESTS_SEAM_EXCEPTION,
  // The features-tests seam exception must come after the general app-scaffolds boundary.
  FEATURES_TESTS_SEAM_EXCEPTION,
);
