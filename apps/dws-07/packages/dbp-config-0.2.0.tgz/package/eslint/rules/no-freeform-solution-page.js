/**
 * Custom ESLint rule — G-SEAM/P2 (quality-gates-and-conformance.md §2 P2, §4 check 2).
 *
 * Detection counterpart to the P1 generator constraint (scaffold-solution.mjs's
 * `pageComponent` create-if-missing stub): flags a `solution/pages/**` file that has grown
 * past a composition-only shape — the "hand-rolled bad reimplementation of a registered
 * organism" leak this whole gate exists to catch. Non-blocking (warn-only, wired into the
 * `pnpm lint:design` report via design.mjs) — `solution/pages/**` is intentionally scoped
 * out of the default blocking config.
 *
 * Three independent checks, each its own messageId:
 *   - G-SEAM-lines:     more than `maxLines` (default 40) non-import/comment/blank lines.
 *   - G-SEAM-shape:     more than one JSX element that is neither an HTML primitive
 *                       (lowercase tag name) nor imported from @dbp/ui or @dbp/organisms/* —
 *                       the "hand-rolled" signal. @dbp/ui and @dbp/organisms elements are
 *                       unlimited/allowed.
 *   - G-SEAM-nocompose: no @dbp/organisms/* import at all AND exceeds the line ceiling —
 *                       a from-scratch reimplementation with nothing composed.
 */

const DEFAULT_MAX_LINES = 40;

function rootJsxName(nameNode) {
  let cur = nameNode;
  while (cur.type === "JSXMemberExpression") cur = cur.object;
  if (cur.type === "JSXIdentifier") return cur.name;
  if (cur.type === "JSXNamespacedName") return cur.namespace.name;
  return null;
}

function isHtmlPrimitiveName(name) {
  return /^[a-z]/.test(name);
}

export default {
  meta: {
    type: "suggestion",
    docs: {
      description:
        "G-SEAM: solution/pages/** pageComponent stubs must stay composition-only — compose a " +
        "registered @dbp/organisms/* organism instead of hand-rolling bespoke JSX.",
    },
    schema: [
      {
        type: "object",
        properties: {
          maxLines: { type: "integer", minimum: 1 },
        },
        additionalProperties: false,
      },
    ],
    messages: {
      "G-SEAM-lines":
        "G-SEAM: {{count}} non-import/comment/blank lines exceeds the composition-only ceiling " +
        "of {{max}} — solution pages should wire props to a registered organism, not grow " +
        "bespoke JSX (docs/09-plans/design-ingestion-approach-2026-07-18/quality-gates-and-conformance.md).",
      "G-SEAM-shape":
        "G-SEAM: {{count}} JSX element(s) are neither an HTML primitive nor imported from " +
        "@dbp/ui or @dbp/organisms/* — more than one is the 'hand-rolled reimplementation' " +
        "signal. Compose a registered organism instead.",
      "G-SEAM-nocompose":
        "G-SEAM: no @dbp/organisms/* import and {{count}} lines exceeds the {{max}}-line " +
        "ceiling — looks like a from-scratch reimplementation instead of composing a " +
        "registered organism.",
    },
  },
  create(context) {
    const options = context.options[0] || {};
    const maxLines = options.maxLines ?? DEFAULT_MAX_LINES;
    const sourceCode = context.sourceCode ?? context.getSourceCode();

    let hasOrganismImport = false;
    const localImportSource = new Map(); // local binding name -> import source
    const flaggedJsxNodes = [];

    return {
      ImportDeclaration(node) {
        const source = node.source.value;
        if (typeof source === "string" && source.startsWith("@dbp/organisms/")) {
          hasOrganismImport = true;
        }
        for (const spec of node.specifiers) {
          if (
            spec.type === "ImportDefaultSpecifier" ||
            spec.type === "ImportSpecifier" ||
            spec.type === "ImportNamespaceSpecifier"
          ) {
            localImportSource.set(spec.local.name, source);
          }
        }
      },

      JSXOpeningElement(node) {
        const name = rootJsxName(node.name);
        if (!name || isHtmlPrimitiveName(name)) return;
        const source = localImportSource.get(name);
        const isAllowed =
          typeof source === "string" && (source === "@dbp/ui" || source.startsWith("@dbp/ui/") || source.startsWith("@dbp/organisms/"));
        if (!isAllowed) flaggedJsxNodes.push(node);
      },

      "Program:exit"(program) {
        const commentLines = new Set();
        for (const comment of sourceCode.getAllComments()) {
          for (let l = comment.loc.start.line; l <= comment.loc.end.line; l++) commentLines.add(l);
        }
        const importLines = new Set();
        for (const stmt of program.body) {
          if (stmt.type === "ImportDeclaration") {
            for (let l = stmt.loc.start.line; l <= stmt.loc.end.line; l++) importLines.add(l);
          }
        }
        let codeLineCount = 0;
        for (let i = 0; i < sourceCode.lines.length; i++) {
          const lineNo = i + 1;
          if (sourceCode.lines[i].trim() === "") continue;
          if (commentLines.has(lineNo)) continue;
          if (importLines.has(lineNo)) continue;
          codeLineCount++;
        }

        if (codeLineCount > maxLines) {
          context.report({
            node: program,
            messageId: "G-SEAM-lines",
            data: { count: String(codeLineCount), max: String(maxLines) },
          });
        }
        if (!hasOrganismImport && codeLineCount > maxLines) {
          context.report({
            node: program,
            messageId: "G-SEAM-nocompose",
            data: { count: String(codeLineCount), max: String(maxLines) },
          });
        }
        if (flaggedJsxNodes.length > 1) {
          context.report({
            node: flaggedJsxNodes[0],
            messageId: "G-SEAM-shape",
            data: { count: String(flaggedJsxNodes.length) },
          });
        }
      },
    };
  },
};
