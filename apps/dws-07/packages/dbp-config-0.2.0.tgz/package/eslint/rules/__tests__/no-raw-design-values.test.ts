import { RuleTester } from "eslint";
import tsParser from "typescript-eslint";
import { describe, it } from "vitest";
import rule from "../no-raw-design-values.js";

const ruleTester = new RuleTester({
  languageOptions: {
    parser: tsParser.parser,
    parserOptions: {
      ecmaFeatures: { jsx: true },
      sourceType: "module",
    },
  },
});

describe("no-raw-design-values", () => {
  it("passes RuleTester valid/invalid cases", () => {
    ruleTester.run("no-raw-design-values", rule, {
      valid: [
        // Token-backed arbitrary value — not a raw hex literal.
        { code: `const x = <div className="bg-[var(--color-primary)]" />;` },
        // hrefs are not className/class/style/clsx contexts.
        { code: `const x = <a href="#anchor">link</a>;` },
        // Hex-looking string outside a className/class/style/clsx context is ignored.
        { code: `const id = "#ff0000";` },
        // Arbitrary px syntax outside a className/clsx context is ignored.
        { code: `const style = "text-[14px]";` },
        // checkRawHex disabled via options.
        {
          code: `const x = <div className="bg-[#ff0000]" />;`,
          options: [{ checkRawHex: false }],
        },
        // checkArbitraryPx disabled via options.
        {
          code: `const x = <div className="text-[14px]" />;`,
          options: [{ checkArbitraryPx: false }],
        },
      ],
      invalid: [
        {
          code: `const x = <div className="bg-[#ff0000]" />;`,
          errors: [{ messageId: "rawHexColor" }],
        },
        {
          code: `const x = <div className="text-[14px]" />;`,
          errors: [{ messageId: "arbitraryPxValue" }],
        },
        {
          code: `const x = cn("bg-[#abc123]");`,
          errors: [{ messageId: "rawHexColor" }],
        },
      ],
    });
  });
});
