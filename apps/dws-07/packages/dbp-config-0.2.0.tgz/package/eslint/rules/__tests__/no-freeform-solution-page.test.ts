import { RuleTester } from "eslint";
import tsParser from "typescript-eslint";
import { describe, it } from "vitest";
import rule from "../no-freeform-solution-page.js";

const ruleTester = new RuleTester({
  languageOptions: {
    parser: tsParser.parser,
    parserOptions: {
      ecmaFeatures: { jsx: true },
      sourceType: "module",
    },
  },
});

function linesOfCode(n: number, filler: string): string {
  return Array.from({ length: n }, () => filler).join("\n");
}

describe("no-freeform-solution-page", () => {
  it("passes RuleTester valid/invalid cases", () => {
    ruleTester.run("no-freeform-solution-page", rule, {
      valid: [
        // Composition-only stub, well under the line ceiling, composing a registered organism.
        {
          code: `
import { WidgetOrganism } from "@dbp/organisms/widget";

export default function Page(props) {
  return <WidgetOrganism {...props} />;
}
`,
        },
      ],
      invalid: [
        // Over the 40-line ceiling — G-SEAM-lines (and G-SEAM-nocompose, since no organism import).
        {
          code: `
import { WidgetOrganism } from "@dbp/organisms/widget";

export default function Page(props) {
  return (
    <WidgetOrganism {...props}>
${linesOfCode(45, "      <span>filler</span>")}
    </WidgetOrganism>
  );
}
`,
          errors: [{ messageId: "G-SEAM-lines" }],
        },
        // More than one local custom element not from @dbp/ui or @dbp/organisms/* — G-SEAM-shape.
        {
          code: `
import { CustomOne } from "./custom-one";
import { CustomTwo } from "./custom-two";

export default function Page() {
  return (
    <div>
      <CustomOne />
      <CustomTwo />
    </div>
  );
}
`,
          errors: [{ messageId: "G-SEAM-shape" }],
        },
        // No @dbp/organisms/* import at all, over the line ceiling — G-SEAM-nocompose (+ G-SEAM-lines).
        {
          code: `
export default function Page() {
  return (
    <div>
${linesOfCode(45, "      <span>filler</span>")}
    </div>
  );
}
`,
          errors: [{ messageId: "G-SEAM-lines" }, { messageId: "G-SEAM-nocompose" }],
        },
      ],
    });
  });
});
