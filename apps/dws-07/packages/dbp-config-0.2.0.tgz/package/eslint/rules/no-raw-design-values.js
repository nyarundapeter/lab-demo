/**
 * Custom ESLint rule — G-TOKEN (raw-hex) + G-SCALE (arbitrary Tailwind px values).
 *
 * Ported from the gap named in dqDesignRules()'s SCOPE NOTE (packages/config/eslint/index.mjs
 * ~line 232): raw-hex / rgb() / arbitrary spacing / arbitrary type sizes "cannot be expressed
 * with core ESLint AST selectors" because those match node *shape*, not string *content*. This
 * rule visits string Literal + TemplateElement nodes directly and regex-scans their content,
 * restricted to className/class/style/clsx-like contexts to keep false positives low.
 *
 * Two checks, one rule, independently toggleable via options (both default on):
 *   - checkRawHex:      #rgb / #rrggbb / #rrggbbaa inside a className/class/clsx/style context.
 *   - checkArbitraryPx:  Tailwind arbitrary-value px syntax, e.g. text-[14px], p-[13px], inside
 *                        a className/class/clsx context.
 *
 * Deliberately conservative: strings that are not inside one of the recognised contexts (JSX
 * className/class attribute, a clsx/cn/classNames/cva call, or a JSX style attribute) are never
 * flagged — this keeps arbitrary data/config strings, hrefs, ids, etc. out of scope.
 */

const HEX_COLOR_PATTERN = /#[0-9a-fA-F]{3,8}\b/;
const ARBITRARY_PX_PATTERN = /\[[0-9.]+px\]/;

const CLASS_LIKE_CALLEES = new Set(["cn", "clsx", "classNames", "classnames", "cva"]);

function getAncestors(node) {
  const chain = [];
  let cur = node.parent;
  while (cur) {
    chain.push(cur);
    cur = cur.parent;
  }
  return chain;
}

function isClassNameAttribute(ancestors) {
  return ancestors.some(
    (n) =>
      n.type === "JSXAttribute" &&
      n.name &&
      n.name.type === "JSXIdentifier" &&
      (n.name.name === "className" || n.name.name === "class"),
  );
}

function isStyleAttribute(ancestors) {
  return ancestors.some(
    (n) => n.type === "JSXAttribute" && n.name && n.name.type === "JSXIdentifier" && n.name.name === "style",
  );
}

function isClassNameCall(ancestors) {
  return ancestors.some(
    (n) => n.type === "CallExpression" && n.callee && n.callee.type === "Identifier" && CLASS_LIKE_CALLEES.has(n.callee.name),
  );
}

/** Context in which raw-hex is checked: className/class attrs, clsx-like calls, or style attrs. */
function isHexContext(ancestors) {
  return isClassNameAttribute(ancestors) || isClassNameCall(ancestors) || isStyleAttribute(ancestors);
}

/** Context in which arbitrary-px is checked: Tailwind class strings only (not style objects,
 * which use plain CSS px values with no bracket syntax and would never match anyway). */
function isTailwindClassContext(ancestors) {
  return isClassNameAttribute(ancestors) || isClassNameCall(ancestors);
}

export default {
  meta: {
    type: "suggestion",
    docs: {
      description:
        "Flag raw hex colours and arbitrary Tailwind px values in className/style contexts (G-TOKEN, G-SCALE).",
    },
    schema: [
      {
        type: "object",
        properties: {
          checkRawHex: { type: "boolean" },
          checkArbitraryPx: { type: "boolean" },
        },
        additionalProperties: false,
      },
    ],
    messages: {
      rawHexColor:
        "G-TOKEN: raw hex colour '{{value}}' bypasses the token system — use a --color-* design token instead (e.g. bg-[var(--color-primary)]).",
      arbitraryPxValue:
        "G-SCALE: arbitrary pixel value '{{value}}' is off the 4px scale — use the type/spacing scale utilities instead of a bracketed px value.",
    },
  },
  create(context) {
    const options = context.options[0] || {};
    const checkRawHex = options.checkRawHex !== false;
    const checkArbitraryPx = options.checkArbitraryPx !== false;

    function checkString(node, rawText) {
      if (typeof rawText !== "string") return;
      const ancestors = getAncestors(node);

      if (checkRawHex && isHexContext(ancestors)) {
        const match = HEX_COLOR_PATTERN.exec(rawText);
        if (match) {
          context.report({ node, messageId: "rawHexColor", data: { value: match[0] } });
        }
      }

      if (checkArbitraryPx && isTailwindClassContext(ancestors)) {
        const match = ARBITRARY_PX_PATTERN.exec(rawText);
        if (match) {
          context.report({ node, messageId: "arbitraryPxValue", data: { value: match[0] } });
        }
      }
    }

    return {
      Literal(node) {
        if (typeof node.value === "string") {
          checkString(node, node.value);
        }
      },
      TemplateElement(node) {
        checkString(node, node.value && node.value.raw);
      },
    };
  },
};
