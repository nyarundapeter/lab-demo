// Non-blocking design-conformance report entrypoint — `pnpm lint:design`.
//
// Wraps the base flat-config (index.mjs) and adds the G-TOKEN (raw-hex) + G-SCALE
// (arbitrary-px) checks from rawDesignValueConfigs() at warn, scoped to the solution
// showcase app and organism components. Deliberately NOT part of the default export
// consumed by `pnpm lint` (--max-warnings 0 would fail on any warn-level finding here).
import tseslint from "typescript-eslint";
import dbpConfig, { rawDesignValueConfigs, noFreeformSolutionPageConfigs } from "./index.mjs";

const SRC = "*.{js,jsx,mjs,cjs,ts,tsx,mts,cts}";

export default tseslint.config(
  ...dbpConfig,
  ...rawDesignValueConfigs([
    `apps/dbp/**/${SRC}`,
    `packages/stack/app-scaffolds/features/**/${SRC}`,
  ]),
  // G-SEAM/P2: solution/pages/** composition-only shape (see quality-gates-and-conformance.md).
  ...noFreeformSolutionPageConfigs([`apps/*/solution/pages/**/*.tsx`]),
);
