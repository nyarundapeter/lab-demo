# Changelog

All notable changes to this package are documented here.

## [0.2.0] - 2026-07-11
Added `maxLinesConfig` to the ESLint preset (`./eslint`) — ports DWS-01's proven
`max-lines` rule (`warn`, max 400, `skipBlankLines`/`skipComments`) into the shared
factory default instead of a hand-rolled per-repo config. Applied to the monorepo's
`apps/**` in the default export and composed into every scaffolded/exported
solution's generated `eslint.config.mjs`, scoped to `app/**`/`solution/**`.
(Generated Control Slice item #5, `docs/03-features/specs/spec-generated-control-slice-2026-07-11.md`.)

## [0.1.0] - 2026-07-10
Initial documented baseline.
