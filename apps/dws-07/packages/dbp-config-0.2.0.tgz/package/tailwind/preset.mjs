export default {
  theme: {
    extend: {
      colors: {
        /* The solution-overridable brand primaries */
        primary:   "var(--color-primary)",
        secondary: "var(--color-secondary)",
        surface:   "var(--color-surface)",
        border:    "var(--color-border)",
        text:      "var(--color-text)",

        /* App background + secondary surfaces (DQ) */
        background:      "var(--color-background)",
        "surface-2":     "var(--color-surface-2)",
        "surface-navy":  "var(--color-surface-navy)",
        /* Content surface role — the white content surface, distinct from the
         * gray `surface` chrome/panel role above (§1b/§7d). Use `bg-surface-content`
         * for a component's own content background; `bg-surface` stays reserved
         * for shell/layout chrome. */
        "surface-content": "var(--color-surface-content)",

        /* On-primary foreground */
        "primary-foreground": "var(--color-primary-foreground)",

        /* Derived text hierarchy */
        "text-primary":   "var(--color-text-primary)",
        "text-secondary": "var(--color-text-secondary)",
        "text-muted":     "var(--color-text-muted)",
        "text-disabled":  "var(--color-text-disabled)",

        /* Derived border hierarchy */
        "border-subtle":  "var(--color-border-subtle)",
        "border-default": "var(--color-border-default)",
        "border-strong":  "var(--color-border-strong)",

        /* Surface variants */
        "surface-nav":    "var(--color-surface-nav)",
        "surface-accent": "var(--color-surface-accent)",

        /* DQ navy / orange tint ramps */
        "navy-50":    "var(--color-navy-50)",
        "navy-100":   "var(--color-navy-100)",
        "navy-200":   "var(--color-navy-200)",
        "orange-50":  "var(--color-orange-50)",
        "orange-100": "var(--color-orange-100)",
        "orange-600": "var(--color-orange-600)",

        /* Status colours — full semantic triads (base / -surface / -text / -border) */
        success:           "var(--color-success)",
        "success-surface": "var(--color-success-surface)",
        "success-text":    "var(--color-success-text)",
        "success-border":  "var(--color-success-border)",
        warning:           "var(--color-warning)",
        "warning-surface": "var(--color-warning-surface)",
        "warning-text":    "var(--color-warning-text)",
        "warning-border":  "var(--color-warning-border)",
        danger:            "var(--color-danger)",
        "danger-surface":  "var(--color-danger-surface)",
        "danger-text":     "var(--color-danger-text)",
        "danger-border":   "var(--color-danger-border)",
        destructive:       "var(--color-destructive)",
        info:              "var(--color-info)",
        "info-surface":    "var(--color-info-surface)",
        "info-text":       "var(--color-info-text)",
        "info-border":     "var(--color-info-border)",
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body:    ["var(--font-body)",    "system-ui", "sans-serif"],
        sans:    ["var(--font-body)",    "system-ui", "-apple-system", "Segoe UI", "sans-serif"],
        mono:    ["var(--font-mono)",    "ui-monospace", "monospace"],
      },
      borderRadius: {
        DEFAULT: "var(--radius)",
        card:    "var(--radius-card)",
        modal:   "var(--radius-modal)",
        button:  "var(--radius-button)",
        input:   "var(--radius-input)",
        pill:    "var(--radius-pill)",
      },
      boxShadow: {
        sm:    "var(--shadow-sm)",
        md:    "var(--shadow-md)",
        lg:    "var(--shadow-lg)",
        xl:    "var(--shadow-xl)",
        hover: "var(--shadow-hover)",
        /* Focus rings as box-shadow utilities (ring-navy / ring-orange / ring-error) */
        "focus-navy":   "var(--focus-ring-navy)",
        "focus-orange": "var(--focus-ring-orange)",
        "focus-error":  "var(--focus-ring-error)",
      },
    },
  },
};
