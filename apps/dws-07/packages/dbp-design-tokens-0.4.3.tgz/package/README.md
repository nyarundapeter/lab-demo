# @dbp/design-tokens

Two plain CSS files — `base.css` (design token custom properties) and `theme.css` (theme-level overrides) — that carry the DBP Blueprint's canonical design language (colors, spacing, surface tokens). Every generated solution app imports these directly in its `app/globals.css` alongside the `@dbp/config` Tailwind preset, rather than redefining tokens per app.

**Tier:** shared

## Exports
| Export | Path |
|---|---|
| `./base.css` | `./base.css` |
| `./theme.css` | `./theme.css` |

No `publishConfig.exports` override. `files: ["base.css", "theme.css"]` limits what ships in the published tarball to just these two files.

## Config schema
N/A — no config schema in this package (plain CSS, no Zod/TS source).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` writes `"@dbp/design-tokens": "workspace:*"` into every generated solution's `package.json`, and every app's `globals.css` imports `@dbp/design-tokens/base.css` and `@dbp/design-tokens/theme.css` directly (confirmed present in dws-01, wfd-01, dxp-01a, dws-03, sdo-01, dia-03).

## Shipping
Workspace package during monorepo development (`workspace:*`). For standalone repos, it ships as a committed tarball (`file:packages/dbp-design-tokens-0.1.0.tgz`) resolved via `.pnpmfile.cjs` — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
