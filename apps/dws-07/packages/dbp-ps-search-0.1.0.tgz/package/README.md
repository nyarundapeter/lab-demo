# @dbp/ps-search

Search platform service backed by `minisearch`. The server side indexes and
queries registered content; the client side (`configureSearchClient`,
`search`, `index`, `removeFromIndex`, `useSearch`, `useIndex`) is the only
sanctioned way solutions perform search — solutions never embed their own
search index or call a search backend directly.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `./client/index.ts` (source) / `./dist/client/index.js` (published) |
| `./server` | `./server/index.ts` (source) / `./dist/server/index.js` (published) |

`publishConfig.exports` splits both entries to `dist/` with `.d.ts` types — same subpaths, built output only.

## Config schema
See `contract.yaml` (OpenAPI 3.0.3, generated via `pnpm contracts:gen` from Zod schemas in `client/types.ts` — never hand-edited).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` registers `PS.SEARCH` (dir `search`, package `@dbp/ps-search`, base path `/api/platform/search`), wires `configureSearchClient` from `@dbp/ps-search/client`, and conditionally imports `@dbp/ps-search/server` into the generated bootstrap when search is enabled.

## Shipping
Within the monorepo, resolved via pnpm workspace linking. For standalone/client delivery, ships as a packed `.tgz` tarball committed into the standalone's `packages/` dir, resolved via `file:` paths plus the `.pnpmfile.cjs` rewrite hook — see `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
