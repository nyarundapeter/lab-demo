# @dbp/ps-events

A platform-wide event bus service. Producers register with `registerProducer` and publish events via `publish`; consumers read recent events with `getRecentEvents` or the `useRecentEvents` TanStack Query hook. The server side (`server/bus.ts`, `server/subscribe.ts`) provides an in-process pub/sub bus with pluggable storage for recent-event history.

**Tier:** platform-service

## Exports
| Export | Path |
|---|---|
| `./client` | `client/index.ts` (dist: `dist/client/index.js`) |
| `./server` | `server/index.ts` (dist: `dist/server/index.js`) |

`publishConfig.exports` points both subpaths at the built `dist/` output (with `.d.ts` types) instead of the `.ts` sources used in the workspace.

## Config schema
N/A — no standalone Zod config-schema file; client configuration is a plain `EventsClientConfig` object set via `configureEventsClient` (`client/config.ts`).

## Consumed by
Generator emit — `scripts/scaffold-solution.mjs` wires `PS.EVENTS` into every scaffolded solution's `/api/platform/events/[[...path]]` route, calls `configureEventsClient` from `@dbp/ps-events/client`, and imports `getEventsService` from `@dbp/ps-events/server` for workflow/audit event wiring when the solution has events enabled.

## Shipping
Inside this monorepo, apps resolve `@dbp/ps-events` via plain pnpm workspace resolution (`workspace:*`). Standalone repos consume it as a committed `.tgz` tarball, resolved through `.pnpmfile.cjs` rewriting the `@dbp/ps-events` dependency to `file:packages/dbp-ps-events-<version>.tgz`. See `docs/08-contributing/package-distribution.md`.

See [CHANGELOG.md](./CHANGELOG.md) for release history.
